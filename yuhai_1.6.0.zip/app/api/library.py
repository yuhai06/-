"""素材库 API。

目录约定（用户指定）：
    <素材库根>/
      ├─ 待发布/
      │    └─ <日期>/<剧名>/xxx.mp4
      └─ 已发布/
           └─ <日期>/<剧名>/xxx.mp4

解析规则：
    · 按 日期/剧名/文件 三层解析
    · **剧名不丢**：写入 tags（如 ["Beneath_the_Surface"]）与 drama 字段
    · 日期文件夹同时写入 day_dir
    · 目录层级不够时降级：只有一层 → 当剧名；文件在根 → drama 留空

质检分层：
    · 基础项（这里能做）：时长 / 分辨率 / 有无音轨 / 文件大小
    · 深度项（需处理管线产出后回写）：台词完整 / 段间无重叠 / 无静音 / 响度
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from pydantic import BaseModel, Field

from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.api.library")
router = APIRouter(tags=["library"])

# 7 种剧型（按剧名关键词初判，之后可由人工/模型修正）
DRAMA_TYPES = {
    "punch":   {"name": "纯爽反打流", "strong": ["billionaire", "heir", "ceo", "humiliate", "kneel", "beg"]},
    "ethics":  {"name": "伦理撕扯流", "strong": ["divorce", "affair", "mistress", "husband", "custody"]},
    "backer":  {"name": "大佬撑腰流", "strong": ["bodyguard", "protect", "save", "scared", "beat", "threaten"]},
    "mystery": {"name": "倒叙悬疑流", "strong": ["secret", "truth", "hidden", "what happened", "evidence"]},
    "tension": {"name": "张力拉锯流", "strong": ["kiss", "touch", "closer", "breathe", "flirt", "sweetheart"]},
    "sweet":   {"name": "甜宠轻度流", "strong": ["love you", "crush", "blush", "heartbeat", "confess"]},
    "rebirth": {"name": "重生逆袭流", "strong": ["second chance", "rebirth", "reborn", "past life", "i died"]},
}

DATE_RE = re.compile(r"^\d{4}[-_]?\d{2}[-_]?\d{2}$|^\d{4}年\d{1,2}月\d{1,2}日$")


# ---------------- ffprobe ----------------
def ffprobe(path: Path) -> dict:
    cmd = ["ffprobe", "-v", "error", "-print_format", "json",
           "-show_format", "-show_streams", str(path)]
    try:
        r = proc.run(cmd, capture_output=True, text=True, timeout=60,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0:
            return {}
        d = json.loads(r.stdout or "{}")
    except Exception as e:
        log.debug("ffprobe failed: %s", e)
        return {}
    dur = float((d.get("format") or {}).get("duration") or 0)
    bitrate = int((d.get("format") or {}).get("bit_rate") or 0)
    w = h = 0
    has_audio = False
    vcodec = ""
    for s in d.get("streams") or []:
        if s.get("codec_type") == "video" and not w:
            w = int(s.get("width") or 0)
            h = int(s.get("height") or 0)
            vcodec = s.get("codec_name") or ""
        if s.get("codec_type") == "audio":
            has_audio = True
    return {"dur": round(dur, 1), "w": w, "h": h, "audio": has_audio,
            "bitrate": bitrate, "vcodec": vcodec}


# ---------------- 路径解析 ----------------
def parse_path(p: Path, root: Path) -> dict:
    """从 <root>/.../<日期>/<剧名>/<文件> 解析出结构化信息。"""
    try:
        rel = p.relative_to(root)
    except ValueError:
        rel = Path(p.name)
    parts = list(rel.parts)
    file_name = parts[-1] if parts else p.name
    dirs = parts[:-1]

    day_dir = ""
    drama = ""
    bucket = ""

    # 去掉可能的「待发布 / 已发布」这一层
    if dirs and dirs[0] in ("待发布", "已发布"):
        bucket = dirs[0]
        dirs = dirs[1:]

    # 从后往前找日期目录
    date_idx = -1
    for i in range(len(dirs) - 1, -1, -1):
        if DATE_RE.match(dirs[i]) or re.match(r"^(单集|精品混剪|混剪)_\d{4}", dirs[i]):
            date_idx = i
            day_dir = dirs[i]
            break

    if date_idx >= 0:
        rest = dirs[date_idx + 1:]
        drama = rest[0] if rest else ""
    else:
        # 没有日期层：最后一层当剧名
        drama = dirs[-1] if dirs else ""

    stem = p.stem
    line = "premium" if re.search(r"主线|混剪|premium", stem + " " + " ".join(dirs), re.I) else "single"
    m = re.search(r"(?:EP|ep|_e)(\d{1,3})", stem)
    ep = f"EP{int(m.group(1)):02d}" if m else ("主线" if line == "premium" else "")

    return {
        "file": file_name,
        "drama": drama,
        "line": line,
        "ep": ep,
        "day_dir": day_dir,
        "bucket": bucket,
        "rel": str(rel).replace("\\", "/"),
    }


def classify_drama(name: str) -> str:
    low = (name or "").lower()
    best, score = "punch", 0
    for k, cfg in DRAMA_TYPES.items():
        s = sum(3 for w in cfg["strong"] if w in low)
        if s > score:
            best, score = k, s
    return best if score > 0 else ""


# ---------------- 列表 ----------------
@router.get("/library")
async def list_library(q: str = "", dtype: str = "all", line: str = "all",
                       state: str = "all", drama: str = "", tag: str = "",
                       copyright: str = "all"):
    """素材列表。

    drama='*' 表示「全部剧」（不做剧名过滤，前端下拉用）。
    copyright: all | ok | fail | unchecked
    """
    sql = "SELECT * FROM library WHERE 1=1"
    params: list[Any] = []
    if q:
        sql += " AND (file LIKE ? OR drama LIKE ? OR tags LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    if drama and drama != "*":
        sql += " AND drama=?"
        params.append(drama)
    if tag:
        sql += " AND tags LIKE ?"
        params.append(f"%{tag}%")
    if dtype and dtype != "all":
        sql += " AND dtype=?"
        params.append(dtype)
    if line != "all":
        sql += " AND line=?"
        params.append(line)
    if state != "all":
        sql += " AND state=?"
        params.append(state)
    if copyright == "ok":
        sql += " AND copyright_ok=1"
    elif copyright == "fail":
        sql += " AND copyright_ok=0"
    elif copyright == "unchecked":
        sql += " AND copyright_ok IS NULL"
    sql += " ORDER BY created_at DESC, drama, ep"
    rows = db.q(sql, params)

    # 按剧名分组统计
    groups: dict[str, dict] = {}
    for r in rows:
        k = r["drama"] or "未分类"
        g = groups.setdefault(k, {"drama": k, "count": 0, "mb": 0.0,
                                  "dtype": r["dtype"] or "", "copyrightFail": 0})
        g["count"] += 1
        g["mb"] += float(r["size_mb"] or 0)
        if r.get("copyright_ok") == 0:
            g["copyrightFail"] += 1

    for r in rows:
        try:
            r["tagList"] = json.loads(r["tags"] or "[]")
        except Exception:
            r["tagList"] = [r["drama"]] if r["drama"] else []

    cop_fail = sum(1 for r in rows if r.get("copyright_ok") == 0)
    cop_ok = sum(1 for r in rows if r.get("copyright_ok") == 1)

    return {
        "items": rows,
        "groups": sorted(groups.values(), key=lambda x: -x["count"]),
        "types": DRAMA_TYPES,
        "root": str(settings.library_root),
        "roots": [str(p) for p in settings.asset_roots if p.exists()],
        "total": len(rows),
        "totalMb": round(sum(float(r["size_mb"] or 0) for r in rows), 1),
        "copyright": {"ok": cop_ok, "fail": cop_fail,
                      "unchecked": len(rows) - cop_ok - cop_fail},
    }


# ---------------- 版权 ----------------
class CopyrightReq(BaseModel):
    id: str
    ok: bool
    note: str = ""


@router.post("/library/copyright")
async def set_copyright(req: CopyrightReq):
    r = db.q1("SELECT * FROM library WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "不存在")
    db.exec("UPDATE library SET copyright_ok=?,copyright_note=? WHERE id=?",
            (1 if req.ok else 0, req.note or None, req.id))
    if not req.ok:
        db.exec("UPDATE library SET state='blocked',block_reason=? WHERE id=?",
                (f"版权不过：{req.note or '检测未通过'}", req.id))
    return {"ok": True}


class CopyrightBatchReq(BaseModel):
    ids: list[str]
    ok: bool = False
    note: str = ""


@router.post("/library/copyright-batch")
async def set_copyright_batch(req: CopyrightBatchReq):
    n = 0
    for lid in req.ids:
        if not db.q1("SELECT 1 FROM library WHERE id=?", (lid,)):
            continue
        db.exec("UPDATE library SET copyright_ok=?,copyright_note=? WHERE id=?",
                (1 if req.ok else 0, req.note or None, lid))
        if not req.ok:
            db.exec("UPDATE library SET state='blocked',block_reason=? WHERE id=?",
                    (f"版权不过：{req.note or '检测未通过'}", lid))
        n += 1
    return {"ok": True, "updated": n}


@router.post("/library/purge-copyright-fail")
async def purge_copyright_fail(deleteFile: bool = True):
    """删除所有版权不过的素材（默认真删文件）。"""
    rows = db.q("SELECT * FROM library WHERE copyright_ok=0")
    if not rows:
        return {"ok": True, "deleted": 0, "note": "没有版权不过的素材"}
    ok, failed, freed = 0, [], 0.0
    for r in rows:
        size = float(r["size_mb"] or 0)
        if deleteFile:
            p = Path(r["path"])
            if p.exists():
                try:
                    p.unlink()
                    freed += size
                except Exception as e:
                    failed.append({"file": r["file"], "reason": str(e)[:80]})
                    continue
        db.exec("DELETE FROM library WHERE id=?", (r["id"],))
        db.exec("DELETE FROM queue WHERE lib_id=?", (r["id"],))
        ok += 1
    db.log_event("warn", "library",
                 f"清理版权不过素材 {ok} 条，释放 {freed:.0f} MB")
    return {"ok": True, "deleted": ok, "failed": failed,
            "freedMb": round(freed, 1)}


# ---------------- 扫描 ----------------
class ScanReq(BaseModel):
    roots: list[str] = []
    minDuration: float = 15.0
    dryRun: bool = False


@router.post("/library/scan")
async def scan(req: ScanReq | None = None):
    """扫描素材目录，按 日期/剧名/文件 解析入库。

    过滤：mp4/mov、时长 ≥ minDuration、必须有音轨。
    剧名写入 drama + tags（不丢）。
    """
    req = req or ScanReq()
    roots = [Path(p) for p in (req.roots or [str(x) for x in settings.asset_roots])]
    roots = [p for p in roots if p.exists()]
    if not roots:
        raise HTTPException(400, f"素材目录都不存在：{[str(x) for x in settings.asset_roots]}")

    job_id = "job-" + uuid.uuid4().hex[:12]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "scan", "扫描素材库", "running", 0,
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_scan(job_id, roots, req))
    return {"ok": True, "jobId": job_id}


async def _run_scan(job_id: str, roots: list[Path], req: ScanReq) -> None:
    added = skipped = failed = 0
    details: list[dict] = []
    try:
        # 先统计总数用于进度
        files: list[tuple[Path, Path]] = []
        for root in roots:
            for ext in ("*.mp4", "*.mov", "*.MP4", "*.MOV"):
                for f in root.rglob(ext):
                    files.append((f, root))
        total = max(1, len(files))
        log.info("scan: %d candidate files", len(files))

        for i, (f, root) in enumerate(files):
            try:
                exists = db.q1("SELECT id FROM library WHERE path=?", (str(f),))
                if exists:
                    skipped += 1
                    continue

                meta = await asyncio.to_thread(ffprobe, f)
                if not meta:
                    failed += 1
                    details.append({"file": f.name, "reason": "无法解析"})
                    continue
                if not meta.get("audio"):
                    failed += 1
                    details.append({"file": f.name, "reason": "无音轨"})
                    continue
                if meta.get("dur", 0) < req.minDuration:
                    failed += 1
                    details.append({"file": f.name,
                                    "reason": f"时长 {meta['dur']}s < {req.minDuration}s"})
                    continue

                info = parse_path(f, root)
                dtype = classify_drama(info["drama"])
                tags = []
                if info["drama"]:
                    tags.append(info["drama"])
                if info["day_dir"]:
                    tags.append(info["day_dir"])
                tags.append("单集" if info["line"] == "single" else "精品混剪")

                if req.dryRun:
                    added += 1
                    details.append({"file": f.name, "drama": info["drama"],
                                    "line": info["line"], "dry": True})
                    continue

                lid = "lib-" + uuid.uuid4().hex[:10]
                # 2026-11-13：存相对路径（不要管哪个盘，跟着软件目录走）
                from app.services import materialpath as mp
                stored = mp.to_storable(str(f))
                db.exec(
                    "INSERT INTO library(id,path,file,drama,dtype,line,ep,dur,size_mb,"
                    "width,height,made_at,state,qc_no_silence,qc_complete,tags,day_dir,"
                    "created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (lid, stored, info["file"], info["drama"], dtype, info["line"],
                     info["ep"], meta["dur"],
                     round(f.stat().st_size / 1048576, 1),
                     meta["w"], meta["h"],
                     datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds"),
                     "ready", 1 if meta.get("audio") else 0, 1,
                     json.dumps(tags, ensure_ascii=False), info["day_dir"], now_iso()))
                added += 1
            except Exception as e:
                failed += 1
                details.append({"file": f.name, "reason": str(e)[:80]})
            finally:
                if i % 5 == 0 or i == len(files) - 1:
                    db.exec("UPDATE jobs SET progress=? WHERE id=?",
                            (int((i + 1) / total * 100), job_id))

        res = {"added": added, "skipped": skipped, "failed": failed,
               "total": len(files), "details": details[:80]}
        db.exec("UPDATE jobs SET status='done',progress=100,result=?,ended_at=? WHERE id=?",
                (json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "library",
                     f"扫描完成：新增 {added}，跳过 {skipped}，失败 {failed}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "library", str(e)[:200])


# ---------------- 质检 ----------------
class QcReq(BaseModel):
    id: str


@router.post("/library/qc")
async def qc(req: QcReq):
    """基础质检（ffprobe 能测的）：时长 / 分辨率 / 音轨 / 码率。

    ⚠ 2026-11-13 用户反馈"拦截了也不说原因、怎么解决"：
        每条 problem 都必须带 fix（解决办法），前端直接展示。
    """
    r = db.q1("SELECT * FROM library WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "素材不存在")
    p = Path(r["path"])
    if not p.exists():
        # 文件不存在：给出可执行的解决办法
        # ① 尝试在同目录找相似名字（整理改名后的文件）
        suggestion = "重新扫描素材目录（可能文件被移动/改名了）"
        fix_action = "rescan"
        parent = p.parent
        if parent.is_dir():
            same_ext = list(parent.glob(f"*{p.suffix.lower()}"))
            if same_ext:
                suggestion = (f"同目录下有 {len(same_ext)} 个同名类型文件"
                              f"（可能是整理时改了名）。点「重新扫描」"
                              f"让库记录对上真实文件")
                fix_action = "rescan"
            elif not parent.exists():
                suggestion = ("源目录整个没了（可能整理时已清空）。"
                              "这条记录已无对应文件，建议删除")
                fix_action = "delete"
        db.exec("UPDATE library SET state='blocked',"
                "block_reason=? WHERE id=?",
                (f"文件不存在（{suggestion}）", req.id))
        return {"ok": False,
                "problems": [{"problem": "文件不存在", "fix": suggestion,
                              "action": fix_action}],
                "checks": [],
                "meta": {}}

    meta = await asyncio.to_thread(ffprobe, p)
    checks = []
    problems = []

    dur = meta.get("dur", 0)
    checks.append({"name": "时长", "ok": dur >= 15, "value": f"{dur}s",
                   "hint": "≥15s" if dur >= 15 else "过短"})
    if dur < 15:
        problems.append({"problem": f"时长 {dur}s 过短",
                         "fix": "剪到 ≥15s 再入库（切片时调 targetSec）",
                         "action": "recut"})

    w, h = meta.get("w", 0), meta.get("h", 0)
    ratio = h / w if w else 0
    vertical = 0.5 <= ratio <= 2.2
    checks.append({"name": "画幅", "ok": vertical, "value": f"{w}×{h}",
                   "hint": "竖屏或接近方屏" if vertical else "比例异常"})
    if not vertical:
        problems.append({"problem": f"画幅异常 {w}×{h}",
                         "fix": "横屏视频不能直接发 Reels；切片管线裁成 9:16 竖屏",
                         "action": "recut"})

    has_audio = bool(meta.get("audio"))
    checks.append({"name": "音轨", "ok": has_audio,
                   "value": "有" if has_audio else "无", "hint": ""})
    if not has_audio:
        problems.append({"problem": "无音轨",
                         "fix": "Reels 必须有声音；用切片管线加 BGM 或换素材",
                         "action": "recut"})

    br = meta.get("bitrate", 0)
    br_ok = br >= 800_000
    checks.append({"name": "码率", "ok": br_ok,
                   "value": f"{br // 1000} kbps" if br else "—",
                   "hint": "≥800kbps" if br_ok else "偏低"})
    if not br_ok and br:
        problems.append({"problem": f"码率偏低（{br // 1000}kbps）",
                         "fix": "上传后画质会糊；建议用高码率源重新切片",
                         "action": "recut"})

    state = "ready" if not problems else "blocked"
    # block_reason 保留简版（列表显示用），详细 fix 在 qc 返回里
    reason_short = "；".join(x["problem"] for x in problems) if problems else None
    db.exec("UPDATE library SET dur=?,width=?,height=?,state=?,qc_no_silence=?,"
            "block_reason=? WHERE id=?",
            (dur, w, h, state, 1 if has_audio else 0,
             reason_short, req.id))
    return {"ok": not problems, "problems": problems, "checks": checks, "meta": meta}


class QcBatchReq(BaseModel):
    ids: list[str] = []


@router.post("/library/qc-batch")
async def qc_batch(req: QcBatchReq):
    ids = req.ids or [r["id"] for r in db.q("SELECT id FROM library LIMIT 200")]
    out = []
    for lid in ids:
        try:
            out.append({"id": lid, **(await qc(QcReq(id=lid)))})
        except Exception as e:
            out.append({"id": lid, "ok": False, "error": str(e)[:80]})
    ok = sum(1 for x in out if x.get("ok"))
    return {"ok": True, "checked": len(out), "passed": ok, "failed": len(out) - ok,
            "items": out}


# ---------------- 推队列 ----------------
class PushReq(BaseModel):
    ids: list[str]
    page: str = ""
    autoSchedule: bool = True


@router.post("/library/push")
async def push_to_queue(req: PushReq):
    if not req.ids:
        raise HTTPException(400, "ids 为空")
    pushed, skipped = 0, []
    for lid in req.ids:
        r = db.q1("SELECT * FROM library WHERE id=?", (lid,))
        if not r:
            skipped.append({"id": lid, "reason": "不存在"})
            continue
        if r["state"] == "blocked":
            skipped.append({"id": lid, "reason": "质检未通过"})
            continue
        if not Path(r["path"]).exists():
            skipped.append({"id": lid, "reason": "文件不存在"})
            continue
        qid = "q-" + uuid.uuid4().hex[:10]
        db.exec("INSERT INTO queue(id,lib_id,path,file,drama,ep,page,dur,size_mb,state,added_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (qid, lid, r["path"], r["file"], r["drama"], r["ep"], req.page or "",
                 r["dur"], r["size_mb"], "ready", now_iso()))
        db.exec("UPDATE library SET state='used',used_by=? WHERE id=?",
                (now_iso()[:16], lid))
        pushed += 1
    db.log_event("ok", "library", f"推入队列 {pushed} 条")
    return {"ok": True, "pushed": pushed, "skipped": skipped}


@router.delete("/library/{lid}")
async def delete_lib(lid: str, deleteFile: bool = True):
    """删除素材。deleteFile=True 时**真删磁盘文件**（默认真删）。"""
    r = db.q1("SELECT * FROM library WHERE id=?", (lid,))
    if not r:
        raise HTTPException(404, "不存在")
    deleted_file = False
    err = None
    if deleteFile:
        p = Path(r["path"])
        if p.exists():
            try:
                p.unlink()
                deleted_file = True
            except Exception as e:
                err = f"删文件失败: {e}"
                log.warning("delete file failed: %s", e)
        else:
            deleted_file = True    # 已经不在了也算删干净
    db.exec("DELETE FROM library WHERE id=?", (lid,))
    # 顺带清掉引用它的队列条目
    db.exec("DELETE FROM queue WHERE lib_id=?", (lid,))
    db.log_event("warn", "library",
                 f"删除素材 {r['file']}（文件{'已删' if deleted_file else '保留'}）")
    if err:
        raise HTTPException(500, err)
    return {"ok": True, "deletedFile": deleted_file, "path": r["path"]}


class BatchDeleteReq(BaseModel):
    ids: list[str]
    deleteFile: bool = True


@router.post("/library/delete-batch")
async def delete_batch(req: BatchDeleteReq):
    """批量删除素材（可真删文件）。"""
    if not req.ids:
        raise HTTPException(400, "ids 为空")
    ok, failed, freed = 0, [], 0
    for lid in req.ids:
        r = db.q1("SELECT * FROM library WHERE id=?", (lid,))
        if not r:
            failed.append({"id": lid, "reason": "不存在"})
            continue
        size = float(r["size_mb"] or 0)
        if req.deleteFile:
            p = Path(r["path"])
            if p.exists():
                try:
                    p.unlink()
                    freed += size
                except Exception as e:
                    failed.append({"id": lid, "reason": str(e)[:80]})
                    continue
        db.exec("DELETE FROM library WHERE id=?", (lid,))
        db.exec("DELETE FROM queue WHERE lib_id=?", (lid,))
        ok += 1
    db.log_event("warn", "library",
                 f"批量删除 {ok} 条，释放 {freed:.0f} MB，失败 {len(failed)}")
    return {"ok": True, "deleted": ok, "failed": failed,
            "freedMb": round(freed, 1)}


class TagsReq(BaseModel):
    id: str
    tags: list[str]


@router.post("/library/tags")
async def set_tags(req: TagsReq):
    r = db.q1("SELECT * FROM library WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "不存在")
    db.exec("UPDATE library SET tags=? WHERE id=?",
            (json.dumps(req.tags, ensure_ascii=False), req.id))
    # 若剧名在标签里，同步 drama 字段
    if req.tags:
        db.exec("UPDATE library SET drama=? WHERE id=?", (req.tags[0], req.id))
    return {"ok": True}


# ---------------- 待发布 → 已发布 归档 ----------------
class ArchiveReq(BaseModel):
    id: str


@router.post("/library/archive")
async def archive(req: ArchiveReq):
    """把素材从「待发布」移到「已发布」目录（不删除）。"""
    r = db.q1("SELECT * FROM library WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "不存在")
    src = Path(r["path"])
    if not src.exists():
        raise HTTPException(400, "文件不存在")
    root = settings.library_root
    dst_dir = root / "已发布"
    if r["day_dir"]:
        dst_dir = dst_dir / r["day_dir"]
    if r["drama"]:
        dst_dir = dst_dir / r["drama"]
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    try:
        src.replace(dst)
    except Exception as e:
        raise HTTPException(500, f"移动失败: {e}")
    db.exec("UPDATE library SET path=?,state='used' WHERE id=?", (str(dst), req.id))
    return {"ok": True, "path": str(dst)}


# ---------------- 处理管线 ----------------
@router.get("/library/pipeline")
async def pipeline():
    rows = db.q("SELECT * FROM jobs WHERE kind='pipeline' ORDER BY created_at DESC LIMIT 50")
    for r in rows:
        for k in ("steps", "payload", "result"):
            if r.get(k):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
    from app.services import pipeline as pl
    return {"items": rows, "tools": pl.tools_ready(), "steps": pl.STEPS}


class RunPipelineReq(BaseModel):
    drama: str
    sourceDir: str = ""
    single: bool = True
    premium: bool = True
    episodes: list[str] = []
    targetSec: int = 45
    model: str = ""


@router.post("/library/pipeline/run")
async def run_pipeline(req: RunPipelineReq):
    """跑真实处理管线（转录 → 语音检测 → 类型判定 → 张力打分 → 剪辑出片）。"""
    if not req.drama.strip():
        raise HTTPException(400, "剧名不能为空")
    from app.services import pipeline as pl
    ready = pl.tools_ready()
    if not ready["exists"]:
        raise HTTPException(400, f"tools 目录不存在：{ready['toolsDir']}")
    missing = [k for k, v in ready["scripts"].items() if not v]
    if missing:
        raise HTTPException(400, f"缺少脚本：{', '.join(missing)}")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": s["name"], "state": "wait", "note": ""} for s in pl.STEPS]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "pipeline", f"处理 {req.drama}", "queued", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))
    asyncio.create_task(pl.run_pipeline(
        job_id, req.drama, req.sourceDir, req.single, req.premium,
        req.episodes or None, req.targetSec))
    return {"ok": True, "jobId": job_id,
            "steps": [s["name"] for s in pl.STEPS]}


@router.get("/library/tools")
async def tools_check():
    from app.services import pipeline as pl
    return pl.tools_ready()


# ---------------- 目录信息 ----------------
@router.get("/library/roots")
async def roots():
    out = []
    for p in [settings.library_root] + list(settings.asset_roots):
        out.append({
            "path": str(p),
            "exists": p.exists(),
            "files": len(list(p.rglob("*.mp4"))) if p.exists() else 0,
        })
    return {"ok": True, "items": out}


@router.get("/library/source-files")
async def source_files():
    """原始素材目录内容（下载的未处理视频，2026-11-13 新增）。

    目录分离原则：
        视频素材/ = 下载的原始素材（这里展示）
        素材库/   = 整理好的成片（成品库 tab 展示）
    """
    from app import paths as _paths
    root = _paths.source_root()
    items = []
    if root.is_dir():
        # 按一级子目录分组；根下散落的文件归「(根目录)」组
        groups: dict[str, list] = {}
        for f in root.rglob("*"):
            if not f.is_file() or f.suffix.lower() not in (
                    ".mp4", ".mov", ".mkv", ".webm"):
                continue
            rel = f.relative_to(root)
            group = rel.parts[0] if len(rel.parts) > 1 else "(根目录)"
            groups.setdefault(group, []).append({
                "name": f.name,
                "sizeMb": round(f.stat().st_size / 1048576, 1),
                "relDir": str(rel.parent) if len(rel.parts) > 1 else "",
            })
        for name, files in groups.items():
            items.append({"name": name, "count": len(files), "files": files})
    return {"ok": True, "root": str(root), "exists": root.is_dir(),
            "items": items}
    return {"items": out, "libraryRoot": str(settings.library_root)}

# ─────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
# 素材文件导出 / 导入（2026-11-13）
#
# ⚠ 这是**搬文件**，不是备份库：
#     导出 = 把 .mp4 复制到你指定的目录
#     导入 = 把 .mp4 复制进素材库/视频素材
#   不生成 index.json、不重建库记录（导入后可选自动扫描入库）
# ─────────────────────────────────────────────────────────────

class ExportFilesReq(BaseModel):
    ids: list[str] = Field(default_factory=list)
    dramas: list[str] = Field(default_factory=list)
    outDir: str = ""
    flat: bool = False


@router.post("/library/export-files")
async def export_files(req: ExportFilesReq):
    """把素材视频文件复制到指定目录（不碰数据库）。"""
    from app.services import material_files as mf
    from app.paths import DATA_DIR

    out_dir = Path(req.outDir) if req.outDir else (
        Path(DATA_DIR) / "export_files")
    r = await asyncio.to_thread(
        mf.export_files, out_dir, req.ids or None,
        req.dramas or None, req.flat)
    return r


class ImportFilesReq(BaseModel):
    srcDir: str
    target: str = "素材库"        # 素材库 | 视频素材
    asDrama: str = ""
    autoScan: bool = False


@router.post("/library/import-files")
async def import_files(req: ImportFilesReq):
    """把某个目录里的视频文件复制进软件目录。"""
    from app.services import material_files as mf
    p = Path(req.srcDir)
    if not p.exists():
        raise HTTPException(400, f"路径不存在: {req.srcDir}")
    r = await asyncio.to_thread(
        mf.import_files, p, req.target, req.asDrama, req.autoScan)
    return r


@router.get("/library/import-dirs")
async def import_dirs():
    """可导入的候选目录。"""
    from app.services import material_files as mf
    return {"ok": True, "items": mf.list_source_dirs()}


@router.post("/library/import-files/upload")
async def import_files_upload(files: list[UploadFile] = File(...)):
    """上传视频文件到临时目录（前端选文件用），返回目录路径。"""
    from app.paths import DATA_DIR
    d = Path(DATA_DIR) / "exports" / "_incoming"
    d.mkdir(parents=True, exist_ok=True)
    saved = 0
    total = 0
    for f in files:
        name = (f.filename or "video.mp4").replace("/", "_").replace("\\", "_")
        dst = d / name
        n = 2
        while dst.exists():
            dst = d / f"{Path(name).stem}_{n}{Path(name).suffix}"
            n += 1
        content = await f.read()
        dst.write_bytes(content)
        saved += 1
        total += len(content)
    return {"ok": True, "dir": str(d), "saved": saved,
            "totalMb": round(total / 1048576, 1)}


@router.post("/library/migrate-paths")
async def migrate_paths():
    """把库里现有的绝对路径统一转成相对形式（一次性迁移）。"""
    from app.services import materialpath as mp
    return await asyncio.to_thread(mp.migrate_db_paths)
# ─────────────────────────────────────────────────────────────
# 素材库路径设置（2026-11-13 用户要求"这个路径能改吗"）
# ─────────────────────────────────────────────────────────────

class PathCfgReq(BaseModel):
    libraryRoot: str = ""
    videoRoot: str = ""
    outputRoot: str = ""


@router.get("/library/path-config")
async def get_path_config():
    """当前三个素材目录配置（含是否可写）。"""
    from app import paths as _p
    out = {}
    for key, fn in (("libraryRoot", _p.library_root),
                    ("videoRoot", _p.source_root),
                    ("outputRoot", _p.output_root)):
        try:
            p = Path(fn())
            # 可写检测
            writable = False
            try:
                p.mkdir(parents=True, exist_ok=True)
                probe = p / ".write_probe"
                probe.write_text("1", encoding="utf-8")
                probe.unlink()
                writable = True
            except Exception:
                writable = False
            out[key] = {"path": str(p), "exists": p.is_dir(),
                        "writable": writable}
        except Exception as e:
            out[key] = {"path": "", "error": str(e)[:80]}
    return {"ok": True, **out}


@router.post("/library/path-config")
async def set_path_config(req: PathCfgReq):
    """修改素材目录（写进 data/config.json，重启后生效）。

    只写配置，**不搬文件**（用户自己挪）。
    """
    import json as _json
    from app.config import settings

    cfg_path = Path(settings.data_dir) / "config.json"
    cfg: dict = {}
    try:
        if cfg_path.is_file():
            cfg = _json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}

    changed = []
    if req.libraryRoot.strip():
        d = Path(req.libraryRoot.strip())
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise HTTPException(400, f"目录不可用: {e}")
        cfg["library_root"] = str(d)
        changed.append(f"素材库 → {d}")
    if req.videoRoot.strip():
        d = Path(req.videoRoot.strip())
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise HTTPException(400, f"目录不可用: {e}")
        cfg["source_root"] = str(d)
        changed.append(f"视频素材 → {d}")
    if req.outputRoot.strip():
        d = Path(req.outputRoot.strip())
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            raise HTTPException(400, f"目录不可用: {e}")
        cfg["output"] = str(d)
        changed.append(f"处理好素材 → {d}")

    if not changed:
        raise HTTPException(400, "没有要修改的路径")

    try:
        cfg_path.write_text(
            _json.dumps(cfg, ensure_ascii=False, indent=2),
            encoding="utf-8")
    except Exception as e:
        raise HTTPException(500, f"写配置失败: {e}")

    db.log_event("info", "library", "修改素材路径: " + "；".join(changed))
    return {"ok": True, "changed": changed,
            "note": "已保存。重启软件后生效（旧记录需要重新扫描）。"}