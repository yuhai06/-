/* 视频数据（三级下钻：号 → 主页 → 视频）
   剧名不是主键，用标签归类。 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import {
  nfmt, pct, badge, pageHead, statCard, lineChart, sparkline,
  $, $$, toast, modal, bar, ts, ago, emptyState,
} from '../ui.js';

let days = 14;
let sortKey = 'plays';
let q = '';
let aiFits = [];
// 三级下钻：account（号总览）→ page（主页总览）→ video（视频明细）
let level = 'account';
let curAccount = '';
let curPage = '';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '视频数据',
      desc: '按号 → 主页 → 视频 三级下钻 · 30 天窗口',
      actions: [
        `<button class="btn sm" data-act="ask-agent"><span data-icon="bolt"></span>问 Agent</button>`,
        `<button class="btn sm" data-act="collect"><span data-icon="refresh"></span>批量采集</button>`,
        `<button class="btn sm ghost" data-act="collect-one"><span data-icon="target"></span>单独采集</button>`,
        `<button class="btn sm ghost" data-act="manual"><span data-icon="plus"></span>手录指标</button>`,
      ],
    })}
    <div id="vd-crumb" style="margin-bottom:11px"></div>
    <div id="vd-body"></div>
  `;

  $$('[data-act="collect"]', root).forEach((b) => (b.onclick = () => doCollect(b)));
  $$('[data-act="collect-one"]', root).forEach((b) => (b.onclick = () => openCollectOne()));
  $$('[data-act="manual"]', root).forEach((b) => (b.onclick = openManual));
  $$('[data-act="ask-agent"]', root).forEach((b) => (b.onclick = () => askAgent(root)));

  paint(root);
  load(root);
}

async function load(root) {
  // 先把号/主页/环境这些基础数据准备好，否则三级下钻分不清归属
  try {
    if (!store.pages || !store.pages.length) await store.loadCore();
    if (!store.accountsData || !(store.accountsData.items || []).length) {
      store.accountsData = await api.accounts();
    }
  } catch (e) {
    console.warn('core load failed', e.message);
  }

  await Promise.all([
    store.loadOverview(days),
    store.loadVideos({ days }),
    (async () => {
      try { aiFits = (await api.aiFit()).items || []; } catch { aiFits = []; }
    })(),
    (async () => {
      try { if (!store.dsh) store.dsh = await api.dshStatus(); } catch { store.dsh = null; }
    })(),
  ]);
  paint(root);
}
/* 三级下钻的渲染：号总览 → 主页总览 → 视频明细 */

function paint(root) {
  const body = $('#vd-body', root);
  const crumb = $('#vd-crumb', root);
  if (!body) return;

  const videos = store.videos || [];
  const ov = store.overview || {};
  const pages = store.pages || [];
  const accs = (store.accountsData && store.accountsData.items) || [];

  // ---- 面包屑 ----
  if (crumb) {
    const parts = [
      `<span class="crumb-item ${level === 'account' ? 'on' : ''}" data-lv="account">全部号</span>`,
    ];
    if (level !== 'account' && curAccount) {
      parts.push(`<span class="crumb-sep">›</span>
        <span class="crumb-item ${level === 'page' ? 'on' : ''}" data-lv="page">${esc(curAccount)}</span>`);
    }
    if (level === 'video' && curPage) {
      parts.push(`<span class="crumb-sep">›</span>
        <span class="crumb-item on">${esc(curPage)}</span>`);
    }
    crumb.innerHTML = `<div class="crumbs">${parts.join('')}</div>`;
    $$('[data-lv]', crumb).forEach((el) => {
      el.onclick = () => {
        const lv = el.dataset.lv;
        if (lv === 'account') { level = 'account'; curAccount = ''; curPage = ''; }
        else if (lv === 'page') { level = 'page'; curPage = ''; }
        paint(root);
      };
    });
  }

  // ---- 按级别渲染 ----
  if (level === 'account') return paintAccounts(body, root, videos, pages, accs, ov);
  if (level === 'page') return paintPages(body, root, videos, pages, ov);
  return paintVideos(body, root, videos, ov);
}

/* ================= 第一级：号总览 ================= */
function paintAccounts(body, root, videos, pages, accs, ov) {
  // 直接按 envCode 建映射：号 → 环境 → 主页
  const envToAcc = {};
  accs.forEach((a) => { if (a.envCode) envToAcc[String(a.envCode)] = a; });

  const groups = {};
  accs.forEach((a) => {
    groups[a.id] = {
      id: a.id, label: a.label, role: a.role, cUser: a.cUser,
      envCode: a.envCode, quota: a.quotaLabel || a.quotaLevel,
      pages: [], plays: 0, clicks: 0, reactions: 0, comments: 0,
      shares: 0, videoCount: 0,
    };
  });
  const orphan = {
    id: '__orphan__', label: '未归属主页', role: 'spare', cUser: '',
    envCode: '', quota: '', pages: [], plays: 0, clicks: 0,
    reactions: 0, comments: 0, shares: 0, videoCount: 0,
  };

  // 主页 → 号（用 envCode 直接对）
  pages.forEach((p) => {
    const acc = envToAcc[String(p.envCode || '')];
    const g = acc ? groups[acc.id] : orphan;
    g.pages.push({ pageId: p.profileId, name: p.name, plays: 0, clicks: 0,
                   videoCount: 0, reactions: 0, comments: 0, shares: 0 });
  });

  // 视频指标累加
  const pmap = {};
  Object.values(groups).forEach((g) => g.pages.forEach((p) => { pmap[p.pageId] = p; }));
  orphan.pages.forEach((p) => { pmap[p.pageId] = p; });

  videos.forEach((v) => {
    const m = v.metrics || {};
    const p = pmap[v.pageId];
    if (!p) return;
    p.plays += m.plays || 0;
    p.clicks += m.clicks || 0;
    p.reactions += m.reactions || 0;
    p.comments += m.comments || 0;
    p.shares += m.shares || 0;
    p.videoCount += 1;
  });

  const all = [...Object.values(groups), orphan].filter((g) => g.pages.length || g.label);
  all.forEach((g) => {
    g.pages.forEach((p) => {
      g.plays += p.plays; g.clicks += p.clicks;
      g.reactions += p.reactions; g.comments += p.comments;
      g.shares += p.shares; g.videoCount += p.videoCount;
    });
  });
  all.sort((a, b) => b.plays - a.plays);

  const totPlays = all.reduce((a, g) => a + g.plays, 0);
  const totClicks = all.reduce((a, g) => a + g.clicks, 0);
  const totPages = all.reduce((a, g) => a + g.pages.length, 0);

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: `近 ${days} 天播放`, value: nfmt(totPlays), unit: '次', iconName: 'eye' })}
      ${statCard({ label: '出站点击', value: nfmt(totClicks), unit: '次', iconName: 'link',
                   foot: totPlays ? `CTR ${((totClicks / totPlays) * 100).toFixed(2)}%` : '' })}
      ${statCard({ label: '号数', value: all.filter((g) => g.role !== 'spare').length, unit: '个',
                   iconName: 'key', foot: `${totPages} 个主页` })}
      ${statCard({ label: '视频总数', value: videos.length, unit: '条', iconName: 'video' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title">按号汇总 <span class="sub">点进去看主页</span></div>
        <div class="seg" data-seg="range">
          <button data-v="7" class="${days === 7 ? 'on' : ''}">7 天</button>
          <button data-v="14" class="${days === 14 ? 'on' : ''}">14 天</button>
          <button data-v="30" class="${days === 30 ? 'on' : ''}">30 天</button>
        </div>
      </div>
      <div class="card-body tight">
        ${all.length ? `
        <div class="tbl-wrap">
          <table class="tbl">
            <thead><tr>
              <th>号</th><th>角色</th><th>c_user</th>
              <th class="num">主页</th><th class="num">视频</th>
              <th class="num">播放</th><th class="num">点击</th>
              <th class="num">互动</th><th class="num">均播</th>
              <th class="num">额度</th><th class="actions"></th>
            </tr></thead>
            <tbody>
              ${all.map((g) => {
                const avg = g.videoCount ? Math.round(g.plays / g.videoCount) : 0;
                const eng = g.reactions + g.comments + g.shares;
                return `
                  <tr data-acc="${g.id}" style="cursor:pointer">
                    <td><b style="font-size:12px">${esc(g.label)}</b></td>
                    <td>${g.role === 'publisher' ? badge('发布号', 'info')
                      : g.role === 'backup' ? badge('备份号', 'purple')
                      : badge('—', 'mute')}</td>
                    <td class="mono" style="font-size:10px">${g.cUser || '—'}</td>
                    <td class="num">${g.pages.length}</td>
                    <td class="num">${g.videoCount}</td>
                    <td class="num" style="font-weight:600">${nfmt(g.plays)}</td>
                    <td class="num" style="color:${g.clicks ? 'var(--ok)' : 'var(--tx-3)'}">${nfmt(g.clicks)}</td>
                    <td class="num">${nfmt(eng)}</td>
                    <td class="num">${nfmt(avg)}</td>
                    <td class="num" style="font-size:10px;color:var(--tx-2)">${esc(g.quota || '—')}</td>
                    <td class="actions">
                      <button class="btn xs ghost" data-acc-go="${g.id}">查看 ›</button>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>` : `<div class="card-body">${emptyState('还没有数据', '先去采集')}</div>`}
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        按号汇总 → 点某个号看它名下所有公共主页的合计 → 再点主页看单条视频。
        这样号多了也不会一屏几千行。
      </div>
    </div>`;

  $$('[data-seg="range"] button', body).forEach((b) => {
    b.onclick = () => { days = +b.dataset.v; load(root); };
  });
  $$('[data-acc]', body).forEach((tr) => {
    tr.onclick = () => {
      curAccount = tr.dataset.acc;
      level = 'page';
      curPage = '';
      paint(root);
    };
  });
}

/* ================= 第二级：某号的主页总览 ================= */
function paintPages(body, root, videos, pages, ov) {
  const envToAcc = {};
  ((store.accountsData && store.accountsData.items) || []).forEach((a) => {
    if (a.envCode) envToAcc[a.envCode] = a;
  });
  const acc = ((store.accountsData && store.accountsData.items) || [])
    .find((a) => a.id === curAccount);
  const accName = acc ? acc.label : '未归属主页';

  // 这个号的主页
  let myPages = pages.filter((p) => {
    if (curAccount === '__orphan__') {
      const env = p.envCode || '';
      return !envToAcc[env];
    }
    return acc && p.envCode === acc.envCode;
  });
  // 若按 env 没匹配到，退回按视频归属
  if (!myPages.length && acc) {
    const pids = new Set(videos.map((v) => v.pageId));
    myPages = pages.filter((p) => pids.has(p.profileId));
  }

  const byPage = {};
  myPages.forEach((p) => {
    byPage[p.profileId] = {
      pageId: p.profileId, name: p.name, assetId: p.assetId,
      health: p.health, plays: 0, clicks: 0, reactions: 0,
      comments: 0, shares: 0, videoCount: 0,
    };
  });
  videos.forEach((v) => {
    const m = v.metrics || {};
    const g = byPage[v.pageId];
    if (!g) return;
    g.plays += m.plays || 0;
    g.clicks += m.clicks || 0;
    g.reactions += m.reactions || 0;
    g.comments += m.comments || 0;
    g.shares += m.shares || 0;
    g.videoCount += 1;
  });

  const list = Object.values(byPage).sort((a, b) => b.plays - a.plays);
  const totPlays = list.reduce((a, g) => a + g.plays, 0);
  const totClicks = list.reduce((a, g) => a + g.clicks, 0);
  const totVideos = list.reduce((a, g) => a + g.videoCount, 0);

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '号', value: accName, unit: '', iconName: 'key',
                   foot: acc ? `c_user ${acc.cUser || '—'}` : '' })}
      ${statCard({ label: '主页数', value: list.length, unit: '个', iconName: 'flag' })}
      ${statCard({ label: '播放合计', value: nfmt(totPlays), unit: '次', iconName: 'eye' })}
      ${statCard({ label: '点击合计', value: nfmt(totClicks), unit: '次', iconName: 'link',
                   foot: totPlays ? `CTR ${((totClicks / totPlays) * 100).toFixed(2)}%` : '' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title">${esc(accName)} 的主页 <span class="sub">${list.length} 个 · 点进去看视频</span></div>
      </div>
      <div class="card-body tight">
        ${list.length ? `
        <div class="tbl-wrap">
          <table class="tbl">
            <thead><tr>
              <th>主页</th><th>page_id</th>
              <th class="num">视频</th><th class="num">播放</th>
              <th class="num">点击</th><th class="num">互动</th>
              <th class="num">均播</th><th>状态</th><th class="actions"></th>
            </tr></thead>
            <tbody>
              ${list.map((g) => {
                const avg = g.videoCount ? Math.round(g.plays / g.videoCount) : 0;
                const eng = g.reactions + g.comments + g.shares;
                return `
                  <tr data-pg="${g.pageId}" style="cursor:pointer">
                    <td><b style="font-family:var(--mono);color:var(--ac);font-size:11.5px">${esc(g.name)}</b></td>
                    <td class="mono" style="font-size:10px">${g.pageId}</td>
                    <td class="num">${g.videoCount}</td>
                    <td class="num" style="font-weight:600">${nfmt(g.plays)}</td>
                    <td class="num" style="color:${g.clicks ? 'var(--ok)' : 'var(--tx-3)'}">${nfmt(g.clicks)}</td>
                    <td class="num">${nfmt(eng)}</td>
                    <td class="num">${nfmt(avg)}</td>
                    <td>${g.health === 'ok' ? badge('正常', 'ok', true) : badge(g.health || '未知', 'warn', true)}</td>
                    <td class="actions">
                      <button class="btn xs ghost" data-pg-go="${g.pageId}">视频 ›</button>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>` : `<div class="card-body">${emptyState('这个号下还没有主页数据', '先提取主页或采集视频')}</div>`}
      </div>
    </div>`;

  $$('[data-pg]', body).forEach((tr) => {
    tr.onclick = () => {
      curPage = tr.dataset.pg;
      level = 'video';
      paint(root);
    };
  });
}

/* ================= 第三级：单主页的视频明细 ================= */
function paintVideos(body, root, videos, ov) {
  let list = videos.filter((v) => v.pageId === curPage);
  if (q) {
    const k = q.toLowerCase();
    list = list.filter((v) => (v.title || '').toLowerCase().includes(k)
      || (v.postId || '').toLowerCase().includes(k)
      || (v.tags || []).some((t) => t.toLowerCase().includes(k)));
  }
  const sorters = {
    plays: (a, b) => (b.metrics.plays || 0) - (a.metrics.plays || 0),
    clicks: (a, b) => (b.metrics.clicks || 0) - (a.metrics.clicks || 0),
    watch: (a, b) => (b.metrics.avgWatch || 0) - (a.metrics.avgWatch || 0),
    time: (a, b) => String(b.publishedDate || '').localeCompare(String(a.publishedDate || '')),
  };
  list.sort(sorters[sortKey] || sorters.plays);

  const pg = (store.pages || []).find((p) => p.profileId === curPage) || {};
  const plays = list.reduce((a, v) => a + (v.metrics.plays || 0), 0);
  const clicks = list.reduce((a, v) => a + (v.metrics.clicks || 0), 0);

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '主页', value: pg.name || curPage, unit: '', iconName: 'flag',
                   foot: pg.assetId ? 'asset OK' : '缺 asset_id' })}
      ${statCard({ label: '视频数', value: list.length, unit: '条', iconName: 'video' })}
      ${statCard({ label: '播放合计', value: nfmt(plays), unit: '次', iconName: 'eye' })}
      ${statCard({ label: '点击合计', value: nfmt(clicks), unit: '次', iconName: 'link',
                   foot: plays ? `CTR ${((clicks / plays) * 100).toFixed(2)}%` : '' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title">${esc(pg.name || curPage)} 的视频 <span class="sub">${list.length} 条</span></div>
        <div style="display:flex;gap:7px;align-items:center">
          <input class="input" id="vd-q" placeholder="搜标题 / 标签" value="${q}"
                 style="width:150px;padding:4px 8px;font-size:11.5px" />
          <div class="seg" data-seg="sort">
            <button class="${sortKey === 'plays' ? 'on' : ''}" data-v="plays">播放</button>
            <button class="${sortKey === 'clicks' ? 'on' : ''}" data-v="clicks">点击</button>
            <button class="${sortKey === 'watch' ? 'on' : ''}" data-v="watch">均播</button>
            <button class="${sortKey === 'time' ? 'on' : ''}" data-v="time">时间</button>
          </div>
        </div>
      </div>
      <div class="card-body tight">
        ${list.length ? `
        <div class="tbl-wrap">
          <table class="tbl">
            <thead><tr>
              <th style="width:34%">视频</th><th>发布时间</th>
              <th class="num">播放</th><th class="num">覆盖</th>
              <th class="num">互动</th><th class="num">评论</th>
              <th class="num">分享</th><th class="num">点击</th>
              <th class="num">均播</th><th>标签</th><th class="actions"></th>
            </tr></thead>
            <tbody>
              ${list.map((v) => {
                const m = v.metrics || {};
                const eng = (m.reactions || 0) + (m.comments || 0) + (m.shares || 0);
                return `
                  <tr data-vid="${v.id}">
                    <td>
                      <div style="font-size:11.5px;line-height:1.4;max-width:320px;
                                  overflow:hidden;text-overflow:ellipsis;display:-webkit-box;
                                  -webkit-line-clamp:2;-webkit-box-orient:vertical">
                        ${esc(v.title || '（无标题）')}
                      </div>
                      <div style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3);margin-top:2px">
                        ${v.postId}
                      </div>
                    </td>
                    <td style="font-size:10.5px;color:var(--tx-2);white-space:nowrap">
                      ${v.publishedDate || v.publishedAt || '—'}
                    </td>
                    <td class="num" style="font-weight:600;color:${(m.plays || 0) > 0 ? 'var(--tx-0)' : 'var(--tx-3)'}">${nfmt(m.plays)}</td>
                    <td class="num">${nfmt(m.reach)}</td>
                    <td class="num">${nfmt(eng)}</td>
                    <td class="num">${nfmt(m.comments)}</td>
                    <td class="num">${nfmt(m.shares)}</td>
                    <td class="num" style="color:${(m.clicks || 0) > 0 ? 'var(--ok)' : 'var(--tx-3)'}">${nfmt(m.clicks)}</td>
                    <td class="num">${m.avgWatch ? m.avgWatch + 's' : '—'}</td>
                    <td>
                      <div style="display:flex;gap:3px;flex-wrap:wrap">
                        ${(v.tags || []).map((t) => `<span class="badge info" style="font-size:9px">${esc(t)}</span>`).join('')
                          || '<span style="font-size:10px;color:var(--tx-3)">—</span>'}
                      </div>
                    </td>
                    <td class="actions">
                      <button class="btn xs ghost" data-x="detail" data-id="${v.id}">详情</button>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>` : `<div class="card-body">${emptyState('这个主页没有视频数据', '点右上「采集数据」')}</div>`}
      </div>
    </div>

    <div class="card" style="margin-top:13px">
      <div class="card-head">
        <div class="card-title">AI 内容适配分析
          <span class="sub">${aiFits.length} 个主页已分析</span>
        </div>
        
      </div>
      <div class="card-body tight" style="max-height:300px;overflow-y:auto">
        ${aiFits.length ? aiFits.map((f) => {
          const ok = f.ready;
          return `
            <div class="litem">
              <span class="dot ${ok ? 'ok' : 'warn'}"></span>
              <div class="litem-main">
                <div class="litem-title">
                  <b style="font-family:var(--mono);color:var(--ac)">${esc(f.pageName)}</b>
                  ${ok ? badge(f.dramaType || 'unknown', 'info') : badge('样本不足', 'warn')}
                  <span style="font-size:9.5px;color:var(--tx-3);font-family:var(--mono)">
                    样本 ${f.sample} · 置信 ${((f.confidence || 0) * 100).toFixed(0)}%
                  </span>
                </div>
                <div class="litem-sub" style="font-family:var(--sans);line-height:1.5">
                  ${esc(f.reason || '')}
                </div>
              </div>
              <button class="btn xs ghost" data-askpage="${f.pageId}">问 Agent</button>
            </div>`;
        }).join('') : `<div class="litem" style="justify-content:center;color:var(--tx-3);padding:22px">
            还没有分析结果 · 点「全部分析」
          </div>`}
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;
                  color:var(--tx-3);line-height:1.6">
        冷启动说明：单主页有效样本（播放 ≥50）不足 8 条时，AI 只标记「样本不足」不下结论。
      </div>
    </div>`;

  const qi = $('#vd-q', body);
  if (qi) qi.oninput = (e) => { q = e.target.value; paint(root); };
  $$('[data-seg="sort"] button', body).forEach((b) => {
    b.onclick = () => { sortKey = b.dataset.v; paint(root); };
  });
  $$('[data-x="detail"]', body).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openDetail(b.dataset.id); };
  });
  $$('[data-askpage]', body).forEach((b) => {
    b.onclick = (e) => {
      e.stopPropagation();
      try {
        sessionStorage.setItem('agent_prefill',
          '分析主页 ' + b.dataset.askpage + ' 的数据表现，建议发什么剧');
      } catch (x) { /* ignore */ }
      location.hash = '#/agent';
    };
  });

}


function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ---------------- 详情 ---------------- */
async function openDetail(id) {
  let d;
  try {
    d = await api.video(id);
  } catch (e) {
    return toast('加载失败', e.message, 'err');
  }
  const body = document.createElement('div');
  const series = d.series || [];
  const tot = d.total || {};
  body.innerHTML = `
    <div style="font-size:12.5px;line-height:1.5;margin-bottom:12px">${esc(d.title || '')}</div>
    <div class="grid g2" style="margin-bottom:14px">
      <div>
        <div class="kv"><span class="k">主页</span><span class="v">${d.pageName || '—'}</span></div>
        <div class="kv"><span class="k">post_id</span><span class="v">${d.postId}</span></div>
        <div class="kv"><span class="k">发布时间</span><span class="v">${d.publishedDate || d.publishedAt || '—'}</span></div>
      </div>
      <div>
        <div class="kv"><span class="k">累计播放</span><span class="v">${nfmt(tot.plays)}</span></div>
        <div class="kv"><span class="k">累计点击</span><span class="v">${nfmt(tot.clicks)}</span></div>
        <div class="kv"><span class="k">累计互动</span><span class="v">${nfmt((tot.reactions || 0) + (tot.comments || 0) + (tot.shares || 0))}</span></div>
      </div>
    </div>
    <div class="section-title">播放曲线</div>
    <div style="margin-bottom:14px">
      ${series.length ? lineChart(series.map((x) => ({ date: x.date, views: x.plays || 0 })), { hgt: 140, key: 'views' })
        : `<div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11.5px">暂无时序</div>`}
    </div>
    <div class="section-title">标签</div>
    <div class="field">
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px" id="tag-list">
        ${(d.tags || []).map((t) => `<span class="badge info">${esc(t)}</span>`).join('')
          || '<span style="font-size:11px;color:var(--tx-3)">还没有标签</span>'}
      </div>
      <div style="display:flex;gap:6px">
        <input class="input" id="tag-in" placeholder="加标签，回车确认" />
        <button class="btn sm" id="tag-add">添加</button>
      </div>
    </div>`;
  const m = modal({
    title: '视频详情',
    width: 'wide',
    body,
    footer: [Object.assign(document.createElement('button'), {
      className: 'btn', textContent: '关闭', onclick: () => m.close(),
    })],
  });

  const addTag = async () => {
    const inp = body.querySelector('#tag-in');
    const t = (inp.value || '').trim();
    if (!t) return;
    const tags = [...(d.tags || []), t];
    try {
      await api.setTags(d.id, tags);
      d.tags = tags;
      body.querySelector('#tag-list').innerHTML = tags.map((x) => `<span class="badge info">${esc(x)}</span>`).join('');
      inp.value = '';
      toast('已添加', t, 'ok');
    } catch (e) { toast('失败', e.message, 'err'); }
  };
  body.querySelector('#tag-add').onclick = addTag;
  body.querySelector('#tag-in').onkeydown = (e) => { if (e.key === 'Enter') addTag(); };
}

/* ---------------- 问 Agent（替代原 AI 分析） ---------------- */
function askAgent(root) {
  const q = '分析一下当前各主页的数据表现，建议发什么剧';
  try { sessionStorage.setItem('agent_prefill', q); } catch (e) { /* ignore */ }
  location.hash = '#/agent';
}

/* ---------------- 统计报表 ---------------- */


/* ---------------- 单独采集（主页 / 视频 / 账号 各一条） ---------------- */
async function openCollectOne() {
  let data = null;
  try {
    data = await api.insightsTargets();
  } catch (e) {
    return toast('读取目标失败', e.message, 'err');
  }
  const pages = (data && data.pages) || [];
  const units = (data && data.units) || [];
  if (!pages.length && !units.length) {
    return toast('没有可采集目标', '先到「主页与授权」扫描主页', 'warn');
  }

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field" style="margin-bottom:12px">
      <label style="display:block;margin-bottom:6px">采集类型</label>
      <div style="display:flex;gap:6px">
        <button class="btn xs primary" data-ctype="page">单个主页</button>
        <button class="btn xs ghost" data-ctype="unit">单条视频</button>
        <button class="btn xs ghost" data-ctype="account">单个账号</button>
      </div>
    </div>
    <div class="field" id="co-pick" style="margin-bottom:12px">
      <label>选择主页（${pages.length} 个）</label>
      <select class="select" id="co-page" style="width:100%">
        ${pages.map((p) => `<option value="${esc(p.id)}">${esc(p.name || p.id)} · ${p.followers || 0} 粉丝 · ${p.views30d || 0} 播放</option>`).join('')}
      </select>
    </div>
    <div class="field" id="co-pick-unit" style="margin-bottom:12px;display:none">
      <label>选择视频（${units.length} 条）</label>
      <select class="select" id="co-unit" style="width:100%">
        ${units.slice(0, 200).map((u) => `<option value="${esc(u.id)}">${esc(u.pageName || '?')} · ${esc((u.title || u.file || '').slice(0, 40))}</option>`).join('')}
      </select>
    </div>
    <p class="muted" style="font-size:10.5px;line-height:1.7;margin:8px 0 0">
      与「批量采集」用的是同一套方法（内容库表格 + 可选 Graph API），
      只是把范围缩小到你选的这一个。
    </p>
    <div id="co-result" style="margin-top:12px"></div>
  `;

  const host = document.createElement('div');
  host.id = 'co-host-el';
  host.appendChild(body);

  // 先声明，供按钮回调引用（避免 TDZ）
  let m = null;

  const btnClose = Object.assign(document.createElement('button'), {
    className: 'btn',
    textContent: '关闭',
    onclick: () => { if (m) m.close(); },
  });
  const btnRun = Object.assign(document.createElement('button'), {
    className: 'btn primary',
    textContent: '开始采集',
    onclick: async () => {
      btnRun.disabled = true;
      const old = btnRun.textContent;
      btnRun.textContent = '采集中…';
      try { await runCollectOne(body); }
      finally { btnRun.disabled = false; btnRun.textContent = old; }
    },
  });

  m = modal({
    title: '单独采集',
    body: host,
    footer: [btnClose, btnRun],
    width: '520px',
  });

  if (host) {

    // 类型切换
    let ctype = 'page';
    body.querySelectorAll('[data-ctype]').forEach((b) => {
      b.onclick = () => {
        ctype = b.dataset.ctype;
        body.querySelectorAll('[data-ctype]').forEach((x) => {
          x.className = 'btn xs ' + (x.dataset.ctype === ctype ? 'primary' : 'ghost');
        });
        document.getElementById('co-pick').style.display = ctype === 'unit' ? 'none' : '';
        document.getElementById('co-pick-unit').style.display = ctype === 'unit' ? '' : 'none';
      };
    });
    body.dataset.ctype = 'page';
    body._getCtype = () => {
      const on = body.querySelector('[data-ctype].primary');
      return on ? on.dataset.ctype : 'page';
    };
  }
}

async function runCollectOne(body) {
  const ctype = body._getCtype ? body._getCtype() : 'page';
  const sel = ctype === 'unit'
    ? document.getElementById('co-unit')
    : document.getElementById('co-page');
  const tid = sel ? sel.value : '';
  if (!tid) return toast('请选择目标', '', 'warn');

  const out = document.getElementById('co-result');
  if (out) {
    out.innerHTML = `<div style="padding:10px;font-size:11px;color:var(--tx-3);line-height:1.8">
      正在采集…（与批量采集同一套方法，单主页约 10-30 秒）</div>`;
  }

  try {
    const r = await api.collectOne({
      targetType: ctype, targetId: tid, days: 30, saveRaw: true,
    });
    if (!out) return;

    const sm = r.summary || {};
    const ok = r.ok;

    if (ok) {
      const rowsHtml = [];
      rowsHtml.push(`<div class="kv"><span class="k">入库视频数</span><span class="v"><b>${sm.saved || 0}</b> 条</span></div>`);
      if (sm.skippedOutWindow) {
        rowsHtml.push(`<div class="kv"><span class="k">超 30 天跳过</span><span class="v">${sm.skippedOutWindow} 条</span></div>`);
      }
      rowsHtml.push(`<div class="kv"><span class="k">采集方法</span><span class="v" style="font-size:9.5px">${esc(r.method || '')}</span></div>`);

      // 单条视频：显示这一条的最新数据
      let unitHtml = '';
      if (r.unit && r.unit.after) {
        const a = r.unit.after;
        unitHtml = `
          <div style="margin-top:10px;padding:9px;border-radius:6px;
                      background:var(--bg-0);font-size:10.5px;line-height:1.9">
            <b>这一条视频的最新数据</b>（${esc(a.date || '')}）<br/>
            播放 <b>${(a.plays || 0).toLocaleString()}</b> ·
            覆盖 <b>${(a.reach || 0).toLocaleString()}</b> ·
            互动 <b>${(a.reactions || 0).toLocaleString()}</b><br/>
            ${a.watchSec ? `观看 ${Math.round(a.watchSec / 60)} 分钟 · ` : ''}
            ${a.avgWatch ? `平均观看 ${a.avgWatch.toFixed(1)}s · ` : ''}
            ${a.completion ? `完播率 ${(a.completion * 100).toFixed(1)}%` : ''}
          </div>`;
      } else if (r.unit) {
        unitHtml = `<div style="margin-top:10px;color:var(--warn);font-size:10.5px">
          这条视频本次没采到新数据（可能超出 30 天窗口或刚发布还没统计）</div>`;
      }

      out.innerHTML = `
        <div style="padding:11px;border-radius:7px;background:rgba(52,211,153,.08);
                    border:1px solid rgba(52,211,153,.3);font-size:11px;line-height:1.9">
          <b style="color:var(--ok)">✓ 采集完成</b>
          ${rowsHtml.join('')}
          ${unitHtml}
        </div>`;
      toast('采集完成', `入库 ${sm.saved || 0} 条`, 'ok');
    } else {
      const d = r.detail || {};
      const reasons = [];
      if (sm.guard) reasons.push('触发风控（' + sm.guard + '）');
      if (sm.error) reasons.push('出错 ' + sm.error + ' 次');
      if (r.error) reasons.push(r.error);
      if (d.skipped) reasons.push('被跳过：' + d.skipped);
      if (d.error) reasons.push(d.error);

      out.innerHTML = `
        <div style="padding:11px;border-radius:7px;background:rgba(248,113,113,.08);
                    border:1px solid rgba(248,113,113,.3);font-size:11px;line-height:1.8">
          <b style="color:var(--danger)">✗ 采集未成功</b><br/>
          ${reasons.length ? esc(reasons.join('；')) : '未知原因'}<br/>
          <span style="color:var(--tx-3);font-size:10px">
            方法：${esc(r.method || '')} · 窗口 ${sm.windowDays || 30} 天
          </span>
          ${d.guard ? `<details style="margin-top:6px"><summary style="cursor:pointer;
              color:var(--tx-3)">风控详情</summary>
            <pre style="font-size:9px;white-space:pre-wrap;background:var(--bg-0);
                        padding:8px;border-radius:5px;margin-top:5px">
${esc(JSON.stringify(d.guard, null, 2))}</pre></details>` : ''}
        </div>`;
      toast('采集未成功', reasons[0] || '见弹窗', 'err', 6000);
    }
  } catch (e) {
    if (out) out.innerHTML = `<div style="color:var(--danger);font-size:11px">
      请求失败：${esc(e.message)}</div>`;
    toast('采集失败', e.message, 'err');
  }
}

/* ---------------- 采集 ---------------- */
async function doCollect(btn) {
  const env = (store.envs || []).find((e) => e.role === 'publisher' && e.status === 'running')
    || (store.envs || []).find((e) => e.status === 'running');
  if (!env) return toast('没有运行中的环境', '先到「指纹浏览器」启动发布号环境', 'err');

  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>采集中…';
  toast('开始采集', `${env.name} · 最近 30 天`, 'info');

  try {
    const r = await api.collectVideos({
      envCode: env.containerCode,
      useGraphApi: true,
      pageIds: [],
      windowDays: 30,
    });
    const t0 = Date.now();
    while (Date.now() - t0 < 1800000) {
      await new Promise((res) => setTimeout(res, 3000));
      const j = await api.job(r.jobId);
      btn.innerHTML = `<span class="spin" data-icon="refresh"></span>${j.progress || 0}%`;
      if (['done', 'failed', 'blocked', 'cancelled'].includes(j.status)) {
        const res = j.result || {};
        if (res.guard) raiseGuard(res.guard);
        toast(j.status === 'done' ? '采集完成' : '采集受阻',
          `入库 ${res.saved || 0} · 超 30 天跳过 ${res.skippedOutWindow || 0} · 风控 ${res.guard ? 1 : 0}`,
          j.status === 'done' ? 'ok' : 'warn', 6000);
        break;
      }
    }
    await load(document.getElementById('view'));
  } catch (e) {
    toast('采集失败', e.message, 'err');
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

/* ---------------- 手录 ---------------- */
function openManual() {
  const list = (store.videos || []).slice(0, 300);
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>选择视频</label>
      <select class="select" id="mn-id">
        ${list.map((v) => `<option value="${v.id}">${v.pageName} · ${esc((v.title || '').slice(0, 50))}</option>`).join('')}
      </select>
    </div>
    <div class="row-3">
      <div class="field"><label>播放</label><input class="input" id="mn-plays" type="number" value="0" /></div>
      <div class="field"><label>覆盖</label><input class="input" id="mn-reach" type="number" value="0" /></div>
      <div class="field"><label>点击</label><input class="input" id="mn-clicks" type="number" value="0" /></div>
    </div>
    <div class="row-3">
      <div class="field"><label>赞</label><input class="input" id="mn-reactions" type="number" value="0" /></div>
      <div class="field"><label>评论</label><input class="input" id="mn-comments" type="number" value="0" /></div>
      <div class="field"><label>分享</label><input class="input" id="mn-shares" type="number" value="0" /></div>
    </div>
    <div class="hint">写入今天日期的快照，会覆盖同日已有值。</div>`;

  const m = modal({
    title: '手动录入指标',
    width: 'wide',
    body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const g = (id) => parseInt(body.querySelector(id).value, 10) || 0;
          try {
            await api.setMetrics({
              unitId: body.querySelector('#mn-id').value,
              plays: g('#mn-plays'), reach: g('#mn-reach'), clicks: g('#mn-clicks'),
              reactions: g('#mn-reactions'), comments: g('#mn-comments'),
              shares: g('#mn-shares'),
            });
            toast('已保存', '指标已更新', 'ok');
            m.close();
            load(document.getElementById('view'));
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}
