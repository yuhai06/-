# -*- coding: utf-8 -*-
"""
agent_chat.py — 用当前接入 Agent 自己的模型做对话式编排

工作方式：
  ① 拿用户消息 + 工具定义（从 mcp_server 的 18 个工具）
  ② 发给 agent 自己的模型（function calling）
  ③ 模型返回 tool_calls → 执行 → 结果回灌 → 继续
  ④ 循环直到模型给出最终回答

模型来源：agent_models 里当前接入的 agent 的 text_model
  dsh      → workbuddy/glm-5.3-flash  @ 127.0.0.1:18326
  ollama   → ui-tars-2b 等 @ 127.0.0.1:11434
  codex    → config.toml 里的 model
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from typing import Any

from app.services import agent_detect as ad
from app.services import agent_models as am

log = logging.getLogger("yuhai.agent.chat")

# ── 停止信号 ──────────────────────────────────────────────
# chat() 运行在 to_thread 的子线程里；stop() 由 HTTP 接口从另一线程调用。
import threading as _threading

_STOP = _threading.Event()          # 置位表示"请求停止"
_STOP_REASON = [""]


class Stopped(Exception):
    """用户主动停止所抛出的中断信号。"""


def request_stop(reason: str = "用户停止") -> dict:
    """请求停止当前/后续对话（可重复调用，幂等）。"""
    _STOP.set()
    _STOP_REASON[0] = reason
    log.warning("agent chat 收到停止请求: %s", reason)
    return {"ok": True, "stopped": True, "reason": reason}


def clear_stop() -> None:
    """新一轮对话开始前复位。"""
    _STOP.clear()
    _STOP_REASON[0] = ""


def is_stopped() -> bool:
    return _STOP.is_set()


def _check_stop() -> None:
    """在关键点调用；被停止则抛 Stopped。"""
    if _STOP.is_set():
        raise Stopped(_STOP_REASON[0] or "用户停止")


MAX_ROUNDS = 6          # 最多几轮工具调用（防死循环）
TIMEOUT = 90

# 需要用户确认的写操作
NEED_CONFIRM = {
    "slice_run", "slice_env_install", "grab_download",
    "publish_reels", "memory_set",
}


# ---------------- 取当前 agent 的对话模型 ----------------
def pick_model() -> dict:
    """返回 (endpoint, model_id, api_key)。"""
    ov = am.overview()
    cid = ov.get("connected")
    if not cid:
        return {"ok": False, "error": "还没接入 Agent（先去雨海 Agent 页选一个）"}

    for a in ad.AGENTS:
        if a["id"] != cid:
            continue
        raw = ad.detect_one(a)
        endpoint = raw.get("endpoint") or ""
        models = raw.get("models") or []
        api_key = ""

        # 用户手动指定的模型优先
        try:
            from app.services import agent_models as _am
            chosen = _am.get_active_model(cid)
            if chosen and chosen in {m.get("id") for m in models}:
                mid = chosen
            else:
                chosen = ""
        except Exception:
            chosen = ""
        if cid == "dsh":
            cfg = ad._read_json(a["paths"][0])
            api_key = cfg.get("key", "")
            if not chosen:
                mid = cfg.get("text_model") or (models[0]["id"] if models else "")
        elif a["kind"] == "toml":
            t = ad._read_toml(a["paths"][0])
            mid = t.get("model") or (models[0]["id"] if models else "")
            prov = t.get("model_provider", "")
            pinfo = (t.get("providers") or {}).get(prov) or {}
            envk = pinfo.get("env_key", "")
            if envk:
                api_key = os.environ.get(envk, "")
        elif cid == "ollama":
            mid = models[0]["id"] if models else ""
        else:
            mid = models[0]["id"] if models else ""

        if not mid:
            return {"ok": False,
                    "error": f"{raw.get('name')} 没有配置可用模型"}
        if not endpoint:
            return {"ok": False,
                    "error": f"{raw.get('name')} 没有可用 endpoint"}
        return {"ok": True, "endpoint": endpoint, "model": mid,
                "apiKey": api_key, "agent": cid, "name": raw.get("name")}

    return {"ok": False, "error": "找不到该 agent 的配置"}


# 常见模型的上下文窗口（token）
CTX_WINDOWS = {
    "glm-5.3": 128000, "deepseek": 128000, "gpt-oss": 32768,
    "nemotron": 128000, "minimax": 200000, "step-5": 128000,
    "qwen": 128000, "claude": 200000, "gemini": 1000000,
    "kimi": 128000, "mimo": 128000,
}


def _ctx_pct(usage: dict, model: str) -> int:
    """上下文占用百分比（按模型窗口估算）。

    usage.prompt 本轮输入 token，completion 输出;
    占用率 = (输入 + 输出) / 窗口 × 100
    """
    win = 128000
    ml = (model or "").lower()
    for k, v in CTX_WINDOWS.items():
        if k in ml:
            win = v
            break
    used = int(usage.get("prompt") or 0) + int(usage.get("completion") or 0)
    if win <= 0:
        return 0
    return min(100, int(used * 100 / win))


# ---------------- 工具定义 ----------------
def tool_specs() -> list[dict]:
    """从 mcp_server 的工具表转成 OpenAI function calling 格式。"""
    import asyncio
    from app import mcp_server as M

    async def _get():
        return await M.mcp.list_tools()

    try:
        tools = asyncio.run(_get())
    except RuntimeError:
        # 已有事件循环（FastAPI 里）→ 用线程跑
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as ex:
            tools = ex.submit(lambda: asyncio.run(_get())).result()

    out = []
    for t in tools:
        schema = getattr(t, "inputSchema", None) or \
            {"type": "object", "properties": {}, "additionalProperties": False}
        out.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": (t.description or "")[:400],
                "parameters": schema,
            },
        })
    return out


def call_tool(name: str, args: dict) -> dict:
    """执行一个 MCP 工具，返回纯 dict。"""
    import asyncio
    from app import mcp_server as M

    async def _call():
        return await M.mcp.call_tool(name, args or {})

    try:
        r = asyncio.run(_call())
    except RuntimeError:
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as ex:
            r = ex.submit(lambda: asyncio.run(_call())).result()

    # mcp 2.x 返回 CallToolResult（不是 tuple）
    # 结构：.structured_content / .content[TextContent(text=json)] / .is_error
    sc = getattr(r, "structured_content", None)
    if isinstance(sc, dict) and sc:
        return sc

    is_err = bool(getattr(r, "is_error", False))
    content = getattr(r, "content", None)
    if content is None and isinstance(r, tuple):
        content = r[0]
        sc2 = r[1] if len(r) > 1 else None
        if isinstance(sc2, dict) and sc2:
            return sc2

    txt = ""
    for c in (content or []):
        txt += getattr(c, "text", "") or ""
    if txt:
        try:
            d = json.loads(txt)
            return d if isinstance(d, dict) else {"result": d}
        except Exception:
            return {"raw": txt, "isError": is_err}

    return r if isinstance(r, dict) else {"raw": str(r)[:500],
                                          "isError": is_err}


# ---------------- HTTP 调用 ----------------
def _post_chat(endpoint: str, model: str, messages: list,
               tools: list | None, api_key: str = "") -> dict:
    base = endpoint.rstrip("/")
    is_ollama = "11434" in base

    if is_ollama:
        url = base + "/api/chat"
        body = {"model": model, "messages": messages, "stream": False}
        if tools:
            body["tools"] = tools
        headers = {"Content-Type": "application/json"}
    else:
        if not base.endswith("/v1"):
            base += "/v1"
        url = base + "/chat/completions"
        body = {"model": model, "messages": messages,
                "temperature": 0.3, "max_tokens": 1200}
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers=headers)
    try:
        raw = urllib.request.urlopen(req, timeout=TIMEOUT).read()
        return {"ok": True, "data": json.loads(raw)}
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = (e.read() or b"").decode("utf-8", "replace")[:300]
        except Exception:
            pass
        return {"ok": False, "error": f"HTTP {e.code}", "detail": detail}
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}


def _parse_reply(d: dict, is_ollama: bool) -> dict:
    """统一解析成 {content, tool_calls}。"""
    if is_ollama:
        msg = d.get("message") or {}
        calls = []
        for c in (msg.get("tool_calls") or []):
            fn = c.get("function") or {}
            args = fn.get("arguments")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except Exception:
                    args = {}
            calls.append({"name": fn.get("name"), "args": args or {}})
        return {"content": (msg.get("content") or "").strip(),
                "tool_calls": calls}

    ch = (d.get("choices") or [{}])[0]
    msg = ch.get("message") or {}
    calls = []
    for c in (msg.get("tool_calls") or []):
        fn = c.get("function") or {}
        args = fn.get("arguments")
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {}
        calls.append({"name": fn.get("name"), "args": args or {},
                      "id": c.get("id") or ""})
    content = (msg.get("content") or "").strip()
    if not content:
        content = (msg.get("reasoning_content") or "").strip()
    return {"content": content, "tool_calls": calls, "id": ch.get("id")}


# ---------------- 主对话循环 ----------------
SYSTEM_PROMPT = """你是「雨海工作台」的运营助手。你能直接操作这个工作台。

能力：抓剧、切片、查成片、发布、看数据。

工作原则：
1. 先看环境（slice_env_check），缺什么提示用户
2. 列剧（slice_list_dramas），确认要切哪部
3. 切片（slice_run）后立刻告诉用户 job_id
4. 用户问进度就用 slice_status
5. 报错时明确说哪里错了、怎么修
6. 记住重要状态（memory_set）

回答要简短直接，用中文。不要在没调用工具时编造成片文件路径。"""


def chat(user_msg: str, history: list | None = None,
         auto_run_tools: bool = True, attachments: list | None = None,
         on_progress=None, chat_id: str = "") -> dict:
    """一轮对话（可能内部跑多次工具）。

    attachments: [{name, kind, path, sizeMb, dataUri?, preview?}]
      图片有 dataUri → 用视觉消息格式塞给模型
      文件有 preview → 把内容摘要拼进提示词

    on_progress: 可选回调 fn(stage, payload)，用于流式推送进度：
      ("thinking", {"round": n})          模型思考中
      ("tool_start", {"tool": name})      开始调工具
      ("tool_end", {"tool": name, "ok": ..., "ms": ...})
      ("reply", {"content": ...})         最终回答
    """
    def _emit(stage, payload=None):
        if on_progress:
            try:
                on_progress(stage, payload or {})
            except Exception:
                pass

    # 新一轮对话：先复位停止标志（上一次的停止不影响这一次）
    clear_stop()

    pk = pick_model()
    if not pk.get("ok"):
        return {"ok": False, "error": pk.get("error"),
                "hint": "先去「雨海 Agent」页接入一个 Agent"}

    endpoint, model, api_key = pk["endpoint"], pk["model"], pk.get("apiKey", "")
    is_ollama = "11434" in endpoint

    # 摘要 + 长期记忆（解决失忆）
    ctx_prefix = ""
    try:
        if chat_id:
            from app.services import agent_context as actx
            ctx = actx.build_context(chat_id, user_msg)
            ctx_prefix = ctx.get("prefix") or ""
            if ctx.get("history") and not history:
                history = ctx["history"]
    except Exception:
        ctx_prefix = ""

    msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
    if ctx_prefix:
        msgs.append({"role": "system", "content": ctx_prefix})
    for h in (history or [])[-8:]:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            msgs.append({"role": h["role"], "content": h["content"]})

    # 附件：图片走 data URI（视觉模型），文件走文本摘要
    atts = attachments or []
    imgs = [a for a in atts if a.get("dataUri")]
    txts = [a for a in atts if not a.get("dataUri")]

    text_msg = user_msg
    if txts:
        parts = []
        for a in txts:
            p = a.get("path") or ""
            nm = a.get("name") or ""
            if a.get("preview"):
                parts.append("[附件] %s（%s）\n内容摘要:\n%s"
                             % (nm, p, a["preview"][:2000]))
            else:
                parts.append("[附件] %s（%s，%sMB）—— 这是本地路径，"
                             "需要时用工具读取"
                             % (nm, p, a.get("sizeMb") or "?"))
        text_msg = "\n\n".join(parts) + "\n\n" + user_msg

    if imgs:
        content = [{"type": "text", "text": text_msg}]
        for a in imgs[:4]:
            content.append({"type": "image_url",
                            "image_url": {"url": a["dataUri"]}})
        msgs.append({"role": "user", "content": content})
    else:
        msgs.append({"role": "user", "content": text_msg})

    tools = tool_specs()
    trace = []
    rounds = 0
    # token 用量累计
    usage = {"prompt": 0, "completion": 0, "cached": 0, "total": 0}

    while rounds < MAX_ROUNDS:
        rounds += 1
        _emit("thinking", {"round": rounds, "model": model})
        _check_stop()   # 每轮调模型前检查
        r = _post_chat(endpoint, model, msgs, tools, api_key)
        if not r.get("ok"):
            return {"ok": False,
                    "error": f"模型调用失败: {r.get('error')}",
                    "detail": r.get("detail", ""),
                    "agent": pk["agent"], "model": model}

        # 累积 token 用量（网关返回 usage）
        u = (r.get("data") or {}).get("usage") or {}
        if u:
            usage["prompt"] += int(u.get("prompt_tokens") or 0)
            usage["completion"] += int(u.get("completion_tokens") or 0)
            usage["total"] += int(u.get("total_tokens") or 0)
            det = u.get("prompt_tokens_details") or {}
            usage["cached"] += int(det.get("cached_tokens") or 0)

        rep = _parse_reply(r["data"], is_ollama)
        calls = rep.get("tool_calls") or []

        # 没有工具调用 → 这就是最终回答
        if not calls:
            ctxpct = _ctx_pct(usage, model)
            _emit("reply", {"content": rep["content"], "rounds": rounds,
                            "usage": usage, "ctxPct": ctxpct})
            return {"ok": True, "reply": rep["content"],
                    "agent": pk["agent"], "model": model,
                    "rounds": rounds, "trace": trace,
                    "usage": usage, "ctxPct": ctxpct}

        # 有工具调用 → 执行，回灌
        if is_ollama:
            msgs.append({"role": "assistant", "content": rep["content"],
                         "tool_calls": [
                             {"function": {"name": c["name"],
                                           "arguments": c["args"]}}
                             for c in calls]})
        else:
            msgs.append({"role": "assistant",
                         "content": rep["content"] or None,
                         "tool_calls": [
                             {"id": c.get("id") or f"call_{i}",
                              "type": "function",
                              "function": {"name": c["name"],
                                           "arguments": json.dumps(
                                               c["args"], ensure_ascii=False)}}
                             for i, c in enumerate(calls)]})

        for i, c in enumerate(calls):
            _check_stop()   # 每个工具执行前检查
            name, args = c["name"], c["args"]
            _emit("tool_start", {"tool": name, "args": args,
                                  "round": rounds})
            t0 = time.time()
            try:
                res = call_tool(name, args)
                ok = bool(res.get("ok", True))
            except Exception as e:
                res = {"ok": False, "error": str(e)[:150]}
                ok = False
            dt = int((time.time() - t0) * 1000)
            _emit("tool_end", {"tool": name, "ok": ok, "ms": dt,
                                "round": rounds})
            trace.append({"round": rounds, "tool": name, "args": args,
                          "ok": ok, "ms": dt,
                          "result": json.dumps(res, ensure_ascii=False)[:800]})

            payload = json.dumps(res, ensure_ascii=False)

            if is_ollama:
                # ollama 原生支持 tool role
                msgs.append({"role": "tool", "content": payload[:3000]})
            else:
                # OpenAI 兼容网关对 tool role 解析不稳（wire_api=responses 更明显）
                # 用 user 消息注入结果，模型一定能读到
                msgs.append({
                    "role": "user",
                    "content": (f"[工具执行结果] {name}\n"
                                f"参数: {json.dumps(args, ensure_ascii=False)}\n"
                                f"结果:\n{payload[:2500]}\n\n"
                                f"请基于以上真实结果回答用户，不要编造。"),
                })

        if not auto_run_tools:
            return {"ok": True, "needContinue": True,
                    "pendingCalls": calls, "trace": trace,
                    "agent": pk["agent"], "model": model}

    return {"ok": True, "reply": "（工具调用轮数用尽，停在这里）",
            "agent": pk["agent"], "model": model,
            "trace": trace, "rounds": rounds}


def quick_test() -> dict:
    """自检：当前 agent 的模型能不能对话。"""
    pk = pick_model()
    if not pk.get("ok"):
        return pk
    r = _post_chat(pk["endpoint"], pk["model"],
                   [{"role": "user", "content": "说'ok'"}], None,
                   pk.get("apiKey", ""))
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error"),
                "detail": r.get("detail", ""),
                "agent": pk["agent"], "model": pk["model"]}
    rep = _parse_reply(r["data"], "11434" in pk["endpoint"])
    return {"ok": bool(rep["content"]), "reply": rep["content"][:60],
            "agent": pk["agent"], "model": pk["model"]}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        print(json.dumps(quick_test(), ensure_ascii=False, indent=1))
    elif len(sys.argv) > 1:
        print(json.dumps(chat(" ".join(sys.argv[1:])),
                         ensure_ascii=False, indent=1))
    else:
        print(json.dumps(quick_test(), ensure_ascii=False, indent=1))
