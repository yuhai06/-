# -*- coding: utf-8 -*-
"""mcp_fs.py — 文件系统工具（让 Agent 读写本机文件）

安全边界
--------
· 读：允许用户盘符下的常见目录（不锁死在项目内，用户需要读电脑上的文件）
· 写：同样允许，但限制单次 5MB
· 拒绝：Windows / Program Files / ProgramData 等系统保护目录
· 上限：单次读 2MB、写 5MB、列目录 500 项，防炸内存
"""
from __future__ import annotations

import logging
import shutil
import string
from pathlib import Path

log = logging.getLogger("yuhai.mcp.fs")

READ_LIMIT = 2 * 1024 * 1024      # 2MB
WRITE_LIMIT = 5 * 1024 * 1024     # 5MB
LIST_LIMIT = 500
FIND_LIMIT = 200

_BLOCKED = (
    "c:\\windows",
    "c:\\program files",
    "c:\\program files (x86)",
    "c:\\programdata",
    "c:\\$recycle.bin",
    "c:\\system volume information",
    "c:\\recovery",
    "c:\\perflogs",
)


def _norm(path: str) -> Path:
    """规范化路径并做安全校验。"""
    if path is None or not str(path).strip():
        raise ValueError("路径为空")
    raw = str(path).strip().strip('"').strip("'")
    p = Path(raw)
    try:
        p = p.expanduser()
    except Exception:
        pass
    low = str(p).lower().replace("/", "\\")
    for b in _BLOCKED:
        if low == b or low.startswith(b + "\\"):
            raise PermissionError("该目录受系统保护，已拒绝: " + str(p))
    return p


def register(mcp) -> None:
    """把所有文件工具注册到 mcp 实例。"""

    @mcp.tool(description="读文件。path=绝对路径；maxKb=最多读多少KB(默认200，上限2048)")
    def fs_read(path: str, maxKb: int = 200) -> dict:
        """读取本机文本文件内容。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "文件不存在: " + str(p)}
            if p.is_dir():
                return {"ok": False, "error": "这是目录，请用 fs_list: " + str(p)}
            size = p.stat().st_size
            cap = min(max(int(maxKb or 200) * 1024, 1024), READ_LIMIT)
            with open(p, "rb") as f:
                head = f.read(8192)
                is_binary = b"\x00" in head
                f.seek(0)
                raw = f.read(cap)
            if is_binary:
                return {"ok": True, "path": str(p), "size": size,
                        "binary": True, "truncated": size > cap,
                        "note": "二进制文件，未返回内容"}
            text = raw.decode("utf-8", errors="replace")
            return {"ok": True, "path": str(p), "size": size,
                    "bytesRead": len(raw), "truncated": size > cap,
                    "content": text}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="列目录。path=目录；pattern=通配符(可选如 *.txt)；limit=最多多少项(默认200)")
    def fs_list(path: str, pattern: str = "", limit: int = 200) -> dict:
        """列出目录内容（含类型/大小/修改时间）。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "目录不存在: " + str(p)}
            if not p.is_dir():
                return {"ok": False, "error": "不是目录: " + str(p)}
            cap = min(max(int(limit or 200), 1), LIST_LIMIT)
            it = p.glob(pattern) if pattern else p.iterdir()
            items = []
            for f in it:
                if len(items) >= cap:
                    break
                try:
                    st = f.stat()
                    items.append({
                        "name": f.name,
                        "path": str(f),
                        "dir": f.is_dir(),
                        "size": 0 if f.is_dir() else st.st_size,
                        "mtime": int(st.st_mtime),
                    })
                except (PermissionError, OSError):
                    continue
            items.sort(key=lambda x: (not x["dir"], x["name"].lower()))
            return {"ok": True, "path": str(p), "count": len(items),
                    "truncated": len(items) >= cap, "items": items}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="搜索文件。root=根目录；name=文件名片段或通配符；maxDepth=最大深度(默认4)")
    def fs_find(root: str, name: str, maxDepth: int = 4) -> dict:
        """在目录树里按文件名查找。"""
        try:
            base = _norm(root)
            if not base.is_dir():
                return {"ok": False, "error": "根目录无效: " + str(base)}
            want = (name or "").strip()
            if not want:
                return {"ok": False, "error": "name 不能为空"}
            depth_cap = max(1, min(int(maxDepth or 4), 8))
            base_depth = len(base.parts)
            use_glob = "*" in want or "?" in want
            lw = want.lower()
            hits = []
            for f in base.rglob("*"):
                try:
                    if len(f.parts) - base_depth > depth_cap:
                        continue
                    matched = f.match(want) if use_glob else (lw in f.name.lower())
                    if not matched:
                        continue
                    st = f.stat()
                    hits.append({"name": f.name, "path": str(f), "dir": f.is_dir(),
                                 "size": 0 if f.is_dir() else st.st_size})
                    if len(hits) >= FIND_LIMIT:
                        break
                except (PermissionError, OSError):
                    continue
            return {"ok": True, "root": str(base), "count": len(hits),
                    "truncated": len(hits) >= FIND_LIMIT, "items": hits}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="写文件。path=绝对路径；content=内容；append=true时追加（不覆盖）。上限5MB")
    def fs_write(path: str, content: str, append: bool = False) -> dict:
        """写入文本文件，自动创建父目录。"""
        try:
            p = _norm(path)
            data = (content or "").encode("utf-8")
            if len(data) > WRITE_LIMIT:
                return {"ok": False,
                        "error": "内容超过 5MB 上限（%.1fMB）" % (len(data) / 1048576)}
            p.parent.mkdir(parents=True, exist_ok=True)
            mode = "ab" if append else "wb"
            with open(p, mode) as f:
                f.write(data)
            return {"ok": True, "path": str(p), "bytes": len(data),
                    "mode": "append" if append else "overwrite",
                    "size": p.stat().st_size}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="查看各磁盘剩余空间")
    def fs_disks() -> dict:
        """列出所有盘符与容量。"""
        out = []
        for letter in string.ascii_uppercase:
            root = letter + ":\\"
            try:
                total, used, free = shutil.disk_usage(root)
                out.append({
                    "drive": letter, "path": root,
                    "totalGb": round(total / 1073741824, 1),
                    "usedGb": round(used / 1073741824, 1),
                    "freeGb": round(free / 1073741824, 1),
                })
            except (OSError, FileNotFoundError):
                continue
        return {"ok": True, "count": len(out), "drives": out}

    @mcp.tool(description="查看文件信息（大小/时间/是否存在），不解包内容")
    def fs_stat(path: str) -> dict:
        """查看单个路径的元信息。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": True, "exists": False, "path": str(p)}
            st = p.stat()
            return {"ok": True, "exists": True, "path": str(p),
                    "dir": p.is_dir(), "size": st.st_size,
                    "mtime": int(st.st_mtime),
                    "ext": p.suffix.lower()}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    log.info("mcp_fs registered (6 tools)")
