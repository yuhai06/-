/* ============================================================
   API 客户端 —— 所有页面数据都从这里来，不再用 mock
   ============================================================ */

const BASE = (() => {
  // 打包后由 C++ 外壳注入；开发时用同源
  if (window.__YHAI_API__) return window.__YHAI_API__;
  if (location.protocol === 'file:') return 'http://127.0.0.1:8710';
  return '';                       // 同源：http://127.0.0.1:8710 直接托管前端
})();

const TO = 120000;

async function req(method, path, body, outerSignal) {
  const opt = { method, headers: {} };
  if (body !== undefined) {
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TO);
  opt.signal = ctl.signal;
  // 外部 signal：让调用方可以中途取消（切页/重新搜索/点停止）
  if (outerSignal) {
    if (outerSignal.aborted) {
      clearTimeout(timer);
      const e = new Error('已取消');
      e.name = 'AbortError';
      throw e;
    }
    outerSignal.addEventListener('abort', () => {
      clearTimeout(timer);
      try { ctl.abort(); } catch (_) {}
    }, { once: true });
  }

  let res;
  try {
    res = await fetch(BASE + path, opt);
  } catch (e) {
    clearTimeout(timer);
    if (e && e.name === 'AbortError') {
      const ae = new Error('已取消');
      ae.name = 'AbortError';
      throw ae;
    }
    throw new ApiError(`后端不可达（${BASE || location.origin}）`, 0, e);
  }
  clearTimeout(timer);

  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }

  if (!res.ok) {
    const msg = (data && (data.detail || data.error)) || `HTTP ${res.status}`;
    throw new ApiError(typeof msg === 'string' ? msg : JSON.stringify(msg), res.status, data);
  }
  return data;
}

export class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.payload = payload;
  }
}

const get = (p, sig) => req('GET', p, undefined, sig);
const post = (p, b, sig) => req('POST', p, b ?? {}, sig);
const patch = (p, b) => req('PATCH', p, b ?? {});
const del = (p) => req('DELETE', p);

/* ---------------- 系统 ---------------- */
export const api = {
  health: () => get('/api/system/health'),
  summary: () => get('/api/system/summary'),
  events: (limit = 200) => get(`/api/system/events?limit=${limit}`),
  config: () => get('/api/system/config'),
  saveConfig: (p) => post('/api/system/config', p),
  /* 后台进程管理 */
  processes: () => get('/api/system/processes'),
  killProcesses: (p) => post('/api/system/processes/kill', p),

  /* ---------------- 环境 ---------------- */
  envs: (refresh = false) => get(`/api/envs?refresh=${refresh}`),
  envDetail: (code) => get(`/api/envs/${code}`),
  syncEnvs: () => post('/api/envs/sync'),
  envHealth: () => get('/api/envs/health'),
  createEnv: (p) => post('/api/envs/create', p),
  deleteRemoteEnv: (codes, alsoLocal = true) =>
    post('/api/envs/delete-remote', { codes, alsoLocal }),
  migrateEnv: (p) => post('/api/envs/migrate', p),
  setEnvProxy: (code, p) => post(`/api/envs/${code}/proxy`, p),
  cloneEnvProxy: (code, fromCode) =>
    post(`/api/envs/${code}/proxy/clone?fromCode=${fromCode}`),

  /* ---------------- 评论区维护 ---------------- */
  commentClassify: (texts, accountId = '') =>
    post('/api/comments/classify', { texts, accountId }),
  commentRules: () => get('/api/comments/rules'),
  saveCommentRules: (p) => post('/api/comments/rules', p),
  commentTemplates: () => get('/api/comments/templates'),
  commentQuota: (accountId = '') => get(`/api/comments/quota?accountId=${accountId}`),
  fetchComments: (p) => post('/api/comments/fetch', p),
  runComments: (p) => post('/api/comments/run', p),
  commentHistory: (p = {}) => {
    const q = new URLSearchParams();
    if (p.pageId) q.set('pageId', p.pageId);
    if (p.action) q.set('action', p.action);
    return get(`/api/comments/history?${q}`);
  },
  watchStatus: () => get('/api/comments/watch'),
  watchConfig: (p) => post('/api/comments/watch', p),
  watchStart: () => post('/api/comments/watch/start'),
  watchStop: () => post('/api/comments/watch/stop'),
  watchRunOnce: (catchUp = false) => post(`/api/comments/watch/run-once?catchUp=${catchUp}`),
  watchTaskCommands: () => get('/api/comments/watch/task'),
  watchInstallTask: (kind = 'alive') => post(`/api/comments/watch/task?kind=${kind}`),
  watchUninstallTask: () => del('/api/comments/watch/task'),
  deleteEnv: (code, hard = false) => del(`/api/envs/${code}?hard=${hard}`),
  restoreEnv: (code) => post(`/api/envs/${code}/restore`),
  startEnv: (code) => post('/api/envs/start', { containerCode: code }),
  stopEnv: (code) => post('/api/envs/stop', { containerCode: code }),
  resolvePid: (pid, port) => {
    const q = new URLSearchParams();
    if (pid) q.set('pid', pid);
    if (port) q.set('port', port);
    return get(`/api/envs/resolve-pid?${q}`);
  },
  probePorts: () => get('/api/envs/probe-ports'),
  testProxy: (p) => post('/api/envs/test-proxy', p),

  /* ---------------- 主页 ---------------- */
  pages: () => get('/api/pages'),
  pageDetail: (id) => get(`/api/pages/${id}`),
  patchPage: (id, p) => patch(`/api/pages/${id}`, p),
  extractPages: (pid, port) => {
    const q = new URLSearchParams();
    if (pid) q.set('pid', pid);
    if (port) q.set('port', port);
    return get(`/api/extract/pages?${q}`);
  },
  extractAsync: (p) => post('/api/pages/extract', p),
  createPages: (p) => post('/api/pages/create', p),

  /* ---------------- 授权 ---------------- */
  authz: () => get('/api/authz'),
  grant: (p) => post('/api/authz/grant', p),
  verifyAuthz: (pageId) => post('/api/authz/verify', { pageId }),

  /* ---------------- 视频（推广矩阵核心） ---------------- */
  videos: (p = {}) => {
    const q = new URLSearchParams();
    Object.entries(p).forEach(([k, v]) => { if (v !== '' && v != null) q.set(k, v); });
    return get(`/api/videos?${q}`);
  },
  video: (id) => get(`/api/videos/${id}`),
  overview: (days = 14) => get(`/api/videos/summary/overview?days=${days}`),
  collectVideos: (p) => post('/api/videos/collect', p),
  /* 数据采集（多粒度） */
  insightsTargets: () => get('/api/insights/targets'),
  collectOne: (p) => post('/api/insights/collect-one', p),
  collectPages: (p) => post('/api/insights/collect-pages', p),
  setMetrics: (p) => post('/api/videos/metrics', p),
  setTags: (unitId, tags) => post('/api/videos/tags', { unitId, tags }),

  /* ---------------- 风控 ---------------- */
  guardStatus: () => get('/api/guard/status'),
  guardEvents: (openOnly = true) => get(`/api/guard/events?open_only=${openOnly}`),
  guardSignatures: () => get('/api/guard/signatures'),
  guardResolve: (id, note = '') => post('/api/guard/resolve', { id, note }),
  guardCheck: (p = {}) => post('/api/guard/check', p),

  /* ---------------- 素材 / 队列 / 排期 ---------------- */
  library: (p = {}) => {
    const q = new URLSearchParams();
    Object.entries(p).forEach(([k, v]) => { if (v !== '' && v != null && v !== 'all') q.set(k, v); });
    return get(`/api/library?${q}`);
  },
  scanLibrary: (p = {}) => post('/api/library/scan', p),
  qcLibrary: (id) => post('/api/library/qc', { id }),
  qcBatch: (ids = []) => post('/api/library/qc-batch', { ids }),
  pushLibrary: (p) => post('/api/library/push', p),
  deleteLib: (id, delFile = true) => del(`/api/library/${id}?deleteFile=${delFile}`),
  deleteLibBatch: (ids, delFile = true) => post('/api/library/delete-batch', { ids, deleteFile: delFile }),
  setLibraryTags: (id, tags) => post('/api/library/tags', { id, tags }),
  setCopyright: (id, ok, note = '') => post('/api/library/copyright', { id, ok, note }),
  setCopyrightBatch: (ids, ok = false, note = '') =>
    post('/api/library/copyright-batch', { ids, ok, note }),
  purgeCopyrightFail: (delFile = true) =>
    post(`/api/library/purge-copyright-fail?deleteFile=${delFile}`),

  /* ---------------- 账号（多号架构） ---------------- */
  accounts: () => get('/api/accounts'),
  addAccount: (p) => post('/api/accounts', p),
  patchAccount: (id, p) => patch(`/api/accounts/${id}`, p),
  delAccount: (id) => del(`/api/accounts/${id}`),
  accountsFromEnvs: () => post('/api/accounts/from-envs'),
  accountsMatrix: () => get('/api/accounts/matrix'),
  accountQuota: (aid) => get(`/api/accounts/${aid}/quota`),
  allQuotas: () => get('/api/accounts/quota'),
  setQuota: (aid, level, note = '') => post(`/api/accounts/${aid}/quota`, { level, note }),
  grantMulti: (p) => post('/api/accounts/grant-multi', p),
  mapRole: (p) => post('/api/accounts/map', p),

  /* ---------------- 推广链接池 ---------------- */
  links: (pid = '') => get(`/api/links?page_id=${encodeURIComponent(pid)}`),
  addLink: (p) => post('/api/links', p),
  delLink: (id) => del(`/api/links/${id}`),
  patchLink: (id, p) => patch(`/api/links/${id}`, p),

  /* ---------------- 标题池 ---------------- */
  titles: (pid = '') => get(`/api/titles?page_id=${encodeURIComponent(pid)}`),
  genTitles: (p) => post('/api/titles/generate', p),
  addTitle: (p) => post('/api/titles', p),
  delTitle: (id) => del(`/api/titles/${id}`),
  pickTitle: (pid, ref = '') => post(`/api/titles/pick?page_id=${encodeURIComponent(pid)}&reference=${encodeURIComponent(ref)}`),
  previewCaptions: (p) => post('/api/videos/preview-captions', p),

  /* ---------------- 发布链接提取 ---------------- */
  extractLinks: (p) => post('/api/links/extract', p),
  extractedLinks: (p = {}) => {
    const q = new URLSearchParams();
    if (p.batchId) q.set('batch_id', p.batchId);
    if (p.pageId) q.set('page_id', p.pageId);
    return get(`/api/links/extracted?${q}`);
  },

  /* ---------------- 处理管线 ---------------- */
  pipelineTools: () => get('/api/library/tools'),

  /* ---------------- 视频制作（内置 ffmpeg） ---------------- */
  videoEnv: () => get('/api/video/env'),
  videoProbe: (path) => post('/api/video/probe', { path }),
  videoOp: (p) => post('/api/video/op', p),
  videoMake: (p) => post('/api/video/make', p),
  videoBatch: (p) => post('/api/video/batch', p),
  videoCaption: (p) => post('/api/video/caption', p),
  videoTemplates: () => get('/api/video/templates'),
  videoBrowse: (path = '') => get(`/api/video/browse?path=${encodeURIComponent(path)}`),
  videoScan: (dirs, recursive = true) => post('/api/video/scan', { dirs, recursive }),
  videoJobs: () => get('/api/video/jobs'),

  /* ---------------- 主页全量同步 ---------------- */
  syncAllPages: (p) => post('/api/pages/sync-all', p),
  syncPageInfo: (pid) => post('/api/pages/sync-all', { pageIds: [pid] }),
  bindPagesToAccount: (envCode, pageIds) =>
    post('/api/accounts/bind-pages', { envCode, pageIds }),

  /* ---------------- 素材抓取 ---------------- */
  grabHot: (cursor = 1, limit = 20) => get(`/api/grab/hot?cursor=${cursor}&limit=${limit}`),
  grabDetail: (cid) => get(`/api/grab/detail?cid=${cid}`),
  grabRun: (p) => post('/api/grab/run', p),
  grabGrabbed: () => get('/api/grab/grabbed'),
  grabEnv: () => get('/api/grab/env'),
  grabTypes: () => get('/api/grab/types'),
  grabRoots: () => get('/api/grab/roots'),
  grabSetRoot: (path) => post('/api/grab/root', { path: path || '' }),
  grabAllHot: (maxPages = 30) => get(`/api/grab/all-hot?maxPages=${maxPages}`),
  grabSearch: (query, pages = 2) =>
    get(`/api/grab/search?query=${encodeURIComponent(query)}&pages=${pages}`),
  grabKeywords: () => get('/api/grab/keywords'),
  grabRecords: () => get('/api/grab/records'),
  grabRecordClear: (cid = '') => post(`/api/grab/records/clear?cid=${encodeURIComponent(cid)}`),
  grabRecordCheck: (cid) => get(`/api/grab/records/check?cid=${encodeURIComponent(cid)}`),

  /* ---------------- 发布文案模板 ---------------- */
  captionTemplates: () => get('/api/captions/templates'),
  saveCaptionTemplate: (p) => post('/api/captions/templates', p),
  delCaptionTemplate: (id) => del(`/api/captions/templates/${id}`),
  genCaptions: (p) => post('/api/captions/generate', p),
  captionVariants: (pageId = '', limit = 100) =>
    get(`/api/captions/variants?pageId=${encodeURIComponent(pageId)}&limit=${limit}`),
  delCaptionVariant: (id) => del(`/api/captions/variants/${id}`),
  /* 标题池状态（合并 caption_variants 与 title_pool） */
  captionPool: (pageId = '') =>
    get(`/api/captions/pool?pageId=${encodeURIComponent(pageId)}`),
  /* 池子不足时用大模型自动补一批 */
  ensureCaptionPool: (p) => post('/api/captions/pool/ensure', p),
  previewCaption: (p) => post('/api/captions/preview', p),

  /* ---------------- 主页跳过发布 ---------------- */
  setSkipPublish: (pid, skip, reason = '') =>
    post(`/api/pages/${pid}/skip-publish`, { skip, reason }),
  setSkipBatch: (pageIds, skip, reason = '') =>
    post('/api/pages/skip-publish-batch', { pageIds, skip, reason }),

  /* ---------------- 短剧切片（严格对齐流程文档） ---------------- */
  sliceEnv: () => get('/api/slice/env'),
  sliceDramas: () => get('/api/slice/dramas'),
  sliceStatus: (drama) => get(`/api/slice/status?drama=${encodeURIComponent(drama)}`),
  sliceRun: (p) => post('/api/slice/run', p),
  sliceStep: (name, p) => post(`/api/slice/step/${name}`, p),
  sliceVerify: (path) => get(`/api/slice/verify?path=${encodeURIComponent(path)}`),
  sliceTypes: () => get('/api/slice/types'),
  sliceJudge: (p) => post('/api/slice/judge', p),
  sliceJudgeBatch: (p) => post('/api/slice/judge-batch', p),
  sliceSetType: (p) => post('/api/slice/set-type', p),
  sliceTypeReport: () => get('/api/slice/type-report'),
  sliceConstraints: () => get('/api/slice/constraints'),
  sliceJobs: () => get('/api/slice/jobs'),
  sliceMarkDone: (drama, deleteSource = false) =>
    post(`/api/slice/mark-done?drama=${encodeURIComponent(drama)}&deleteSource=${deleteSource}`),
  sliceCheckDialogue: (drama, ep = '', plan = '') => {
    const q = new URLSearchParams({ drama });
    if (ep) q.set('ep', ep);
    if (plan) q.set('plan', plan);
    return get(`/api/slice/check-dialogue?${q}`);
  },
  sliceAudioGuard: (path, minSilence = 2.0) =>
    get(`/api/slice/audio-guard?path=${encodeURIComponent(path)}&minSilence=${minSilence}`),
  sliceSources: () => get('/api/slice/sources'),
  sliceSourcesSave: (roots) => post('/api/slice/sources', { roots }),

  /* ---------------- 热更新 ---------------- */
  updateStatus: () => get('/api/update/status'),
  updateCheck: (remote = '') =>
    get('/api/update/check' + (remote ? `?remote=${encodeURIComponent(remote)}` : '')),
  updateAuto: (restart = true, remote = '') =>
    post(`/api/update/auto?restart=${restart}${remote ? `&remote=${encodeURIComponent(remote)}` : ''}`, {}),
  updateBackups: () => get('/api/update/backups'),
  updateApply: (restart = true) => post(`/api/update/apply?restart=${restart}`, {}),
  updateRollback: (backup = '') => post('/api/update/rollback', { backup }),
  updateUpload: (file) => {
    const fd = new FormData();
    fd.append('file', file);
    return fetch('/api/update/package', { method: 'POST', body: fd })
      .then((r) => r.json().then((d) => (r.ok ? d : Promise.reject(new Error(d.detail || '上传失败')))));
  },

  /* ---------------- ReelsPublisher 内核批量发布 ---------------- */
  reelsStatus: () => get('/api/reels/status'),
  reelsCheck: () => post('/api/reels/check', {}),
  reelsMaterials: (directory = '') =>
    get('/api/reels/materials' + (directory ? `?directory=${encodeURIComponent(directory)}` : '')),
  reelsPrepare: (containerCode = '') =>
    post(`/api/reels/prepare${containerCode ? `?containerCode=${containerCode}` : ''}`, {}),
  reelsPages: () => get('/api/reels/pages'),
  reelsFiles: (directory = '') =>
    get('/api/reels/files' + (directory ? `?directory=${encodeURIComponent(directory)}` : '')),
  reelsStop: (jobId = '') =>
    post(`/api/reels/stop${jobId ? `?jobId=${jobId}` : ''}`, {}),
  reelsPublish: (p) => post('/api/reels/publish', p),

  /* ---------------- 发布平台（FB 不带标签 / TK 带） ---------------- */
  publishPlatform: () => get('/api/publish/platform'),
  setPublishPlatform: (platform) => post('/api/publish/platform', { platform }),
  setHashtags: (hashtags) => post('/api/publish/hashtags', { hashtags }),
  captionPreview: (pageId, drama) =>
    get(`/api/publish/preview?pageId=${encodeURIComponent(pageId)}&drama=${encodeURIComponent(drama)}`),

  /* ---------------- 全自动总控 ---------------- */
  autoStatus: () => get('/api/auto'),
  autoMaster: (enabled) => post('/api/auto/master', { enabled }),
  autoItem: (key, enabled) => post('/api/auto/item', { key, enabled }),
  autoStop: () => post('/api/auto/stop'),
  autoItems: () => get('/api/auto/items'),
  autoQuick: (key) => post('/api/auto/quick', { key }),

  /* ---------------- 雨海 Agent ---------------- */
  agentDetect: () => get('/api/agent/detect'),
  agentDeepScan: () => post('/api/agent/deep-scan'),
  agentConnect: (agentId) => post('/api/agent/connect', { agentId }),
  agentOverview: () => get('/api/agent/overview'),
  agentHide: (p) => post('/api/agent/model/hide', p),
  agentSelectModel: (p) => post('/api/agent/model/select', p),
  agentUpload: (file) => {
    const fd = new FormData();
    fd.append('file', file);
    return fetch('/api/agent/upload', { method: 'POST', body: fd })
      .then((r) => r.json());
  }, 
  agentHideChannel: (p) => post('/api/agent/model/hide-channel', p),
  agentTest: (p) => post('/api/agent/model/test', p),
  agentTestAll: (p) => post('/api/agent/model/test-all', p),
  agentMemory: () => get('/api/agent/memory'),
  agentMemorySet: (p) => post('/api/agent/memory', p),
  agentChat: (p) => post('/api/agent/chat', p),
  // 流式对话：onEvt(stage, payload) 实时回调
  // 支持中断：agentChatStream.abort() 会断掉 fetch 与后端循环
  agentChatStream: (() => {
    let current = null;
    const fn = async (payload, onEvt) => {
      const ctrl = new AbortController();
      current = ctrl;
      try {
        const res = await fetch('/api/agent/chat/stream', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: ctrl.signal,
        });
        if (!res.ok || !res.body) {
          throw new Error('后端不可达（' + res.status + '）');
        }
        const rd = res.body.getReader();
        const dec = new TextDecoder();
        let buf = '';
        while (true) {
          const { done, value } = await rd.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const parts = buf.split('\n\n');
          buf = parts.pop() || '';
          for (const p of parts) {
            const line = p.trim();
            if (!line.startsWith('data:')) continue;
            let obj = null;
            try { obj = JSON.parse(line.slice(5).trim()); } catch (e) { continue; }
            if (obj && obj.stage && obj.stage !== 'ping') onEvt(obj.stage, obj);
          }
        }
        return true;
      } catch (e) {
        if (e && e.name === 'AbortError') {
          onEvt('stopped', { stage: 'stopped', stopped: true });
          return false;
        }
        throw e;
      } finally {
        current = null;
      }
    };
    fn.abort = () => { if (current) { current.abort(); return true; } return false; };
    fn.isRunning = () => !!current;
    return fn;
  })(),

  // 通知后端停止（中断工具执行循环）
  agentChatStop: () => post('/api/agent/chat/stop', {}),
  agentChatTest: () => get('/api/agent/chat/test'),
  // 会话历史
  agentChats: (limit = 40, q = '') =>
    get(`/api/agent/chats?limit=${limit}${q ? '&q=' + encodeURIComponent(q) : ''}`),
  agentChatNew: (p) => post('/api/agent/chats', p || {}),
  agentChatGet: (id) => get(`/api/agent/chats/${id}`),
  agentChatAppend: (id, p) => post(`/api/agent/chats/${id}/msg`, p),
  agentChatRename: (id, title) =>
    patch(`/api/agent/chats/${id}`, { title }),
  agentChatPin: (id, pinned) => post(`/api/agent/chats/${id}/pin`, { pinned }),
  agentChatDel: (id) => del(`/api/agent/chats/${id}`),
  agentChatSummary: (id) => get(`/api/agent/chats/${id}/summary`),
  agentChatSummarize: (id) => post(`/api/agent/chats/${id}/summarize`, {}),
  // 长期记忆
  agentMem: () => get('/api/agent/mem'),
  agentMemList: () => get('/api/agent/mem'),
  agentMemShow: (key) => get('/api/agent/mem'),
  agentMemDelete: (key) => del(`/api/agent/mem/${encodeURIComponent(key)}`),
  agentMemSet: (key, value) => post('/api/agent/mem', { key, value }),
  agentMemDel: (key) => del(`/api/agent/mem/${encodeURIComponent(key)}`),
  agentMemAuto: (text) => post('/api/agent/mem', { auto: text }),
  agentTools: () => get('/api/agent/tools'),
  agentMcp: () => get('/api/agent/mcp'),

  /* ---------------- 环境自检 / 安装 ---------------- */
  envFull: () => get('/api/env/full'),
  envInstall: (what = 'all', target = '') => post(
    `/api/env/install?what=${what}${target ? '&target=' + encodeURIComponent(target) : ''}`),
  envModel: (name = 'small') => get(`/api/env/model?name=${name}`),
  envPaths: () => get('/api/env/paths'),
  envPathsSave: (patch) => post('/api/env/paths', patch),
  envEnsureDirs: () => post('/api/env/ensure-dirs'),

  /* ---------------- AI 分析 ---------------- */
  aiAnalyze: (p) => post('/api/ai/analyze', p),
  aiAnalyzeBatch: (p) => post('/api/ai/analyze-batch', p),
  aiFit: () => get('/api/ai/fit'),
  aiFitPage: (pid) => get(`/api/ai/fit/${pid}`),
  aiStats: (pid, days = 30) => get(`/api/ai/stats/${pid}?windowDays=${days}`),
  aiHistory: () => get('/api/ai/history'),
  aiMatch: (pid, mode = 'fit', limit = 50) =>
    get(`/api/ai/match?page_id=${encodeURIComponent(pid)}&mode=${mode}&limit=${limit}`),
  archiveLib: (id) => post('/api/library/archive', { id }),
  libraryRoots: () => get('/api/library/roots'),
  pipeline: () => get('/api/library/pipeline'),
  runPipeline: (p) => post('/api/library/pipeline/run', p),

  queue: (kind = '', state = '') => {
    const q = [];
    if (kind) q.push(`kind=${kind}`);
    if (state) q.push(`state=${state}`);
    return get('/api/queue' + (q.length ? '?' + q.join('&') : ''));
  },
  scheduleMissed: (days = 7) => get(`/api/schedule/missed?days=${days}`),
  scheduleRequeue: (sid) => post(`/api/schedule/${sid}/requeue`),
  addQueue: (p) => post('/api/queue', p),
  delQueue: (id, delFile = false) => del(`/api/queue/${id}?deleteFile=${delFile}`),

  schedule: (p = {}) => {
    const q = new URLSearchParams();
    if (p.from) q.set('from', p.from);
    if (p.to) q.set('to', p.to);
    return get(`/api/schedule?${q}`);
  },
  addSchedule: (p) => post('/api/schedule', p),
  patchSchedule: (id, p) => patch(`/api/schedule/${id}`, p),
  delSchedule: (id) => del(`/api/schedule/${id}`),
  scheduleRules: () => get('/api/schedule/rules'),
  setScheduleRules: (p) => post('/api/schedule/rules', p),
  autoplan: (p) => post('/api/schedule/autoplan', p),
  capacity: (days = 3) => post(`/api/schedule/capacity?days=${days}`),

  /* ---------------- 发布 ---------------- */
  publish: (p) => post('/api/publish', p),
  publishHistory: () => get('/api/publish/history'),
  captionTemplate: () => get('/api/publish/caption-template'),
  renderCaption: (p) => post('/api/publish/render-caption', p),

  /* ---------------- 邮件 ---------------- */
  mails: (p = {}) => {
    const q = new URLSearchParams();
    if (p.limit) q.set('limit', p.limit);
    if (p.mailbox) q.set('mailbox', p.mailbox);
    if (p.onlyCode) q.set('only_code', 'true');
    return get(`/api/mail?${q}`);
  },
  latestCode: (mailbox = '', maxAge = 900) =>
    get(`/api/mail/latest?mailbox=${encodeURIComponent(mailbox)}&max_age_sec=${maxAge}`),
  markSeen: (id) => post('/api/mail/seen', { id }),
  mailChannels: () => get('/api/mail/channels'),
  saveChannel: (p) => post('/api/mail/channels', p),
  testChannel: (id) => post('/api/mail/channels/test', { id }),
  pullMail: (p = {}) => post('/api/mail/pull', p),
  manualMail: (p) => post('/api/mail/manual', p),

  /* ---------------- 三方 ---------------- */
  integrations: () => get('/api/integrations'),
  saveIntegration: (p) => post('/api/integrations', p),
  testIntegration: (id) => post(`/api/integrations/${id}/test`),
  models: () => get('/api/integrations/models'),
  dshStatus: () => get('/api/integrations/dsh'),
  dshModels: () => get('/api/integrations/dsh/models'),
  dshSelectModel: (model) => post('/api/integrations/dsh/model', { model }),
  dshChannels: () => get('/api/integrations/dsh/channels'),
  dshPlugins: () => get('/api/integrations/dsh/plugins'),
  dshTest: (model) => get(`/api/integrations/dsh/test?model=${encodeURIComponent(model)}`),
  skills: () => get('/api/integrations/skills'),
  plugins: () => get('/api/integrations/plugins'),

  /* ---------------- 任务 ---------------- */
  jobs: (p = {}) => {
    const q = new URLSearchParams();
    if (p.status) q.set('status', p.status);
    if (p.kind) q.set('kind', p.kind);
    if (p.limit) q.set('limit', p.limit);
    return get(`/api/jobs?${q}`);
  },
  job: (id) => get(`/api/jobs/${id}`),
  cancelJob: (id) => post(`/api/jobs/${id}/cancel`),

  /* ---------------- 洞察（旧接口，保留兼容） ---------------- */
  insights: (days = 14) => get(`/api/insights?days=${days}`),
  collectInsights: (p = {}) => post('/api/insights/collect', p),

  /* ---------------- 短剧下载（多站点） ---------------- */
  dlSites: (sig) => get('/api/dl/sites', sig),
  dlEnv: (sig) => get('/api/dl/env', sig),
  dlHome: (site = 'pinedrama') => get(`/api/dl/home?site=${encodeURIComponent(site)}`),
  dlSearch: (site, kw = '', limit = 60, sig) =>
    get(`/api/dl/search?site=${encodeURIComponent(site)}&kw=${encodeURIComponent(kw)}&limit=${limit}`, sig),
  dlMeta: (site, slug, force = 0, sig) =>
    get(`/api/dl/meta?site=${encodeURIComponent(site)}&slug=${encodeURIComponent(slug)}&force=${force}`, sig),
  dlDownload: (p) => post('/api/dl/download', p),
  dlTasks: () => get('/api/dl/tasks'),
  dlCancel: (id) => post('/api/dl/task/cancel', { id }),
  dlRemove: (id) => post('/api/dl/task/remove', { id }),
  dlLibrary: () => get('/api/dl/library'),
  dlEpisodes: (site, slug) =>
    get(`/api/dl/episodes?site=${encodeURIComponent(site)}&slug=${encodeURIComponent(slug)}`),
  dlTikTokMeta: (id) => get(`/api/dl/tiktok/meta?id=${encodeURIComponent(id)}`),
  dlTikTokDownload: (id) => post('/api/dl/tiktok/download', { id }),
  dlConfig: () => get('/api/dl/config'),
  dlConfigSet: (p) => post('/api/dl/config', p),
  dlBrowse: (path = '') => get(`/api/dl/browse?path=${encodeURIComponent(path)}`),
  dlPickFolder: (initial = '') =>
    post(`/api/dl/pick-folder?initial=${encodeURIComponent(initial)}`, {}),
  dlSdMeta: (id, force = 0, sig) =>
    get(`/api/dl/sd/meta?id=${encodeURIComponent(id)}&force=${force}`, sig),
  dlSdStatus: () => get('/api/dl/sd/status'),
  dlSdBatch: (ids, stopOnFail = false) =>
    post('/api/dl/sd/batch', { ids, stopOnFail }),
  dlSdHistory: () => get('/api/dl/sd/history'),
  dlSdHistoryClear: (ids = null) =>
    post('/api/dl/sd/history/clear', ids ? { ids } : {}),
  dlSdBrowserStart: (p = {}) => post('/api/dl/sd/browser/start', p),
  dlSdBrowserStop: () => post('/api/dl/sd/browser/stop', {}),
  dlSdBrowserEnsure: (p = {}) => post('/api/dl/sd/browser/ensure', p),
  dlSdBrowserConfig: (p = {}) => post('/api/dl/sd/browser/config', p),
  dlSlice: (p) => post('/api/dl/slice', p),
};

/* ---------------- 轮询工具 ---------------- */
export function pollJob(jobId, { interval = 2500, timeout = 600000,
                                onTick } = {}) {
  const t0 = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const j = await api.job(jobId);
        if (onTick) onTick(j);
        if (['done', 'failed', 'blocked', 'cancelled'].includes(j.status)) {
          return resolve(j);
        }
        if (Date.now() - t0 > timeout) {
          return reject(new ApiError('任务超时', 408, j));
        }
        setTimeout(tick, interval);
      } catch (e) {
        reject(e);
      }
    };
    tick();
  });
}
