/* 雨海 Agent — 方案 C 卡片流
   检测本机 Agent → 接入 → 显示全部模型（DSH订阅 + 网关全量）→ 对话操作 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { pageHead, $, $$, toast, ts, emptyState } from '../ui.js';

let ov = null;
let detecting = false;
let chatHistory = [];      // [{role, content, trace, error}]
let chatting = false;
let tab = 'chat';          // chat | models
let filterCh = '';         // 模型渠道筛选
let showGateway = true;    // 是否显示网关全量

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

const nl = (s) => esc(s).replace(/\n/g, '<br>');

const short = (p) => {
  const s = String(p || '');
  if (s.length < 46) return s;
  return s.slice(0, 20) + '…' + s.slice(-22);
};

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '雨海 Agent',
      desc: '接入本机 Agent，用它的模型驱动工作台',
      actions: [
        `<button class="btn sm" data-act="detect"><span data-icon="refresh"></span>重新检测</button>`,
        `<button class="btn sm ghost" data-act="deep">深度扫描</button>`,
      ],
    })}
    <div id="ag-body"></div>
  `;
  $$('[data-act="detect"]', root).forEach((b) => (b.onclick = () => detect(root)));
  $$('[data-act="deep"]', root).forEach((b) => (b.onclick = () => deepScan(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try { ov = await api.agentOverview(); } catch { ov = null; }
  paint(root);
}

async function detect(root) {
  if (detecting) return;
  detecting = true;
  const box = $('#ag-body', root);
  if (box) box.innerHTML = renderDetecting();
  try {
    const r = await api.agentDetect();
    toast(r.ok ? '检测完成' : '未找到 Agent', `${r.installed} 个可用`,
          r.ok ? 'ok' : 'warn');
    await load(root);
  } catch (e) { toast('检测失败', e.message, 'err'); }
  detecting = false;
}

async function deepScan(root) {
  toast('深度扫描中', '逐个磁盘找，可能几十秒', 'info');
  try {
    const r = await api.agentDeepScan();
    toast(`找到 ${r.count} 个`, (r.found || []).slice(0, 3).join('\n') || '无', 'ok');
  } catch (e) { toast('扫描失败', e.message, 'err'); }
}

/* ══════════════════════════════════════════
   检测中：骨架动画
   ══════════════════════════════════════════ */
function renderDetecting() {
  return `
    <style>${CARD_CSS}</style>
    <div class="ag-pane" style="height:auto;min-height:300px">
      <div class="ag-bg"></div>
      <div style="position:relative;padding:60px 24px;text-align:center">
        <div class="ag-scan"></div>
        <div style="font-size:14px;color:var(--tx-0);font-weight:600;margin-bottom:8px">
          正在扫描本机 Agent</div>
        <div style="font-size:11px;color:var(--tx-2);line-height:1.9">
          DSH · Codex · Claude · Cursor · Ollama · WorkBuddy<br>
          Windsurf · Cline · Continue · Trae
        </div>
      </div>
    </div>`;
}

/* ══════════════════════════════════════════
   未接入：Agent 选择卡片（重点重做）
   ══════════════════════════════════════════ */
function renderPicker(ov) {
  const list = (ov && ov.detected) || [];
  const found = list.filter((a) => a.installed);
  const missing = list.filter((a) => !a.installed);

  const card = (a) => {
    const on = ov && ov.connected === a.id;
    const n = (a.models || []).length;
    const gw = a.gatewayCount || 0;
    return `
      <div class="ag-agent-card ${on ? 'on' : ''} ${a.installed ? '' : 'off'}"
           data-pick="${esc(a.id)}" data-installed="${a.installed ? 1 : 0}">
        <div class="ag-agent-top">
          <div class="ag-agent-ico">${esc(a.name.slice(0, 2))}</div>
          <div class="ag-agent-name">${esc(a.name)}</div>
          ${on ? '<div class="ag-agent-badge">使用中</div>' : ''}
        </div>
        <div class="ag-agent-why">${esc(a.why || '')}</div>
        <div class="ag-agent-stat">
          ${a.installed
            ? `<span class="ag-ok">●</span> 已安装 · ${n} 个模型${gw ? ` <span style="opacity:.6">(网关 ${gw})</span>` : ''}`
            : `<span class="ag-dim">○</span> 未检测到`}
        </div>
        ${a.installed ? '' : `
          <div class="ag-agent-dl" data-dl="${esc(a.download || '')}">
            ${a.download ? '点击下载 →' : '需手动安装'}
          </div>`}
      </div>`;
  };

  return `
    <style>${CARD_CSS}</style>
    <div style="margin-bottom:14px">
      <div style="font-size:13px;font-weight:600;color:var(--tx-1);margin-bottom:4px">
        选择要接入的 Agent</div>
      <div style="font-size:10.5px;color:var(--tx-3);line-height:1.8">
        只显示接入的 Agent 自己的模型 · 点卡片切换 · 灰色的是未安装
      </div>
    </div>

    <div class="ag-agent-grid">
      ${found.map(card).join('')}
      ${missing.length ? `
        <div class="ag-agent-divider">未安装（共 ${missing.length} 个）</div>
        ${missing.map(card).join('')}` : ''}
    </div>
  `;
}

/* ══════════════════════════════════════════
   主渲染
   ══════════════════════════════════════════ */
function paint(root) {
  const box = $('#ag-body', root);
  if (!box) return;

  if (!ov) { box.innerHTML = renderPicker(null); bindPicker(root); return; }
  if (!ov.connected) { box.innerHTML = renderPicker(ov); bindPicker(root); return; }

  // 已接入 → 顶部状态条 + tab + 内容
  const ms = ov.models || [];
  const visible = ms.filter((m) => !m.hidden);
  const gwCount = ms.filter((m) => m.inGateway).length;

  box.innerHTML = `
    <style>${CARD_CSS}</style>
    <div class="ag-topbar">
      <div class="ag-dot"></div>
      <div class="ag-topname">${esc(ov.name || ov.connected)}</div>
      <div class="ag-topmeta">${visible.length} 个模型${
        gwCount ? ` · 网关 ${gwCount}` : ''}</div>
      <div class="ag-topsep"></div>
      <div class="ag-modelsel" id="ag-model-sel">
        <span class="ag-sel-cur" title="${esc(ov.model || '')}">${
          esc(shortModel(ov.model || '（默认）'))}</span>
        <span class="ag-sel-arr">▾</span>
        <div class="ag-sel-pop" id="ag-sel-pop">
          ${visible.map((m) => `
            <div class="ag-sel-row ${m.id === ov.model ? 'on' : ''}"
                 data-pick-m="${esc(m.id)}">
              <span class="ag-sel-nm">${esc(m.id)}</span>
              ${m.vision ? '<i class="ag-tag v">视</i>' : ''}
            </div>`).join('')}
        </div>
      </div>
      <button class="ag-tbtn ${tab === 'chat' ? 'on' : ''}" data-tab="chat">
        对话</button>
      <button class="ag-tbtn ${tab === 'models' ? 'on' : ''}" data-tab="models">
        模型 <span class="ag-cnt">${visible.length}</span></button>
      <button class="ag-tbtn ghost" data-act="switch">切换</button>
    </div>
    ${tab === 'chat' ? renderChat(ov) : renderModels(ov)}
  `;

  // tab 切换
  $$('[data-tab]', root).forEach((b) => {
    b.onclick = () => { tab = b.dataset.tab; paint(root); };
  });
  const sw = $('[data-act="switch"]', root);
  if (sw) sw.onclick = async () => {
    try { await api.agentConnect(''); await load(root); }
    catch (e) { toast('切换失败', e.message, 'err'); }
  };

  if (tab === 'chat') bindChat(root);
  else bindModels(root);
}

function bindPicker(root) {
  $$('[data-pick]', root).forEach((c) => {
    c.onclick = async () => {
      const id = c.dataset.pick;
      if (c.dataset.installed !== '1') {
        const dl = c.querySelector('[data-dl]');
        const url = dl && dl.dataset.dl;
        if (url) { window.open(url, '_blank'); toast('下载页已打开', '', 'ok'); }
        else toast('未安装', '需要手动装这个 Agent', 'warn');
        return;
      }
      try {
        const r = await api.agentConnect(id);
        toast('已接入', r.note || r.name || id, 'ok');
        await load(root);
      } catch (e) { toast('接入失败', e.message, 'err'); }
    };
  });
}

/* ══════════════════════════════════════════
   对话（方案 C）
   ══════════════════════════════════════════ */
function renderChat(ov) {
  const cards = chatHistory.map((m) => {
    if (m.role === 'user') {
      const at = (m.atts || []).map((a) => `
        <span class="ag-att-chip">${a.kind === 'image' ? '🖼' : '📄'}
          ${esc(a.name)}</span>`).join('');
      return `<div class="ag-card me">${nl(m.content)}
        ${at ? `<div class="ag-att-row">${at}</div>` : ''}</div>`;
    }
    const tr = (m.trace || []).map((t) => `
      <div class="ag-tool ${t.ok ? '' : 'fail'}">
        <span class="ag-tic">${t.ok ? '✓' : '✗'}</span>
        <span class="ag-tnm">${esc(t.tool)}</span>
        <span class="ag-tms">${t.ms}ms</span>
      </div>`).join('');
    return `
      <div class="ag-card ai">
        <div class="ag-ai-head">
          <div class="ag-avatar">雨</div>
          <div class="ag-ai-name">${esc(ov.name || '雨海 Agent')}</div>
          <div class="ag-ai-model">${esc(m.model || ov.model || '')}</div>
        </div>
        ${m.error
          ? `<div style="color:var(--danger);font-size:11px">${nl(m.content)}</div>`
          : nl(m.content)}
        ${tr ? `<div class="ag-tools">${tr}</div>` : ''}
      </div>`;
  }).join('');

  const empty = `
    <div class="ag-empty">
      <div class="ag-empty-ico">雨</div>
      <div class="ag-empty-t">直接说话就能操作工作台</div>
      <div class="ag-empty-hints">
        ${[
          '现在有哪些剧可以切？',
          '给网易发布号01 建个主页 Y20，授权给它',
          '检查一下环境有没有问题',
          '上次切到哪了？',
        ].map((h) => `<div class="ag-hint-item" data-hint="${esc(h)}">
            <span class="ag-hint-arr">›</span>${esc(h)}</div>`).join('')}
      </div>
    </div>`;

  return `
    <div class="ag-chatwrap">
      <div id="ag-chat" class="ag-chatbody">
        ${cards || empty}
        ${chatting ? `<div class="ag-card ai">
          <div class="ag-ai-head">
            <div class="ag-avatar">雨</div>
            <div class="ag-ai-name">正在思考…</div>
          </div>
          <div class="ag-typing"><span></span><span></span><span></span></div>
        </div>` : ''}
      </div>
      <div class="ag-inputarea">
        <div class="ag-attbar" id="ag-attbar"></div>
        <div class="ag-inputbox">
          <textarea id="ag-input" rows="2"
            placeholder="说要做什么…（Enter 发送 · Shift+Enter 换行 · 可直接粘贴截图）"></textarea>
          <div class="ag-actions">
            <button class="ag-uploadb" id="ag-upload" title="上传文件/图片">
              <span>＋</span></button>
            <input type="file" id="ag-file" multiple
              accept="image/*,.txt,.md,.json,.csv,.log,.py,.js,.html,.pdf,.zip"
              style="display:none" />
            <button class="ag-mini" id="ag-clear">清空</button>
            <div class="ag-hintline">${esc(ov.name || '')} · ${esc(shortModel(ov.model || ''))}</div>
            <button class="ag-sendbtn" id="ag-send" ${chatting ? 'disabled' : ''}>
              ${chatting ? '…' : '发送'}</button>
          </div>
        </div>
      </div>
    </div>`;
}

let attachments = [];      // 待发送附件

function shortModel(m) {
  const x = String(m || '');
  if (!x) return '（默认）';
  return x.length > 28 ? x.slice(0, 26) + '…' : x;
}

function bindChat(root) {
  const inp = $('#ag-input', root);

  // ---- 模型下拉 ----
  const sel = $('#ag-model-sel', root);
  const pop = $('#ag-sel-pop', root);
  if (sel && pop) {
    sel.onclick = (e) => {
      e.stopPropagation();
      pop.classList.toggle('open');
    };
    document.addEventListener('click', () => pop.classList.remove('open'), {
      once: true,
    });
    $$('[data-pick-m]', root).forEach((r) => {
      r.onclick = async (e) => {
        e.stopPropagation();
        pop.classList.remove('open');
        const mid = r.dataset.pickM;
        try {
          await api.agentSelectModel({ agentId: ov.connected, modelId: mid });
          toast('已切换模型', mid, 'ok');
          await load(root);
        } catch (err) { toast('切换失败', err.message, 'err'); }
      };
    });
  }

  // ---- 上传 ----
  const upb = $('#ag-upload', root);
  const fin = $('#ag-file', root);
  if (upb && fin) {
    upb.onclick = () => fin.click();
    fin.onchange = async () => {
      const files = Array.from(fin.files || []);
      fin.value = '';
      for (const f of files) await addAttachment(root, f);
    };
  }

  // ---- 粘贴截图 ----
  if (inp) {
    inp.onpaste = async (e) => {
      const items = (e.clipboardData || {}).items || [];
      for (const it of items) {
        if (it.type && it.type.startsWith('image/')) {
          e.preventDefault();
          const blob = it.getAsFile();
          if (blob) {
            await addAttachment(root, new File([blob],
              'paste_' + Date.now() + '.png', { type: blob.type }));
          }
        }
      }
    };
  }

  paintAtts(root);
  const btn = $('#ag-send', root);
  if (btn) btn.onclick = () => send(root);
  if (inp) {
    try {
      const pre = sessionStorage.getItem('agent_prefill');
      if (pre && !inp.value) {
        inp.value = pre;
        sessionStorage.removeItem('agent_prefill');
      }
    } catch (e) { /* ignore */ }
    inp.onkeydown = (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(root); }
    };
    inp.focus();
  }
  $$('[data-hint]', root).forEach((h) => {
    h.onclick = () => {
      const i = $('#ag-input', root);
      if (i) { i.value = h.dataset.hint; i.focus(); }
      if (h.dataset.hint) send(root);
    };
  });
  const clr = $('#ag-clear', root);
  if (clr) clr.onclick = () => { chatHistory = []; paint(root); };
  scrollBottom(root);
}

async function addAttachment(root, file) {
  toast('上传中', file.name, 'info');
  try {
    const r = await api.agentUpload(file);
    if (!r.ok) { toast('上传失败', r.error || '', 'err'); return; }
    attachments.push(r);
    paintAtts(root);
    toast('已添加', `${r.name} (${r.sizeMb}MB)`, 'ok');
  } catch (e) { toast('上传失败', e.message, 'err'); }
}

function paintAtts(root) {
  const bar = $('#ag-attbar', root);
  if (!bar) return;
  if (!attachments.length) { bar.innerHTML = ''; bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  bar.innerHTML = attachments.map((a, i) => `
    <div class="ag-att ${a.kind === 'image' ? 'img' : ''}" data-attidx="${i}">
      ${a.kind === 'image' && a.dataUri
        ? `<img src="${a.dataUri}" alt="" />`
        : `<span class="ag-att-ico">📄</span>`}
      <span class="ag-att-nm">${esc(a.name)}</span>
      <span class="ag-att-sz">${a.sizeMb}MB</span>
      <span class="ag-att-x" data-attdel="${i}">×</span>
    </div>`).join('');
  $$('[data-attdel]', bar).forEach((b) => {
    b.onclick = () => {
      attachments.splice(Number(b.dataset.attdel), 1);
      paintAtts(root);
    };
  });
}

function scrollBottom(root) {
  const c = $('#ag-chat', root);
  if (c) c.scrollTop = c.scrollHeight;
}

async function send(root) {
  if (chatting) return;
  const inp = $('#ag-input', root);
  const text = (inp && inp.value || '').trim();
  if (!text) return;
  inp.value = '';
  const atts = attachments.slice();
  attachments = [];
  chatHistory.push({
    role: 'user', content: text,
    atts: atts.map((a) => ({ name: a.name, kind: a.kind })) });
  chatting = true;
  paint(root);
  try {
    const r = await api.agentChat({
      message: text,
      history: chatHistory.slice(0, -1)
        .map((h) => ({ role: h.role, content: h.content })),
      autoRunTools: true,
      attachments: atts,
    });
    chatHistory.push({
      role: 'assistant', content: r.reply || r.content || '（无回复）',
      trace: r.trace || [], model: r.model, error: r.error,
    });
  } catch (e) {
    chatHistory.push({ role: 'assistant', content: '请求失败: ' + e.message,
                       error: true });
  }
  chatting = false;
  paint(root);
}

/* ══════════════════════════════════════════
   模型（带自动隐藏 + 网关开关）
   ══════════════════════════════════════════ */
function renderModels(ov) {
  const all = ov.models || [];
  const ms = showGateway ? all : all.filter((m) => !m.inGateway || m.inDsh);

  const groups = {};
  for (const m of ms) {
    const g = m.channel || m.source || (m.id.includes('/') ? m.id.split('/')[0] : '其它');
    (groups[g] = groups[g] || []).push(m);
  }

  const gwTotal = all.filter((m) => m.inGateway).length;
  const dshTotal = all.filter((m) => m.inDsh).length;

  const chips = Object.keys(groups).sort().map((g) => {
    const n = groups[g].length;
    const hid = groups[g].filter((x) => x.hidden).length;
    const allHid = hid === n;
    return `<button class="ag-chip ${allHid ? 'ghost' : ''}"
      data-hidech="${esc(g)}" data-to="${allHid ? '0' : '1'}">
      ${esc(g)} ${n}${hid ? `<span class="ag-chip-dim">隐${hid}</span>` : ''}</button>`;
  }).join('');

  const rowHtml = (m) => {
    const t = (ov.tested || {})[m.id];
    const st = t ? (t.ok ? 'ok' : 'bad') : '';
    return `<div class="ag-mrow">
      <div class="ag-mname" title="${esc(m.id)}">${esc(m.id)}</div>
      <div class="ag-mtags">
        ${m.inDsh ? '<i class="ag-tag dsh">dsh</i>' : ''}
        ${m.inGateway && !m.inDsh ? '<i class="ag-tag gw">网关</i>' : ''}
        ${m.vision ? '<i class="ag-tag v">视觉</i>' : ''}
      </div>
      <div class="ag-mstat ${st}">
        ${st === 'ok' ? '✓' : st === 'bad' ? '✗ ' + esc((t.error || '').slice(0, 14)) : ''}
      </div>
      <button class="ag-mbtn" data-test="${esc(m.id)}">测</button>
      <button class="ag-mbtn" data-hide="${esc(m.id)}"
        data-to="${m.hidden ? 0 : 1}">${m.hidden ? '显' : '隐'}</button>
    </div>`;
  };

  const sections = Object.keys(groups).sort().map((g) => {
    const list = groups[g];
    const shown = list.filter((m) => !m.hidden);
    return `<div class="ag-mgroup">
      <div class="ag-mghead">${esc(g)}
        <span class="ag-mgcnt">${shown.length}/${list.length}</span></div>
      ${shown.map(rowHtml).join('')}
      ${list.length - shown.length > 0
        ? `<div class="ag-mhidden">另有 ${list.length - shown.length} 个已隐藏</div>`
        : ''}
    </div>`;
  }).join('');

  const hiddenCount = all.filter((m) => m.hidden).length;

  return `
    <div class="ag-models">
      <div class="ag-mtop">
        <div class="ag-mmeta">
          端点 ${esc(short(ov.endpoint) || '本地')}<br>
          DSH 订阅 ${dshTotal} · 网关全量 ${gwTotal} · 隐藏 ${hiddenCount}
        </div>
        <div class="ag-mctl">
          <button class="ag-tbtn ${showGateway ? 'on' : ''}" data-act="gwtoggle">
            ${showGateway ? '显示网关全量' : '只看 DSH 订阅'}</button>
          <button class="ag-tbtn" data-act="testall">全测</button>
          <button class="ag-tbtn" data-act="autohide">测+自动隐藏坏的</button>
        </div>
      </div>
      <div class="ag-chips">${chips}</div>
      <div class="ag-mlist">${sections}</div>
    </div>`;
}

function bindModels(root) {
  const gwT = $('[data-act="gwtoggle"]', root);
  if (gwT) gwT.onclick = () => { showGateway = !showGateway; paint(root); };

  $$('[data-hide]', root).forEach((b) => {
    b.onclick = () => toggleHide(root, b.dataset.hide, b.dataset.to === '1');
  });
  $$('[data-hidech]', root).forEach((b) => {
    b.onclick = () => hideChannel(root, b.dataset.hidech, b.dataset.to === '1');
  });
  $$('[data-test]', root).forEach((b) => {
    b.onclick = () => testModel(root, b.dataset.test);
  });

  const ta = $('[data-act="testall"]', root);
  if (ta) ta.onclick = async () => {
    ta.disabled = true; ta.textContent = '测试中…';
    toast('批量测试', '逐个验证，较慢', 'info');
    try {
      const r = await api.agentTestAll({ agentId: ov.connected });
      toast('完成', `${r.passed} 可用 / ${r.failed} 不可用`, 'ok');
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    ta.disabled = false; ta.textContent = '全测';
  };

  const ah = $('[data-act="autohide"]', root);
  if (ah) ah.onclick = async () => {
    if (!confirm('会逐个实测全部模型，失败的自动隐藏。\n模型多时可能要几分钟，继续？')) return;
    ah.disabled = true; ah.textContent = '实测中…';
    toast('自动隐藏', '实测全部模型，失败的重试一次', 'info');
    try {
      const r = await api.agentTestAll({
        agentId: ov.connected, autoHide: true,
      });
      toast('完成',
        `${r.passed} 可用 / ${r.failed} 不可用，已隐藏 ${r.autoHidden || 0} 个`,
        (r.passed || 0) > 0 ? 'ok' : 'warn', 8000);
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    ah.disabled = false; ah.textContent = '测+自动隐藏坏的';
  };
}

async function toggleHide(root, mid, hidden) {
  try {
    await api.agentHide({ agentId: ov.connected, modelId: mid, hidden });
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function hideChannel(root, ch, hidden) {
  try {
    const r = await api.agentHideChannel({ agentId: ov.connected, channel: ch, hidden });
    toast(hidden ? '已隐藏' : '已显示', `${ch} ${r.count || ''} 个`, 'ok');
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function testModel(root, mid) {
  toast('测试中', mid, 'info');
  try {
    const r = await api.agentTest({ agentId: ov.connected, modelId: mid });
    toast(r.ok ? '可用' : '不可用',
      r.ok ? (r.reply || '').slice(0, 30) : (r.error || ''),
      r.ok ? 'ok' : 'err', 6000);
    await load(root);
  } catch (e) { toast('失败', e.message, 'err'); }
}

/* ══════════════════════════════════════════
   样式（方案 C）
   ══════════════════════════════════════════ */
const CARD_CSS = `
.ag-pane{position:relative;background:var(--bg-1);border:1px solid var(--line);
  border-radius:12px;overflow:hidden}
.ag-bg{position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(circle at 15% 5%,var(--ac)1a,transparent 42%),
  radial-gradient(circle at 88% 90%,var(--ok)12,transparent 38%)}

/* ---- 顶部状态条 ---- */
.ag-topbar{display:flex;align-items:center;gap:9px;padding:11px 14px;
  background:var(--bg-2);border:1px solid var(--line);border-radius:9px;
  margin-bottom:11px}
.ag-dot{width:7px;height:7px;border-radius:50%;background:var(--ok);
  box-shadow:0 0 6px var(--ok)88;flex-shrink:0}
.ag-topname{font-size:12.5px;font-weight:600;color:var(--tx-0)}
.ag-topmeta{font-size:10px;color:var(--tx-2)}
.ag-topsep{flex:1}
.ag-tbtn{background:var(--bg-3);border:1px solid var(--line);border-radius:6px;
  color:var(--tx-2);font-size:10px;padding:4px 10px;cursor:pointer;
  font-family:inherit;transition:.15s}
.ag-tbtn:hover{background:var(--line);color:var(--tx-1)}
.ag-tbtn.on{background:var(--ac)22;border-color:var(--ac)66;color:var(--ac)}
.ag-tbtn.ghost{background:none}
.ag-cnt{opacity:.6;font-size:9px}

/* ---- 卡片 ---- */
.ag-chatwrap{border:1px solid var(--line);border-radius:11px;
  background:var(--bg-1);overflow:hidden;position:relative}
.ag-chatbody{height:calc(100vh - 320px);min-height:300px;overflow-y:auto;
  padding:15px;display:flex;flex-direction:column;gap:11px;
  background:radial-gradient(circle at 12% 0%,var(--ac)12,transparent 40%)}
.ag-card{border-radius:10px;padding:11px 13px;font-size:12px;line-height:1.72;
  animation:agIn .22s ease}
@keyframes agIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.ag-card.me{background:linear-gradient(135deg,var(--ac)26,var(--ac)0d);
  border:1px solid var(--ac)4d;align-self:flex-end;max-width:82%;color:var(--ac)}
.ag-card.ai{background:var(--bg-2);border:1px solid var(--bg-3);max-width:92%;
  color:var(--tx-1)}
.ag-ai-head{display:flex;align-items:center;gap:7px;margin-bottom:7px;
  padding-bottom:7px;border-bottom:1px solid var(--bg-3)}
.ag-avatar{width:20px;height:20px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:9px;color:#fff;
  font-weight:600}
.ag-ai-name{font-size:10.5px;color:var(--tx-0);font-weight:600}
.ag-ai-model{font-size:9px;color:var(--tx-3);margin-left:auto;
  font-family:var(--mono);max-width:55%;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}

/* ---- 工具链 ---- */
.ag-tools{margin-top:9px;display:flex;flex-direction:column;gap:4px}
.ag-tool{display:flex;align-items:center;gap:7px;background:var(--bg-1);
  border:1px solid var(--bg-3);border-left:2px solid var(--ok);border-radius:5px;
  padding:5px 9px;font-size:10px}
.ag-tool.fail{border-left-color:var(--danger)}
.ag-tic{color:var(--ok);flex-shrink:0}
.ag-tool.fail .ag-tic{color:var(--danger)}
.ag-tnm{color:var(--tx-1);font-family:var(--mono)}
.ag-tms{margin-left:auto;color:var(--tx-3)}

/* ---- 输入 ---- */
.ag-inputarea{padding:11px 13px 13px;border-top:1px solid var(--bg-3);
  background:var(--bg-2)99}
.ag-inputbox{background:var(--bg-1);border:1px solid var(--line);border-radius:9px;
  padding:9px 11px;transition:.15s}
.ag-inputbox:focus-within{border-color:var(--ac);
  box-shadow:0 0 0 2px var(--ac)22}
.ag-inputbox textarea{width:100%;background:none;border:none;outline:none;
  color:var(--tx-1);font-size:12px;resize:none;font-family:inherit;
  line-height:1.6}
.ag-inputbox textarea::placeholder{color:var(--tx-3)}
.ag-actions{display:flex;align-items:center;gap:8px;margin-top:7px}
.ag-mini{background:none;border:none;color:var(--tx-3);font-size:9.5px;
  cursor:pointer;padding:2px 4px;font-family:inherit}
.ag-mini:hover{color:var(--tx-1)}
.ag-hintline{flex:1;font-size:9px;color:var(--tx-3);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-sendbtn{background:linear-gradient(135deg,var(--ac),var(--ac-2));border:none;
  border-radius:6px;color:#fff;font-size:11px;font-weight:500;
  padding:5px 15px;cursor:pointer;font-family:inherit}
.ag-sendbtn:disabled{opacity:.5;cursor:default}

/* ---- 空状态 ---- */
.ag-empty{display:flex;flex-direction:column;align-items:center;
  justify-content:center;flex:1;padding:26px 14px;text-align:center}
.ag-empty-ico{width:44px;height:44px;border-radius:50%;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:17px;color:#fff;
  font-weight:600;margin-bottom:13px;
  box-shadow:0 4px 18px var(--ac)44}
.ag-empty-t{font-size:12.5px;color:var(--tx-0);font-weight:600;margin-bottom:14px}
.ag-empty-hints{display:flex;flex-direction:column;gap:6px;width:100%;
  max-width:420px}
.ag-hint-item{text-align:left;font-size:11px;color:var(--tx-2);
  background:var(--bg-2);border:1px solid var(--bg-3);border-radius:7px;
  padding:7px 11px;cursor:pointer;transition:.15s}
.ag-hint-item:hover{background:var(--ac)1a;border-color:var(--ac)4d;
  color:var(--ac);transform:translateX(2px)}
.ag-hint-arr{color:var(--ac);margin-right:6px;font-weight:600}

/* ---- 打字动画 ---- */
.ag-typing{display:flex;gap:4px;padding:4px 0}
.ag-typing span{width:5px;height:5px;border-radius:50%;background:var(--ac);
  animation:agBlink 1.3s infinite}
.ag-typing span:nth-child(2){animation-delay:.18s}
.ag-typing span:nth-child(3){animation-delay:.36s}
@keyframes agBlink{0%,60%,100%{opacity:.25}30%{opacity:1}}

/* ---- 扫描动画 ---- */
.ag-scan{width:60px;height:60px;margin:0 auto 18px;border-radius:50%;
  border:2px solid var(--ac)33;position:relative}
.ag-scan:after{content:'';position:absolute;inset:-2px;border-radius:50%;
  border:2px solid transparent;border-top-color:var(--ac);
  animation:agSpin 1s linear infinite}
@keyframes agSpin{to{transform:rotate(360deg)}}

/* ---- Agent 选择卡片 ---- */
.ag-agent-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));
  gap:10px}
.ag-agent-card{position:relative;background:var(--bg-2);border:1px solid var(--line);
  border-radius:10px;padding:12px 13px;cursor:pointer;transition:.18s;
  overflow:hidden}
.ag-agent-card:hover{border-color:var(--ac)66;transform:translateY(-2px);
  box-shadow:0 6px 20px var(--sh-2)}
.ag-agent-card.on{border-color:var(--ok)88;background:var(--bg-2);
  box-shadow:0 0 0 1px var(--ok)33 inset}
.ag-agent-card.on:before{content:'';position:absolute;left:0;top:0;bottom:0;
  width:3px;background:linear-gradient(180deg,var(--ok),var(--ok))}
.ag-agent-card.off{opacity:.5}
.ag-agent-card.off:hover{opacity:.75}
.ag-agent-top{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.ag-agent-ico{width:26px;height:26px;border-radius:7px;flex-shrink:0;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:10px;color:#fff;
  font-weight:600}
.ag-agent-card.on .ag-agent-ico{background:linear-gradient(135deg,var(--ok),#2a9d5c)}
.ag-agent-name{font-size:12px;font-weight:600;color:var(--tx-0)}
.ag-agent-badge{font-size:8.5px;padding:2px 6px;border-radius:4px;
  background:var(--ok)26;border:1px solid var(--ok)55;color:var(--ok);
  margin-left:auto}
.ag-agent-why{font-size:10px;color:var(--tx-2);line-height:1.6;margin-bottom:6px;
  min-height:28px}
.ag-agent-stat{font-size:10px;color:var(--tx-2)}
.ag-ok{color:var(--ok)}.ag-dim{color:var(--tx-3)}
.ag-agent-dl{font-size:9.5px;color:var(--ac);margin-top:5px;
  text-decoration:underline}
.ag-agent-divider{grid-column:1/-1;font-size:10px;color:var(--tx-3);
  padding:9px 0 3px;border-bottom:1px solid var(--bg-3);margin-bottom:2px}

/* ---- 模型列表 ---- */
.ag-models{}
.ag-mtop{display:flex;align-items:center;gap:10px;background:var(--bg-2);
  border:1px solid var(--line);border-radius:9px;padding:10px 13px;
  margin-bottom:10px}
.ag-mmeta{font-size:9.5px;color:var(--tx-2);line-height:1.8}
.ag-mctl{margin-left:auto;display:flex;gap:6px;flex-wrap:wrap}
.ag-chips{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:11px}
.ag-chip{background:var(--bg-2);border:1px solid var(--line);border-radius:12px;
  color:var(--tx-2);font-size:9.5px;padding:3px 9px;cursor:pointer;
  font-family:inherit;transition:.15s}
.ag-chip:hover{background:var(--ac)1a;border-color:var(--ac)55;color:var(--ac)}
.ag-chip.ghost{opacity:.42}
.ag-chip-dim{opacity:.45;margin-left:3px}
.ag-mlist{max-height:calc(100vh - 380px);overflow-y:auto;padding-right:3px}
.ag-mgroup{margin-bottom:12px}
.ag-mghead{font-size:9.5px;color:var(--tx-3);font-family:var(--mono);
  margin-bottom:5px;letter-spacing:.3px}
.ag-mgcnt{opacity:.55;margin-left:5px}
.ag-mrow{display:flex;align-items:center;gap:7px;padding:5px 9px;
  background:var(--bg-2);border:1px solid var(--bg-3);border-radius:6px;
  margin-bottom:3px;transition:.12s}
.ag-mrow:hover{border-color:var(--line);background:var(--bg-3)}
.ag-mname{font-size:10px;color:var(--tx-1);font-family:var(--mono);flex:1;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ag-mtags{display:flex;gap:3px;flex-shrink:0}
.ag-tag{font-size:8px;padding:1px 5px;border-radius:3px;font-style:normal}
.ag-tag.dsh{background:var(--ok)26;color:var(--ok)}
.ag-tag.gw{background:var(--purple)26;color:var(--purple)}
.ag-tag.v{background:var(--ac)26;color:var(--ac)}
.ag-mstat{font-size:9px;flex-shrink:0;max-width:100px;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-mstat.ok{color:var(--ok)}.ag-mstat.bad{color:var(--danger)}
.ag-mbtn{background:var(--bg-3);border:1px solid var(--line);border-radius:4px;
  color:var(--tx-2);font-size:9px;padding:2px 7px;cursor:pointer;
  font-family:inherit;flex-shrink:0}
.ag-mbtn:hover{background:var(--line);color:var(--tx-1)}
.ag-mhidden{font-size:9px;color:var(--tx-3);padding:4px 0 0 9px}

/* ---- 模型下拉 ---- */
.ag-modelsel{position:relative;display:flex;align-items:center;gap:5px;
  background:var(--bg-3);border:1px solid var(--line);border-radius:6px;
  padding:4px 9px;cursor:pointer;font-size:10px;max-width:220px}
.ag-modelsel:hover{border-color:var(--ac-line)}
.ag-sel-cur{color:var(--tx-1);font-family:var(--mono);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-sel-arr{color:var(--tx-3);font-size:8px;flex-shrink:0}
.ag-sel-pop{display:none;position:absolute;top:calc(100% + 4px);right:0;
  width:340px;max-height:320px;overflow-y:auto;background:var(--bg-2);
  border:1px solid var(--line);border-radius:8px;padding:5px;
  box-shadow:var(--sh-3);z-index:200}
.ag-sel-pop.open{display:block}
.ag-sel-row{display:flex;align-items:center;gap:6px;padding:5px 8px;
  border-radius:5px;cursor:pointer;font-size:10px}
.ag-sel-row:hover{background:var(--ac-dim)}
.ag-sel-row.on{background:var(--ac-dim);color:var(--ac)}
.ag-sel-nm{font-family:var(--mono);color:var(--tx-1);flex:1;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ---- 上传 ---- */
.ag-uploadb{width:24px;height:24px;border-radius:6px;background:var(--bg-3);
  border:1px solid var(--line);color:var(--tx-2);cursor:pointer;
  font-size:13px;line-height:1;flex-shrink:0;padding:0}
.ag-uploadb:hover{background:var(--ac-dim);border-color:var(--ac-line);
  color:var(--ac)}
.ag-attbar{display:none;flex-wrap:wrap;gap:6px;padding:0 0 7px}
.ag-att{display:flex;align-items:center;gap:6px;background:var(--bg-2);
  border:1px solid var(--line);border-radius:7px;padding:4px 7px;
  font-size:9.5px;max-width:230px}
.ag-att.img{border-color:var(--ac-line)}
.ag-att img{width:26px;height:26px;object-fit:cover;border-radius:4px}
.ag-att-ico{font-size:13px}
.ag-att-nm{color:var(--tx-1);overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap;max-width:130px}
.ag-att-sz{color:var(--tx-3);flex-shrink:0}
.ag-att-x{color:var(--tx-3);cursor:pointer;padding:0 3px;flex-shrink:0;
  font-size:11px}
.ag-att-x:hover{color:var(--danger)}
.ag-att-row{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;
  padding-top:6px;border-top:1px solid var(--ac-line)}
.ag-att-chip{font-size:9px;background:var(--ac-dim);color:var(--ac);
  border-radius:4px;padding:2px 6px}
`;
