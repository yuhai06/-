# -*- coding: utf-8 -*-
"""Agent 接入 API：检测 / 连接 / 模型清单 / 开关 / 可用性实测。"""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

log = logging.getLogger("yuhai.api.agent")
router = APIRouter()


# ---------------- 检测 ----------------
@router.get("/agent/detect")
async def agent_detect(deep: bool = False):
    """检测本机 Agent。deep=true 才做多盘一级扫描。"""
    from app.services import agent_detect as ad
    r = await asyncio.to_thread(ad.detect_all)
    if deep:
        d = await asyncio.to_thread(ad.deep_scan)
        r["deep"] = d
    return r


@router.post("/agent/deep-scan")
async def agent_deep_scan():
    """深度扫描（用户主动点，会慢）。"""
    from app.services import agent_detect as ad
    return await asyncio.to_thread(ad.deep_scan)


# ---------------- 连接 ----------------
class ConnectReq(BaseModel):
    agentId: str


@router.post("/agent/connect")
async def agent_connect(req: ConnectReq):
    """接入某个 agent（之后只显示它的模型）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.connect, req.agentId)


@router.get("/agent/overview")
async def agent_overview():
    """首屏：当前接入 + 模型清单 + 可切换列表。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.overview)


# ---------------- 模型开关 ----------------
class HideReq(BaseModel):
    agentId: str
    modelId: str
    hidden: bool = True


@router.post("/agent/model/hide")
async def agent_hide(req: HideReq):
    """隐藏/显示单个模型。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.set_hidden, req.agentId,
                                   req.modelId, req.hidden)


class HideChannelReq(BaseModel):
    agentId: str
    channel: str
    hidden: bool = True


# ---------------- 附件上传 ----------------
UPLOAD_DIR = None


def _upload_dir():
    global UPLOAD_DIR
    if UPLOAD_DIR is None:
        from app import paths
        UPLOAD_DIR = paths.DATA_DIR / "agent_uploads"
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    return UPLOAD_DIR


@router.post("/agent/upload")
async def agent_upload(file: UploadFile = File(...)):
    """上传文件/图片给对话用。返回路径，前端把它放进 attachments。

    图片存成 base64 data URI 供视觉模型直接读；
    其他文件存盘，只给模型路径和内容摘要。
    """
    import base64
    import time as _t
    from pathlib import Path as _P

    d = _upload_dir()
    name = file.filename or "upload.bin"
    safe = "".join(c for c in name if c.isalnum() or c in "._-")[:80]
    dst = d / ("%d_%s" % (_t.time(), safe or "upload.bin"))

    raw = await file.read()
    if len(raw) > 60 * 1048576:
        raise HTTPException(413, "文件超过 60MB")
    dst.write_bytes(raw)

    ext = _P(safe).suffix.lower()
    is_img = ext in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
    out = {
        "ok": True,
        "name": name,
        "path": str(dst),
        "sizeMb": round(len(raw) / 1048576, 2),
        "kind": "image" if is_img else "file",
    }
    if is_img and len(raw) < 6 * 1048576:
        mime = { ".png": "image/png", ".jpg": "image/jpeg",
                 ".jpeg": "image/jpeg", ".webp": "image/webp",
                 ".gif": "image/gif", ".bmp": "image/bmp" }.get(ext,
                 "image/png")
        out["dataUri"] = "data:%s;base64,%s" % (
            mime, base64.b64encode(raw).decode())
    else:
        # 文本类抽前 3000 字给模型看
        if ext in (".txt", ".md", ".json", ".csv", ".log", ".py",
                   ".js", ".ts", ".html", ".css", ".yaml", ".yml"):
            try:
                out["preview"] = raw.decode("utf-8", "ignore")[:3000]
            except Exception:
                pass
    return out


class SelectModelReq(BaseModel):
    agentId: str
    modelId: str = ""


@router.post("/agent/model/select")
async def agent_select_model(req: SelectModelReq):
    """切换对话用哪个模型（modelId 留空 = 恢复配置默认）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.set_active_model, req.agentId,
                                   req.modelId)


@router.post("/agent/model/hide-channel")
async def agent_hide_channel(req: HideChannelReq):
    """按渠道批量隐藏（如 our-free-model 一次全隐）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.hide_channel, req.agentId,
                                   req.channel, req.hidden)


# ---------------- 可用性实测 ----------------
class TestReq(BaseModel):
    agentId: str
    modelId: str


@router.post("/agent/model/test")
async def agent_test(req: TestReq):
    """实测一个模型能不能用（真发一次请求）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_one, req.agentId, req.modelId)


class TestAllReq(BaseModel):
    agentId: str
    limit: int = 0
    autoHide: bool = False     # 测完自动隐藏失败的


@router.post("/agent/model/test-all")
async def agent_test_all(req: TestAllReq):
    """批量实测（顺序跑，慢）。autoHide=True 时测完自动隐藏失败的。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_all, req.agentId, req.limit,
                                   req.autoHide)


# ---------------- 记忆 ----------------
@router.get("/agent/memory")
async def agent_memory_list():
    """Agent 跨会话记忆（读）。"""
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.list_all)


class MemSetReq(BaseModel):
    key: str
    value: str


@router.post("/agent/memory")
async def agent_memory_set(req: MemSetReq):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.set, req.key, req.value)


@router.delete("/agent/memory/{key}")
async def agent_memory_del(key: str):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.delete, key)


# ---------------- 对话（用 Agent 自己的模型） ----------------
class ChatReq(BaseModel):
    message: str
    history: list = []
    autoRunTools: bool = True
    attachments: list = []   # [{name, kind, path, sizeMb}]


@router.post("/agent/chat")
async def agent_chat(req: ChatReq):
    """用当前接入 Agent 的模型对话，可调用工具操作工作台。

    attachments: [{name, kind, path, sizeMb}] —— 文件/图片会拼进提示词。
    """
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.chat, req.message, req.history,
                                   req.autoRunTools, req.attachments)


@router.get("/agent/chat/test")
async def agent_chat_test():
    """自检：当前 agent 的模型能不能对话。"""
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.quick_test)


@router.get("/agent/tools")
async def agent_tools():
    """MCP 工具清单（给前端展示 + 供外部 agent 参考）。"""
    from app.services import agent_chat as ac
    specs = await asyncio.to_thread(ac.tool_specs)
    return {"ok": True, "count": len(specs),
            "items": [{"name": s["function"]["name"],
                       "description": s["function"]["description"]}
                      for s in specs]}


# ---------------- MCP 接入信息 ----------------
@router.get("/agent/mcp")
async def agent_mcp():
    """MCP 服务地址 + 外部 Agent 接入配置示例。"""
    import os
    from app.config import settings
    from app.mcp_server import mcp as M
    port = int(os.environ.get("YUHAI_PORT", settings.port))
    tools = await M.list_tools()
    return {
        "ok": True,
        "url": f"http://127.0.0.1:{port}/mcp/",
        "transport": "streamable-http",
        "count": len(tools),
        "tools": [{"name": t.name, "description": t.description}
                  for t in tools],
        "config_example": {
            "mcpServers": {
                "yuhai": {
                    "url": f"http://127.0.0.1:{port}/mcp/",
                    "transport": "streamable-http",
                }
            }
        },
    }
