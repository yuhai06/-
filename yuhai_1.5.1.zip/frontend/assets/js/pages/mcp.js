/* mcp.js — MCP 接入页：把雨海的 116 个工具暴露给外部 Agent
 *
 * 这个页面不做业务，只做三件事：
 *   ① 显示 MCP 地址，可直接复制
 *   ② 给出各家 Agent 的现成配置（Claude Code / Cursor / DSH / 通用）
 *   ③ 列出全部工具，方便写提示词
 */
import { api } from '../api.js';
import { toast, copyText, pageHead, $, $$ } from '../ui.js';

let state = {
  info: null,
  loading: false,
  filter: '',
  cat: 'all',
};

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: 'MCP 接入',
      desc: '把工作台的工具交给外部 Agent 操作',
      actions: [`<button class="btn sm" data-act="reload"><span data-icon="refresh"></span>刷新</button>`],
    })}
    <div id="mcp-body"></div>
  `;
  $$('[data-act="reload"]', root).forEach((b) => (b.onclick = () => load(root, true)));
  paint(root);
  load(root);
}

async function load(root, force = false) {
  if (state.loading) return;
  state.loading = true;
  try {
    const r = await api.mcpInfo();
    state.info = r;
    paint(root);
  } catch (e) {
    toast('读取失败', e.message, 'err');
  } finally {
    state.loading = false;
  }
}

function paint(root) {
  const box = $('#mcp-body', root);
  if (!box) return;

  if (!state.info) {
    box.innerHTML = '<div class="card"><div class="card-body muted">读取中…</div></div>';
    return;
  }

  const info = state.info;
  if (!info.ok) {
    box.innerHTML = `<div class="card"><div class="card-body">
      <div style="color:var(--danger)">MCP 服务未就绪：${esc(info.error || '')}</div>
    </div></div>`;
    return;
  }

  const tools = info.tools || [];
  const cats = {};
  for (const t of tools) {
    const p = (t.name || '').split('_')[0] || 'other';
    cats[p] = (cats[p] || 0) + 1;
  }
  const catList = Object.entries(cats).sort((a, b) => b[1] - a[1]);

  // 按类别过滤
  let shown = tools;
  if (state.cat !== 'all') {
    shown = tools.filter((t) => (t.name || '').startsWith(state.cat + '_'));
  }
  if (state.filter) {
    const q = state.filter.toLowerCase();
    shown = shown.filter(
      (t) => (t.name || '').toLowerCase().includes(q)
        || (t.description || '').toLowerCase().includes(q));
  }

  box.innerHTML = `
    <div class="card">
      <div class="card-head"><div class="card-title">MCP 服务地址</div></div>
      <div class="card-body">
        <div class="kv">
          <span class="k">状态</span>
          <span class="v"><b style="color:var(--ok)">● 运行中</b></span>
        </div>
        <div class="kv">
          <span class="k">地址</span>
          <span class="v" style="font-family:var(--mono);font-size:11px">${esc(info.url)}</span>
        </div>
        <div class="kv">
          <span class="k">传输方式</span>
          <span class="v">${esc(info.transport)}</span>
        </div>
        <div class="kv">
          <span class="k">工具数</span>
          <span class="v"><b>${info.count}</b> 个</span>
        </div>
        <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn sm primary" data-copy="url">复制地址</button>
          <button class="btn sm" data-copy="json">复制通用配置</button>
          <button class="btn sm" data-copy="claude">Claude Code 命令</button>
          <button class="btn sm" data-copy="dsh">DSH 命令行</button>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">接入配置（直接复制粘贴）</div></div>
      <div class="card-body">
        <p class="hint">把下面任意一段贴到对应 Agent 的配置文件里，它就有这 ${info.count} 个工具了。</p>

        <div style="margin-top:12px">
          <div style="font-size:11px;font-weight:600;margin-bottom:5px">
            Claude Code（命令行一条）
          </div>
          <pre class="code-block" id="cfg-claude">claude mcp add yuhai --transport http ${esc(info.url)}</pre>
        </div>

        <div style="margin-top:12px">
          <div style="font-size:11px;font-weight:600;margin-bottom:5px">
            Cursor / Cline / 任意 MCP 客户端（JSON）
          </div>
          <pre class="code-block" id="cfg-json">${esc(JSON.stringify(info.config_example, null, 2))}</pre>
        </div>

        <div style="margin-top:12px">
          <div style="font-size:11px;font-weight:600;margin-bottom:5px">
            DSH（命令行直接执行任务）
          </div>
          <pre class="code-block" id="cfg-dsh">set DEEPSEEK_API_KEY=你的key
dsh --profile headless --approval-policy never "从剧库找3部百合剧，下载切片，发到Y03"</pre>
        </div>

        <div style="margin-top:12px">
          <div style="font-size:11px;font-weight:600;margin-bottom:5px">
            推荐提示词模板（贴给外部 Agent）
          </div>
          <pre class="code-block" id="cfg-prompt">${esc(promptTemplate(info.count))}</pre>
          <button class="btn sm" data-copy="prompt" style="margin-top:6px">复制提示词</button>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-title">工具清单（${info.count} 个）</div>
      </div>
      <div class="card-body">
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
          <button class="btn xs ${state.cat === 'all' ? 'primary' : 'ghost'}"
            data-cat="all">全部 ${tools.length}</button>
          ${catList.map(([c, n]) => `
            <button class="btn xs ${state.cat === c ? 'primary' : 'ghost'}"
              data-cat="${esc(c)}">${esc(c)} ${n}</button>`).join('')}
        </div>
        <input class="input" id="mcp-filter" placeholder="搜索工具名或说明…"
          value="${esc(state.filter)}"
          style="width:100%;margin-bottom:10px" />
        <div id="mcp-tool-list" style="max-height:520px;overflow-y:auto">
          ${shown.length ? shown.map((t) => `
            <div class="tool-row">
              <div class="tool-name">${esc(t.name)}</div>
              <div class="tool-desc">${esc((t.description || '').slice(0, 160))}</div>
            </div>`).join('') : '<div class="muted" style="padding:12px">没有匹配的工具</div>'}
        </div>
        <div class="muted" style="font-size:10px;margin-top:8px">
          显示 ${shown.length} / ${tools.length} 个
        </div>
      </div>
    </div>
  `;

  // 复制按钮
  $$('[data-copy]', box).forEach((b) => {
    b.onclick = () => {
      const k = b.dataset.copy;
      let txt = '';
      if (k === 'url') txt = info.url;
      else if (k === 'json') txt = JSON.stringify(info.config_example, null, 2);
      else if (k === 'claude') txt = `claude mcp add yuhai --transport http ${info.url}`;
      else if (k === 'dsh') txt = `dsh --profile headless --approval-policy never "你的任务"`;
      else if (k === 'prompt') txt = promptTemplate(info.count);
      copyText(txt);
      toast('已复制', k === 'url' ? info.url : '内容已复制到剪贴板', 'ok');
    };
  });

  // 类别切换
  $$('[data-cat]', box).forEach((b) => {
    b.onclick = () => {
      state.cat = b.dataset.cat;
      paint(root);
    };
  });

  // 搜索
  const inp = $('#mcp-filter', box);
  if (inp) {
    let timer = null;
    inp.oninput = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.filter = inp.value.trim();
        paint(root);
        const el = $('#mcp-filter', root);
        if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
      }, 250);
    };
  }
}

function promptTemplate(count) {
  return `你是雨海工作台的运营助手，通过 MCP 调用工作台的 ${count} 个工具完成任务。

【工具全景（按类）】
slice_*    切片：slice_list_dramas / slice_run / slice_status / slice_result / slice_env_check
dl_*       下载：dl_tk_eps（TK剧集按id下）/ dl_search / dl_sd_meta / dl_sd_batch / dl_ledger_list / dl_ledger_of
drama_*    剧型：drama_find（按关系或题材筛）/ drama_stats / drama_genre_check / drama_types
publish_*  发布：publish_reels / publish_pages / publish_history / publish_run
page_*     主页：page_list / page_create / page_update / page_extract / page_skip_publish
account_*  账号：account_list / account_create / account_quota / account_update
env_*      环境：env_list / env_start / env_stop / env_sync / env_test_proxy
task_*     任务清单：task_create / task_done / task_status / task_clear
fs_*       文件：fs_read / fs_write / fs_list / fs_find / fs_grep / fs_table / fs_read_chunk / fs_disks / fs_stat
library_*  素材库：library_list / library_scan / library_qc
video_*    视频处理：video_clip / video_concat / video_make / video_vertical / video_speed / video_normalize / video_burn_subs / video_probe
schedule_* 排期：schedule_list / schedule_queue / schedule_capacity
data_*     数据：data_collect / data_overview / data_page_fit
mail_*     邮箱：mail_inbox / mail_latest / mail_latest_code / mail_pull / mail_channels
authz_*    授权：authz_grant / authz_grant_multi / authz_verify / authz_matrix
memory_*   记忆：memory_set / memory_get / memory_list
system_*   系统：system_health / system_logs / system_guard / system_failures

【剧库怎么查】
剧库表：C:\Users\m1989\Desktop\tkid.txt（TSV，15列，约1300部）
  [2]collection_id（TK剧集id）  [6]剧集名称  [8]内容主题标签
用 fs_table 或 fs_grep 读，不要 fs_read 硬读。

已扫好官方题材标签的剧：用 drama_find() 秒查，支持：
  drama_find(rel="GL")            → 百合
  drama_find(rel="BG")            → 男女
  drama_find(rel="BG", genre="Werewolf")        → 狼人
  drama_find(genre="Family Feud")               → 家庭争斗
  drama_find(genre="Revenge")                   → 复仇
  drama_find(genre="Romantic Complications")    → 情感纠葛
  drama_find(genre="Vampire")                   → 吸血鬼
  drama_find(genre="Fantasy")                   → 玄幻
  drama_find(genre="Royal Palace")              → 宫廷
  drama_find(genre="Sismance")                  → 姊妹情
  limit= 控制返回数量

常用题材数量参考：Family Feud 492 / Romantic Complications 293 / Revenge 260 /
  Werewolf 94 / Fantasy 96 / Royal Palace 26 / Vampire 8 / Sismance 8 / GL 8
全部标签用 drama_stats() 看。

【标准流程（按任务需要选，不必全做）】
① 找剧     drama_find(rel=..., genre=..., limit=N)
② 查台账   dl_ledger_of(tkId="...")  看哪些集下过了
③ 下载     dl_tk_eps(tkId="...", eps=[1,2,3,4,5,6])  自动跳过已下的
④ 切片     slice_run(drama="剧名_tkId", mode="auto")  必须 auto
⑤ 确认     slice_result(drama="...") 或 library_list()
⑥ 查容量   schedule_capacity()
⑦ 发布     publish_reels(pageIds=[...], ...) 或 publish_run(...)

【通用规矩】
1. 接到多步骤任务，第一步先 task_create 建清单；每完成一项 task_done 打勾
2. 系统会检查清单：有未打勾的项不允许结束，会提示你继续
3. 切片必须 mode="auto"（会自动补转录/语音/张力/出片）
4. 下载前先 dl_ledger_of，别重复下载（台账记录文件被删的集，默认跳过）
5. 发布前先 schedule_capacity 确认容量
6. 失败就记录原因继续下一步，不要卡住
7. 不确定可以问用户，但能自己查到的别问
8. 每完成一个阶段简短汇报（1-2 行）

【主页类型提示】
主页的题材适配不是固定的。除非用户明确说某主页只发某类型，
否则可以按题材相近度自由分配。用户指定了就以用户为准。`;
}
