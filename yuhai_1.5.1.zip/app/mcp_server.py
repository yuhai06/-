# -*- coding: utf-8 -*-
"""
mcp_server.py — 把工作台暴露成 MCP 服务，让外部 Agent 直接操作

设计（按 MCP 2.x 规范 + 2026-07-28 最佳实践）：
  ① stateless：状态不挂连接，长任务用 job_id handle
  ② 工具名 snake_case，1-128 字符
  ③ inputSchema 用 JSON Schema
  ④ 失败返回 isError + 可操作消息
  ⑤ 工具列表静态，不随连接变化

挂载方式（main.py）：
    from app.mcp_server import mcp
    app.mount("/mcp", mcp.streamable_http_app())

外部 agent 连接：
    {"mcpServers": {"yuhai": {"url": "http://127.0.0.1:PORT/mcp",
                              "transport": "streamable-http"}}}
"""
from __future__ import annotations

import json
import logging
import os

from mcp.server.mcpserver import MCPServer
import time

log = logging.getLogger("yuhai.mcp")

mcp = MCPServer(
    name="yuhai-workbench",
    title="雨海工作台",
    description="短剧运营工作台：抓取、切片、发布、数据分析",
    instructions=(
        "这是短剧运营工作台。常用流程：\n"
        "1. slice_env_check 先看环境是否就绪\n"
        "2. slice_list_dramas 看有哪些剧可切\n"
        "3. slice_run 开始切片（返回 job_id）\n"
        "4. slice_status(job_id) 查进度\n"
        "5. slice_result 拿成片列表\n"
        "\n"
        "【短剧下载（推荐）】多站点下载：\n"
        "  dl_sites 看有哪些站点 →\n"
        "  dl_search(site, keyword) 搜剧拿 slug →\n"
        "  dl_check(site, slug) 看详情和 freeEps 免费集 →\n"
        "  dl_download_eps(site, slug, eps) 下载拿 task_id →\n"
        "  dl_task(task_id) 查进度 →\n"
        "  dl_library 列已下载 → dl_send_to_slice(site, dir) 送去切片\n"
        "  站点：pinedrama / dramabox / moboreels / goodshort / tiktok / tiktok_drama\n"
        "  TikTok：dl_tiktok_meta(id) 查信息，dl_tiktok_download(id) 下载\n"
        "\n"
        "【TK短剧（TikTok 内的短剧板块）】\n"
        "  ID 来自地址 tiktok.com/shortdrama/episode/<ID>/1\n"
        "  dl_sd_meta(id) 查详情 → dl_sd_batch([id1,id2,...]) 批量查\n"
        "  dl_sd_history() 看查过哪些（避免重复）\n"
        "  dl_sd_browser('start'|'stop'|'status'|'login') 管调试浏览器\n"
        "\n"
        "  ⚠ 下载前提：必须在 Chrome 里登录 TikTok，否则接口不下发 playAddr。\n"
        "    先调 dl_sd_login() 确认 loggedIn=true，再下载。\n"
        "    没登录就 dl_sd_browser(action='login') 开窗，让用户手动登录。\n"
        "\n"
        "  ⚠ 下载要用剧自己的 ID，不是自己猜的：\n"
        "    dl_check(site='tiktok_drama', slug=<剧ID>) 看 total 和免费集\n"
        "    dl_download_eps(site='tiktok_drama', slug=<剧ID>, eps=[1,2,3])\n"
        "    然后 dl_task_detail(task_id) 逐集确认 state/duration，\n"
        "    不要只看 ok 计数 —— 时长和接口声明差太多就是下错了。\n"
        "\n"
        "⚠ 下载/抓取只用 dl_* 系列。旧版 grab_* 已停用，不要调用。\n"
        "发布：publish_reels 发到 Facebook Reels\n"
        "记忆：memory_set / memory_get 记住跨会话状态"
    ),
    version="1.0.0",
)


def _ok(**kw):
    return {"ok": True, **kw}


def _err(msg: str, **kw):
    return {"ok": False, "error": msg, **kw}


# ═══════════════════════════════════════════════
#  切片
# ═══════════════════════════════════════════════
@mcp.tool(description="环境自检：Python包/FFmpeg/ASR模型/脚本/GPU/代理")
def slice_env_check() -> dict:
    from app.services import envcheck
    r = envcheck.full_check()
    return _ok(
        ready=r["ok"],
        python_ok=all(p["ok"] for p in r["python"] if p["required"]),
        ffmpeg=r["ffmpeg"]["ok"],
        nvenc=r["ffmpeg"].get("nvenc"),
        model={"ok": r["model"]["ok"], "name": r["model"]["name"],
               "sizeMb": r["model"].get("sizeMb")},
        tools={"ok": r["tools"]["ok"],
               "stale": len(r["tools"].get("stale") or [])},
        gpu={"name": r["gpu"].get("name"), "cuda": r["gpu"].get("cuda")},
        warnings=r["warnings"],
        fixable=[f["what"] for f in (r.get("fixable") or [])],
    )


@mcp.tool(description="修环境。what: all|python|ffmpeg|whisper|tools|cuda")
def slice_env_install(what: str = "all") -> dict:
    from app.services import envcheck
    r = envcheck.install_one(what)
    return _ok(what=what, ok=r.get("ok"),
               note=r.get("note") or r.get("error") or "")


@mcp.tool(description="列出所有短剧及处理状态（哪些能切、切到哪一步）")
def slice_list_dramas() -> dict:
    from app.services import slicing as sl
    items = sl.list_dramas()
    out = []
    for d in items:
        st = d.get("steps") or {}
        out.append({
            "drama": d["drama"],
            "title": d.get("title"),
            "sourceEpisodes": d.get("sourceEpisodes") or 0,
            "hasSource": d.get("hasSource"),
            "state": d.get("state"),
            "transcribed": bool((st.get("transcribe") or {}).get("done")),
            "segments": (st.get("transcribe") or {}).get("segments") or 0,
            "type": (st.get("classify") or {}).get("typeName") or "",
            "tensionSegs": (st.get("tension") or {}).get("segments") or 0,
            "singles": (st.get("single") or {}).get("count") or 0,
            "premiums": (st.get("premium") or {}).get("count") or 0,
        })
    return _ok(count=len(out), items=out)


@mcp.tool(description=(
    "开始切片。mode: auto（智能，自动补齐前置步骤，推荐）|"
    "full（完整流水线）|transcribe|voice|classify|tension|"
    "single|premium|all。返回 job_id，用 slice_status 查进度"))
def slice_run(drama: str, mode: str = "auto", eps: str = "",
              target: int = 45, model: str = "small") -> dict:
    from app.services import slicing as sl
    import uuid
    job_id = "mcp-" + uuid.uuid4().hex[:10]
    eps_list = [e.strip() for e in eps.split(",") if e.strip()] if eps else None

    try:
        # ── auto：检查缺哪步就补哪步 ──
        if mode == "auto":
            _st = sl.drama_status(drama)
            st = _st.get("steps") or _st      # 状态在 steps 里
            result = {}
            ran = []

            if not (st.get("transcribe") or {}).get("done"):
                result["transcribe"] = sl.step_transcribe(job_id, drama, model=model)
                ran.append("转录")
            if not (st.get("voice") or {}).get("done"):
                result["voice"] = sl.step_voice(job_id, drama)
                ran.append("语音")
            if not (st.get("classify") or {}).get("done"):
                cr = sl.step_classify(job_id, drama)
                result["classify"] = cr
                # 类型判定失败不阻塞出片（台词太少/小语种都会失败）
                ran.append("分类" if cr.get("ok") else "分类(跳过-不影响出片)")
            if not (st.get("tension") or {}).get("done"):
                result["tension"] = sl.step_tension(job_id, drama)
                ran.append("张力")

            result["single"] = sl.step_single(job_id, drama, eps_list, target)
            result["premium"] = sl.step_premium(job_id, drama)
            ran += ["单集", "精品"]

            return _ok(job_id=job_id, drama=drama, mode="auto",
                       stepsRun=ran, result=result,
                       hint="用 slice_status 查详情，slice_result 看成片")

        # ── 单步 ──
        if mode == "transcribe":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_transcribe(job_id, drama, model=model))
        if mode == "voice":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_voice(job_id, drama))
        if mode == "classify":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_classify(job_id, drama))
        if mode == "tension":
            return _ok(job_id=job_id, drama=drama,
                       result=sl.step_tension(job_id, drama))

        # ── full：硬跑全流程 ──
        if mode == "full":
            result = {}
            result["transcribe"] = sl.step_transcribe(job_id, drama, model=model)
            result["voice"] = sl.step_voice(job_id, drama)
            result["classify"] = sl.step_classify(job_id, drama)
            result["tension"] = sl.step_tension(job_id, drama)
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
            result["premium"] = sl.step_premium(job_id, drama)
            return _ok(job_id=job_id, drama=drama, mode="full", result=result)

        # ── 出片（要求已有台词本，缺了明确报错）──
        result = {}
        if mode in ("single", "all"):
            tr = sl.read_transcript(drama)
            if not tr:
                return _err(
                    "缺少台词本，无法出片。请用 mode='auto' 自动补转录，"
                    "或先调 slice_run(mode='transcribe')",
                    drama=drama, missing="transcript")
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
        if mode in ("premium", "all"):
            result["premium"] = sl.step_premium(job_id, drama)
        return _ok(job_id=job_id, drama=drama, mode=mode, result=result,
                   hint=f"用 slice_status('{job_id}') 查详情")
    except Exception as e:
        import traceback
        return _err(f"切片失败: {str(e)[:200]}", drama=drama,
                    trace=traceback.format_exc()[-400:])


@mcp.tool(description="查 job 进度")
def slice_status(job_id: str) -> dict:
    from app.db import db
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        return _err(f"没有这个 job: {job_id}", available_hint="用 slice_run 创建")
    return _ok(
        id=r["id"], kind=r.get("kind"), status=r.get("status"),
        progress=r.get("progress"),
        steps=json.loads(r.get("steps") or "[]"),
        result=json.loads(r.get("result") or "{}") if r.get("result") else {},
        error=r.get("error") or "",
    )


@mcp.tool(description="列出成片（单集/精品）")
def slice_result(drama: str = "") -> dict:
    from app import paths
    out = []
    for pat in ("单集_*", "精品混剪_*"):
        for d in paths.output_root().glob(pat):
            if not d.is_dir():
                continue
            for sub in d.iterdir():
                if not sub.is_dir():
                    continue
                if drama and drama.lower() not in sub.name.lower():
                    continue
                vids = [f for f in sub.glob("*.mp4")]
                if not vids:
                    continue
                out.append({
                    "kind": "single" if "单集" in pat else "premium",
                    "drama": sub.name,
                    "date": d.name.split("_")[-1],
                    "count": len(vids),
                    "files": [{"name": f.name,
                               "mb": round(f.stat().st_size / 1048576, 1)}
                              for f in vids[:20]],
                })
    return _ok(count=len(out), items=out)


@mcp.tool(description="校验成片：台词完整/无重叠/无静音")
def slice_verify(video_path: str) -> dict:
    from app.services import slicing as sl
    try:
        return _ok(**sl.verify_output(video_path))
    except Exception as e:
        return _err(f"校验失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  旧版抓取工具（已停用）
# ═══════════════════════════════════════════════
# 这两条工具已从 MCP 隐藏，避免 Agent 误用旧的 PineDrama 抓取链路。
# 替代方案：dl_sites → dl_search → dl_check → dl_download_eps
#
# 如需临时恢复（调试用）：
#     set YUHAI_ENABLE_LEGACY_GRAB=1
# 恢复后 grab_search / grab_download 会重新出现在工具列表里。
# 默认开启：用户要求把全部功能暴露给 agent，不再隐藏任何工具。
# 想临时关闭：set YUHAI_ENABLE_LEGACY_GRAB=0
_LEGACY_GRAB = os.getenv("YUHAI_ENABLE_LEGACY_GRAB", "1").strip() not in (
    "0", "false", "no", "")

if _LEGACY_GRAB:
    @mcp.tool(description="[旧版] 搜剧（PineDrama），返回剧名/集数/cid。"
                          "新流程请用 dl_search")
    def grab_search(keyword: str, limit: int = 15) -> dict:
        from app.legacy.services import grab as g
        try:
            r = g.search(keyword) if hasattr(g, "search") else {}
            if not r:
                r = g.hot_list() if hasattr(g, "hot_list") else {}
            items = (r.get("items") or r.get("collections") or [])[:limit]
            return _ok(keyword=keyword, count=len(items), items=items)
        except Exception as e:
            return _err(f"搜索失败: {str(e)[:100]}")

    @mcp.tool(description="[旧版] 下载剧集。cid 来自 grab_search；eps 如 '1-10'。"
                          "新流程请用 dl_download_eps")
    def grab_download(cid: str, eps: str = "1-10") -> dict:
        from app.legacy.services import grab as g
        try:
            r = g.download(cid, eps) if hasattr(g, "download") else {}
            return _ok(cid=cid, result=r)
        except Exception as e:
            return _err(f"下载失败: {str(e)[:100]}")
else:
    log.info("legacy grab MCP tools disabled (set YUHAI_ENABLE_LEGACY_GRAB=1 to enable)")


# ═══════════════════════════════════════════════
#  短剧下载（多站点）—— 与「短剧下载」页面同一套后端
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "列可用下载站点。返回 id（pinedrama/dramabox/moboreels/goodshort/"
    "tiktok/tiktok_drama）和名称"))
def dl_sites() -> dict:
    from app.services import dl
    try:
        items = [{"id": k, "name": v["name"]} for k, v in dl.SITES.items()]
        items.append({"id": "tiktok", "name": "TikTok"})
        items.append({"id": "tiktok_drama", "name": "TK短剧"})
        return _ok(count=len(items), items=items, root=str(dl.out_root()))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "在多站点里搜剧。site 见 dl_sites；keyword 为空则返回该站全部目录。"
    "返回 slug 列表（后续传给 dl_check / dl_download_eps）"))
def dl_search(site: str = "pinedrama", keyword: str = "", limit: int = 20) -> dict:
    from app.services import dl
    try:
        r = dl.search(site, keyword, limit)
        return _ok(site=site, keyword=keyword, total=r["total"], slugs=r["slugs"])
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "查一部剧的详情：剧名/总集数/免费集/封面/简介。"
    "site + slug（slug 来自 dl_search）。返回 freeEps 是可直接下载的集号"))
def dl_check(site: str, slug: str) -> dict:
    from app.services import dl
    try:
        # TK短剧走 sd_drama，其它走 fetch_meta
        if site == "tiktok_drama":
            m = dl.sd_drama(slug)
        elif site == "tiktok":
            vid = dl.tk_id_from(slug)
            m = dl.tk_meta(vid) if vid else {}
            if not m:
                return _err("没识别到 TikTok 作品 ID")
        else:
            m = dl.fetch_meta(site, slug)

        eps = m.get("eps") or []
        free = [e["ep"] for e in eps if e.get("free")]
        # TK短剧额外给出时长信息，方便判断片子长短
        durs = {}
        if site == "tiktok_drama":
            for e in eps:
                if e.get("duration"):
                    durs[str(e["ep"])] = int(e["duration"])
        return _ok(site=site, slug=slug, name=m.get("name"),
                   total=m.get("total"), freeEps=free,
                   freeCount=len(free), rating=m.get("rating"),
                   desc=(m.get("desc") or "")[:240],
                   cover=m.get("cover"), folder=m.get("folder") or "",
                   durations=durs or None,
                   degraded=bool(m.get("degraded")))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "按集下载。site + slug（来自 dl_search/dl_check）+ eps 列表如 [1,2,3]。"
    "返回 task_id，用 dl_task 查进度"))
def dl_download_eps(site: str, slug: str, eps: list[int] = [], lang: str = "en") -> dict:
    from app.services import dl, dlq
    try:
        eps = sorted({int(x) for x in eps if int(x) > 0})
        if not eps:
            return _err("eps 不能为空，例如 [1,2,3]")

        # 按站点取元数据
        if site == "tiktok_drama":
            m = dl.sd_drama(slug)
        else:
            m = dl.fetch_meta(site, slug)

        t = dlq.new_task(site, slug, m.get("name") or slug,
                         m.get("cover") or "", eps, lang)
        dlq.submit(t)
        return _ok(task_id=t["id"], site=site, slug=slug,
                   name=m.get("name"), count=len(eps),
                   hint=("TK短剧下载较慢，每集约 30-60 秒；"
                         "用 dl_task_detail(task_id) 逐集确认时长是否正确")
                        if site == "tiktok_drama" else None)
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "查下载任务进度。task_id 留空则返回全部任务。"
    "注意：顶层 ok 是「调用成功」，items[].ok 是「该任务成功的集数」，别搞混；"
    "要逐集看真实时长/大小请用 dl_task_detail"))
def dl_task(task_id: int = 0) -> dict:
    from app.services import dlq
    try:
        items = dlq.snapshot()
        if task_id:
            items = [x for x in items if x["id"] == int(task_id)]
            if not items:
                return _err(f"任务 {task_id} 不存在")
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="列本地已下载的短剧（含站点/集数/大小/目录）")
def dl_library() -> dict:
    from app.services import dl
    try:
        items = dl.scan_local()
        return _ok(series=len(items), files=sum(i["count"] for i in items),
                   bytes=sum(i["bytes"] for i in items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "把已下载的剧送去切片（硬链接到源素材根，切片页可直接选）。"
    "site + dir（dir 来自 dl_library）"))
def dl_send_to_slice(site: str, dir: str) -> dict:
    from app.services import dl
    try:
        r = dl.send_to_slice(site, dir)
        return _ok(**r)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "TikTok 作品元数据。id 可以是作品 ID 或整条链接。"
    "返回作者/播放/点赞/评论/分享/时长/直链数"))
def dl_tiktok_meta(id: str) -> dict:
    from app.services import dl
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID（需要 15–25 位数字）")
        m = dl.tk_meta(vid)
        return _ok(id=vid, author=(m.get("author") or {}).get("uniqueId"),
                   desc=(m.get("desc") or "")[:160],
                   duration=m.get("duration"), stats=m.get("stats"),
                   web_url=m.get("web_url"), cover=m.get("cover"))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="下载 TikTok 作品（走 yt-dlp）。id 为作品 ID 或链接，返回 task_id")
def dl_tiktok_download(id: str) -> dict:
    from app.services import dl, dlq
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID")
        m = dl.tk_meta(vid)
        t = dlq.new_task("tiktok", vid, (m.get("desc") or vid)[:60],
                         m.get("cover") or "", [1], "")
        t["web_url"] = m.get("web_url")
        dlq.submit(t)
        return _ok(task_id=t["id"], vid=vid, url=m.get("web_url"))
    except Exception as e:
        return _err(str(e)[:140])


# ═══════════════════════════════════════════════
#  TK短剧（shortdrama）—— 需要本机 Chrome 调试端口
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "查 TikTok 短剧详情。id 是 tiktok.com/shortdrama/episode/<ID>/1 里的 ID。"
    "返回剧名/总集数/观看量/分集数。浏览器没开会自动拉起（无头，不弹窗）"))
def dl_sd_meta(id: str) -> dict:
    from app.services import dl
    try:
        m = dl.sd_drama(id)
        return _ok(id=m.get("id"), name=m.get("name"), total=m.get("total"),
                   watched=m.get("watched"), eps=len(m.get("eps") or []),
                   author=(m.get("author") or {}).get("uniqueId"),
                   degraded=bool(m.get("degraded")),
                   cover=m.get("cover") or "")
    except Exception as e:
        return _err(str(e)[:300])


@mcp.tool(description=(
    "批量查 TikTok 短剧。ids 是 ID 列表（最多 50 个）。"
    "串行+节流避免风控；每部最多 90 秒，超时自动跳过不影响其它。"
    "大批量（>5 部）会先返回 jobId，后台继续跑，可用 dl_sd_batch_status 查进度"))
def dl_sd_batch(ids: list[str]) -> dict:
    from app.services import dl
    try:
        ids = [str(x).strip() for x in (ids or []) if str(x).strip()]
        if not ids:
            return _err("ids 不能为空")
        ids = ids[:50]

        # 少量（<=5）直接同步跑，结果立即返回
        if len(ids) <= 5:
            r = dl.sd_batch(ids, timeout_each=90.0)
            return _ok(total=r["total"], ok=r["ok"],
                       elapsed=r.get("elapsed"), items=r["items"])

        # 大批量：起后台线程，立即返回 jobId，避免 agent 长时间无响应
        import threading
        import uuid as _uuid
        job_id = "sdb-" + _uuid.uuid4().hex[:10]
        _SD_BATCH_JOBS[job_id] = {
            "jobId": job_id, "status": "running", "total": len(ids),
            "done": 0, "ok": 0, "items": [], "startedAt": time.time(),
        }

        def _bg():
            st = _SD_BATCH_JOBS[job_id]

            def _prog(i, total, did, result):
                st["done"] = i
                st["total"] = total
                st["items"].append(result)
                if result.get("ok"):
                    st["ok"] += 1

            try:
                r = dl.sd_batch(ids, timeout_each=90.0, on_progress=_prog)
                st["status"] = "done"
                st["ok"] = r.get("ok", st["ok"])
                st["elapsed"] = r.get("elapsed")
            except Exception as e:
                st["status"] = "failed"
                st["error"] = str(e)[:200]
            finally:
                st["endedAt"] = time.time()

        threading.Thread(target=_bg, daemon=True,
                         name="sdbatch-" + job_id).start()
        return _ok(
            jobId=job_id, total=len(ids), status="running",
            hint=("已在后台开始，共 %d 部，每部最多 90 秒。"
                  "用 dl_sd_batch_status(jobId) 查进度，"
                  "别重复提交同一批。" % len(ids)))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "判断短剧是不是百合(GL/女女)。传剧名+介绍文本，用当前模型判定。"
    "返回 isGL / confidence / reason。批量时传 items=[{name,desc}]，"
    "最多 30 条，一次调用搞定"))
def drama_gl_check(name: str = "", desc: str = "",
                   items: list[dict] = []) -> dict:
    """用模型判断剧集是否为百合(GL)。"""
    from app.services import agent_chat as ac

    def _judge_one(nm: str, ds: str) -> dict:
        prompt = (
            "判断下面这部短剧是不是百合(GL/女女恋爱)。\n\n"
            "剧名：%s\n介绍：%s\n\n"
            "判定规则：\n"
            "- GL：两个女性之间的恋爱关系是主线\n"
            "- BG：男女恋爱（哪怕女主戏份重、男性出场少，也是BG）\n"
            "- 注意：女主复仇/宅斗/真假千金/雌竞 都不是百合\n"
            "- 注意：只有一名女性主角、男性角色少，也不等于百合\n"
            "- 不确定就回答 unclear，不要猜\n\n"
            "只输出一行 JSON，不要解释：\n"
            '{"verdict":"GL|BG|unclear","confidence":0.0-1.0,'
            '"reason":"20字内依据"}'
            % (nm[:120], (ds or "")[:600])
        )
        try:
            pk = ac.pick_model()
            if not pk.get("ok"):
                return {"ok": False, "error": "无可用模型"}
            r = ac._post_chat(pk["endpoint"], pk["model"],
                              [{"role": "user", "content": prompt}],
                              None, pk.get("apiKey", ""))
            if not r.get("ok"):
                return {"ok": False, "error": str(r.get("error"))[:100]}
            rep = ac._parse_reply(r["data"], "11434" in pk["endpoint"])
            txt = (rep.get("content") or "").strip()
            # 抠 JSON
            import re as _re
            m = _re.search(r"\{.*\}", txt, _re.S)
            if m:
                try:
                    j = json.loads(m.group(0))
                    return {"ok": True, **j}
                except Exception:
                    pass
            return {"ok": True, "verdict": "unclear", "confidence": 0.0,
                    "reason": txt[:60]}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, str(e)[:80])}

    # 批量模式
    if items:
        out = []
        gl_list = []
        for it in items[:30]:
            nm = (it.get("name") or "").strip()
            ds = (it.get("desc") or "").strip()
            cid = (it.get("id") or "").strip()
            if not nm:
                continue
            j = _judge_one(nm, ds)
            item = {"id": cid, "name": nm,
                    "verdict": j.get("verdict") or "unclear",
                    "confidence": j.get("confidence") or 0,
                    "reason": j.get("reason") or j.get("error") or ""}
            out.append(item)
            if item["verdict"] == "GL":
                gl_list.append(item)
        return _ok(checked=len(out), glCount=len(gl_list),
                   gl=gl_list, all=out)

    # 单条模式
    if not name:
        return _err("name 不能为空（或传 items 批量）")
    j = _judge_one(name, desc)
    return _ok(name=name, **j)


@mcp.tool(description=(
    "创建任务清单。接到多步骤任务时**必须先调这个**，把要做的事拆成条目。"
    "之后每完成一项调 task_done。全部打勾前不允许结束任务。"
    "例：items=['下载3部百合剧各6集','切片','确认成片','发布到Y03']"))
def task_create(items: list[str] = [], planId: str = "") -> dict:
    from app.services import task_plan as tp
    if not items:
        return _err("items 不能为空")
    r = tp.create(items, planId)
    return _ok(**r, hint="记住 planId，完成每项后调 task_done")


@mcp.tool(description=(
    "标记任务项完成。seq=第几项（从1开始），或 keyword=标题关键词。"
    "note 写完成说明（如'出片6集'）"))
def task_done(planId: str, seq: int = 0, keyword: str = "",
              note: str = "") -> dict:
    from app.services import task_plan as tp
    if not planId:
        return _err("planId 不能为空")
    r = tp.done(planId, seq=seq, keyword=keyword, note=note)
    if not r.get("ok"):
        return _err(r.get("error") or "标记失败")
    # 顺便返回进度
    st = tp.status(planId)
    return _ok(**r, progress="%d/%d" % (st["done"], st["total"]),
               allDone=st["allDone"], pending=st["pending"],
               nextPending=st["nextPending"])


@mcp.tool(description="查任务清单进度：哪些做完了、还剩什么")
def task_status(planId: str = "") -> dict:
    from app.services import task_plan as tp
    if not planId:
        r = tp.latest_plan()
        if not r.get("ok"):
            return _err("没有进行中的计划")
        return _ok(**r)
    return _ok(**tp.status(planId))


@mcp.tool(description="清除任务清单（任务彻底结束或放弃时用）")
def task_clear(planId: str) -> dict:
    from app.services import task_plan as tp
    if not planId:
        return _err("planId 不能为空")
    return _ok(**tp.clear(planId))


@mcp.tool(description=(
    "查下载台账：哪些剧下过、下过多少集、多少集还在磁盘上。"
    "发布后删掉的集也记着（state=deleted），不会重复下载"))
def dl_ledger_list() -> dict:
    from app.services import dl_ledger as ledger
    rows = ledger.list_dramas()
    st = ledger.stats()
    return _ok(count=len(rows), stats=st, dramas=rows)


@mcp.tool(description=(
    "查某部剧的下载台账：哪些集下过、哪些还在、哪些被删了。"
    "下之前用它确认，避免重复下载"))
def dl_ledger_of(tkId: str) -> dict:
    from app.services import dl_ledger as ledger
    tid = str(tkId or "").strip()
    if not tid:
        return _err("tkId 不能为空")
    recs = ledger.get_done(tid)
    alive, deleted = [], []
    for ep, r in sorted(recs.items()):
        if r["state"] == "done":
            alive.append(ep)
        else:
            deleted.append(ep)
    return _ok(
        tkId=tid, totalRecorded=len(recs),
        alive=alive, deleted=deleted,
        details={str(k): v for k, v in sorted(recs.items())})


@mcp.tool(description=(
    "把磁盘上已有的下载补进台账（首次启用台账、或台账丢了时用）。"
    "dirs 不传则扫所有已知下载目录"))
def dl_ledger_sync(tkIds: list[str] = [], dirs: list[str] = []) -> dict:
    from app.services import dl_ledger as ledger
    from app.services import dl
    from pathlib import Path as _P

    scan = dirs or []
    if not scan:
        try:
            scan.append(str(dl.slice_target_root()))
        except Exception:
            pass
        try:
            scan.append(str(dl.out_root()))
        except Exception:
            pass
        from app import paths
        scan.append(str(_P(paths.DATA_DIR) / "tk_downloads"))
        scan.append(r"E:\tmp\gl_test")

    ids = [str(x).strip() for x in (tkIds or []) if str(x).strip()]
    if not ids:
        return _err("tkIds 不能为空（要同步哪些剧）")

    out = []
    total = 0
    for tid in ids[:50]:
        try:
            r = ledger.sync_from_disk(tid, scan)
            out.append(r)
            total += r.get("synced") or 0
        except Exception as e:
            out.append({"tkId": tid, "error": str(e)[:80]})

    return _ok(totalSynced=total, scannedDirs=scan, items=out)


@mcp.tool(description=(
    "从剧库里筛出指定类型的剧。rel: GL(百合)/BG(男女)/BL(男男)/none/unclear。"
    "genre: 按官方题材标签过滤（如 Sismance/Werewolf/Mafia/Vampire）。"
    "用于「给我找 N 部百合剧」这类需求，直接从已扫好的 1089 部库里查，秒回"))
def drama_find(rel: str = "", genre: str = "", limit: int = 50) -> dict:
    """按关系类型/题材从剧库筛选。"""
    from app.db import db

    sql = "SELECT tk_id, name, rel, confidence, genres, reason FROM drama_genre WHERE 1=1"
    params = []

    if rel:
        sql += " AND rel=?"
        params.append(rel.strip().upper())

    if genre:
        # genres 存在为 JSON 数组字符串，例如 ["Werewolf", "City"]
        # 用 LIKE '%"Werewolf"%' 精确匹配单个标签（注意引号）
        g = genre.strip()
        sql += " AND genres LIKE ?"
        params.append('%"' + g + '"%')

    sql += " ORDER BY confidence DESC LIMIT ?"
    params.append(min(int(limit or 50), 500))

    try:
        rows = db.q(sql, tuple(params))
    except Exception as e:
        # 附带 SQL 和参数，便于定位
        import traceback
        return _err(
            "查询失败: %s: %s" % (type(e).__name__, str(e)[:150]),
            sql=sql, params=[str(p) for p in params],
            trace=traceback.format_exc()[-400:])

    import json as _j
    items = []
    for r in rows:
        try:
            g = _j.loads(r["genres"] or "[]")
        except Exception:
            g = []
        items.append({
            "tkId": r["tk_id"], "name": r["name"], "rel": r["rel"],
            "confidence": r["confidence"], "genres": g,
        })

    return _ok(count=len(items), rel=rel or "全部",
               genre=genre or "全部", items=items)


@mcp.tool(description="查剧库统计：各关系类型有多少部、有哪些题材标签")
def drama_stats() -> dict:
    from app.db import db
    import json as _j
    from collections import Counter

    rows = db.q("SELECT rel, genres FROM drama_genre")
    rel_c = Counter()
    genre_c = Counter()
    for r in rows:
        rel_c[r["rel"]] += 1
        try:
            for g in _j.loads(r["genres"] or "[]"):
                genre_c[str(g)] += 1
        except Exception:
            pass

    return _ok(
        total=len(rows),
        byRel=dict(rel_c),
        topGenres=[{"genre": g, "count": n}
                   for g, n in genre_c.most_common(30)],
    )


@mcp.tool(description=(
    "判断短剧的情感主线类型（GL女女/BG男女/BL男男/none无/none无感情线）。"
    "tkId=剧集id。会自动从 TK 拉真实剧情简介再判断，准确度高。"
    "返回 rel/confidence/genres(题材标签)/lead(主角是谁)/reason。"
    "单部直接传 tkId；批量传 tkIds 列表（最多50）"))
def drama_genre_check(tkId: str = "", tkIds: list[str] = [],
                      useCache: bool = True) -> dict:
    """判断短剧是不是百合，并提取题材标签。"""
    from app.services import drama_genre as dg

    ids = []
    if tkId:
        ids.append(str(tkId).strip())
    for x in (tkIds or []):
        s = str(x).strip()
        if s and s not in ids:
            ids.append(s)
    if not ids:
        return _err("tkId 或 tkIds 不能为空")

    ids = ids[:50]
    out = []
    gl = []
    for tid in ids:
        r = dg.classify_one("", "", "", tid, use_cache=useCache,
                            fetch_meta=True)
        out.append(r)
        if r.get("rel") == "GL" and (r.get("confidence") or 0) >= 0.6:
            gl.append(r)

    if len(ids) == 1:
        return _ok(**out[0])
    return _ok(checked=len(out), glCount=len(gl), gl=gl, all=out)


@mcp.tool(description="查剧型识别统计（已判多少部、各类型分布）")
def drama_genre_stats() -> dict:
    from app.services import drama_genre as dg
    return _ok(**dg.stats())

@mcp.tool(description=(
    "下载 TikTok 短剧的指定集（本地无片源时用这个）。"
    "tkId=剧集id(collection_id，19位数字)；eps=集号列表如[1,2,3]；"
    "dest=保存目录(可选，默认库目录)。返回每集下载结果与文件路径。"
    "⚠ 这是唯一能从 TK id 直接下片的入口，不要用 dl_check/dl_tiktok_download"))
def dl_tk_eps(tkId: str, eps: list[int] = [], dest: str = "",
              force: bool = False) -> dict:
    """按 TK collection_id 下载指定集。

    台账机制：下载前先查 dl_ledger，
      已下过且文件在 → 跳过
      已下过但文件被删 → 默认也跳过（避免重复下载），
                        要重下请传 force=True
    """
    import subprocess as _sp
    import os as _os
    from pathlib import Path as _P
    from app.services import dl
    from app.services import dl_ledger as ledger

    tid = str(tkId or "").strip()
    if not tid:
        return _err("tkId 不能为空")
    nums = sorted({int(x) for x in (eps or []) if int(x) > 0})
    if not nums:
        return _err("eps 不能为空，例如 [1,2,3]")

    try:
        exe = dl.py_exe()
    except Exception as e:
        return _err("找不到 Python: " + str(e)[:120])

    script = _P(__file__).resolve().parent / "tk_ep_download.py"
    if not script.exists():
        return _err("找不到下载脚本: " + str(script))

    # 目录：优先用户指定；否则直接落到「切片能识别的源素材根」
    # ⚠ 关键：切片只扫 source_roots() 下的目录，下到别处等于白下
    if dest:
        base = _P(dest)
    else:
        try:
            root = dl.slice_target_root()      # 切片真正读的目录
            # 用剧名做目录名（切片按目录名建剧），拿不到剧名就用 id
            title = ""
            try:
                _m = dl.sd_drama(tid)
                title = (_m.get("name") or "").strip()
            except Exception:
                pass
            dirname = ("%s_%s" % (title[:40], tid)) if title else tid
            # 去掉 Windows 非法字符
            for ch in '<>:"/\\|?*':
                dirname = dirname.replace(ch, "_")
            base = _P(root) / dirname
        except Exception:
            from app import paths
            base = _P(paths.DATA_DIR) / "tk_downloads" / tid
    base.mkdir(parents=True, exist_ok=True)

    # 拿剧名（写台账用）
    drama_name = ""
    try:
        _mm = dl.sd_drama(tid)
        drama_name = (_mm.get("name") or "").strip()
    except Exception:
        pass

    # ⭐ 台账判断：哪些要下、哪些跳过
    plan = ledger.plan_eps(tid, nums[:30], force=force, check_file=True)
    to_download = plan["toDownload"]
    skip_list = plan["skipped"]

    results = []
    ok_n = 0

    # 先记跳过的
    for ep in skip_list:
        rec = ledger.get_done(tid).get(int(ep)) or {}
        results.append({
            "ep": ep, "ok": True, "skipped": plan["details"].get(ep, "已下载过"),
            "bytes": rec.get("size") or 0,
            "path": rec.get("path") or "",
        })
        ok_n += 1

    for ep in to_download:
        try:
            pr = _sp.run(
                [exe, str(script), tid, str(ep), str(out)],
                capture_output=True, text=True, timeout=300,
                encoding="utf-8", errors="replace",
                creationflags=(0x08000000 if _os.name == "nt" else 0))
            raw = (pr.stdout or "").strip()
            line = raw.splitlines()[-1] if raw else ""
            try:
                j = json.loads(line)
            except Exception:
                j = {}
            good = bool(j.get("ok")) and out.exists()
            if good:
                ok_n += 1
                # ⭐ 写台账
                try:
                    ledger.mark_done(
                        tid, ep,
                        size=j.get("bytes") or (out.stat().st_size if out.exists() else 0),
                        duration=float(j.get("duration") or 0),
                        path=str(out) if out.exists() else "",
                        dramaname=drama_name)
                except Exception:
                    pass
            results.append({
                "ep": ep, "ok": good,
                "bytes": j.get("bytes") or (out.stat().st_size if out.exists() else 0),
                "path": str(out) if out.exists() else "",
                "err": (j.get("err") or "")[:150] or
                       ("" if good else (pr.stderr or "")[:150]),
            })
        except _sp.TimeoutExpired:
            results.append({"ep": ep, "ok": False, "err": "超时(300s)"})
        except Exception as e:
            results.append({"ep": ep, "ok": False,
                            "error": "%s: %s" % (type(e).__name__, str(e)[:120])})

    return _ok(
        tkId=tid, dramaname=drama_name,
        requested=len(nums), success=ok_n,
        downloaded=len(to_download), skippedAlready=len(skip_list),
        destDir=str(base), items=results,
        plan=plan["details"],
        hint=("下载 %d 集 / 跳过 %d 集（已下过），文件在 %s"
              % (len(to_download), len(skip_list), base)))


# 批量查询任务状态表（内存，进程内有效）
_SD_BATCH_JOBS: dict = {}


@mcp.tool(description="查批量短剧查询任务的进度。jobId 从 dl_sd_batch 返回")
def dl_sd_batch_status(jobId: str = "") -> dict:
    if not jobId:
        # 没传就返回全部
        items = []
        for jid, st in _SD_BATCH_JOBS.items():
            items.append({
                "jobId": jid, "status": st.get("status"),
                "done": st.get("done"), "total": st.get("total"),
                "ok": st.get("ok"),
                "elapsed": round((st.get("endedAt") or time.time())
                                 - st.get("startedAt", 0), 1),
            })
        return _ok(count=len(items), jobs=items)

    st = _SD_BATCH_JOBS.get(jobId)
    if not st:
        return _err("找不到任务: " + jobId)
    return _ok(
        jobId=jobId, status=st.get("status"),
        done=st.get("done"), total=st.get("total"), ok=st.get("ok"),
        elapsed=round((st.get("endedAt") or time.time())
                      - st.get("startedAt", 0), 1),
        items=st.get("items") or [],
        error=st.get("error"))


@mcp.tool(description=(
    "查已搜过的 TikTok 短剧历史（本地保留最近 300 条，含剧名/集数/观看量）。"
    "可以用来避免重复查询，或找回之前查过的剧"))
def dl_sd_history(limit: int = 50) -> dict:
    from app.services import dl
    try:
        items = dl.sd_history()[:limit]
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "管理 TK短剧用的调试浏览器。action: status|start|stop|login。"
    "headless=true 时不显示窗口；stop 会彻底关闭释放内存"))
def dl_sd_browser(action: str = "status", headless: bool = True) -> dict:
    try:
        from app.services import tk_browser
        a = (action or "status").lower()
        if a == "start":
            r = tk_browser.start(headless=headless)
            return _ok(**r)
        if a == "stop":
            r = tk_browser.stop()
            return _ok(**r)
        if a == "login":
            # 开有头窗口让用户手动登录（下载必须登录才有 playAddr）
            r = tk_browser.start(headless=False)
            return _ok(**r, hint="Chrome 已打开，请让用户手动登录 TikTok，"
                                 "登录后调 action=verify 确认")
        if a in ("verify", "check"):
            return _sd_login_check()
        return _ok(**tk_browser.status())
    except Exception as e:
        return _err(str(e)[:200])


def _sd_login_check() -> dict:
    """检查调试浏览器里 TikTok 是否已登录（决定能否下载）"""
    try:
        from playwright.sync_api import sync_playwright
        from app.services import tk_browser
        if not tk_browser.cdp_alive():
            return _err("调试浏览器没启动，先 dl_sd_browser(action='start')")
        with sync_playwright() as pw:
            br = pw.chromium.connect_over_cdp(tk_browser.CDP_URL, timeout=30000)
            ctx = br.contexts[0]
            pg = None
            for x in ctx.pages:
                if "tiktok.com" in (x.url or ""):
                    pg = x
                    break
            if pg is None:
                pg = ctx.new_page()
                pg.goto("https://www.tiktok.com/", wait_until="domcontentloaded",
                        timeout=40000)
                time.sleep(3)
            r = pg.evaluate("""async () => {
                try {
                    const res = await fetch(
                        'https://www.tiktok.com/passport/web/account/info/?aid=1459',
                        {credentials: 'include'});
                    const t = await res.text();
                    let d = null;
                    try { d = JSON.parse(t); } catch(e) {}
                    const uid = d && ((d.data && d.data.user_id) || d.user_id);
                    return {ok: !!uid, userId: uid || null,
                            msg: (d && (d.message || d.msg)) || null};
                } catch(e) { return {ok: false, err: String(e).slice(0, 60)}; }
            }""")
            # 只关自己开的页
            return _ok(loggedIn=bool(r.get("ok")),
                       userId=r.get("userId"),
                       note=("已登录，可以正常下载" if r.get("ok")
                             else "未登录 —— playAddr 不会下发，下载会失败。"
                                  "调用 dl_sd_browser(action='login') 开窗让用户登录"))
    except Exception as e:
        return _err(str(e)[:200])


@mcp.tool(description=(
    "检查 TikTok 登录状态。下载 TK短剧必须先登录，否则接口不给 playAddr。"
    "返回 loggedIn / userId"))
def dl_sd_login() -> dict:
    return _sd_login_check()


@mcp.tool(description=(
    "看某个下载任务的逐集明细：state（ok/fail/skip）/ 大小 / 实际时长 / 清晰度档位。"
    "用来确认下载是否真的对（不只看 ok 计数）"))
def dl_task_detail(task_id: int) -> dict:
    from app.services import dlq
    try:
        items = dlq.snapshot()
        x = next((i for i in items if i["id"] == int(task_id)), None)
        if not x:
            return _err(f"任务 {task_id} 不存在")
        eps = []
        for e in x.get("eps") or []:
            eps.append({
                "ep": e.get("ep"), "state": e.get("state"),
                "bytes": e.get("bytes") or 0,
                "mb": round((e.get("bytes") or 0) / 1048576.0, 2),
                "duration": e.get("duration") or 0,
                "quality": e.get("quality") or "",
                "msg": e.get("msg") or "",
            })
        return _ok(task_id=task_id, site=x.get("site"), name=x.get("name"),
                   done=x.get("done"), total=x.get("total"),
                   finished=x.get("finished"),
                   okCount=x.get("ok"),          # 成功集数（避免和 ok 布尔冲突）
                   bytes=x.get("bytes"), eps=eps)
    except Exception as e:
        return _err(str(e)[:160])


# ═══════════════════════════════════════════════
#  素材 / 成片
# ═══════════════════════════════════════════════
@mcp.tool(description="列素材库")
def library_list(limit: int = 50) -> dict:
    from app.api import library as lib
    try:
        r = lib.list_items(limit=limit) if hasattr(lib, "list_items") else None
        if r is None:
            from app.services import slicing as sl
            ds = sl.list_dramas()
            return _ok(count=len(ds), items=ds[:limit])
        return _ok(**r) if isinstance(r, dict) else _ok(items=r)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  发布
# ═══════════════════════════════════════════════
@mcp.tool(description="发布视频到 Facebook Reels")
def publish_reels(video_path: str, page_id: str = "",
                  caption: str = "") -> dict:
    from app.services import reels as rl
    try:
        if hasattr(rl, "publish"):
            r = rl.publish(video_path, page_id, caption)
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        return _err("发布模块未提供 publish 接口")
    except Exception as e:
        return _err(f"发布失败: {str(e)[:120]}")


@mcp.tool(description="查可发布的主页列表")
def publish_pages() -> dict:
    from app.services import reels as rl
    try:
        plan = rl.plan_pages() if hasattr(rl, "plan_pages") else []
        return _ok(count=len(plan), pages=plan)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  系统
# ═══════════════════════════════════════════════
@mcp.tool(description="系统健康检查")
def system_health() -> dict:
    from app.db import db
    from app.services import envcheck
    e = envcheck.full_check()
    return _ok(ready=e["ok"], warnings=e["warnings"],
               gpu=e["gpu"].get("name"),
               cuda=e["gpu"].get("cuda"))


@mcp.tool(description="读最近日志")
def system_logs(limit: int = 30) -> dict:
    from app.db import db
    rows = db.q("""SELECT ts, level, source, msg FROM events
                   ORDER BY rowid DESC LIMIT ?""", (limit,))
    return _ok(count=len(rows), items=[dict(r) for r in rows])


# ═══════════════════════════════════════════════
#  记忆（跨会话）
# ═══════════════════════════════════════════════
@mcp.tool(description="写记忆（跨会话保留）。常用键：current_drama / preference / last_step")
def memory_set(key: str, value: str) -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.set(key, value))


@mcp.tool(description="读记忆")
def memory_get(key: str) -> dict:
    from app.services import agent_memory as mem
    r = mem.get(key)
    if not r.get("ok"):
        return _err(r.get("error") or "没有这个键", key=key)
    return _ok(key=r["key"], value=r["value"], updatedAt=r["updatedAt"])


@mcp.tool(description="列出所有记忆")
def memory_list() -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.list_all())


# ═══════════════════════════════════════════════
#  Agent 自身的模型信息
# ═══════════════════════════════════════════════
@mcp.tool(description="列出当前接入 Agent 的模型（含可用性）")
def agent_models() -> dict:
    from app.services import agent_models as am
    o = am.overview()
    return _ok(connected=o["connected"], name=o["name"],
               models=[{"id": m["id"], "role": m.get("role"),
                        "tested": bool((m.get("test") or {}).get("at")),
                        "ok": (m.get("test") or {}).get("ok")}
                       for m in (o["visible"] or [])])


_APP_CACHE = None


def get_app():
    """返回挂到 FastAPI 的 Starlette 应用（**单例**）。

    必须单例：lifespan 里启动的 session manager 与挂载的 app
    必须是同一个对象，否则 streamable-http 会报
    "Task group is not initialized"。
    """
    global _APP_CACHE
    if _APP_CACHE is None:
        _APP_CACHE = mcp.streamable_http_app(
            streamable_http_path="/", stateless_http=True)
    return _APP_CACHE


# 全功能工具（账号/主页/授权/发布/失败诊断等）在 mcp_tools_full 里注册
try:
    from app.legacy.mcp_tools_full import register as _register_full
    _register_full(mcp)
    log.info("mcp_tools_full registered")
except Exception as _e:
    log.warning("mcp_tools_full register failed: %s", _e)

# 剧型工具（列出/判定/手动指定）
try:
    from app.mcp_type import register as _register_type
    _register_type(mcp)
    log.info("mcp_type registered")
except Exception as _e:
    log.warning("mcp_type register failed: %s", _e)

# 邮箱工具（通道配置/测试/拉取/验证码）
try:
    from app.mcp_mail import register as _register_mail
    _register_mail(mcp)
    log.info("mcp_mail registered")
except Exception as _e:
    log.warning("mcp_mail register failed: %s", _e)

# 视频制作工具（clip/concat/vertical/subs/speed/lufs）
try:
    from app.mcp_video import register as _register_video
    _register_video(mcp)
    log.info("mcp_video registered")
except Exception as _e:
    log.warning("mcp_video register failed: %s", _e)

# 文件系统工具（读/写/列目录/搜索/磁盘）
try:
    from app.mcp_fs import register as _register_fs
    _register_fs(mcp)
    log.info("mcp_fs registered")
except Exception as _e:
    log.warning("mcp_fs register failed: %s", _e)
