"""播放量 API：从 Business Suite 主页成效分析采集，按主页按天入库。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.adapters.facebook import FB, FBError
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.insights")
router = APIRouter(tags=["insights"])

# 成效分析页的数字提取：Meta 用「1.2万」「3,456」混合格式
NUM_JS = r"""
(() => {
  const bodyText = document.body ? document.body.innerText : '';

  // ---- 数字解析：支持 1.2万 / 3,456 / 1.5K / 2.3M ----
  const parseNum = (s) => {
    if (s === null || s === undefined) return null;
    s = String(s).replace(/,/g, '').replace(/\s/g, '').trim();
    if (!s) return null;
    let mul = 1;
    if (/亿/.test(s)) mul = 1e8;
    else if (/万|w/i.test(s)) mul = 1e4;
    else if (/千/i.test(s)) mul = 1e3;
    else if (/[kK]$/.test(s)) mul = 1e3;
    else if (/[mM]$/.test(s)) mul = 1e6;
    else if (/[bB]$/.test(s)) mul = 1e9;
    const n = parseFloat(s.replace(/[^\d.]/g, ''));
    return isNaN(n) ? null : Math.round(n * mul);
  };

  // ---- 结构化提取：找标签元素，取它后面的数字（最可靠）----
  // Meta 成效分析里每个指标是 label + value 的节点对
  const byLabel = (labels) => {
    const all = Array.from(document.querySelectorAll('div,span,h2,h3,h4,p'));
    for (const el of all) {
      const txt = (el.textContent || '').trim();
      if (txt.length > 30) continue;          // 纯标签，不该太长
      for (const lb of labels) {
        if (!new RegExp('^' + lb + '$', 'i').test(txt)) continue;
        // ① 先在父节点/兄弟里找数字
        const scope = el.parentElement ? el.parentElement.parentElement : null;
        if (scope) {
          const cand = Array.from(scope.querySelectorAll('div,span,h2,h3,h4'))
            .map(n => (n.textContent || '').trim())
            .filter(t => /^[\d.,]+\s*[万亿千kKmMbB]?$/.test(t));
          if (cand.length) return parseNum(cand[cand.length - 1]);
        }
        // ② 退回文本正则（限制在同一行内，避免跨界）
        const m = bodyText.match(new RegExp(lb + '[^\\n\\d]{0,20}([\\d.,]+\\s*[万亿千kKmMbB]?)', 'i'));
        if (m) return parseNum(m[1]);
      }
    }
    return null;
  };

  // ---- 宽松正则兜底（限定行内，不跨行）----
  const byRegex = (pats) => {
    for (const p of pats) {
      const m = bodyText.match(p);
      if (m) {
        const v = parseNum(m[1]);
        if (v !== null) return v;
      }
    }
    return null;
  };

  const views = byLabel(['播放次数', '播放量', 'Views', 'Video views', 'Plays'])
    ?? byRegex([/播放次数[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /(?:^|\n)\s*Views?[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /Plays?[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  const reach = byLabel(['覆盖人数', '触及人数', 'Reach', 'Accounts reached', 'People reached'])
    ?? byRegex([/覆盖人数[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /(?:^|\n)\s*Reach[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  const minutes = byLabel(['观看分钟', '观看时长', 'Watch time', 'Minutes viewed'])
    ?? byRegex([/观看分钟[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /Watch time[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  const reactions = byLabel(['心情', '赞', '互动', 'Reactions', 'Engagement', 'Likes'])
    ?? byRegex([/(?:心情|赞|互动)[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /(?:^|\n)\s*(?:Reactions|Engagement)[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  const followers = byLabel(['粉丝', '追踪者', 'Followers', 'Page followers'])
    ?? byRegex([/(?:粉丝|追踪者)[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i,
                /Followers[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  // 新关注（涨粉）
  const newFollowers = byLabel(['新关注', '新增粉丝', 'New followers', 'Followers gained'])
    ?? byRegex([/(?:新关注|新增粉丝|Followers gained)[^\n\d]{0,15}([\d.,]+\s*[万亿千kKmM]?)/i]);

  return {
    views: views,
    reach: reach,
    minutes: minutes,
    reactions: reactions,
    followers: followers,
    newFollowers: newFollowers,
    // 调试用：返回原始文本前 2000 字，便于排查解析失败
    raw: bodyText.slice(0, 2000),
    // 解析诊断：哪些字段没拿到
    missing: [
      views === null ? 'views' : null,
      reach === null ? 'reach' : null,
      minutes === null ? 'minutes' : null,
      reactions === null ? 'reactions' : null,
    ].filter(Boolean)
  };
})()
"""


# ══════════════════════════════════════════════════════════
# 多粒度采集：支持「主页 / 单视频 / 单账号」独立采集
# ══════════════════════════════════════════════════════════

class CollectOneReq(BaseModel):
    """单目标采集（比批量更可控，可指定类型）。"""
    targetType: str = "page"        # page | unit | account
    targetId: str = ""              # page_id / unit_id / profileId
    days: int = 30
    saveRaw: bool = True            # 采集失败时是否保留原始文本


class CollectAllReq(BaseModel):
    """批量采集：可按类型筛选。"""
    targetTypes: list[str] = ["page"]     # page / unit / account
    days: int = 30
    limit: int = 0                        # 0=不限


@router.get("/insights/targets")
async def insights_targets():
    """列出可采集的目标（主页 / 视频 / 账号），供前端勾选。"""
    pages = db.q(
        "SELECT page_id, asset_id, name, followers, views_30d, health "
        "FROM pages ORDER BY name")
    units = db.q(
        "SELECT u.id, u.page_id, u.file, u.title, u.published_at, u.permalink, "
        "       p.name AS page_name "
        "FROM units u LEFT JOIN pages p ON p.page_id=u.page_id "
        "ORDER BY u.published_at DESC LIMIT 300")
    return {
        "ok": True,
        "pages": [{
            "id": p["page_id"], "assetId": p["asset_id"], "name": p["name"],
            "followers": p["followers"], "views30d": p["views_30d"],
            "health": p["health"],
        } for p in pages],
        "units": [{
            "id": u["id"], "pageId": u["page_id"], "pageName": u["page_name"],
            "file": u["file"], "title": u["title"],
            "publishedAt": u["published_at"], "permalink": u["permalink"],
        } for u in units],
        "counts": {"pages": len(pages), "units": len(units)},
    }


@router.post("/insights/collect-one")
async def collect_one(req: CollectOneReq):
    """采集单个目标（主页 / 视频 / 账号）。

    与批量接口不同，这里精确到一条，失败会返回原始文本便于排查。
    """
    ttype = (req.targetType or "page").strip().lower()
    tid = (req.targetId or "").strip()
    if not tid:
        raise HTTPException(400, "targetId 不能为空")

    env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    # 解析目标 -> (asset_id, page_id, unit_id)
    asset, page_id, unit_id, url = None, None, None, None

    if ttype == "page":
        row = db.q1("SELECT page_id, asset_id, name FROM pages WHERE page_id=? "
                    "OR asset_id=?", (tid, tid))
        if not row:
            raise HTTPException(404, "找不到主页: " + tid)
        page_id, asset = row["page_id"], row["asset_id"]
        url = ("https://business.facebook.com/latest/insights/overview"
               f"?asset_id={asset}")

    elif ttype == "unit":
        row = db.q1("SELECT u.id, u.page_id, u.permalink, u.title, "
                    "u.post_id, p.asset_id, p.name AS page_name "
                    "FROM units u LEFT JOIN pages p ON p.page_id=u.page_id "
                    "WHERE u.id=?", (tid,))
        if not row:
            raise HTTPException(404, "找不到视频: " + tid)
        unit_id, page_id = row["id"], row["page_id"]
        asset = row["asset_id"]
        # 走内容库表格（已验证可靠），而不是 insights 概览页
        url = ("https://business.facebook.com/latest/posts/published_posts"
               f"?asset_id={asset}")

    elif ttype == "account":
        # 账号级：取该账号下所有主页的汇总
        row = db.q1("SELECT page_id, asset_id, name FROM pages WHERE page_id=?",
                    (tid,))
        if not row:
            raise HTTPException(404, "找不到账号: " + tid)
        page_id, asset = row["page_id"], row["asset_id"]
        url = ("https://business.facebook.com/latest/insights/overview"
               f"?asset_id={asset}")
    else:
        raise HTTPException(400, "targetType 必须是 page / unit / account")

    if not asset and ttype != "unit":
        raise HTTPException(400, "该目标缺少 asset_id，请先扫描主页")

    # 单目标采集（同步返回，不建 job，直观看到结果）
    from app.adapters.facebook import FB
    result = {"ok": False, "targetType": ttype, "targetId": tid,
              "pageId": page_id, "assetId": asset, "url": url}

    try:
        async with FB(int(env["cdp_port"])) as fb:
            await fb.assert_identity(settings.fb_publisher_cuser)
            page = await fb.tab()
            await page.goto(url, wait_until_loaded=12.0)

            # ⚠ 关键修复：轮询等待数据渲染完成（Meta 是 SPA，骨架先出数据后到）
            # 原来固定等 3 秒 → 只读到左侧导航，没有任何指标数字
            ready = False
            waited = 0.0
            last_probe = {}
            for _ in range(25):                # 最多 25 秒
                try:
                    last_probe = await page.eval(WAIT_JS) or {}
                except Exception:
                    last_probe = {}
                if last_probe.get("ready"):
                    ready = True
                    break
                await asyncio.sleep(1.0)
                waited += 1.0

            # 数据没出来时再多等 3 秒（有些页面数字延迟渲染）
            if not ready:
                await asyncio.sleep(3.0)

            data = await page.eval(NUM_JS) or {}
            data["_renderWait"] = round(waited, 1)
            data["_ready"] = ready
            data["_textLen"] = last_probe.get("textLen")
            if not ready and not data.get("views"):
                # 把「轮询时看到的行」也带回去，便于判断卡在哪
                data["_probeLines"] = last_probe.get("lines") or []

            today = date.today().isoformat()
            saved = {}

            if ttype == "unit" and unit_id:
                # 视频级：走内容库表格（collect_via_suite，已验证可靠）
                from app.services import metrics as mx
                rows = await mx.collect_via_suite(
                    fb, asset, env_code="", page_id=page_id)
                # 处理 guard
                if rows and rows[0].get("_guard"):
                    result["guard"] = rows[0]["_guard"]
                    result["error"] = "触发风控，已停止"
                    return result

                target_post = (row["post_id"] or "").strip()
                target_id = unit_id
                matched = None
                for rr in rows:
                    if target_post and (rr.get("post_id") or "") == target_post:
                        matched = rr
                        break
                if matched is None and target_post:
                    # 退一步：用 unit_id 关联（upsert 会写回）
                    for rr in rows:
                        if (rr.get("unit_id") or "") == unit_id:
                            matched = rr
                            break

                if matched is None:
                    result["error"] = (
                        "内容库里没找到这条视频（可能超出 30 天窗口或已删除）")
                    result["hint"] = (
                        f"内容库共解析 {len(rows)} 条；"
                        f"目标 post_id={target_post or '(空)'}")
                    if rows:
                        result["sampleTitles"] = [
                            (x.get("title") or "")[:40] for x in rows[:5]]
                else:
                    # 写库（复用成熟实现）
                    uid = mx.upsert_unit_metrics(page_id, asset, matched)
                    data = {
                        "views": matched.get("plays"),
                        "reach": matched.get("reach"),
                        "reactions": matched.get("reactions"),
                        "comments": matched.get("comments"),
                        "shares": matched.get("shares"),
                        "minutes": None,
                    }
                    saved["unit_metrics"] = bool(uid)
            else:
                # 主页级：写 insights
                if data.get("views") is not None:
                    db.exec(
                        "INSERT INTO insights(page_id,date,views,reach,minutes,"
                        "reactions,comments,shares,collected_at) "
                        "VALUES(?,?,?,?,?,?,?,?,?) "
                        "ON CONFLICT(page_id,date) DO UPDATE SET "
                        "views=excluded.views, reach=excluded.reach, "
                        "minutes=excluded.minutes, "
                        "reactions=excluded.reactions, "
                        "collected_at=excluded.collected_at",
                        (page_id, today, data.get("views") or 0,
                         data.get("reach") or 0, data.get("minutes") or 0,
                         data.get("reactions") or 0, 0, 0, now_iso()))
                    db.exec("UPDATE pages SET views_30d=?, followers=COALESCE(?, followers) "
                            "WHERE page_id=?",
                            (data.get("views") or 0, data.get("followers"),
                             page_id))
                    saved["insights"] = True

            result["ok"] = bool(saved)
            result["data"] = {
                "views": data.get("views"),
                "reach": data.get("reach"),
                "minutes": data.get("minutes"),
                "reactions": data.get("reactions"),
                "followers": data.get("followers"),
                "newFollowers": data.get("newFollowers"),
            }
            result["missing"] = data.get("missing") or []
            result["saved"] = saved
            if not saved and req.saveRaw:
                result["rawText"] = (data.get("raw") or "")[:1500]
                render_wait = data.get("_renderWait")
                ready_flag = data.get("_ready")
                text_len = data.get("_textLen")
                probe = data.get("_probeLines") or []
                tips = []
                if not ready_flag:
                    tips.append(
                        f"等待 {render_wait}s 后数据区仍未渲染"
                        f"（页面文本仅 {text_len} 字，只有导航菜单）")
                    tips.append("可能是：① Meta 加载慢，稍后重试；"
                                "② 该主页当前无数据；③ 需要先在页面上选时间范围")
                else:
                    tips.append("数据已渲染但标签未匹配，看 rawText 里的实际文字")
                if probe:
                    tips.append("页面里的数字行：" + " | ".join(probe[:5]))
                result["hint"] = "；".join(tips)
                result["diag"] = {
                    "ready": ready_flag,
                    "waitSec": render_wait,
                    "textLen": text_len,
                    "probeLines": probe,
                }
    except FBError as e:
        result["error"] = str(e)
    except Exception as e:
        result["error"] = "%s: %s" % (type(e).__name__, e)

    return result


# 等待数据渲染：轮询直到页面出现指标数字，或超时
WAIT_JS = r"""
(() => {
  const t = document.body ? document.body.innerText : '';
  // 判断依据：出现指标标签（中/英）且附近有数字
  const hasLabel = /播放次数|覆盖人数|观看分钟|Views?|Reach|Watch\stime|Plays/i.test(t);
  const hasDigits = /\d{1,3}(?:[,\s]\d{3})*|\d+[万亿千kKmM]/.test(t);
  const hasNav = /概览|计划|成效|受众|消息|Overview|Planned|Insights|Audience|Messages/i.test(t);
  // 页面文本长度也可参考：只有导航时通常 < 400 字
  return {
    ready: hasLabel && hasDigits,
    textLen: t.length,
    hasNav: hasNav,
    // 返回疑似包含指标的行（便于判断）
    lines: t.split('\n').filter(x => /\d/.test(x) && x.trim().length < 80).slice(0, 12),
  };
})()
"""


class CollectReq(BaseModel):
    pageIds: list[str] = []
    days: int = 30


@router.post("/insights/collect")
async def collect(req: CollectReq):
    env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    targets = req.pageIds or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]
    if not targets:
        raise HTTPException(400, "没有可采集的主页（缺 asset_id）")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{len(targets)} 个主页", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "insights", f"采集播放量 {len(targets)} 个主页", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_collect(job_id, targets, int(env["cdp_port"])))
    return {"ok": True, "jobId": job_id}


async def _run_collect(job_id: str, page_ids: list[str], port: int) -> None:
    ok, fail = 0, 0
    today = date.today().isoformat()
    try:
        async with FB(port) as fb:
            await fb.assert_identity(settings.fb_publisher_cuser)
            for i, pid in enumerate(page_ids):
                row = db.q1("SELECT asset_id,name FROM pages WHERE page_id=?", (pid,))
                asset = row["asset_id"] if row else None
                if not asset:
                    fail += 1
                    continue
                page = await fb.tab()   # 复用唯一工作标签
                try:
                    await page.goto(
                        f"https://business.facebook.com/latest/insights/overview?asset_id={asset}",
                        wait_until_loaded=9.0)
                    await asyncio.sleep(2.5)
                    data = await page.eval(NUM_JS) or {}
                    if data.get("views") is not None:
                        db.exec(
                            "INSERT INTO insights(page_id,date,views,reach,minutes,reactions,"
                            "comments,shares,collected_at) VALUES(?,?,?,?,?,?,?,?,?)"
                            " ON CONFLICT(page_id,date) DO UPDATE SET"
                            " views=excluded.views, reach=excluded.reach,"
                            " minutes=excluded.minutes, reactions=excluded.reactions,"
                            " collected_at=excluded.collected_at",
                            (pid, today, data.get("views") or 0, data.get("reach") or 0,
                             data.get("minutes") or 0, data.get("reactions") or 0, 0, 0,
                             now_iso()))
                        db.exec("UPDATE pages SET views_30d=? WHERE page_id=?",
                                (data.get("views") or 0, pid))
                        ok += 1
                    else:
                        fail += 1
                        db.log_event("warn", "insights", f"{row['name']} 未解析到数字")
                except Exception as e:
                    fail += 1
                    log.debug("insights %s failed: %s", pid, e)
                db.exec("UPDATE jobs SET progress=? WHERE id=?",
                        (int((i + 1) / len(page_ids) * 100), job_id))
                await asyncio.sleep(2)
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps({"ok": ok, "fail": fail}), now_iso(), job_id))
        db.log_event("ok", "insights", f"采集完成 {ok} 成功 / {fail} 失败")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


@router.get("/insights")
async def get_insights(days: int = Query(14, ge=1, le=90)):
    pages = db.q("SELECT page_id,name,asset_id,views_30d,followers,published,health "
                 "FROM pages ORDER BY views_30d DESC")
    series = db.q(
        "SELECT date,SUM(views) views,SUM(reach) reach,SUM(minutes) minutes "
        "FROM insights WHERE date>=? GROUP BY date ORDER BY date",
        ((date.today() - timedelta(days=days)).isoformat(),))
    rows = []
    for p in pages:
        ins = db.q1(
            "SELECT SUM(views) v, SUM(reach) r, SUM(minutes) m, SUM(reactions) rc,"
            " SUM(comments) c, SUM(shares) s FROM insights WHERE page_id=?", (p["page_id"],))
        rows.append({
            "id": p["page_id"],
            "name": p["name"],
            "assetId": p["asset_id"],
            "views30d": p["views_30d"] or (ins or {}).get("v") or 0,
            "followers": p["followers"] or 0,
            "published": p["published"] or 0,
            "health": p["health"],
            "reactions": (ins or {}).get("rc") or 0,
            "comments": (ins or {}).get("c") or 0,
            "shares": (ins or {}).get("s") or 0,
            "watchMinutes": (ins or {}).get("m") or 0,
        })
    return {"series": series, "pages": rows, "days": days}


@router.get("/insights/{page_id}")
async def page_insights(page_id: str, days: int = 14):
    rows = db.q("SELECT * FROM insights WHERE page_id=? ORDER BY date DESC LIMIT ?",
                (page_id, days))
    agg = db.q1("SELECT SUM(views) v,SUM(reach) r,SUM(minutes) m FROM insights WHERE page_id=?",
                (page_id,))
    return {"pageId": page_id, "daily": rows, "total": agg}
