/* 雨海 Agent
   检测本机 Agent → 接入 → 只显示它的模型 → 可开关/可实测 → 直接对话操作 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import {
  pageHead, $, $$, toast, ts, emptyState,
} from '../ui.js';

let ov = null;
let detecting = false;
let testing = '';
let chatHistory = [];      // [{role, content}]
let chatting = false;
let tab = 'chat';          // chat | models

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '雨海 Agent',
      desc: '接入本机 Agent，用它的模型驱动工作台',
      actions: [
        `<button class="btn sm" data-act="detect"><span data-icon="refresh"></span>重新检测</button>`,
        `<button class="btn sm ghost" data-act="deep">深度扫描</button>`,
      ],
    })}
    <div id="ag-body"></div>
  `;
  $$('[data-act="detect"]', root).forEach((b) => (b.onclick = () => detect(root)));
  $$('[data-act="deep"]', root).forEach((b) => (b.onclick = () => deepScan(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try { ov = await api.agentOverview(); } catch { ov = null; }
  paint(root);
}

async function detect(root) {
  if (detecting) return;
  detecting = true;
  const box = $('#ag-body', root);
  if (box) box.innerHTML = `<div class="card"><div class="card-body"
    style="padding:20px">正在检测本机 Agent…</div></div>`;
  try {
    const r = await api.agentDetect();
    toast(r.ok ? '检测完成' : '未找到 Agent', `${r.installed} 个可用`,
          r.ok ? 'ok' : 'warn');
    await load(root);
  } catch (e) { toast('检测失败', e.message, 'err'); }
  detecting = false;
}

async function deepScan(root) {
  toast('深度扫描中', '逐个磁盘找，可能几十秒', 'info');
  try {
    const r = await api.agentDeepScan();
    toast(`找到 ${r.count} 个`, (r.found || []).slice(0, 3).join('\n') || '无', 'ok');
  } catch (e) { toast('扫描失败', e.message, 'err'); }
}

async function connect(root, id) {
  try {
    const r = await api.agentConnect(id);
    toast(r.ok ? '已接入' : '接入失败', r.note || '', r.ok ? 'ok' : 'err');
    await load(root);
  } catch (e) { toast('接入失败', e.message, 'err'); }
}

async function toggleHide(root, modelId, hidden) {
  if (!ov?.connected) return;
  try {
    await api.agentHide({ agentId: ov.connected, modelId, hidden });
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function hideChannel(root, channel, hidden) {
  if (!ov?.connected) return;
  try {
    const r = await api.agentHideChannel({ agentId: ov.connected, channel, hidden });
    toast(hidden ? '已隐藏' : '已显示', `${channel} ${r.affected} 个`, 'ok');
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function testModel(root, modelId) {
  if (!ov?.connected || testing) return;
  testing = modelId;
  paint(root);
  try {
    const r = await api.agentTest({ agentId: ov.connected, modelId });
    toast(r.ok ? '可用' : '不可用', r.reply || r.error || '',
          r.ok ? 'ok' : 'err');
  } catch (e) { toast('测试失败', e.message, 'err'); }
  testing = '';
  await load(root);
}

/* ---------------- 对话 ---------------- */
async function send(root) {
  if (chatting) return;
  const input = $('#ag-input', root);
  const msg = (input?.value || '').trim();
  if (!msg) return;

  chatting = true;
  input.value = '';
  chatHistory.push({ role: 'user', content: msg });
  paint(root);

  try {
    const r = await api.agentChat({
      message: msg,
      history: chatHistory.slice(-8),
    });
    if (r.ok) {
      chatHistory.push({ role: 'assistant', content: r.reply || '' });
      if (r.trace?.length) {
        chatHistory[chatHistory.length - 1].trace = r.trace;
      }
    } else {
      chatHistory.push({
        role: 'assistant',
        content: `⚠️ ${r.error || '调用失败'}${r.hint ? '\n' + r.hint : ''}`,
        error: true,
      });
    }
  } catch (e) {
    chatHistory.push({ role: 'assistant', content: `⚠️ ${e.message}`, error: true });
  }
  chatting = false;
  paint(root);
  scrollBottom(root);
}

function scrollBottom(root) {
  const box = $('#ag-chat', root);
  if (box) box.scrollTop = box.scrollHeight;
}

/* ---------------- 渲染 ---------------- */
function paint(root) {
  const box = $('#ag-body', root);
  if (!box) return;

  if (!ov) {
    box.innerHTML = `<div class="card"><div class="card-body" style="padding:24px;
      text-align:center;color:var(--tx-3)">点「重新检测」扫描本机 Agent</div></div>`;
    return;
  }

  if (!ov.connected) {
    box.innerHTML = renderPicker(ov);
    $$('[data-connect]', root).forEach((b) => {
      b.onclick = () => connect(root, b.dataset.connect);
    });
    return;
  }

  // 已接入：顶部信息 + tab
  const vis = (ov.visible || []).length;
  box.innerHTML = `
    <div class="card" style="margin-bottom:0">
      <div class="card-head" style="border-bottom:1px solid var(--line)">
        <div class="card-title">
          <span style="color:var(--ok)">●</span>
          ${esc(ov.name || ov.connected)}
          <span class="chip" style="margin-left:6px;font-size:9px">${vis} 模型</span>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn xs ${tab === 'chat' ? 'primary' : 'ghost'}"
                  data-tab="chat">对话</button>
          <button class="btn xs ${tab === 'models' ? 'primary' : 'ghost'}"
                  data-tab="models">模型</button>
          <button class="btn xs ghost" data-act="switch">切换</button>
        </div>
      </div>
      ${tab === 'chat' ? renderChat(root) : renderModels(ov)}
    </div>`;

  $$('[data-tab]', root).forEach((b) => {
    b.onclick = () => { tab = b.dataset.tab; paint(root); if (tab === 'chat') scrollBottom(root); };
  });
  const sw = $('[data-act="switch"]', root);
  if (sw) sw.onclick = async () => {
    try { await api.agentConnect(''); await load(root); }
    catch (e) { toast('切换失败', e.message, 'err'); }
  };

  if (tab === 'chat') {
    const inp = $('#ag-input', root);
    const btn = $('#ag-send', root);
    if (btn) btn.onclick = () => send(root);
    if (inp) {
      // 从其它页面「问 Agent」跳过来时，预填问题
      try {
        const pre = sessionStorage.getItem('agent_prefill');
        if (pre && !inp.value) {
          inp.value = pre;
          sessionStorage.removeItem('agent_prefill');
        }
      } catch (e) { /* ignore */ }
      inp.onkeydown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(root); }
      };
      inp.focus();
    }
    const clr = $('#ag-clear', root);
    if (clr) clr.onclick = () => { chatHistory = []; paint(root); };
  } else {
    $$('[data-hide]', root).forEach((b) => {
      b.onclick = () => toggleHide(root, b.dataset.hide, b.dataset.to === '1');
    });
    $$('[data-hidech]', root).forEach((b) => {
      b.onclick = () => hideChannel(root, b.dataset.hidech, b.dataset.to === '1');
    });
    $$('[data-test]', root).forEach((b) => {
      b.onclick = () => testModel(root, b.dataset.test);
    });
    const ta = $('[data-act="testall"]', root);
    if (ta) ta.onclick = async () => {
      ta.disabled = true; ta.textContent = '测试中…';
      toast('批量测试', '逐个验证，较慢', 'info');
      try {
        const r = await api.agentTestAll({ agentId: ov.connected });
        toast('完成', `${r.passed} 可用 / ${r.failed} 不可用`, 'ok');
      } catch (e) { toast('失败', e.message, 'err'); }
      ta.disabled = false; ta.textContent = '全测';
      await load(root);
    };
  }
}

function renderChat(root) {
  const bubbles = chatHistory.map((m) => {
    if (m.role === 'user') {
      return `<div style="display:flex;justify-content:flex-end;margin:8px 0">
        <div style="max-width:78%;background:var(--bg-3);padding:8px 11px;
             border-radius:10px;font-size:11px;line-height:1.7">${nl(m.content)}</div>
      </div>`;
    }
    const trace = (m.trace || []).map((t) => `
      <div style="font-family:var(--mono);font-size:9px;color:var(--tx-3);
                  padding:2px 0 2px 8px;border-left:2px solid ${t.ok ? 'var(--ok)' : 'var(--danger)'}">
        ${t.ok ? '✓' : '✗'} ${esc(t.tool)} (${t.ms}ms)</div>`).join('');
    return `<div style="margin:8px 0">
      <div style="max-width:82%;background:${m.error ? 'rgba(220,60,60,.1)' : 'var(--bg-2)'};
           border:1px solid var(--line);padding:8px 11px;border-radius:10px;
           font-size:11px;line-height:1.7">
        ${nl(m.content)}
      </div>
      ${trace}
    </div>`;
  }).join('');

  return `
    <div class="card-body" style="padding:0">
      <div id="ag-chat" style="height:calc(100vh - 330px);min-height:260px;
           overflow:auto;padding:12px 14px">
        ${bubbles || `<div style="color:var(--tx-3);font-size:11px;line-height:2">
          直接说话就能操作工作台，例如：<br>
          · 现在有哪些剧可以切？<br>
          · 帮我把 Wrong Door 切成单集<br>
          · 检查一下环境有没有问题<br>
          · 上次切到哪了？
        </div>`}
        ${chatting ? `<div style="color:var(--tx-3);font-size:10px;padding:6px 0">
          正在思考…</div>` : ''}
      </div>
      <div style="border-top:1px solid var(--line);padding:10px 14px;
           display:flex;gap:8px;align-items:flex-end">
        <textarea id="ag-input" rows="2" placeholder="说要做什么…（Enter 发送）"
          style="flex:1;resize:none;background:var(--bg-2);border:1px solid var(--line);
                 border-radius:6px;padding:7px 9px;font-size:11px;
                 font-family:inherit;color:var(--tx-1);outline:none"></textarea>
        <button class="btn sm" id="ag-clear" title="清空对话">清空</button>
        <button class="btn sm primary" id="ag-send"
          ${chatting ? 'disabled' : ''}>${chatting ? '…' : '发送'}</button>
      </div>
    </div>`;
}

function renderModels(ov) {
  const ms = ov.models || [];
  const groups = {};
  for (const m of ms) {
    const g = m.source || (m.id.includes('/') ? m.id.split('/')[0] : '其它');
    (groups[g] = groups[g] || []).push(m);
  }
  const chips = Object.keys(groups).map((g) => {
    const n = groups[g].length;
    const hid = groups[g].filter((x) => x.hidden).length;
    const all = hid === n;
    return `<button class="btn xs ${all ? 'ghost' : ''}"
      data-hidech="${esc(g)}" data-to="${all ? '0' : '1'}" style="font-size:9px">
      ${esc(g)} ${n}${hid ? ` <span style="opacity:.5">(隐${hid})</span>` : ''}</button>`;
  }).join('');

  const rows = Object.keys(groups).map((g) => {
    const list = groups[g];
    const shown = list.filter((m) => !m.hidden);
    return `<div style="margin-top:10px">
      <div style="font-size:9.5px;color:var(--tx-3);font-family:var(--mono);
           margin-bottom:4px">${esc(g)} <span style="opacity:.6">
           ${shown.length}/${list.length}</span></div>
      ${shown.map(renderRow).join('')}
      ${list.length - shown.length > 0 ? `<div style="font-size:9px;
        color:var(--tx-3);padding:2px 0 0 20px">另有
        ${list.length - shown.length} 个已隐藏</div>` : ''}
    </div>`;
  }).join('');

  return `
    <div class="card-body" style="padding:12px 14px">
      <div style="font-size:9.5px;color:var(--tx-3);line-height:1.9">
        端点：${esc(short(ov.endpoint) || '本地')}
        ${ov.path ? `<br>配置：${esc(short(ov.path))}` : ''}
      </div>
      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:10px;
           padding-top:10px;border-top:1px solid var(--line)">
        <span style="font-size:9px;color:var(--tx-3);align-self:center">
          按渠道开关：</span>${chips}
        <button class="btn xs ghost" data-act="testall"
          style="font-size:9px;margin-left:auto">全测</button>
      </div>
      <div style="max-height:calc(100vh - 380px);overflow:auto;margin-top:6px">
        ${rows || `<div style="font-size:10px;color:var(--tx-3);padding:12px 0">
          该 Agent 已安装但没配模型，去它自己的设置里选一个</div>`}
      </div>
    </div>`;
}

function renderRow(m) {
  const t = m.test || {};
  const badge = t.at
    ? (t.ok ? `<span style="color:var(--ok);font-size:9px">✓</span>`
            : `<span style="color:var(--danger);font-size:9px">✗</span>`)
    : '';
  const role = (m.role || []).join('+');
  const busy = testing === m.id;
  return `<div style="display:flex;align-items:center;gap:7px;padding:5px 0 5px 16px">
    <span style="flex:1;font-family:var(--mono);font-size:10px;color:var(--tx-2);
         overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(m.id)}</span>
    ${m.sizeMb ? `<span style="font-size:9px;color:var(--tx-3)">${m.sizeMb}MB</span>` : ''}
    ${m.vision ? `<span class="chip" style="font-size:8.5px">视觉</span>` : ''}
    ${role ? `<span style="font-size:9px;color:var(--tx-3)">${esc(role)}</span>` : ''}
    ${badge}
    <button class="btn xs ghost" data-test="${esc(m.id)}" ${busy ? 'disabled' : ''}
      style="font-size:9px">${busy ? '…' : '测'}</button>
    <button class="btn xs ghost" data-hide="${esc(m.id)}" data-to="1"
      style="font-size:9px">隐藏</button>
  </div>`;
}

function renderPicker(ov) {
  const items = ov.switchable || [];
  if (!items.length) {
    return `<div class="card">
      <div class="card-head"><div class="card-title">未检测到 Agent</div></div>
      <div class="card-body" style="padding:16px">
        <div style="color:var(--tx-3);font-size:11px;line-height:1.9;
             margin-bottom:12px">
          工作台需要 Agent 提供：<br>
          · 理解剧情、判断哪段台词最抓人<br>
          · 按类型编排 5 阶段结构<br>
          · 对话式操作工作台
        </div>
        <div style="font-size:10px;color:var(--tx-3);margin-bottom:8px">
          或安装以下任一：</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${['Ollama|https://ollama.com/download',
             'Claude Code|https://claude.ai/code',
             'Codex|https://github.com/openai/codex',
             'Cursor|https://cursor.com',
             'WorkBuddy|https://www.workbuddy.cn']
            .map((x) => {
              const [n, u] = x.split('|');
              return `<a class="btn xs ghost" href="${u}" target="_blank">${n}</a>`;
            }).join('')}
        </div>
      </div></div>`;
  }
  return `<div class="card">
    <div class="card-head">
      <div class="card-title">选择要接入的 Agent</div>
      <span style="font-size:9.5px;color:var(--tx-3)">接入后只显示它的模型</span>
    </div>
    <div class="card-body" style="padding:8px 14px">
      ${items.map((it) => `<div style="display:flex;align-items:center;gap:10px;
        padding:9px 0;border-bottom:1px solid var(--line)">
        <span style="width:16px;color:var(--ok)">●</span>
        <span style="width:130px;color:var(--tx-2)">${esc(it.name)}</span>
        <span style="flex:1;font-size:9.5px;color:var(--tx-3)">
          ${it.models} 个模型${it.endpoint ? ' · ' + esc(short(it.endpoint)) : ''}
          ${it.error ? ' · <span style="color:var(--warn)">' + esc(it.error) + '</span>' : ''}
        </span>
        <button class="btn xs primary" data-connect="${esc(it.id)}">接入</button>
      </div>`).join('')}
    </div></div>`;
}

function short(s) {
  if (!s) return '';
  return s.length > 46 ? s.slice(0, 22) + '…' + s.slice(-20) : s;
}
function nl(s) {
  return esc(s).replace(/\n/g, '<br>');
}
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
