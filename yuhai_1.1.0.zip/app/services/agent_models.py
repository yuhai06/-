# -*- coding: utf-8 -*-
"""
agent_models.py — 模型清单管理：**只显示当前接入 agent 的模型**

三个功能（按用户要求）：
  ① 只显示当前 agent 在用的模型（接 dsh 就只有 dsh 的 36 个）
  ② 每个模型可开关（隐藏不看的，比如 our-free-model 那 32 个）
  ③ 每个模型可实测可用性（真发一次请求）

存储：
  data/agent_state.json
  {
    "connected": "dsh",
    "hidden": {"dsh": ["our-free-model/beam-free", ...]},
    "tested": {"dsh": {"workbuddy/glm-5.3-flash": {"ok": true, "at": "..."}}}
  }
"""
from __future__ import annotations

import io
import json
import logging
import os
import time
from pathlib import Path

from app.services import agent_detect as ad

log = logging.getLogger("yuhai.agent.models")

STATE_FILE = None


def _state_path() -> Path:
    global STATE_FILE
    if STATE_FILE:
        return Path(STATE_FILE)
    from app.config import settings
    p = Path(settings.data_dir) / "agent_state.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE = p
    return p


def load_state() -> dict:
    p = _state_path()
    if not p.exists():
        return {"connected": "", "hidden": {}, "tested": {}}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        d.setdefault("connected", "")
        d.setdefault("hidden", {})
        d.setdefault("tested", {})
        return d
    except Exception:
        return {"connected": "", "hidden": {}, "tested": {}}


def save_state(d: dict) -> None:
    _state_path().write_text(json.dumps(d, ensure_ascii=False, indent=1),
                             encoding="utf-8")


# ---------------- 连接 ----------------
def get_connected() -> str:
    return load_state().get("connected") or ""


def connect(agent_id: str) -> dict:
    """选一个 agent 作为当前接入（之后只显示它的模型）。"""
    d = load_state()
    d["connected"] = agent_id
    save_state(d)
    info = detect_connected()
    return {"ok": bool(info.get("models")), "connected": agent_id,
            "models": len(info.get("models") or []),
            "note": f"已接入 {info.get('name') or agent_id}"
                    f"（{len(info.get('models') or [])} 个模型）"}


def detect_connected() -> dict:
    """返回当前接入 agent 的完整信息（含模型，已应用隐藏过滤）。"""
    cid = get_connected()
    all_info = ad.detect_all()
    if not cid:
        return {"connected": "", "items": all_info["items"],
                "models": [], "name": "", "installed": all_info["installed"]}

    item = next((i for i in all_info["items"] if i["id"] == cid), None)
    if not item:
        return {"connected": cid, "error": "选中的 agent 已不存在",
                "models": [], "items": all_info["items"],
                "installed": all_info["installed"]}

    st = load_state()
    hidden = set(st.get("hidden", {}).get(cid) or [])
    tested = st.get("tested", {}).get(cid) or {}

    models = []
    for m in (item.get("models") or []):
        mid = m.get("id")
        rec = {**m,
               "hidden": mid in hidden,
               "test": tested.get(mid) or {},
               }
        models.append(rec)

    return {
        "connected": cid,
        "name": item.get("name"),
        "path": item.get("path"),
        "endpoint": item.get("endpoint"),
        "error": item.get("error"),
        "download": item.get("download"),
        "items": all_info["items"],
        "installed": all_info["installed"],
        "models": models,
        "visible": [m for m in models if not m["hidden"]],
        "hiddenCount": len(hidden),
    }


# ---------------- 开关（隐藏/显示） ----------------
def set_hidden(agent_id: str, model_id: str, hidden: bool) -> dict:
    d = load_state()
    hs = set(d["hidden"].get(agent_id) or [])
    if hidden:
        hs.add(model_id)
    else:
        hs.discard(model_id)
    d["hidden"][agent_id] = sorted(hs)
    save_state(d)
    return {"ok": True, "hidden": sorted(hs),
            "count": len(hs)}


def hide_channel(agent_id: str, channel: str, hidden: bool = True) -> dict:
    """按渠道/前缀批量隐藏（比如一次隐藏所有 our-free-model/*）。"""
    info = _raw_models(agent_id)
    n = 0
    for m in info:
        mid = m.get("id") or ""
        ch = m.get("channel") or (mid.split("/")[0] if "/" in mid else "")
        src = m.get("source") or ""
        if ch == channel or src == channel or mid.startswith(channel + "/"):
            set_hidden(agent_id, mid, hidden)
            n += 1
    return {"ok": True, "affected": n, "channel": channel}


def _raw_models(agent_id: str) -> list:
    """不经隐藏过滤，直接拿 agent 的全部模型。"""
    for a in ad.AGENTS:
        if a["id"] == agent_id:
            r = ad.detect_one(a)
            return r.get("models") or []
    return []


# ---------------- 可用性实测 ----------------
def test_one(agent_id: str, model_id: str) -> dict:
    """实测一个模型能不能用（真发请求），结果存起来。"""
    info = detect_connected()
    endpoint = ""
    api_key = ""

    # 找 endpoint / key
    for a in ad.AGENTS:
        if a["id"] != agent_id:
            continue
        raw = ad.detect_one(a)
        endpoint = raw.get("endpoint") or ""
        if a["id"] == "dsh":
            cfg = ad._read_json(a["paths"][0])
            api_key = cfg.get("key", "")
        elif a["kind"] == "toml":
            t = ad._read_toml(a["paths"][0])
            prov = t.get("model_provider", "")
            pinfo = (t.get("providers") or {}).get(prov) or {}
            envk = pinfo.get("env_key", "")
            if envk:
                api_key = os.environ.get(envk, "")
        break

    if not endpoint:
        return {"ok": False, "error": "该 agent 没有可测试的 endpoint"}

    r = ad.test_model(endpoint, model_id, api_key)

    d = load_state()
    d["tested"].setdefault(agent_id, {})[model_id] = {
        "ok": r.get("ok", False),
        "at": int(time.time() * 1000),
        "error": r.get("error", ""),
        "reply": r.get("reply", ""),
        "via": r.get("via", ""),
    }
    save_state(d)
    return {**r, "model": model_id, "agent": agent_id}


def test_all(agent_id: str, limit: int = 0) -> dict:
    """批量测（顺序跑，避免打爆网关）。"""
    models = _raw_models(agent_id)
    if limit:
        models = models[:limit]
    results = []
    ok = fail = 0
    for m in models:
        mid = m.get("id")
        r = test_one(agent_id, mid)
        results.append({"id": mid, "ok": r.get("ok"),
                        "error": r.get("error", ""),
                        "reply": r.get("reply", "")[:30]})
        if r.get("ok"):
            ok += 1
        else:
            fail += 1
    return {"ok": True, "total": len(results), "passed": ok,
            "failed": fail, "results": results}


# ---------------- 汇总给前端 ----------------
def overview() -> dict:
    """前端首屏：当前接入 + 模型清单 + 可切换的 agent 列表。"""
    info = detect_connected()
    st = load_state()

    # 可切换的 agent（只列装了的）
    switchable = []
    for it in info.get("items") or []:
        if not it.get("installed"):
            continue
        switchable.append({
            "id": it["id"], "name": it["name"],
            "models": len(it.get("models") or []),
            "endpoint": it.get("endpoint") or "",
            "error": it.get("error") or "",
            "connected": it["id"] == info.get("connected"),
        })

    # 按来源分组（前端折叠显示用）
    groups: dict[str, list] = {}
    for m in info.get("models") or []:
        src = m.get("source") or (
            (m.get("id") or "").split("/")[0]
            if "/" in (m.get("id") or "") else "其它")
        groups.setdefault(src, []).append(m)

    return {
        "connected": info.get("connected"),
        "name": info.get("name"),
        "path": info.get("path"),
        "endpoint": info.get("endpoint"),
        "error": info.get("error"),
        "switchable": switchable,
        "models": info.get("models") or [],
        "visible": info.get("visible") or [],
        "groups": {k: len(v) for k, v in groups.items()},
        "hiddenCount": info.get("hiddenCount") or 0,
        "stateFile": str(_state_path()),
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "connect":
        print(connect(sys.argv[2]))
    elif len(sys.argv) > 1 and sys.argv[1] == "test":
        print(test_one(sys.argv[2], sys.argv[3]))
    elif len(sys.argv) > 1 and sys.argv[1] == "testall":
        r = test_all(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 0)
        print(json.dumps({k: r[k] for k in ("total", "passed", "failed")},
                         ensure_ascii=False))
        for x in r["results"][:20]:
            print(f"  {'OK ' if x['ok'] else 'FAIL'} {x['id'][:44]:<46} "
                  f"{(x['reply'] or x['error'])[:40]}")
    else:
        o = overview()
        print(f"接入: {o['connected'] or '(未选)'}  {o['name'] or ''}")
        print(f"模型: {len(o['models'])} 个（隐藏 {o['hiddenCount']}）")
        print(f"分组: {o['groups']}")
        print(f"可切换: {[s['id'] for s in o['switchable']]}")
