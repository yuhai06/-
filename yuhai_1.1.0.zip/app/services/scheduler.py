"""排期执行引擎：每分钟扫一次，到点把排期的素材推入发布任务。

规则：
  · 只处理 state='planned' 且 queue_id 非空、时间已到
  · 主页受限 → 标 blocked，不执行
  · 素材文件不存在 → 标 blocked
  · 发布成功 → 排期 done，队列条目删除（连同文件，按规则）
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.scheduler")


class Scheduler:
    def __init__(self, interval: float = 60.0) -> None:
        self.interval = interval
        self._task: asyncio.Task | None = None
        self._stop = False
        # 串行发布锁：防止两轮 tick 重叠，也防止并发开多个 CDP 连接
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop = False
        self._task = asyncio.create_task(self._loop())
        log.info("scheduler started (interval=%ss)", self.interval)

    async def stop(self) -> None:
        self._stop = True
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except Exception:
                pass
            self._task = None
        log.info("scheduler stopped")

    async def _loop(self) -> None:
        while not self._stop:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.exception("scheduler tick failed: %s", e)
            await asyncio.sleep(self.interval)

    async def tick(self) -> int:
        """执行到点的排期。返回启动的任务数。

        **总闸（最高优先级）**：
            schedule.rules.autoEnabled=false 或 manualOnly=true 时，
            tick 直接返回 0，不碰任何排期，不碰 FB。
            用户要求「全部改手动」时靠这个开关保证绝不自动发布。

        expireMin（默认 180 分钟）：排期时间超过这么多分钟仍未执行，
        **转为手动发布**（不回队列、不丢弃），理由：
            · 用户关软件几小时后重开，不该一次性涌出十几条旧排期
              （那是明显的非人类行为，极易触发风控）
            · 但素材是辛苦抓+切的，不能浪费 → 转 missed 后仍留在队列里，
              用户在「发布中心 → 待手动」能看到，挑合适的时机自己发
        设 expireMin=0 可关闭此限制（全部按时补发）。

        状态流转：
            planned --(到点)--> running --> done（成功）
            planned --(超时)--> missed（转手动，素材保留在队列 ready）
            planned --(失败)--> blocked（素材回队列 ready，可重试）
        """
        R = {**(db.get_kv("schedule.rules") or {})}

        # ---- 总闸：关闭时完全不动作 ----
        if R.get("manualOnly") or R.get("autoEnabled") is False:
            # 顺手把「到点但没发」的排期标成 missed（不发布，只标记）
            return 0

        delete_after = R.get("deleteAfterPublish", True)
        expire_min = int(R.get("expireMin", 180))
        to_manual = R.get("expireToManual", True)   # 超时是否转手动

        now = datetime.now()
        horizon = (now + timedelta(minutes=1)).strftime("%H:%M")
        today = now.strftime("%Y-%m-%d")

        due = db.q(
            "SELECT * FROM schedule WHERE state='planned' AND date=? AND time<=?",
            (today, horizon))

        # 过期检查：超出 expireMin 的转手动（不自动补发）
        if expire_min > 0:
            expired = []
            for s in due:
                try:
                    t = s["time"]
                    h, m = t.split(":")[:2]
                    sched_dt = now.replace(hour=int(h), minute=int(m),
                                           second=0, microsecond=0)
                    if (now - sched_dt).total_seconds() > expire_min * 60:
                        expired.append(s)
                except Exception:
                    continue
            for s in expired:
                if to_manual:
                    # 转手动：排期标 missed，素材退回队列 ready（可手动发）
                    db.exec("UPDATE schedule SET state='missed',note=? WHERE id=?",
                            (f"超时 {expire_min} 分钟，已转手动发布", s["id"]))
                    if s["queue_id"]:
                        db.exec("UPDATE queue SET state='ready' WHERE id=?",
                                (s["queue_id"],))
                    db.log_event("warn", "schedule",
                                 f"{s['page']} {s['time']} 超时 → 转手动发布"
                                 f"（素材保留，可在发布中心手动发）")
                else:
                    db.exec("UPDATE schedule SET state='missed',note=? WHERE id=?",
                            (f"超过 {expire_min} 分钟未执行，跳过补发", s["id"]))
                    db.log_event("warn", "schedule",
                                 f"{s['page']} {s['time']} 已过期 {expire_min} 分钟，"
                                 f"标记 missed（不补发）")
            due = [s for s in due if s not in expired]

        started = 0
        todo: list[tuple] = []
        for s in due:
            q = db.q1("SELECT * FROM queue WHERE id=?", (s["queue_id"],)) if s["queue_id"] else None
            if not q:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("缺少素材", s["id"]))
                db.log_event("warn", "schedule", f"{s['page']} {s['time']} 缺少素材")
                continue
            path = Path(q["path"])
            if not path.exists():
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("素材文件不存在", s["id"]))
                db.log_event("warn", "schedule", f"{q['file']} 不存在")
                continue

            # 主页查找：排期里可能存的是主页名（Y01）也可能是 page_id
            # （数字 ID）。必须两种都能匹配，否则整批排期会卡在「主页不存在」
            page = db.q1(
                "SELECT * FROM pages WHERE page_id=? OR name=?", (s["page"], s["page"]))
            if not page:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("主页不存在", s["id"]))
                continue
            if page["health"] != "ok":
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        (f"主页状态 {page['health']}", s["id"]))
                db.log_event("warn", "schedule",
                             f"{page['name']} 受限，跳过 {s['time']} 排期")
                continue
            if not page["asset_id"]:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("缺少 asset_id", s["id"]))
                continue

            env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
            if not env:
                db.log_event("warn", "schedule", "发布号环境未启动，排期等待")
                continue

            db.exec("UPDATE schedule SET state='running' WHERE id=?", (s["id"],))
            db.exec("UPDATE queue SET state='publishing' WHERE id=?", (q["id"],))
            todo.append((s, q, page, env))
            started += 1

        # **串行发布**：一个 CDP 连接一个浏览器，同时开 18 个任务
        # 必然 CDP handshake 超时（实测 Page.enable / Runtime.enable timeout）。
        # 用一个后台队列顺序跑，每条发布完再下一条。
        if todo:
            async with self._lock:
                for s, q, page, env in todo:
                    try:
                        await self._publish_one(s, q, page, env, delete_after)
                    except Exception as e:
                        log.exception("serial publish failed: %s", e)
                        db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                                (f"{type(e).__name__}: {e}"[:120], s["id"]))
                        db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
                    await asyncio.sleep(8)   # 两条之间间隔，模拟人操作节奏
        return started

    async def _publish_one(self, sched: dict, q: dict, page: dict,
                           env: dict, delete_after: bool) -> None:
        from app.adapters.facebook import FB, FBError
        from app.config import settings
        try:
            async with FB(int(env["cdp_port"])) as fb:
                await fb.assert_identity(settings.fb_publisher_cuser)
                caption = self._caption(page, q)
                # 先切主页身份（校验发布位置）
                label = page["name"]
                res = await fb.publish_reel(page["asset_id"], q["path"], caption, label)
            if res.get("ok"):
                db.exec("UPDATE schedule SET state='done',note=? WHERE id=?",
                        (res.get("acceptance"), sched["id"]))
                db.exec("UPDATE queue SET state='done' WHERE id=?", (q["id"],))
                db.exec("UPDATE pages SET published=published+1 WHERE page_id=?",
                        (page["page_id"],))
                db.log_event("ok", "schedule",
                             f"{page['name']} 发布成功 · {res.get('acceptance')}")
                if delete_after:
                    try:
                        Path(q["path"]).unlink()
                        db.exec("DELETE FROM queue WHERE id=?", (q["id"],))
                        db.log_event("ok", "schedule", f"素材已删 {q['file']}")
                    except Exception as e:
                        log.debug("unlink failed: %s", e)
            else:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        (res.get("error"), sched["id"]))
                db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
                db.log_event("err", "schedule",
                             f"{page['name']} 发布失败: {res.get('error')}")
        except FBError as e:
            db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                    (str(e)[:120], sched["id"]))
            db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
            db.log_event("err", "schedule", f"{page['name']}: {e}")
        except Exception as e:
            log.exception("publish one failed")
            db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                    (f"{type(e).__name__}: {e}"[:120], sched["id"]))
            db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))

    @staticmethod
    def _caption(page: dict, q: dict) -> str:
        """排期自动发布的文案——**和手动发布共用同一套逻辑**。

        之前的实现有两个严重问题：
            ① 没有推广链接（用户硬规则：发文必带链接）
            ② 剧名带 `_<cid>` 后缀，直接发出去很难看
        现在统一走 caption 服务：随机标题 + 随机链接 + 按平台加标签。
        平台默认 FB（不加标签），切到 TK 才带 #pinedrama 那套。
        """
        from app.services import caption as cap
        from app.services import platform_cfg as pc

        drama = q.get("drama") or page.get("drama") or ""
        # 去掉取自抓取目录的 _<纯数字cid> 后缀
        if "_" in drama:
            tail = drama.rsplit("_", 1)[-1]
            if tail.isdigit() and len(tail) >= 10:
                drama = drama.rsplit("_", 1)[0]
        ep = q.get("ep") or ""

        # 标题：优先用标题池随机（按主页），退回剧名
        title = ""
        try:
            picked = cap.pick_caption(page.get("page_id") or "", "")
            title = (picked or {}).get("title") or ""
        except Exception:
            title = ""
        if not title:
            title = f"{drama} {ep}".strip() or cap.REFERENCE_TITLE

        # 链接：按主页随机，避开最近用过的
        link = None
        try:
            link = cap.pick_link(page.get("page_id") or "")
        except Exception:
            link = None

        # 组装：标题 + 链接 (+ 平台标签)
        return pc.build_body(title, (link or {}).get("url") or "")



scheduler = Scheduler()
