# -*- coding: utf-8 -*-
"""
mcp_server.py — 把工作台暴露成 MCP 服务，让外部 Agent 直接操作

设计（按 MCP 2.x 规范 + 2026-07-28 最佳实践）：
  ① stateless：状态不挂连接，长任务用 job_id handle
  ② 工具名 snake_case，1-128 字符
  ③ inputSchema 用 JSON Schema
  ④ 失败返回 isError + 可操作消息
  ⑤ 工具列表静态，不随连接变化

挂载方式（main.py）：
    from app.mcp_server import mcp
    app.mount("/mcp", mcp.streamable_http_app())

外部 agent 连接：
    {"mcpServers": {"yuhai": {"url": "http://127.0.0.1:PORT/mcp",
                              "transport": "streamable-http"}}}
"""
from __future__ import annotations

import json
import logging

from mcp.server.mcpserver import MCPServer

log = logging.getLogger("yuhai.mcp")

mcp = MCPServer(
    name="yuhai-workbench",
    title="雨海工作台",
    description="短剧运营工作台：抓取、切片、发布、数据分析",
    instructions=(
        "这是短剧运营工作台。常用流程：\n"
        "1. slice_env_check 先看环境是否就绪\n"
        "2. slice_list_dramas 看有哪些剧可切\n"
        "3. slice_run 开始切片（返回 job_id）\n"
        "4. slice_status(job_id) 查进度\n"
        "5. slice_result 拿成片列表\n"
        "\n"
        "抓取：grab_search 找剧 → grab_download 下载\n"
        "发布：publish_reels 发到 Facebook Reels\n"
        "记忆：memory_set / memory_get 记住跨会话状态"
    ),
    version="1.0.0",
)


def _ok(**kw):
    return {"ok": True, **kw}


def _err(msg: str, **kw):
    return {"ok": False, "error": msg, **kw}


# ═══════════════════════════════════════════════
#  切片
# ═══════════════════════════════════════════════
@mcp.tool(description="环境自检：Python包/FFmpeg/ASR模型/脚本/GPU/代理")
def slice_env_check() -> dict:
    from app.services import envcheck
    r = envcheck.full_check()
    return _ok(
        ready=r["ok"],
        python_ok=all(p["ok"] for p in r["python"] if p["required"]),
        ffmpeg=r["ffmpeg"]["ok"],
        nvenc=r["ffmpeg"].get("nvenc"),
        model={"ok": r["model"]["ok"], "name": r["model"]["name"],
               "sizeMb": r["model"].get("sizeMb")},
        tools={"ok": r["tools"]["ok"],
               "stale": len(r["tools"].get("stale") or [])},
        gpu={"name": r["gpu"].get("name"), "cuda": r["gpu"].get("cuda")},
        warnings=r["warnings"],
        fixable=[f["what"] for f in (r.get("fixable") or [])],
    )


@mcp.tool(description="修环境。what: all|python|ffmpeg|whisper|tools|cuda")
def slice_env_install(what: str = "all") -> dict:
    from app.services import envcheck
    r = envcheck.install_one(what)
    return _ok(what=what, ok=r.get("ok"),
               note=r.get("note") or r.get("error") or "")


@mcp.tool(description="列出所有短剧及处理状态（哪些能切、切到哪一步）")
def slice_list_dramas() -> dict:
    from app.services import slicing as sl
    items = sl.list_dramas()
    out = []
    for d in items:
        st = d.get("steps") or {}
        out.append({
            "drama": d["drama"],
            "title": d.get("title"),
            "sourceEpisodes": d.get("sourceEpisodes") or 0,
            "hasSource": d.get("hasSource"),
            "state": d.get("state"),
            "transcribed": bool((st.get("transcribe") or {}).get("done")),
            "segments": (st.get("transcribe") or {}).get("segments") or 0,
            "type": (st.get("classify") or {}).get("typeName") or "",
            "tensionSegs": (st.get("tension") or {}).get("segments") or 0,
            "singles": (st.get("single") or {}).get("count") or 0,
            "premiums": (st.get("premium") or {}).get("count") or 0,
        })
    return _ok(count=len(out), items=out)


@mcp.tool(description="开始切片。mode: single（单集）|premium（精品）|all。返回 job_id，用 slice_status 查进度")
def slice_run(drama: str, mode: str = "all", eps: str = "",
              target: int = 45) -> dict:
    from app.services import slicing as sl
    import uuid
    job_id = "mcp-" + uuid.uuid4().hex[:10]
    eps_list = [e.strip() for e in eps.split(",") if e.strip()] if eps else None

    try:
        result = {}
        if mode in ("single", "all"):
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
        if mode in ("premium", "all"):
            result["premium"] = sl.step_premium(job_id, drama)
        return _ok(job_id=job_id, drama=drama, mode=mode, result=result,
                   hint=f"用 slice_status('{job_id}') 查详情")
    except Exception as e:
        return _err(f"切片失败: {str(e)[:120]}", drama=drama)


@mcp.tool(description="查 job 进度")
def slice_status(job_id: str) -> dict:
    from app.db import db
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        return _err(f"没有这个 job: {job_id}", available_hint="用 slice_run 创建")
    return _ok(
        id=r["id"], kind=r.get("kind"), status=r.get("status"),
        progress=r.get("progress"),
        steps=json.loads(r.get("steps") or "[]"),
        result=json.loads(r.get("result") or "{}") if r.get("result") else {},
        error=r.get("error") or "",
    )


@mcp.tool(description="列出成片（单集/精品）")
def slice_result(drama: str = "") -> dict:
    from app import paths
    out = []
    for pat in ("单集_*", "精品混剪_*"):
        for d in paths.output_root().glob(pat):
            if not d.is_dir():
                continue
            for sub in d.iterdir():
                if not sub.is_dir():
                    continue
                if drama and drama.lower() not in sub.name.lower():
                    continue
                vids = [f for f in sub.glob("*.mp4")]
                if not vids:
                    continue
                out.append({
                    "kind": "single" if "单集" in pat else "premium",
                    "drama": sub.name,
                    "date": d.name.split("_")[-1],
                    "count": len(vids),
                    "files": [{"name": f.name,
                               "mb": round(f.stat().st_size / 1048576, 1)}
                              for f in vids[:20]],
                })
    return _ok(count=len(out), items=out)


@mcp.tool(description="校验成片：台词完整/无重叠/无静音")
def slice_verify(video_path: str) -> dict:
    from app.services import slicing as sl
    try:
        return _ok(**sl.verify_output(video_path))
    except Exception as e:
        return _err(f"校验失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  抓取
# ═══════════════════════════════════════════════
@mcp.tool(description="搜剧（按关键词），返回剧名/集数/cid")
def grab_search(keyword: str, limit: int = 15) -> dict:
    from app.services import grab as g
    try:
        r = g.search(keyword) if hasattr(g, "search") else {}
        if not r:
            r = g.hot_list() if hasattr(g, "hot_list") else {}
        items = (r.get("items") or r.get("collections") or [])[:limit]
        return _ok(keyword=keyword, count=len(items), items=items)
    except Exception as e:
        return _err(f"搜索失败: {str(e)[:100]}")


@mcp.tool(description="下载剧集。cid 来自 grab_search；eps 如 '1-10'")
def grab_download(cid: str, eps: str = "1-10") -> dict:
    from app.services import grab as g
    try:
        r = g.download(cid, eps) if hasattr(g, "download") else {}
        return _ok(cid=cid, result=r)
    except Exception as e:
        return _err(f"下载失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  素材 / 成片
# ═══════════════════════════════════════════════
@mcp.tool(description="列素材库")
def library_list(limit: int = 50) -> dict:
    from app.api import library as lib
    try:
        r = lib.list_items(limit=limit) if hasattr(lib, "list_items") else None
        if r is None:
            from app.services import slicing as sl
            ds = sl.list_dramas()
            return _ok(count=len(ds), items=ds[:limit])
        return _ok(**r) if isinstance(r, dict) else _ok(items=r)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  发布
# ═══════════════════════════════════════════════
@mcp.tool(description="发布视频到 Facebook Reels")
def publish_reels(video_path: str, page_id: str = "",
                  caption: str = "") -> dict:
    from app.services import reels as rl
    try:
        if hasattr(rl, "publish"):
            r = rl.publish(video_path, page_id, caption)
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        return _err("发布模块未提供 publish 接口")
    except Exception as e:
        return _err(f"发布失败: {str(e)[:120]}")


@mcp.tool(description="查可发布的主页列表")
def publish_pages() -> dict:
    from app.services import reels as rl
    try:
        plan = rl.plan_pages() if hasattr(rl, "plan_pages") else []
        return _ok(count=len(plan), pages=plan)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  系统
# ═══════════════════════════════════════════════
@mcp.tool(description="系统健康检查")
def system_health() -> dict:
    from app.db import db
    from app.services import envcheck
    e = envcheck.full_check()
    return _ok(ready=e["ok"], warnings=e["warnings"],
               gpu=e["gpu"].get("name"),
               cuda=e["gpu"].get("cuda"))


@mcp.tool(description="读最近日志")
def system_logs(limit: int = 30) -> dict:
    from app.db import db
    rows = db.q("""SELECT ts, level, source, msg FROM events
                   ORDER BY rowid DESC LIMIT ?""", (limit,))
    return _ok(count=len(rows), items=[dict(r) for r in rows])


# ═══════════════════════════════════════════════
#  记忆（跨会话）
# ═══════════════════════════════════════════════
@mcp.tool(description="写记忆（跨会话保留）。常用键：current_drama / preference / last_step")
def memory_set(key: str, value: str) -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.set(key, value))


@mcp.tool(description="读记忆")
def memory_get(key: str) -> dict:
    from app.services import agent_memory as mem
    r = mem.get(key)
    if not r.get("ok"):
        return _err(r.get("error") or "没有这个键", key=key)
    return _ok(key=r["key"], value=r["value"], updatedAt=r["updatedAt"])


@mcp.tool(description="列出所有记忆")
def memory_list() -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.list_all())


# ═══════════════════════════════════════════════
#  Agent 自身的模型信息
# ═══════════════════════════════════════════════
@mcp.tool(description="列出当前接入 Agent 的模型（含可用性）")
def agent_models() -> dict:
    from app.services import agent_models as am
    o = am.overview()
    return _ok(connected=o["connected"], name=o["name"],
               models=[{"id": m["id"], "role": m.get("role"),
                        "tested": bool((m.get("test") or {}).get("at")),
                        "ok": (m.get("test") or {}).get("ok")}
                       for m in (o["visible"] or [])])


_APP_CACHE = None


def get_app():
    """返回挂到 FastAPI 的 Starlette 应用（**单例**）。

    必须单例：lifespan 里启动的 session manager 与挂载的 app
    必须是同一个对象，否则 streamable-http 会报
    "Task group is not initialized"。
    """
    global _APP_CACHE
    if _APP_CACHE is None:
        _APP_CACHE = mcp.streamable_http_app(
            streamable_http_path="/", stateless_http=True)
    return _APP_CACHE


# 全功能工具（账号/主页/授权/发布/失败诊断等）在 mcp_tools_full 里注册
try:
    from app.mcp_tools_full import register as _register_full
    _register_full(mcp)
    log.info("mcp_tools_full registered")
except Exception as _e:
    log.warning("mcp_tools_full register failed: %s", _e)
