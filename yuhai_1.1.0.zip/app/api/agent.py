# -*- coding: utf-8 -*-
"""Agent 接入 API：检测 / 连接 / 模型清单 / 开关 / 可用性实测。"""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

log = logging.getLogger("yuhai.api.agent")
router = APIRouter()


# ---------------- 检测 ----------------
@router.get("/agent/detect")
async def agent_detect(deep: bool = False):
    """检测本机 Agent。deep=true 才做多盘一级扫描。"""
    from app.services import agent_detect as ad
    r = await asyncio.to_thread(ad.detect_all)
    if deep:
        d = await asyncio.to_thread(ad.deep_scan)
        r["deep"] = d
    return r


@router.post("/agent/deep-scan")
async def agent_deep_scan():
    """深度扫描（用户主动点，会慢）。"""
    from app.services import agent_detect as ad
    return await asyncio.to_thread(ad.deep_scan)


# ---------------- 连接 ----------------
class ConnectReq(BaseModel):
    agentId: str


@router.post("/agent/connect")
async def agent_connect(req: ConnectReq):
    """接入某个 agent（之后只显示它的模型）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.connect, req.agentId)


@router.get("/agent/overview")
async def agent_overview():
    """首屏：当前接入 + 模型清单 + 可切换列表。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.overview)


# ---------------- 模型开关 ----------------
class HideReq(BaseModel):
    agentId: str
    modelId: str
    hidden: bool = True


@router.post("/agent/model/hide")
async def agent_hide(req: HideReq):
    """隐藏/显示单个模型。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.set_hidden, req.agentId,
                                   req.modelId, req.hidden)


class HideChannelReq(BaseModel):
    agentId: str
    channel: str
    hidden: bool = True


@router.post("/agent/model/hide-channel")
async def agent_hide_channel(req: HideChannelReq):
    """按渠道批量隐藏（如 our-free-model 一次全隐）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.hide_channel, req.agentId,
                                   req.channel, req.hidden)


# ---------------- 可用性实测 ----------------
class TestReq(BaseModel):
    agentId: str
    modelId: str


@router.post("/agent/model/test")
async def agent_test(req: TestReq):
    """实测一个模型能不能用（真发一次请求）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_one, req.agentId, req.modelId)


class TestAllReq(BaseModel):
    agentId: str
    limit: int = 0


@router.post("/agent/model/test-all")
async def agent_test_all(req: TestAllReq):
    """批量实测（顺序跑，慢）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_all, req.agentId, req.limit)


# ---------------- 记忆 ----------------
@router.get("/agent/memory")
async def agent_memory_list():
    """Agent 跨会话记忆（读）。"""
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.list_all)


class MemSetReq(BaseModel):
    key: str
    value: str


@router.post("/agent/memory")
async def agent_memory_set(req: MemSetReq):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.set, req.key, req.value)


@router.delete("/agent/memory/{key}")
async def agent_memory_del(key: str):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.delete, key)


# ---------------- 对话（用 Agent 自己的模型） ----------------
class ChatReq(BaseModel):
    message: str
    history: list = []
    autoRunTools: bool = True


@router.post("/agent/chat")
async def agent_chat(req: ChatReq):
    """用当前接入 Agent 的模型对话，可调用工具操作工作台。"""
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.chat, req.message, req.history,
                                   req.autoRunTools)


@router.get("/agent/chat/test")
async def agent_chat_test():
    """自检：当前 agent 的模型能不能对话。"""
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.quick_test)


@router.get("/agent/tools")
async def agent_tools():
    """MCP 工具清单（给前端展示 + 供外部 agent 参考）。"""
    from app.services import agent_chat as ac
    specs = await asyncio.to_thread(ac.tool_specs)
    return {"ok": True, "count": len(specs),
            "items": [{"name": s["function"]["name"],
                       "description": s["function"]["description"]}
                      for s in specs]}


# ---------------- MCP 接入信息 ----------------
@router.get("/agent/mcp")
async def agent_mcp():
    """MCP 服务地址 + 外部 Agent 接入配置示例。"""
    import os
    from app.config import settings
    from app.mcp_server import mcp as M
    port = int(os.environ.get("YUHAI_PORT", settings.port))
    tools = await M.list_tools()
    return {
        "ok": True,
        "url": f"http://127.0.0.1:{port}/mcp/",
        "transport": "streamable-http",
        "count": len(tools),
        "tools": [{"name": t.name, "description": t.description}
                  for t in tools],
        "config_example": {
            "mcpServers": {
                "yuhai": {
                    "url": f"http://127.0.0.1:{port}/mcp/",
                    "transport": "streamable-http",
                }
            }
        },
    }
