/* 发布中心（重写版）
   一条链路：选主页 → 选素材 → 设参数 → 发布
   文案：多标题随机（按主页从变体池抽）或固定模板
   平台：固定 Facebook（TK 后续再加）
   底层：ReelsPublisher 内核（回执校验 / 断点续跑 / 失败不删素材）  */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, nfmt, ts, emptyState,
} from '../ui.js';

/* ---------------- 状态 ---------------- */
let selPages = new Set();
let selFiles = new Set();
let runningJob = '';
let showAdvanced = false;      // 高级选项（链接池 / 目录）
let titleMode = 'random';      // random | fixed
let lastResult = null;

let reelsData = { ok: false, version: '', planPages: 0, pages: [] };
let reelsPages = { items: [], total: 0, usable: 0 };
let reelsFiles = { items: [], total: 0, mixCount: 0 };
let tplData = { items: [], vars: {}, default: '' };
let variants = [];
let linksData = [];
let poolInfo = { count: 0, sources: {}, items: [] };

/* ---------------- 入口 ---------------- */
export function render(root) {
  root.innerHTML = `
    ${pageHead({
    title: '发布中心',
    desc: '选主页 → 选素材 → 设参数 → 发布。素材发布成功后自动删除。',
    actions: [
      `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
    ],
  })}
    <div id="pb-body"></div>
  `;
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  root.querySelector('#pb-body').innerHTML = `<div class="card"><div class="card-body">
    <div style="padding:28px;text-align:center;color:var(--tx-3);font-size:11px">正在读取内核与素材…</div>
  </div></div>`;
  load(root);
}

async function load(root) {
  try {
    const results = await Promise.allSettled([
      api.reelsStatus(),
      api.reelsPages(),
      api.reelsFiles(),
      api.captionTemplates(),
      api.captionVariants(),
      api.links(),
      api.captionPool(''),
    ]);
    if (results[0].status === 'fulfilled') reelsData = results[0].value || reelsData;
    if (results[1].status === 'fulfilled') reelsPages = results[1].value || reelsPages;
    if (results[2].status === 'fulfilled') reelsFiles = results[2].value || reelsFiles;
    if (results[3].status === 'fulfilled') tplData = results[3].value || tplData;
    if (results[4].status === 'fulfilled') variants = (results[4].value || {}).items || [];
    if (results[5].status === 'fulfilled') linksData = (results[5].value || {}).items || [];
    if (results[6] && results[6].status === 'fulfilled') poolInfo = results[6].value || poolInfo;
  } catch (e) {
    toast('读取失败', e.message, 'err');
  }
  paint(root);
}

/* ---------------- 视图 ---------------- */
function paint(root) {
  const body = $('#pb-body', root);
  if (!body) return;

  const pages = reelsPages.items || [];
  const files = reelsFiles.items || [];
  const usablePages = pages.filter((p) => p.selectable);
  const nPages = selPages.size || usablePages.length;
  const _sel = computeSelectedFiles();
  const nFiles = _sel.files.length;
  const clipsPerPage = Number(($('#rl-clips', root) || {}).value) || 1;
  const need = nPages * clipsPerPage;
  const enough = nFiles >= need;
  const kernelOk = !!reelsData.ok;
  const canRun = kernelOk && nPages > 0 && nFiles > 0 && enough && !runningJob;

  body.innerHTML = `
    ${summaryBar({ nPages, nFiles, need, enough, kernelOk, clipsPerPage })}
    ${stepPages(pages, usablePages)}
    ${stepFiles(files)}
    ${stepParams({ need, enough, clipsPerPage })}
    ${stepCaption()}
    ${actionBar({ canRun, kernelOk, nPages, nFiles, need, enough })}
    ${advancedBlock()}
    <div id="rl-out"></div>
    ${lastResult ? resultBlock(lastResult) : ''}
  `;

  bindAll(root);
}

/* 顶部数字条 */
function summaryBar({ nPages, nFiles, need, enough, kernelOk, clipsPerPage }) {
  const short = need > nFiles;
  return `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '已选主页', value: nPages, unit: '个', iconName: 'layers' })}
      ${statCard({ label: '已选素材', value: nFiles, unit: '条', iconName: 'film' })}
      ${statCard({
    label: '本轮需要', value: need, unit: '条', iconName: 'check',
    foot: short ? `<span style="color:var(--danger)">还差 ${need - nFiles} 条</span>` : `每主页 ${clipsPerPage} 条`,
  })}
      ${statCard({
    label: '内核', value: kernelOk ? '就绪' : '不可用', unit: '',
    iconName: 'bolt', foot: kernelOk ? esc(reelsData.version || '') : '检查 ReelsPublisher 路径',
  })}
    </div>`;
}

/* 步骤 1：主页 */
function stepPages(pages, usablePages) {
  const allSelected = usablePages.length > 0 && selPages.size === 0;
  return `
    <div class="card" style="margin-bottom:11px">
      <div class="card-head">
        <div class="card-title"><span class="step-no">1</span> 选择主页
          <span class="badge mute" style="margin-left:6px;font-size:9px">
            ${selPages.size ? `已选 ${selPages.size}` : `默认全部 ${usablePages.length}`}</span>
        </div>
        <div style="display:flex;gap:5px">
          <button class="btn xs ghost" id="rl-pages-all">全选</button>
          <button class="btn xs ghost" id="rl-pages-none">清空</button>
        </div>
      </div>
      <div class="card-body">
        ${pages.length ? `
          <div class="pick-grid">
            ${pages.map((p) => `
              <label class="pick-chip ${p.selectable ? '' : 'off'} ${selPages.has(p.pageId) ? 'on' : ''}">
                <input type="checkbox" data-page="${esc(p.pageId)}"
                       ${selPages.has(p.pageId) ? 'checked' : ''}
                       ${p.selectable ? '' : 'disabled'} />
                <span>${esc(p.pageName || p.pageId || '—')}</span>
              </label>`).join('')}
          </div>` : emptyState('没有可发布的主页', '先在「指纹浏览器」里登录并获取主页')}
      </div>
    </div>`;
}

/* 步骤 2：按「剧 → 集」组织素材（符合真实发布流程）
 *
 * 发布流程是「一部剧 → 发到某个主页 → 该剧选 N 集」，
 * 不是「从 300 个平铺文件里勾几条」。
 * 所以这里按 video.title（= 所在文件夹名 = 剧名）分组。
 */

/* 把文件列表按剧名分组 */
function groupByDrama(files) {
  const g = {};
  for (const f of (files || [])) {
    // title 由后端从文件夹名取；没有就用路径推
    let t = f.title || '';
    if (!t) {
      const parts = String(f.path || '').replace(/\\/g, '/').split('/');
      t = parts.length >= 2 ? parts[parts.length - 2] : '未归类';
    }
    if (!g[t]) g[t] = [];
    g[t].push(f);
  }
  return g;
}

/* 估算剧名（去序号前缀/去tkId/下划线转空格） */
function cleanDramaName(name) {
  let s = String(name || '').trim();
  s = s.replace(/^\\d+[_\\.\\-\\s]+/, '');
  s = s.replace(/[_\\-][0-9]{15,}$/, '');
  s = s.replace(/[ _\\-](ITA|CN|EN|v\\d+)$/i, '');
  s = s.replace(/_/g, ' ').replace(/\\s{2,}/g, ' ').trim();
  return s || name || '未命名';
}

/* 当前每主页发几条 */
function curClips() {
  const el = document.getElementById('rl-clips');
  const v = el ? parseInt(el.value, 10) : (window._pbClips || 6);
  return Number.isFinite(v) && v >= 1 ? Math.min(v, 20) : 6;
}

/* 每部剧想发几条：存在 window._dramaPick = {剧名: 条数} */
function dramaPick() {
  if (!window._dramaPick) window._dramaPick = {};
  return window._dramaPick;
}

function stepFiles(files) {
  const groups = groupByDrama(files);
  const names = Object.keys(groups).sort((a, b) => {
    return groups[b].length - groups[a].length;
  });
  const pick = dramaPick();
  const clips = curClips();

  // 已选统计
  let pickedDramas = 0;
  let pickedFiles = 0;
  for (const nm of names) {
    const n = pick[nm] || 0;
    if (n > 0) {
      pickedDramas += 1;
      pickedFiles += Math.min(n, groups[nm].length);
    }
  }

  // 没选择时：按默认规则（每剧最多 clips 条，但不足就全用）
  const autoUsed = !pickedDramas;
  if (autoUsed) {
    for (const nm of names) {
      pickedFiles += Math.min(clips, groups[nm].length);
    }
  }

  return `
    <div class="card" style="margin-bottom:11px">
      <div class="card-head">
        <div class="card-title"><span class="step-no">2</span> 选择剧集
          <span class="badge mute" style="margin-left:6px;font-size:9px">
            ${pickedDramas ? `已选 ${pickedDramas} 部 / ${pickedFiles} 集`
      : `未选（默认每部最多 ${clips} 集）`}</span>
          ${reelsFiles.mixCount ? `<span class="badge warn" style="font-size:9px;margin-left:4px">${reelsFiles.mixCount} 条混剪已排除</span>` : ''}
        </div>
        <div style="display:flex;gap:5px;align-items:center">
          <input class="input" id="rl-clips-top" type="number" value="${clips}"
                 min="1" max="20" style="width:58px;padding:2px 6px;font-size:10px"
                 title="每部剧发几集" />
          <span style="font-size:9px;color:var(--tx-3)">集/剧</span>
          <button class="btn xs" id="rl-files-auto">按此集数套用</button>
          <button class="btn xs ghost" id="rl-files-none">清空</button>
        </div>
      </div>
      <div class="card-body">
        ${names.length ? `
          <div class="drama-list">
            ${names.map((nm) => {
        const arr = groups[nm];
        const total = arr.length;
        const n = pick[nm] || 0;
        const on = n > 0;
        const short = total < clips;
        const en = cleanDramaName(nm);
        const needEn = /[\u4e00-\u9fff]/.test(en);
        return `
                <div class="drama-row ${on ? 'on' : ''}" data-drama="${esc(nm)}">
                  <label class="drama-chk">
                    <input type="checkbox" data-drama-cb="${esc(nm)}"
                           ${on ? 'checked' : ''} />
                  </label>
                  <div class="drama-main">
                    <div class="drama-name">${esc(en)}</div>
                    <div class="drama-sub">
                      ${total} 集${short ? ` <span style="color:var(--danger)">（不足 ${clips} 集）</span>` : ''}
                      ${needEn ? ' <span style="color:#fbbf24">· 中文剧名</span>' : ''}
                    </div>
                  </div>
                  <div class="drama-num">
                    <input class="input" type="number" data-drama-n="${esc(nm)}"
                           value="${n || Math.min(clips, total)}"
                           min="1" max="${Math.min(20, total)}"
                           style="width:52px;padding:2px 5px;font-size:10px"
                           ${on ? '' : 'disabled'} />
                    <span class="drama-unit">集</span>
                  </div>
                </div>`;
      }).join('')}
          </div>` : emptyState('没有可用素材', '在「素材库」或「短剧切片」里准备好素材')}
      </div>
    </div>`;
}

/* 步骤 3：参数 */
function stepParams({ need, enough, clipsPerPage }) {
  return `
    <div class="card" style="margin-bottom:11px">
      <div class="card-head">
        <div class="card-title"><span class="step-no">3</span> 发布参数</div>
      </div>
      <div class="card-body">
        <div class="row-3">
          <div class="field">
            <label>每主页发几条</label>
            <input class="input" id="rl-clips" type="number" value="${clipsPerPage}" min="1" max="20" />
          </div>
          <div class="field">
            <label>并发环境数</label>
            <input class="input" id="rl-conc" type="number" value="1" min="1" max="5" />
          </div>
          <div class="field">
            <label>上传卡住容忍（秒）</label>
            <input class="input" id="rl-stall" type="number" value="180" min="60" max="3600" step="30" />
          </div>
        </div>
        <p class="hint ${enough ? '' : 'err'}">
          本轮需要 <b>${need}</b> 条素材${enough ? '，数量充足。' : `，当前只有 ${selFiles.size || reelsFiles.items.length} 条，还差 ${need - (selFiles.size || reelsFiles.items.length)} 条。`}
        </p>
      </div>
    </div>`;
}

/* 步骤 4：文案 */
function stepCaption() {
  const randomOn = titleMode === 'random';
  return `
    <div class="card" style="margin-bottom:11px">
      <div class="card-head">
        <div class="card-title"><span class="step-no">4</span> 文案来源</div>
        <div class="seg">
          <button class="seg-btn ${randomOn ? 'on' : ''}" data-mode="random">多标题随机</button>
          <button class="seg-btn ${randomOn ? '' : 'on'}" data-mode="fixed">固定模板</button>
        </div>
      </div>
      <div class="card-body">
        ${randomOn ? `
          <p class="hint ${poolInfo.count ? 'ok' : 'err'}">
            每个主页从「标题池」里各抽一条独立标题，链接从链接池按主页随机，避开最近用过的。
            当前可用标题 <b>${poolInfo.count}</b> 条
            ${poolInfo.sources?.variant ? `（变体 ${poolInfo.sources.variant}` : ''}
            ${poolInfo.sources?.pool ? `${poolInfo.sources?.variant ? ' + ' : '（'}旧池 ${poolInfo.sources.pool}` : ''}
            ${poolInfo.count ? '）' : ''}
            · 链接 <b>${linksData.length}</b> 条。
          </p>
          ${poolInfo.count === 0 ? `
            <div class="hint err" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span>标题池为空，发布时会自动用大模型补一批。</span>
              <button class="btn xs primary" id="rl-genpool">立即生成标题</button>
            </div>` : `
            <button class="btn xs ghost" id="rl-genpool" style="margin-top:6px">再补一批标题</button>`}
          <div class="field" style="margin-top:8px">
            <label>参考标题（变体池为空时的兜底）</label>
            <input class="input" id="rl-ref" value="${esc(tplData.default || '')}"
                   placeholder="留空则用系统默认英文钩子标题" />
          </div>` : `
          <div class="field">
            <label>固定标题模板（<code>{{DRAMA}}</code> = 剧名）</label>
            <textarea class="input" id="rl-desc" rows="4"
              style="font-family:var(--mono);font-size:11px;resize:vertical">${esc(tplData.default || '')}</textarea>
          </div>
          <p class="hint">所有主页共用这一段文案，剧名按素材所在文件夹自动替换。</p>`}
      </div>
    </div>`;
}

/* 操作条 */
function actionBar({ canRun, kernelOk, nPages, nFiles, need, enough }) {
  const reasons = [];
  if (!kernelOk) reasons.push('内核不可用');
  if (!nPages) reasons.push('未选主页');
  if (!nFiles) reasons.push('未选素材');
  if (nFiles && !enough) reasons.push(`素材不足（需 ${need}）`);

  return `
    <div class="card action-card" style="margin-bottom:11px">
      <div class="card-body" style="display:flex;align-items:center;gap:10px">
        <button class="btn primary" id="rl-go" ${canRun ? '' : 'disabled'}
          style="padding:9px 22px;font-size:12px">
          <span data-icon="send"></span> 开始发布
        </button>
        <button class="btn danger" id="rl-stop"
          style="display:${runningJob ? '' : 'none'}">停止</button>
        <button class="btn ghost sm" id="rl-check">检查环境</button>
        <span style="font-size:10px;color:${canRun ? 'var(--ok)' : 'var(--tx-3)'}">
          ${canRun ? `将发 ${nPages} 个主页 × ${(Number(($('#rl-clips') || {}).value) || 1)} 条` : reasons.join(' · ')}
        </span>
      </div>
    </div>`;
}

/* 高级选项 */
function advancedBlock() {
  return `
    <details class="adv" ${showAdvanced ? 'open' : ''}>
      <summary>高级选项（素材目录 / 链接池）</summary>
      <div class="adv-body">
        <div class="field">
          <label>链接池（每行一个，多标题随机模式下按主页随机取）</label>
          <textarea class="input" id="rl-links" rows="3"
            style="font-family:var(--mono);font-size:10.5px">${esc(linksData.map((x) => x.url).join('\n'))}</textarea>
        </div>
      </div>
    </details>`;
}

function resultBlock(r) {
  return `
    <div class="card" style="margin-bottom:11px">
      <div class="card-head"><div class="card-title">上次发布结果</div></div>
      <div class="card-body">
        <p class="hint ${r.ok ? 'ok' : 'err'}">${r.ok ? '✓ 完成' : '✗ 失败'}：${esc(r.note || '')}</p>
      </div>
    </div>`;
}

/* ---------------- 事件绑定 ---------------- */
function bindAll(root) {
  // 主页
  $$('[data-page]', root).forEach((cb) => {
    cb.onchange = () => {
      if (cb.checked) selPages.add(cb.dataset.page);
      else selPages.delete(cb.dataset.page);
      paint(root);
    };
  });
  const pa = document.getElementById('rl-pages-all');
  if (pa) pa.onclick = () => {
    reelsPages.items.forEach((p) => { if (p.selectable) selPages.add(p.pageId); });
    paint(root);
  };
  const pn = document.getElementById('rl-pages-none');
  if (pn) pn.onclick = () => { selPages.clear(); paint(root); };

  // 素材：按剧勾选 + 每剧集数
  $$('[data-drama-cb]', root).forEach((cb) => {
    cb.onchange = () => {
      const name = cb.dataset.dramaCb;
      const pick = dramaPick();
      if (cb.checked) {
        const groups = groupByDrama(reelsFiles.items);
        const total = (groups[name] || []).length;
        const clips = curClips();
        pick[name] = Math.min(clips, total);
      } else {
        delete pick[name];
      }
      paint(root);
    };
  });

  // 每剧集数输入
  $$('[data-drama-n]', root).forEach((inp) => {
    inp.onchange = () => {
      const name = inp.dataset.dramaN;
      const groups = groupByDrama(reelsFiles.items);
      const total = (groups[name] || []).length;
      let v = parseInt(inp.value, 10);
      if (!Number.isFinite(v) || v < 1) v = 1;
      if (v > total) v = total;
      const pick = dramaPick();
      pick[name] = v;
      inp.value = v;
      paint(root);
    };
  });

  // 「按此集数套用」：把顶部集数套给所有已勾的剧
  const applyBtn = document.getElementById('rl-files-auto');
  if (applyBtn) applyBtn.onclick = () => {
    const topEl = document.getElementById('rl-clips-top');
    const clips = topEl ? Math.max(1, Math.min(20, parseInt(topEl.value, 10) || 6)) : 6;
    window._pbClips = clips;
    const groups = groupByDrama(reelsFiles.items);
    const pick = dramaPick();
    const names = Object.keys(groups);
    if (Object.keys(pick).length === 0) {
      // 一部都没勾 → 全部按 clips 套
      for (const nm of names) {
        pick[nm] = Math.min(clips, groups[nm].length);
      }
    } else {
      for (const nm of Object.keys(pick)) {
        pick[nm] = Math.min(clips, (groups[nm] || []).length);
      }
    }
    paint(root);
    toast('已套用', `每部剧 ${clips} 集`, 'ok');
  };

  // 顶部集数变化 → 记住
  const topClips = document.getElementById('rl-clips-top');
  if (topClips) topClips.onchange = () => {
    let v = parseInt(topClips.value, 10);
    if (!Number.isFinite(v) || v < 1) v = 1;
    if (v > 20) v = 20;
    window._pbClips = v;
  };

  const fn = document.getElementById('rl-files-none');
  if (fn) fn.onclick = () => {
    window._dramaPick = {};
    paint(root);
  };

  // 条数变化 → 重新算需求
  const clips = document.getElementById('rl-clips');
  if (clips) clips.onchange = () => paint(root);

  // 文案模式
  $$('[data-mode]', root).forEach((b) => {
    b.onclick = () => { titleMode = b.dataset.mode; paint(root); };
  });

  // 一键生成标题
  const genpool = document.getElementById('rl-genpool');
  if (genpool) genpool.onclick = async () => {
    genpool.disabled = true;
    genpool.textContent = '生成中…';
    try {
      const r = await api.ensureCaptionPool({ want: 10 });
      toast('已生成标题',
        `新增 ${r.generated || 0} 条 · 现有 ${r.count || 0} 条（${r.source || '—'}）`, 'ok');
      await load(root);
    } catch (e) {
      toast('生成失败', e.message, 'err');
      genpool.disabled = false;
      genpool.textContent = '立即生成标题';
    }
  };

  // 检查环境
  const chk = document.getElementById('rl-check');
  if (chk) chk.onclick = async () => {
    chk.disabled = true;
    chk.textContent = '检查中…';
    const out = document.getElementById('rl-out');
    if (out) out.innerHTML = `<div class="card"><div class="card-body">
      <p class="hint">① 启动发布号浏览器 → ② 等待 CDP 就绪 → ③ 整理成一个 Meta 工作标签 → ④ 提取 asset_id</p>
      <p class="hint">全部自动完成，不需要手动点任何页面…</p>
    </div></div>`;
    try {
      const r = await api.reelsPrepare();
      if (out) out.innerHTML = `<div class="card"><div class="card-body">
        <p class="hint ok">✓ 环境就绪 · CDP ${esc(String(r.cdpPort))}${r.started ? '（已自动启动）' : ''}</p>
        <p class="hint">工作页 <b>${esc(r.pageName || '—')}</b> · asset ${esc(String(r.assetId || '—'))}</p>
      </div></div>`;
      toast('环境就绪', r.pageName || '', 'ok');
      // 自动刷新主页/素材列表，省掉手动再点一次
      try { reelsPages = await api.reelsPages(); } catch { /* ignore */ }
      try { reelsFiles = await api.reelsFiles(); } catch { /* ignore */ }
      paint(root);
    } catch (e) {
      if (out) out.innerHTML = `<div class="card"><div class="card-body"><p class="hint err">检查失败：${esc(e.message)}</p></div></div>`;
      toast('检查失败', e.message, 'err');
    } finally {
      chk.disabled = false;
      chk.textContent = '检查环境';
    }
  };

  // 停止
  const stop = document.getElementById('rl-stop');
  if (stop) stop.onclick = async () => {
    stop.disabled = true;
    stop.textContent = '停止中…';
    try {
      const r = await api.reelsStop(runningJob);
      toast('已停止', r.note || '', 'warn');
      runningJob = '';
      paint(root);
    } catch (e) {
      toast('停止失败', e.message, 'err');
      stop.disabled = false;
      stop.textContent = '停止';
    }
  };

  // 开始发布
  const go = document.getElementById('rl-go');
  if (go) go.onclick = () => confirmAndRun(root);
}

/* 按当前剧选择，算出实际要发的文件列表和总数 */
function computeSelectedFiles() {
  const groups = groupByDrama(reelsFiles.items);
  const pick = dramaPick();
  const names = Object.keys(pick).filter((k) => (pick[k] || 0) > 0);

  if (!names.length) {
    // 没勾任何剧 → 默认每部按 clips 取前 N 集
    const clips = curClips();
    const out = [];
    for (const nm of Object.keys(groups)) {
      const arr = groups[nm].slice(0, Math.min(clips, groups[nm].length));
      out.push(...arr.map((f) => f.path));
    }
    return { files: out, byDrama: null, mode: 'auto' };
  }

  const out = [];
  const byDrama = {};
  for (const nm of names) {
    const want = Math.min(pick[nm] || 0, groups[nm].length);
    const arr = groups[nm].slice(0, want);
    byDrama[nm] = arr.map((f) => f.path);
    out.push(...byDrama[nm]);
  }
  return { files: out, byDrama, mode: 'pick' };
}

/* ---------------- 发布 ---------------- */
function confirmAndRun(root) {
  const pages = [...selPages];
  const sel = computeSelectedFiles();
  const files = sel.files;
  const byDrama = sel.byDrama;
  const clipsPerPage = Number(($('#rl-clips', root) || {}).value)
    || curClips() || 1;
  const concurrency = Number(($('#rl-conc', root) || {}).value) || 1;
  const stall = Number(($('#rl-stall', root) || {}).value) || 180;
  const refTitle = ($('#rl-ref', root) || {}).value || '';
  const fixedTpl = ($('#rl-desc', root) || {}).value || '';
  const linkPool = ($('#rl-links', root) || {}).value || '';

  const nPages = pages.length || reelsPages.items.filter((p) => p.selectable).length;

  // 按剧分组的模式：每个剧独立算（不必满足「主页数 × 集数」）
  if (byDrama) {
    const dramas = Object.keys(byDrama);
    const total = files.length;
    if (!dramas.length) {
      toast('还没选剧', '先在上面勾选要发的剧', 'err');
      return;
    }
    // 主页数必须 >= 剧数，否则要配对
    if (nPages < dramas.length) {
      toast('主页不够', `选了 ${dramas.length} 部剧，但只有 ${nPages} 个主页。`
        + `请补选主页，或减少剧数。`, 'err');
      return;
    }
    const detail = dramas.map((d) => `${cleanDramaName(d)} × ${byDrama[d].length}`).join('、');
    modal({
      title: '确认发布',
      body: `<div style="font-size:11px;line-height:1.9">
        <div>主页：<b>${nPages}</b> 个</div>
        <div>剧数：<b>${dramas.length}</b> 部，共 <b>${total}</b> 集</div>
        <div style="margin-top:6px;padding:8px;background:var(--bg-2);border-radius:5px">
          ${esc(detail)}
        </div>
        <div style="margin-top:8px;color:var(--tx-3);font-size:10px">
          每部剧发到对应主页，剧名取文件夹名，文案自动套标准模板。
        </div>
      </div>`,
      footer: [
        { text: '取消', cls: 'ghost' },
        {
          text: '开始发布', cls: 'primary',
          onClick: (c) => {
            if (c) c();
            doRun({
              pages, files, byDrama, clipsPerPage, concurrency,
              stall, refTitle, fixedTpl, linkPool,
            });
          },
        },
      ],
    });
    return;
  }

  // 普通模式（没按剧选）
  const nFiles = files.length;
  const need = nPages * clipsPerPage;
  if (nFiles < need) {
    toast('素材不足', `需要 ${need} 条，只有 ${nFiles} 条`, 'err');
    return;
  }

  modal({
    title: '确认发布',
    body: `
      <p style="font-size:11.5px;line-height:2">
        将发布 <b>${nPages}</b> 个主页 × <b>${clipsPerPage}</b> 条 = <b>${need}</b> 条素材<br/>
        文案：<b>${titleMode === 'random' ? '多标题随机（按主页各抽一条）' : '固定模板'}</b><br/>
        平台：<b>Facebook</b>（不加标签）<br/>
        并发：<b>${concurrency}</b> 个环境 · 上传容忍 <b>${stall}s</b>
      </p>
      <p style="font-size:10.5px;color:var(--tx-3);line-height:1.8;margin-top:10px">
        · 会自动开浏览器、整理工作页、发布、校验回执<br/>
        · <b>发布成功的素材会自动删除</b>，失败的保留<br/>
        · 出现验证码/风控会停下并保留现场
      </p>`,
    footer: [
      { text: '取消', kind: 'ghost', onClick: (c) => c() },
      { text: '确认发布', kind: 'primary', onClick: (c) => { c(); doRun({ pages, files, clipsPerPage, concurrency, stall, refTitle, fixedTpl, linkPool }); } },
    ],
    width: '460px',
  });
}

async function doRun(opts) {
  runningJob = 'pending';
  const out = document.getElementById('rl-out');
  if (out) {
    out.innerHTML = `<div class="card"><div class="card-body">
      <p class="hint">正在启动发布任务…</p></div></div>`;
  }

  // ⭐ 按剧分组模式：每部剧单独发一批，剧名取文件夹名
  if (opts.byDrama) {
    const dramas = Object.keys(opts.byDrama);
    const pages = opts.pages || [];
    const jobs = [];
    // 主页按顺序分配：第 i 部剧 → pages[i % pages.length]
    for (let i = 0; i < dramas.length; i += 1) {
      const nm = dramas[i];
      const mats = opts.byDrama[nm] || [];
      if (!mats.length) continue;
      const pg = pages.length ? [pages[i % pages.length]] : [];
      const dramaName = cleanDramaName(nm);
      if (out && jobs.length === 0) {
        out.innerHTML = `<div class="card"><div class="card-body">
          <p class="hint">正在发第 1/${dramas.length} 部：${esc(dramaName)}</p>
        </div></div>`;
      }
      try {
        const r = await api.reelsPublish({
          directory: '',
          // 固定文案：用标准模板 + 剧名（后端会补链接）
          description: opts.fixedTpl || '',
          fixedTitle: '',
          titleMode: opts.fixedTpl ? 'fixed' : 'random',
          referenceTitle: dramaName,
          useRandomLink: true,
          linkPool: opts.linkPool,
          clipsPerPage: mats.length,
          concurrency: opts.concurrency,
          publishMode: 'merge',
          autoPrepare: true,
          pages: pg,
          materials: mats,
          uploadStallTimeoutSeconds: opts.stall,
        });
        jobs.push({ drama: dramaName, jobId: r.jobId, ok: true });
        toast(`第 ${i + 1}/${dramas.length} 部已启动`,
          `${dramaName} · ${mats.length} 集`, 'ok');
      } catch (e) {
        jobs.push({ drama: dramaName, ok: false, error: e.message });
        toast(`第 ${i + 1} 部启动失败`, `${dramaName}：${e.message}`, 'err');
      }
      // 等一小会儿再发下一部，避免内核 BUSY
      await new Promise((ok) => setTimeout(ok, 1200));
    }

    runningJob = (jobs.find((x) => x.ok) || {}).jobId || '';
    const okN = jobs.filter((x) => x.ok).length;
    if (out) {
      out.innerHTML = `<div class="card"><div class="card-body">
        <div style="font-size:11.5px;line-height:1.9">
          <div style="font-weight:600;margin-bottom:6px">
            已启动 ${okN}/${dramas.length} 部</div>
          ${jobs.map((j) => `<div style="color:${j.ok ? 'var(--tx-1)' : 'var(--danger)'}">
            ${j.ok ? '✓' : '✗'} ${esc(j.drama)}
            ${j.ok ? `<span class="muted" style="font-size:9.5px"> · ${esc(j.jobId)}</span>` : ` · ${esc(j.error)}`}
          </div>`).join('')}
        </div>
      </div></div>`;
    }
    if (runningJob) watchJob(runningJob, out);
    return;
  }

  try {
    const r = await api.reelsPublish({
      directory: '',
      description: titleMode === 'fixed' ? opts.fixedTpl : '',
      fixedTitle: titleMode === 'fixed' ? opts.fixedTpl : '',
      titleMode: titleMode === 'random' ? 'random' : 'fixed',
      referenceTitle: opts.refTitle,
      useRandomLink: true,
      linkPool: opts.linkPool,
      clipsPerPage: opts.clipsPerPage,
      concurrency: opts.concurrency,
      publishMode: 'merge',
      autoPrepare: true,
      pages: opts.pages,
      materials: opts.files,
      uploadStallTimeoutSeconds: opts.stall,
    });
    runningJob = r.jobId || '';
    toast('已启动', `任务 ${r.jobId}`, 'ok');
    watchJob(r.jobId, out);
    const body = $('#pb-body');
    if (body) paint(document);
  } catch (e) {
    runningJob = '';
    toast('启动失败', e.message, 'err');
    if (out) out.innerHTML = `<div class="card"><div class="card-body">
      <p class="hint err">启动失败：${esc(e.message)}</p></div></div>`;
  }
}

/* 轮询任务进度 */
function watchJob(jobId, out) {
  if (!jobId) return;
  let ticks = 0;
  const timer = setInterval(async () => {
    ticks += 1;
    try {
      const jobs = await store.loadJobs();
      const job = (store.jobs || []).find((j) => j.id === jobId);
      if (!job) return;
      const steps = job.steps || [];
      if (out) {
        out.innerHTML = `<div class="card"><div class="card-body">
          <p class="hint">任务 <b>${esc(jobId)}</b> · ${esc(job.status)} · ${job.progress || 0}%</p>
          ${steps.map((s) => `<div class="step-row">
            <span class="step-dot ${s.state}"></span>
            <span style="flex:1">${esc(s.name)}</span>
            <span style="font-size:9.5px;color:var(--tx-3)">${esc(s.note || '')}</span>
          </div>`).join('')}
        </div></div>`;
      }
      if (['done', 'failed', 'stopped'].includes(job.status)) {
        clearInterval(timer);
        runningJob = '';
        lastResult = {
          ok: job.status === 'done',
          note: job.error || (job.status === 'done' ? '全部完成' : job.status),
        };
        paint(document);
        toast(lastResult.ok ? '发布完成' : '发布未完成', lastResult.note, lastResult.ok ? 'ok' : 'err', 6000);
      }
    } catch { /* 忽略单次失败 */ }
    if (ticks > 1200) clearInterval(timer); // 最多 2 小时
  }, 6000);
}

/* ---------------- 工具 ---------------- */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
