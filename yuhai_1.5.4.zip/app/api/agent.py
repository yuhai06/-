# -*- coding: utf-8 -*-
"""Agent 接入 API：检测 / 连接 / 模型清单 / 开关 / 可用性实测。"""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

log = logging.getLogger("yuhai.api.agent")
router = APIRouter()


# ---------------- 检测 ----------------
@router.get("/agent/detect")
async def agent_detect(deep: bool = False):
    """检测本机 Agent。deep=true 才做多盘一级扫描。"""
    from app.services import agent_detect as ad
    r = await asyncio.to_thread(ad.detect_all)
    if deep:
        d = await asyncio.to_thread(ad.deep_scan)
        r["deep"] = d
    return r


@router.post("/agent/deep-scan")
async def agent_deep_scan():
    """深度扫描（用户主动点，会慢）。"""
    from app.services import agent_detect as ad
    return await asyncio.to_thread(ad.deep_scan)


# ---------------- 连接 ----------------
class ConnectReq(BaseModel):
    agentId: str


@router.post("/agent/connect")
async def agent_connect(req: ConnectReq):
    """接入某个 agent（之后只显示它的模型）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.connect, req.agentId)


@router.get("/agent/overview")
async def agent_overview():
    """首屏：当前接入 + 模型清单 + 可切换列表。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.overview)


# ---------------- 模型开关 ----------------
class HideReq(BaseModel):
    agentId: str
    modelId: str
    hidden: bool = True


@router.post("/agent/model/hide")
async def agent_hide(req: HideReq):
    """隐藏/显示单个模型。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.set_hidden, req.agentId,
                                   req.modelId, req.hidden)


class HideChannelReq(BaseModel):
    agentId: str
    channel: str
    hidden: bool = True



# ---------------- 会话历史 ----------------
@router.get("/agent/chats")
async def agent_chat_list(limit: int = 40, q: str = ""):
    """会话列表（按更新时间倒序）。"""
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.list_chats, limit, q)


class NewChatReq(BaseModel):
    title: str = ""
    agent: str = ""
    model: str = ""


@router.post("/agent/chats")
async def agent_chat_new(req: NewChatReq):
    """新建对话。"""
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.create_chat, req.title, req.agent,
                                   req.model)


@router.get("/agent/chats/{chat_id}")
async def agent_chat_get(chat_id: str, limit: int = 200):
    """读一个会话的全部消息。"""
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.get_chat, chat_id, limit)


class AppendReq(BaseModel):
    role: str
    content: str = ""
    model: str = ""
    trace: list = []
    atts: list = []
    error: bool = False


@router.post("/agent/chats/{chat_id}/msg")
async def agent_chat_append(chat_id: str, req: AppendReq):
    """往会话追加一条消息（前端本地存历史用）。"""
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.append_msg, chat_id, req.role,
                                   req.content, req.model, req.trace,
                                   req.atts, req.error)


class RenameReq(BaseModel):
    title: str


@router.patch("/agent/chats/{chat_id}")
async def agent_chat_rename(chat_id: str, req: RenameReq):
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.rename_chat, chat_id, req.title)


class PinReq(BaseModel):
    pinned: bool = True


@router.post("/agent/chats/{chat_id}/pin")
async def agent_chat_pin(chat_id: str, req: PinReq):
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.pin_chat, chat_id, req.pinned)


@router.delete("/agent/chats/{chat_id}")
async def agent_chat_del(chat_id: str):
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.delete_chat, chat_id)


@router.delete("/agent/chats")
async def agent_chat_clear():
    """清空全部会话。"""
    from app.services import agent_history as ah
    return await asyncio.to_thread(ah.clear_all)



# ---------------- 长期记忆 ----------------
@router.get("/agent/mem")
async def agent_mem_list():
    from app.services import agent_context as ctx
    return await asyncio.to_thread(ctx.list_memory)


class MemSet2Req(BaseModel):
    key: str = ""
    value: str = ""
    auto: str = ""     # 传 auto=消息文本 → 自动抽取重要事实


@router.post("/agent/mem")
async def agent_mem_set(req: MemSet2Req):
    from app.services import agent_context as ctx
    if req.auto:
        saved = await asyncio.to_thread(ctx.save_auto, req.auto)
        return {"ok": True, "auto": True, "saved": saved}
    if not req.key:
        raise HTTPException(400, "key 不能为空")
    return await asyncio.to_thread(ctx.set_memory, req.key, req.value)


@router.delete("/agent/mem/{key}")
async def agent_mem_del(key: str):
    from app.services import agent_context as ctx
    return await asyncio.to_thread(ctx.del_memory, key)


@router.get("/agent/chats/{chat_id}/summary")
async def agent_chat_summary(chat_id: str):
    """读会话摘要。"""
    from app.services import agent_context as ctx
    return {"ok": True, "summary": await asyncio.to_thread(
        ctx.get_summary, chat_id)}


@router.post("/agent/chats/{chat_id}/summarize")
async def agent_chat_summarize(chat_id: str):
    """手动触发压缩。"""
    from app.services import agent_context as ctx
    s = await asyncio.to_thread(ctx.build_summary, chat_id)
    if s:
        await asyncio.to_thread(ctx.set_summary, chat_id, s)
    return {"ok": True, "summary": s}


# ---------------- 附件上传 ----------------
UPLOAD_DIR = None


def _upload_dir():
    global UPLOAD_DIR
    if UPLOAD_DIR is None:
        from app import paths
        UPLOAD_DIR = paths.DATA_DIR / "agent_uploads"
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    return UPLOAD_DIR


@router.post("/agent/upload")
async def agent_upload(file: UploadFile = File(...)):
    """上传文件/图片给对话用。返回路径，前端把它放进 attachments。

    图片存成 base64 data URI 供视觉模型直接读；
    其他文件存盘，只给模型路径和内容摘要。
    """
    import base64
    import time as _t
    from pathlib import Path as _P

    d = _upload_dir()
    name = file.filename or "upload.bin"
    safe = "".join(c for c in name if c.isalnum() or c in "._-")[:80]
    dst = d / ("%d_%s" % (_t.time(), safe or "upload.bin"))

    raw = await file.read()
    if len(raw) > 60 * 1048576:
        raise HTTPException(413, "文件超过 60MB")
    dst.write_bytes(raw)

    ext = _P(safe).suffix.lower()
    is_img = ext in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
    out = {
        "ok": True,
        "name": name,
        "path": str(dst),
        "sizeMb": round(len(raw) / 1048576, 2),
        "kind": "image" if is_img else "file",
    }
    if is_img and len(raw) < 6 * 1048576:
        mime = { ".png": "image/png", ".jpg": "image/jpeg",
                 ".jpeg": "image/jpeg", ".webp": "image/webp",
                 ".gif": "image/gif", ".bmp": "image/bmp" }.get(ext,
                 "image/png")
        out["dataUri"] = "data:%s;base64,%s" % (
            mime, base64.b64encode(raw).decode())
    else:
        # 文本类抽前 3000 字给模型看
        if ext in (".txt", ".md", ".json", ".csv", ".log", ".py",
                   ".js", ".ts", ".html", ".css", ".yaml", ".yml"):
            try:
                out["preview"] = raw.decode("utf-8", "ignore")[:3000]
            except Exception:
                pass
    return out


class SelectModelReq(BaseModel):
    agentId: str
    modelId: str = ""


@router.post("/agent/model/select")
async def agent_select_model(req: SelectModelReq):
    """切换对话用哪个模型（modelId 留空 = 恢复配置默认）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.set_active_model, req.agentId,
                                   req.modelId)


@router.post("/agent/model/hide-channel")
async def agent_hide_channel(req: HideChannelReq):
    """按渠道批量隐藏（如 our-free-model 一次全隐）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.hide_channel, req.agentId,
                                   req.channel, req.hidden)


# ---------------- 可用性实测 ----------------
class TestReq(BaseModel):
    agentId: str
    modelId: str


@router.post("/agent/model/test")
async def agent_test(req: TestReq):
    """实测一个模型能不能用（真发一次请求）。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_one, req.agentId, req.modelId)


class TestAllReq(BaseModel):
    agentId: str
    limit: int = 0
    autoHide: bool = False     # 测完自动隐藏失败的


@router.post("/agent/model/test-all")
async def agent_test_all(req: TestAllReq):
    """批量实测（顺序跑，慢）。autoHide=True 时测完自动隐藏失败的。"""
    from app.services import agent_models as am
    return await asyncio.to_thread(am.test_all, req.agentId, req.limit,
                                   req.autoHide)


# ---------------- 记忆 ----------------
@router.get("/agent/memory")
async def agent_memory_list():
    """Agent 跨会话记忆（读）。"""
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.list_all)


class MemSetReq(BaseModel):
    key: str
    value: str


@router.post("/agent/memory")
async def agent_memory_set(req: MemSetReq):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.set, req.key, req.value)


@router.delete("/agent/memory/{key}")
async def agent_memory_del(key: str):
    from app.services import agent_memory as mem
    return await asyncio.to_thread(mem.delete, key)


# ---------------- 对话（用 Agent 自己的模型） ----------------
class ChatReq(BaseModel):
    message: str
    chatId: str = ""         # 会话 id（用于摘要+记忆）
    history: list = []
    autoRunTools: bool = True
    attachments: list = []   # [{name, kind, path, sizeMb}]


@router.post("/agent/chat/stop")
async def agent_chat_stop():
    """停止当前正在运行的 Agent 对话（中断工具执行循环）。"""
    from app.services import agent_chat as ac
    r = ac.request_stop("用户点击停止")
    return {**r, "note": "已停止；下一次发送会自动复位"}


@router.get("/agent/chat/status")
async def agent_chat_status():
    """查询是否正在运行 / 是否已请求停止。"""
    from app.services import agent_chat as ac
    return {"ok": True, "running": not ac.is_stopped() and False,
            "stopped": ac.is_stopped()}


# ══════════════════════════════════════════════════════════
# 外部 Agent 引擎（多引擎支持）
# 前端可切换 DSH / Claude Code / Codex / WorkBuddy / Aider / Gemini
# ══════════════════════════════════════════════════════════

class DshReq(BaseModel):
    message: str = ""
    sessionId: str = ""
    chatId: str = ""


class EngineReq(BaseModel):
    message: str = ""
    engine: str = "dsh"
    sessionId: str = ""
    chatId: str = ""


@router.get("/agent/engines")
async def agent_engines():
    """列出所有外部引擎及可用状态。"""
    from app.services import agent_engines as ae
    items = ae.list_engines()
    avail = [e for e in items if e.get("available")]
    return {
        "ok": True,
        "engines": items,
        "availableCount": len(avail),
        "default": "dsh" if any(e["id"] == "dsh" and e["available"] for e in items)
                   else (avail[0]["id"] if avail else ""),
    }


@router.post("/agent/engine/stop")
async def agent_engine_stop(req: EngineReq | None = None):
    """停止当前外部 agent 任务。"""
    from app.services import agent_engines as ae
    eid = (req.engine if req else "") or ""
    return ae.request_stop(eid, "用户点击停止")


@router.post("/agent/engine/stream")
async def agent_engine_stream(req: EngineReq):
    """用指定外部 agent 跑任务，SSE 流式返回。

    事件与自建 agent 完全一致：
      data: {"stage":"tool_start","tool":"...","args":{}}
      data: {"stage":"tool_end","tool":"...","ok":true,"ms":12}
      data: {"stage":"reply","content":"..."}
      data: {"stage":"done","ok":true,"reply":"..."}
    """
    import json as _json
    import queue as _queue
    from fastapi.responses import StreamingResponse
    from app.services import agent_engines as ae

    if not (req.message or "").strip():
        raise HTTPException(400, "message 不能为空")
    if not req.engine:
        raise HTTPException(400, "engine 不能为空")

    q: _queue.Queue = _queue.Queue()

    def worker():
        def on_event(stage, payload):
            q.put({"stage": stage, **(payload or {})})

        try:
            r = ae.run(req.engine, req.message, req.sessionId, on_event=on_event)
            if not r.get("ok") and (r.get("error") or r.get("stopped")):
                q.put({"stage": "done", "ok": False,
                       "stopped": bool(r.get("stopped")),
                       "error": r.get("error") or "",
                       "sessionId": r.get("sessionId", "")})
        except Exception as e:
            q.put({"stage": "done", "ok": False,
                   "error": "%s: %s" % (type(e).__name__, str(e)[:200])})

    async def gen():
        import asyncio as _aio
        task = _aio.create_task(_aio.to_thread(worker))
        idle = 0
        while True:
            try:
                item = await _aio.to_thread(q.get, True, 2.0)
            except Exception:
                idle += 1
                if task.done() and q.empty():
                    break
                if idle > 5:
                    yield "data: " + _json.dumps(
                        {"stage": "ping"}, ensure_ascii=False) + "\n\n"
                    idle = 0
                continue
            idle = 0
            st = item.get("stage")
            yield "data: " + _json.dumps(item, ensure_ascii=False) + "\n\n"
            if st == "done":
                break
            await _aio.sleep(0)

        if not task.done():
            try:
                await task
            except Exception:
                pass

    return StreamingResponse(
        gen(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ── 向后兼容：旧的 /agent/dsh/* 接口转发到通用引擎 ──

@router.get("/agent/dsh/status")
async def dsh_status_compat():
    from app.services import agent_engines as ae
    e = ae.engine_by_id("dsh")
    path = ae._find_bin(e["bins"]) if e else ""
    return {"ok": bool(path), "engine": "dsh",
            "path": path or "", "hasKey": bool(ae._api_key("dsh")),
            "version": ""}


@router.post("/agent/dsh/stop")
async def dsh_stop_compat():
    from app.services import agent_engines as ae
    return ae.request_stop("dsh", "用户点击停止")


@router.post("/agent/dsh/stream")
async def dsh_stream_compat(req: DshReq):
    r = EngineReq(message=req.message, engine="dsh",
                  sessionId=req.sessionId, chatId=req.chatId)
    return await agent_engine_stream(r)


@router.post("/agent/chat/stream")
async def agent_chat_stream(req: ChatReq):
    """流式对话（SSE）：实时推送 思考 / 工具调用 / 最终回答。

    前端用 EventSource 或 fetch+ReadableStream 读。
    事件格式：
      data: {"stage":"thinking","round":1}
      data: {"stage":"tool_start","tool":"slice_env_check"}
      data: {"stage":"tool_end","tool":"...","ok":true,"ms":844}
      data: {"stage":"reply","content":"..."}
      data: {"stage":"done","ok":true,...}
    """
    import json as _json
    import queue as _queue
    from fastapi.responses import StreamingResponse
    from app.services import agent_chat as ac

    q: _queue.Queue = _queue.Queue()

    def worker():
        from app.services import agent_history as _ah

        def on_prog(stage, payload):
            q.put({"stage": stage, **(payload or {})})

        try:
            # 存用户消息
            if req.chatId and req.message:
                try:
                    _ah.append_msg(req.chatId, "user", req.message,
                                   atts=req.attachments or None)
                except Exception as _e:
                    log.debug("save user msg failed: %s", _e)

            r = ac.chat(req.message, req.history, req.autoRunTools,
                        req.attachments, on_progress=on_prog,
                        chat_id=req.chatId)

            # 存助手回复（含工具 trace）
            if req.chatId and r and r.get("ok"):
                try:
                    _ah.append_msg(req.chatId, "assistant",
                                   r.get("reply") or "",
                                   model=r.get("model") or "",
                                   trace=r.get("trace") or None)
                except Exception as _e:
                    log.debug("save reply failed: %s", _e)

            # ── 自动续跑：轮数用尽但任务未完成时，继续往下跑 ──
            # 单次 chat() 有轮数上限（默认40），长流程（选剧→切片→发布）
            # 可能需要几轮接力。这里自动续跑，最多 4 次接力。
            relay = 0
            while (r and r.get("needContinue") and relay < 4):
                relay += 1
                q.put({"stage": "thinking",
                       "round": f"续跑 {relay}/4",
                       "note": "工具轮数用尽，自动继续"})
                try:
                    _ah.append_msg(req.chatId, "assistant",
                                   r.get("reply") or "",
                                   model=r.get("model") or "",
                                   trace=r.get("trace") or None)
                except Exception:
                    pass
                r = ac.chat(
                    "继续完成任务。上一步你因为工具轮数用尽而中断，"
                    "请接着往下做，不要重复已经做过的事。",
                    None, req.autoRunTools, None,
                    on_progress=on_prog, chat_id=req.chatId)

            q.put({"stage": "done", **(r or {})})
        except ac.Stopped as e:
            # 用户主动停止：不是错误，前端显示"已停止"
            q.put({"stage": "stopped", "ok": False,
                   "stopped": True, "reason": str(e) or "用户停止"})
            q.put({"stage": "done", "ok": False, "stopped": True,
                   "error": "已停止"})
        except Exception as e:
            q.put({"stage": "done", "ok": False,
                   "error": str(e)[:200]})

    async def gen():
        import asyncio as _aio
        task = _aio.create_task(_aio.to_thread(worker))
        idle = 0
        while True:
            try:
                item = await _aio.to_thread(q.get, True, 2.0)
            except Exception:
                idle += 1
                if task.done() and q.empty():
                    break
                if idle > 3:
                    yield "data: " + _json.dumps(
                        {"stage": "ping"}, ensure_ascii=False) + "\n\n"
                    idle = 0
                continue
            idle = 0
            yield "data: " + _json.dumps(item, ensure_ascii=False) + "\n\n"
            if item.get("stage") == "done":
                break

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@router.post("/agent/chat")
async def agent_chat(req: ChatReq):
    """用当前接入 Agent 的模型对话，可调用工具操作工作台。

    attachments: [{name, kind, path, sizeMb}] —— 文件/图片会拼进提示词。
    """
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.chat, req.message, req.history,
                                   req.autoRunTools, req.attachments,
                                   None, req.chatId)


@router.get("/agent/chat/test")
async def agent_chat_test():
    """自检：当前 agent 的模型能不能对话。"""
    from app.services import agent_chat as ac
    return await asyncio.to_thread(ac.quick_test)


@router.get("/agent/tools")
async def agent_tools():
    """MCP 工具清单（给前端展示 + 供外部 agent 参考）。"""
    from app.services import agent_chat as ac
    specs = await asyncio.to_thread(ac.tool_specs)
    return {"ok": True, "count": len(specs),
            "items": [{"name": s["function"]["name"],
                       "description": s["function"]["description"]}
                      for s in specs]}


# ---------------- MCP 接入信息 ----------------
@router.get("/agent/mcp")
async def agent_mcp():
    """MCP 服务地址 + 外部 Agent 接入配置示例。"""
    import os
    from app.config import settings
    from app.mcp_server import mcp as M
    port = int(os.environ.get("YUHAI_PORT", settings.port))
    tools = await M.list_tools()
    return {
        "ok": True,
        "url": f"http://127.0.0.1:{port}/mcp/",
        "transport": "streamable-http",
        "count": len(tools),
        "tools": [{"name": t.name, "description": t.description}
                  for t in tools],
        "config_example": {
            "mcpServers": {
                "yuhai": {
                    "url": f"http://127.0.0.1:{port}/mcp/",
                    "transport": "streamable-http",
                }
            }
        },
    }
