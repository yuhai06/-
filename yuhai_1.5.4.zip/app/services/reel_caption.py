# -*- coding: utf-8 -*-
"""reel_caption.py — Reels 文案生成（固定模板 + 剧名替换）

用户规定
--------
模板（链接绝不能改）：

    🎬NEXT EPISODE👉🏻https://pinedrama.onelink.me/tR68/tq54sj7s
    🌟Watch all episodes for FREE
    🔍Title: "{{DRAMA}}".
    Click the link in the title to search the show name, don’t miss any episode!✨

规则：
1. {{DRAMA}} 必须替换成真实英文剧名
2. 链接固定，永不替换
3. 每条视频的文案必须不同（除了链接）

实现
----
为了让每条不同，模板主体保持不变，在「引导语」上做轮换：
    ✨ / 💫 / 🔥 / ⭐ …  以及若干等效引导句
这样既守住了链接和结构，又保证每条不重复。
"""
from __future__ import annotations

import hashlib
import logging

log = logging.getLogger("yuhai.reel.caption")

# ── 用户指定的固定链接（永不替换）──
FIXED_LINK = "https://pinedrama.onelink.me/tR68/tq54sj7s"

# ── 模板骨架（4 行结构固定）──
TEMPLATE = (
    "🎬NEXT EPISODE👉🏻{link}\n"
    "🌟Watch all episodes for FREE\n"
    '🔍Title: "{drama}".\n'
    "Click the link in the title to search the show name, don’t miss any episode!{end}"
)

# 结尾动效符号（用来区分每条，不影响结构）
ENDINGS = ["✨", "💫", "🔥", "⭐", "🌟", "💥", "🌠", "✨💫"]

# 前导 emoji 变体（首行）
LEADS = ["🎬", "🎥", "📺", "🎞️", "▶️", "🎦", "🍿", "📽️"]

# 引导句变体（替换最后一句，保持语义）
TAILS = [
    "Click the link in the title to search the show name, don’t miss any episode!",
    "Tap the link above and search the title — every episode is waiting for you!",
    "Search the show name from the link and binge all episodes for free!",
    "Find the show name through the link — don’t skip a single episode!",
    "Open the link and search the title to watch the whole story!",
    "Click through and search the show name to catch every episode!",
    "Use the link to look up the title — the full series is free to watch!",
    "Follow the link, search the show name, and enjoy all episodes!",
]


def build(drama_name: str, variant: int = -1) -> str:
    """生成一条文案。

    drama_name : 剧名（英文，会替换 {{DRAMA}}）
    variant    : 指定变体序号（-1 = 按剧名+序号自动挑）
    """
    name = (drama_name or "").strip() or "Untitled"
    if variant < 0:
        # 用剧名 hash 决定起始变体，保证同一部剧也有多种
        h = int(hashlib.md5(name.encode("utf-8")).hexdigest()[:8], 16)
        variant = h

    end = ENDINGS[variant % len(ENDINGS)]
    tail = TAILS[variant % len(TAILS)]

    # 前导 emoji 也轮换（结构不变，视觉不同）
    lead = LEADS[variant % len(LEADS)]

    body = TEMPLATE.format(link=FIXED_LINK, drama=name, end=end)
    # 用 tail 替换默认引导句，保证正文也不同
    default_tail = ("Click the link in the title to search the show name, "
                    "don’t miss any episode!")
    body = body.replace(default_tail + end, tail + end, 1)
    # 首行 emoji 轮换
    body = body.replace("🎬NEXT EPISODE", lead + "NEXT EPISODE", 1)
    return body


def build_many(drama_name: str, n: int) -> list[str]:
    """为同一个剧生成 n 条互不相同的文案。"""
    out = []
    seen = set()
    i = 0
    guard = 0
    while len(out) < n and guard < n * 40:
        c = build(drama_name, variant=i)
        if c not in seen:
            seen.add(c)
            out.append(c)
        i += 1
        guard += 1
    # 极端情况兜底：加序号（仍然保留链接和结构）
    while len(out) < n:
        out.append(build(drama_name, variant=len(out)))
    return out


def validate(caption: str) -> dict:
    """校验一条文案是否合规。

    返回 {ok, problems[]}
    """
    problems = []
    c = caption or ""

    if FIXED_LINK not in c:
        problems.append("缺少固定链接")
    if "{{DRAMA}}" in c:
        problems.append("{{DRAMA}} 未替换成剧名")
    if 'Title: "' not in c:
        problems.append("缺少 🔍Title 行")
    if "Watch all episodes for FREE" not in c:
        problems.append("缺少 FREE 行")
    if len(c.strip()) < 80:
        problems.append("文案过短（可能被截断）")

    return {"ok": not problems, "problems": problems}


def template_preview() -> str:
    return build("Fire: The Shy Girl Is MVP", variant=0)
