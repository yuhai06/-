# -*- coding: utf-8 -*-
"""
mcp_server.py — 把工作台暴露成 MCP 服务，让外部 Agent 直接操作

设计（按 MCP 2.x 规范 + 2026-07-28 最佳实践）：
  ① stateless：状态不挂连接，长任务用 job_id handle
  ② 工具名 snake_case，1-128 字符
  ③ inputSchema 用 JSON Schema
  ④ 失败返回 isError + 可操作消息
  ⑤ 工具列表静态，不随连接变化

挂载方式（main.py）：
    from app.mcp_server import mcp
    app.mount("/mcp", mcp.streamable_http_app())

外部 agent 连接：
    {"mcpServers": {"yuhai": {"url": "http://127.0.0.1:PORT/mcp",
                              "transport": "streamable-http"}}}
"""
from __future__ import annotations

import json
import logging
import os

from mcp.server.mcpserver import MCPServer
import time

log = logging.getLogger("yuhai.mcp")

mcp = MCPServer(
    name="yuhai-workbench",
    title="雨海工作台",
    description="短剧运营工作台：抓取、切片、发布、数据分析",
    instructions=(
        "这是短剧运营工作台。常用流程：\n"
        "1. slice_env_check 先看环境是否就绪\n"
        "2. slice_list_dramas 看有哪些剧可切\n"
        "3. slice_run 开始切片（返回 job_id）\n"
        "4. slice_status(job_id) 查进度\n"
        "5. slice_result 拿成片列表\n"
        "\n"
        "【短剧下载（推荐）】多站点下载：\n"
        "  dl_sites 看有哪些站点 →\n"
        "  dl_search(site, keyword) 搜剧拿 slug →\n"
        "  dl_check(site, slug) 看详情和 freeEps 免费集 →\n"
        "  dl_download_eps(site, slug, eps) 下载拿 task_id →\n"
        "  dl_task(task_id) 查进度 →\n"
        "  dl_library 列已下载 → dl_send_to_slice(site, dir) 送去切片\n"
        "  站点：pinedrama / dramabox / moboreels / goodshort / tiktok / tiktok_drama\n"
        "  TikTok：dl_tiktok_meta(id) 查信息，dl_tiktok_download(id) 下载\n"
        "\n"
        "【TK短剧（TikTok 内的短剧板块）】\n"
        "  ID 来自地址 tiktok.com/shortdrama/episode/<ID>/1\n"
        "  dl_sd_meta(id) 查详情 → dl_sd_batch([id1,id2,...]) 批量查\n"
        "  dl_sd_history() 看查过哪些（避免重复）\n"
        "  dl_sd_browser('start'|'stop'|'status') 管调试浏览器\n"
        "  注意：浏览器没开会自动拉起（无头模式，用户看不到窗口）；\n"
        "        TikTok 会风控，批量查询内部已做节流，失败等 1-2 分钟再试\n"
        "\n"
        "⚠ 下载/抓取只用 dl_* 系列。旧版 grab_* 已停用，不要调用。\n"
        "发布：publish_reels 发到 Facebook Reels\n"
        "记忆：memory_set / memory_get 记住跨会话状态"
    ),
    version="1.0.0",
)


def _ok(**kw):
    return {"ok": True, **kw}


def _err(msg: str, **kw):
    return {"ok": False, "error": msg, **kw}


# ═══════════════════════════════════════════════
#  切片
# ═══════════════════════════════════════════════
@mcp.tool(description="环境自检：Python包/FFmpeg/ASR模型/脚本/GPU/代理")
def slice_env_check() -> dict:
    from app.services import envcheck
    r = envcheck.full_check()
    return _ok(
        ready=r["ok"],
        python_ok=all(p["ok"] for p in r["python"] if p["required"]),
        ffmpeg=r["ffmpeg"]["ok"],
        nvenc=r["ffmpeg"].get("nvenc"),
        model={"ok": r["model"]["ok"], "name": r["model"]["name"],
               "sizeMb": r["model"].get("sizeMb")},
        tools={"ok": r["tools"]["ok"],
               "stale": len(r["tools"].get("stale") or [])},
        gpu={"name": r["gpu"].get("name"), "cuda": r["gpu"].get("cuda")},
        warnings=r["warnings"],
        fixable=[f["what"] for f in (r.get("fixable") or [])],
    )


@mcp.tool(description="修环境。what: all|python|ffmpeg|whisper|tools|cuda")
def slice_env_install(what: str = "all") -> dict:
    from app.services import envcheck
    r = envcheck.install_one(what)
    return _ok(what=what, ok=r.get("ok"),
               note=r.get("note") or r.get("error") or "")


@mcp.tool(description="列出所有短剧及处理状态（哪些能切、切到哪一步）")
def slice_list_dramas() -> dict:
    from app.services import slicing as sl
    items = sl.list_dramas()
    out = []
    for d in items:
        st = d.get("steps") or {}
        out.append({
            "drama": d["drama"],
            "title": d.get("title"),
            "sourceEpisodes": d.get("sourceEpisodes") or 0,
            "hasSource": d.get("hasSource"),
            "state": d.get("state"),
            "transcribed": bool((st.get("transcribe") or {}).get("done")),
            "segments": (st.get("transcribe") or {}).get("segments") or 0,
            "type": (st.get("classify") or {}).get("typeName") or "",
            "tensionSegs": (st.get("tension") or {}).get("segments") or 0,
            "singles": (st.get("single") or {}).get("count") or 0,
            "premiums": (st.get("premium") or {}).get("count") or 0,
        })
    return _ok(count=len(out), items=out)


@mcp.tool(description="开始切片。mode: single（单集）|premium（精品）|all。返回 job_id，用 slice_status 查进度")
def slice_run(drama: str, mode: str = "all", eps: str = "",
              target: int = 45) -> dict:
    from app.services import slicing as sl
    import uuid
    job_id = "mcp-" + uuid.uuid4().hex[:10]
    eps_list = [e.strip() for e in eps.split(",") if e.strip()] if eps else None

    try:
        result = {}
        if mode in ("single", "all"):
            result["single"] = sl.step_single(job_id, drama, eps_list, target)
        if mode in ("premium", "all"):
            result["premium"] = sl.step_premium(job_id, drama)
        return _ok(job_id=job_id, drama=drama, mode=mode, result=result,
                   hint=f"用 slice_status('{job_id}') 查详情")
    except Exception as e:
        return _err(f"切片失败: {str(e)[:120]}", drama=drama)


@mcp.tool(description="查 job 进度")
def slice_status(job_id: str) -> dict:
    from app.db import db
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        return _err(f"没有这个 job: {job_id}", available_hint="用 slice_run 创建")
    return _ok(
        id=r["id"], kind=r.get("kind"), status=r.get("status"),
        progress=r.get("progress"),
        steps=json.loads(r.get("steps") or "[]"),
        result=json.loads(r.get("result") or "{}") if r.get("result") else {},
        error=r.get("error") or "",
    )


@mcp.tool(description="列出成片（单集/精品）")
def slice_result(drama: str = "") -> dict:
    from app import paths
    out = []
    for pat in ("单集_*", "精品混剪_*"):
        for d in paths.output_root().glob(pat):
            if not d.is_dir():
                continue
            for sub in d.iterdir():
                if not sub.is_dir():
                    continue
                if drama and drama.lower() not in sub.name.lower():
                    continue
                vids = [f for f in sub.glob("*.mp4")]
                if not vids:
                    continue
                out.append({
                    "kind": "single" if "单集" in pat else "premium",
                    "drama": sub.name,
                    "date": d.name.split("_")[-1],
                    "count": len(vids),
                    "files": [{"name": f.name,
                               "mb": round(f.stat().st_size / 1048576, 1)}
                              for f in vids[:20]],
                })
    return _ok(count=len(out), items=out)


@mcp.tool(description="校验成片：台词完整/无重叠/无静音")
def slice_verify(video_path: str) -> dict:
    from app.services import slicing as sl
    try:
        return _ok(**sl.verify_output(video_path))
    except Exception as e:
        return _err(f"校验失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  旧版抓取工具（已停用）
# ═══════════════════════════════════════════════
# 这两条工具已从 MCP 隐藏，避免 Agent 误用旧的 PineDrama 抓取链路。
# 替代方案：dl_sites → dl_search → dl_check → dl_download_eps
#
# 如需临时恢复（调试用）：
#     set YUHAI_ENABLE_LEGACY_GRAB=1
# 恢复后 grab_search / grab_download 会重新出现在工具列表里。
_LEGACY_GRAB = os.getenv("YUHAI_ENABLE_LEGACY_GRAB", "").strip() in ("1", "true", "yes")

if _LEGACY_GRAB:
    @mcp.tool(description="[旧版] 搜剧（PineDrama），返回剧名/集数/cid。"
                          "新流程请用 dl_search")
    def grab_search(keyword: str, limit: int = 15) -> dict:
        from app.legacy.services import grab as g
        try:
            r = g.search(keyword) if hasattr(g, "search") else {}
            if not r:
                r = g.hot_list() if hasattr(g, "hot_list") else {}
            items = (r.get("items") or r.get("collections") or [])[:limit]
            return _ok(keyword=keyword, count=len(items), items=items)
        except Exception as e:
            return _err(f"搜索失败: {str(e)[:100]}")

    @mcp.tool(description="[旧版] 下载剧集。cid 来自 grab_search；eps 如 '1-10'。"
                          "新流程请用 dl_download_eps")
    def grab_download(cid: str, eps: str = "1-10") -> dict:
        from app.legacy.services import grab as g
        try:
            r = g.download(cid, eps) if hasattr(g, "download") else {}
            return _ok(cid=cid, result=r)
        except Exception as e:
            return _err(f"下载失败: {str(e)[:100]}")
else:
    log.info("legacy grab MCP tools disabled (set YUHAI_ENABLE_LEGACY_GRAB=1 to enable)")


# ═══════════════════════════════════════════════
#  短剧下载（多站点）—— 与「短剧下载」页面同一套后端
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "列可用下载站点。返回 id（pinedrama/dramabox/moboreels/goodshort/"
    "tiktok/tiktok_drama）和名称"))
def dl_sites() -> dict:
    from app.services import dl
    try:
        items = [{"id": k, "name": v["name"]} for k, v in dl.SITES.items()]
        items.append({"id": "tiktok", "name": "TikTok"})
        items.append({"id": "tiktok_drama", "name": "TK短剧"})
        return _ok(count=len(items), items=items, root=str(dl.out_root()))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "在多站点里搜剧。site 见 dl_sites；keyword 为空则返回该站全部目录。"
    "返回 slug 列表（后续传给 dl_check / dl_download_eps）"))
def dl_search(site: str = "pinedrama", keyword: str = "", limit: int = 20) -> dict:
    from app.services import dl
    try:
        r = dl.search(site, keyword, limit)
        return _ok(site=site, keyword=keyword, total=r["total"], slugs=r["slugs"])
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "查一部剧的详情：剧名/总集数/免费集/封面/简介。"
    "site + slug（slug 来自 dl_search）。返回 freeEps 是可直接下载的集号"))
def dl_check(site: str, slug: str) -> dict:
    from app.services import dl
    try:
        m = dl.fetch_meta(site, slug)
        free = [e["ep"] for e in (m.get("eps") or []) if e.get("free")]
        return _ok(site=site, slug=slug, name=m.get("name"),
                   total=m.get("total"), freeEps=free,
                   freeCount=len(free), rating=m.get("rating"),
                   desc=(m.get("desc") or "")[:240],
                   cover=m.get("cover"), folder=m.get("folder") or "")
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "按集下载。site + slug（来自 dl_search/dl_check）+ eps 列表如 [1,2,3]。"
    "返回 task_id，用 dl_task 查进度"))
def dl_download_eps(site: str, slug: str, eps: list[int] = [], lang: str = "en") -> dict:
    from app.services import dl, dlq
    try:
        eps = sorted({int(x) for x in eps if int(x) > 0})
        if not eps:
            return _err("eps 不能为空，例如 [1,2,3]")
        m = dl.fetch_meta(site, slug)
        t = dlq.new_task(site, slug, m.get("name") or slug,
                         m.get("cover") or "", eps, lang)
        dlq.submit(t)
        return _ok(task_id=t["id"], site=site, slug=slug,
                   name=m.get("name"), count=len(eps))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="查下载任务进度。task_id 留空则返回全部任务")
def dl_task(task_id: int = 0) -> dict:
    from app.services import dlq
    try:
        items = dlq.snapshot()
        if task_id:
            items = [x for x in items if x["id"] == int(task_id)]
            if not items:
                return _err(f"任务 {task_id} 不存在")
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="列本地已下载的短剧（含站点/集数/大小/目录）")
def dl_library() -> dict:
    from app.services import dl
    try:
        items = dl.scan_local()
        return _ok(series=len(items), files=sum(i["count"] for i in items),
                   bytes=sum(i["bytes"] for i in items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "把已下载的剧送去切片（硬链接到源素材根，切片页可直接选）。"
    "site + dir（dir 来自 dl_library）"))
def dl_send_to_slice(site: str, dir: str) -> dict:
    from app.services import dl
    try:
        r = dl.send_to_slice(site, dir)
        return _ok(**r)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "TikTok 作品元数据。id 可以是作品 ID 或整条链接。"
    "返回作者/播放/点赞/评论/分享/时长/直链数"))
def dl_tiktok_meta(id: str) -> dict:
    from app.services import dl
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID（需要 15–25 位数字）")
        m = dl.tk_meta(vid)
        return _ok(id=vid, author=(m.get("author") or {}).get("uniqueId"),
                   desc=(m.get("desc") or "")[:160],
                   duration=m.get("duration"), stats=m.get("stats"),
                   web_url=m.get("web_url"), cover=m.get("cover"))
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description="下载 TikTok 作品（走 yt-dlp）。id 为作品 ID 或链接，返回 task_id")
def dl_tiktok_download(id: str) -> dict:
    from app.services import dl, dlq
    try:
        vid = dl.tk_id_from(id)
        if not vid:
            return _err("没识别到作品 ID")
        m = dl.tk_meta(vid)
        t = dlq.new_task("tiktok", vid, (m.get("desc") or vid)[:60],
                         m.get("cover") or "", [1], "")
        t["web_url"] = m.get("web_url")
        dlq.submit(t)
        return _ok(task_id=t["id"], vid=vid, url=m.get("web_url"))
    except Exception as e:
        return _err(str(e)[:140])


# ═══════════════════════════════════════════════
#  TK短剧（shortdrama）—— 需要本机 Chrome 调试端口
# ═══════════════════════════════════════════════
@mcp.tool(description=(
    "查 TikTok 短剧详情。id 是 tiktok.com/shortdrama/episode/<ID>/1 里的 ID。"
    "返回剧名/总集数/观看量/分集数。浏览器没开会自动拉起（无头，不弹窗）"))
def dl_sd_meta(id: str) -> dict:
    from app.services import dl
    try:
        m = dl.sd_drama(id)
        return _ok(id=m.get("id"), name=m.get("name"), total=m.get("total"),
                   watched=m.get("watched"), eps=len(m.get("eps") or []),
                   author=(m.get("author") or {}).get("uniqueId"),
                   degraded=bool(m.get("degraded")),
                   cover=m.get("cover") or "")
    except Exception as e:
        return _err(str(e)[:300])


@mcp.tool(description=(
    "批量查 TikTok 短剧。ids 是 ID 列表（最多 50 个）。"
    "串行+节流避免风控；每部最多 90 秒，超时自动跳过不影响其它。"
    "大批量（>5 部）会先返回 jobId，后台继续跑，可用 dl_sd_batch_status 查进度"))
def dl_sd_batch(ids: list[str]) -> dict:
    from app.services import dl
    try:
        ids = [str(x).strip() for x in (ids or []) if str(x).strip()]
        if not ids:
            return _err("ids 不能为空")
        ids = ids[:50]

        # 少量（<=5）直接同步跑，结果立即返回
        if len(ids) <= 5:
            r = dl.sd_batch(ids, timeout_each=90.0)
            return _ok(total=r["total"], ok=r["ok"],
                       elapsed=r.get("elapsed"), items=r["items"])

        # 大批量：起后台线程，立即返回 jobId，避免 agent 长时间无响应
        import threading
        import uuid as _uuid
        job_id = "sdb-" + _uuid.uuid4().hex[:10]
        _SD_BATCH_JOBS[job_id] = {
            "jobId": job_id, "status": "running", "total": len(ids),
            "done": 0, "ok": 0, "items": [], "startedAt": time.time(),
        }

        def _bg():
            st = _SD_BATCH_JOBS[job_id]

            def _prog(i, total, did, result):
                st["done"] = i
                st["total"] = total
                st["items"].append(result)
                if result.get("ok"):
                    st["ok"] += 1

            try:
                r = dl.sd_batch(ids, timeout_each=90.0, on_progress=_prog)
                st["status"] = "done"
                st["ok"] = r.get("ok", st["ok"])
                st["elapsed"] = r.get("elapsed")
            except Exception as e:
                st["status"] = "failed"
                st["error"] = str(e)[:200]
            finally:
                st["endedAt"] = time.time()

        threading.Thread(target=_bg, daemon=True,
                         name="sdbatch-" + job_id).start()
        return _ok(
            jobId=job_id, total=len(ids), status="running",
            hint=("已在后台开始，共 %d 部，每部最多 90 秒。"
                  "用 dl_sd_batch_status(jobId) 查进度，"
                  "别重复提交同一批。" % len(ids)))
    except Exception as e:
        return _err(str(e)[:200])


# 批量查询任务状态表（内存，进程内有效）
_SD_BATCH_JOBS: dict = {}


@mcp.tool(description="查批量短剧查询任务的进度。jobId 从 dl_sd_batch 返回")
def dl_sd_batch_status(jobId: str = "") -> dict:
    if not jobId:
        # 没传就返回全部
        items = []
        for jid, st in _SD_BATCH_JOBS.items():
            items.append({
                "jobId": jid, "status": st.get("status"),
                "done": st.get("done"), "total": st.get("total"),
                "ok": st.get("ok"),
                "elapsed": round((st.get("endedAt") or time.time())
                                 - st.get("startedAt", 0), 1),
            })
        return _ok(count=len(items), jobs=items)

    st = _SD_BATCH_JOBS.get(jobId)
    if not st:
        return _err("找不到任务: " + jobId)
    return _ok(
        jobId=jobId, status=st.get("status"),
        done=st.get("done"), total=st.get("total"), ok=st.get("ok"),
        elapsed=round((st.get("endedAt") or time.time())
                      - st.get("startedAt", 0), 1),
        items=st.get("items") or [],
        error=st.get("error"))


@mcp.tool(description=(
    "查已搜过的 TikTok 短剧历史（本地保留最近 300 条，含剧名/集数/观看量）。"
    "可以用来避免重复查询，或找回之前查过的剧"))
def dl_sd_history(limit: int = 50) -> dict:
    from app.services import dl
    try:
        items = dl.sd_history()[:limit]
        return _ok(count=len(items), items=items)
    except Exception as e:
        return _err(str(e)[:140])


@mcp.tool(description=(
    "管理 TK短剧用的调试浏览器。action: status|start|stop。"
    "headless=true 时不显示窗口；stop 会彻底关闭释放内存"))
def dl_sd_browser(action: str = "status", headless: bool = True) -> dict:
    try:
        from app.services import tk_browser
        a = (action or "status").lower()
        if a == "start":
            r = tk_browser.start(headless=headless)
            return _ok(**r)
        if a == "stop":
            r = tk_browser.stop()
            return _ok(**r)
        return _ok(**tk_browser.status())
    except Exception as e:
        return _err(str(e)[:200])


# ═══════════════════════════════════════════════
#  素材 / 成片
# ═══════════════════════════════════════════════
@mcp.tool(description="列素材库")
def library_list(limit: int = 50) -> dict:
    from app.api import library as lib
    try:
        r = lib.list_items(limit=limit) if hasattr(lib, "list_items") else None
        if r is None:
            from app.services import slicing as sl
            ds = sl.list_dramas()
            return _ok(count=len(ds), items=ds[:limit])
        return _ok(**r) if isinstance(r, dict) else _ok(items=r)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  发布
# ═══════════════════════════════════════════════
@mcp.tool(description="发布视频到 Facebook Reels")
def publish_reels(video_path: str, page_id: str = "",
                  caption: str = "") -> dict:
    from app.services import reels as rl
    try:
        if hasattr(rl, "publish"):
            r = rl.publish(video_path, page_id, caption)
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        return _err("发布模块未提供 publish 接口")
    except Exception as e:
        return _err(f"发布失败: {str(e)[:120]}")


@mcp.tool(description="查可发布的主页列表")
def publish_pages() -> dict:
    from app.services import reels as rl
    try:
        plan = rl.plan_pages() if hasattr(rl, "plan_pages") else []
        return _ok(count=len(plan), pages=plan)
    except Exception as e:
        return _err(f"读取失败: {str(e)[:100]}")


# ═══════════════════════════════════════════════
#  系统
# ═══════════════════════════════════════════════
@mcp.tool(description="系统健康检查")
def system_health() -> dict:
    from app.db import db
    from app.services import envcheck
    e = envcheck.full_check()
    return _ok(ready=e["ok"], warnings=e["warnings"],
               gpu=e["gpu"].get("name"),
               cuda=e["gpu"].get("cuda"))


@mcp.tool(description="读最近日志")
def system_logs(limit: int = 30) -> dict:
    from app.db import db
    rows = db.q("""SELECT ts, level, source, msg FROM events
                   ORDER BY rowid DESC LIMIT ?""", (limit,))
    return _ok(count=len(rows), items=[dict(r) for r in rows])


# ═══════════════════════════════════════════════
#  记忆（跨会话）
# ═══════════════════════════════════════════════
@mcp.tool(description="写记忆（跨会话保留）。常用键：current_drama / preference / last_step")
def memory_set(key: str, value: str) -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.set(key, value))


@mcp.tool(description="读记忆")
def memory_get(key: str) -> dict:
    from app.services import agent_memory as mem
    r = mem.get(key)
    if not r.get("ok"):
        return _err(r.get("error") or "没有这个键", key=key)
    return _ok(key=r["key"], value=r["value"], updatedAt=r["updatedAt"])


@mcp.tool(description="列出所有记忆")
def memory_list() -> dict:
    from app.services import agent_memory as mem
    return _ok(**mem.list_all())


# ═══════════════════════════════════════════════
#  Agent 自身的模型信息
# ═══════════════════════════════════════════════
@mcp.tool(description="列出当前接入 Agent 的模型（含可用性）")
def agent_models() -> dict:
    from app.services import agent_models as am
    o = am.overview()
    return _ok(connected=o["connected"], name=o["name"],
               models=[{"id": m["id"], "role": m.get("role"),
                        "tested": bool((m.get("test") or {}).get("at")),
                        "ok": (m.get("test") or {}).get("ok")}
                       for m in (o["visible"] or [])])


_APP_CACHE = None


def get_app():
    """返回挂到 FastAPI 的 Starlette 应用（**单例**）。

    必须单例：lifespan 里启动的 session manager 与挂载的 app
    必须是同一个对象，否则 streamable-http 会报
    "Task group is not initialized"。
    """
    global _APP_CACHE
    if _APP_CACHE is None:
        _APP_CACHE = mcp.streamable_http_app(
            streamable_http_path="/", stateless_http=True)
    return _APP_CACHE


# 全功能工具（账号/主页/授权/发布/失败诊断等）在 mcp_tools_full 里注册
try:
    from app.legacy.mcp_tools_full import register as _register_full
    _register_full(mcp)
    log.info("mcp_tools_full registered")
except Exception as _e:
    log.warning("mcp_tools_full register failed: %s", _e)

# 剧型工具（列出/判定/手动指定）
try:
    from app.mcp_type import register as _register_type
    _register_type(mcp)
    log.info("mcp_type registered")
except Exception as _e:
    log.warning("mcp_type register failed: %s", _e)

# 邮箱工具（通道配置/测试/拉取/验证码）
try:
    from app.mcp_mail import register as _register_mail
    _register_mail(mcp)
    log.info("mcp_mail registered")
except Exception as _e:
    log.warning("mcp_mail register failed: %s", _e)

# 视频制作工具（clip/concat/vertical/subs/speed/lufs）
try:
    from app.mcp_video import register as _register_video
    _register_video(mcp)
    log.info("mcp_video registered")
except Exception as _e:
    log.warning("mcp_video register failed: %s", _e)

# 文件系统工具（读/写/列目录/搜索/磁盘）
try:
    from app.mcp_fs import register as _register_fs
    _register_fs(mcp)
    log.info("mcp_fs registered")
except Exception as _e:
    log.warning("mcp_fs register failed: %s", _e)
