/* 设置（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import { pageHead, $, $$, toast, badge, ago } from '../ui.js';

let cfg = {};
let paths = { items: [], snapshot: {}, configFile: '' };
let upd = { version: '1.0.0', fileCount: 0, backups: [], hotCount: {} };

/* ── 后台进程管理 ─────────────────────────────────────────── */
const PROC_KIND_LABEL = {
  main: '主程序',
  backend: '后端服务',
  helper: '辅助脚本',
  stray: '⚠ 多余实例',
  other: '其它',
};

async function loadProcesses() {
  const list = document.getElementById('proc-list');
  const badge = document.getElementById('proc-badge');
  const killStray = document.getElementById('proc-kill-stray');
  if (!list) return;

  let d = null;
  try {
    d = await api.processes();
  } catch (e) {
    list.innerHTML = '<div style="color:var(--danger)">读取失败：' + esc(e.message) + '</div>';
    if (badge) badge.textContent = '读取失败';
    return;
  }

  const items = d.items || [];
  if (badge) {
    badge.textContent = items.length + ' 个 · ' + (d.totalMemoryMb || 0) + 'MB';
    badge.className = 'badge ' + (d.strayCount ? 'danger' : 'ok');
  }
  if (killStray) {
    killStray.style.display = d.strayCount ? '' : 'none';
    killStray.textContent = '清理多余实例（' + d.strayCount + '）';
  }

  if (!items.length) {
    list.innerHTML = '<div class="muted">没有相关进程</div>';
    return;
  }

  list.innerHTML = items.map((x) => {
    const isStray = x.kind === 'stray';
    const color = isStray ? 'var(--danger)' : (x.kind === 'main' ? 'var(--ok)' : 'var(--tx-2)');
    return '<div style="display:flex;align-items:center;gap:8px;padding:5px 0;'
      + 'border-bottom:1px solid var(--line)">'
      + '<span style="color:' + color + ';min-width:78px">' + esc(PROC_KIND_LABEL[x.kind] || x.kind) + '</span>'
      + '<span style="font-family:var(--mono);min-width:52px">PID ' + x.pid + '</span>'
      + '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;'
      + 'color:var(--tx-3);font-size:9.5px" title="' + esc(x.cmdline) + '">' + esc(x.cmdline) + '</span>'
      + '<span style="min-width:52px;text-align:right">' + (x.memoryMb || 0) + 'MB</span>'
      + (x.isSelf ? '<span class="badge" style="font-size:8px">当前</span>'
        : '<button class="btn xs ghost" data-proc-kill="' + x.pid + '">结束</button>')
      + '</div>';
  }).join('');

  list.querySelectorAll('[data-proc-kill]').forEach((b) => {
    b.onclick = async () => {
      b.disabled = true;
      try {
        const r = await api.killProcesses({ pids: [Number(b.dataset.procKill)] });
        toast('已结束', (r.note || '') + (r.failed && r.failed.length ? '（部分失败）' : ''),
          r.failed && r.failed.length ? 'warn' : 'ok');
        await loadProcesses();
      } catch (e) {
        toast('结束失败', e.message, 'err');
        b.disabled = false;
      }
    };
  });
}

function bindProcessPanel() {
  const rf = document.getElementById('proc-refresh');
  if (rf) rf.onclick = () => loadProcesses();

  const ks = document.getElementById('proc-kill-stray');
  if (ks) ks.onclick = async () => {
    ks.disabled = true;
    try {
      const r = await api.killProcesses({ onlyStray: true });
      toast('已清理', r.note || '', 'ok');
      await loadProcesses();
    } catch (e) {
      toast('清理失败', e.message, 'err');
    } finally {
      ks.disabled = false;
    }
  };

  loadProcesses();
}

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '设置',
      desc: '全局配置、路径、安全阀',
      actions: [`<button class="btn sm primary" data-act="save">保存配置</button>`],
    })}
    <div id="st-body"></div>
  `;
  $$('[data-act="save"]', root).forEach((b) => (b.onclick = () => doSave(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    cfg = await api.config();
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  try {
    paths = await api.envPaths();
  } catch { paths = { items: [], snapshot: {}, configFile: '' }; }
  try {
    upd = await api.updateStatus();
  } catch { /* ignore */ }
  paint(root);
  bindPaths(root);
  bindEnv(root);
  // 检查内置 ffmpeg
  try {
    const env = await api.videoEnv();
    const a = document.getElementById('ff-status');
    const b = document.getElementById('ffp-status');
    if (a) a.innerHTML = env.ok
      ? `<span style="color:var(--ok)">✓ ${env.bundled ? '内置' : '系统'} · ${esc((env.version || '').slice(0, 40))}</span>`
      : `<span style="color:var(--danger)">✗ ${esc(env.error || '不可用')}</span>`;
    if (b) b.innerHTML = env.ok
      ? `<span style="color:var(--ok)">✓ 可用</span>`
      : `<span style="color:var(--danger)">✗</span>`;
  } catch { /* ignore */ }
}

/* ---------------- 环境自检 ---------------------------- */
const ENV_ROW = (ok, label, detail, action) => `
  <div style="display:flex;align-items:center;gap:8px;padding:3px 0">
    <span style="width:14px;color:${ok ? 'var(--ok)' : 'var(--danger)'}">
      ${ok ? '✓' : '✗'}</span>
    <span style="width:96px;color:var(--tx-2)">${label}</span>
    <span style="flex:1;color:var(--tx-3);font-size:9.5px">${detail}</span>
    ${action || ''}
  </div>`;

function renderEnv(root, d) {
  const list = document.getElementById('env-list');
  const badge = document.getElementById('env-badge');
  if (!list) return;

  const rows = [];

  // Python 包
  const pyMiss = (d.python || []).filter((p) => !p.ok && p.required);
  rows.push(ENV_ROW(pyMiss.length === 0,
    'Python 包',
    pyMiss.length ? `缺 ${pyMiss.map((p) => p.name).join(', ')}`
                  : `${(d.python || []).length} 个就位`,
    pyMiss.length ? `<button class="btn xs" data-env="python">安装</button>` : ''));

  // FFmpeg
  rows.push(ENV_ROW(d.ffmpeg?.ok, 'FFmpeg',
    d.ffmpeg?.ok
      ? `${d.ffmpeg.bundled ? '内置' : '系统'} · NVENC ${d.ffmpeg.nvenc ? '可用' : '不可用'}`
      : (d.ffmpeg?.version || '不可用'),
    !d.ffmpeg?.ok ? `<button class="btn xs" data-env="ffmpeg">安装</button>` : ''));

  // ASR 模型（关键）
  const m = d.model || {};
  rows.push(ENV_ROW(m.ok, 'ASR 模型',
    m.ok ? `${m.name} · ${m.sizeMb || 0}MB · ${m.where || ''}`
         : (m.hint || `缺 ${m.name}`),
    !m.ok ? `<button class="btn xs primary" data-env="whisper">下载 ${m.needMb || ''}MB</button>` : ''));

  // 脚本版本
  const t = d.tools || {};
  const staleN = (t.stale || []).length;
  const missN = (t.missing || []).length;
  rows.push(ENV_ROW(t.ok && !staleN,
    '切片脚本',
    missN ? `缺 ${missN} 个` : (staleN ? `${staleN} 个版本旧` : `${Object.keys(t.scripts || {}).length} 个就位`),
    (staleN || missN) ? `<button class="btn xs" data-env="tools">更新</button>` : ''));

  // GPU / CUDA
  const g = d.gpu || {};
  if (g.ok) {
    rows.push(ENV_ROW(g.cuda, 'GPU 加速',
      g.cuda ? `${g.name} · CUDA 可用`
             : `${g.name} · CUDA 不可用（走 CPU，慢 5-10 倍）`,
      !g.cuda ? `<button class="btn xs" data-env="cuda">修复</button>` : ''));
  } else {
    rows.push(ENV_ROW(false, 'GPU 加速', '无 NVIDIA 显卡，转录走 CPU', ''));
  }

  // 字体/BGM
  const a = d.assets || {};
  rows.push(ENV_ROW(a.ok, '字体/BGM',
    a.ok ? `${a.fontCount} 字体 · ${a.bgmCount} BGM · ${a.sfxCount} 音效` : '缺失',
    !a.ok ? `<button class="btn xs" data-env="assets">查看</button>` : ''));

  // 代理
  const px = d.proxy || {};
  rows.push(ENV_ROW(px.alive, '代理',
    px.alive ? `${px.proxy} 可用` : (px.hint || '未启动（抓取功能不可用）'), ''));

  list.innerHTML = rows.join('');

  // 徽章
  const fixN = (d.fixable || []).length;
  if (badge) {
    badge.textContent = d.ok && !fixN ? '全部就绪' : `${fixN} 项待修复`;
    badge.style.color = d.ok && !fixN ? 'var(--ok)' : 'var(--danger)';
  }
  const btn = document.getElementById('env-fixall');
  if (btn) btn.disabled = !fixN;

  // 绑定按钮
  $$('[data-env]', root).forEach((b) => {
    b.onclick = () => runEnvInstall(root, b.dataset.env, b);
  });
}

async function checkEnv(root) {
  const list = document.getElementById('env-list');
  if (list) list.innerHTML = '正在检测环境…';
  try {
    const d = await api.envFull();
    renderEnv(root, d);
    return d;
  } catch (e) {
    if (list) list.innerHTML = `<span style="color:var(--danger)">检测失败: ${esc(e.message)}</span>`;
    return null;
  }
}

async function runEnvInstall(root, what, btn) {
  const out = document.getElementById('env-out');
  const oldText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '处理中…';
  if (out) {
    out.style.display = 'block';
    out.textContent = `正在处理 ${what}…\n（下载大文件可能几分钟，别关窗口）`;
  }
  try {
    const r = await api.envInstall(what);
    // 打印日志
    const logs = [];
    if (r.steps) {
      for (const s of r.steps) {
        logs.push(`[${s.ok ? 'OK' : 'FAIL'}] ${s.what}: ${s.detail}`);
        for (const l of (s.log || [])) logs.push('    ' + l);
      }
    } else {
      logs.push(`[${r.ok ? 'OK' : 'FAIL'}] ${r.note || r.error || ''}`);
      if (r.attempts) for (const a of r.attempts) {
        logs.push(`    ${a.file || a.source || a.pkg || a.tool}: ` +
                  `${a.ok ? 'OK' : (a.error || '失败')}`);
      }
      for (const m of (r.manual || [])) logs.push('  · ' + m);
    }
    if (out) out.textContent = logs.join('\n');
    toast(r.ok ? '处理完成' : '部分失败', (r.note || r.error || '').slice(0, 60),
          r.ok ? 'ok' : 'err');
    // 刷新检测
    await checkEnv(root);
  } catch (e) {
    if (out) out.textContent = '失败: ' + (e.message || e);
    toast('执行失败', String(e.message || e).slice(0, 60), 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = oldText;
  }
}

function bindEnv(root) {
  const rf = document.getElementById('env-refresh');
  if (rf) rf.onclick = () => { rf.disabled = true; checkEnv(root).finally(() => { rf.disabled = false; }); };
  const fa = document.getElementById('env-fixall');
  if (fa) fa.onclick = () => runEnvInstall(root, 'all', fa);
  checkEnv(root);
}

/* ---------------- 路径配置 ---------------- */
function bindPaths(root) {
  const save = document.getElementById('path-save');
  if (save) {
    save.onclick = async () => {
      const patch = {};
      $$('.path-in', root).forEach((el) => {
        if (!el.readOnly) patch[el.dataset.key] = el.value.trim();
      });
      save.disabled = true; save.textContent = '保存中…';
      try {
        const r = await api.envPathsSave(patch);
        toast('已保存', r.note || '', 'ok', 6000);
        paths = await api.envPaths();
        paint(root); bindPaths(root);
      } catch (e) { toast('保存失败', e.message, 'err'); }
      finally { save.disabled = false; save.textContent = '保存'; }
    };
  }
  const ens = document.getElementById('path-ensure');
  if (ens) {
    ens.onclick = async () => {
      ens.disabled = true; ens.textContent = '创建中…';
      try {
        const r = await api.envEnsureDirs();
        toast(r.created.length ? `已创建 ${r.created.length} 个目录` : '目录都已存在',
          (r.created || []).join('\n'), 'ok', 6000);
        paths = await api.envPaths();
        paint(root); bindPaths(root);
      } catch (e) { toast('创建失败', e.message, 'err'); }
      finally { ens.disabled = false; ens.textContent = '创建缺失目录'; }
    };
  }
}

function paint(root) {
  const body = $('#st-body', root);
  if (!body) return;
  const h = store.summary || {};

  body.innerHTML = `
      <!-- 环境自检（换电脑先跑这个） -->
      <div class="card" style="margin-bottom:13px" id="env-card">
        <div class="card-head">
          <div class="card-title">
            <span data-icon="shield"></span> 环境自检
            <span class="chip" id="env-badge" style="margin-left:6px;font-size:9px">检测中…</span>
          </div>
          <div style="display:flex;gap:6px;align-items:center">
            <button class="btn xs" id="env-refresh">重新检测</button>
            <button class="btn xs primary" id="env-fixall" disabled>一键修复</button>
          </div>
        </div>
        <div class="card-body" style="padding:10px 14px">
          <div id="env-list" style="font-size:10px;line-height:1.9;color:var(--tx-3)">
            正在检测环境…
          </div>
          <div id="env-out" style="display:none;margin-top:8px;padding-top:8px;
               border-top:1px solid var(--line);font-family:var(--mono);
               font-size:9px;line-height:1.7;color:var(--tx-3);
               max-height:180px;overflow:auto;white-space:pre-wrap"></div>
        </div>
      </div>
      <!-- 热更新 -->
      <div class="card" style="margin-bottom:13px">
        <div class="card-head">
          <div class="card-title">
            <span data-icon="refresh"></span> 系统更新
            <span class="chip" style="margin-left:6px;font-family:var(--mono);font-size:9px">
              v${esc(upd.version || '1.0.0')}</span>
          </div>
          <div style="display:flex;gap:6px;align-items:center">
            <span style="font-size:9.5px;color:var(--tx-3)">
              ${upd.fileCount || 0} 文件 · ${esc(upd.updatedAt ? ago(upd.updatedAt) : '未更新过')}</span>
            <input type="file" id="upd-file" accept=".zip" style="display:none" />
            <button class="btn xs" id="upd-check">检查更新</button>
            <button class="btn xs ghost" id="upd-pick">选包</button>
            <button class="btn xs primary" id="upd-apply" disabled>应用</button>
          </div>
        </div>
        <div class="card-body" style="padding:10px 14px">
          <div style="display:flex;gap:6px;align-items:center;margin-bottom:8px">
            <span style="font-size:9.5px;color:var(--tx-3);white-space:nowrap">
              更新源</span>
            <input type="text" id="upd-remote"
              placeholder="留空=扫本地包；填 https://cdn.jsdelivr.net/gh/USER/REPO@main/manifest.json"
              style="flex:1;background:var(--bg-2);border:1px solid var(--line);
                     border-radius:5px;padding:4px 7px;font-size:9.5px;
                     font-family:var(--mono);color:var(--tx-2);outline:none" />
            <button class="btn xs ghost" id="upd-save-src">保存</button>
          </div>
          <div id="upd-out" style="font-size:10px;line-height:1.8;color:var(--tx-3)">
            点「检查更新」自动扫描更新包
          </div>
          ${(upd.backups || []).length ? `
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;
                      padding-top:8px;border-top:1px solid var(--line)">
            ${upd.backups.map((b) => `
              <button class="btn xs ghost" data-rollback="${esc(b.name)}"
                      style="font-family:var(--mono);font-size:9px">
                ↩ ${esc(b.name.slice(-8))}
              </button>`).join('')}
          </div>` : ''}
        </div>
      </div>
    <div class="grid g2">
      <div class="card">
      <div class="card">
        <div class="card-head"><div class="card-title">账号与环境</div></div>
        <div class="card-body">
          ${(store.envs || []).filter((e) => e.role !== 'spare').map((a) => `
            <div class="field" style="border:1px solid var(--line-soft);border-radius:var(--r-md);padding:11px 12px">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                <strong style="font-size:12.5px">${esc(a.roleLabel)}</strong>
                <span class="badge ${a.role === 'publisher' ? 'info' : 'purple'}">${esc(a.name)}</span>
                <span class="chip ghost" style="margin-left:auto">${a.containerCode}</span>
              </div>
              <div class="row-2">
                <div class="field" style="margin:0"><label>邮箱</label>
                  <input class="input" value="${esc(a.account || '未登录')}" readonly style="color:var(--tx-2)" /></div>
                <div class="field" style="margin:0"><label>c_user</label>
                  <input class="input" value="${a.cUser || '—'}" readonly style="color:var(--tx-2)" /></div>
              </div>
            </div>`).join('') || '<div class="hint">未发现环境</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">路径（跨环境可改）</div>
          <div style="display:flex;gap:5px">
            <button class="btn xs ghost" id="path-ensure">创建缺失目录</button>
            <button class="btn xs primary" id="path-save">保存</button>
          </div>
        </div>
        <div class="card-body">
          <div class="hint" style="margin-bottom:9px">
            换电脑/换目录只改这里。优先级：环境变量 &gt; 本页保存的值 &gt; 自动发现。
            保存后写入 <code style="font-family:var(--mono)">config.json</code>，重启生效。
          </div>
          ${(paths.items || []).map((p) => `
            <div class="field" style="margin-bottom:8px">
              <label style="display:flex;align-items:center;gap:6px">
                ${esc(p.label)}
                <span class="badge ${p.source === '自动发现' ? 'mute'
                  : p.source === '环境变量' ? 'info' : 'ok'}" style="font-size:8.5px">${p.source}</span>
                <span style="margin-left:auto;font-size:9px;color:var(--tx-3);
                             font-family:var(--mono)">${esc(p.envKey)}</span>
              </label>
              <input class="input path-in" data-key="${esc(p.key)}"
                     value="${esc(p.value || '')}"
                     ${p.source === '环境变量' ? 'readonly' : ''}
                     style="font-family:var(--mono);font-size:10.5px;
                            ${p.source === '环境变量' ? 'color:var(--tx-2)' : ''}" />
            </div>`).join('')}
          <div class="field" style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)">
            <label>只读信息</label>
            <div style="font-size:10px;color:var(--tx-2);line-height:1.9;font-family:var(--mono)">
              <div>数据目录 ${esc(paths.snapshot?.dataDir || cfg.dataDir || '')}</div>
              <div>数据库 ${esc(cfg.dbPath || '')}</div>
              <div>前端 ${esc(cfg.frontendDir || '')}</div>
              <div>配置文件 ${esc(paths.configFile || '')}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">网络与接口</div></div>
        <div class="card-body">
          <div class="row-2">
            <div class="field"><label>Hubstudio API</label>
              <input class="input" id="cfg-hubstudioApi" value="${esc(cfg.hubstudioApi || '')}"
                     style="font-family:var(--mono);font-size:11px" /></div>
            <div class="field"><label>Clash API</label>
              <input class="input" id="cfg-clashApi" value="${esc(cfg.clashApi || '')}"
                     style="font-family:var(--mono);font-size:11px" /></div>
          </div>
          <div class="field">
            <label>Node 命令</label>
            <input class="input" readonly value="${esc((cfg.nodeCommand || []).join(' '))}"
                   style="font-family:var(--mono);font-size:11px;color:var(--tx-2)" />
            <div class="hint">用于跑 ReelsPublisher 的 .mjs 脚本</div>
          </div>
          <div class="kv"><span class="k">后端端口</span><span class="v">${cfg.port || 8710}</span></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">AI 模型端点</div></div>
        <div class="card-body">
          <div class="field">
            <label>OpenAI 兼容端点（base URL）</label>
            <input class="input" id="cfg-llmBase" value="${esc(cfg.llmBase || '')}"
                   placeholder="https://api.deepseek.com" style="font-family:var(--mono);font-size:11px" />
            <div class="hint">
              DSH 的免费模型不对外暴露网关，要 AI 分析生效需填一个兼容端点。
              留空则 AI 分析走规则统计兜底（不编造结论）。
            </div>
          </div>
          <div class="field">
            <label>API Key</label>
            <input class="input" id="cfg-llmKey" type="password" value="${esc(cfg.llmKey || '')}"
                   placeholder="sk-..." style="font-family:var(--mono);font-size:11px" />
          </div>
          <div class="field">
            <label>默认模型名</label>
            <input class="input" id="cfg-llmModel" value="${esc(cfg.llmModel || 'deepseek-chat')}"
                   placeholder="deepseek-chat" style="font-family:var(--mono);font-size:11px" />
          </div>
          <div class="kv"><span class="k">当前状态</span>
            <span class="v" style="color:${cfg.llmBase ? 'var(--ok)' : 'var(--warn)'}">
              ${cfg.llmBase ? '已配置' : '未配置（规则兜底）'}</span></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">内置工具</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">ffmpeg</span>
            <span class="v" id="ff-status">检查中…</span></div>
          <div class="kv"><span class="k">ffprobe</span>
            <span class="v" id="ffp-status">检查中…</span></div>
          <div style="margin-top:9px;padding:9px 11px;background:var(--bg-0);
                      border-radius:var(--r-sm);font-size:10px;color:var(--tx-3);line-height:1.7">
            视频制作全部用内置 ffmpeg，不依赖外部程序。换电脑照样能用。
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">安全阀（后端强制）</div></div>
        <div class="card-body">
          ${[
            ['授权只认 profile ID', '姓名/邮箱请求 → 422', true],
            ['建主页每日上限', '默认 2，超出 400', true],
            ['服务端拒绝即停手', '非 transient 错误直接 break', true],
            ['发布只认受理回执', '看不到回执判失败', true],
            ['失败不删素材', '仅成功才 unlink', true],
            ['排期每日上限', '同页同日超出 → 400', true],
            ['排期最小间隔', '默认 120 分钟', true],
            ['风控命中即熔断', '账号级整批停止', true],
            ['标签页复用', '单实例单标签', true],
          ].map(([k, v, on]) => `
            <div class="litem" style="padding:7px 0">
              <span class="dot ${on ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">${k}</div>
                <div class="litem-sub" style="font-family:var(--sans);font-size:10px">${v}</div>
              </div>
              ${on ? badge('启用', 'ok') : badge('关闭', 'mute')}
            </div>`).join('')}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">数据概况</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">主页</span><span class="v">${h.pages || 0} 个</span></div>
          <div class="kv"><span class="k">视频</span><span class="v">${h.videoCount || 0} 条</span></div>
          <div class="kv"><span class="k">素材库</span><span class="v">${h.libReady || 0} 条可发布</span></div>
          <div class="kv"><span class="k">队列</span><span class="v">${h.queueReady || 0} 条待发</span></div>
          <div class="kv"><span class="k">排期</span><span class="v">${h.schedulePlanned || 0} 条已排</span></div>
          <div class="kv"><span class="k">风控未处理</span><span class="v" style="color:${h.alerts ? 'var(--danger)' : 'var(--ok)'}">${h.alerts || 0} 条</span></div>
        </div>
      </div>

      <div class="card" id="proc-card">
        <div class="card-head">
          <div class="card-title">后台进程
            <span class="badge" id="proc-badge" style="margin-left:6px">读取中…</span></div>
          <div style="display:flex;gap:6px">
            <button class="btn xs ghost" id="proc-refresh">刷新</button>
            <button class="btn xs danger" id="proc-kill-stray"
              style="display:none">清理多余实例</button>
          </div>
        </div>
        <div class="card-body">
          <p class="muted" style="font-size:10.5px;line-height:1.7;margin:0 0 8px">
            这里列出本工作台相关的所有进程。多余的「工作台实例」通常是辅助脚本被误当主程序启动，
            占内存且看不到窗口，可以直接清理。
          </p>
          <div id="proc-list" style="font-size:10.5px">
            <div class="muted">读取中…</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">关于</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">版本</span><span class="v">${esc(upd.version || '1.0.0')}</span></div>
          <div class="kv"><span class="k">前端</span><span class="v">原生 JS · 无构建</span></div>
          <div class="kv"><span class="k">后端</span><span class="v">FastAPI · SQLite WAL</span></div>
          <div class="kv"><span class="k">浏览器控制</span><span class="v">裸 CDP WebSocket</span></div>
          <div class="kv"><span class="k">发布内核</span><span class="v">ReelsPublisher v19.7</span></div>
        </div>
      </div>

    </div>
  `;
  bindUpdate(root);
  bindProcessPanel();
}

/* ---------------- 热更新绑定 ---------------- */
function bindUpdate(root) {
  const fileIn = document.getElementById('upd-file');
  const pick = document.getElementById('upd-pick');
  const check = document.getElementById('upd-check');
  const apply = document.getElementById('upd-apply');
  const out = document.getElementById('upd-out');
  let picked = null;
  let found = null;   // 检查更新发现的包

  const say = (html) => { if (out) out.innerHTML = html; };
  // 远程更新源：从 localStorage 恢复 + 保存按钮
  const remoteIn = document.getElementById('upd-remote');
  const saveSrc = document.getElementById('upd-save-src');
  try {
    const saved = localStorage.getItem('yuhai_update_remote') || '';
    if (remoteIn && saved) remoteIn.value = saved;
  } catch (e) { /* ignore */ }
  if (saveSrc && remoteIn) {
    saveSrc.onclick = () => {
      try { localStorage.setItem('yuhai_update_remote', remoteIn.value.trim()); }
      catch (e) { /* ignore */ }
      toast('已保存', remoteIn.value ? '下次检查用这个源' : '改回扫本地', 'ok');
    };
  }

  /* ---- 检查更新（自动扫 _updates）---- */
  if (check) {
    check.onclick = async () => {
      check.disabled = true; check.textContent = '检查中…';
      say('<div style="color:var(--tx-2)">正在扫描更新包…</div>');
      try {
        const remote = (document.getElementById('upd-remote')?.value || '').trim();
        const r = await api.updateCheck(remote);
        if (r.hasUpdate && r.latest) {
          found = r.latest;
          say(`<div style="color:var(--ok)">✓ 发现新版本
                <b>${esc(r.latest.version)}</b>
                · ${r.latest.fileCount} 文件 · ${r.latest.sizeMb} MB</div>
              <div style="color:var(--tx-3);font-size:9px">
                当前 v${esc(r.current)} → 新 v${esc(r.latest.version)}
              </div>
              <div style="margin-top:7px">
                <button class="btn xs primary" id="upd-go">立即更新</button>
              </div>`);
          toast('发现新版本', `${r.current} → ${r.latest.version}`, 'ok', 7000);
          // 绑定「立即更新」
          const go = document.getElementById('upd-go');
          if (go) go.onclick = () => runAuto(r.latest.version);
        } else {
          found = null;
          const cnt = (r.candidates || []).length;
          say(`<div style="color:var(--tx-2)">已是最新版本 v${esc(r.current)}</div>
               <div style="color:var(--tx-3);font-size:9px">
                 目录 ${cnt} 个包 · 没有比当前更新的
               </div>`);
          toast('已是最新', `v${r.current}`, 'ok', 5000);
        }
      } catch (e) {
        say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
        toast('检查失败', e.message, 'err', 7000);
      } finally { check.disabled = false; check.textContent = '检查更新'; }
    };
  }

  /* ---- 一键更新（Auto）---- */
  async function runAuto(ver) {
    if (!confirm(`更新到 ${ver}？\n会自动备份，然后 3 秒后重启程序。`)) return;
    check && (check.disabled = true);
    say('<div style="color:var(--tx-2)">正在应用更新…</div>');
    try {
      const remote = (document.getElementById('upd-remote')?.value || '').trim();
      const r = await api.updateAuto(true, remote);
      if (r.hasUpdate === false) {
        say(`<div style="color:var(--tx-2)">${esc(r.note || '已是最新')}</div>`);
        return;
      }
      say(`<div style="color:var(--ok)">✓ 已更新到 ${esc(r.version)}
            （${r.files} 个文件）</div>
           <div style="color:var(--tx-3)">${esc(r.from || '')} → ${esc(r.version)}</div>
           <div style="color:var(--warn)">程序即将重启…</div>`);
      toast('更新成功', '3 秒后重启', 'ok', 8000);
    } catch (e) {
      say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
      toast('更新失败', e.message, 'err', 8000);
      if (check) { check.disabled = false; check.textContent = '检查更新'; }
    }
  }

  /* ---- 手动选包 ---- */
  if (pick && fileIn) {
    pick.onclick = () => fileIn.click();
    fileIn.onchange = async () => {
      const f = fileIn.files?.[0];
      if (!f) return;
      picked = null;
      apply.disabled = true;
      say(`<div style="color:var(--tx-2)">校验中：${esc(f.name)} …</div>`);
      try {
        const r = await api.updateUpload(f);
        picked = r;
        say(`<div style="color:var(--ok)">✓ 包有效 · v${esc(r.version)}
              · ${r.fileCount} 文件</div>`);
        apply.disabled = false;
        toast('更新包已校验', `${r.version} · ${r.fileCount} 文件`, 'ok');
      } catch (e) {
        say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
        toast('校验失败', e.message, 'err', 7000);
      }
    };
  }

  if (apply) {
    apply.onclick = async () => {
      if (!picked) return;
      if (!confirm(`应用更新到 ${picked.version}？\n会先自动备份，然后 3 秒后重启程序。`)) return;
      apply.disabled = true;
      apply.textContent = '应用中…';
      say('<div style="color:var(--tx-2)">正在覆盖文件并校验…</div>');
      try {
        const r = await api.updateApply(true);
        say(`<div style="color:var(--ok)">✓ 已更新到 ${esc(r.version)}（${r.files} 个文件）</div>
             <div style="color:var(--warn)">程序即将重启…</div>`);
        toast('更新成功', '3 秒后重启', 'ok', 8000);
      } catch (e) {
        say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
        toast('更新失败', e.message, 'err', 8000);
        apply.disabled = false;
        apply.textContent = '应用';
      }
    };
  }

  $$('[data-rollback]', root).forEach((b) => {
    b.onclick = async () => {
      const name = b.dataset.rollback;
      if (!confirm(`回滚到 ${name}？\n当前 app/frontend 会被该备份覆盖，然后重启。`)) return;
      b.disabled = true;
      try {
        const r = await api.updateRollback(name);
        toast('已回滚', `${r.backup} · 3 秒后重启`, 'ok', 8000);
        say(`<div style="color:var(--ok)">✓ 已回滚到 ${esc(r.backup)}</div>`);
      } catch (e) {
        toast('回滚失败', e.message, 'err', 7000);
        b.disabled = false;
      }
    };
  });
}

async function doSave(root) {
  const patch = {};
  const g = (id) => {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
  };
  ['hubstudioApi', 'clashApi', 'reelsEnvDir', 'libraryRoot',
   'llmBase', 'llmKey', 'llmModel'].forEach((k) => {
    const v = g('cfg-' + k);
    if (v !== '') patch[k] = v;
  });
  const roots = g('cfg-assetRoots');
  if (roots) patch.assetRoots = roots.split(';').map((s) => s.trim()).filter(Boolean);
  try {
    await api.saveConfig(patch);
    toast('已保存', '部分配置需重启后端生效', 'ok', 5000);
    await load(root);
  } catch (e) {
    toast('保存失败', e.message, 'err');
  }
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
