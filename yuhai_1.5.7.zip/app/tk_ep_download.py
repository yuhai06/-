#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TK短剧单集下载（独立子进程）—— v2 基于接口

为什么推翻 v1：
    v1 抓的是页面 video 元素发出的媒体流，那是「推荐流/广告/预览片」，
    内容跟目标剧毫无关系。ffprobe 一验就露馅（时长 16s / 画面是俄语剧）。

v2 正确链路（实盘验证）：
    ① /api/drama/episode/item_list/   → 拿 item_id + duration
    ② /api/item/detail/?itemId=xxx    → 拿 video.playAddr + bitrateInfo
    ③ 页面内 fetch(credentials:'include') + Range 分块下载
    ④ 校验：字节数 == size、ffprobe 时长 ≈ duration

前置条件：Chrome 已登录 TikTok（playAddr 只有登录后才下发）。
    未登录时 playAddr 为空，v2 会直接报错而不是下错内容。

用法:
    python tk_ep_download.py <drama_id> <ep> <out_path> [--cdp URL] [--quality best|1080]
输出: 一行 JSON {"ok":bool,"bytes":N,"duration":F,"quality":str,"err":str}
"""
import base64
import io
import json
import os
import subprocess
import sys
import time

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 接口需要的完整 web 参数（缺一个就可能返回空）
BASE_QS = (
    "aid=1988&app_name=tiktok_web&device_platform=web_pc"
    "&browser_language=zh-CN&browser_platform=Win32&browser_name=Mozilla"
    "&browser_version=5.0&channel=tiktok_web&cookie_enabled=true"
    "&device_id=&os=windows&priority_region=&referer=&region=US"
    "&screen_height=1080&screen_width=1920&tz_name=Asia%2FShanghai"
)

# 取分集列表（支持翻页，一页 30 条）
JS_EP_LIST = r"""async (args) => {
    const [did, base, cursor] = args;
    const qs = new URLSearchParams(base);
    qs.set('dramaID', did);
    qs.set('count', '30');
    qs.set('cursor', String(cursor || 0));
    qs.set('from_page', 'short_drama');
    try {
        const r = await fetch('https://www.tiktok.com/api/drama/episode/item_list/?' + qs,
            {credentials: 'include'});
        const t = await r.text();
        const j = JSON.parse(t);
        return {
            status: r.status,
            items: (j.itemList || []).map(it => ({
                id: it.id,
                ep: (((it.dramaInfo || {}).DramaVideoData) || {}).EpisodeNumber || 0,
                dur: (it.video || {}).duration || 0,
            })),
            hasMore: !!j.hasMore,
            cursor: j.cursor || 0,
        };
    } catch (e) {
        return {err: String(e).slice(0, 100)};
    }
}"""


def collect_episodes(pg, drama_id: str, want_ep: int, max_pages: int = 6) -> dict:
    """翻页找目标集。返回 {item_id, duration} 或 {err}

    大多数情况第 1 页就命中，只在目标集靠后时才翻页，
    避免每集都多打几次接口（TikTok 对短剧接口有频率限制）。
    """
    cursor = 0
    seen = 0
    pages = 0
    first_dur = {}
    while pages < max_pages:
        r = pg.evaluate(JS_EP_LIST, [drama_id, BASE_QS, cursor])
        pages += 1
        if r.get("err"):
            return {"err": f"取分集列表失败: {r['err']}"}

        items = r.get("items") or []
        if not items:
            break

        for it in items:
            ep = int(it.get("ep") or 0)
            seen += 1
            if ep and ep not in first_dur:
                first_dur[ep] = float(it.get("dur") or 0)
            if ep == want_ep:
                return {
                    "item_id": str(it["id"]),
                    "duration": float(it.get("dur") or 0),
                    "pages": pages,
                    "scanned": seen,
                }

        if not r.get("hasMore"):
            break
        nc = int(r.get("cursor") or 0)
        if nc == cursor:
            break
        cursor = nc
        time.sleep(0.8)      # 页间小歇，降风控

    avail = sorted(first_dur.keys())
    rng = f"{avail[0]}~{avail[-1]}" if avail else "无"
    return {"err": f"分集列表里没有第 {want_ep} 集"
                   f"（翻了 {pages} 页共 {seen} 条，集号范围 {rng}）"}

# 取单集详情（拿 playAddr）
JS_ITEM = r"""async (args) => {
    const [itemId, base] = args;
    try {
        const r = await fetch(
            `https://www.tiktok.com/api/item/detail/?itemId=${itemId}&${base}`,
            {credentials: 'include'});
        const t = await r.text();
        if (!t) return {err: 'empty response'};
        const j = JSON.parse(t);
        const st = (j.itemInfo || {}).itemStruct;
        if (!st) return {err: 'no itemStruct (可能需要登录)'};
        const v = st.video || {};
        return {
            playAddr: v.playAddr || '',
            downloadAddr: v.downloadAddr || '',
            duration: v.duration || 0,
            width: v.width || 0, height: v.height || 0,
            size: v.size || 0,
            ratio: v.ratio || '',
            desc: (st.desc || '').slice(0, 80),
            bitrates: (v.bitrateInfo || []).map(b => ({
                gear: b.GearName || '',
                bitrate: b.Bitrate || 0,
                w: ((b.PlayAddr || {}).Width) || 0,
                h: ((b.PlayAddr || {}).Height) || 0,
                url: (((b.PlayAddr || {}).UrlList) || [''])[0] || '',
            })),
        };
    } catch (e) {
        return {err: String(e).slice(0, 100)};
    }
}"""

# 分块取数据 + 返回 Content-Range 里的总大小
JS_FETCH = r"""async (args) => {
    const [u, start, size] = args;
    try {
        const r = await fetch(u, {
            credentials: 'include',
            headers: {'Range': `bytes=${start}-${start + size - 1}`}
        });
        const cr = r.headers.get('content-range') || '';
        const m = cr.match(/\/(\d+)\s*$/);
        const total = m ? parseInt(m[1], 10) : 0;
        if (r.status !== 200 && r.status !== 206) {
            return {err: 'status ' + r.status, total};
        }
        const buf = new Uint8Array(await r.arrayBuffer());
        let s = '';
        for (let i = 0; i < buf.length; i += 8192) {
            s += String.fromCharCode.apply(null,
                buf.subarray(i, Math.min(i + 8192, buf.length)));
        }
        return {len: buf.length, total, b64: btoa(s)};
    } catch (e) {
        return {err: String(e).slice(0, 80)};
    }
}"""


def ffprobe_duration(path: str) -> float:
    """读时长；找不到 ffprobe 就返回 0"""
    cands = []
    try:
        from app import paths
        ff, fp = paths.ffmpeg()
        if fp:
            cands.append(str(fp))
    except Exception:
        pass
    here = os.path.dirname(os.path.abspath(__file__))
    cands += [
        os.path.join(here, "..", "bin", "ffprobe.exe"),
        os.path.join(here, "..", "..", "bin", "ffprobe.exe"),
        r"C:\Users\m1989\.local\bin\ffprobe.EXE",
        "ffprobe",
    ]
    for c in cands:
        try:
            if c != "ffprobe" and not os.path.exists(c):
                continue
            p = subprocess.run(
                [c, "-v", "error", "-show_entries", "format=duration",
                 "-of", "csv=p=0", path],
                capture_output=True, text=True, timeout=30,
                creationflags=(0x08000000 if os.name == "nt" else 0))
            t = (p.stdout or "").strip()
            if t:
                return float(t)
        except Exception:
            continue
    return 0.0


def pick_url(info: dict, quality: str = "best") -> tuple[str, str]:
    """按质量策略选 URL，返回 (url, 说明)

    best  → 码率最高（默认，画质最实）
    1080  → 分辨率最高（优先 1080x1920）
    """
    brs = [b for b in (info.get("bitrates") or []) if b.get("url")]
    if brs:
        if quality == "1080":
            brs.sort(key=lambda b: (b.get("h") or 0, b.get("bitrate") or 0),
                     reverse=True)
        else:
            brs.sort(key=lambda b: (b.get("bitrate") or 0, b.get("h") or 0),
                     reverse=True)
        b = brs[0]
        return b["url"], f"{b['gear']} {b['w']}x{b['h']} {b['bitrate']}bps"

    addr = info.get("playAddr") or info.get("downloadAddr")
    if addr:
        return addr, f"playAddr {info.get('width')}x{info.get('height')}"
    return "", "无可用地址"


def main():
    if len(sys.argv) < 4:
        print(json.dumps({"ok": False, "err": "用法: <drama_id> <ep> <out_path>"}))
        return 1

    drama_id = sys.argv[1].strip()
    ep = int(sys.argv[2])
    out_path = sys.argv[3]
    cdp = "http://127.0.0.1:9222"
    quality = "best"
    for i, a in enumerate(sys.argv):
        if a == "--cdp" and i + 1 < len(sys.argv):
            cdp = sys.argv[i + 1]
        elif a == "--quality" and i + 1 < len(sys.argv):
            quality = sys.argv[i + 1]

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print(json.dumps({"ok": False, "err": f"playwright 未安装: {e}"}))
        return 1

    result = {"ok": False, "bytes": 0, "duration": 0.0,
              "quality": "", "err": ""}
    pw = br = pg = None

    try:
        pw = sync_playwright().start()
        br = pw.chromium.connect_over_cdp(cdp, timeout=60000)
        ctx = br.contexts[0]

        # 必须在一个 tiktok 页面上执行 fetch（带 Cookie/Referer）
        pg = None
        _own_page = False
        for x in ctx.pages:
            if "tiktok.com" in (x.url or ""):
                pg = x
                break
        if pg is None:
            pg = ctx.new_page()
            _own_page = True
            pg.goto("https://www.tiktok.com/shortdrama",
                    wait_until="domcontentloaded", timeout=50000)
            time.sleep(4)

        # ── ① 找 item_id（必要时翻页）──
        found = collect_episodes(pg, drama_id, ep)
        if found.get("err"):
            result["err"] = found["err"]
            print(json.dumps(result, ensure_ascii=False))
            return 2

        item_id = found["item_id"]
        expect_dur = float(found.get("duration") or 0)

        # ── ② 取 playAddr ──
        info = pg.evaluate(JS_ITEM, [item_id, BASE_QS])
        if info.get("err"):
            result["err"] = (f"取详情失败: {info['err']}。"
                             "如果提示 no itemStruct，多半是 Chrome 没登录 TikTok")
            print(json.dumps(result, ensure_ascii=False))
            return 4

        # 用详情里的 duration（更权威）
        if info.get("duration"):
            expect_dur = float(info["duration"])

        url, qdesc = pick_url(info, quality)
        result["quality"] = qdesc
        if not url:
            result["err"] = "接口没给 playAddr（未登录或该集受限）"
            print(json.dumps(result, ensure_ascii=False))
            return 5

        # ── ③ 分块下载 ──
        head = pg.evaluate(JS_FETCH, [url, 0, 1])
        if head.get("err"):
            result["err"] = f"探测失败: {head['err']}"
            print(json.dumps(result, ensure_ascii=False))
            return 6

        total = int(head.get("total") or info.get("size") or 0)
        if total <= 0:
            result["err"] = "拿不到文件大小"
            print(json.dumps(result, ensure_ascii=False))
            return 7

        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        tmp = out_path + ".part"

        CHUNK = 512 * 1024
        MAX_CHUNKS = 4000
        written = 0
        t0 = time.time()

        with open(tmp, "wb") as f:
            for i in range(MAX_CHUNKS):
                start = i * CHUNK
                if start >= total:
                    break

                r = None
                for attempt in range(3):
                    r = pg.evaluate(JS_FETCH, [url, start, CHUNK])
                    if r and not r.get("err") and (r.get("len") or 0) > 0:
                        break
                    time.sleep(1.2)

                if not r or r.get("err") or (r.get("len") or 0) <= 0:
                    break

                raw = base64.b64decode(r["b64"])
                if not raw:
                    break
                f.write(raw)
                written += len(raw)
                if len(raw) < CHUNK:
                    break

        # ── ④ 校验 ──
        pct = written * 100.0 / total
        if written < total * 0.98:
            try:
                os.unlink(tmp)
            except Exception:
                pass
            result["err"] = (f"下载不完整 {written}/{total} ({pct:.0f}%)")
            result["bytes"] = written
            print(json.dumps(result, ensure_ascii=False))
            return 8

        # 头部校验
        with open(tmp, "rb") as f:
            head12 = f.read(12)
        if head12[4:8] != b"ftyp":
            try:
                os.unlink(tmp)
            except Exception:
                pass
            result["err"] = f"不是有效 MP4（头 {head12[:8]!r}）"
            print(json.dumps(result, ensure_ascii=False))
            return 9

        actual_dur = ffprobe_duration(tmp)
        result["duration"] = round(actual_dur, 2)

        # 时长校验：接口说有 duration 就必须对上（误差 12%）
        if expect_dur > 0 and actual_dur > 0:
            diff = abs(actual_dur - expect_dur) / expect_dur
            if diff > 0.12:
                try:
                    os.unlink(tmp)
                except Exception:
                    pass
                result["err"] = (f"时长不符：实际 {actual_dur:.1f}s "
                                 f"应约 {expect_dur:.0f}s（差 {diff*100:.0f}%）")
                result["bytes"] = written
                print(json.dumps(result, ensure_ascii=False))
                return 10

        os.replace(tmp, out_path)
        result["ok"] = True
        result["bytes"] = written
        result["err"] = ""
        result["elapsed"] = round(time.time() - t0, 1)
        print(json.dumps(result, ensure_ascii=False))
        return 0

    except Exception as e:
        result["err"] = repr(e)[:200]
        print(json.dumps(result, ensure_ascii=False))
        return 11
    finally:
        # ⚠ 只关自己开的 page，绝不能 br.close()
        #   connect_over_cdp 得到的 browser 是「接管」关系，
        #   调 br.close() 会把用户整个 Chrome 关掉，
        #   导致下一集下载时 9222 端口已死。
        try:
            if pg is not None and _own_page:
                pg.close()
        except Exception:
            pass
        try:
            if pw is not None:
                pw.stop()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
