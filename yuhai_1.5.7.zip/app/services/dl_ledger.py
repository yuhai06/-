# -*- coding: utf-8 -*-
"""dl_ledger.py — 下载台账

解决的问题
----------
之前只检查「文件是否存在」来判断要不要下载：
    发布后删除成片 → 源素材也没了 → 下次又完整下载一遍

现在改成持久化台账：
    ① 每次下载成功，把 (tkId, ep, 大小, 时长, 路径) 记进 DB
    ② 台账记录不随文件删除而消失
    ③ 下次下载前先查台账：
       - 有记录且文件还在 → 跳过
       - 有记录但文件被删 → 标记为「已下载过-已清理」，
         默认仍然跳过（避免重复下载）；
         需要重下时显式传 force=True
    ④ 支持查「哪些剧下过了」「总共下了多少集」

表结构
------
dl_ledger(
    tk_id      TEXT,   -- 剧集 id
    ep         INTEGER,-- 集号
    size       INTEGER,-- 字节数
    duration   REAL,   -- 秒
    path       TEXT,   -- 最后一次已知路径
    state      TEXT,   -- done / deleted / failed
    dramaname  TEXT,   -- 剧名
    created_at TEXT,
    updated_at TEXT,
    PRIMARY KEY (tk_id, ep)
)
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.dl.ledger")


def _ensure_table() -> None:
    try:
        db.exec("""CREATE TABLE IF NOT EXISTS dl_ledger (
            tk_id TEXT NOT NULL,
            ep INTEGER NOT NULL,
            size INTEGER DEFAULT 0,
            duration REAL DEFAULT 0,
            path TEXT DEFAULT '',
            state TEXT DEFAULT 'done',
            dramaname TEXT DEFAULT '',
            created_at TEXT,
            updated_at TEXT,
            PRIMARY KEY (tk_id, ep)
        )""")
    except Exception as e:
        log.debug("ensure ledger table: %s", e)


def mark_done(tk_id: str, ep: int, size: int = 0, duration: float = 0,
              path: str = "", dramaname: str = "") -> None:
    """记录一集下载成功。"""
    _ensure_table()
    try:
        db.exec(
            "INSERT INTO dl_ledger(tk_id,ep,size,duration,path,state,"
            "dramaname,created_at,updated_at) "
            "VALUES(?,?,?,?,?,'done',?,?,?) "
            "ON CONFLICT(tk_id,ep) DO UPDATE SET "
            "size=excluded.size, duration=excluded.duration, "
            "path=excluded.path, state='done', "
            "dramaname=excluded.dramaname, updated_at=excluded.updated_at",
            (tk_id, int(ep), int(size or 0), float(duration or 0),
             str(path or ""), dramaname or "", now_iso(), now_iso()))
    except Exception as e:
        log.debug("mark_done failed: %s", e)


def mark_deleted(tk_id: str, ep: int) -> None:
    """标记某集已被清理（文件不见了）。"""
    _ensure_table()
    try:
        db.exec("UPDATE dl_ledger SET state='deleted', updated_at=? "
                "WHERE tk_id=? AND ep=?", (now_iso(), tk_id, int(ep)))
    except Exception as e:
        log.debug("mark_deleted failed: %s", e)


def get_done(tk_id: str) -> dict[int, dict]:
    """拿某部剧所有已下载过的集（含已被删的）。"""
    _ensure_table()
    try:
        rows = db.q(
            "SELECT ep,size,duration,path,state,updated_at "
            "FROM dl_ledger WHERE tk_id=? ORDER BY ep", (tk_id,))
        return {
            int(r["ep"]): {
                "size": r["size"], "duration": r["duration"],
                "path": r["path"], "state": r["state"],
                "updatedAt": r["updated_at"],
            }
            for r in rows
        }
    except Exception as e:
        log.debug("get_done failed: %s", e)
        return {}


def should_skip(tk_id: str, ep: int, check_file: bool = True) -> tuple[bool, str]:
    """判断这一集要不要跳过下载。

    返回 (skip, reason)
      skip=True  → 不用下
      reason     → 说明为什么跳过（或为什么该下）
    """
    _ensure_table()
    rec = get_done(tk_id).get(int(ep))
    if not rec:
        return False, "从未下载过"

    # 台账里有记录
    if rec["state"] == "done":
        if check_file:
            p = Path(rec["path"] or "")
            if p and p.exists() and p.stat().st_size > 10240:
                return True, "已下载且文件存在"
            # 文件没了 → 更新状态
            mark_deleted(tk_id, ep)
            return True, "已下载过（文件已清理，跳过避免重复下载）"
        return True, "已下载过"

    if rec["state"] == "deleted":
        return True, "已下载过（文件已清理，跳过避免重复下载）"

    if rec["state"] == "failed":
        return False, "上次失败，重新下载"

    return False, "状态未知，重新下载"


def plan_eps(tk_id: str, want_eps: list[int],
             force: bool = False,
             check_file: bool = True) -> dict:
    """为一批集数做下载计划。

    返回：
      {
        "toDownload": [1,2,3],     要下的
        "skipped":    [4,5],       跳过的
        "details":    {1: "原因", ...}
      }
    """
    _ensure_table()
    to_dl = []
    skipped = []
    details = {}

    for ep in want_eps:
        if force:
            to_dl.append(ep)
            details[ep] = "强制重下"
            continue
        skip, reason = should_skip(tk_id, ep, check_file=check_file)
        details[ep] = reason
        if skip:
            skipped.append(ep)
        else:
            to_dl.append(ep)

    return {"toDownload": to_dl, "skipped": skipped, "details": details}


def stats() -> dict:
    """台账统计。"""
    _ensure_table()
    try:
        total = db.q1("SELECT COUNT(*) AS n FROM dl_ledger") or {}
        done = db.q1("SELECT COUNT(*) AS n FROM dl_ledger "
                     "WHERE state='done'") or {}
        deleted = db.q1("SELECT COUNT(*) AS n FROM dl_ledger "
                        "WHERE state='deleted'") or {}
        dramas = db.q1("SELECT COUNT(DISTINCT tk_id) AS n FROM dl_ledger") or {}
        size = db.q1("SELECT COALESCE(SUM(size),0) AS n FROM dl_ledger "
                     "WHERE state='done'") or {}
        return {
            "total": total.get("n") or 0,
            "done": done.get("n") or 0,
            "deleted": deleted.get("n") or 0,
            "dramas": dramas.get("n") or 0,
            "totalMb": round((size.get("n") or 0) / 1048576, 1),
        }
    except Exception as e:
        log.debug("stats failed: %s", e)
        return {"total": 0, "done": 0, "deleted": 0, "dramas": 0,
                "totalMb": 0}


def list_dramas() -> list[dict]:
    """列出所有下过的剧。"""
    _ensure_table()
    try:
        rows = db.q(
            "SELECT tk_id, dramaname, "
            "  COUNT(*) AS eps, "
            "  SUM(CASE WHEN state='done' THEN 1 ELSE 0 END) AS alive, "
            "  SUM(size) AS bytes, MAX(updated_at) AS last "
            "FROM dl_ledger GROUP BY tk_id ORDER BY last DESC")
        return [{
            "tkId": r["tk_id"],
            "name": r["dramaname"] or "",
            "episodes": r["eps"],
            "alive": r["alive"],
            "sizeMb": round((r["bytes"] or 0) / 1048576, 1),
            "lastAt": r["last"],
        } for r in rows]
    except Exception as e:
        log.debug("list_dramas failed: %s", e)
        return []


def sync_from_disk(tk_id: str, dirs: list[str] = None) -> dict:
    """扫描磁盘，把存在的集补进台账（首次启用时用）。"""
    _ensure_table()
    import re
    found = 0
    for d in (dirs or []):
        base = Path(d)
        if not base.exists():
            continue
        for f in base.rglob("*.mp4"):
            if tk_id not in f.name:
                continue
            m = re.search(r'[_-](?:ep|EP)?0*(\d+)\.mp4$', f.name, re.I)
            if not m:
                continue
            ep = int(m.group(1))
            mark_done(tk_id, ep, size=f.stat().st_size,
                      path=str(f))
            found += 1
    return {"tkId": tk_id, "synced": found}
