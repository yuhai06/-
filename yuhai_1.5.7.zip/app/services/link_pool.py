# -*- coding: utf-8 -*-
"""link_pool.py — 链接池持久化

用户诉求
--------
「链接只是现在只有一个，如果增加我会在发布的链接池里增加，
 但是会不会我添加了但是退出或者更新不见了？」

答案：会。原实现把 link_pool 当作一次性字符串传参，
     进程结束就没了，更新也不带。

现在改成数据库持久化：
  - 存到 link_pool 表（label / url / weight / page_id / enabled）
  - 发布时按权重随机抽，自动排除最近用过的
  - 退出、更新都还在（DB 在 data/ 下，更新包不动它）

表结构
------
link_pool(
  id INTEGER PK,
  url TEXT UNIQUE,
  label TEXT,
  weight INTEGER DEFAULT 1,
  page_id TEXT DEFAULT '',   空 = 所有主页通用
  enabled INTEGER DEFAULT 1,
  used_count INTEGER DEFAULT 0,
  last_used_at TEXT,
  created_at TEXT
)
"""
from __future__ import annotations

import logging
import time

from app.db import db, now_iso

log = logging.getLogger("yuhai.link.pool")


def _ensure() -> None:
    try:
        db.exec("""CREATE TABLE IF NOT EXISTS link_pool (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL UNIQUE,
            label TEXT DEFAULT '',
            weight INTEGER DEFAULT 1,
            page_id TEXT DEFAULT '',
            enabled INTEGER DEFAULT 1,
            used_count INTEGER DEFAULT 0,
            last_used_at TEXT DEFAULT '',
            created_at TEXT
        )""")
    except Exception as e:
        log.debug("ensure link_pool: %s", e)


def add(url: str, label: str = "", weight: int = 1,
        page_id: str = "") -> dict:
    """加一个链接（已存在则更新）。"""
    _ensure()
    u = (url or "").strip()
    if not u:
        return {"ok": False, "error": "url 不能为空"}
    try:
        db.exec(
            "INSERT INTO link_pool(url,label,weight,page_id,enabled,"
            "used_count,last_used_at,created_at) "
            "VALUES(?,?,?,?,1,0,'',?) "
            "ON CONFLICT(url) DO UPDATE SET "
            "label=excluded.label, weight=excluded.weight, "
            "page_id=excluded.page_id, enabled=1",
            (u, label or "", int(weight or 1), page_id or "", now_iso()))
        return {"ok": True, "url": u}
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}


def remove(url: str = "", link_id: int = 0) -> dict:
    _ensure()
    try:
        if link_id:
            db.exec("DELETE FROM link_pool WHERE id=?", (int(link_id),))
        elif url:
            db.exec("DELETE FROM link_pool WHERE url=?", (url.strip(),))
        else:
            return {"ok": False, "error": "需要 url 或 id"}
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}


def list_all(enabled_only: bool = False) -> list[dict]:
    _ensure()
    try:
        sql = "SELECT * FROM link_pool"
        if enabled_only:
            sql += " WHERE enabled=1"
        sql += " ORDER BY used_count ASC, id ASC"
        rows = db.q(sql)
        return [dict(r) for r in rows]
    except Exception as e:
        log.debug("list link_pool: %s", e)
        return []


def pick(page_id: str = "", n: int = 1) -> list[str]:
    """按权重随机抽 n 个链接（排除最近用过的）。

    返回 url 列表，不够 n 个就循环补。
    """
    _ensure()
    pool = [x for x in list_all(enabled_only=True)
            if not x.get("page_id") or str(x.get("page_id")) == str(page_id)]
    if not pool:
        # 池空 → 回落到固定链接
        try:
            from app.services import reel_caption as rc
            return [rc.FIXED_LINK] * max(1, n)
        except Exception:
            return []

    # 权重展开
    weighted = []
    for x in pool:
        w = max(1, int(x.get("weight") or 1))
        weighted.extend([x] * w)

    import random as _r
    out = []
    for _ in range(max(1, n)):
        # 优先用 used_count 最小的
        cand = sorted(weighted, key=lambda x: (x.get("used_count") or 0))
        top = [c for c in cand
               if (c.get("used_count") or 0) == (cand[0].get("used_count") or 0)]
        out.append(_r.choice(top)["url"])
    return out


def mark_used(url: str) -> None:
    _ensure()
    try:
        db.exec("UPDATE link_pool SET "
                "used_count=COALESCE(used_count,0)+1, last_used_at=? "
                "WHERE url=?", (now_iso(), url))
    except Exception:
        pass


def as_text(page_id: str = "", n: int = 1) -> str:
    """生成 link_pool 字符串（每行一个），给 worker 用。"""
    return "\n".join(pick(page_id=page_id, n=n))


def stats() -> dict:
    _ensure()
    try:
        total = db.q1("SELECT COUNT(*) AS n FROM link_pool") or {}
        on = db.q1("SELECT COUNT(*) AS n FROM link_pool "
                   "WHERE enabled=1") or {}
        return {"total": total.get("n") or 0, "enabled": on.get("n") or 0}
    except Exception:
        return {"total": 0, "enabled": 0}


def seed_defaults() -> dict:
    """首次运行时把用户给的固定链接写进池（幂等）。"""
    _ensure()
    try:
        from app.services import reel_caption as rc
        n = stats().get("total") or 0
        if n == 0:
            add(rc.FIXED_LINK, label="PineDrama 默认", weight=1)
            log.info("链接池已初始化，写入默认链接")
            return {"ok": True, "seeded": 1}
        return {"ok": True, "seeded": 0}
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}
