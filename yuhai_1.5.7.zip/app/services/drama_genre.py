# -*- coding: utf-8 -*-
"""drama_genre.py — 短剧类型精准识别

为什么需要这个：
    剧库表的「内容主题」列只有题材标签（City/Revenge/Werewolf...），
    没有「性取向」维度，判断不了百合。
    剧集介绍（第14列）里才有真实的主角关系和情感线。

做法：
    ① 用剧名 + 介绍文本，让模型判断
    ② 输出固定枚举：GL(女女) / BG(男女) / BL(男男) / unclear
    ③ 同时输出题材标签（复仇/甜宠/狼人/豪门...），便于后续按题材排号
    ④ 结果缓存到 DB，同一部剧只判一次

成本：
    一次判断约 800-1500 token。340 部 ≈ 50 万 token，可接受。
"""
from __future__ import annotations

import json
import logging
import re
import time

from app.db import db, now_iso

log = logging.getLogger("yuhai.drama.genre")

# 关系类型枚举
REL_GL = "GL"          # 女女
REL_BG = "BG"          # 男女
REL_BL = "BL"          # 男男
REL_NONE = "none"      # 无感情线
REL_UNCLEAR = "unclear"

SYSTEM = """你是短剧内容分析专家。你的任务是精准判断一部短剧的「情感主线类型」。

判断标准（严格按此执行）：
1. GL（女女/百合）：两个女性之间的恋爱关系是剧情主线。
2. BG（男女）：一男一女的恋爱关系是主线。
   - ⚠ 女主复仇、宅斗、真假千金、雌竞、女主逆袭 → 都是 BG，不是 GL
   - ⚠ 男主戏份少、男性角色少、女性角色多 → 不等于 GL
   - ⚠ 只要有一条明确的男女感情线，就是 BG
3. BL（男男）：两个男性之间的恋爱关系是主线。
4. none：完全没有感情线（纯复仇/纯悬疑/纯亲情）。
5. unclear：信息不足，无法判断。

另外提取题材标签（可多选，从这些里选）：
复仇 逆袭 甜宠 虐恋 狼人 吸血鬼 豪门 契约婚姻 先婚后爱 带娃 重生
穿越 玄幻 总裁 黑道 校园 年龄差 三角恋 破镜重圆 暗恋 假戏真做
真假千金 婆媳 家族斗争 娱乐圈 医生 律师 军婚 战神 神医

只输出 JSON，不要任何解释和 markdown：
{"rel":"GL|BG|BL|none|unclear","confidence":0.0-1.0,
 "genres":["复仇","狼人"],
 "lead":"一句话说明主角是谁跟谁",
 "reason":"20字内判断依据"}"""


def _ensure_table() -> None:
    """建缓存表（幂等）。"""
    try:
        db.exec("""CREATE TABLE IF NOT EXISTS drama_genre (
            tk_id TEXT PRIMARY KEY,
            name TEXT,
            rel TEXT,
            confidence REAL,
            genres TEXT,
            lead TEXT,
            reason TEXT,
            model TEXT,
            checked_at TEXT
        )""")
    except Exception as e:
        log.debug("ensure table: %s", e)


def _parse_json(txt: str) -> dict:
    """从模型回复里抠出 JSON。"""
    if not txt:
        return {}
    m = re.search(r"\{[\s\S]*\}", txt)
    if not m:
        return {}
    try:
        return json.loads(m.group(0))
    except Exception:
        # 尝试修掉尾逗号
        s = re.sub(r",\s*([}\]])", r"\1", m.group(0))
        try:
            return json.loads(s)
        except Exception:
            return {}


def _fetch_tk_meta(tk_id: str) -> dict:
    """从 TK 拉真实剧名/简介/genres（比剧库表的英文简介详细得多）。"""
    if not tk_id:
        return {}
    try:
        from app.services import dl
        m = dl.sd_drama(tk_id)
        return {
            "name": (m.get("name") or "").strip(),
            "desc": (m.get("desc") or "").strip(),
            "genres": m.get("genres") or [],
            "total": m.get("total"),
        }
    except Exception as e:
        log.debug("fetch tk meta %s: %s", tk_id, e)
        return {}


def classify_one(name: str, desc: str = "", theme: str = "",
                 tk_id: str = "", use_cache: bool = True,
                 fetch_meta: bool = True) -> dict:
    """判断单部剧。返回 {rel, confidence, genres, lead, reason}。

    fetch_meta=True 时会先从 TK 拉真实简介（更准），
    拉不到才退回传入的 desc。
    """
    _ensure_table()

    # 缓存
    if use_cache and tk_id:
        row = db.q1("SELECT * FROM drama_genre WHERE tk_id=?", (tk_id,))
        if row:
            return {
                "tkId": tk_id, "name": row["name"],
                "rel": row["rel"], "confidence": row["confidence"],
                "genres": json.loads(row["genres"] or "[]"),
                "lead": row["lead"], "reason": row["reason"],
                "cached": True,
            }

    # 从 TK 补充真实简介（关键：剧库表只有 26% 有介绍）
    tk_genres = []
    if fetch_meta and tk_id:
        meta = _fetch_tk_meta(tk_id)
        if meta:
            if not name and meta.get("name"):
                name = meta["name"]
            tk_desc = meta.get("desc") or ""
            # TK 简介更详细时优先用
            if len(tk_desc) > len(desc or ""):
                desc = tk_desc
            tk_genres = meta.get("genres") or []
            if not theme and tk_genres:
                theme = ",".join(str(g) for g in tk_genres)

            # ⭐ 官方标签优先：Sismance = TikTok 官方的"姐妹情/百合"分类
            #   这是最权威的判据，比模型读简介更准（实测模型会把
            #   「Love at first hiss」判成 unclear，但官方标签就是 Sismance）
            g_low = [str(g).lower() for g in tk_genres]
            official_gl = any("sismance" in g for g in g_low)

            if official_gl:
                out = {
                    "tkId": tk_id,
                    "name": name[:120],
                    "rel": REL_GL,
                    "confidence": 0.98,
                    "genres": [str(g)[:20] for g in tk_genres[:8]],
                    "lead": "",
                    "reason": "TikTok 官方标签含 Sismance（百合分类）",
                    "source": "official_tag",
                }
                # 写缓存
                try:
                    db.exec(
                        "INSERT INTO drama_genre(tk_id,name,rel,confidence,"
                        "genres,lead,reason,model,checked_at) "
                        "VALUES(?,?,?,?,?,?,?,?,?) "
                        "ON CONFLICT(tk_id) DO UPDATE SET rel=excluded.rel, "
                        "confidence=excluded.confidence, "
                        "genres=excluded.genres, lead=excluded.lead, "
                        "reason=excluded.reason, model=excluded.model, "
                        "checked_at=excluded.checked_at",
                        (tk_id, out["name"], REL_GL, 0.98,
                         json.dumps(out["genres"], ensure_ascii=False),
                         "", out["reason"], "official_tag", now_iso()))
                except Exception:
                    pass
                return out

            # 官方标签里有 Romance 但没 Sismance → 大概率是 BG
            # （不强制覆盖，留给模型判断细节）

    if not name:
        return {"tkId": tk_id, "rel": REL_UNCLEAR, "confidence": 0,
                "genres": [], "lead": "", "reason": "无剧名"}

    user = "剧名：%s\n" % name[:150]
    if theme:
        user += "官方题材标签：%s\n" % theme[:200]
    if desc:
        user += "剧情简介：%s\n" % desc[:1200]
    else:
        user += "（无剧情简介，只能靠剧名和标签推断，不确定就回答 unclear）\n"
    user += "\n请判断这部剧的情感主线类型。"

    try:
        from app.services import agent_chat as ac
        pk = ac.pick_model()
        if not pk.get("ok"):
            return {"tkId": tk_id, "rel": REL_UNCLEAR, "confidence": 0,
                    "genres": [], "lead": "", "reason": "无可用模型"}

        r = ac._post_chat(
            pk["endpoint"], pk["model"],
            [{"role": "system", "content": SYSTEM},
             {"role": "user", "content": user}],
            None, pk.get("apiKey", ""))
        if not r.get("ok"):
            return {"tkId": tk_id, "rel": REL_UNCLEAR, "confidence": 0,
                    "genres": [], "lead": "", "reason": "模型失败: " + str(r.get("error"))[:80]}

        rep = ac._parse_reply(r["data"], "11434" in pk["endpoint"])
        j = _parse_json(rep.get("content") or "")

        rel = (j.get("rel") or REL_UNCLEAR).strip()
        if rel not in (REL_GL, REL_BG, REL_BL, REL_NONE, REL_UNCLEAR):
            rel = REL_UNCLEAR
        genres = j.get("genres") or []
        if not isinstance(genres, list):
            genres = [str(genres)]

        out = {
            "tkId": tk_id, "name": name[:120],
            "rel": rel,
            "confidence": float(j.get("confidence") or 0),
            "genres": [str(g)[:20] for g in genres[:8]],
            "lead": (j.get("lead") or "")[:120],
            "reason": (j.get("reason") or "")[:120],
        }

        # 写缓存
        try:
            db.exec(
                "INSERT INTO drama_genre(tk_id,name,rel,confidence,genres,"
                "lead,reason,model,checked_at) VALUES(?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(tk_id) DO UPDATE SET rel=excluded.rel, "
                "confidence=excluded.confidence, genres=excluded.genres, "
                "lead=excluded.lead, reason=excluded.reason, "
                "model=excluded.model, checked_at=excluded.checked_at",
                (tk_id, out["name"], rel, out["confidence"],
                 json.dumps(out["genres"], ensure_ascii=False),
                 out["lead"], out["reason"], pk["model"], now_iso()))
        except Exception as e:
            log.debug("cache write: %s", e)

        return out

    except Exception as e:
        log.debug("classify failed: %s", e)
        return {"tkId": tk_id, "rel": REL_UNCLEAR, "confidence": 0,
                "genres": [], "lead": "", "reason": "%s: %s" % (type(e).__name__, str(e)[:80])}


def classify_batch(items: list[dict], sleep_s: float = 0.3,
                   on_progress=None) -> dict:
    """批量判断。items = [{tkId|id, name, desc, theme}]"""
    out = []
    gl = []
    total = len(items)
    for i, it in enumerate(items):
        tk_id = str(it.get("tkId") or it.get("id") or "").strip()
        name = (it.get("name") or "").strip()
        desc = (it.get("desc") or "").strip()
        theme = (it.get("theme") or "").strip()
        r = classify_one(name, desc, theme, tk_id)
        out.append(r)
        if r.get("rel") == REL_GL and r.get("confidence", 0) >= 0.6:
            gl.append(r)
        if on_progress:
            try:
                on_progress(i + 1, total, r)
            except Exception:
                pass
        if i < total - 1 and sleep_s:
            time.sleep(sleep_s)

    from collections import Counter
    c = Counter(x.get("rel") for x in out)
    return {
        "total": total,
        "glCount": len(gl),
        "gl": gl,
        "dist": dict(c),
        "all": out,
    }


def stats() -> dict:
    """已判定的统计。"""
    _ensure_table()
    rows = db.q("SELECT rel, COUNT(*) AS n FROM drama_genre GROUP BY rel")
    total = db.q1("SELECT COUNT(*) AS n FROM drama_genre") or {}
    return {
        "total": total.get("n") or 0,
        "byRel": {r["rel"]: r["n"] for r in rows},
    }
