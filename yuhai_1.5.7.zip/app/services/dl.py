"""短剧下载器服务（多站点聚合）

接入自独立版「海外短剧下载器」，适配工作台的路径/代理约定。

站点：
    pinedrama  PineDrama   —— 官方 getEpisodePlayUrl 接口
    dramabox   DramaBox    —— __NEXT_DATA__ 里 chapterList[].mp4
    moboreels  MoboReels   —— Nuxt 内联 episMedia[].mediaUrl
    goodshort  GoodShort   —— __INITIAL_STATE__ 里 m3u8Path（HLS，走 ffmpeg）
    tiktok     TikTok      —— yt-dlp
    tiktok_drama TK短剧     —— tiktok.com/shortdrama/episode/{id}/1

设计原则：
    · 不碰工作台已有的 grab（PineDrama 素材抓取）流程
    · 输出目录独立：<素材根>/短剧下载/<站点>/<剧名>/
    · 所有网络请求走 paths.proxy()，没有代理就直连
"""
from __future__ import annotations

import concurrent.futures as cf
import html as html_lib
import json
import logging
import os
import re
import subprocess
import threading
import time
import traceback
from pathlib import Path

import requests

from app import paths

log = logging.getLogger("yuhai.services.dl")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")

PINE = "https://pinedrama.com"

# ─────────────── 站点定义 ───────────────
SITES = {
    "pinedrama": {"name": "PineDrama", "color": "#2dd4bf",
                  "detail": "https://pinedrama.com/dramas/{slug}", "kind": "mp4"},
    "dramabox": {"name": "DramaBox", "color": "#f59e0b",
                 "detail": "https://www.dramabox.com/drama/{slug}", "kind": "mp4"},
    "moboreels": {"name": "MoboReels", "color": "#a78bfa",
                  "detail": "https://www.moboreels.com/drama/{slug}", "kind": "mp4"},
    "goodshort": {"name": "GoodShort", "color": "#f472b6",
                  "detail": "https://www.goodshort.com/drama/{slug}", "kind": "hls"},
}

SITE_REFERER = {
    "pinedrama": "https://pinedrama.com/",
    "dramabox": "https://www.dramabox.com/",
    "moboreels": "https://www.moboreels.com/",
    "goodshort": "https://www.goodshort.com/",
    "tiktok": "https://www.tiktok.com/",
    "tiktok_drama": "https://www.tiktok.com/",
}


# ─────────────── 基础设施 ───────────────
def py_exe() -> str:
    """返回能执行 .py 脚本的 Python 解释器路径。

    ⚠ 不能用 sys.executable：打包（frozen）后它指向「雨海工作台.exe」，
      用它跑 py 脚本会启动第二个工作台实例（占新端口 + 弹新窗口）。
    """
    import os as _os
    import shutil as _sh
    import sys as _sys
    from pathlib import Path as _P

    # ① 显式配置
    env = _os.environ.get("YUHAI_PYTHON")
    if env and _P(env).exists():
        return env

    if not getattr(_sys, "frozen", False):
        return _sys.executable

    # ② 打包目录附近
    exe_dir = _P(_sys.executable).resolve().parent
    cands = [
        exe_dir / "python.exe",
        exe_dir / "python" / "python.exe",
        exe_dir / "_internal" / "python.exe",
        exe_dir.parent / "python.exe",
    ]
    for c in cands:
        if c.exists():
            return str(c)

    # ③ 系统 PATH
    for name in ("python.exe", "python3.exe", "py.exe"):
        found = _sh.which(name)
        if found:
            return found

    # ④ 兜底：给出可读错误，避免静默起新实例
    raise RuntimeError(
        "找不到可用的 Python 解释器来执行辅助脚本。"
        "请安装 Python 或设置环境变量 YUHAI_PYTHON 指向 python.exe")


def out_root() -> Path:
    """下载根目录

    优先级：
      ① 用户在「短剧下载」页设置的自定义目录（dl_config.json）
      ② 环境变量 YUHAI_DL_ROOT
      ③ <素材根>/短剧下载
    """
    p = _dl_cfg().get("root") or ""
    if p:
        root = Path(p).expanduser()
        if not root.is_absolute():
            root = Path(p)
    else:
        try:
            base = paths.source_roots()[0]
        except Exception:
            base = Path(paths.workspace()) / "素材"
        root = base / "短剧下载"

    for sub in ("", ".cache", ".cache/meta", ".cache/shortdrama",
                ".cache/tiktok_meta", ".cache/home", ".state"):
        try:
            (root / sub).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


# ─────────────── 下载配置（根目录 / 目录结构） ───────────────
_DL_CFG_CACHE = [None, 0.0]      # [dict, mtime]


def _dl_cfg_path() -> Path:
    """配置文件放在数据目录，不依赖下载根（改根之前也能读到）"""
    try:
        return Path(paths.DATA_DIR) / "dl_config.json"
    except Exception:
        return Path("dl_config.json")


def _dl_cfg() -> dict:
    """读配置（带 2 秒缓存，改了立即生效）"""
    p = _dl_cfg_path()
    try:
        mt = p.stat().st_mtime if p.exists() else 0
    except Exception:
        mt = 0
    if _DL_CFG_CACHE[0] is not None and _DL_CFG_CACHE[1] == mt:
        return _DL_CFG_CACHE[0]

    cfg = {}
    if p.exists():
        try:
            d = json.loads(p.read_text(encoding="utf-8-sig"))
            if isinstance(d, dict):
                cfg = d
        except Exception:
            cfg = {}
    # 环境变量兜底
    if not cfg.get("root"):
        env = os.getenv("YUHAI_DL_ROOT", "").strip()
        if env:
            cfg["root"] = env
    _DL_CFG_CACHE[0] = cfg
    _DL_CFG_CACHE[1] = mt
    return cfg


def dl_cfg_get() -> dict:
    """给前端/接口看：当前生效的配置"""
    c = _dl_cfg()
    return {
        "root": c.get("root") or str(out_root()),
        "layout": c.get("layout") or "drama",   # drama=按剧名, site=按站点
        "effective": str(out_root()),
        "default_root": _default_root(),
    }


def _default_root() -> str:
    try:
        return str(paths.source_roots()[0] / "短剧下载")
    except Exception:
        return str(Path(paths.workspace()) / "素材" / "短剧下载")


def dl_cfg_set(root: str | None = None, layout: str | None = None) -> dict:
    """保存配置，立即生效"""
    p = _dl_cfg_path()
    cfg = dict(_dl_cfg())
    if root is not None:
        r = (root or "").strip()
        if r:
            try:
                Path(r).expanduser().mkdir(parents=True, exist_ok=True)
            except Exception as e:
                raise RuntimeError(f"目录不可用：{r} ({str(e)[:60]})")
            cfg["root"] = str(Path(r).expanduser())
        else:
            cfg.pop("root", None)
    if layout is not None:
        if layout not in ("drama", "site"):
            raise RuntimeError("layout 只能是 drama 或 site")
        cfg["layout"] = layout
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:
        raise RuntimeError(f"保存配置失败：{str(e)[:80]}")
    _DL_CFG_CACHE[0] = None
    _DL_CFG_CACHE[1] = 0.0
    return dl_cfg_get()


def drama_dir(site: str, name_or_slug: str) -> Path:
    """一部剧的落盘目录

    layout=drama（默认）：<根>/<剧名>/           —— 按剧名，跨站点也能一眼找到
    layout=site        ：<根>/<站点>/<剧名>/     —— 按站点分类
    """
    layout = (_dl_cfg().get("layout") or "drama").lower()
    nm = safe(name_or_slug)
    if layout == "site":
        return out_root() / site / nm
    return out_root() / nm


def _proxies():
    px = ""
    try:
        px = paths.proxy() or ""
    except Exception:
        pass
    return {"http": px, "https": px} if px else None


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": UA,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
    })
    s.proxies = _proxies() or {}
    return s


_S = [_session()]


def sess() -> requests.Session:
    return _S[0]


def safe(name: str, maxlen: int = 110) -> str:
    n = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", str(name or ""))
    n = re.sub(r"\s+", " ", n).strip(" .")
    return (n[:maxlen] or "untitled")


def _unesc(s: str) -> str:
    return (s or "").replace("\\u002F", "/").replace("\\/", "/") \
                    .replace("\\u003D", "=").replace("\\u0026", "&") \
                    .replace("\\u0025", "%")


def _jget(url: str, timeout: int = 30, retries: int = 3, headers: dict | None = None):
    last = None
    for i in range(retries):
        try:
            r = sess().get(url, timeout=timeout, headers=headers or {})
            if r.status_code == 200:
                return r
            last = f"HTTP {r.status_code}"
            if r.status_code == 404:
                break
        except Exception as e:
            last = repr(e)[:100]
        time.sleep(0.6 * (i + 1))
    raise RuntimeError(last or "unknown")


def ffmpeg_bin() -> str:
    try:
        ff, _ = paths.ffmpeg()
        if ff:
            return str(ff)
    except Exception:
        pass
    import shutil
    return shutil.which("ffmpeg") or "ffmpeg"


# ─────────────── 下载 ───────────────
def dl_http(url: str, dest: Path, referer: str = "", on_progress=None) -> int:
    tmp = dest.with_suffix(".part")
    dest.parent.mkdir(parents=True, exist_ok=True)

    is_tk = "tiktok" in (url or "") or "ibytedtos" in (url or "")
    hdrs = {
        "User-Agent": UA,
        "Accept": "*/*",
        "Accept-Encoding": "identity",
    }
    if is_tk:
        # TikTok CDN 校验 Referer 和 Range
        hdrs["Referer"] = "https://www.tiktok.com/"
        hdrs["Origin"] = "https://www.tiktok.com"
    else:
        hdrs["Referer"] = referer or (PINE + "/")

    with sess().get(url, timeout=240, stream=True, headers=hdrs) as r:
        if r.status_code in (401, 403, 410):
            tmp.unlink(missing_ok=True)
            raise PermissionError(f"HTTP {r.status_code}（签名可能过期）")
        r.raise_for_status()
        total = int(r.headers.get("content-length") or 0)
        got = 0
        last_cb = 0
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 18):
                if chunk:
                    f.write(chunk)
                    got += len(chunk)
                    if on_progress and (got - last_cb > 512 * 1024 or got == total):
                        last_cb = got
                        try:
                            on_progress(got, total)
                        except Exception:
                            pass

    if got < 2048:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"文件过小 {got}B")

    # 检查是不是 HTML/JSON 错误页伪装成 mp4
    try:
        with open(tmp, "rb") as f:
            head = f.read(16)
        if head[:5] in (b"<!doc", b"<html", b"<?xml") or head[:1] == b"{":
            tmp.unlink(missing_ok=True)
            raise PermissionError("返回的不是视频（签名过期或需登录）")
    except PermissionError:
        raise
    except Exception:
        pass

    tmp.replace(dest)
    return got


def dl_hls(url: str, dest: Path, referer: str = "", on_progress=None) -> int:
    """HLS（m3u8）用 ffmpeg 合并成 mp4"""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".part.mp4")
    cmd = [ffmpeg_bin(), "-y", "-loglevel", "error",
           "-user_agent", UA,
           "-headers", f"Referer: {referer or (PINE + '/')}\r\n",
           "-reconnect", "1", "-reconnect_streamed", "1",
           "-reconnect_delay_max", "5", "-rw_timeout", "20000000",
           "-i", url, "-c", "copy", "-movflags", "+faststart", str(tmp)]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=900,
                       encoding="utf-8", errors="replace",
                       creationflags=(0x08000000 if __import__("os").name == "nt" else 0))
    if p.returncode != 0 or not tmp.exists() or tmp.stat().st_size < 100 * 1024:
        err = (p.stderr or "").strip().splitlines()
        if tmp.exists():
            tmp.unlink(missing_ok=True)
        raise RuntimeError(f"ffmpeg 失败: {err[-1][:80] if err else p.returncode}")
    sz = tmp.stat().st_size
    tmp.replace(dest)
    if on_progress:
        try:
            on_progress(sz, sz)
        except Exception:
            pass
    return sz


def download(url: str, dest: Path, referer: str = "", on_progress=None) -> int:
    if ".m3u8" in url:
        return dl_hls(url, dest, referer, on_progress)
    return dl_http(url, dest, referer, on_progress)


# ─────────────── PineDrama ───────────────
def parse_pinedrama(slug: str, html: str) -> dict:
    anchor = f'\\"series_slug\\":\\"{slug}\\"'
    pos = html.find(anchor)
    if pos < 0:
        raise RuntimeError("详情页无 series_slug")
    near = html[max(0, pos - 3000):pos + 400]

    def last(pat, d=""):
        g = re.findall(pat, near, re.S)
        return g[-1] if g else d

    def un(raw):
        if not raw:
            return ""
        try:
            return json.loads('"' + raw.replace('"', '\\"') + '"')
        except Exception:
            return raw

    meta = {
        "slug": slug, "site": "pinedrama",
        "name": un(last(r'\\"langs_list\\":\[[^\]]*\],\\"name\\":\\"(.*?)\\",\\"photo_list\\"')) or slug,
        "cover": last(r'\\"cover_url\\":\\"([^"\\]+)\\"'),
        "total": 0, "rating": last(r'\\"rating\\":\\"([\d.]+)\\"'),
        "desc": un(last(r'\\"short_desc\\":\\"(.*?)\\",\\"shortlink'))
                or un(last(r'\\"desc\\":\\"(.*?)\\",\\"episode_list')),
        "genres": list(dict.fromkeys(re.findall(r'\\"genre_slug\\":\\"([a-z\-]+)\\"', near))),
        "langs": ["en"], "eps": [],
    }
    ep = last(r'\\"episode_num\\":(\d+),\\"faq\\"', "0")
    meta["total"] = int(ep) if str(ep).isdigit() else 0
    lg = last(r'\\"langs_list\\":\[([^\]]*)\]')
    meta["langs"] = re.findall(r"([a-z]{2})", lg) or ["en"]
    blocks = list(re.finditer(r'\\"episode_list\\":\[(.*?)\]', html[:pos + 400], re.S))
    if blocks:
        free = sorted({int(x) for x in re.findall(r'\\"episode_id\\":(\d+)', blocks[-1].group(1))})
        meta["eps"] = [{"ep": n, "url": "", "free": True} for n in free]
    return meta


def pine_play_url(slug: str, ep: int, lang: str = "en"):
    u = (f"{PINE}/api/episode/getEpisodePlayUrl"
         f"?series_slug={requests.utils.quote(slug)}&language={lang}&episode_id={ep}")
    try:
        r = sess().get(u, timeout=25)
        if r.status_code != 200:
            return None, f"HTTP {r.status_code}"
        j = r.json()
    except Exception as e:
        return None, f"err {repr(e)[:60]}"
    if j.get("code") == 200 and (j.get("data") or {}).get("url"):
        return j["data"]["url"], "ok"
    return None, (j.get("msg") or f"code={j.get('code')}")


# ─────────────── DramaBox ───────────────
def parse_dramabox(slug: str, html: str) -> dict:
    m = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html, re.S)
    if not m:
        raise RuntimeError("无 __NEXT_DATA__")
    d = json.loads(m.group(1))["props"]["pageProps"]
    bi = d.get("bookInfo") or {}
    cl = d.get("chapterList") or []
    meta = {
        "slug": slug, "site": "dramabox",
        "name": bi.get("bookName") or slug,
        "cover": _unesc(bi.get("cover", "")).split("@")[0],
        "total": bi.get("chapterCount") or len(cl),
        "rating": str(bi.get("score") or ""),
        "desc": (bi.get("introduction") or "")[:400],
        "genres": bi.get("tags") or [],
        "langs": ["en"], "eps": [],
    }
    for c in cl:
        idx = int(c.get("index") or 0) + 1
        url = _unesc(c.get("mp4") or "")
        ok = bool(c.get("unlock")) and bool(url)
        meta["eps"].append({"ep": idx, "url": url if ok else "", "free": ok})
    return meta


# ─────────────── MoboReels ───────────────
def parse_moboreels(slug: str, html: str) -> dict:
    name = slug
    m0 = re.search(r'<title>([^<]+)</title>', html)
    if m0:
        name = html_lib.unescape(re.sub(r"\s*\|.*$", "", m0.group(1))).strip()
        name = re.sub(r"\s*Full Movie\s*[-–]?\s*\d+\s*Episodes\s*[-–]?\s*MoboReels\s*$", "", name).strip()
        name = re.sub(r"\s*[-–]\s*MoboReels\s*$", "", name).strip()
    cover = ""
    og = re.search(r'og:image"\s+content="([^"]+)"', html)
    if og:
        cover = _unesc(og.group(1)).split("?")[0]
    desc = ""
    od = re.search(r'og:description"\s+content="([^"]+)"', html)
    if od:
        desc = html_lib.unescape(od.group(1))[:400]

    cur_urls = [_unesc(x) for x in re.findall(r'mediaUrl:"(https:[^"]+)"', html)]
    cur_urls = [u for u in cur_urls if ".mp4" in u]
    di = html.find("detail:{")
    cur_locked = bool(re.search(r'isLock:!0', html[di:di + 3000])) if di > 0 else True
    cur_num = 1
    if di > 0:
        mm = re.search(r'episNum:(\d+)', html[di:di + 3000])
        if mm:
            cur_num = int(mm.group(1))

    seen = {}
    for m in re.finditer(r'\{episId:"(\d+)",episNum:(\d+),isFree:([a-zA-Z0-9_$!]+),isLock:([a-zA-Z0-9_$!]+)', html):
        e = {"episId": m.group(1), "ep": int(m.group(2)),
             "isLock": m.group(4) in ("!0", "true")}
        seen[e["ep"]] = e
    all_ids = list(dict.fromkeys(re.findall(r'episId:"(\d+)"', html)))
    total = max(len(all_ids), max(seen) if seen else 1)

    eps = []
    for e in [seen[k] for k in sorted(seen)]:
        free = not e["isLock"]
        url = ""
        if free and e["ep"] == cur_num and cur_urls and not cur_locked:
            url = cur_urls[0]
        eps.append({"ep": e["ep"], "url": url, "free": bool(url)})
    have = {e["ep"] for e in eps}
    for i in range(1, total + 1):
        if i not in have:
            eps.append({"ep": i, "url": "", "free": False})
    eps.sort(key=lambda x: x["ep"])
    return {
        "slug": slug, "site": "moboreels", "name": name, "cover": cover,
        "total": total, "rating": "", "desc": desc, "genres": [],
        "langs": ["en"], "eps": eps,
        "note": f"MoboReels 只对第 {cur_num} 集给出播放地址（官方剧集接口本机不可达）",
    }


# ─────────────── GoodShort ───────────────
def parse_goodshort(slug: str, html: str) -> dict:
    txt = _unesc(html)
    name = slug
    mn = re.search(r'"bookName"\s*:\s*"([^"]+)"', txt)
    if mn:
        name = mn.group(1)
    cover = ""
    mc = re.search(r'"cover"\s*:\s*"([^"]+)"', txt)
    if mc:
        cover = mc.group(1)
    total = 0
    mt = re.search(r'"chapterCount"\s*:\s*(\d+)', txt)
    if mt:
        total = int(mt.group(1))
    desc = ""
    md = re.search(r'"introduction"\s*:\s*"([^"]{10,600})"', txt)
    if md:
        desc = md.group(1)[:400]

    urls = []
    for u in re.findall(r'"m3u8Path"\s*:\s*"([^"]+)"', txt):
        u = _unesc(u)
        if u and u not in urls:
            urls.append(u)
    eps = [{"ep": i + 1, "url": u, "free": True} for i, u in enumerate(urls)]
    return {
        "slug": slug, "site": "goodshort", "name": name, "cover": cover,
        "total": total or len(eps), "rating": "", "desc": desc,
        "genres": [], "langs": ["en"], "eps": eps,
    }


PARSERS = {
    "pinedrama": parse_pinedrama,
    "dramabox": parse_dramabox,
    "moboreels": parse_moboreels,
    "goodshort": parse_goodshort,
}


# ─────────────── TikTok ───────────────
def ytdlp_bin() -> str:
    import shutil
    for c in (paths.tools_dir() / "yt-dlp.exe", paths.tools_dir() / "bin" / "yt-dlp.exe"):
        if c.exists():
            return str(c)
    return shutil.which("yt-dlp") or "yt-dlp"


def tk_dir() -> Path:
    return out_root() / "tiktok"


def tk_id_from(s: str) -> str:
    s = (s or "").strip()
    if not s:
        return ""
    m = re.search(r"/video/(\d{15,25})", s)
    if m:
        return m.group(1)
    m = re.fullmatch(r"(\d{15,25})", s)
    if m:
        return m.group(1)
    m = re.search(r"(\d{15,25})", s)
    return m.group(1) if m else ""


def tk_meta(vid: str) -> dict:
    """按作品 ID 取元数据（embed/v2 的 __FRONTITY_CONNECT_STATE__）"""
    vid = str(vid)
    cf_ = out_root() / ".cache" / "tiktok_meta" / f"{safe(vid)}.json"
    if cf_.exists() and time.time() - cf_.stat().st_mtime < 3600 * 6:
        try:
            return json.loads(cf_.read_text(encoding="utf-8"))
        except Exception:
            pass

    url = f"https://www.tiktok.com/embed/v2/{vid}"
    hdrs = {"User-Agent": UA, "Referer": "https://www.tiktok.com/",
            "Accept-Language": "en-US,en;q=0.9"}
    last, html = None, None
    for i in range(4):
        try:
            r = sess().get(url, headers=hdrs, timeout=30)
            if r.status_code == 200:
                html = r.text
                break
            if r.status_code == 429:
                last = "TikTok 限流（429），稍后再试"
                time.sleep(8 * (i + 1))
                continue
            last = f"HTTP {r.status_code}"
        except Exception as e:
            last = repr(e)[:90]
        time.sleep(1.0 * (i + 1))
    if html is None:
        raise RuntimeError(last or "embed 抓取失败")

    m = re.search(r'id="__FRONTITY_CONNECT_STATE__" type="application/json">(.*?)</script>', html, re.S)
    if not m:
        raise RuntimeError("页面无 state 数据")
    st = json.loads(m.group(1))
    data = (st.get("source") or {}).get("data") or {}
    vd = None
    for k, v in data.items():
        if isinstance(v, dict) and "videoData" in v:
            vd = v["videoData"]
            break
    if not vd or not (vd.get("itemInfos") or {}).get("id"):
        raise RuntimeError("作品不可见（可能已删除/私密/地区限制）")

    ii = vd["itemInfos"]
    ai = vd.get("authorInfos") or {}
    ast = vd.get("authorStats") or {}
    vm = (ii.get("video") or {}).get("videoMeta") or {}
    out = {
        "id": ii.get("id"), "site": "tiktok",
        "name": (ii.get("text") or vid)[:80],
        "desc": ii.get("text") or "",
        "cover": (ii.get("covers") or [""])[0],
        "duration": vm.get("duration") or 0,
        "width": vm.get("width") or 0, "height": vm.get("height") or 0,
        "create": ii.get("createTime") or 0,
        "stats": {"play": ii.get("playCount") or 0,
                  "like": ii.get("diggCount") or 0,
                  "comment": ii.get("commentCount") or 0,
                  "share": ii.get("shareCount") or 0},
        "author": {"uniqueId": ai.get("uniqueId") or "",
                   "nick": ai.get("nickName") or "",
                   "verified": bool(ai.get("verified")),
                   "followers": ast.get("followerCount") or 0},
        "video_urls": (ii.get("video") or {}).get("urls") or [],
        "total": 1,
        "eps": [{"ep": 1, "url": "", "free": True, "ytdlp": True}],
        "web_url": f"https://www.tiktok.com/@{ai.get('uniqueId') or 'tiktok'}/video/{ii.get('id')}",
    }
    cf_.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


# ─────────────── 元数据 ───────────────
def meta_path(site: str, slug: str) -> Path:
    return out_root() / ".cache" / "meta" / f"{safe(site)}__{safe(slug)}.json"


def fetch_meta(site: str, slug: str, force: bool = False) -> dict:
    cf_ = meta_path(site, slug)
    if not force and cf_.exists() and time.time() - cf_.stat().st_mtime < 3600 * 6:
        try:
            c = json.loads(cf_.read_text(encoding="utf-8"))
            if c.get("name") and c["name"] != slug:
                return c
        except Exception:
            pass
    if site not in PARSERS:
        raise RuntimeError(f"未知站点: {site}")
    cfg = SITES[site]
    url = cfg["detail"].format(slug=slug)
    hdrs = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9",
            "Referer": SITE_REFERER[site]}
    r = _jget(url, timeout=35, headers=hdrs)
    meta = PARSERS[site](slug, r.text)
    meta["source_url"] = url
    cf_.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return meta


# ─────────────── 站点目录 ───────────────
def home_path(site: str) -> Path:
    return out_root() / ".cache" / "home" / f"{site}.json"


def fetch_home(site: str, force: bool = False) -> dict:
    p = home_path(site)
    if not force and p.exists() and time.time() - p.stat().st_mtime < 3600 * 12:
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    base = {"pinedrama": "https://pinedrama.com/",
            "dramabox": "https://www.dramabox.com/",
            "moboreels": "https://www.moboreels.com/",
            "goodshort": "https://www.goodshort.com/"}.get(site)
    if not base:
        return {"site": site, "slugs": []}
    slugs = []
    try:
        html = _jget(base, timeout=35).text
        if site == "pinedrama":
            slugs = sorted(set(re.findall(r'/dramas/([a-z0-9\-]+)', html)))[:40]
        elif site == "dramabox":
            slugs = list(dict.fromkeys(re.findall(r'/drama/(\d+/[A-Za-z0-9\-%]+)', html)))
        elif site == "moboreels":
            slugs = list(dict.fromkeys(re.findall(r'/drama/([a-z0-9][a-z0-9\-]*-\d{4,})', html)))
        elif site == "goodshort":
            slugs = list(dict.fromkeys(re.findall(r'/drama/([a-z0-9\-]+-\d+)', html)))
    except Exception as e:
        log.warning("fetch_home %s failed: %s", site, e)
    out = {"site": site, "slugs": slugs, "fetched": time.time()}
    p.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return out


def index_path() -> Path:
    return out_root() / ".cache" / "pinedrama_slugs.txt"


def pine_index(refresh: bool = False) -> list[str]:
    p = index_path()
    need = refresh or not p.exists() or time.time() - p.stat().st_mtime > 86400 * 3
    if need:
        try:
            xml = _jget(f"{PINE}/sitemap/movie.xml", timeout=60).text
            slugs = sorted(set(re.findall(r'pinedrama\.com/dramas/([a-z0-9\-]+)', xml)))
            if slugs:
                p.write_text("\n".join(slugs), encoding="utf-8")
        except Exception:
            if not p.exists():
                return []
    try:
        return p.read_text(encoding="utf-8").split()
    except Exception:
        return []


def search(site: str, kw: str, limit: int = 60) -> dict:
    kwl = (kw or "").strip().lower().replace(" ", "-")
    if site == "pinedrama":
        all_s = pine_index()
        hits = [s for s in all_s if kwl in s] if kwl else all_s
        return {"slugs": hits[:limit], "total": len(hits), "site": site}
    h = fetch_home(site)
    all_s = h.get("slugs") or []
    hits = [s for s in all_s if kwl in s.lower()] if kwl else all_s
    return {"slugs": hits[:limit], "total": len(hits), "site": site}


# ─────────────── 本地片库 ───────────────
def scan_local() -> list[dict]:
    """扫本地片库。兼容两种布局：
    layout=drama → <根>/<剧名>/*.mp4
    layout=site  → <根>/<站点>/<剧名>/*.mp4
    """
    root = out_root()
    items = []
    seen_dirs = set()

    def add(site: str, sub: Path):
        key = str(sub.resolve()).lower()
        if key in seen_dirs:
            return
        mp4s = sorted(sub.glob("*.mp4"))
        if not mp4s:
            return
        seen_dirs.add(key)
        slug = ""
        mf = sub / "_meta.json"
        if mf.exists():
            try:
                slug = json.loads(mf.read_text(encoding="utf-8")).get("slug") or ""
            except Exception:
                pass
        # 没有 _meta.json 时，从文件名/剧名推断站点；
        # 逗号前用文件名特征，逗号后兜底
        if not site:
            nm = sub.name
            if re.search(r"[\u4e00-\u9fff]", nm):
                site = "tiktok_drama"      # 中文剧名基本是 TK短剧
            elif re.search(r"^\d+/", slug or ""):
                site = "dramabox"          # DramaBox slug 形如 42000028173/Title
            else:
                site = "pinedrama"
        eps = []
        for m in mp4s:
            hit = re.findall(r"-(\d+)\.mp4$", m.name)
            if hit:
                eps.append(int(hit[-1]))
        items.append({
            "site": site,
            "site_name": SITES.get(site, {}).get("name")
                         or ("TikTok短剧" if site == "tiktok_drama" else
                             ("TikTok" if site == "tiktok" else site)),
            "dir": sub.name, "slug": slug,
            "folder": str(sub),
            "count": len(mp4s),
            "bytes": sum(x.stat().st_size for x in mp4s),
            "eps": sorted(eps),
        })

    site_keys = list(SITES.keys()) + ["tiktok", "tiktok_drama"]

    # ① 站点子目录布局
    for site in site_keys:
        d = root / site
        if d.is_dir():
            for sub in d.iterdir():
                if sub.is_dir():
                    add(site, sub)

    # ② 剧名直挂布局（跳过站点目录本身和隐藏目录）
    if root.is_dir():
        for sub in root.iterdir():
            if not sub.is_dir():
                continue
            if sub.name.startswith(".") or sub.name in site_keys:
                continue
            add("", sub)

    items.sort(key=lambda x: -x["count"])
    return items


def episode_files(site: str, slug_or_dir: str) -> dict:
    # layout=drama 时剧目录直接挂在根下，需要两处都找
    cands = [out_root() / safe(slug_or_dir), out_root() / site / safe(slug_or_dir)]
    for sub in cands:
        if not sub.is_dir():
            continue
        files = []
        for f in sorted(sub.glob("*.mp4")):
            m = re.findall(r"-(\d+)\.mp4$", f.name)
            files.append({"ep": int(m[-1]) if m else 0, "path": str(f),
                          "bytes": f.stat().st_size})
        if files:
            return {"files": files, "name": sub.name, "folder": str(sub)}

    # 兜底：按 _meta.json 里的 slug 扫
    for root in (out_root(), out_root() / site):
        if not root.is_dir():
            continue
        for sub in root.iterdir():
            if not sub.is_dir():
                continue
            mf = sub / "_meta.json"
            if not mf.exists():
                continue
            try:
                if (json.loads(mf.read_text(encoding="utf-8")).get("slug") or "") != slug_or_dir:
                    continue
            except Exception:
                continue
            files = []
            for f in sorted(sub.glob("*.mp4")):
                m = re.findall(r"-(\d+)\.mp4$", f.name)
                files.append({"ep": int(m[-1]) if m else 0, "path": str(f),
                              "bytes": f.stat().st_size})
            return {"files": files, "name": sub.name, "folder": str(sub)}
    return {"files": []}


# ─────────────── 送去切片 ───────────────
def slice_target_root() -> Path:
    """切片的源素材根（下载内容会被链接/复制到这里供切片识别）"""
    try:
        roots = paths.source_roots()
        if roots:
            return roots[0]
    except Exception:
        pass
    return out_root().parent


# ─────────────── TK 短剧（shortdrama） ───────────────
CDP_URL = os.getenv("TK_CDP", "http://127.0.0.1:9222") if False else "http://127.0.0.1:9222"
SD_CACHE = None


def sd_cache() -> Path:
    p = out_root() / ".cache" / "shortdrama"
    p.mkdir(parents=True, exist_ok=True)
    return p


# ─────────────── 搜索历史（保留查过的剧） ───────────────
def sd_history_path() -> Path:
    p = out_root() / ".cache" / "sd_history.json"
    return p


def sd_history(touch: bool = False, item: dict | None = None) -> list[dict]:
    """读取/写入 TK短剧查询历史（最多 300 条，按最近使用排序）"""
    p = sd_history_path()
    data = []
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                data = []
        except Exception:
            data = []

    if touch and item:
        did = str(item.get("id") or "")
        data = [x for x in data if str(x.get("id")) != did]
        data.insert(0, {
            "id": did,
            "name": item.get("name") or "",
            "total": item.get("total") or 0,
            "watched": item.get("watched") or 0,
            "cover": item.get("cover") or "",
            "author": (item.get("author") or {}).get("uniqueId") or "",
            "genres": item.get("genres") or [],
            "degraded": bool(item.get("degraded")),
            "ts": int(time.time()),
        })
        data = data[:300]
        try:
            p.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                         encoding="utf-8")
        except Exception:
            pass
    return data


def sd_history_clear(ids: list[str] | None = None) -> dict:
    """清空或删除指定条目"""
    if not ids:
        try:
            sd_history_path().unlink(missing_ok=True)
        except Exception:
            pass
        return {"ok": True, "left": 0}
    p = sd_history_path()
    data = sd_history()
    keep = [x for x in data if str(x.get("id")) not in {str(i) for i in ids}]
    try:
        p.write_text(json.dumps(keep, ensure_ascii=False, indent=1),
                     encoding="utf-8")
    except Exception:
        pass
    return {"ok": True, "left": len(keep)}


def sd_batch(ids: list[str], stop_on_fail: bool = False,
             timeout_each: float = 90.0, on_progress=None) -> dict:
    """批量查询（串行 + 节流，避免风控）。

    timeout_each: 单个剧最多等多少秒（默认 90，原来无限制可能卡 4 分钟）
    on_progress:  可选回调 fn(index, total, drama_id, result)，
                  每抓完一个就调一次，agent 可以边抓边汇报
    """
    ids = [str(x).strip() for x in (ids or []) if str(x).strip()]
    total = len(ids)
    out = []
    t_start = time.time()

    for i, did in enumerate(ids):
        # 单个超时保护：用线程 + join，避免卡死整个批次
        result = None
        try:
            box = {}

            def _work():
                try:
                    box["ok"] = sd_drama(did)
                except Exception as e:
                    box["err"] = "%s: %s" % (type(e).__name__, str(e)[:180])

            th = threading.Thread(target=_work, daemon=True)
            th.start()
            th.join(timeout_each)

            if th.is_alive():
                # 超时：放弃这一个，继续下一个（不让整批卡死）
                result = {"id": did, "ok": False,
                          "error": "超时（>%.0fs），已跳过" % timeout_each}
            elif "err" in box:
                result = {"id": did, "ok": False, "error": box["err"]}
            else:
                m = box.get("ok") or {}
                result = {
                    "id": did, "ok": True,
                    "name": m.get("name"), "total": m.get("total"),
                    "watched": m.get("watched"),
                    "eps": len(m.get("eps") or []),
                    "cover": m.get("cover") or "",
                    "degraded": bool(m.get("degraded")),
                }
        except Exception as e:
            result = {"id": did, "ok": False,
                      "error": "%s: %s" % (type(e).__name__, str(e)[:180])}

        out.append(result)

        # 进度回调（agent 用它来实时汇报）
        if on_progress:
            try:
                on_progress(i + 1, total, did, result)
            except Exception:
                pass

        if not result.get("ok") and stop_on_fail:
            break

        # 每个之间节流，降低风控概率
        if i < total - 1:
            try:
                time.sleep(_SD_GAP)
            except Exception:
                pass

    ok = sum(1 for x in out if x.get("ok"))
    return {"items": out, "total": total, "ok": ok,
            "elapsed": round(time.time() - t_start, 1)}


def sd_available() -> bool:
    try:
        from app.services import tk_browser
        return tk_browser.cdp_alive()
    except Exception:
        try:
            r = requests.get(f"{CDP_URL}/json/version", timeout=3)
            return r.status_code == 200
        except Exception:
            return False


def sd_fetch(drama_id: str, wait: int = 16, retries: int = 3) -> dict:
    """调用独立脚本抓 TK 短剧（Playwright sync API 不能跑在 FastAPI 线程里）"""
    import subprocess as sp
    import sys as _sys
    script = Path(__file__).resolve().parent.parent / "tk_fetch.py"
    if not script.exists():
        raise RuntimeError(f"找不到抓取脚本: {script}")
    pr = sp.run([py_exe(), str(script), str(drama_id),
                 "--wait", str(wait), "--retries", str(retries)],
                capture_output=True, text=True, timeout=240,
                encoding="utf-8", errors="replace",
                creationflags=(0x08000000 if __import__("os").name == "nt" else 0))
    raw = (pr.stdout or "").strip()
    if not raw:
        raise RuntimeError(f"抓取无输出（exit={pr.returncode}） {(pr.stderr or '')[:120]}")
    try:
        return json.loads(raw.splitlines()[-1])
    except Exception:
        raise RuntimeError(f"结果解析失败: {raw[:150]}")


# ── 查询节流：TikTok 短剧页连续打开会触发风控，这里做冷却 ──
_SD_LAST = [0.0]          # 上次查询结束时间
_SD_GAP = 8.0             # 两次查询之间至少间隔 8 秒
_SD_FAILS = [0]           # 连续失败次数


def sd_cooldown_left() -> float:
    """还要等多少秒才能查下一次"""
    gap = time.time() - _SD_LAST[0]
    left = _SD_GAP - gap
    return max(0.0, left)


def sd_note_fail() -> None:
    _SD_FAILS[0] += 1


def sd_note_ok() -> None:
    _SD_FAILS[0] = 0


def sd_state() -> dict:
    return {
        "cooldown": round(sd_cooldown_left(), 1),
        "fails": _SD_FAILS[0],
        "gap": _SD_GAP,
    }


def sd_drama(drama_id: str, force: bool = False) -> dict:
    drama_id = str(drama_id).strip()
    cf_ = sd_cache() / f"{safe(drama_id)}.json"
    if not force and cf_.exists() and time.time() - cf_.stat().st_mtime < 7200:
        try:
            c = json.loads(cf_.read_text(encoding="utf-8"))
            if c.get("name"):
                # 命中缓存也记历史（用户可能换了地方查同一部）
                try:
                    sd_history(touch=True, item=c)
                except Exception:
                    pass
                return c
        except Exception:
            pass
    if not sd_available():
        # 自动拉起（默认无头，用户看不到窗口）
        try:
            from app.services import tk_browser
            tk_browser.ensure(headless=True)
        except Exception as e:
            raise RuntimeError(
                f"Chrome 自动启动失败：{str(e)[:120]}\n"
                "可以手动双击「启动Chrome带调试端口.bat」，或在页面点「接管浏览器」。")

    if not sd_available():
        raise RuntimeError(
            "没连上 Chrome 调试端口（9222）。\n"
            "解决办法：双击工作台目录下的「启动Chrome带调试端口.bat」，"
            "等 Chrome 打开 tiktok.com/shortdrama 后再点查询。")

    # 节流：距上次查询太近就等一会儿（TikTok 连续开页面会风控）
    left = sd_cooldown_left()
    if left > 0:
        time.sleep(left)

    try:
        col = sd_fetch(drama_id)
    finally:
        _SD_LAST[0] = time.time()
        try:
            from app.services import tk_browser
            tk_browser.touch()
        except Exception:
            pass

    dom = col.get("dom") or {}

    # 主路：接口拿到了 dramaInfo
    if col.get("detail"):
        try:
            j1 = json.loads(col["detail"])
            di = j1.get("dramaInfo") or {}
        except Exception:
            j1, di = {}, {}
        if di:
            out = _sd_build(di, col, drama_id)
            sd_note_ok()
            cf_.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
            try:
                sd_history(touch=True, item=out)
            except Exception:
                pass
            return out

    # 兜底：接口被风控，但页面渲染出来了 → 用 DOM 数据
    if dom.get("title") or dom.get("epCount"):
        sd_note_ok()
        total = int(dom.get("epCount") or 0)
        out = {
            "id": drama_id,
            "site": "tiktok_drama",
            "name": dom.get("title") or "",
            "total": total,
            "watched": 0,
            "duration": (dom.get("dur") or 0) * max(total, 1),
            "limited_free": False,
            "desc": "",
            "cover": "",
            "genres": [],
            "rating": "",
            "langs": ["zh-Hans"],
            "author": {},
            "eps": [{"ep": i + 1, "url": "", "free": True,
                     "duration": dom.get("dur") or 0}
                    for i in range(total)],
            "degraded": True,
            "note": "接口被 TikTok 风控，以下信息从页面直接读取；"
                    "分集直链需等风控解除后才能下载。",
        }
        cf_.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
        try:
            sd_history(touch=True, item=out)
        except Exception:
            pass
        return out

    # 彻底失败
    sd_note_fail()
    n = _SD_FAILS[0]
    extra = ""
    if n >= 2:
        extra = (f"\n⚠ 已连续失败 {n} 次，很可能是 TikTok 会话被临时风控。"
                 "建议：在 Chrome 里手动打开一次短剧页确认能看，等几分钟再试。")
    body_err = "（页面显示 Something went wrong）" if (dom or {}).get("bodyErr") else ""
    raise RuntimeError(
        f"TikTok 抓不到这部剧{body_err}。\n"
        "常见原因：① 地区限制 ② 内容下架/私密 ③ 会话风控。\n"
        f"可在 Chrome 里手动打开确认：tiktok.com/shortdrama/episode/{drama_id}/1"
        + extra)


def _sd_build(di: dict, col: dict, drama_id: str) -> dict:
    """从 dramaInfo + 拦截到的分集构建结果"""
    out = {
        "id": str(di.get("dramaID") or drama_id),
        "site": "tiktok_drama",
        "name": di.get("dramaName") or "",
        "total": di.get("numVideos") or 0,
        "watched": di.get("numWatched") or 0,
        "duration": di.get("totalDuration") or 0,
        "limited_free": bool(di.get("isLimitedFree")),
        "desc": (di.get("description") or "")[:400],
        "cover": ((di.get("cover") or {}).get("urlList") or [""])[0],
        "genres": [t.get("tagVal") for t in (di.get("themes") or []) if t.get("tagVal")],
        "rating": "",
        "langs": ["zh-Hans"],
        "author": {
            "uniqueId": (((di.get("author") or {}).get("user") or {}).get("uniqueId")),
            "nick": (((di.get("author") or {}).get("user") or {}).get("nickname")),
            "followers": (((di.get("author") or {}).get("stats") or {}).get("followerCount")),
        },
        "eps": [],
    }
    seen = set()
    for raw in (col.get("eps") or []):
        try:
            j2 = json.loads(raw)
        except Exception:
            continue
        for it in (j2.get("itemList") or []):
            iid = str(it.get("id") or "")
            if not iid or iid in seen:
                continue
            seen.add(iid)
            v = it.get("video") or {}
            d = it.get("dramaInfo") or {}
            vd = d.get("DramaVideoData") or {}
            out["eps"].append({
                "ep": vd.get("EpisodeNumber") or (len(out["eps"]) + 1),
                "url": v.get("playAddr") or "",
                "dl": v.get("downloadAddr") or "",
                # TK短剧的 playAddr 永远是空的（付费墙），但下载走的是
                # 「播放触发 → 页面内 fetch」方案，所以只要拿到 item_id 就能下
                "free": True,
                "item_id": iid,
                "duration": v.get("duration") or 0,
                "play": ((it.get("stats") or {}).get("playCount")) or 0,
            })
    out["eps"].sort(key=lambda x: (x["ep"] or 0))

    # 关键：接口只返回第一页（通常 24 条），但下载走的是
    # tiktok.com/shortdrama/episode/{drama_id}/{ep} 这个 URL，
    # 不依赖 item_id。所以按 numVideos 补齐集号，后面的集照样能下。
    total = int(out.get("total") or 0)
    if total > len(out["eps"]):
        have = {e["ep"] for e in out["eps"]}
        for i in range(1, total + 1):
            if i not in have:
                out["eps"].append({
                    "ep": i, "url": "", "dl": "", "free": True,
                    "item_id": "", "duration": 0, "play": 0,
                    "filler": True,          # 标记：后勤补齐的集号
                })
        out["eps"].sort(key=lambda x: (x["ep"] or 0))
    return out


def send_to_slice(site: str, dir_name: str) -> dict:
    """把某部已下载的剧送去切片。

    切片按「源素材根/<剧名>/*.mp4」扫描，所以这里在源素材根下建同名目录，
    再用硬链接（同盘，0 拷贝、0 额外占用）把文件挂过去；跨盘则回退复制。
    """
    import os
    src = None
    for cand in (out_root() / safe(dir_name), out_root() / site / safe(dir_name)):
        if cand.is_dir() and list(cand.glob("*.mp4")):
            src = cand
            break
    if src is None:
        raise RuntimeError(f"目录不存在或没有视频: {dir_name}")
    mp4s = sorted(src.glob("*.mp4"))
    if not mp4s:
        raise RuntimeError("这部剧还没有下载任何集")

    dst_root = slice_target_root()
    dst = dst_root / safe(dir_name)
    dst.mkdir(parents=True, exist_ok=True)

    linked = copied = skipped = 0
    for f in mp4s:
        t = dst / f.name
        if t.exists() and t.stat().st_size == f.stat().st_size:
            skipped += 1
            continue
        try:
            os.link(str(f), str(t))          # 硬链接：同盘秒完成
            linked += 1
        except Exception:
            try:
                import shutil
                shutil.copy2(str(f), str(t))  # 跨盘/不支持硬链接 → 复制
                copied += 1
            except Exception as e:
                log.warning("send_to_slice %s failed: %s", f.name, e)

    # 带上元数据，切片侧能读到剧名/分类
    mf = src / "_meta.json"
    if mf.exists():
        try:
            (dst / "_meta.json").write_text(mf.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception:
            pass

    return {
        "ok": True,
        "target": str(dst),
        "total": len(mp4s),
        "linked": linked, "copied": copied, "skipped": skipped,
    }
