# -*- coding: utf-8 -*-
"""publish_admin.py — 发布内核管理工具

补齐 MCP 缺的三个能力（agent 没有它们就会卡死）：

  pub_state()          查内核状态：currentRun 是否被锁、哪些页面 halted、
                       哪些 assignment 停在 submission_intent（结果不确定）
  pub_unlock()         解除 needs_attention 锁（归档/结束本轮）
  pub_resolve()        标记某条 assignment 的结果（发成功 / 没发出去），
                       用于解决「点了发布但结果不确定」

为什么必须有
------------
ReelsPublisher 内核用 state.json 的 currentRun 记录本轮发布。
如果某条 assignment 停在 submission_intent（已点发布按钮但没拿到结果），
currentRun.state 会变 needs_attention，之后 createRun 直接抛 RUN_ACTIVE，
**所有后续发布全部被拦**。

原来只能人工到工作台 GUI 点「结束本轮/归档」才能解，
MCP 没这个工具，agent 就彻底卡住。
"""
from __future__ import annotations

import json
import logging
import shutil
import time
from pathlib import Path

log = logging.getLogger("yuhai.publish.admin")

# submission_intent = 已点击发布但未确认（结果不确定）
# halted            = 该主页被中止
# needs_attention   = 整个 run 需要人工介入
RISKY_STATES = ("submission_intent", "submitting", "publishing")


def state_path() -> Path:
    """state.json 的位置。"""
    from app.services import reels as rl
    try:
        return Path(rl.data_dir()) / "state.json"
    except Exception:
        pass
    p = Path(r"E:\ReelsPublisher-v19.7-Portable\resources\data\state.json")
    return p


def _load() -> dict:
    p = state_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log.debug("read state: %s", e)
        return {}


def _save(d: dict, backup: bool = True) -> str:
    p = state_path()
    bak = ""
    if backup and p.exists():
        try:
            bak = str(p.with_name(
                "state.json.bak-%s" % time.strftime("%Y%m%d-%H%M%S")))
            shutil.copy2(p, bak)
        except Exception:
            bak = ""
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return bak


def summary() -> dict:
    """查内核当前状态。"""
    d = _load()
    cr = d.get("currentRun") or {}
    state = cr.get("state") or ""
    pages = cr.get("pages") or []
    assigns = cr.get("assignments") or []

    halted = [{"pageId": p.get("pageId"), "name": p.get("name"),
               "state": p.get("state")}
              for p in pages if p.get("state") == "halted"]

    risky = []
    for a in assigns:
        st = str(a.get("state") or "")
        if st in RISKY_STATES or st in ("halted", "failed"):
            risky.append({
                "pageId": a.get("pageId"),
                "file": a.get("file") or a.get("source") or "",
                "state": st,
            })

    locked = state in ("needs_attention", "running", "paused") or bool(risky)

    return {
        "ok": True,
        "statePath": str(state_path()),
        "stateExists": state_path().exists(),
        "runId": cr.get("id"),
        "runState": state,
        "startedAt": cr.get("startedAt"),
        "materialRoot": cr.get("materialRoot"),
        "description": (cr.get("description") or "")[:120],
        "clipsPerPage": cr.get("clipsPerPage"),
        "pageCount": len(pages),
        "assignmentCount": len(assigns),
        "haltedPages": halted,
        "riskyAssignments": risky,
        "locked": locked,
        "needUnlock": state == "needs_attention" or bool(risky),
        "hint": ("内核被锁，需要 pub_unlock 解除"
                 if locked else "内核空闲，可以发布"),
    }


def unlock(resolve_as: str = "unknown", note: str = "") -> dict:
    """解除 needs_attention 锁。

    resolve_as:
      unknown   - 结果不确定（默认，最保守：当作已发，不重发）
      sent      - 确认发出去了
      failed    - 确认没发出去（会允许重发）

    做法：把 currentRun 归档到 history，清空 currentRun，
         并清理 risky assignment。
    """
    d = _load()
    if not d:
        return {"ok": False, "error": "state.json 不存在或读不了"}

    cr = d.get("currentRun")
    if not cr:
        return {"ok": True, "skipped": True, "reason": "没有 currentRun，本来就是空的"}

    before = {
        "runState": cr.get("state"),
        "runId": cr.get("id"),
        "assignments": len(cr.get("assignments") or []),
    }

    # 归档
    hist = d.setdefault("history", [])
    archived = dict(cr)
    archived["_archivedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    archived["_resolvedAs"] = resolve_as
    archived["_note"] = note
    hist.append(archived)
    if len(hist) > 50:
        d["history"] = hist[-50:]

    # 清理 currentRun
    d["currentRun"] = None

    # 把 resolve_as=failed 的 assignment 对应素材从 usedHashes 里摘掉，
    # 这样下次能重发；sent/unknown 保留（避免重复）
    if resolve_as == "failed":
        try:
            used = d.get("usedHashes") or {}
            to_drop = []
            for a in (cr.get("assignments") or []):
                h = a.get("hash") or a.get("sha") or ""
                if h and h in used:
                    to_drop.append(h)
            for h in to_drop:
                used.pop(h, None)
        except Exception:
            pass

    bak = _save(d)
    log.warning("发布内核解锁: %s → %s (resolveAs=%s)", before, "idle", resolve_as)

    return {
        "ok": True,
        "archived": before,
        "resolveAs": resolve_as,
        "backup": bak,
        "state": summary(),
    }


def resolve_assignment(page_id: str = "", file_hint: str = "",
                       result: str = "sent", note: str = "") -> dict:
    """标记某条 assignment 的最终结果，不用整体解锁。

    result: sent（发出去了）/ failed（没发出去）
    """
    d = _load()
    cr = d.get("currentRun") or {}
    assigns = cr.get("assignments") or []
    if not assigns:
        return {"ok": False, "error": "没有 currentRun.assignments"}

    hit = []
    for a in assigns:
        if page_id and str(a.get("pageId")) != str(page_id):
            continue
        f = str(a.get("file") or a.get("source") or "")
        if file_hint and file_hint not in f:
            continue
        hit.append(a)

    if not hit:
        return {"ok": False,
                "error": "没找到匹配的 assignment（pageId=%s file=%s）"
                         % (page_id, file_hint)}

    for a in hit:
        a["state"] = "done" if result == "sent" else "failed"
        a["_resolvedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        a["_resolveNote"] = note

    # 如果所有 assignment 都落定了，顺手解锁
    still_risky = [a for a in assigns
                   if str(a.get("state")) in RISKY_STATES]
    if not still_risky and cr.get("state") == "needs_attention":
        cr["state"] = "completed"

    bak = _save(d)
    return {
        "ok": True,
        "resolved": len(hit),
        "result": result,
        "stillRisky": len(still_risky),
        "backup": bak,
        "state": summary(),
    }


def publish_delay_options() -> dict:
    """说明定时发布的能力边界（Meta 原生排定）。"""
    return {
        "ok": True,
        "mode": "meta_native_scheduling",
        "rule": ("只有同一主页一次提交多条（clipsPerPage>1）时才启用原生定时："
                 "第 1 条立即发，第 2/3/4 条自动 +30/+60/+90 分钟"),
        "clipsPerPage1": "clipsPerPage=1 是全部即时发，不做定时",
        "maxPerBatch": 4,
        "intervals": [0, 30, 60, 90],
        "alternative": ("需要 120 分钟以上的间隔，走工作台「排期与队列」"
                        "（schedule_queue），那条链路独立于本次发布"),
        "titleSource": ("🔍Title 里的剧名由 worker 用【视频所在文件夹名】替换，"
                        "所以素材目录名必须是英文剧名才能得到英文标题"),
    }
