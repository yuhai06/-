"""ReelsPublisher 内核对接——通过 Node worker 的 IPC 批量发布。

为什么用这个：
    自研 CDP 直接发 Reels 不稳（reels_composer 页面会让浏览器内核卡死，
    且上传 input 是动态创建的，直接 querySelector 找不到）。
    ReelsPublisher v19.7 已经有成熟的批量发布链路：
        playwright-core 连接 Hubstudio CDP →
        skill-runtime 的 publisher 完成「打开 composer → 塞视频 →
        填标题 → 点发布 → 提取回执 → 清理素材」
    我们直接复用它的 worker IPC。

通信方式：
    worker.mjs 必须由父进程 fork，且 process.send 存在。
    命令：status / checkBrowsers / start / discoverPages / shutdown
    资源：REELS_PUBLISHER_DATA_DIR（state.json 与历史记录）
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.reels")

# ---------- 路径 ----------
def reels_root() -> Path:
    """ReelsPublisher 安装根目录。"""
    env = os.environ.get("YUHAI_REELS_ROOT", "").strip()
    if env:
        return Path(env)
    # 从 reels_env_dir（.../resources/worker/src）上溯三级
    p = Path(settings.reels_env_dir)
    for _ in range(3):
        p = p.parent
    return p


def worker_entry() -> Path:
    return Path(settings.reels_env_dir) / "worker.mjs"


def data_dir() -> Path:
    """worker 的 state/history 目录。"""
    env = os.environ.get("YUHAI_REELS_DATA", "").strip()
    if env:
        d = Path(env)
    else:
        d = reels_root() / "resources" / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def node_cmd() -> list[str]:
    """拿一个可用的 node 命令前缀。"""
    n = shutil.which("node")
    if n:
        return [n]
    # 用 Electron 二进制当 node
    exe = Path(os.environ.get("YUHAI_ELECTRON_NODE",
                              r"E:\ReelsPublisher-v19.7-Portable\Reels Publisher.exe"))
    if exe.exists():
        return [str(exe)]
    return ["node"]


def available() -> dict:
    """内核可用性检查。"""
    w = worker_entry()
    d = data_dir()
    node = node_cmd()
    st = d / "state.json"
    plan = {}
    disc = {}
    if st.exists():
        try:
            s = json.loads(st.read_text(encoding="utf-8"))
            plan = s.get("plan") or {}
            disc = s.get("discovery") or {}
        except Exception:
            pass
    return {
        "ok": w.exists() and len(node) > 0,
        "worker": str(w),
        "workerExists": w.exists(),
        "dataDir": str(d),
        "node": node[0] if node else "",
        "planPages": len((plan.get("assignments") or [])),
        "discoveredPages": len((disc.get("pages") or [])),
        "hasState": st.exists(),
        "version": "v19.7",
    }


# ---------- 单次调用（不常驻） ----------
# 正在跑的 worker 进程（jobId → Popen），用于「停止」
RUNNING: dict[str, "subprocess.Popen"] = {}


async def call_worker(commands: list[dict], timeout_s: float = 180,
                      on_progress=None, job_id: str = "") -> dict:
    """一次性启动 worker，按顺序执行 commands，返回最后一次结果。

    commands: [{"id":"c1","command":"status","payload":{}}, ...]
    最后会自动 shutdown。

    job_id 非空时会把进程登记到 RUNNING，供 stop_worker 停止。
    """
    w = worker_entry()
    if not w.exists():
        return {"ok": False, "error": f"worker 不存在: {w}"}

    d = data_dir()
    nc = node_cmd()

    # 写一个临时驱动脚本，避免复杂 IPC 编码问题
    drv = d / f"_drv_{uuid.uuid4().hex[:8]}.mjs"
    drv.write_text(_driver_js(str(w), str(d), commands), encoding="utf-8")

    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NO_WINDOW | \
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    proc = subprocess.Popen(nc + [str(drv)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, **kw)
    if job_id:
        RUNNING[job_id] = proc
    out_lines: list[str] = []
    try:
        for raw in proc.stdout:  # type: ignore
            line = raw.decode("utf-8", "replace").rstrip()
            out_lines.append(line)
            if on_progress and line.startswith("[progress]"):
                try:
                    on_progress(line[10:].strip())
                except Exception:
                    pass
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"ok": False, "error": "worker 超时", "log": out_lines[-30:]}
    finally:
        RUNNING.pop(job_id, None)
        try:
            drv.unlink()
        except Exception:
            pass

    # 解析最后一行 JSON
    result = {}
    for line in reversed(out_lines):
        if line.startswith("[result]"):
            try:
                result = json.loads(line[8:].strip())
                break
            except Exception:
                pass
    return {"ok": True, "result": result, "log": out_lines[-40:]}


def _driver_js(worker: str, data: str, commands: list[dict]) -> str:
    """生成驱动脚本（fork worker，顺跑命令，输出 [result] JSON）。"""
    return f"""
import {{ fork }} from 'node:child_process';
const WORKER = {json.dumps(worker)};
const DATA = {json.dumps(data)};
const CMDS = {json.dumps(commands, ensure_ascii=False)};

let seq = 0;
const pending = new Map();
const child = fork(WORKER, [], {{
  env: {{ ...process.env,
    REELS_PUBLISHER_DATA_DIR: DATA,
    REELS_PUBLISHER_OUTPUT_DIR: DATA }},
  stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
}});

function call(command, payload, timeoutMs) {{
  return new Promise((resolve, reject) => {{
    const id = 'r' + (++seq);
    pending.set(id, {{ resolve, reject }});
    child.send({{ id, command, payload: payload || {{}} }});
    setTimeout(() => {{
      if (pending.has(id)) {{ pending.delete(id); reject(new Error('timeout:' + command)); }}
    }}, timeoutMs || 180000);
  }});
}}

child.on('message', (m) => {{
  if (m.type === 'ready') {{ run(); return; }}
  if (m.type === 'progress') {{
    const e = m.event || {{}};
    if (e.stage) console.log('[progress] ' + e.stage);
    return;
  }}
  if (m.id && pending.has(m.id)) {{
    const {{ resolve, reject }} = pending.get(m.id);
    pending.delete(m.id);
    if (m.ok) resolve(m.value);
    else reject(new Error((m.error?.code || 'ERR') + ': ' + (m.error?.message || '')));
  }}
}});
child.stderr?.on('data', (d) => {{
  const s = d.toString().trim();
  if (s) console.log('[err] ' + s.slice(0, 300));
}});

async function run() {{
  let last = null;
  try {{
    for (const c of CMDS) {{
      last = await call(c.command, c.payload, c.timeout || 180000);
    }}
  }} catch (e) {{
    console.log('[result] ' + JSON.stringify({{ ok: false, error: e.message }}));
  }}
  console.log('[result] ' + JSON.stringify({{ ok: true, value: last }}));
  try {{ await call('shutdown', {{}}, 20000); }} catch {{}}
  child.kill();
  setTimeout(() => process.exit(0), 500);
}}
setTimeout(() => {{ console.log('[result] ' + JSON.stringify({{ ok: false, error: 'global timeout' }})); child.kill(); process.exit(1); }}, 3600000);
"""


# ---------- 高层操作 ----------
async def status() -> dict:
    r = await call_worker([{"command": "status", "payload": {}, "timeout": 60000}],
                          timeout_s=90)
    if not r.get("ok"):
        return r
    return {"ok": True, **(r.get("result") or {})}


async def check_browsers() -> dict:
    r = await call_worker(
        [{"command": "checkBrowsers", "payload": {}, "timeout": 120000}],
        timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{browserCheck:{...}}}
    if "value" in v and isinstance(v.get("value"), dict):
        v = v["value"]
    bc = (v.get("browserCheck") or {})
    return {"ok": True, "results": bc.get("results") or [],
            "environments": bc.get("environments") or []}


async def scan_materials(directory: str) -> dict:
    r = await call_worker(
        [{"command": "scanMaterials",
          "payload": {"directory": directory, "directories": [directory]},
          "timeout": 120000}], timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{groups,total,folderCount,sampleTitle}}
    if "value" in v and isinstance(v.get("value"), dict):
        return {"ok": True, **(v["value"])}
    return {"ok": True, **v}


async def publish(directory: str, description: str, link_pool: str,
                  clips_per_page: int = 1, concurrency: int = 1,
                  publish_mode: str = "merge",
                  browser_ids: list[str] | None = None,
                  pages: list[str] | None = None,
                  materials: list[str] | None = None,
                  title_mode: str = "random",
                  reference_title: str = "",
                  use_random_link: bool = True,
                  fixed_title: str = "",
                  timeout_s: float = 3600, on_progress=None,
                  job_id: str = "",
                  interval_minutes: int = 30) -> dict:
    """批量发布。description 是标题模板，link_pool 是链接池（每行一个）。

    pages     : 限定发哪些主页（pageId 列表，空=全部）
    materials : 限定用哪些素材（文件路径列表，空=目录里全部）
    """
    cmds = []
    if browser_ids:
        cmds.append({"command": "checkBrowsers", "payload": {}, "timeout": 120000})

    payload = {
        "directory": directory,
        "directories": [directory],
        "publishMode": publish_mode,
        "clipsPerPage": clips_per_page,
        "concurrency": concurrency,
        "browserIds": browser_ids or [],
        "description": description,
        "linkPool": link_pool,
        "interPageDelaySeconds": {"min": max(0, int(interval_minutes or 30)) * 60,
                                  "max": max(0, int(interval_minutes or 30)) * 60},
    }

    # 多标题随机：为每个目标主页预先抽一条独立文案，交给 worker 按主页替换。
    # worker 端 description 是单一模板，这里用 pageCaptions 覆盖到对应主页。
    if (title_mode or "random").lower() == "random":
        try:
            from app.services import caption as cap
            from app.services import reels as _self  # noqa: F401
            targets = list(pages) if pages else [p.get("pageId") for p in plan_pages()]
            page_captions: dict[str, str] = {}

            # 池子为空或太少时，自动用大模型补一批标题（每主页至少 8 条）。
            if on_progress:
                try:
                    on_progress("检查标题池…")
                except Exception:
                    pass
            auto_note = ""
            # 池子要够大，主页多时每主页才可能抽到不同标题。
            want_total = max(12, len([t for t in targets if t]) * 3)
            for pid in targets:
                if not pid:
                    continue
                try:
                    ensure = await cap.ensure_title_pool(
                        page_id=str(pid),
                        ref=reference_title or "",
                        want=want_total,
                    )
                    if ensure.get("generated"):
                        auto_note = (f"自动生成标题 {ensure['generated']} 条"
                                     f"（{ensure.get('source')}）")
                except Exception as e:
                    print(f"[reels] 自动补标题失败 {pid}: {e}")
            if auto_note and on_progress:
                try:
                    on_progress(auto_note)
                except Exception:
                    pass
            for pid in targets:
                if not pid:
                    continue
                picked = cap.pick_caption(str(pid), reference_title or "")
                title = (picked or {}).get("title") or ""
                title = title or reference_title.strip()
                if not title:
                    continue
                # 轮转：把用掉的标题 used_count +1，下个主页就会挑到别的
                try:
                    if picked.get("titleId"):
                        cap.mark_title_used(picked["titleId"],
                                            "pool" if str(picked.get("source", "")).startswith("pool") else "variant")
                except Exception:
                    pass
                link_url = ""
                if use_random_link:
                    try:
                        lk = cap.pick_link(str(pid))
                        link_url = (lk or {}).get("url") or ""
                        if lk and lk.get("id"):
                            cap.mark_link_used(lk["id"])
                    except Exception:
                        link_url = ""
                else:
                    parts = (link_pool or "").split()
                    link_url = parts[0] if parts else ""
                caption = f"{title}\n\n{link_url}" if link_url else title
                page_captions[str(pid)] = caption
            if page_captions:
                payload["pageCaptions"] = page_captions
        except Exception as e:
            print(f"[reels] 逐主页文案生成失败，退回单一模板: {e}")
    elif fixed_title.strip():
        payload["description"] = fixed_title.strip()
    # 限定主页：worker 支持 skippedPageIds（反向排除）
    if pages:
        from app.services.reels import plan_pages as _pp
        all_ids = [p.get("pageId") for p in _pp()]
        skip = [x for x in all_ids if x and x not in set(pages)]
        if skip:
            payload["skippedPageIds"] = skip
    # 限定素材：worker 支持 selectedFiles
    if materials:
        payload["selectedFiles"] = materials

    cmds.append({"command": "start", "payload": payload,
                 "timeout": int(timeout_s * 1000)})

    r = await call_worker(cmds, timeout_s=timeout_s + 120, on_progress=on_progress,
                          job_id=job_id)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    if "value" in v and isinstance(v.get("value"), dict):
        return {"ok": True, **(v["value"])}
    return {"ok": True, **v}


def stop_worker(job_id: str = "") -> dict:
    """停止发布。

    job_id 指定就只停那个，不指定就停全部。
    先礼后兵：taskkill /T 杀进程树（worker 是 fork 出来的子进程）。
    """
    targets = []
    if job_id:
        p = RUNNING.get(job_id)
        if p:
            targets.append((job_id, p))
    else:
        targets = list(RUNNING.items())

    if not targets:
        # 兜底：扫系统里所有 _drv 驱动的 node 进程
        killed = _kill_stray()
        return {"ok": True, "stopped": killed,
                "note": "没有登记的进程，已清理遗留节点" if killed else "没有正在跑的发布"}

    out = []
    for jid, p in targets:
        try:
            # 杀进程树（Node 的子进程一起）
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
                               capture_output=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                               timeout=15)
            else:
                p.kill()
            out.append(jid)
        except Exception as e:
            log.warning("stop %s failed: %s", jid, e)
    # 再清一遍遗留
    stray = _kill_stray()
    for jid in out:
        RUNNING.pop(jid, None)
    return {"ok": True, "stopped": out, "strayCleaned": stray,
            "note": f"已停止 {len(out)} 个任务"}


def _kill_stray() -> int:
    """清理遗留的 _drv 驱动 node 进程。"""
    if os.name != "nt":
        return 0
    n = 0
    try:
        r = subprocess.run(
            ["wmic", "process", "where", "name='node.exe'", "get",
             "ProcessId,CommandLine", "/format:csv"],
            capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for line in (r.stdout or "").splitlines():
            if "_drv_" in line and "worker" in line.lower() or "_drv_" in line:
                parts = [x for x in line.split(",") if x.strip()]
                pid = parts[-1].strip()
                if pid.isdigit():
                    subprocess.run(["taskkill", "/F", "/T", "/PID", pid],
                                   capture_output=True,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                                   timeout=10)
                    n += 1
    except Exception:
        pass
    return n


def state_snapshot() -> dict:
    """读 state.json 里的计划/发现数据（不启动 worker，快）。"""
    st = data_dir() / "state.json"
    if not st.exists():
        return {}
    try:
        return json.loads(st.read_text(encoding="utf-8"))
    except Exception:
        return {}


def plan_pages() -> list[dict]:
    """当前 plan 里的主页清单。"""
    s = state_snapshot()
    out = []
    for a in (s.get("plan") or {}).get("assignments") or []:
        out.append({
            "pageId": a.get("pageId"),
            "pageName": a.get("pageName"),
            "profileId": a.get("profileId"),
            "environmentId": a.get("environmentId"),
        })
    return out
