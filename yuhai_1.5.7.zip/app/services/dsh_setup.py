# -*- coding: utf-8 -*-
"""dsh_setup.py — 自动配置 DSH headless profile

作用
----
雨海启动/用户点"修复 DSH 接入"时，把模板写进
~/.dsh/profiles/headless/cordis.patch.yml，内容是：
  - 补权限预设
  - 禁用 DSH 自带通用工具（pwsh/bash/fs/jobs/web/workflow/subagent）
  - 挂雨海 MCP（端口按实际监听端口）

为什么必须禁用自带工具
----------------------
不禁用时，DSH 会优先用自己熟悉的 pwsh/read/edit 反复空转
（实测 20+ 次 0ms 调用），完全不去碰雨海的 119 个 MCP 工具。
禁掉之后它只能用 mcp__yuhai__*，行为立刻正常。
"""
from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

log = logging.getLogger("yuhai.dsh.setup")

TEMPLATE_REL = Path("app") / "templates" / "dsh_headless_patch.yml"

# 判定「已配置好」的特征串
MARK_MCP = "mcp-yuhai"
MARK_DISABLE_PWSH = "id: tool-pwsh"


def dsh_home() -> Path:
    return Path(os.path.expanduser("~")) / ".dsh"


def patch_path() -> Path:
    return dsh_home() / "profiles" / "headless" / "cordis.patch.yml"


def template_path() -> Path:
    """模板文件位置（兼容打包后的 frozen 布局）。"""
    import sys
    base = Path(getattr(sys, "_MEIPASS", "")) if getattr(sys, "frozen", False) else None
    if base:
        p = base / TEMPLATE_REL
        if p.exists():
            return p
    # 从本文件回溯到 backend 根
    here = Path(__file__).resolve()
    for parent in [here.parent.parent, here.parent.parent.parent]:
        p = parent / "app" / "templates" / "dsh_headless_patch.yml"
        if p.exists():
            return p
        p = parent / TEMPLATE_REL
        if p.exists():
            return p
    return Path("")


def status() -> dict:
    """查当前 DSH profile 的配置状态。"""
    pp = patch_path()
    home = dsh_home()

    out = {
        "dshHome": str(home),
        "dshInstalled": home.exists(),
        "patchFile": str(pp),
        "patchExists": pp.exists(),
        "hasMcp": False,
        "toolsDisabled": False,
        "mcpUrl": "",
        "needFix": True,
    }

    if not pp.exists():
        return out

    try:
        txt = pp.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return out

    out["hasMcp"] = MARK_MCP in txt
    out["toolsDisabled"] = MARK_DISABLE_PWSH in txt
    for ln in txt.split("\n"):
        if "url:" in ln and "/mcp/" in ln:
            out["mcpUrl"] = ln.split("url:", 1)[-1].strip()
            break

    out["needFix"] = not (out["hasMcp"] and out["toolsDisabled"])
    return out


def install(port: int = 0, force: bool = False) -> dict:
    """写入/修复 DSH headless 配置。

    port  : 雨海实际监听端口（0 = 自动推断）
    force : 强制覆盖（会先备份）
    """
    home = dsh_home()
    if not home.exists():
        return {"ok": False,
                "error": "没检测到 DSH（%s 不存在）。装了 DSH 再试。" % home}

    tpl = template_path()
    if not tpl or not tpl.exists():
        return {"ok": False, "error": "找不到配置模板: %s" % tpl}

    pp = patch_path()
    pp.parent.mkdir(parents=True, exist_ok=True)

    # 推断端口
    if not port:
        try:
            import os as _os
            port = int(_os.environ.get("YUHAI_PORT", "") or 0)
        except Exception:
            port = 0
    if not port:
        # 从 mcp_server 的 settings 拿
        try:
            from app.config import settings
            port = int(settings.port or 0)
        except Exception:
            port = 0
    if not port:
        port = 8710

    # 已有配置：不 force 且已经合规 → 跳过
    cur = status()
    if cur["patchExists"] and not force:
        if cur["hasMcp"] and cur["toolsDisabled"]:
            # 只检查端口是否需要更新
            want = "http://127.0.0.1:%d/mcp/" % port
            if cur["mcpUrl"] == want:
                return {"ok": True, "skipped": True,
                        "reason": "已配置好", **cur}
            # 只改端口
            try:
                txt = pp.read_text(encoding="utf-8", errors="replace")
                lines = []
                for ln in txt.split("\n"):
                    if "url:" in ln and "/mcp/" in ln:
                        indent = ln[:len(ln) - len(ln.lstrip())]
                        ln = indent + "url: " + want
                    lines.append(ln)
                pp.write_text("\n".join(lines), encoding="utf-8", newline="\n")
                log.info("DSH profile 端口更新为 %d", port)
                return {"ok": True, "updated": "port", **status()}
            except Exception as e:
                return {"ok": False, "error": "改端口失败: %s" % e}

    # 备份原文件
    backup = ""
    if pp.exists():
        try:
            backup = str(pp.with_suffix(".yml.bak-%s" % __import__("time").strftime("%Y%m%d-%H%M%S")))
            shutil.copy2(pp, backup)
        except Exception:
            backup = ""

    # 渲染模板
    try:
        body = tpl.read_text(encoding="utf-8")
    except Exception as e:
        return {"ok": False, "error": "读模板失败: %s" % e}

    body = body.replace("{PORT}", str(port))

    try:
        pp.write_text(body, encoding="utf-8", newline="\n")
    except Exception as e:
        return {"ok": False, "error": "写配置失败: %s" % e}

    log.info("DSH headless 配置已写入: %s (port=%d, backup=%s)",
             pp, port, backup or "无")

    return {"ok": True, "written": str(pp), "port": port,
            "backup": backup, **status()}


def verify() -> dict:
    """跑 dsh --dump-config 验证配置是否被接受。"""
    import subprocess
    st = status()
    if not st["patchExists"]:
        return {"ok": False, "error": "配置文件不存在"}

    bin_ = ""
    for n in ("dsh.cmd", "dsh.exe", "dsh"):
        c = shutil.which(n)
        if c:
            bin_ = c
            break
    if not bin_:
        return {"ok": False, "error": "找不到 dsh 命令"}

    try:
        r = subprocess.run(
            [bin_, "--profile", "headless", "--dump-config"],
            capture_output=True, text=True, timeout=60,
            creationflags=(0x08000000 if os.name == "nt" else 0))
        out = (r.stdout or "") + (r.stderr or "")
        has_mcp = "mcp-yuhai" in out
        has_err = "not found" in out.lower() or "error" in out.lower()
        disabled = out.count("disabled: true")
        return {
            "ok": has_mcp and not has_err,
            "hasMcpInDump": has_mcp,
            "disabledCount": disabled,
            "error": "" if not has_err else
                     "\n".join([l for l in out.split("\n")
                                if "error" in l.lower() or "not found" in l.lower()][:3]),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}
