"""短剧切片流程（严格对齐《短剧切片完整流程.md》）。

唯一标准流程：
    下载素材 → 转录台词 → 语音检测 → 类型判定 → 张力打分
    → 分两条线出片（单集 / 精品混剪）→ 校验 → 删素材

核心脚本（都在 E:\\账号运营\\tools）：
    transcribe_audio.py   faster-whisper 转录
    voice_check3.py       频谱检测人声（99.4%）
    classify.py           7 类强弱关键词加权
    score_lines2.py       8 维度张力打分
    cut_ep2.py            单集出片
    plan_from_tension.py  精品 5 阶段计划
    render_plan.py        渲染（xfade+调色+BGM+CTA）
    pipeline2.py          双线一键
    chk_full2.py          台词完整性 + 无重叠校验
    audio_guard.py        静音段检查
    mark_done.py          标记完成

硬约束（违反必返工）：
    ① 台词完整不截断（冲突丢低分段）
    ② 段间零重叠
    ③ pad 0.15s
    ④ 不用字幕 OCR 对齐
    ⑤ 过滤 <1.5s 的段
    ⑥ 单段 > target×1.4 拆单句
    ⑦ 时长容差 ±6s
    ⑧ 段数不足放宽
    ⑨ 成片 <30s 直接不生成
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso
from app import paths
from app import proc

log = logging.getLogger("yuhai.slice")

# ---------------- 路径 ----------------
def tools_dir() -> Path:
    return paths.tools_dir()


def state_dir() -> Path:
    return paths.state_dir()


def source_roots() -> list[Path]:
    """源素材可能存在的所有位置（按优先级）。"""
    return paths.source_roots()


def source_dir() -> Path:
    """主源素材目录（不存在就建）。"""
    d = paths.source_roots()[0]
    d.mkdir(parents=True, exist_ok=True)
    return d


def find_drama_dir(drama: str) -> Path | None:
    """在多个位置里找这部剧的文件夹。"""
    for root in source_roots():
        if not root.exists():
            continue
        # 精确名
        d = root / drama
        if d.is_dir() and list(d.glob("*.mp4")):
            return d
        # 抓取的目录名带 cid 后缀：<剧名>_<cid>
        for sub in root.iterdir():
            if not sub.is_dir():
                continue
            if sub.name == drama or sub.name.startswith(f"{drama}_"):
                if list(sub.glob("*.mp4")):
                    return sub
    return None


def out_root() -> Path:
    """成片根目录（可配置，默认 <工作区>\\处理好素材）。"""
    d = paths.output_root()
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------- 七种剧型 ----------------
DRAMA_TYPES = {
    "punch":   {"name": "纯爽反打流", "strong": ["billionaire", "heir", "ceo", "humiliate", "kneel", "beg"],
                "bgm": ["boss_swagger", "epic_rise"],
                "rhythm": "压抑 → 爆发 → 碾压 → 悬念"},
    "ethics":  {"name": "伦理撕扯流", "strong": ["divorce", "affair", "mistress", "husband", "custody"],
                "bgm": ["tension_loop", "dark_trap"],
                "rhythm": "压抑 → 对质 → 撕破脸 → 反转 → 悬念"},
    "backer":  {"name": "大佬撑腰流", "strong": ["bodyguard", "protect", "save", "scared", "beat", "threaten"],
                "bgm": ["boss_swagger", "dark_trap"],
                "rhythm": "委屈 → 憋屈 → 爆发 → 碾压 → 悬念"},
    "mystery": {"name": "倒叙悬疑流", "strong": ["secret", "truth", "hidden", "what happened", "evidence"],
                "bgm": ["dark_trap", "tension_loop"],
                "rhythm": "高能 → 回溯 → 揭密 → 反转 → 回环"},
    "tension": {"name": "张力拉锯流", "strong": ["kiss", "touch", "closer", "breathe", "flirt", "sweetheart"],
                "bgm": ["tension_loop", "dark_trap"],
                "rhythm": "挑衅 → 施压 → 逼问 → 袒露 → 悬念"},
    "sweet":   {"name": "甜宠轻度流", "strong": ["love you", "crush", "blush", "heartbeat", "confess"],
                "bgm": ["sweet_pop", "sad_piano"],
                "rhythm": "甜 → 酸 → 苦 → 回甜 → 悬念"},
    "rebirth": {"name": "重生逆袭流", "strong": ["second chance", "rebirth", "reborn", "past life", "i died", "not dead"],
                "bgm": ["epic_rise", "boss_swagger"],
                "rhythm": "低谷 → 觉醒 → 反攻 → 碾压 → 悬念"},
}

# 5 阶段结构（150s 目标）
STAGES = [
    {"name": "① 爆点开场钩子", "range": [0, 12]},
    {"name": "② 言语施压与连环反击", "range": [12, 40]},
    {"name": "③ 不可逆决裂时刻", "range": [40, 62]},
    {"name": "④ 强援入局/反差打脸", "range": [62, 85]},
    {"name": "⑤ 极致悬念卡点", "range": [85, 100]},
]

# 硬约束
CONSTRAINTS = {
    "padPre": 0.15,
    "padPost": 0.15,
    "xfadeDur": 0.28,
    "minTakeSec": 1.5,
    "targetTolerance": 6.0,
    "minOutputSec": 30,
    "splitThreshold": 1.4,
    "renderMinSegs": 2,
    "targetLufs": -14,
    "origDb": -20,
    "bgmDb": -19,
    "resolution": "1080x1920",
    "fps": 30,
}


def tool_env() -> dict:
    """给工具脚本注入路径环境变量。

    脚本里的 paths.py 会优先读这些变量，所以后端解析出来的路径
    就是脚本实际用的路径——两边不会漂移。换机器只改后端一处。
    """
    from app import paths as _p

    roots = [str(x) for x in _p.source_roots()]
    return {
        "PYTHONIOENCODING": "utf-8",
        "PYTHONUTF8": "1",
        # 工作区与各目录
        "YUHAI_WORKSPACE": str(_p.WORKSPACE),
        "YUHAI_TOOLS": str(_p.tools_dir()),
        "YUHAI_STATE": str(_p.state_dir()),
        # 源素材：主目录 + 所有候选都要给脚本，
        # 只用第一个会导致「剧在第二个目录里就找不到」
        "YUHAI_SOURCE": roots[0] if roots else "",
        "YUHAI_SOURCE_ROOTS": ";".join(roots),
        "YUHAI_OUTPUT": str(_p.output_root()),
        "YUHAI_LIBRARY": str(_p.library_root()),
        "YUHAI_AUDIO": str(_p.audio_dir()),
        "YUHAI_FONTS": str(_p.fonts_dir()),
        "YUHAI_WORK": str(_p.DATA_DIR / "work"),
        "YUHAI_ASR_WORK": str(_p.DATA_DIR / "work" / "asr"),
        "YUHAI_RENDER_WORK": str(_p.DATA_DIR / "work" / "render"),
        "YUHAI_VERIFY_VIS": str(_p.DATA_DIR / "work" / "verify_vis"),
    }


def _run(script: str, args: list[str], timeout: int = 7200,
         on_line=None) -> dict:
    """跑脚本，实时把输出喂给 on_line 回调（用于进度解析）。"""
    path = tools_dir() / script
    if not path.exists():
        return {"ok": False, "code": -1, "error": f"脚本不存在: {path}",
                "lines": []}
    cmd = [sys.executable, "-u", str(path), *args]
    env = {**os.environ, **tool_env()}
    lines: list[str] = []
    try:
        p = proc.popen(cmd, cwd=str(tools_dir()), env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding="utf-8", errors="replace",
                             bufsize=1)
        import time
        t0 = time.time()
        for line in p.stdout:  # type: ignore
            line = line.rstrip("\n")
            lines.append(line)
            if on_line:
                try:
                    on_line(line)
                except Exception:
                    pass
            if time.time() - t0 > timeout:
                p.kill()
                return {"ok": False, "code": -2, "error": "超时", "lines": lines}
        p.wait()
        return {"ok": p.returncode == 0, "code": p.returncode,
                "lines": lines, "cmd": " ".join(cmd)}
    except Exception as e:
        return {"ok": False, "code": -3, "error": str(e)[:200], "lines": lines}


# ---------------- 状态读取 ----------------
def read_transcript(drama: str) -> dict:
    p = state_dir() / "subs" / f"{drama}_transcript.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def read_voice(drama: str) -> dict:
    p = state_dir() / "voice_check" / f"{drama}.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def read_script(drama: str) -> dict:
    p = state_dir() / "scripts" / f"{drama}.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def read_tension(drama: str) -> dict:
    p = state_dir() / "plans" / f"{drama}_tension.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def read_plan(drama: str) -> dict:
    """读精品混剪计划。

    plan_from_tension.py 实际输出的是 {drama}_tension_plan.json，
    优先读它，其余为兼容旧文件名。
    """
    for name in (f"{drama}_tension_plan.json",
                 f"{drama}_premium_plan.json",
                 f"{drama}_plan.json"):
        p = state_dir() / "plans" / name
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
    # 兜底：按通配找最新生成的
    plans = sorted((state_dir() / "plans").glob(f"{drama}*plan*.json"),
                   key=lambda x: x.stat().st_mtime, reverse=True)
    for p in plans:
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
    return {}


def drama_status(drama: str) -> dict:
    """一部剧当前进行到哪一步（读 _state 判断）。"""
    tr = read_transcript(drama)
    vc = read_voice(drama)
    sc = read_script(drama)
    tn = read_tension(drama)
    pl = read_plan(drama)

    segs = tr.get("segments") or []
    eps = sorted({s.get("ep") for s in segs if s.get("ep")})
    dtype = sc.get("dtype") or sc.get("type") or ""
    dt = DRAMA_TYPES.get(dtype) or {}

    # 源素材
    src = find_drama_dir(drama)
    src_eps = sorted(f.name for f in src.glob("*.mp4")) if src else []

    # 成片
    # ⚠ cut_ep2.py 实际把单集输出到 OUT_BASE 根目录
    #   （文件名形如 <剧名>_01.mp4），而不是 单集_* 子目录。
    #   原来只查子目录，导致明明出片了却报 count=0。
    singles = []
    premiums = []

    # ① 单集：先查 单集_* 子目录（旧布局），再查根目录（实际布局）
    for d in out_root().glob("单集_*"):
        sub = d / drama
        if sub.exists():
            singles += [str(f) for f in sub.glob("*.mp4")]
    # 根目录：<剧名>_NN.mp4
    import re as _re
    pat = _re.compile(r"^%s_\d+\.mp4$" % _re.escape(drama))
    for f in out_root().glob("%s_*.mp4" % drama):
        if pat.match(f.name):
            singles.append(str(f))
    # 去重
    singles = sorted(set(singles))

    # ② 精品：查 精品混剪_* 子目录
    for d in out_root().glob("精品混剪_*"):
        sub = d / drama
        if sub.exists():
            premiums += [str(f) for f in sub.glob("*.mp4")]
    premiums = sorted(set(premiums))

    return {
        "drama": drama,
        "sourceEpisodes": len(src_eps),
        "sourceDir": str(src) if src else "",
        "sourceRoots": [str(r) for r in source_roots() if r.exists()],
        "steps": {
            "transcribe": {"done": bool(segs), "segments": len(segs),
                           "episodes": len(eps)},
            "voice": {"done": bool(vc), "checked": len(vc.get("results") or vc) if isinstance(vc, dict) else 0},
            "classify": {"done": bool(dtype), "dtype": dtype,
                         "typeName": dt.get("name", ""),
                         "rhythm": dt.get("rhythm", ""),
                         "bgm": dt.get("bgm", [])},
            "tension": {"done": bool(tn),
                        "segments": len(tn.get("segments") or []),
                        "dur": round(sum(float(s.get("dur") or 0)
                                         for s in (tn.get("segments") or [])), 1)},
            "plan": {"done": bool(pl),
                     "shots": len(pl.get("shots") or []),
                     "stages": len({s.get("stage")
                                    for s in (pl.get("shots") or [])
                                    if s.get("stage")})},
            "single": {"done": bool(singles), "count": len(singles), "files": singles[:10]},
            "premium": {"done": bool(premiums), "count": len(premiums), "files": premiums[:5]},
        },
        "ready": bool(segs),
    }


def list_dramas() -> list[dict]:
    """列出所有处理过/可处理的剧。

    三个来源合并（流程要求成片后删源片，所以不能只看源目录）：
        ① 源素材目录（还能继续切片）
        ② _state/subs 转录文件（跑过步骤①，源片可能已删）
        ③ 成片目录 单集_* / 精品混剪_*（已出片）
    """
    seen: dict[str, dict] = {}

    def clean_title(n: str) -> str:
        """目录名 <剧名>_<cid> → 只留剧名（cid 是纯数字长串）。"""
        if "_" in n:
            tail = n.rsplit("_", 1)[-1]
            if tail.isdigit() and len(tail) >= 10:
                return n.rsplit("_", 1)[0]
        return n

    def put(name: str, display: str = "", **kw) -> None:
        cur = seen.get(name)
        if cur is None:
            seen[name] = {"drama": name, "title": display or clean_title(name),
                          "dir": "", "root": "",
                          "episodes": 0, "sizeMb": 0.0, "progress": 0,
                          "hasSource": False, "hasState": False, "hasOutput": False,
                          "sourceEpisodes": 0, **kw}
        else:
            if display and not cur.get("title"):
                cur["title"] = display
            cur.update({k: v for k, v in kw.items() if v not in ("", 0, 0.0, False)
                        or k not in cur})

    # ① 源素材
    for root in source_roots():
        if not root.exists():
            continue
        for d in sorted(root.iterdir()):
            if not d.is_dir():
                continue
            # 只扫一次（*.mp4 已包含 EP*.mp4，之前加两遍导致集数翻倍）
            eps = list(d.glob("*.mp4"))
            if not eps:
                continue
            name = d.name
            display = clean_title(name)
            cur = seen.get(name)
            size = round(sum(f.stat().st_size for f in eps) / 1048576, 1)
            if cur is None:
                seen[name] = {"drama": d.name, "title": display,
                              "dir": str(d), "root": str(root),
                              "episodes": len(eps), "sizeMb": size, "progress": 0,
                              "hasSource": True, "hasState": False,
                              "hasOutput": False, "sourceEpisodes": len(eps)}
            else:
                cur["hasSource"] = True
                cur["dir"] = cur["dir"] or str(d)
                cur["root"] = cur["root"] or str(root)
                cur["episodes"] = max(cur["episodes"], len(eps))
                cur["sourceEpisodes"] = cur["episodes"]
                cur["sizeMb"] = max(cur["sizeMb"], size)

    # ② 转录状态（源片删了也保留）
    subs = state_dir() / "subs"
    if subs.exists():
        for f in subs.glob("*_transcript.json"):
            name = f.name[:-len("_transcript.json")]
            put(name)
            seen[name]["hasState"] = True

    # ③ 成片
    for pat in ("单集_*", "精品混剪_*"):
        for d in out_root().glob(pat):
            if not d.is_dir():
                continue
            for sub in sorted(d.iterdir()):
                if not sub.is_dir():
                    continue
                vids = list(sub.glob("*.mp4"))
                if not vids:
                    continue
                put(sub.name)
                seen[sub.name]["hasOutput"] = True

    # 补 steps / progress
    for name, item in seen.items():
        st = drama_status(item["drama"])
        steps = st["steps"]
        item["steps"] = steps
        item["progress"] = sum(1 for k in ("transcribe", "voice", "classify", "tension")
                               if steps[k]["done"])
        item["episodes"] = max(item["episodes"], st.get("sourceEpisodes") or 0)
        item["epLines"] = steps["transcribe"].get("episodes") or 0
        item["outCount"] = (steps["single"].get("count") or 0) + \
                           (steps["premium"].get("count") or 0)
        item["canSlice"] = bool(item["hasSource"])
        item["state"] = ("已出片" if item["hasOutput"]
                         else "可切片" if item["hasSource"]
                         else "仅状态（源片已删）" if item["hasState"]
                         else "未知")

    return sorted(seen.values(),
                  key=lambda x: (not x["hasSource"], -x["outCount"], -x["episodes"]))



# ---------------- 五个步骤 ----------------
def step_transcribe(job_id: str, drama: str, model: str = "small",
                    max_ep: int = 0, lang: str = "auto") -> dict:
    """步骤 1：台词转录。

    lang 默认 "auto"：让 whisper 自动检测语言。
    绝不能写死 "en" —— 印尼语/日语/葡语剧会被「翻译」成英文，
    台词内容错，后面类型判定、张力打分、选点全部建立在错误文本上。
    """
    args = ["--drama", drama, "--model", model, "--lang", lang]
    if max_ep:
        args += ["--max-ep", str(max_ep)]

    def on_line(line: str):
        # whisper 输出进度：解析 "EP01 12.3s" 之类
        m = re.search(r"(EP\d+).*?(\d+\.?\d*)s", line)
        if m:
            db.exec("UPDATE jobs SET steps=? WHERE id=?",
                    (json.dumps([{"name": f"转录 {m.group(1)}",
                                  "state": "run",
                                  "note": f"{m.group(2)}s"}],
                                ensure_ascii=False), job_id))

    r = _run("transcribe_audio.py", args, on_line=on_line)
    if r["ok"]:
        tr = read_transcript(drama)
        n = len(tr.get("segments") or [])
        det = tr.get("detected_lang") or ""
        forced = tr.get("lang") or ""
        warn = ""
        if det and forced and forced not in ("auto", "none", "") and det != forced:
            warn = f" ⚠️ 语言不符(强制{forced}/实际{det})"
        return {"ok": True, "segments": n, "lang": det or forced,
                "note": f"转录 {n} 句 [{det or forced}]{warn}"}
    return {"ok": False, "error": (r.get("error") or
                                   "\n".join(r["lines"][-5:]))[:400]}


def step_voice(job_id: str, drama: str) -> dict:
    """步骤 2：语音检测（过滤无声段）。"""
    r = _run("voice_check3.py", ["--drama", drama])
    if r["ok"]:
        vc = read_voice(drama)
        return {"ok": True, "note": "频谱检测完成"}
    return {"ok": False, "error": (r.get("error") or
                                   "\n".join(r["lines"][-5:]))[:400]}


def step_classify(job_id: str, drama: str) -> dict:
    """步骤 3：类型判定（7 类强弱关键词）。"""
    r = _run("classify.py", ["--drama", drama])
    sc = read_script(drama)
    dtype = sc.get("dtype") or sc.get("type") or ""
    if r["ok"] and dtype:
        dt = DRAMA_TYPES.get(dtype, {})
        return {"ok": True, "dtype": dtype,
                "note": f"{dt.get('name', dtype)}"}
    # 诊断：区分「脚本失败」还是「台词太少/语言错」
    tr = read_transcript(drama)
    n = len(tr.get("segments") or [])
    det = tr.get("detected_lang") or ""
    why = "未判定出类型"
    if n == 0:
        why = "未判定出类型（无台词本，先跑步骤①）"
    elif n < 20:
        why = f"未判定出类型（仅 {n} 句台词，样本太少）"
    elif det and det not in ("en",):
        why = f"未判定出类型（台词是 {det}，关键词库以英语为主）"
    return {"ok": False, "error": why[:300]}


def step_tension(job_id: str, drama: str, thresh: float = 1.0,
                 max_gap: float = 1.5) -> dict:
    """步骤 4：台词张力打分（8 维度）。

    score_lines2.py 的实际输出字段是 "segments"（张力段），
    不是 "lines"/"scored" —— 读错字段会导致永远 0 句。
    """
    r = _run("score_lines2.py",
             ["--drama", drama, "--thresh", str(thresh),
              "--max-gap", str(max_gap)])
    if not r["ok"]:
        return {"ok": False, "error": (r.get("error") or
                                       "\n".join(r["lines"][-5:]))[:400]}

    tn = read_tension(drama)
    segs = tn.get("segments") or []
    n = len(segs)
    total_dur = sum(float(s.get("dur") or 0) for s in segs)
    # 真实失败：0 段 = 阈值太高或台词质量差，要明确报出来
    if n == 0:
        tr = read_transcript(drama)
        n_lines = len(tr.get("segments") or [])
        return {"ok": False,
                "error": (f"张力打分为 0 段（台词 {n_lines} 句，阈值 {thresh}）。"
                          f"把阈值降到 0.6 再试，或检查台词语言是否正确")[:300]}
    return {"ok": True, "segments": n, "dur": round(total_dur, 1),
            "note": f"{n} 个张力段 / {total_dur:.0f}s"}


def step_single(job_id: str, drama: str, eps: list[str] | None = None,
                target: float = 45) -> dict:
    """步骤 5-A：单集出片（40-55s，段边界对齐台词）。"""
    made, failed = [], []
    eps = eps or []
    if not eps:
        # 从转录里拿集号
        tr = read_transcript(drama)
        eps = sorted({s.get("ep") for s in (tr.get("segments") or [])
                      if s.get("ep")})[:20]
    total = max(1, len(eps))
    for i, ep in enumerate(eps):
        r = _run("cut_ep2.py",
                 ["--drama", drama, "--ep", ep, "--target", str(target)])
        if r["ok"]:
            made.append(ep)
        else:
            failed.append({"ep": ep,
                           "error": (r.get("error") or
                                     "\n".join(r["lines"][-3:]))[:200]})
        db.exec("UPDATE jobs SET progress=? WHERE id=?",
                (int((i + 1) / total * 100), job_id))
    return {"ok": bool(made), "made": made, "failed": failed,
            "note": f"出片 {len(made)}/{len(eps)} 集"}


def step_premium(job_id: str, drama: str) -> dict:
    """步骤 5-B：精品混剪（5 阶段）。"""
    # 先做计划
    r1 = _run("plan_from_tension.py", ["--drama", drama])
    if not r1["ok"]:
        return {"ok": False,
                "error": (r1.get("error") or "\n".join(r1["lines"][-5:]))[:400]}

    plan = read_plan(drama)
    if not plan:
        return {"ok": False,
                "error": f"计划文件未生成（找 {drama}_tension_plan.json）"}

    # 计划文件名：plan_from_tension.py 输出 {drama}_tension_plan.json
    plan_path = state_dir() / "plans" / f"{drama}_tension_plan.json"
    if not plan_path.exists():
        cands = sorted((state_dir() / "plans").glob(f"{drama}*plan*.json"),
                       key=lambda x: x.stat().st_mtime, reverse=True)
        if not cands:
            return {"ok": False, "error": f"计划文件不存在: {plan_path.name}"}
        plan_path = cands[0]

    # 输出到 精品混剪_<日期>\<剧名>\
    from datetime import date
    outdir = out_root() / f"精品混剪_{date.today().isoformat()}" / drama
    outdir.mkdir(parents=True, exist_ok=True)
    outfile = outdir / f"{drama}_主线版.mp4"

    r2 = _run("render_plan.py",
              [str(plan_path), "--out", str(outfile), "--no-stage-label"])
    if r2["ok"] and outfile.exists():
        size = round(outfile.stat().st_size / 1048576, 1)
        shots = plan.get("shots") or []
        stages = len({s.get("stage") for s in shots if s.get("stage")})
        return {"ok": True, "path": str(outfile), "sizeMb": size,
                "shots": len(shots), "stages": stages,
                "note": f"主线版 {size}MB / {len(shots)} 段 / {stages} 阶段"}
    return {"ok": False,
            "error": (r2.get("error") or "\n".join(r2["lines"][-5:]))[:400]}


# ---------------- 校验 ----------------
def verify_output(video_path: str) -> dict:
    """校验成片：台词完整性 + 无重叠 + 无静音段。"""
    from app.services import video_maker as vm
    info = vm.probe(video_path)
    out = {"path": video_path, "info": info, "checks": []}

    # 时长 ≥30s
    dur = info.get("dur") or 0
    out["checks"].append({"name": "时长 ≥30s", "ok": dur >= 30,
                          "value": f"{dur}s"})
    # 分辨率
    w, h = info.get("w") or 0, info.get("h") or 0
    out["checks"].append({"name": "分辨率 1080×1920",
                          "ok": w == 1080 and h == 1920,
                          "value": f"{w}×{h}"})
    # 帧率
    fps = info.get("fps") or 0
    out["checks"].append({"name": "帧率 30fps",
                          "ok": abs(fps - 30) < 0.5, "value": f"{fps}fps"})
    # 音轨
    out["checks"].append({"name": "有音轨", "ok": bool(info.get("audio")),
                          "value": "有" if info.get("audio") else "无"})
    # 响度
    lufs = measure_lufs(video_path)
    out["checks"].append({"name": "响度 ≈ -14 LUFS",
                          "ok": abs(lufs + 14) < 3 if lufs else False,
                          "value": f"{lufs} LUFS" if lufs else "测不出"})
    out["lufs"] = lufs
    return out


def measure_lufs(path: str) -> float | None:
    """用 ffmpeg loudnorm 测响度。"""
    from app.services import video_maker as vm
    try:
        p = proc.run(
            [vm.ffmpeg_path(), "-hide_banner", "-i", path,
             "-af", "loudnorm=I=-14:TP=-1.5:print_format=json",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=300,
            encoding="utf-8", errors="replace")
        m = re.search(r'"input_i"\s*:\s*"(-?[\d.]+)"', p.stderr or "")
        return float(m.group(1)) if m else None
    except Exception:
        return None


def check_dialogue_complete(drama: str, ep: str = "",
                            plan_path: str = "") -> dict:
    """通用台词完整性校验（替代硬编码路径的 chk_full2.py）。

    检查三件事：
        ① 每段声称的台词是否完整落在段内（不被截断）
        ② 相邻段是否重叠
        ③ 段内实际台词数与声称是否一致

    数据来源：
        plan: _state/plans/<剧>_<EP>_dialogue.json 或指定的 plan.json
        transcript: _state/subs/<剧>_transcript.json
    """
    tr = read_transcript(drama)
    segs = tr.get("segments") or []
    if not segs:
        return {"ok": False, "error": "没有转录文件，先跑步骤①"}

    # 找 plan
    plans_dir = state_dir() / "plans"
    plan = None
    plan_file = None
    if plan_path and Path(plan_path).exists():
        try:
            plan = json.loads(Path(plan_path).read_text(encoding="utf-8-sig"))
            plan_file = plan_path
        except Exception:
            pass
    if plan is None:
        cands = []
        if ep:
            cands.append(plans_dir / f"{drama}_{ep}_dialogue.json")
        # 优先 EP 编号的 plan，跳过 leftover / tension 之类非分段文件
        cands += sorted(plans_dir.glob(f"{drama}_EP*_dialogue.json"))
        cands += sorted(plans_dir.glob(f"{drama}*plan*.json"))
        for c in cands:
            if c.exists():
                try:
                    plan = json.loads(c.read_text(encoding="utf-8-sig"))
                    plan_file = str(c)
                    break
                except Exception:
                    continue
    if not plan:
        return {"ok": False, "error": f"没有找到 plan 文件（{plans_dir}\\{drama}*）"}

    shots = plan.get("shots") or plan.get("segments") or []
    if not shots:
        return {"ok": False, "error": "plan 里没有 shots"}

    # ---- 解析该 plan 属于哪一集（关键：否则会拿全剧台词比对） ----
    ep_resolved = (ep or plan.get("ep") or "").strip()
    if not ep_resolved:
        for s in shots:
            if s.get("ep"):
                ep_resolved = str(s["ep"]).strip()
                break
    if not ep_resolved and plan_file:
        m = re.search(r"_(EP\d+)", Path(plan_file).name, re.I)
        if m:
            ep_resolved = m.group(1).upper()
    if not ep_resolved:
        # 无法定位集号 → 不猜，直接报错，避免全剧台词误判
        return {"ok": False, "planFile": plan_file,
                "error": "plan 未标注集号，无法定位对应台词（请传 ep=EPxx）"}

    # 该集台词（集号大小写/前缀宽松匹配）
    def _same_ep(v: Any) -> bool:
        a = str(v or "").strip().upper()
        b = ep_resolved.upper()
        return a == b or a.lstrip("EP") == b.lstrip("EP")

    ep_lines = [s for s in segs if _same_ep(s.get("ep"))]
    ep_lines.sort(key=lambda x: x.get("start") or 0)
    if not ep_lines:
        return {"ok": False, "planFile": plan_file, "ep": ep_resolved,
                "error": f"转录里没有 {ep_resolved} 的台词（先跑步骤①转录）"}

    TOL = 0.25          # 边界容差：切点落在台词首尾 0.25s 内不算截断
    issues = []
    detail = []
    prev_end = -999.0
    for i, s in enumerate(shots):
        st = float(s.get("start") or 0)
        en = float(s.get("end") or 0)
        in_seg = [l for l in ep_lines
                  if (l.get("start") or 0) >= st - TOL
                  and (l.get("end") or 0) <= en + TOL]
        # 截断 = 与段有实质交集、但超出容差没被完全包含
        cut = []
        for l in ep_lines:
            ls = float(l.get("start") or 0)
            le = float(l.get("end") or 0)
            if le <= st + TOL or ls >= en - TOL:      # 完全在段外
                continue
            if ls >= st - TOL and le <= en + TOL:     # 完全在段内
                continue
            # 越过边界的部分超过容差才算截断
            lost = max(0.0, st - ls) + max(0.0, le - en)
            if lost > TOL:
                cut.append({"start": ls, "end": le, "lost": round(lost, 2),
                            "text": (l.get("text") or "")[:60]})
        gap = st - prev_end if prev_end > -999 else 0
        overlap = gap < -0.05

        if cut:
            worst = max(c["lost"] for c in cut)
            issues.append(f"段{i+1} 截断 {len(cut)} 句台词（最严重丢 {worst:.2f}s）")
        if overlap:
            issues.append(f"段{i+1} 与上段重叠 {-gap:.2f}s")

        detail.append({
            "seg": i + 1, "start": round(st, 2), "end": round(en, 2),
            "dur": round(en - st, 2), "gap": round(gap, 2),
            "lines": len(in_seg), "cut": len(cut),
            "cutText": [c["text"] for c in cut[:3]],
            "overlap": overlap,
            "text": (s.get("text") or "")[:80],
        })
        prev_end = en

    total_dur = sum(d["dur"] for d in detail)
    return {
        "ok": len(issues) == 0,
        "planFile": plan_file,
        "ep": ep_resolved,
        "epLines": len(ep_lines),
        "segments": len(shots),
        "totalDur": round(total_dur, 1),
        "issues": issues[:20],
        "detail": detail[:60],
        "verdict": ("✅ 全部段内台词完整、无重叠" if not issues
                    else f"❌ {len(issues)} 个问题"),
    }


def check_audio_guard(video_path: str, min_silence: float = 2.0,
                      noise_db: int = -40) -> dict:
    """静音段检查（替代 audio_guard.py）。

    用 ffmpeg silencedetect 找超过 min_silence 秒的静音。
    """
    from app.services import video_maker as vm
    try:
        r = proc.run(
            [vm.ffmpeg_path(), "-hide_banner", "-i", video_path,
             "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=600,
            encoding="utf-8", errors="replace")
        err = r.stderr or ""
        starts = [float(x) for x in re.findall(r"silence_start:\s*([\d.]+)", err)]
        ends = [float(x) for x in re.findall(r"silence_end:\s*([\d.]+)", err)]
        spans = []
        for i, s in enumerate(starts):
            e = ends[i] if i < len(ends) else None
            spans.append({"start": round(s, 1),
                          "end": round(e, 1) if e else None,
                          "dur": round((e - s), 1) if e else None})
        total = sum(x["dur"] or 0 for x in spans)
        return {
            "ok": len(spans) == 0,
            "silences": len(spans),
            "totalSilence": round(total, 1),
            "spans": spans[:15],
            "threshold": f"{noise_db}dB / {min_silence}s",
            "verdict": ("✅ 无静音段" if not spans
                        else f"⚠ {len(spans)} 段静音，共 {total:.1f}s"),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


# ---------------- 完整管线 ----------------
async def run_pipeline(job_id: str, drama: str, cfg: dict) -> None:
    """跑完整流程。"""
    do_single = cfg.get("single", True)
    do_premium = cfg.get("premium", True)
    model = cfg.get("model", "small")
    target = cfg.get("target", 45)
    max_ep = cfg.get("maxEp", 0)
    eps = cfg.get("episodes") or []

    names = ["① 台词转录", "② 语音检测", "③ 类型判定",
             "④ 张力打分", "⑤ 单集出片", "⑥ 精品混剪"]
    if not do_single:
        names[4] = "⑤ 单集出片（跳过）"
    if not do_premium:
        names[5] = "⑥ 精品混剪（跳过）"

    steps = [{"name": n, "state": "wait", "note": ""} for n in names]
    db.exec("UPDATE jobs SET status='running',steps=?,started_at=? WHERE id=?",
            (json.dumps(steps, ensure_ascii=False), now_iso(), job_id))

    def mark(i: int, state: str, note: str = ""):
        steps[i]["state"] = state
        if note:
            steps[i]["note"] = note[:200]
        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                (json.dumps(steps, ensure_ascii=False), job_id))

    result: dict[str, Any] = {"drama": drama}
    try:
        # ① 转录
        mark(0, "run")
        r = step_transcribe(job_id, drama, model, max_ep)
        mark(0, "done" if r["ok"] else "err", r.get("note") or r.get("error", ""))
        result["transcribe"] = r
        if not r["ok"]:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (f"转录失败: {r.get('error')}", now_iso(), job_id))
            return

        # ② 语音检测
        mark(1, "run")
        r = step_voice(job_id, drama)
        mark(1, "done" if r["ok"] else "warn", r.get("note") or r.get("error", ""))
        result["voice"] = r

        # ③ 类型判定
        mark(2, "run")
        r = step_classify(job_id, drama)
        mark(2, "done" if r["ok"] else "warn", r.get("note") or r.get("error", ""))
        result["classify"] = r

        # ④ 张力打分
        mark(3, "run")
        r = step_tension(job_id, drama)
        mark(3, "done" if r["ok"] else "err", r.get("note") or r.get("error", ""))
        result["tension"] = r
        if not r["ok"]:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (f"打分失败: {r.get('error')}", now_iso(), job_id))
            return

        # ⑤ 单集
        if do_single:
            mark(4, "run")
            r = step_single(job_id, drama, eps, target)
            mark(4, "done" if r["ok"] else "warn",
                 r.get("note") or r.get("error", ""))
            result["single"] = r
        else:
            mark(4, "skip", "已跳过")

        # ⑥ 精品
        if do_premium:
            mark(5, "run")
            r = step_premium(job_id, drama)
            mark(5, "done" if r["ok"] else "warn",
                 r.get("note") or r.get("error", ""))
            result["premium"] = r
        else:
            mark(5, "skip", "已跳过")

        # 校验
        verifies = []
        for f in (result.get("single", {}).get("made") or [])[:3]:
            pass
        prem = result.get("premium", {}).get("path")
        if prem:
            verifies.append(verify_output(prem))
        result["verify"] = verifies

        db.exec("UPDATE jobs SET status='done',progress=100,result=?,ended_at=?"
                " WHERE id=?",
                (json.dumps(result, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "slice", f"{drama} 流程完成")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "slice", str(e)[:200])

# ══════════════════════════════════════════
#  剧型（包装 classify.py）
# ══════════════════════════════════════════
def _classify_mod():
    """导入 classify.py（tools 目录下）。"""
    import sys
    td = tools_dir()
    if str(td) not in sys.path:
        sys.path.insert(0, str(td))
    import classify as C
    return C


def list_types() -> dict:
    """列出所有剧型 + 阈值。"""
    try:
        C = _classify_mod()
        return {"ok": True, "types": C.ALL_TYPES,
                "fallback": C.FALLBACK_TYPE,
                "threshold": C.MIN_RATE,
                "minHits": C.MIN_HITS,
                "note": "7 种真实类型 + 1 种通用兜底"}
    except Exception as e:
        return {"ok": False, "error": "读取类型失败: %s" % str(e)[:100]}


def classify_drama(drama: str) -> dict:
    """判定某部剧的类型。"""
    try:
        C = _classify_mod()
        t, d = C.classify(drama)
        if t is None:
            return {"ok": False,
                    "error": "没找到这部剧的转录文件",
                    "drama": drama}
        return {"ok": True, "drama": drama, "type": t,
                "matched": d.get("matched"),
                "fallback": d.get("fallback"),
                "override": d.get("override"),
                "bestScore": d.get("bestScore"),
                "bestHits": d.get("bestHits"),
                "threshold": d.get("threshold"),
                "nLines": d.get("n_lines"),
                "suggestTop": d.get("suggestTop"),
                "scores": d.get("scores"),
                "note": d.get("note") or ""}
    except Exception as e:
        return {"ok": False, "error": "判定失败: %s" % str(e)[:120]}


def set_type_override(drama: str, type_name: str = "") -> dict:
    """手动指定类型。空字符串 = 取消。"""
    try:
        C = _classify_mod()
        return C.set_override(drama, type_name)
    except Exception as e:
        return {"ok": False, "error": "设置失败: %s" % str(e)[:120]}


def type_report() -> list:
    """所有剧的判定结果。"""
    out = []
    try:
        C = _classify_mod()
    except Exception as e:
        return [{"error": str(e)[:80]}]
    try:
        for d in list_dramas():
            name = d.get("drama") or ""
            if not name:
                continue
            try:
                t, det = C.classify(name)
            except Exception:
                continue
            out.append({
                "drama": name,
                "title": d.get("title") or name,
                "type": t,
                "matched": (det or {}).get("matched"),
                "fallback": (det or {}).get("fallback"),
                "override": (det or {}).get("override"),
                "bestScore": (det or {}).get("bestScore"),
                "nLines": (det or {}).get("n_lines"),
                "suggestTop": (det or {}).get("suggestTop"),
            })
    except Exception as e:
        out.append({"error": str(e)[:80]})
    return out

