# -*- coding: utf-8 -*-
"""
agent_chat.py — 用当前接入 Agent 自己的模型做对话式编排

工作方式：
  ① 拿用户消息 + 工具定义（从 mcp_server 的 18 个工具）
  ② 发给 agent 自己的模型（function calling）
  ③ 模型返回 tool_calls → 执行 → 结果回灌 → 继续
  ④ 循环直到模型给出最终回答

模型来源：agent_models 里当前接入的 agent 的 text_model
  dsh      → workbuddy/glm-5.3-flash  @ 127.0.0.1:18326
  ollama   → ui-tars-2b 等 @ 127.0.0.1:11434
  codex    → config.toml 里的 model
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from typing import Any

from app.services import agent_detect as ad
from app.services import agent_models as am

log = logging.getLogger("yuhai.agent.chat")

# ── 停止信号 ──────────────────────────────────────────────
# chat() 运行在 to_thread 的子线程里；stop() 由 HTTP 接口从另一线程调用。
import threading as _threading

_STOP = _threading.Event()          # 置位表示"请求停止"
_STOP_REASON = [""]


class Stopped(Exception):
    """用户主动停止所抛出的中断信号。"""


def request_stop(reason: str = "用户停止") -> dict:
    """请求停止当前/后续对话（可重复调用，幂等）。"""
    _STOP.set()
    _STOP_REASON[0] = reason
    log.warning("agent chat 收到停止请求: %s", reason)
    return {"ok": True, "stopped": True, "reason": reason}


def clear_stop() -> None:
    """新一轮对话开始前复位。"""
    _STOP.clear()
    _STOP_REASON[0] = ""


def is_stopped() -> bool:
    return _STOP.is_set()


def _check_stop() -> None:
    """在关键点调用；被停止则抛 Stopped。"""
    if _STOP.is_set():
        raise Stopped(_STOP_REASON[0] or "用户停止")


MAX_ROUNDS = 500        # 最多几轮工具调用（长流程可达走完）
# 说明：完成「选剧→切片→等待→发布」这种长流程需要 20+ 轮，
#       6 轮远远不够，agent 会中途被截断并回复"轮数用尽"。
TIMEOUT = 90

# 需要用户确认的写操作
NEED_CONFIRM = {
    "slice_run", "slice_env_install", "grab_download",
    "publish_reels", "memory_set",
}


# ---------------- 取当前 agent 的对话模型 ----------------
def pick_model() -> dict:
    """返回 (endpoint, model_id, api_key)。"""
    ov = am.overview()
    cid = ov.get("connected")
    if not cid:
        return {"ok": False, "error": "还没接入 Agent（先去雨海 Agent 页选一个）"}

    for a in ad.AGENTS:
        if a["id"] != cid:
            continue
        raw = ad.detect_one(a)
        endpoint = raw.get("endpoint") or ""
        models = raw.get("models") or []
        api_key = ""

        # 用户手动指定的模型优先
        try:
            from app.services import agent_models as _am
            chosen = _am.get_active_model(cid)
            if chosen and chosen in {m.get("id") for m in models}:
                mid = chosen
            else:
                chosen = ""
        except Exception:
            chosen = ""
        if cid == "dsh":
            cfg = ad._read_json(a["paths"][0])
            api_key = cfg.get("key", "")
            if not chosen:
                mid = cfg.get("text_model") or (models[0]["id"] if models else "")
        elif a["kind"] == "toml":
            t = ad._read_toml(a["paths"][0])
            mid = t.get("model") or (models[0]["id"] if models else "")
            prov = t.get("model_provider", "")
            pinfo = (t.get("providers") or {}).get(prov) or {}
            envk = pinfo.get("env_key", "")
            if envk:
                api_key = os.environ.get(envk, "")
        elif cid == "ollama":
            mid = models[0]["id"] if models else ""
        else:
            mid = models[0]["id"] if models else ""

        if not mid:
            return {"ok": False,
                    "error": f"{raw.get('name')} 没有配置可用模型"}
        if not endpoint:
            return {"ok": False,
                    "error": f"{raw.get('name')} 没有可用 endpoint"}
        return {"ok": True, "endpoint": endpoint, "model": mid,
                "apiKey": api_key, "agent": cid, "name": raw.get("name")}

    return {"ok": False, "error": "找不到该 agent 的配置"}


# 常见模型的上下文窗口（token）
CTX_WINDOWS = {
    "glm-5.3": 128000, "deepseek": 128000, "gpt-oss": 32768,
    "nemotron": 128000, "minimax": 200000, "step-5": 128000,
    "qwen": 128000, "claude": 200000, "gemini": 1000000,
    "kimi": 128000, "mimo": 128000,
}


def _ctx_pct(usage: dict, model: str) -> int:
    """上下文占用百分比（按模型窗口估算）。

    usage.prompt 本轮输入 token，completion 输出;
    占用率 = (输入 + 输出) / 窗口 × 100
    """
    win = 128000
    ml = (model or "").lower()
    for k, v in CTX_WINDOWS.items():
        if k in ml:
            win = v
            break
    used = int(usage.get("prompt") or 0) + int(usage.get("completion") or 0)
    if win <= 0:
        return 0
    return min(100, int(used * 100 / win))


# ---------------- 工具定义 ----------------
def tool_specs() -> list[dict]:
    """从 mcp_server 的工具表转成 OpenAI function calling 格式。"""
    import asyncio
    from app import mcp_server as M

    async def _get():
        return await M.mcp.list_tools()

    try:
        tools = asyncio.run(_get())
    except RuntimeError:
        # 已有事件循环（FastAPI 里）→ 用线程跑
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as ex:
            tools = ex.submit(lambda: asyncio.run(_get())).result()

    out = []
    for t in tools:
        schema = getattr(t, "inputSchema", None) or \
            {"type": "object", "properties": {}, "additionalProperties": False}
        out.append({
            "type": "function",
            "function": {
                "name": t.name,
                "description": (t.description or "")[:400],
                "parameters": schema,
            },
        })
    return out


def call_tool(name: str, args: dict) -> dict:
    """执行一个 MCP 工具，返回纯 dict。"""
    import asyncio
    from app import mcp_server as M

    async def _call():
        return await M.mcp.call_tool(name, args or {})

    try:
        r = asyncio.run(_call())
    except RuntimeError:
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as ex:
            r = ex.submit(lambda: asyncio.run(_call())).result()

    # mcp 2.x 返回 CallToolResult（不是 tuple）
    # 结构：.structured_content / .content[TextContent(text=json)] / .is_error
    sc = getattr(r, "structured_content", None)
    if isinstance(sc, dict) and sc:
        return sc

    is_err = bool(getattr(r, "is_error", False))
    content = getattr(r, "content", None)
    if content is None and isinstance(r, tuple):
        content = r[0]
        sc2 = r[1] if len(r) > 1 else None
        if isinstance(sc2, dict) and sc2:
            return sc2

    txt = ""
    for c in (content or []):
        txt += getattr(c, "text", "") or ""
    if txt:
        try:
            d = json.loads(txt)
            return d if isinstance(d, dict) else {"result": d}
        except Exception:
            return {"raw": txt, "isError": is_err}

    return r if isinstance(r, dict) else {"raw": str(r)[:500],
                                          "isError": is_err}


# ---------------- HTTP 调用 ----------------
def _post_chat(endpoint: str, model: str, messages: list,
               tools: list | None, api_key: str = "") -> dict:
    base = endpoint.rstrip("/")
    is_ollama = "11434" in base

    if is_ollama:
        url = base + "/api/chat"
        body = {"model": model, "messages": messages, "stream": False}
        if tools:
            body["tools"] = tools
        headers = {"Content-Type": "application/json"}
    else:
        if not base.endswith("/v1"):
            base += "/v1"
        url = base + "/chat/completions"
        body = {"model": model, "messages": messages,
                "temperature": 0.3, "max_tokens": 1200}
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers=headers)
    try:
        raw = urllib.request.urlopen(req, timeout=TIMEOUT).read()
        return {"ok": True, "data": json.loads(raw)}
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = (e.read() or b"").decode("utf-8", "replace")[:300]
        except Exception:
            pass
        return {"ok": False, "error": f"HTTP {e.code}", "detail": detail}
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}


def _parse_reply(d: dict, is_ollama: bool) -> dict:
    """统一解析成 {content, tool_calls}。"""
    if is_ollama:
        msg = d.get("message") or {}
        calls = []
        for c in (msg.get("tool_calls") or []):
            fn = c.get("function") or {}
            args = fn.get("arguments")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except Exception:
                    args = {}
            calls.append({"name": fn.get("name"), "args": args or {}})
        return {"content": (msg.get("content") or "").strip(),
                "tool_calls": calls}

    ch = (d.get("choices") or [{}])[0]
    msg = ch.get("message") or {}
    calls = []
    for c in (msg.get("tool_calls") or []):
        fn = c.get("function") or {}
        args = fn.get("arguments")
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {}
        calls.append({"name": fn.get("name"), "args": args or {},
                      "id": c.get("id") or ""})
    content = (msg.get("content") or "").strip()
    if not content:
        content = (msg.get("reasoning_content") or "").strip()
    return {"content": content, "tool_calls": calls, "id": ch.get("id")}


# ---------------- 主对话循环 ----------------
SYSTEM_PROMPT = """你是「雨海工作台」的运营助手。你能直接操作这个工作台。

能力：抓剧、切片、查成片、发布、看数据、**读写本地文件**。

━━━ 文件工具（处理表格/大文件必看）━━━
- fs_grep(path, pattern, col, maxHits)
    全文搜索，**不受读大小限制**，几十万行的表也能一次扫完。
    col=8 表示只搜第 9 列（0 基），做 TSV/CSV 按列筛选时必用。
    例：fs_grep("x.tsv", "GL", col=8) → 只找「内容主题」列含 GL 的行
- fs_read_chunk(path, offset, maxKb)
    大文件分段读，用返回的 nextOffset 继续下一段。适合逐段分析。
- fs_table(path, sep, columns, filter, limit)
    把 TSV/CSV 直接读成结构化行，可只取指定列、按关键词过滤。
    做「按某列筛选/统计」时**优先用它**，比 fs_read 更省事。
- fs_read / fs_list / fs_find / fs_write / fs_stat / fs_disks
    普通读写。

⚠ 处理大表格的正确姿势：
  不要用 fs_read 硬读（会截断）。
  要筛选 → fs_table(filter=...)
  要搜索 → fs_grep(col=...)
  要逐段看 → fs_read_chunk
  结论必须基于真实搜索结果，**不要因为"没看到"就说"没有"**，
  除非你已经用 fs_grep 全量搜过并确认 0 命中。

━━━ 干活原则 ━━━
1. 先看环境（slice_env_check），缺什么提示用户
2. 列剧（slice_list_dramas），确认要切哪部
3. 切片（slice_run）后立刻告诉用户 job_id
4. 用户问进度就用 slice_status
5. 报错时明确说哪里错了、怎么修
6. 记住重要状态（memory_set）
7. 批量查剧（dl_sd_batch）> 5 部时立即返回 jobId，
   之后用 dl_sd_batch_status 查进度，别干等

━━━ 从剧库表格里选剧的标准流程 ━━━
表结构（TSV，制表符分隔，第 1 行是表头）：
  [0]日期 [1]资源类型 [2]collection_id(剧集id) [3]是否新热剧
  [4]剧目类型 [5]剧目等级 [6]剧集名称 [7]contract title
  [8]内容主题 [9]contract id ...

选剧步骤（自己做完，别问用户）：
1. 先确认有哪些标签：
   fs_grep(文件, "^[^\t]*\t", col=8) 或
   fs_table(文件, columns="内容主题", limit=2000) 然后统计
2. 用户要的类型如果在标签里 → fs_grep(文件, "标签名", col=8) 精确取
3. 用户要的类型**不在标签里** → 不要空转找，直接：
   · 说明"库里没有该标签，全部 N 种标签是：..."
   · 给出替代方案（按剧名关键词 / 按题材近似）
   · 按最接近的方案先挑出候选清单，让用户确认或直接跑
4. 挑出的 id 用 [2]collection_id 列，格式是 19 位数字

━━━ TK短剧下载：唯一正确流程（别走弯路）━━━
用户给的 TK id（19 位 collection_id）要下载成片，只有一条路：

  ① dl_sd_meta(id="7697601274577196039")
     拿剧名/总集数/每集 item_id。
     注意：eps 里的 url 和 dl 字段是空的，这是正常的，别纠结。

  ② dl_tk_eps(tkId="7697601274577196039", eps=[1,2,3,4,5,6])
     这是**唯一能从 TK id 直接下片**的工具。
     每集约 15 秒、2-3MB，会返回文件路径。
     下载到 data/tk_downloads/<tkId>/ 下。

⚠ 不要做的事（这些都会失败，已验证）：
  ✗ dl_check("tiktok_drama", id)  → tiktok_drama 不在 SITES 里，必失败
  ✗ dl_tiktok_download(id)        → 直连拿不到 playAddr，必超时
  ✗ dl_download_eps("tiktok_drama", ...) → 同上
  ✗ 拿 TK id 去 pinedrama/dramabox/moboreels 搜 → 那是站点的 slug，不是 TK id

只有 4 个站点支持 slug 下载：pinedrama / dramabox / moboreels / goodshort。
它们用剧名或 slug，跟 TK id 是两套体系。用户给 TK id 就用 dl_tk_eps。

━━━ 完整发布流程 ━━━
1. fs_table / fs_grep 读表，选出剧的 collection_id
2. dl_sd_meta 确认剧名和集数
3. dl_tk_eps 下载指定的 6 集（每部剧都下 6 集）
4. slice_run 切片处理（或 dl_send_to_slice 送进切片队列）
5. 等切片完成（用 dl_task / slice_status 查）
6. publish_reels 发布，指定 pageIds 和每页集数
7. schedule_capacity 先查今日容量，别超发

━━━ 任务清单：多步骤任务必须先建 ━━━
接到「做完 A 再做 B 然后 C」这类任务，**第一步就调 task_create**：

    task_create(items=[
        "下载3部百合剧各6集",
        "切片（mode=auto）",
        "确认成片存在",
        "发布到 Y03",
    ])
    → 返回 planId，记住它

之后每完成一项立刻打勾：
    task_done(planId="plan-xxx", seq=1, note="下载6集成功")

⚠ 系统会检查：清单里有未打勾的项时，**不允许结束回答**。
   你会收到"[系统拦截] 任务还没做完"的提示，必须继续做。
   这是为了防止你只做了一部分就说"完成"。

查进度：task_status(planId="plan-xxx")
全部完成后：可以输出总结，不用手动 clear。

━━━ 下载：先查台账，别重复下 ━━━
下载前先查有没有下过：
    dl_ledger_of(tkId="7672974352903640072")
    → alive=[1,2,3] deleted=[4,5]  ← 4/5 下过但文件被删了

dl_tk_eps 内部也会自动查台账：
    已下过 + 文件在       → 跳过
    已下过 + 文件被删     → 默认也跳过（避免重复下载）
    确实要重下           → dl_tk_eps(..., force=True)

所以正常调用 dl_tk_eps 就够了，它自己会判断，返回体里有
downloaded/skippedAlready 两个数字。

━━━ 遇到信息不足时 ━━━
先用工具查清楚，**能自己查到的不要问用户**。
只有两种情况才问：
  ① 用户的指令本身有歧义（如"随便类型"没说什么类型）
  ② 需要用户做取舍（如"发 6 集"是指每部 6 集还是每主页 6 集）
问的时候要给出你查到的实际情况 + 具体选项，让用户一句话就能答。

回答要简短直接，用中文。不要在没调用工具时编造成片文件路径。"""


def chat(user_msg: str, history: list | None = None,
         auto_run_tools: bool = True, attachments: list | None = None,
         on_progress=None, chat_id: str = "",
         max_rounds: int = 0) -> dict:
    """一轮对话（可能内部跑多次工具）。

    attachments: [{name, kind, path, sizeMb, dataUri?, preview?}]
      图片有 dataUri → 用视觉消息格式塞给模型
      文件有 preview → 把内容摘要拼进提示词

    on_progress: 可选回调 fn(stage, payload)，用于流式推送进度：
      ("thinking", {"round": n})          模型思考中
      ("tool_start", {"tool": name})      开始调工具
      ("tool_end", {"tool": name, "ok": ..., "ms": ...})
      ("reply", {"content": ...})         最终回答
    """
    def _emit(stage, payload=None):
        if on_progress:
            try:
                on_progress(stage, payload or {})
            except Exception:
                pass

    # 新一轮对话：先复位停止标志（上一次的停止不影响这一次）
    clear_stop()

    pk = pick_model()
    if not pk.get("ok"):
        return {"ok": False, "error": pk.get("error"),
                "hint": "先去「雨海 Agent」页接入一个 Agent"}

    endpoint, model, api_key = pk["endpoint"], pk["model"], pk.get("apiKey", "")
    is_ollama = "11434" in endpoint

    # 摘要 + 长期记忆（解决失忆）
    ctx_prefix = ""
    try:
        if chat_id:
            from app.services import agent_context as actx
            ctx = actx.build_context(chat_id, user_msg)
            ctx_prefix = ctx.get("prefix") or ""
            if ctx.get("history") and not history:
                history = ctx["history"]
    except Exception:
        ctx_prefix = ""

    msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
    if ctx_prefix:
        msgs.append({"role": "system", "content": ctx_prefix})
    for h in (history or [])[-8:]:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            msgs.append({"role": h["role"], "content": h["content"]})

    # 附件：图片走 data URI（视觉模型），文件走文本摘要
    atts = attachments or []
    imgs = [a for a in atts if a.get("dataUri")]
    txts = [a for a in atts if not a.get("dataUri")]

    text_msg = user_msg
    if txts:
        parts = []
        for a in txts:
            p = a.get("path") or ""
            nm = a.get("name") or ""
            if a.get("preview"):
                parts.append("[附件] %s（%s）\n内容摘要:\n%s"
                             % (nm, p, a["preview"][:2000]))
            else:
                parts.append("[附件] %s（%s，%sMB）—— 这是本地路径，"
                             "需要时用工具读取"
                             % (nm, p, a.get("sizeMb") or "?"))
        text_msg = "\n\n".join(parts) + "\n\n" + user_msg

    if imgs:
        content = [{"type": "text", "text": text_msg}]
        for a in imgs[:4]:
            content.append({"type": "image_url",
                            "image_url": {"url": a["dataUri"]}})
        msgs.append({"role": "user", "content": content})
    else:
        msgs.append({"role": "user", "content": text_msg})

    tools = tool_specs()
    trace = []
    rounds = 0
    cap_rounds = int(max_rounds) if max_rounds and int(max_rounds) > 0 else MAX_ROUNDS
    # token 用量累计
    usage = {"prompt": 0, "completion": 0, "cached": 0, "total": 0}

    while rounds < cap_rounds:
        rounds += 1
        _emit("thinking", {"round": rounds, "model": model})
        _check_stop()   # 每轮调模型前检查
        r = _post_chat(endpoint, model, msgs, tools, api_key)
        if not r.get("ok"):
            return {"ok": False,
                    "error": f"模型调用失败: {r.get('error')}",
                    "detail": r.get("detail", ""),
                    "agent": pk["agent"], "model": model}

        # 累积 token 用量（网关返回 usage）
        u = (r.get("data") or {}).get("usage") or {}
        if u:
            usage["prompt"] += int(u.get("prompt_tokens") or 0)
            usage["completion"] += int(u.get("completion_tokens") or 0)
            usage["total"] += int(u.get("total_tokens") or 0)
            det = u.get("prompt_tokens_details") or {}
            usage["cached"] += int(det.get("cached_tokens") or 0)

        rep = _parse_reply(r["data"], is_ollama)
        calls = rep.get("tool_calls") or []

        # 没有工具调用 → 可能想结束，但先检查任务清单
        if not calls:
            # ⭐ 强制检查：任务清单里还有未完成项 → 不许结束
            try:
                from app.services import task_plan as _tp
                _pend = _tp.latest_plan()
                if _pend.get("ok") and _pend.get("pending", 0) > 0:
                    _nx = _pend.get("nextPending") or {}
                    _warn = (
                        "[系统拦截] 任务还没做完，不能结束。\n"
                        "进度：%d/%d 已完成，还剩 %d 项。\n"
                        "下一项：seq=%s  %s\n\n"
                        "请继续调用工具完成它，完成后调 "
                        "task_done(planId='%s', seq=%s, note='...')。\n"
                        "全部打勾前不要输出总结性回答。"
                        % (_pend.get("done", 0), _pend.get("total", 0),
                           _pend.get("pending", 0),
                           _nx.get("seq"), _nx.get("title"),
                           _pend.get("planId"), _nx.get("seq")))
                    log.warning("拦截提前结束: %d/%d 未完成",
                                _pend.get("done", 0), _pend.get("total", 0))
                    _emit("warn", {"kind": "unfinished",
                                   "left": _pend.get("pending", 0),
                                   "next": _nx})
                    msgs.append({"role": "user", "content": _warn})
                    trace.append({"round": rounds, "tool": "_intercept",
                                  "args": {}, "ok": True, "ms": 0,
                                  "result": "拦截提前结束，剩余 %d 项"
                                            % _pend.get("pending", 0)})
                    continue        # 再跑一轮，不给结束
            except Exception as _e:
                log.debug("task plan check failed: %s", _e)

            ctxpct = _ctx_pct(usage, model)
            _emit("reply", {"content": rep["content"], "rounds": rounds,
                            "usage": usage, "ctxPct": ctxpct})
            return {"ok": True, "reply": rep["content"],
                    "agent": pk["agent"], "model": model,
                    "rounds": rounds, "trace": trace,
                    "usage": usage, "ctxPct": ctxpct}

        # 有工具调用 → 执行，回灌
        if is_ollama:
            msgs.append({"role": "assistant", "content": rep["content"],
                         "tool_calls": [
                             {"function": {"name": c["name"],
                                           "arguments": c["args"]}}
                             for c in calls]})
        else:
            msgs.append({"role": "assistant",
                         "content": rep["content"] or None,
                         "tool_calls": [
                             {"id": c.get("id") or f"call_{i}",
                              "type": "function",
                              "function": {"name": c["name"],
                                           "arguments": json.dumps(
                                               c["args"], ensure_ascii=False)}}
                             for i, c in enumerate(calls)]})

        for i, c in enumerate(calls):
            _check_stop()   # 每个工具执行前检查
            name, args = c["name"], c["args"]
            _emit("tool_start", {"tool": name, "args": args,
                                  "round": rounds})
            t0 = time.time()
            try:
                res = call_tool(name, args)
                ok = bool(res.get("ok", True))
            except Exception as e:
                res = {"ok": False, "error": str(e)[:150]}
                ok = False
            dt = int((time.time() - t0) * 1000)
            _emit("tool_end", {"tool": name, "ok": ok, "ms": dt,
                                "round": rounds})
            trace.append({"round": rounds, "tool": name, "args": args,
                          "ok": ok, "ms": dt,
                          "result": json.dumps(res, ensure_ascii=False)[:800]})

            payload = json.dumps(res, ensure_ascii=False)

            if is_ollama:
                # ollama 原生支持 tool role
                msgs.append({"role": "tool", "content": payload[:3000]})
            else:
                # OpenAI 兼容网关对 tool role 解析不稳（wire_api=responses 更明显）
                # 用 user 消息注入结果，模型一定能读到
                msgs.append({
                    "role": "user",
                    "content": (f"[工具执行结果] {name}\n"
                                f"参数: {json.dumps(args, ensure_ascii=False)}\n"
                                f"结果:\n{payload[:2500]}\n\n"
                                f"请基于以上真实结果回答用户，不要编造。"),
                })

        if not auto_run_tools:
            return {"ok": True, "needContinue": True,
                    "pendingCalls": calls, "trace": trace,
                    "agent": pk["agent"], "model": model}

    return {"ok": False, "needContinue": True,
            "reply": (f"（已达到 {cap_rounds} 轮工具调用上限，任务未完成。"
                      f"已完成部分见 trace，请让我继续）"),
            "agent": pk["agent"], "model": model,
            "trace": trace, "rounds": rounds}


def quick_test() -> dict:
    """自检：当前 agent 的模型能不能对话。"""
    pk = pick_model()
    if not pk.get("ok"):
        return pk
    r = _post_chat(pk["endpoint"], pk["model"],
                   [{"role": "user", "content": "说'ok'"}], None,
                   pk.get("apiKey", ""))
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error"),
                "detail": r.get("detail", ""),
                "agent": pk["agent"], "model": pk["model"]}
    rep = _parse_reply(r["data"], "11434" in pk["endpoint"])
    return {"ok": bool(rep["content"]), "reply": rep["content"][:60],
            "agent": pk["agent"], "model": pk["model"]}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        print(json.dumps(quick_test(), ensure_ascii=False, indent=1))
    elif len(sys.argv) > 1:
        print(json.dumps(chat(" ".join(sys.argv[1:])),
                         ensure_ascii=False, indent=1))
    else:
        print(json.dumps(quick_test(), ensure_ascii=False, indent=1))
