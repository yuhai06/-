# -*- coding: utf-8 -*-
"""dsh_bridge.py — 在软件内驱动 DSH headless

原理
----
后端 subprocess 启动：
    dsh --profile headless --approval-policy never --json "<任务>"
读它的 NDJSON 输出，翻译成自建 agent 同样的 SSE 事件：
    tool_call   → tool_start
    tool_result → tool_end
    text        → reply
    final       → done

前端复用现有的 Agent 页面，只是换了个"引擎"。

关键点
------
1. DSH 的 --json 是逐行 JSON（NDJSON），不是 SSE
2. 需要 DEEPSEEK_API_KEY 环境变量
3. 支持 --session-id 续跑同一个会话
4. 该进程会加载雨海 MCP，所以能调 116 个工具
"""
from __future__ import annotations

import json
import logging
import os
import queue
import subprocess
import threading
import time
from pathlib import Path

log = logging.getLogger("yuhai.agent.dsh")

# 停止信号
_STOP = threading.Event()
_CUR_PROC: subprocess.Popen | None = None
_LOCK = threading.Lock()

def _find_dsh() -> str:
    """找 dsh 可执行文件。

    Windows 上 dsh 是 .cmd 批处理，subprocess 直接叫 "dsh" 会 WinError 2，
    必须给完整路径（含 .cmd 扩展名）。
    """
    import shutil as _sh
    cands = [
        os.path.expandvars(r"%USERPROFILE%\.local\bin\dsh.cmd"),
        os.path.expandvars(r"%USERPROFILE%\.local\bin\dsh.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\dsh\dsh.cmd"),
        os.path.expandvars(r"%APPDATA%\npm\dsh.cmd"),
    ]
    for c in cands:
        if os.path.isfile(c):
            return c
    # PATH 里找
    for name in ("dsh.cmd", "dsh.exe", "dsh"):
        w = _sh.which(name)
        if w:
            return w
    return "dsh"      # 保底


DSH_BIN = _find_dsh()

# 从 DSH 凭据里读 key
def _api_key() -> str:
    """拿 DEEPSEEK_API_KEY：环境变量优先，其次读 .dsh/.credentials.yaml"""
    k = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if k:
        return k

    # 从 credentials.yaml 抠
    cands = [
        Path.home() / ".dsh" / ".credentials.yaml",
    ]
    for p in cands:
        if not p.exists():
            continue
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
            for ln in txt.split("\n"):
                if "DEEPSEEK_API_KEY:" in ln:
                    v = ln.split(":", 1)[1].strip().strip("'\"")
                    if v:
                        return v
        except Exception as e:
            log.debug("read cred %s: %s", p, e)
    return ""


def available() -> dict:
    """检查 DSH 是否可用。"""
    try:
        r = subprocess.run([DSH_BIN, "--version"], capture_output=True,
                           text=True, timeout=15,
                           creationflags=_no_window())
        ver = (r.stdout or r.stderr or "").strip()[:80]
    except Exception as e:
        return {"ok": False, "error": "找不到 dsh 命令: " + str(e)[:100]}

    key = _api_key()
    prof = Path.home() / ".dsh" / "profiles" / "headless" / "cordis.patch.yml"
    has_mcp = False
    if prof.exists():
        try:
            has_mcp = "mcp-yuhai" in prof.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass

    return {
        "ok": True, "version": ver,
        "hasKey": bool(key), "hasMcpPatch": bool(has_mcp),
        "profile": str(prof),
    }


def _no_window() -> int:
    return 0x08000000 if os.name == "nt" else 0


def request_stop(reason: str = "用户停止") -> dict:
    _STOP.set()
    with _LOCK:
        p = _CUR_PROC
    if p:
        try:
            p.terminate()
            time.sleep(0.4)
            if p.poll() is None:
                p.kill()
        except Exception:
            pass
    log.warning("dsh 停止: %s", reason)
    return {"ok": True, "stopped": True}


def is_stopped() -> bool:
    return _STOP.is_set()


def chat_stream(task: str, session_id: str = "",
                on_event=None, timeout_s: int = 3600) -> dict:
    """跑一次 DSH 任务，逐行解析 --json 输出，回调 on_event。

    on_event(stage, payload)：
      ("session", {"sessionId": ...})
      ("tool_start", {"tool": ..., "args": ...})
      ("tool_end", {"tool": ..., "ok": bool, "ms": int, "result": str})
      ("reply", {"content": ...})
      ("done", {"ok": bool, "reply": ..., "sessionId": ...})
    """
    global _CUR_PROC
    _STOP.clear()

    key = _api_key()
    if not key:
        return {"ok": False, "error": "缺少 DEEPSEEK_API_KEY"}

    env = {**os.environ, "DEEPSEEK_API_KEY": key,
           "PYTHONIOENCODING": "utf-8"}

    cmd = [DSH_BIN, "--profile", "headless",
           "--approval-policy", "never", "--json"]
    if session_id:
        cmd += ["--session-id", session_id]
    cmd.append(task)

    log.info("dsh run: %s", " ".join(cmd[:6]) + " ...")

    def emit(stage, payload=None):
        if on_event:
            try:
                on_event(stage, payload or {})
            except Exception:
                pass

    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            bufsize=1, env=env,
            creationflags=_no_window())
    except Exception as e:
        return {"ok": False, "error": "启动 dsh 失败: " + str(e)[:150]}

    with _LOCK:
        _CUR_PROC = proc

    # 工具调用记录：callId → {name, t0}
    pending = {}
    final_text = ""
    new_sid = session_id
    ok = False
    error = ""
    got_final = False

    t_start = time.time()

    try:
        for raw in proc.stdout:  # type: ignore
            if _STOP.is_set():
                break
            if time.time() - t_start > timeout_s:
                error = "超时"
                try:
                    proc.kill()
                except Exception:
                    pass
                break

            line = (raw or "").strip()
            if not line.startswith("{"):
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue

            t = ev.get("type")

            if t == "session":
                new_sid = ev.get("sessionId") or new_sid
                emit("session", {"sessionId": new_sid})

            elif t == "thinking":
                txt = ev.get("text") or ""
                if txt:
                    emit("thinking", {"text": txt[:2000]})

            elif t == "tool_call":
                cid = ev.get("callId") or ""
                name = (ev.get("tool") or "").replace("mcp__yuhai__", "")
                args = ev.get("input") or {}
                pending[cid] = {"name": name, "t0": time.time()}
                emit("tool_start", {"tool": name, "args": args,
                                    "callId": cid})

            elif t == "tool_result":
                cid = ev.get("callId") or ""
                rec = pending.pop(cid, {})
                name = rec.get("name", "?")
                ms = int((time.time() - rec.get("t0", time.time())) * 1000)
                res = ev.get("result")
                if isinstance(res, (dict, list)):
                    res = json.dumps(res, ensure_ascii=False)
                res = str(res or "")
                good = ev.get("status") != "failed"
                emit("tool_end", {"tool": name, "ok": good,
                                  "ms": ms, "result": res[:4000],
                                  "callId": cid})

            elif t == "text":
                txt = ev.get("text") or ""
                if txt:
                    emit("reply", {"content": txt})

            elif t == "final":
                final_text = ev.get("text") or final_text
                new_sid = ev.get("sessionId") or new_sid
                reason = (ev.get("reason") or {}).get("kind") or ""
                ok = reason in ("completed", "", "success")
                emit("done", {"ok": ok, "reply": final_text,
                              "sessionId": new_sid, "reason": reason})
                # ⚠ 关键：收到 final 立即退出读循环。
                #   dsh 发完 final 后进程不一定马上退出，
                #   for raw in proc.stdout 会一直等 EOF → 整个调用卡死。
                got_final = True
                break

            elif t == "error":
                error = str(ev.get("text") or ev.get("error") or "")[:300]

    except Exception as e:
        error = "%s: %s" % (type(e).__name__, str(e)[:150])
    finally:
        with _LOCK:
            _CUR_PROC = None

        # 关掉管道，防止子进程写满缓冲区卡住
        for _p in ("stdout", "stderr"):
            try:
                f = getattr(proc, _p, None)
                if f:
                    f.close()
            except Exception:
                pass

        # ⚠ 关键：先让进程退出，再读 stderr。
        #   直接 proc.stderr.read() 会阻塞到 EOF —— 子进程还活着时永远等不到，
        #   导致 worker 线程卡死、SSE 流不关闭、前端一直"正在思考"。
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        pass
        except Exception:
            pass

        # 进程已退出，这时读 stderr 不会阻塞；再套一层超时兜底
        err = ""
        if proc.stderr:
            try:
                import threading as _th
                box = {}

                def _rd():
                    try:
                        box["v"] = proc.stderr.read() or ""
                    except Exception:
                        box["v"] = ""

                t = _th.Thread(target=_rd, daemon=True)
                t.start()
                t.join(timeout=2.0)
                err = (box.get("v") or "").strip()
            except Exception:
                err = ""

        if err and not final_text:
            for ln in err.split("\n"):
                if any(k in ln for k in ("Error", "error", "MISSING",
                                          "not found", "failed")):
                    error = error or ln.strip()[:250]
                    break

    if _STOP.is_set():
        return {"ok": False, "stopped": True, "error": "已停止",
                "reply": final_text, "sessionId": new_sid}

    if not ok and not final_text and error:
        return {"ok": False, "error": error, "sessionId": new_sid}

    return {"ok": True, "reply": final_text, "sessionId": new_sid,
            "elapsed": round(time.time() - t_start, 1)}
