# -*- coding: utf-8 -*-
"""task_plan.py — Agent 任务清单

解决的核心问题
--------------
agent 会在任务没做完时就说"完成"，然后结束。
例：7 部剧只切了 3 部，回复"3/7 ✅"就 DONE。

机制
----
① 用户发任务后，agent 必须先调 task_plan_create 拆成待办项
② 每完成一项调 task_plan_done 打勾
③ 系统检查：还有没打勾的项 → 不让结束（返回 needContinue）
④ 清单持久化到 DB，会话中断后能接着做

表
--
agent_tasks(
    id          INTEGER PRIMARY KEY,
    plan_id     TEXT,      -- 一个任务计划
    seq         INTEGER,   -- 顺序
    title       TEXT,      -- 待办内容
    done        INTEGER,   -- 0/1
    note        TEXT,      -- 完成说明
    created_at  TEXT,
    done_at     TEXT
)
"""
from __future__ import annotations

import logging
import uuid

from app.db import db, now_iso

log = logging.getLogger("yuhai.agent.tasks")


def _ensure_table() -> None:
    try:
        db.exec("""CREATE TABLE IF NOT EXISTS agent_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plan_id TEXT NOT NULL,
            seq INTEGER NOT NULL,
            title TEXT NOT NULL,
            done INTEGER DEFAULT 0,
            note TEXT DEFAULT '',
            created_at TEXT,
            done_at TEXT
        )""")
    except Exception as e:
        log.debug("ensure tasks table: %s", e)


def create(items: list[str], plan_id: str = "") -> dict:
    """创建任务清单。items 是待办项列表。"""
    _ensure_table()
    pid = plan_id or ("plan-" + uuid.uuid4().hex[:10])
    ts = now_iso()
    for i, title in enumerate(items, 1):
        t = (title or "").strip()
        if not t:
            continue
        db.exec(
            "INSERT INTO agent_tasks(plan_id,seq,title,done,note,"
            "created_at) VALUES(?,?,?,0,'',?)",
            (pid, i, t[:200], ts))
    return {"ok": True, "planId": pid, "count": len(items)}


def done(plan_id: str, seq: int = 0, keyword: str = "",
         note: str = "") -> dict:
    """标记某一项完成。seq 优先，没给 seq 就用 keyword 模糊匹配。"""
    _ensure_table()
    if seq:
        db.exec("UPDATE agent_tasks SET done=1, note=?, done_at=? "
                "WHERE plan_id=? AND seq=?",
                (note[:200], now_iso(), plan_id, int(seq)))
        return {"ok": True, "planId": plan_id, "seq": seq}
    if keyword:
        rows = db.q(
            "SELECT id, seq, title FROM agent_tasks "
            "WHERE plan_id=? AND done=0 AND title LIKE ? LIMIT 1",
            (plan_id, "%" + keyword + "%"))
        if rows:
            r = rows[0]
            db.exec("UPDATE agent_tasks SET done=1, note=?, done_at=? "
                    "WHERE id=?", (note[:200], now_iso(), r["id"]))
            return {"ok": True, "planId": plan_id, "seq": r["seq"],
                    "title": r["title"]}
        return {"ok": False, "error": "没找到匹配的待办项: " + keyword}
    return {"ok": False, "error": "需要 seq 或 keyword"}


def status(plan_id: str) -> dict:
    """查清单进度。"""
    _ensure_table()
    rows = db.q(
        "SELECT seq, title, done, note FROM agent_tasks "
        "WHERE plan_id=? ORDER BY seq", (plan_id,))
    total = len(rows)
    finished = sum(1 for r in rows if r["done"])
    pending = [{"seq": r["seq"], "title": r["title"]}
               for r in rows if not r["done"]]
    return {
        "ok": True,
        "planId": plan_id,
        "total": total,
        "done": finished,
        "pending": len(pending),
        "allDone": total > 0 and finished == total,
        "items": [dict(r) for r in rows],
        "nextPending": pending[0] if pending else None,
    }


def latest_plan() -> dict:
    """最近一个未完成的计划（用于续跑）。"""
    _ensure_table()
    rows = db.q(
        "SELECT plan_id, COUNT(*) AS total, "
        "SUM(done) AS finished, MAX(created_at) AS ts "
        "FROM agent_tasks GROUP BY plan_id "
        "ORDER BY ts DESC LIMIT 5")
    for r in rows:
        if (r["finished"] or 0) < (r["total"] or 0):
            return status(r["plan_id"])
    return {"ok": False, "error": "没有未完成的计划"}


def clear(plan_id: str) -> dict:
    _ensure_table()
    db.exec("DELETE FROM agent_tasks WHERE plan_id=?", (plan_id,))
    return {"ok": True, "planId": plan_id}
