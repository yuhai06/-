# -*- coding: utf-8 -*-
"""mcp_fs.py — 文件系统工具（让 Agent 读写本机文件）

安全边界
--------
· 读：允许用户盘符下的常见目录（不锁死在项目内，用户需要读电脑上的文件）
· 写：同样允许，但限制单次 5MB
· 拒绝：Windows / Program Files / ProgramData 等系统保护目录
· 上限：单次读 2MB、写 5MB、列目录 500 项，防炸内存
"""
from __future__ import annotations

import logging
import shutil
import string
from pathlib import Path

log = logging.getLogger("yuhai.mcp.fs")

READ_LIMIT = 2 * 1024 * 1024      # 2MB
WRITE_LIMIT = 5 * 1024 * 1024     # 5MB
LIST_LIMIT = 500
FIND_LIMIT = 200

_BLOCKED = (
    "c:\\windows",
    "c:\\program files",
    "c:\\program files (x86)",
    "c:\\programdata",
    "c:\\$recycle.bin",
    "c:\\system volume information",
    "c:\\recovery",
    "c:\\perflogs",
)


def _norm(path: str) -> Path:
    """规范化路径并做安全校验。"""
    if path is None or not str(path).strip():
        raise ValueError("路径为空")
    raw = str(path).strip().strip('"').strip("'")
    p = Path(raw)
    try:
        p = p.expanduser()
    except Exception:
        pass
    low = str(p).lower().replace("/", "\\")
    for b in _BLOCKED:
        if low == b or low.startswith(b + "\\"):
            raise PermissionError("该目录受系统保护，已拒绝: " + str(p))
    return p


def register(mcp) -> None:
    """把所有文件工具注册到 mcp 实例。"""

    @mcp.tool(description="读文件。path=绝对路径；maxKb=最多读多少KB(默认200，上限2048)")
    def fs_read(path: str, maxKb: int = 200) -> dict:
        """读取本机文本文件内容。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "文件不存在: " + str(p)}
            if p.is_dir():
                return {"ok": False, "error": "这是目录，请用 fs_list: " + str(p)}
            size = p.stat().st_size
            cap = min(max(int(maxKb or 200) * 1024, 1024), READ_LIMIT)
            with open(p, "rb") as f:
                head = f.read(8192)
                is_binary = b"\x00" in head
                f.seek(0)
                raw = f.read(cap)
            if is_binary:
                return {"ok": True, "path": str(p), "size": size,
                        "binary": True, "truncated": size > cap,
                        "note": "二进制文件，未返回内容"}
            text = raw.decode("utf-8", errors="replace")
            return {"ok": True, "path": str(p), "size": size,
                    "bytesRead": len(raw), "truncated": size > cap,
                    "content": text}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="列目录。path=目录；pattern=通配符(可选如 *.txt)；limit=最多多少项(默认200)")
    def fs_list(path: str, pattern: str = "", limit: int = 200) -> dict:
        """列出目录内容（含类型/大小/修改时间）。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "目录不存在: " + str(p)}
            if not p.is_dir():
                return {"ok": False, "error": "不是目录: " + str(p)}
            cap = min(max(int(limit or 200), 1), LIST_LIMIT)
            it = p.glob(pattern) if pattern else p.iterdir()
            items = []
            for f in it:
                if len(items) >= cap:
                    break
                try:
                    st = f.stat()
                    items.append({
                        "name": f.name,
                        "path": str(f),
                        "dir": f.is_dir(),
                        "size": 0 if f.is_dir() else st.st_size,
                        "mtime": int(st.st_mtime),
                    })
                except (PermissionError, OSError):
                    continue
            items.sort(key=lambda x: (not x["dir"], x["name"].lower()))
            return {"ok": True, "path": str(p), "count": len(items),
                    "truncated": len(items) >= cap, "items": items}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="搜索文件。root=根目录；name=文件名片段或通配符；maxDepth=最大深度(默认4)")
    def fs_find(root: str, name: str, maxDepth: int = 4) -> dict:
        """在目录树里按文件名查找。"""
        try:
            base = _norm(root)
            if not base.is_dir():
                return {"ok": False, "error": "根目录无效: " + str(base)}
            want = (name or "").strip()
            if not want:
                return {"ok": False, "error": "name 不能为空"}
            depth_cap = max(1, min(int(maxDepth or 4), 8))
            base_depth = len(base.parts)
            use_glob = "*" in want or "?" in want
            lw = want.lower()
            hits = []
            for f in base.rglob("*"):
                try:
                    if len(f.parts) - base_depth > depth_cap:
                        continue
                    matched = f.match(want) if use_glob else (lw in f.name.lower())
                    if not matched:
                        continue
                    st = f.stat()
                    hits.append({"name": f.name, "path": str(f), "dir": f.is_dir(),
                                 "size": 0 if f.is_dir() else st.st_size})
                    if len(hits) >= FIND_LIMIT:
                        break
                except (PermissionError, OSError):
                    continue
            return {"ok": True, "root": str(base), "count": len(hits),
                    "truncated": len(hits) >= FIND_LIMIT, "items": hits}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="写文件。path=绝对路径；content=内容；append=true时追加（不覆盖）。上限5MB")
    def fs_write(path: str, content: str, append: bool = False) -> dict:
        """写入文本文件，自动创建父目录。"""
        try:
            p = _norm(path)
            data = (content or "").encode("utf-8")
            if len(data) > WRITE_LIMIT:
                return {"ok": False,
                        "error": "内容超过 5MB 上限（%.1fMB）" % (len(data) / 1048576)}
            p.parent.mkdir(parents=True, exist_ok=True)
            mode = "ab" if append else "wb"
            with open(p, mode) as f:
                f.write(data)
            return {"ok": True, "path": str(p), "bytes": len(data),
                    "mode": "append" if append else "overwrite",
                    "size": p.stat().st_size}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description="查看各磁盘剩余空间")
    def fs_disks() -> dict:
        """列出所有盘符与容量。"""
        out = []
        for letter in string.ascii_uppercase:
            root = letter + ":\\"
            try:
                total, used, free = shutil.disk_usage(root)
                out.append({
                    "drive": letter, "path": root,
                    "totalGb": round(total / 1073741824, 1),
                    "usedGb": round(used / 1073741824, 1),
                    "freeGb": round(free / 1073741824, 1),
                })
            except (OSError, FileNotFoundError):
                continue
        return {"ok": True, "count": len(out), "drives": out}

    @mcp.tool(description="查看文件信息（大小/时间/是否存在），不解包内容")
    def fs_stat(path: str) -> dict:
        """查看单个路径的元信息。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": True, "exists": False, "path": str(p)}
            st = p.stat()
            return {"ok": True, "exists": True, "path": str(p),
                    "dir": p.is_dir(), "size": st.st_size,
                    "mtime": int(st.st_mtime),
                    "ext": p.suffix.lower()}
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description=(
        "在文件里搜索文本（grep）。path=文件路径；pattern=关键词或正则；"
        "ignoreCase=忽略大小写(默认true)；maxHits=最多返回多少行(默认100)；"
        "col=只搜第几列(0基，TSV/CSV用，-1=整行)。大文件也能全量扫，不受读上限限制"))
    def fs_grep(path: str, pattern: str, ignoreCase: bool = True,
                maxHits: int = 100, col: int = -1) -> dict:
        """全文搜索（自动扫完整个文件，不受 fs_read 的 200KB 限制）。"""
        import re as _re
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "文件不存在: " + str(p)}
            if p.is_dir():
                return {"ok": False, "error": "这是目录，请用 fs_find"}
            if not (pattern or "").strip():
                return {"ok": False, "error": "pattern 不能为空"}

            flags = _re.IGNORECASE if ignoreCase else 0
            try:
                rx = _re.compile(pattern, flags)
            except _re.error:
                # 正则非法 → 当纯文本处理
                rx = _re.compile(_re.escape(pattern), flags)

            cap = max(1, min(int(maxHits or 100), 2000))
            hits = []
            total_lines = 0
            scanned = 0
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                for ln_no, line in enumerate(f, 1):
                    total_lines += 1
                    scanned += len(line)
                    target = line
                    if col is not None and int(col) >= 0:
                        parts = line.rstrip("\n").split("\t")
                        if len(parts) <= int(col):
                            continue
                        target = parts[int(col)]
                    if rx.search(target):
                        hits.append({
                            "line": ln_no,
                            "text": line.rstrip("\n")[:500],
                        })
                        if len(hits) >= cap:
                            # 继续统计总数但不再存
                            pass
            return {
                "ok": True, "path": str(p),
                "pattern": pattern, "col": col,
                "hitCount": len(hits),
                "truncated": len(hits) >= cap,
                "totalLines": total_lines,
                "bytesScanned": scanned,
                "hits": hits[:cap],
            }
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description=(
        "分段读大文件。path=文件；offset=起始字节(默认0)；"
        "maxKb=本次读多少KB(默认500，上限4096)。返回 nextOffset 供继续读"))
    def fs_read_chunk(path: str, offset: int = 0, maxKb: int = 500) -> dict:
        """按字节偏移分段读，适合几百KB以上的大文件。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "文件不存在: " + str(p)}
            if p.is_dir():
                return {"ok": False, "error": "这是目录"}
            size = p.stat().st_size
            off = max(0, int(offset or 0))
            if off >= size:
                return {"ok": True, "path": str(p), "size": size,
                        "offset": off, "eof": True, "content": "",
                        "nextOffset": None}
            cap = max(1024, min(int(maxKb or 500) * 1024, 4 * 1024 * 1024))
            with open(p, "rb") as f:
                f.seek(off)
                raw = f.read(cap)
            # 尽量在换行处截断，避免切坏一行
            if off + len(raw) < size:
                cut = raw.rfind(b"\n")
                if cut > 0:
                    raw = raw[:cut + 1]
            text = raw.decode("utf-8", errors="replace")
            next_off = off + len(raw)
            return {
                "ok": True, "path": str(p), "size": size,
                "offset": off, "bytesRead": len(raw),
                "eof": next_off >= size,
                "nextOffset": None if next_off >= size else next_off,
                "content": text,
            }
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    @mcp.tool(description=(
        "读分隔符表格（TSV/CSV）。path=文件；sep=分隔符(默认\\t)；"
        "limit=最多多少行(默认500，上限5000)；offset=跳过前几行；"
        "columns=只取这几列(逗号分隔的列名或索引)；filter=只返回包含该文本的行"))
    def fs_table(path: str, sep: str = "\t", limit: int = 500,
                 offset: int = 0, columns: str = "",
                 filter: str = "") -> dict:
        """把 TSV/CSV 读成结构化行，agent 可以直接按列分析。"""
        try:
            p = _norm(path)
            if not p.exists():
                return {"ok": False, "error": "文件不存在: " + str(p)}
            sep = sep if sep else "\t"
            cap = max(1, min(int(limit or 500), 5000))
            skip = max(0, int(offset or 0))
            want_cols = [c.strip() for c in (columns or "").split(",") if c.strip()]
            flt = (filter or "").strip().lower()

            with open(p, "r", encoding="utf-8", errors="replace") as f:
                header_line = f.readline().rstrip("\n")
                header = header_line.split(sep)
                ncol = len(header)

                # 解析要取的列索引
                idxs = list(range(ncol))
                if want_cols:
                    idxs = []
                    for wc in want_cols:
                        if wc.isdigit() and int(wc) < ncol:
                            idxs.append(int(wc))
                        elif wc in header:
                            idxs.append(header.index(wc))

                rows = []
                total = 0
                for ln in f:
                    if not ln.strip():
                        continue
                    total += 1
                    if total <= skip:
                        continue
                    if flt and flt not in ln.lower():
                        continue
                    parts = ln.rstrip("\n").split(sep)
                    row = {}
                    for i in idxs:
                        name = header[i] if i < ncol else ("col%d" % i)
                        row[name] = (parts[i] if i < len(parts) else "")
                    rows.append(row)
                    if len(rows) >= cap:
                        break

            return {
                "ok": True, "path": str(p),
                "sep": sep, "columns": header,
                "rowCount": len(rows),
                "totalDataRows": total,
                "truncated": len(rows) >= cap,
                "rows": rows,
            }
        except PermissionError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}

    log.info("mcp_fs registered (9 tools)")
