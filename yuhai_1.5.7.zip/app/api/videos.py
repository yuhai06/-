"""视频数据 API（推广矩阵形态）。

数据粒度：**单条视频**（unit），不是剧、不是主页。
一次发布 = 一个 unit，可跨任意题材；剧目只是可选标签。
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.db import db, now_iso

log = logging.getLogger("yuhai.api.videos")
router = APIRouter(tags=["videos"])


# ---------------- 视频列表 ----------------
@router.get("/videos")
async def list_videos(page_id: str = "", state: str = "all", q: str = "",
                      days: int = Query(0, ge=0, le=3650), limit: int = 500):
    """视频列表。days=0（默认）返回**全部**；>0 时才按天数过滤。"""
    sql = """SELECT u.*, p.name AS page_name
             FROM units u LEFT JOIN pages p ON p.page_id = u.page_id
             WHERE 1=1"""
    params: list[Any] = []
    if page_id:
        sql += " AND u.page_id=?"
        params.append(page_id)
    if state != "all":
        sql += " AND u.state=?"
        params.append(state)
    if q:
        sql += " AND (u.title LIKE ? OR u.post_id LIKE ? OR u.tags LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    # days=0 → 不限制时间，返回全部
    # 兼容旧行为：解析不出 published_date 时退回 created_at
    if days and days > 0:
        since = (date.today() - timedelta(days=days)).isoformat()
        sql += (" AND (COALESCE(NULLIF(u.published_date,''), "
                "substr(u.created_at,1,10)) >= ?)")
        params.append(since)
    sql += " ORDER BY COALESCE(NULLIF(u.published_date,''), substr(u.created_at,1,10)) DESC, u.created_at DESC LIMIT ?"
    params.append(min(limit, 2000))
    rows = db.q(sql, params)

    out = []
    today = date.today().isoformat()
    for r in rows:
        m = db.q1("SELECT * FROM unit_metrics WHERE unit_id=? AND date=?",
                  (r["id"], today)) or {}
        m0 = db.q1(
            "SELECT * FROM unit_metrics WHERE unit_id=? ORDER BY date ASC LIMIT 1",
            (r["id"],)) or {}
        growth = 0
        if m0.get("plays") and m.get("plays"):
            growth = round((m["plays"] - m0["plays"]) / max(1, m0["plays"]) * 100, 1)
        out.append({
            "id": r["id"],
            "postId": r["post_id"],
            "pageId": r["page_id"],
            "pageName": r["page_name"],
            "assetId": r["asset_id"],
            "title": r["title"] or "",
            "tags": json.loads(r["tags"] or "[]") if r["tags"] else [],
            "publishedAt": r["published_at"],
            "publishedDate": r.get("published_date") or "",
            "state": r["state"],
            "tracker": r["tracker"],
            "metrics": {
                "plays": m.get("plays") or 0,
                "reach": m.get("reach") or 0,
                "reactions": m.get("reactions") or 0,
                "comments": m.get("comments") or 0,
                "shares": m.get("shares") or 0,
                "saves": m.get("saves") or 0,
                "avgWatch": m.get("avg_watch") or 0,
                "completion": m.get("completion") or 0,
                "clicks": m.get("clicks") or 0,
            },
            "firstPlays": m0.get("plays") or 0,
            "growthPct": growth,
            "collectedAt": m.get("collected_at"),
        })
    return {"items": out, "count": len(out)}


# ---------------- 单条视频详情 ----------------
@router.get("/videos/{unit_id}")
async def video_detail(unit_id: str):
    r = db.q1("SELECT u.*, p.name AS page_name FROM units u "
              "LEFT JOIN pages p ON p.page_id=u.page_id WHERE u.id=?", (unit_id,))
    if not r:
        raise HTTPException(404, "视频不存在")
    series = db.q(
        "SELECT date,plays,reach,reactions,comments,shares,clicks,completion "
        "FROM unit_metrics WHERE unit_id=? ORDER BY date", (unit_id,))
    total = db.q1(
        "SELECT MAX(plays) plays, MAX(reach) reach, MAX(reactions) reactions,"
        " MAX(comments) comments, MAX(shares) shares, MAX(clicks) clicks "
        "FROM unit_metrics WHERE unit_id=?", (unit_id,)) or {}
    return {
        "id": r["id"], "postId": r["post_id"], "pageId": r["page_id"],
        "pageName": r["page_name"], "title": r["title"],
        "publishedAt": r["published_at"],
        "publishedDate": r.get("published_date") or "",
        "state": r["state"],
        "tracker": r["tracker"],
        "series": series,
        "total": {k: v or 0 for k, v in total.items()},
    }


# ---------------- 汇总 ----------------
@router.get("/videos/summary/overview")
async def overview(days: int = Query(14, ge=1, le=90)):
    """矩阵总览：按天聚合 + 分主页 + Top 视频。"""
    since = (date.today() - timedelta(days=days)).isoformat()
    daily = db.q(
        "SELECT date, SUM(plays) plays, SUM(reach) reach, SUM(reactions) reactions,"
        " SUM(comments) comments, SUM(shares) shares, SUM(clicks) clicks,"
        " COUNT(DISTINCT unit_id) videos"
        " FROM unit_metrics WHERE date>=? GROUP BY date ORDER BY date", (since,))

    by_page = db.q(
        """SELECT p.page_id, p.name, p.health,
                  COUNT(DISTINCT u.id) videos,
                  COALESCE(SUM(m.plays),0) plays,
                  COALESCE(SUM(m.clicks),0) clicks
           FROM pages p
           LEFT JOIN units u ON u.page_id = p.page_id
           LEFT JOIN unit_metrics m ON m.unit_id = u.id AND m.date>=?
           GROUP BY p.page_id ORDER BY plays DESC""", (since,))

    top = db.q(
        """SELECT u.id, u.title, u.post_id, p.name AS page_name,
                  MAX(m.plays) plays, MAX(m.reactions) reactions,
                  MAX(m.clicks) clicks
           FROM units u
           LEFT JOIN pages p ON p.page_id=u.page_id
           JOIN unit_metrics m ON m.unit_id=u.id
           WHERE m.date>=?
           GROUP BY u.id ORDER BY plays DESC LIMIT 20""", (since,))

    totals = db.q1(
        "SELECT COALESCE(SUM(plays),0) plays, COALESCE(SUM(reach),0) reach,"
        " COALESCE(SUM(reactions),0) reactions, COALESCE(SUM(clicks),0) clicks"
        " FROM unit_metrics WHERE date>=?", (since,)) or {}

    return {
        "days": days,
        "daily": daily,
        "byPage": by_page,
        "topVideos": top,
        "totals": totals,
        "videoCount": db.q1("SELECT COUNT(*) c FROM units WHERE state='published'")["c"],
    }


# ---------------- 手动录入指标 ----------------
class MetricsReq(BaseModel):
    unitId: str
    date: str = ""
    plays: int | None = None
    reach: int | None = None
    reactions: int | None = None
    comments: int | None = None
    shares: int | None = None
    clicks: int | None = None
    note: str = ""


# ---------------- 发布前预览：随机链接 + 随机标题 ----------------
class PreviewReq(BaseModel):
    pageIds: list[str]
    reference: str = ""
    titleCount: int = 5
    model: str = ""


@router.post("/videos/preview-captions")
async def preview_captions(req: PreviewReq):
    """给每个主页预览：这次会用哪个链接、哪个标题。

    链接与标题都从池里随机取，且避开最近用过的。
    """
    from app.services import caption
    out = []
    for pid in req.pageIds:
        p = db.q1("SELECT name,asset_id FROM pages WHERE page_id=?", (pid,))
        link = caption.pick_link(pid)
        cap = caption.pick_caption(pid, req.reference)
        out.append({
            "pageId": pid,
            "pageName": (p or {}).get("name") or pid,
            "hasAsset": bool((p or {}).get("asset_id")),
            "link": {"id": link["id"], "label": link["label"],
                     "url": link["url"]} if link else None,
            "title": cap.get("title"),
            "titleSource": cap.get("source"),
            "titleId": cap.get("titleId"),
            "poolSize": db.q1(
                "SELECT COUNT(*) c FROM title_pool WHERE page_id=? AND enabled=1",
                (pid,))["c"],
            "linkCount": len([x for x in caption.list_links(pid) if x["enabled"]]),
        })
    return {"items": out, "reference": req.reference or caption.REFERENCE_TITLE}


@router.post("/videos/metrics")
async def set_metrics(req: MetricsReq):
    r = db.q1("SELECT * FROM units WHERE id=?", (req.unitId,))
    if not r:
        raise HTTPException(404, "视频不存在")
    d = req.date or date.today().isoformat()
    cur = db.q1("SELECT * FROM unit_metrics WHERE unit_id=? AND date=?",
                (req.unitId, d)) or {}
    vals = {
        "plays": req.plays if req.plays is not None else cur.get("plays", 0),
        "reach": req.reach if req.reach is not None else cur.get("reach", 0),
        "reactions": req.reactions if req.reactions is not None else cur.get("reactions", 0),
        "comments": req.comments if req.comments is not None else cur.get("comments", 0),
        "shares": req.shares if req.shares is not None else cur.get("shares", 0),
        "clicks": req.clicks if req.clicks is not None else cur.get("clicks", 0),
    }
    db.exec(
        "INSERT INTO unit_metrics(unit_id,date,plays,reach,reactions,comments,shares,"
        "clicks,collected_at,source) VALUES(?,?,?,?,?,?,?,?,?,'manual')"
        " ON CONFLICT(unit_id,date) DO UPDATE SET plays=excluded.plays,"
        " reach=excluded.reach, reactions=excluded.reactions,"
        " comments=excluded.comments, shares=excluded.shares, clicks=excluded.clicks,"
        " collected_at=excluded.collected_at, source='manual'",
        (req.unitId, d, vals["plays"], vals["reach"], vals["reactions"],
         vals["comments"], vals["shares"], vals["clicks"], now_iso()))
    return {"ok": True, "date": d}


# ---------------- 触发采集 ----------------
class CollectReq(BaseModel):
    pageIds: list[str] = []
    envCode: str = ""
    useGraphApi: bool = True
    windowDays: int = 0         # 0=全部；>0 时才限制最近 N 天


@router.post("/videos/collect")
async def collect(req: CollectReq):
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的发布号环境，先启动再采集")

    token = ""
    if req.useGraphApi:
        integ = db.q1("SELECT * FROM integrations WHERE id='graph'")
        if integ:
            try:
                token = (json.loads(integ["config"] or "{}")).get("token", "")
            except Exception:
                token = ""

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{len(req.pageIds) or '全部'} 个主页", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "metrics",
             (f"采集最近 {req.windowDays} 天视频数据"
              if req.windowDays else "采集全部视频数据"), "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run(job_id, env, req, token))
    return {"ok": True, "jobId": job_id, "usedGraphApi": bool(token),
            "windowDays": req.windowDays}


async def _run(job_id: str, env: dict, req: CollectReq, token: str) -> None:
    from app.services import metrics as mx
    try:
        res = await mx.collect_all(env["container_code"], int(env["cdp_port"]),
                                   token=token, page_ids=req.pageIds or None,
                                   window_days=req.windowDays)
        status = "blocked" if res["guard"] else ("done" if not res["error"] else "blocked")
        db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? WHERE id=?",
                (status, json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok" if not res["guard"] else "warn", "metrics",
                     f"采集完成 入库 {res['saved']} · 超窗跳过 {res['skippedOutWindow']} "
                     f"· guard={res['guard']} · err={res['error']}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "metrics", str(e)[:200])


# ---------------- 标签（替代剧名） ----------------
class TagReq(BaseModel):
    unitId: str
    tags: list[str]


@router.post("/videos/tags")
async def set_tags(req: TagReq):
    db.exec("UPDATE units SET tags=? WHERE id=?",
            (json.dumps(req.tags, ensure_ascii=False), req.unitId))
    return {"ok": True}
