"""发布 API：唯一入口是 /publish/orders。

旧链路（/publish 的逐条直发）保留为兼容壳，内部转调新编排层，
但前端不再使用它 —— 见 publish_engine.py 文件头说明。

端点
----
GET  /publish/sources          内部数据概览（素材/主页/标题/链接池）
POST /publish/preview          只算文案与分配，不落库（发布前预览）
POST /publish/orders           创建订单并启动
GET  /publish/orders           订单列表
GET  /publish/orders/{id}      订单详情（含每条明细）
POST /publish/orders/{id}/cancel   取消
POST /publish/orders/{id}/resolve  判定结果不确定的明细
GET  /publish/orders/{id}/events   SSE 实时进度
POST /publish/orders/{id}/retry-failed  只重试失败项
"""
from __future__ import annotations

import asyncio
import json
import logging
import shutil
import uuid
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.db import db, now_iso
from app.services import publish_engine as pe

log = logging.getLogger("yuhai.api.publish")
router = APIRouter(tags=["publish"])

# 运行中的订单（order_id -> asyncio.Task），用于真取消
RUNNING: dict[str, object] = {}   # 存 Thread（发布跑独立线程，见 create_order）


def _guard(fn):
    """把 PublishError / IntegrityError 翻成 4xx，别让用户看到 500。

    旧实现的裸异常会走 main.py 的全局 handler 变成 500「unhandled error」，
    前端只能显示一句英文堆栈，无法定位是哪条规则没过。
    """
    import functools

    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        from sqlite3 import IntegrityError
        try:
            return await fn(*args, **kwargs)
        except HTTPException:
            raise
        except pe.PublishError as e:
            raise HTTPException(400, str(e))
        except IntegrityError as e:
            msg = str(e)
            if "publish_orders.idem_key" in msg:
                raise HTTPException(409, "相同内容的发布订单已存在，"
                                         "请打开历史订单继续，或调整素材/主页后再提交")
            raise HTTPException(400, f"数据冲突：{msg[:160]}")
        except ValueError as e:
            raise HTTPException(400, str(e))

    return wrapper


# ─────────────────────────────────────────────────────────────
# 概览
# ─────────────────────────────────────────────────────────────

def _pick(row, key: str):
    """从 sqlite row 里取一个可能不存在的列（不同版本 schema 不一样）。"""
    try:
        return row[key]
    except (KeyError, IndexError):
        return None


def _auth_users_of(page_id: str) -> list[dict]:
    """该主页的授权账号列表（详情弹窗里的「授权」区块）。

    表结构不同版本不一致：优先 page_authz，退回 authz 表；
    两处都没有就返回空列表，前端显示"未获取到授权信息"。
    """
    for table, cols in (
        ("page_authz", "c_user, status, level, checked_at"),
        ("authz", "c_user, status, level, checked_at"),
    ):
        try:
            rows = db.q(
                f"SELECT {cols} FROM {table} WHERE page_id=? "
                f"ORDER BY status DESC", (page_id,))
            if rows:
                return [{
                    "cUser": r["c_user"] or "",
                    "status": r["status"] or "",
                    "level": r["level"] or "",
                    "checkedAt": r["checked_at"] or "",
                } for r in rows]
        except Exception:
            continue
    return []


@router.get("/publish/sources")
async def sources(group: str = "publish"):
    """发布页需要知道的全部内部数据现状（一次请求拿齐）。

    group: 'publish'（默认，只返回发布号分组）| 'auth' | 'all'

    注意：library.ready 是"库里标记为 ready 的行数"，
    library.usable 才是"真正能发的条数"（文件存在 + 未混剪 + 版权 OK）。
    界面上要显示 usable，否则会出现"显示 8 条却提示素材不足"。
    """
    lib = db.q1(
        """SELECT
             COUNT(*) AS total,
             SUM(CASE WHEN state='ready' THEN 1 ELSE 0 END) AS ready,
             SUM(CASE WHEN state='used' THEN 1 ELSE 0 END) AS used,
             SUM(CASE WHEN kind='mix' THEN 1 ELSE 0 END) AS mix
           FROM library""") or {}
    q = db.q1("SELECT COUNT(*) AS total FROM queue WHERE state='ready'") or {}
    pg = db.q1(
        """SELECT COUNT(*) AS total,
                  SUM(CASE WHEN asset_id IS NOT NULL AND asset_id<>'' THEN 1 ELSE 0 END) AS with_asset,
                  SUM(CASE WHEN health='ok' THEN 1 ELSE 0 END) AS ok
             FROM pages""") or {}
    env = db.q1("SELECT COUNT(*) AS n FROM envs WHERE role='publisher' "
                "AND status='running'") or {}

    # 真实可发：走和发布同一条判据
    lib_avail = pe.count_available(source="library")
    que_avail = pe.count_available(source="queue")

    # 库里有 ready 但文件没了（含路径自愈后仍找不到）→ 单独报出来
    missing = 0
    try:
        for r in db.q("SELECT path FROM library WHERE state='ready' "
                      "AND path IS NOT NULL AND path<>''"):
            if not pe.resolve_path(r["path"]):
                missing += 1
    except Exception:
        pass
    q_missing = 0
    try:
        for r in db.q("SELECT path FROM queue WHERE state='ready' "
                      "AND path IS NOT NULL AND path<>''"):
            if not pe.resolve_path(r["path"]):
                q_missing += 1
    except Exception:
        pass
    # 统计有多少条是靠"按文件名找回"的，让用户知道路径已经过期
    healed = 0
    try:
        for r in db.q("SELECT path FROM library WHERE state='ready' "
                      "AND path IS NOT NULL AND path<>''"):
            raw = r["path"]
            if not Path(raw).is_file() and pe.resolve_path(raw):
                healed += 1
    except Exception:
        pass
    hint = ""
    if missing or q_missing or healed:
        try:
            from app import paths as _paths
            hint = f"当前素材根目录：{_paths.output_root()}"
        except Exception:
            hint = ""

    links = db.q("SELECT * FROM promo_links WHERE enabled=1 ORDER BY weight DESC")

    # 标题不再落库（按剧实时生成），这里报"已为几部剧备好标题"的缓存状态
    try:
        from app.services import caption as cap
        title_cache = cap.cache_stats()
    except Exception as e:
        log.debug("cache_stats failed: %s", e)
        title_cache = {"dramas": [], "ttlSeconds": 0}

    # 主页清单：以「数据库 pages 表」为主，但补上内核 plan 里出现、
    # 数据库还没有的主页（数量对不上时前端会漏掉整个环境，是实机问题）。
    #
    # 为什么需要这一步：
    #   内核 discoverPages 会从每个环境抓到它名下的全部主页，
    #   而数据库 pages 表可能只同步过其中一个环境。
    #   实机表现：1932079482 有 3 个主页（Z01/Z03Shop/Z05Shop），
    #   但 pages 表里一条都没有 → 前端按环境分组时那个环境显示 0 个主页。
    page_rows = db.q(
        """SELECT p.page_id, p.asset_id, p.name, p.health, p.skip_publish,
                  p.published, p.env_code,
                  a.label AS account_label, a.c_user,
                  e.status AS env_status
             FROM pages p
             LEFT JOIN accounts a ON a.env_code = p.env_code AND a.enabled = 1
             LEFT JOIN envs e     ON e.container_code = p.env_code
            ORDER BY p.name""")

    pages_out = []
    for r in page_rows:
        reason = ""
        if not r["asset_id"]:
            reason = "缺 asset_id"
        elif (r["health"] or "ok") != "ok":
            reason = f"状态 {r['health']}"
        elif r["skip_publish"]:
            reason = "标记为手动发布"
        elif not r["env_code"]:
            reason = "未绑定环境"
        elif (r["env_status"] or "") != "running":
            reason = "环境未启动"
        pages_out.append({
            "pageId": r["page_id"],
            "pageName": r["name"] or r["page_id"],
            "assetId": r["asset_id"] or "",
            "health": r["health"] or "ok",
            "envCode": r["env_code"] or "",
            "envStatus": r["env_status"] or "",
            "envRunning": (r["env_status"] or "") == "running",
            "accountLabel": r["account_label"] or "",
            "published": int(r["published"] or 0),
            "selectable": not reason,
            "blockReason": reason,
            "fromPlan": False,
            # 详情弹窗要用的额外字段（拿不到就给空，前端显示 0 / –）
            "views30": int(_pick(r, "views_30") or 0),
            "followers": int(_pick(r, "followers") or 0),
            "authUsers": _auth_users_of(r["page_id"]),
        })

    plan_env_map: dict[str, str] = {}
    plan_name_map: dict[str, str] = {}
    try:
        from app.services import reels as _rl
        for a in _rl.plan_pages():
            pid = str(a.get("pageId") or "")
            if pid:
                plan_env_map[pid] = str(a.get("environmentId") or "")
                plan_name_map[pid] = str(a.get("pageName") or "")
    except Exception as e:
        log.debug("read plan pages failed: %s", e)

    # 以 assets/profile 双键都能对上
    known_keys: set[str] = set()
    for r in page_rows:
        if r["page_id"]:
            known_keys.add(str(r["page_id"]))
        if r["asset_id"]:
            known_keys.add(str(r["asset_id"]))

    ghosts = []
    for pid, env_code in plan_env_map.items():
        if pid in known_keys:
            continue
        ghosts.append({
            "pageId": pid,
            "pageName": plan_name_map.get(pid) or pid,
            "assetId": pid,                 # 内核对 pageId 用的是 asset id
            "health": "ok",
            "envCode": env_code,
            "envStatus": "",
            "envRunning": True,
            "accountLabel": "",
            "published": 0,
            "selectable": bool(env_code),
            "blockReason": "" if env_code else "未绑定环境",
            "fromPlan": True,               # 标记：只在核心里有，库里没同步
        })

    pages_out.extend(ghosts)
    pages_out.sort(key=lambda x: (x["envCode"], x["pageName"]))

    # 分组过滤：发布页只看发布号，授权页只看授权号
    group_filter = (group or "publish").strip().lower()
    if group_filter in ("publish", "auth"):
        keep = {r["container_code"] for r in db.q(
            "SELECT container_code FROM envs WHERE COALESCE(user_group,'')=?"
            " OR COALESCE(user_group,'')=''", (group_filter,))}
        if group_filter == "publish":
            # 未分组的号默认当发布号（向后兼容：现有 5 个号都未分组）
            pages_out = [p for p in pages_out
                         if (p["envCode"] or "") in keep
                         or not (p["envCode"] or "")]
        else:
            # 授权页：只保留明确标成 auth 的
            auth_only = {r["container_code"] for r in db.q(
                "SELECT container_code FROM envs WHERE user_group='auth'")}
            pages_out = [p for p in pages_out
                         if (p["envCode"] or "") in auth_only]

    # 环境清单：发布页按「账号 → 主页」两级展示。
    #
    # 2026-11-12 加分组过滤：
    #   用户可以把每个号分成「发布号」或「授权号」，
    #   发布中心只显示发布号（user_group='publish' 或未分组）。
    #   授权号由「主页与授权」页消费，不出现在这里。
    env_rows = db.q(
        """SELECT e.container_code, e.name AS env_name, e.role, e.status,
                  e.cdp_port, e.c_user, COALESCE(e.user_group,'') AS user_group,
                  a.id AS account_id, a.label AS account_label, a.c_user AS account_cuser
             FROM envs e
             LEFT JOIN accounts a ON a.env_code = e.container_code AND a.enabled = 1
            WHERE e.status <> 'removed'
              AND (COALESCE(e.user_group,'') = ''
                   OR e.user_group = 'publish'
                   OR e.user_group = ?)
            ORDER BY CASE e.role WHEN 'publisher' THEN 0
                                 WHEN 'backup' THEN 1 ELSE 2 END,
                     e.container_code""",
        (group_filter if group_filter != "publish" else "__none__",))

    # 每个环境挂几个主页、其中几个可发
    by_env: dict[str, dict] = {}
    for p in pages_out:
        code = p["envCode"] or ""
        slot = by_env.setdefault(code, {"total": 0, "selectable": 0})
        slot["total"] += 1
        if p["selectable"]:
            slot["selectable"] += 1

    envs_out = []
    shown_codes = {p["envCode"] for p in pages_out if p["envCode"]}
    for r in env_rows:
        code = r["container_code"]
        # 分组过滤后，没有主页的环境就不展示了（避免空卡片占位）
        if group_filter in ("publish", "auth") and code not in shown_codes:
            continue
        stat = by_env.get(code) or {"total": 0, "selectable": 0}
        envs_out.append({
            "envCode": code,
            "envName": r["env_name"] or code,
            "role": r["role"] or "",
            "userGroup": r["user_group"] or "",
            "status": r["status"] or "",
            "running": (r["status"] or "") == "running",
            "cdpPort": r["cdp_port"],
            "accountId": r["account_id"] or "",
            "accountLabel": r["account_label"] or "",
            "cUser": r["account_cuser"] or r["c_user"] or "",
            "pageTotal": stat["total"],
            "pageSelectable": stat["selectable"],
        })

    return {
        "ok": True,
        "library": {
            "total": lib.get("total") or 0,
            "ready": lib.get("ready") or 0,
            "used": lib.get("used") or 0,
            "mix": lib.get("mix") or 0,
            "usable": lib_avail["count"],
            "missingFiles": missing,
            "healedFiles": healed,
            "currentRoot": hint,
        },
        "queue": {"ready": que_avail["count"], "missingFiles": q_missing},
        "pages": {
            "total": pg.get("total") or 0,
            "withAsset": pg.get("with_asset") or 0,
            "ok": pg.get("ok") or 0,
            "list": pages_out,
            "selectable": sum(1 for p in pages_out if p["selectable"]),
        },
        "environments": envs_out,
        "envs": {"running": env.get("n") or 0},
        "dramas": lib_avail["dramas"],
        "links": links,
        "titles": {
            "mode": "on_the_fly",          # 按剧实时生成，不再有落库池
            "cacheDramas": len(title_cache.get("dramas") or []),
            "cacheLeft": sum(d.get("left", 0)
                             for d in (title_cache.get("dramas") or [])),
            "ttlSeconds": title_cache.get("ttlSeconds", 0),
        },
        "limits": {"minClips": pe.MIN_CLIPS, "maxClips": pe.MAX_CLIPS,
                   "captionStyles": list(pe.CAPTION_STYLES)},
    }


# ─────────────────────────────────────────────────────────────
# 请求模型
# ─────────────────────────────────────────────────────────────

class PreviewReq(BaseModel):
    pageIds: list[str] = Field(default_factory=list)
    clipsPerPage: int = 1
    materialSource: Literal["library", "queue", "path"] = "library"
    materials: list[str] = Field(default_factory=list)
    directory: str = ""
    allocMode: Literal["merge", "per_drama"] = "merge"
    captionStyle: Literal["simple", "template"] = "simple"
    fixedTitle: str = ""
    fixedLink: str = ""
    referenceTitle: str = ""
    templateBody: str = ""
    language: str = ""
    includeUsed: bool = False
    # 点「重新生成标题」时置 true，清掉按剧缓存重新让 AI 生成
    regenTitles: bool = False
    # ── 指定剧（2026-11-13 修复）──
    # ⚠ 之前前端勾选剧名+集数只存在前端 state.picked 里，
    #   从来没传给后端 —— UI 上的「已指定 N 部剧」是假的，
    #   实际分配永远走全库混合。这里补上真实传递。
    #
    # dramaPicks: {"剧名": 要发的条数}
    #   · 空对象 = 不指定，走原逻辑（merge 全库混发 / per_drama 按偏好）
    #   · 非空 = **只用这些剧的素材**，每部剧最多取指定条数
    # 若同时给了 dramas_only（只限剧，不限条数），以 dramaPicks 为准。
    dramaPicks: dict[str, int] = Field(default_factory=dict)


class CreateOrderReq(PreviewReq):
    concurrency: int = 1
    dryRun: bool = False
    autoPrepare: bool = True
    uploadStallSeconds: int = 180
    # 同一主页内多条视频的排期间隔（分钟）。默认 30。
    spacingMinutes: int = 30
    # 逐条间隔：第 i 条相对平台基线的分钟数。
    # 传了就优先用它，可以做到不等距（例如 [0, 30, 90, 180]）。
    # 空数组/不传 → 按 spacingMinutes 等距累加。
    scheduleOffsets: list[int] = Field(default_factory=list)
    title: str = ""


class ResolveReq(BaseModel):
    itemIds: list[str] = Field(default_factory=list)
    sent: bool = True
    note: str = ""


# ─────────────────────────────────────────────────────────────
# 预览（发布前必须看到这一屏）
# ─────────────────────────────────────────────────────────────

def _allocate_only(req: PreviewReq) -> tuple[list[pe.PageTarget], pe.AllocationResult, str]:
    """只做素材分配，不组装文案（2026-11-13 拆分）。

    ⚠ 为什么要拆：分配带随机洗牌，跑两遍结果不同。
      必须先分配一次拿到真实用到的剧 → 按它生成标题 → 再原地注入，
      不能"先生成标题再分配"（那样标题和视频对不上）。
    """
    pages = pe.resolve_pages(req.pageIds)
    materials = pe.resolve_materials(
        source=req.materialSource,
        materials=req.materials,
        directory=req.directory,
        include_used=req.includeUsed,
    )
    used = pe.used_hashes()
    alloc = pe.allocate(
        pages, materials, req.clipsPerPage,
        already_used_hashes=used, mode=req.allocMode,
        drama_picks=req.dramaPicks or None,
    )

    shortage_note = ""
    if alloc.shortage:
        if req.dramaPicks:
            shortage_note = alloc.note or "指定剧素材不足"
        else:
            clips = pe.normalize_clips(req.clipsPerPage)
            can_pages = max(0, alloc.available // max(1, clips))
            partial = pe.allocate(
                pages[:can_pages] if can_pages else [],
                materials, clips,
                already_used_hashes=used, mode=req.allocMode,
            )
            alloc = partial
            shortage_note = (f"素材不足：{len(pages)} 个主页 × {clips} 条 = 需要 "
                             f"{len(pages) * clips} 条，当前可发 {alloc.available} 条，"
                             f"还差 {len(pages) * clips - alloc.available} 条")
    return pages, alloc, shortage_note


def _attach_captions(req: PreviewReq, pages: list[pe.PageTarget],
                     alloc: pe.AllocationResult, shortage_note: str,
                     titles_by_drama: dict[str, list[str]] | None = None
                     ) -> dict:
    """原地给已分配好的每条注入文案（复用同一份 alloc，不重新分配）。"""
    title_cursor: dict[str, int] = {}
    # 构建小写 → 标题列表 的映射，兼容库里的剧名大小写不一致
    titles_lower: dict[str, list[str]] = {}
    if titles_by_drama:
        for k, v in titles_by_drama.items():
            titles_lower[(k or "").strip().lower()] = v

    for it in alloc.items:
        d = (it.material.drama or "").strip()
        preset = ""
        if titles_by_drama:
            lst = titles_by_drama.get(d) or titles_lower.get(d.lower()) or []
            idx = title_cursor.get(d.lower(), 0)
            if idx < len(lst):
                preset = lst[idx]
            title_cursor[d.lower()] = idx + 1

        it.caption = pe.build_caption(
            page_id=it.page.page_id,
            drama=it.material.drama,
            ep=it.material.ep,
            style=req.captionStyle,
            fixed_title=req.fixedTitle,
            fixed_link=req.fixedLink,
            reference_title=req.referenceTitle,
            template_body=req.templateBody,
            language=req.language,
            preset_title=preset,
        )

    clips = pe.normalize_clips(req.clipsPerPage)
    return {
        "pageCount": len({i.page.page_id for i in alloc.items}),
        "itemCount": len(alloc.items),
        "clipsPerPage": clips,
        "materialAvailable": alloc.available,
        "materialRequired": len(pages) * clips,
        "shortage": max(0, len(pages) * clips - alloc.available),
        "shortageNote": shortage_note,
        "requestedPages": len(pages),
    }


def _plan(req: PreviewReq,
          titles_by_drama: dict[str, list[str]] | None = None
          ) -> tuple[list[pe.PageTarget], pe.AllocationResult, dict]:
    """兼容旧调用：分配 + 组装一次做完。"""
    pages, alloc, shortage_note = _allocate_only(req)
    stats = _attach_captions(req, pages, alloc, shortage_note, titles_by_drama)
    return pages, alloc, stats

async def prepare_batch_titles(req: PreviewReq, materials: list,
                               force: bool = False,
                               alloc_items: list | None = None
                               ) -> dict[str, list[str]]:
    """按本轮**实际分配出去**的素材，统计每部剧需要几条，再分配标题。

    ⚠ 2026-11-13 重写（用户反馈"标题乱分/生成不出来"）：
        旧实现靠猜——按「主页数 × 条数 ÷ 剧数」估算每部剧要几条，
        然后给**所有**剧都生成。但素材是随机分配的：
          · 实际发出去的剧可能只有 3 部，却给 40 部都生成了标题（大量浪费）
          · 某个实际发出去的剧可能恰好没预估够，标题对不上视频
        现在改为：拿到 alloc_items（已完成分配）后，按**真实用到的剧和条数**
        精确统计。这样标题和视频一定一一对应，也不会为没发的剧浪费调用。

    alloc_items 为空时退回旧估算逻辑（兼容预览前的标题预热场景）。
    """
    from app.services import caption as cap

    if req.captionStyle != "simple" or req.fixedTitle.strip():
        return {}

    counts: dict[str, int] = {}

    if alloc_items:
        # 精确统计：本轮真正会用到的剧 + 条数
        #
        # ⚠ 2026-11-13 修复大小写重复（用户反馈标题数量不对）：
        #   库里同一部剧可能有两个 drama 值：
        #     "A Prisioneira da Chefe do Crime"
        #     "A prisioneira da chefe do crime"
        #   直接按原值统计会变成两部剧 → 各生成一份标题 →
        #   前端统计成两部、总标题数翻倍、JSON 里还出现"重复键"。
        #   这里按 lower() 归并，用出现最多的那个写法作为显示名。
        canon: dict[str, dict] = {}
        for it in alloc_items:
            d = (it.material.drama or "").strip()
            if not d:
                continue
            k = d.lower()
            slot = canon.setdefault(k, {"name": d, "count": 0,
                                        "variants": {}})
            slot["count"] += 1
            slot["variants"][d] = slot["variants"].get(d, 0) + 1

        for k, slot in canon.items():
            # 用出现次数最多的写法做规范名
            best = max(slot["variants"].items(), key=lambda x: x[1])[0]
            counts[best] = slot["count"]

        log.info("标题按实际分配统计：%d 部剧 %s",
                 len(counts), {k: v for k, v in list(counts.items())[:5]})
    else:
        # 兜底估算（没有分配结果时）
        per_page = max(1, int(req.clipsPerPage or 1))
        n_pages = max(1, len(req.pageIds or []))
        total_need = per_page * n_pages
        drama_kinds = {}
        for m in materials:
            d = (m.drama or "").strip()
            if d:
                drama_kinds[d] = drama_kinds.get(d, 0) + 1
        kinds = len(drama_kinds) or 1
        per_drama = max(per_page, (total_need + kinds - 1) // kinds + per_page)
        for d in drama_kinds:
            counts[d] = per_drama

    if not counts:
        return {}

    try:
        return await cap.assign_batch_titles(counts, force_regenerate=force)
    except Exception as e:
        log.warning("批量分配标题失败: %s", e)
        return {}


@router.post("/publish/preview")
@_guard
async def preview(req: PreviewReq):
    # ⚠ 2026-11-13 顺序修正：**先分配一次、拿到真实用到的剧**，
    #   再按实际用到的剧生成标题，最后原地注入同一份 alloc。
    #   旧实现先猜剧再生成 → 混合发布时标题和视频对不上、还浪费大量模型调用。
    pages, alloc, shortage_note = _allocate_only(req)
    titles_by_drama: dict[str, list[str]] = {}
    if req.captionStyle == "simple" and not req.fixedTitle.strip() and alloc.items:
        mats = pe.resolve_materials(
            source=req.materialSource, materials=req.materials,
            directory=req.directory, include_used=req.includeUsed)
        titles_by_drama = await prepare_batch_titles(
            req, mats, force=req.regenTitles, alloc_items=alloc.items)
    stats = _attach_captions(req, pages, alloc, shortage_note, titles_by_drama)

    items = [{        "pageId": it.page.page_id,
        "pageName": it.page.name,
        "assetId": it.page.asset_id,
        "file": it.material.file,
        "drama": it.material.drama,
        "ep": it.material.ep,
        "slot": it.slot,
        "title": it.caption.title if it.caption else "",
        "link": it.caption.link if it.caption else "",
        "caption": it.caption.body if it.caption else "",
        "captionSource": it.caption.source if it.caption else "",
    } for it in alloc.items]
    return {"ok": True, **stats, "items": items,
            "titlesByDrama": {k: len(v) for k, v in titles_by_drama.items()}}


# ─────────────────────────────────────────────────────────────
# 创建订单
# ─────────────────────────────────────────────────────────────

@router.post("/publish/orders")
@_guard
async def create_order(req: CreateOrderReq):
    from app.services import automation as au
    if au.observe_only():
        raise HTTPException(403, "当前是「只观察不动作」模式，发布已被拦截。"
                                 "去 概览 → 全自动 里关掉「只观察」，再发布。")

    # ⚠ 2026-11-13 顺序修正：先分配一次拿到真实用到的剧，再生成标题。
    #   和 preview 用同一套 _allocate_only + _attach_captions，
    #   保证「预览看到的标题」== 「实际发出去的标题」。
    pages, alloc, shortage_note = _allocate_only(req)
    titles_by_drama: dict[str, list[str]] = {}
    if (req.captionStyle == "simple" and not req.fixedTitle.strip()
            and alloc.items):
        try:
            mats = pe.resolve_materials(
                source=req.materialSource, materials=req.materials,
                directory=req.directory, include_used=req.includeUsed)
            titles_by_drama = await prepare_batch_titles(
                req, mats, force=req.regenTitles, alloc_items=alloc.items)
        except Exception as e:
            log.warning("建单前分配标题失败: %s", e)
    stats = _attach_captions(req, pages, alloc, shortage_note, titles_by_drama)

    # 建单必须硬拦：预览可以只展示能发的部分，但真发不能少发。
    if stats.get("shortage"):
        raise HTTPException(400, stats.get("shortageNote") or "素材不足")

    order_id = pe.new_order_id()
    idem = pe.order_idem_key(
        [p.page_id for p in pages],
        [i.material.sha256 for i in alloc.items],
        pe.normalize_clips(req.clipsPerPage))

    holder = _claim(idem, order_id)
    if holder:
        raise HTTPException(409, f"相同的发布任务仍在进行（{holder}），"
                                 f"请等待完成或先取消")

    pe.create_order(
        order_id=order_id, pages=pages, items=alloc.items,
        clips_per_page=pe.normalize_clips(req.clipsPerPage),
        caption_style=req.captionStyle,
        material_source=req.materialSource,
        alloc_mode=req.allocMode,
        payload=req.model_dump(),
        title=req.title,
    )
    _release(idem)

    if req.dryRun:
        pe.set_order(order_id, state="ATTENTION", stage="演练模式：只准备未提交")
        pe.mark_items(order_id, "SKIPPED")
        return {"ok": True, "orderId": order_id, "dryRun": True, **stats}

    # 用**独立线程 + 独立事件循环**跑发布，而不是 asyncio.create_task。
    #
    # ⚠ 为什么不用 create_task（2026-11-12 实机踩坑）：
    #   create_task 把协程挂到"当前调用方"的事件循环上。
    #   从 FastAPI 走（UI 点发布）时，那个 loop 是 uvicorn 的长驻 loop，
    #   任务能正常跑完。
    #   但从 MCP 工具走（agent 调 publish_now）时，工具是同步函数，
    #   内部用 asyncio.run() 调本函数 —— asyncio.run 返回时会关闭 loop，
    #   后台任务立刻被 CancelledError 打断，
    #   订单被标成 CANCELLED / "用户取消"，0 秒结束，一条都没发。
    #
    #   改成 threading.Thread 后，发布跑在自己的 loop 上，
    #   跟调用方是 HTTP 还是 MCP 完全无关，两条路都可靠。
    import threading

    def _worker_thread() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_run_order(order_id, req))
        except Exception as e:
            log.exception("publish thread crashed: %s", e)
            try:
                pe.set_order(order_id, state="FAILED",
                             stage=f"线程异常: {str(e)[:120]}",
                             ended_at=now_iso())
            except Exception:
                pass
        finally:
            try:
                loop.close()
            except Exception:
                pass

    th = threading.Thread(target=_worker_thread,
                          name=f"publish-{order_id}", daemon=True)
    th.start()
    RUNNING[order_id] = th

    return {"ok": True, "orderId": order_id, **stats}


def _claim(idem: str, job_id: str) -> str:
    """幂等占位：检查与插入同一事务；带租约，避免崩溃后永久卡死。

    直接复用 api/reels.py 的实现（那是全项目唯一设计正确的并发原语）。
    """
    from app.api.reels import _claim_signature
    return _claim_signature(idem, job_id)


def _release(idem: str) -> None:
    try:
        db.exec("UPDATE publish_locks SET status='done', updated_at=? WHERE signature=?",
                (now_iso(), idem))
    except Exception:
        pass


def _free_idem(order_id: str, reason: str = "cancelled") -> None:
    """订单没发成时，把 idem_key 让出来，允许下次重发同一批素材。

    ⚠ 为什么需要（2026-11-12 实机踩坑）：
        publish_orders.idem_key 是 NOT NULL UNIQUE，
        签名 = hash(主页 + 素材 sha256 + 每页条数)。

        取消/失败的订单会一直占着这个签名，于是：
          同一个素材 + 同一个主页 再提交 → 撞 UNIQUE → 409
        但那条素材其实从没发出去，用户被永久卡住。
        （实机表现：EP59 第一次订单 0 秒 CANCELLED，之后每次都被 409 拦，
          换素材才能过，而可用素材本来就不多。）

        做法：终态时把 idem_key 改成 `{原签名}#{原因}-{order_id}`，
        保住可追溯性，同时把原始签名让出来。
        成功（COMPLETED）的订单不动 —— 那种情况重复提交确实该拦。
    """
    try:
        row = db.q1("SELECT idem_key FROM publish_orders WHERE id=?", (order_id,))
        key = str((row or {}).get("idem_key") or "")
        if not key or "#" in key:
            return
        new_key = f"{key}#{reason}-{order_id}"
        db.exec("UPDATE publish_orders SET idem_key=? WHERE id=?",
                (new_key, order_id))
        log.info("释放幂等签名 %s → %s", key[:16], new_key[:28])
    except Exception as e:
        log.warning("释放 idem_key 失败 %s: %s", order_id, e)


# ─────────────────────────────────────────────────────────────
# 执行
# ─────────────────────────────────────────────────────────────

async def _run_order(order_id: str, req: CreateOrderReq) -> None:
    """按主页串行调 worker。每个主页一次 start，clipsPerPage=该主页条数。

    为什么按主页而不是一次全发：
      · worker 的 pageCaptions 是按 pageId 覆盖文案，逐页调用才能保证
        "这个主页发的是这几条、这段文案"是可验证的事实
      · staging 目录按主页隔离，worker 的删源只动 staging
      · 单页失败不影响其他主页，符合"漏发比重复发便宜"的取舍
    """
    from app.services import reels as rl

    order = pe.get_order(order_id)
    if not order:
        return

    items = order["items"]
    by_page: dict[str, list[dict]] = {}
    for it in items:
        by_page.setdefault(it["page_id"], []).append(it)

    pe.set_order(order_id, state="PREPARING", started_at=now_iso(),
                 stage="准备环境与素材")

    ok_n = fail_n = 0

    def on_prog(msg: str) -> None:
        """把内核进度写进订单的 stage，前端 SSE 能看到。"""
        try:
            pe.set_order(order_id, stage=str(msg)[:160])
            db.exec("UPDATE jobs SET steps=? WHERE id=?",
                    (json.dumps([{"name": msg, "state": "run", "note": ""}],
                                ensure_ascii=False), order_id))
        except Exception:
            pass

    try:
        # ① 一次性把浏览器摆好 + 抓好 plan：只做一次，不是每页都做。
        #    每页重做会把工作标签导来导去，反而破坏 checkBrowsers 的判据。
        if on_prog:
            on_prog("准备浏览器与发布计划…")
        prep = await rl.prepare_publish_ready(on_progress=on_prog)
        if not prep.get("ok"):
            err = prep.get("error") or "准备失败"
            pe.mark_items(order_id, "FAILED", error=err[:300])
            _free_idem(order_id, "failed")
            pe.set_order(order_id, state="FAILED", ended_at=now_iso(),
                         error=err[:400], stage=f"准备失败：{err}"[:120])
            db.log_event("err", "publish", f"订单 {order_id} 准备失败：{err}")
            return

        # ② 逐个主页执行
        # 归档上次残留运行，避免 RUN_ACTIVE（每页之前还会再归档一次）
        try:
            await rl.archive_current_run()
        except Exception as e:
            log.warning("archive before publish failed: %s", e)

        # 按主页批量发：内核会走「批量上传 + 排期」流程。
        #
        # 用户需求是"每个主页发 N 条，全部立即发布"。
        # 内核的 processPublicPageBatch 在 batchSize > 1 时：
        #   第 1 条 → 保持「立即发布」
        #   第 2 条起 → 点每行的「立即发布」下拉，把目标时间设为
        #               平台基线 + slot×30 分钟（core/browser_worker_lib.mjs:498）
        # 这个排期是用**平台自己的时间控件**填的，不是本地定时，
        # 所以 Meta 会在那些时间点自己发出去。
        #
        # 之前一次超过 1 条就失败，原因是 openSchedulePanel 用 exact 匹配
        # 「立即发布」，而 Meta 在窄列里把它渲染成「立即...」→ 120s 超时。
        # 已在 meta_controls.mjs 修好（labelPattern 允许截断）。
        for idx, (page_id, rows) in enumerate(by_page.items(), 1):
            if order_id in CANCELLED:
                pe.mark_items(order_id, "SKIPPED", error="用户取消")
                _free_idem(order_id, "cancelled")
                pe.set_order(order_id, state="CANCELLED", stage="已取消",
                             ended_at=now_iso())
                return

            page_name = rows[0].get("page_name") or page_id
            pe.set_order(
                order_id, state="RUNNING",
                stage=f"[{idx}/{len(by_page)}] {page_name} · {len(rows)} 条",
                progress=int((idx - 1) / max(1, len(by_page)) * 100),
            )
            for r in rows:
                pe.set_item(r["id"], state="RUNNING")

            # 每页发之前，把该页所属环境单独 prepare 一次。
            #
            # 为什么每页都要做（不是订单开始做一次就够）：
            #   ① 上一页发布完，内核会把标签导航到 latest/home；
            #      composer 失败时标签可能停在 bulk_upload_composer，
            #      内核的 chooseExistingMetaWorkTab 会拒绝复用 → META_TAB_REQUIRED
            #   ② discoverPages 抓 Page ID 时把标签导到 facebook.com/bookmarks/pages
            #   ③ HubStudio 会在空闲时回收标签
            # 实机表现：1932079482 报 BROWSER_NOT_READY，而它准备阶段明明是 ready 的。
            try:
                env_for_page = (db.q1("SELECT env_code FROM pages WHERE page_id=?",
                                      (page_id,)) or {}).get("env_code") or ""
                if env_for_page:
                    # 先关掉残留 composer（它也是 latest/，prepare 不会关它）
                    closed = await _close_composer_tabs(env_for_page)
                    if closed:
                        log.info("page %s: 关闭 %d 个残留 composer", page_name, closed)
                    from app.services import prepare as pz
                    pr = await pz.prepare_publish(env_for_page)
                    if not pr.get("ok"):
                        err = (f"环境 {env_for_page} 无法打开 Meta 工作标签："
                               f"{pr.get('error')}")
                        log.warning("page %s prepare failed: %s", page_name, err)
                        for r in rows:
                            pe.commit_item(order_id, r, success=False,
                                           error=err[:300])
                            fail_n += 1
                        pe.set_order(order_id, ok_count=ok_n, fail_count=fail_n,
                                     progress=int(idx / max(1, len(by_page)) * 100))
                        continue
            except Exception as e:
                log.warning("prepare page %s env failed: %s", page_name, e)

            result = await _publish_one_page(
                order_id=order_id, page_id=page_id, page_name=page_name,
                rows=rows, req=req,
            )

            if result.get("ok"):
                for r in rows:
                    pe.commit_item(order_id, r, success=True,
                                   acceptance=result.get("acceptance") or "")
                    ok_n += 1
            else:
                err = (result.get("error") or "发布失败")[:300]
                for r in rows:
                    pe.commit_item(order_id, r, success=False, error=err)
                    fail_n += 1

            pe.set_order(order_id, ok_count=ok_n, fail_count=fail_n,
                         progress=int(idx / max(1, len(by_page)) * 100))

        final_state = "COMPLETED" if fail_n == 0 else (
            "ATTENTION" if ok_n else "FAILED")
        pe.set_order(order_id, state=final_state, ended_at=now_iso(),
                     ok_count=ok_n, fail_count=fail_n, progress=100,
                     stage=f"完成：成功 {ok_n}，失败 {fail_n}")
        db.log_event("ok" if fail_n == 0 else "warn", "publish",
                     f"订单 {order_id} 结束：成功 {ok_n} / 失败 {fail_n}")

    except asyncio.CancelledError:
        pe.mark_items(order_id, "SKIPPED", error="用户取消")
        _free_idem(order_id, "cancelled")
        pe.set_order(order_id, state="CANCELLED", ended_at=now_iso(),
                     stage="已取消")
        raise
    except Exception as e:
        log.exception("publish order failed: %s", e)
        pe.mark_items(order_id, "FAILED", error=str(e)[:300])
        _free_idem(order_id, "failed")
        pe.set_order(order_id, state="FAILED", ended_at=now_iso(),
                     error=str(e)[:400], stage=f"异常：{e}"[:120])
    finally:
        pe.cleanup_stage(order_id)


async def _publish_one_page(*, order_id: str, page_id: str, page_name: str,
                            rows: list[dict], req: CreateOrderReq) -> dict:
    """调一次 worker 发一个主页。staging 目录隔离素材。

    ⚠ pageId 的两种语义（这是踩了很久的坑）：
        数据库 pages.page_id   = profile id（61595086030150）
        内核 plan 里的 pageId  = **asset id**（1381470255051396）
    内核的 skip / plan / pages[] 全部用 asset id。
    如果这里是 profile id，reels.publish 的 skippedPageIds 会把
    所有主页（含目标）都跳过 → remainingPlan 为空 → PLAN_REQUIRED。
    所以这里统一传 asset_id，并同时把它作为 skippedPageIds 的反向依据。
    """
    from app.services import reels as rl

    page_row = db.q1(
        "SELECT env_code, asset_id, page_id FROM pages WHERE page_id=?", (page_id,))
    env_code = (page_row or {}).get("env_code") or ""
    asset_id = str((page_row or {}).get("asset_id") or "")
    worker_page_id = asset_id or page_id          # 内核认 asset id

    # staging：把这条订单里属于这个主页的素材做成一个目录
    stage_dir = Path(pe._stage_root()) / order_id / _safe(page_name)
    if stage_dir.exists():
        shutil.rmtree(stage_dir, ignore_errors=True)
    stage_dir.mkdir(parents=True, exist_ok=True)
    for r in rows:
        src = Path(r["file"])
        if not src.is_file():
            return {"ok": False, "error": f"素材不存在：{src.name}"}
        dst = stage_dir / src.name
        if dst.exists():
            dst = stage_dir / f"{r['slot']:02d}_{src.name}"
        if not dst.exists():
            pe._link_or_copy(src, dst)

    caption = rows[0].get("caption") or ""
    stall = max(60, min(3600, int(req.uploadStallSeconds or 180)))

    # 每发一页之前，必须确认 composer 是干净的。
    #
    # ⚠ 这是"连发 3 条只有 1 条真发出去"的根因：
    #   Meta 的批量上传器在发布完成后**不会清空自己**，它会保留已完成的文件行。
    #   如果这时直接往里追加新文件、再点发布，Meta 会静默拒绝 ——
    #   按钮能点、上传进度能到 100%，就是不发布，且不报任何错。
    #   实机证据：Business Suite 里查不到第 2、3 条，只有第 1 条在那里。
    #
    # 做法：发现 composer 标签还开着就关掉它，让内核重新打开一个干净的。
    try:
        closed = await _close_composer_tabs(env_code)
        if closed:
            log.info("page %s: 关闭 %d 个残留 composer 标签", page_name, closed)
            # 关掉之后要重新 prepare 才能拿到工作标签
            from app.services import prepare as pz2
            await pz2.prepare_publish(env_code)
    except Exception as e:
        log.debug("close stale composer failed: %s", e)

    # 发出前最后确认 staging 里真的有足够文件。
    # worker 会用自己的 usedHashes 再过滤一遍目录里的文件。
    staged = ([x for x in stage_dir.iterdir()
               if x.suffix.lower() in (".mp4", ".mov", ".m4v", ".webm")]
              if stage_dir.exists() else [])
    if len(staged) < len(rows):
        return {"ok": False,
                "error": (f"staging 只有 {len(staged)} 个视频，需要 {len(rows)} 个"
                          f"（目录 {stage_dir.name}）")}

    # ⚠ 关键：把这次要发的素材从内核 usedHashes 里"临时放行"。
    #
    # 内核的 selectAvailableVideos 会严格跳过 usedHashes 里的文件：
    #     if (!used.has(fingerprint.sha256)) available.push(...)
    # 而 staging 目录里只有本次要发的那几个文件 —— 只要其中一个在 usedHashes 里，
    # 可用数就是 0，报 MATERIAL_SHORTAGE: 当前只有 0 个。
    #
    # 实机踩坑：yuhai 侧已经按 used_hashes() 过滤过素材了，
    # 但两边判据不同步（内核那份还含之前手工发的），结果前端显示"素材充足"、
    # 发布却报素材不足。
    #
    # 这里通过 releaseHash 把本次要发的 hash 从内核记录里放出，
    # 让内核重新接受它们。发成功后会重新写回 usedHashes。
    try:
        staged_hashes = [pe._sha256(str(f)) for f in staged]
        core_used = set(rl.state_snapshot().get("usedHashes") or [])
        blocked = [h for h in staged_hashes if h in core_used]
        if blocked:
            log.info("page %s: 放行 %d 个已用素材 hash", page_name, len(blocked))
            await rl.release_hashes(blocked)
    except Exception as e:
        log.warning("release hashes failed for %s: %s", page_name, e)

    log.info("page %s staging %s: %d files", page_name, stage_dir, len(staged))

    # 发出前最后确认这个环境真的有可用的 Meta 工作标签。
    # 不做这一步的话，内核会以 BROWSER_NOT_READY 失败，
    # 但错误挂在整批上、看不出是"环境掉线"还是"标签被占"。
    try:
        cb = await rl.check_browsers()
        hit = next((x for x in (cb.get("results") or [])
                    if str(x.get("environmentId")) == str(env_code)), None)
        if not hit or hit.get("status") != "ready":
            reason = (hit or {}).get("error") or (hit or {}).get("code") or "未知"
            return {"ok": False,
                    "error": f"环境 {env_code} 没有可用的 Meta 工作标签（{reason}）"}
    except Exception as e:
        log.debug("pre-publish browser check failed: %s", e)

    # 每页发之前都归档一次残留运行：上一页结束后内核可能停在 needs_attention，
    # 不归档会导致下一页直接 RUN_ACTIVE 被拒（这是实机踩过的坑）。
    try:
        await rl.archive_current_run()
    except Exception as e:
        log.debug("archive before page %s failed: %s", page_id, e)

    try:
        r = await rl.publish(
            directory=str(stage_dir),
            description=caption,
            link_pool="",
            clips_per_page=max(1, len(rows)),
            concurrency=1,
            publish_mode="merge",
            browser_ids=[env_code] if env_code else None,
            pages=[worker_page_id],
            materials=None,
            title_mode="fixed",
            fixed_title=caption,
            upload_stall_seconds=stall,
            spacing_minutes=max(0, int(req.spacingMinutes or 30)),
            schedule_offsets=(req.scheduleOffsets or None),
            on_progress=None,
            job_id="",
            auto_prepare=False,          # 外层已经 prepare 过全部环境，别重复
        )
    except Exception as e:
        log.warning("worker publish %s failed: %s", page_name, e)
        return {"ok": False, "error": str(e)[:300]}

    verdict = r.get("_verdict") or {}
    if verdict.get("ok"):
        pages = r.get("pages") or []
        acc = ""
        for p in pages:
            if str(p.get("pageId")) in (worker_page_id, page_id):
                acc = str(p.get("state") or "")
        return {"ok": True, "acceptance": acc or "upload_accepted"}

    return {"ok": False,
            "error": verdict.get("reason") or r.get("error") or "发布未完成"}


def _safe(name: str) -> str:
    keep = "".join(ch if (ch.isalnum() or ch in "-_.") else "_" for ch in (name or ""))
    return keep[:40] or "page"


async def _close_composer_tabs(env_code: str) -> int:
    """关掉该环境里所有 bulk_upload_composer 标签，返回关掉的数量。

    为什么需要：Meta 批量上传器发布完不清空自己，
    残留的编辑器会让下一次提交静默失败（按钮能点、进度能到 100%、就是不发布）。
    """
    import httpx

    if not env_code:
        return 0
    row = db.q1("SELECT cdp_port FROM envs WHERE container_code=?", (env_code,))
    port = int((row or {}).get("cdp_port") or 0)
    if not port:
        return 0

    closed = 0
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.get(f"http://127.0.0.1:{port}/json/list")
            tabs = r.json() if r.status_code == 200 else []
            for t in tabs:
                u = t.get("url") or ""
                if t.get("type") == "page" and "bulk_upload_composer" in u:
                    try:
                        await c.get(f"http://127.0.0.1:{port}/json/close/{t['id']}")
                        closed += 1
                    except Exception:
                        pass
    except Exception as e:
        log.debug("list tabs failed: %s", e)
    return closed


# 取消标记（进程内）
CANCELLED: set[str] = set()


# ─────────────────────────────────────────────────────────────
# 查询 / 取消 / 判定 / 重试
# ─────────────────────────────────────────────────────────────

@router.get("/publish/orders")
async def list_orders(limit: int = 40):
    rows = pe.list_orders(limit)
    for r in rows:
        r["progressInfo"] = pe.progress_of(r["id"])
    return {"items": rows, "total": len(rows)}


@router.get("/publish/orders/{order_id}")
async def get_order(order_id: str):
    o = pe.get_order(order_id)
    if not o:
        raise HTTPException(404, "订单不存在")
    o["progressInfo"] = pe.progress_of(order_id)
    o["running"] = order_id in RUNNING
    return {"ok": True, **o}


@router.post("/publish/orders/{order_id}/cancel")
async def cancel_order(order_id: str):
    o = pe.get_order(order_id)
    if not o:
        raise HTTPException(404, "订单不存在")
    CANCELLED.add(order_id)

    # 发布跑在独立线程里（见 create_order），线程没法强制 kill，
    # 靠 CANCELLED 集合让 _run_order 的循环在每个主页边界自己退出。
    # 这里只做标记 + 停 worker，不碰线程对象。
    task = RUNNING.get(order_id)
    if task is not None:
        try:
            if hasattr(task, "is_alive") and not task.is_alive():
                RUNNING.pop(order_id, None)
        except Exception:
            pass

    # 同时停掉 worker 进程（staging 里的发布正在跑）
    try:
        from app.services import reels as rl
        rl.stop_worker("")
    except Exception:
        pass

    pe.mark_items(order_id, "SKIPPED", error="用户取消")
    _free_idem(order_id, "cancelled")
    pe.set_order(order_id, state="CANCELLED", ended_at=now_iso(), stage="已取消")
    return {"ok": True, "note": "已取消，未提交的明细已标记跳过"}


@router.post("/publish/orders/{order_id}/resolve")
async def resolve_items(order_id: str, req: ResolveReq):
    """判定"结果不确定"的明细到底发没发出去。

    sent=True  → COMMITTED（永久锁住，不会再发）
    sent=False → FAILED（释放后可以重试）
    """
    o = pe.get_order(order_id)
    if not o:
        raise HTTPException(404, "订单不存在")

    ids = set(req.itemIds or [])
    touched = 0
    for it in o["items"]:
        if ids and it["id"] not in ids:
            continue
        if it["state"] not in ("ATTENTION", "RUNNING", "PENDING"):
            continue
        if req.sent:
            pe.commit_item(order_id, it, success=True,
                           acceptance="manual_confirmed")
        else:
            pe.set_item(it["id"], state="FAILED",
                        error=req.note or "人工判定未发出")
        touched += 1

    pe.set_order(order_id, stage=f"人工判定 {touched} 条")
    return {"ok": True, "touched": touched}


@router.post("/publish/orders/{order_id}/retry-failed")
async def retry_failed(order_id: str):
    """只把失败/跳过的明细重排一次（不新建订单，不重复发成功的）。"""
    o = pe.get_order(order_id)
    if not o:
        raise HTTPException(404, "订单不存在")
    if order_id in RUNNING:
        raise HTTPException(409, "订单仍在执行")

    retry = [it for it in o["items"] if it["state"] in ("FAILED", "SKIPPED")]
    if not retry:
        return {"ok": True, "note": "没有需要重试的明细", "retried": 0}

    # 重置为 PENDING 后重建任务
    for it in retry:
        pe.set_item(it["id"], state="PENDING", error=None)
    pe.set_order(order_id, state="PREPARING", stage="重试失败项",
                 ended_at=None, error=None)
    CANCELLED.discard(order_id)

    req = CreateOrderReq(**{
        k: v for k, v in json.loads(o.get("payload") or "{}").items()
        if k in CreateOrderReq.model_fields
    })
    # 与 create_order 一致：跑独立线程，不依赖调用方的事件循环
    import threading as _th
    def _retry_thread() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_run_order(order_id, req))
        except Exception as e:
            log.exception("retry thread crashed: %s", e)
        finally:
            try:
                loop.close()
            except Exception:
                pass
    t = _th.Thread(target=_retry_thread, name=f"retry-{order_id}", daemon=True)
    t.start()
    RUNNING[order_id] = t
    return {"ok": True, "retried": len(retry)}


# ─────────────────────────────────────────────────────────────
# SSE 实时进度（替代前端 6 秒轮询）
# ─────────────────────────────────────────────────────────────

@router.get("/publish/orders/{order_id}/events")
async def order_events(order_id: str):
    o = pe.get_order(order_id)
    if not o:
        raise HTTPException(404, "订单不存在")

    async def gen():
        last = ""
        for _ in range(1800):        # 最多 30 分钟（1s 一拍）
            cur = pe.get_order(order_id)
            if not cur:
                yield _sse({"error": "订单已删除"})
                return
            payload = {
                "state": cur["state"],
                "stage": cur["stage"],
                "progress": cur["progress"],
                "okCount": cur["ok_count"],
                "failCount": cur["fail_count"],
                "running": order_id in RUNNING,
                "counts": pe.progress_of(order_id)["counts"],
                "items": [{
                    "id": it["id"], "pageName": it["page_name"],
                    "state": it["state"], "slot": it["slot"],
                    "file": it["file_name"], "error": it["error"],
                } for it in cur["items"]],
            }
            sig = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            if sig != last:
                last = sig
                yield _sse(payload)
            if cur["state"] in ("COMPLETED", "FAILED", "CANCELLED", "ATTENTION"):
                if order_id not in RUNNING:
                    return
            await asyncio.sleep(1)
        yield _sse({"error": "超时"})

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


def _sse(obj: dict) -> str:
    return f"data: {json.dumps(obj, ensure_ascii=False, default=str)}\n\n"


# ─────────────────────────────────────────────────────────────
# 兼容层：旧端点保留，内部转新链路
# ─────────────────────────────────────────────────────────────

@router.get("/publish/history")
async def history(limit: int = 50):
    return {"items": pe.list_orders(limit)}


@router.get("/publish/caption-template")
async def caption_template():
    from app.services import caption_tpl as ct
    return {"template": ct.DEFAULT_BODY,
            "vars": list(ct.VARS.keys()) if isinstance(ct.VARS, dict) else ct.VARS}


class CaptionReq(BaseModel):
    template: str = ""
    drama: str = ""
    ep: str = ""
    ep_title: str = ""
    hook: str = ""
    pageId: str = ""


@router.post("/publish/render-caption")
async def render_caption(req: CaptionReq):
    plan = pe.build_caption(
        page_id=req.pageId, drama=req.drama, ep=req.ep,
        style="template", template_body=req.template, language="en")
    return {"caption": plan.body, "title": plan.title, "link": plan.link}
