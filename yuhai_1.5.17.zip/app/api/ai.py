"""AI 分析 API：主页受众画像 + 内容适配建议 + 素材智能匹配。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.db import db, now_iso
from app.services import ai_analysis as ai

log = logging.getLogger("yuhai.api.ai")
router = APIRouter(tags=["ai"])


# ---------------- 单页分析 ----------------
class AnalyzeReq(BaseModel):
    pageId: str
    model: str = ""
    useModel: bool = True


@router.post("/ai/analyze")
async def analyze(req: AnalyzeReq):
    r = db.q1("SELECT page_id,name FROM pages WHERE page_id=?", (req.pageId,))
    if not r:
        raise HTTPException(404, "主页不存在")
    res = await ai.analyze_page(req.pageId, req.model, req.useModel)
    return res


class AnalyzeBatchReq(BaseModel):
    pageIds: list[str] = []
    model: str = ""
    useModel: bool = True


@router.post("/ai/analyze-batch")
async def analyze_batch(req: AnalyzeBatchReq):
    targets = req.pageIds or [p["page_id"] for p in db.q("SELECT page_id FROM pages")]
    job_id = "job-" + uuid.uuid4().hex[:12]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "ai", f"AI 分析 {len(targets)} 个主页", "running", 0,
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_batch(job_id, targets, req.model, req.useModel))
    return {"ok": True, "jobId": job_id, "total": len(targets)}


async def _run_batch(job_id: str, ids: list[str], model: str, use_model: bool) -> None:
    ok, weak, fail = 0, 0, 0
    details = []
    try:
        for i, pid in enumerate(ids):
            try:
                res = await ai.analyze_page(pid, model, use_model)
                if res["sample"] < ai.MIN_SAMPLES:
                    weak += 1
                else:
                    ok += 1
                details.append({"pageId": pid, "sample": res["sample"],
                                "type": (res.get("result") or {}).get("drama_type"),
                                "conf": (res.get("result") or {}).get("confidence")})
            except Exception as e:
                fail += 1
                details.append({"pageId": pid, "error": str(e)[:100]})
            db.exec("UPDATE jobs SET progress=? WHERE id=?",
                    (int((i + 1) / len(ids) * 100), job_id))
            await asyncio.sleep(0.4)
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps({"ok": ok, "insufficient": weak, "fail": fail,
                             "details": details}, ensure_ascii=False),
                 now_iso(), job_id))
        db.log_event("ok", "ai", f"分析完成 有效 {ok} · 样本不足 {weak} · 失败 {fail}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


# ---------------- 查询结果 ----------------
@router.get("/ai/fit")
async def list_fit():
    rows = db.q("""SELECT f.*, p.name AS page_name, p.health
                   FROM page_fit f LEFT JOIN pages p ON p.page_id=f.page_id
                   ORDER BY f.ts DESC""")
    out = []
    for r in rows:
        try:
            kw = json.loads(r["keywords"] or "[]")
            av = json.loads(r["avoid"] or "[]")
        except Exception:
            kw, av = [], []
        out.append({
            "pageId": r["page_id"],
            "pageName": r["page_name"] or r["page_id"],
            "health": r["health"],
            "dramaType": r["drama_type"],
            "keywords": kw,
            "avoid": av,
            "reason": r["reason"],
            "confidence": r["confidence"],
            "sample": r["sample_size"],
            "model": r["model"],
            "ts": r["ts"],
            "ready": (r["sample_size"] or 0) >= ai.MIN_SAMPLES,
        })
    return {"items": out, "minSamples": ai.MIN_SAMPLES}


@router.get("/ai/fit/{page_id}")
async def get_fit(page_id: str):
    r = db.q1("SELECT * FROM page_fit WHERE page_id=?", (page_id,))
    if not r:
        return {"ok": False, "error": "尚未分析", "pageId": page_id}
    try:
        kw = json.loads(r["keywords"] or "[]")
        av = json.loads(r["avoid"] or "[]")
    except Exception:
        kw, av = [], []
    return {"ok": True, "pageId": page_id, "dramaType": r["drama_type"],
            "keywords": kw, "avoid": av, "reason": r["reason"],
            "confidence": r["confidence"], "sample": r["sample_size"],
            "model": r["model"], "ts": r["ts"]}


# ---------------- 手动绑定：指定剧 → 指定主页（2026-11-13） ----------------
class BindReq(BaseModel):
    pageId: str
    dramas: list[str] = Field(default_factory=list)   # 空数组 = 解除绑定
    source: str = "manual"                            # manual | ai


@router.post("/ai/fit-bind")
async def bind_dramas(req: BindReq):
    """把「指定剧只发给指定主页」写成 page_fit.keywords。

    per_drama 分配模式读这张表：keywords 里的剧优先发，
    avoid 里的不发。这里用户直接指定 dramas 列表（精确匹配剧名）。
    """
    if not req.pageId:
        raise HTTPException(400, "pageId 为空")
    p = db.q1("SELECT page_id, name FROM pages WHERE page_id=?", (req.pageId,))
    if not p:
        raise HTTPException(404, "主页不存在")

    dramas = [d.strip() for d in req.dramas if d.strip()]
    now = now_iso()
    # 首次加列（老库没有 manual/source）
    try:
        db.exec("ALTER TABLE page_fit ADD COLUMN manual INTEGER DEFAULT 0")
    except Exception:
        pass
    try:
        db.exec("ALTER TABLE page_fit ADD COLUMN source TEXT DEFAULT ''")
    except Exception:
        pass
    exists = db.q1("SELECT page_id FROM page_fit WHERE page_id=?", (req.pageId,))
    if exists:
        db.exec("""UPDATE page_fit
                   SET keywords=?, source=?, ts=?, manual=1
                   WHERE page_id=?""",
                (json.dumps(dramas, ensure_ascii=False), req.source,
                 now, req.pageId))
    else:
        db.exec("""INSERT INTO page_fit(page_id, keywords, avoid, drama_type,
                   reason, confidence, sample_size, model, source, manual, ts)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (req.pageId, json.dumps(dramas, ensure_ascii=False), "[]",
                 "", "用户手动绑定：只发指定剧", 1.0, 0, "", req.source,
                 1, now))
    return {"ok": True, "pageId": req.pageId,
            "pageName": p["name"], "dramas": dramas,
            "note": ("已绑定：" + "、".join(dramas)) if dramas
                     else "已解除绑定（该主页回到全库分配）"}


@router.get("/ai/fit-bindings")
async def list_bindings():
    """全部手动绑定清单（剧 → 主页）。"""
    rows = db.q("""SELECT f.page_id, f.keywords, f.manual, f.ts,
                          p.name AS page_name
                   FROM page_fit f LEFT JOIN pages p ON p.page_id=f.page_id
                   WHERE f.manual=1 ORDER BY p.name""")
    out = []
    for r in rows:
        try:
            dramas = json.loads(r["keywords"] or "[]")
        except Exception:
            dramas = []
        out.append({"pageId": r["page_id"], "pageName": r["page_name"] or "",
                    "dramas": dramas, "ts": r["ts"]})
    return {"ok": True, "items": out}


@router.get("/ai/stats/{page_id}")
async def page_stats(page_id: str, windowDays: int = 30):
    """原始统计特征（不调模型），前端画图用。"""
    st = ai.collect_page_stats(page_id, windowDays)
    return {
        "pageId": page_id, "pageName": st.page_name,
        "videos": st.videos, "withPlays": st.videos_with_plays,
        "totalPlays": st.total_plays, "totalClicks": st.total_clicks,
        "medianPlays": round(st.median_plays, 1),
        "byType": st.by_type, "byDuration": st.by_duration,
        "byHour": {str(k): v for k, v in st.by_hour.items()},
        "topTitles": st.top_titles, "lowTitles": st.low_titles,
        "ready": st.ready, "minSamples": ai.MIN_SAMPLES,
    }


@router.get("/ai/history")
async def history(limit: int = 50):
    rows = db.q("SELECT * FROM ai_analysis ORDER BY ts DESC LIMIT ?", (min(limit, 200),))
    for r in rows:
        for k in ("input_json", "result"):
            if r.get(k):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
    return {"items": rows}


# ---------------- 素材智能匹配 ----------------
@router.get("/ai/match")
async def match_library(page_id: str = "", mode: str = "fit", limit: int = 50):
    """按主页适配度给素材打分排序。

    mode:
      fit    按 AI 建议的剧型/关键词匹配
      random 随机打乱
      all    不排序
    """
    lib = db.q("SELECT * FROM library WHERE state='ready'")
    if not lib:
        return {"items": [], "note": "素材库没有可发布素材"}

    if mode == "random":
        import random
        random.shuffle(lib)
        return {"items": lib[:limit], "mode": "random"}

    if mode == "all" or not page_id:
        return {"items": lib[:limit], "mode": "all"}

    fit = db.q1("SELECT * FROM page_fit WHERE page_id=?", (page_id,))
    if not fit:
        return {"items": lib[:limit], "mode": "all",
                "note": "该主页尚未 AI 分析，未排序"}

    try:
        keywords = json.loads(fit["keywords"] or "[]")
        avoid = json.loads(fit["avoid"] or "[]")
    except Exception:
        keywords, avoid = [], []
    want_type = fit["drama_type"] or ""

    def score(x: dict) -> float:
        s = 0.0
        if want_type and x.get("dtype") == want_type:
            s += 50
        blob = ((x.get("drama") or "") + " " + (x.get("file") or "")
                + " " + (x.get("tags") or "")).lower()
        for kw in keywords:
            if kw and kw.lower() in blob:
                s += 12
        for av in avoid:
            if av and av.lower() in blob:
                s -= 25
        if x.get("copyright_ok") == 0:
            s -= 100     # 版权不过的直接排最后
        if x.get("state") == "blocked":
            s -= 100
        return s

    ranked = sorted(lib, key=score, reverse=True)
    out = []
    for x in ranked[:limit]:
        x2 = dict(x)
        x2["fitScore"] = round(score(x), 1)
        out.append(x2)
    return {"items": out, "mode": "fit", "wantType": want_type,
            "keywords": keywords, "confidence": fit["confidence"],
            "sample": fit["sample_size"],
            "note": "" if (fit["sample_size"] or 0) >= ai.MIN_SAMPLES
                    else f"样本不足（{fit['sample_size']} 条），匹配仅供参考"}

# ─────────────────────────────────────────────────────────────
# 剧集自由打标签（2026-11-13）
#
# 用户要求："不要局限于分类，直接让模型自由判断打标签，不要乱打，
#            看剧里面的全部视频内容的信息打，同一个剧可以打多个标签，
#            类型绑定就直接选择有这个标签的"
# ─────────────────────────────────────────────────────────────

class TagOneReq(BaseModel):
    drama: str
    model: str = ""


class TagBatchReq(BaseModel):
    model: str = ""
    onlyMissing: bool = True
    limit: int = 50


@router.get("/ai/tags")
async def tags_list():
    """所有剧的标签（按剧分组）。"""
    from app.services import drama_tags as dt
    items = dt.list_tags()
    # 顺带报出还没打标签的剧，方便界面提示
    from app.db import db as _db
    all_dramas = [r["drama"] for r in _db.q(
        "SELECT drama, COUNT(*) AS n FROM library "
        "WHERE state='ready' AND drama IS NOT NULL AND drama<>'' "
        "GROUP BY drama ORDER BY n DESC")]
    tagged = {it["drama"] for it in items}
    return {"ok": True, "items": items,
            "total": len(all_dramas),
            "tagged": len(tagged),
            "untagged": [d for d in all_dramas if d not in tagged][:60]}


@router.post("/ai/tags/one")
async def tags_one(req: TagOneReq):
    """给一部剧打标签（读台词 → 模型自由总结）。"""
    from app.services import drama_tags as dt
    return await dt.tag_drama(req.drama, req.model)


@router.post("/ai/tags/batch")
async def tags_batch(req: TagBatchReq):
    """批量打标签。onlyMissing=True 只补还没打过的。"""
    from app.services import drama_tags as dt
    return await dt.tag_all(req.model, onlyMissing=req.onlyMissing,
                            limit=req.limit)


@router.post("/ai/tags/clear")
async def tags_clear(drama: str = ""):
    """清掉某部剧的标签（drama 为空则清全部）。"""
    from app.services import drama_tags as dt
    dt.ensure_schema()
    if drama:
        from app.db import db as _db
        _db.exec("DELETE FROM drama_tags WHERE drama=?", (drama,))
    else:
        from app.db import db as _db
        _db.exec("DELETE FROM drama_tags")
    return {"ok": True}