# -*- coding: utf-8 -*-
"""素材整理：把成片按「剧名/文件名」归档，顺带做剧名语言转换。

═══════════════════════════════════════════════════════════════
用户需求（2026-11-12）：
    "增加一下整理素材的按钮，并且要求入库后的视频必须整理素材，
     不然不算正式入库。整理素材要求按剧名/文件，把整理素材加上
     素材名字转换什么语言"

设计：
    · 整理 = 把散落的成片（单集_日期/剧名/文件.mp4）搬进
      素材库根目录下的统一结构：
          素材库/<剧名英文或中文>/<文件>
    · 剧名语言可选：
          keep      保持原样（默认）
          en        转成英文（美区发布用，走 reel_caption 的映射）
          zh        转成中文
    · 入库时如果没整理过（library.organized=0），状态记 uncertain，
      发布时不允许选中 —— 这就是"不整理不算正式入库"
═══════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app import paths
from app.db import db, now_iso

log = logging.getLogger("yuhai.organize")
router = APIRouter()

LangMode = Literal["keep", "en", "zh"]


# ─────────────────────────────────────────────────────────────
# 剧名转换
# ─────────────────────────────────────────────────────────────

def _has_chinese(s: str) -> bool:
    return bool(re.search(r"[\u4e00-\u9fff]", s or ""))


def _clean_name(name: str) -> str:
    """剧名清洗：去 _<纯数字cid> 后缀、去多余空格、非法字符转下划线。"""
    s = (name or "").strip()
    # 去掉抓取目录带来的 cid 后缀：{中文剧名}_{20位数字}
    m = re.match(r"^(.+?)_(\d{15,})$", s)
    if m:
        s = m.group(1)
    s = re.sub(r"\s+", " ", s)
    # 文件名安全：只保留中英文数字和 - _ . 空格
    s = re.sub(r"[^\w\u4e00-\u9fff\-_. ]+", "_", s)
    return s.strip(" ._-") or "未命名"


def _load_title_map() -> dict[str, str]:
    """加载用户维护的剧名映射表（中文 → 指定语言）。

    数据源（合并，后者覆盖）：
      ① 代码内置 reel_caption.CN_TITLE_MAP（历史数据）
      ② DB 表 title_map（用户在软件里维护，cn 列 → en 列）
    """
    m: dict[str, str] = {}
    try:
        from app.services import reel_caption as rc
        m.update(getattr(rc, "CN_TITLE_MAP", {}) or {})
    except Exception:
        pass
    try:
        rows = db.q("SELECT cn, en FROM title_map")
        for r in rows or []:
            if r.get("cn") and r.get("en"):
                m[r["cn"]] = r["en"]
    except Exception:
        pass
    return m


def _save_title_map(cn: str, en: str) -> None:
    """写一条映射进 DB（用户界面维护用）。首次自动建表。"""
    db.exec("""CREATE TABLE IF NOT EXISTS title_map(
                cn TEXT PRIMARY KEY,
                en TEXT NOT NULL,
                updated_at TEXT)""")
    db.exec("INSERT INTO title_map(cn,en,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(cn) DO UPDATE SET en=excluded.en, "
            "updated_at=excluded.updated_at",
            (cn, en, now_iso()))


def convert_drama_name(name: str, mode: LangMode = "keep") -> str:
    """按语言模式转换剧名。

    keep  原样（只做清洗）
    en    转英文：先查映射表（DB+内置），没有映射的中文剧名
          用拼音/逐字规则没法可靠翻译 —— 保持原名并在结果里
          标记 unmapped=True，让调用方看到哪些剧没转成功。
    zh    转中文：反查映射表
    """
    base = _clean_name(name)
    if mode == "keep":
        return base

    cn_map = _load_title_map()
    rev_map = {}
    for cn, en in cn_map.items():
        try:
            rev_map[_clean_name(en).lower()] = cn
        except Exception:
            pass

    if mode == "en":
        if not _has_chinese(base):
            return base
        # 直接查
        if base in cn_map:
            return _clean_name(cn_map[base])
        # 去 cid 后缀后查 / 宽松匹配（全角/繁简差异）
        for cn, en in cn_map.items():
            cn_c = _clean_name(cn)
            if cn_c == base or cn_c.replace(" ", "") == base.replace(" ", ""):
                return _clean_name(en)
        # 转不了 —— 保持原名（调用方用 unmapped_names 看到清单）
        log.warning("剧名转英文无映射: %s", base)
        return base

    if mode == "zh":
        if _has_chinese(base):
            return base
        return _clean_name(rev_map.get(base.lower(), base))

    return base


# ─────────────────────────────────────────────────────────────
# 整理计划
# ─────────────────────────────────────────────────────────────

@dataclass
class MovePlan:
    lib_id: str
    src: str
    dst: str
    drama_old: str
    drama_new: str
    file_old: str
    file_new: str
    reason: str = ""          # 为什么不动
    skip: bool = False
    conflict: bool = False    # 目标已存在


def _target_dir(root: Path, drama: str) -> Path:
    return root / _clean_name(drama)


def _target_file(drama: str, ep: str, line: str, orig: str,
                 mode: LangMode) -> str:
    """目标文件名。

    规则：
      · 单集：{剧名}_EP{nn}.mp4
      · 主线/混剪：{剧名}_主线.mp4
      · 保留原扩展名
    """
    ext = Path(orig).suffix.lower() or ".mp4"
    d = _clean_name(drama)
    if line == "premium" or "主线" in orig or "混剪" in orig:
        return f"{d}_主线{ext}"
    m = re.search(r"(?:EP|ep|_e)(\d{1,3})", Path(orig).stem)
    if m:
        return f"{d}_EP{int(m.group(1)):02d}{ext}"
    return _clean_name(Path(orig).stem) + ext


def build_plan(ids: list[str], mode: LangMode = "keep",
               root: Path | None = None,
               dry: bool = False) -> list[MovePlan]:
    """算出每个素材要搬到哪。不实际移动。"""
    root = root or paths.library_root()
    plans: list[MovePlan] = []

    if ids:
        rows = db.q(
            f"SELECT * FROM library WHERE id IN ({','.join('?' * len(ids))})",
            tuple(ids))
    else:
        rows = db.q("SELECT * FROM library WHERE state IN ('ready','used')")

    for r in rows or []:
        old_drama = str(r.get("drama") or "")
        new_drama = convert_drama_name(old_drama, mode)
        line = str(r.get("line") or "single")
        ep = str(r.get("ep") or "")
        new_file = _target_file(new_drama, ep, line, r["file"], mode)

        dst_dir = _target_dir(root, new_drama)
        dst = dst_dir / new_file

        # 源文件真实位置（可能路径已过期）
        src = str(r["path"])
        from app.services import publish_engine as pe
        real = pe.resolve_path(src)
        if not real:
            plans.append(MovePlan(
                lib_id=r["id"], src=src, dst=str(dst),
                drama_old=old_drama, drama_new=new_drama,
                file_old=r["file"], file_new=new_file,
                reason="源文件不存在", skip=True))
            continue

        src = str(real)
        # 已经在目标位置 → 只需更新库记录
        if Path(src).resolve() == dst.resolve():
            plans.append(MovePlan(
                lib_id=r["id"], src=src, dst=str(dst),
                drama_old=old_drama, drama_new=new_drama,
                file_old=r["file"], file_new=new_file,
                reason="已在目标位置（只更新记录）"))
            continue

        conflict = dst.exists()
        plans.append(MovePlan(
            lib_id=r["id"], src=src, dst=str(dst),
            drama_old=old_drama, drama_new=new_drama,
            file_old=r["file"], file_new=new_file,
            conflict=conflict,
            reason="目标已存在同名文件" if conflict else ""))

    return plans


# ─────────────────────────────────────────────────────────────
# 接口
# ─────────────────────────────────────────────────────────────

class OrganizeReq(BaseModel):
    ids: list[str] = Field(default_factory=list)
    lang: LangMode = "keep"
    dryRun: bool = False
    moveFiles: bool = True        # false = 只改库记录，不动文件


@router.get("/library/organize/path")
async def organize_path():
    """素材库根目录（前端显示"整理到哪"）。"""
    root = paths.library_root()
    return {"ok": True, "root": str(root), "exists": root.exists()}


@router.post("/library/organize/preview")
async def organize_preview(req: OrganizeReq):
    """预览整理计划：每条素材从哪搬到哪，剧名怎么变。"""
    try:
        plans = build_plan(req.ids, req.lang, dry=True)
    except Exception as e:
        raise HTTPException(500, f"生成计划失败: {e}")

    items = [{
        "id": p.lib_id,
        "fileOld": p.file_old,
        "fileNew": p.file_new,
        "dramaOld": p.drama_old,
        "dramaNew": p.drama_new,
        "src": p.src,
        "dst": p.dst,
        "skip": p.skip,
        "conflict": p.conflict,
        "reason": p.reason,
    } for p in plans]

    # ⚠ 转换失败的剧名清单（有中文但映射表里没有 → 保持原名）
    # 用户看到这个清单就知道要去映射表里补哪几条
    unmapped: list[str] = []
    if req.lang != "keep":
        seen: set[str] = set()
        for p in plans:
            if (req.lang == "en" and _has_chinese(p.drama_old)
                    and p.drama_old == p.drama_new and p.drama_old not in seen):
                seen.add(p.drama_old)
                unmapped.append(p.drama_old)

    return {
        "ok": True,
        "root": str(paths.library_root()),
        "total": len(items),
        "skipped": sum(1 for x in items if x["skip"]),
        "conflicts": sum(1 for x in items if x["conflict"]),
        "renameCount": sum(1 for x in items
                           if x["dramaOld"] != x["dramaNew"]
                           or x["fileOld"] != x["fileNew"]),
        "unmapped": unmapped,
        "items": items[:200],
    }


@router.post("/library/organize/run")
async def organize_run(req: OrganizeReq):
    """执行整理：搬文件 + 更新库记录 + 标记 organized=1。"""
    try:
        plans = build_plan(req.ids, req.lang)
    except Exception as e:
        raise HTTPException(500, f"生成计划失败: {e}")

    moved = renamed = failed = 0
    details: list[dict] = []
    emptied_dirs: set[str] = set()   # 整理后被清空的源目录（2026-11-13 用户要求删掉）

    for p in plans:
        if p.skip:
            details.append({"id": p.lib_id, "file": p.file_old,
                            "result": "skip", "reason": p.reason})
            continue

        src = Path(p.src)
        dst = Path(p.dst)

        try:
            src_dir = None
            if req.moveFiles and src.resolve() != dst.resolve():
                src_dir = src.parent
                dst.parent.mkdir(parents=True, exist_ok=True)
                if dst.exists():
                    # 同名冲突：加序号，绝不覆盖
                    stem, suf = dst.stem, dst.suffix
                    n = 2
                    while dst.exists():
                        dst = dst.parent / f"{stem}_{n}{suf}"
                        n += 1
                    p.dst = str(dst)

                # 优先硬链接（同盘秒完成、不占额外空间），失败才复制+删源
                linked = False
                try:
                    import os as _os
                    if src.drive.lower() == dst.drive.lower():
                        _os.link(str(src), str(dst))
                        linked = True
                except Exception:
                    linked = False
                if not linked:
                    await asyncio.to_thread(shutil.copy2, str(src), str(dst))
                try:
                    if linked:
                        src.unlink()
                except Exception as e:
                    log.debug("unlink src failed: %s", e)
                moved += 1

            if p.drama_old != p.drama_new or p.file_old != p.file_new:
                renamed += 1

            # 更新库记录
            from app.services import publish_engine as pe
            new_hash = ""
            try:
                new_hash = pe._sha256(str(dst if dst.exists() else src))
            except Exception:
                pass

            db.exec(
                "UPDATE library SET path=?, file=?, drama=?, "
                "organized=1, organized_at=?, target_lang=?, "
                "state=CASE WHEN state='blocked' THEN state ELSE 'ready' END, "
                "used_by=NULL "
                "WHERE id=?",
                (str(dst), Path(p.dst).name, p.drama_new, now_iso(),
                 req.lang, p.lib_id))

            details.append({"id": p.lib_id, "file": p.file_old,
                            "newFile": Path(p.dst).name,
                            "dst": str(dst), "result": "ok"})

            # 记录源目录，最后统一清理空目录
            if src_dir is not None:
                emptied_dirs.add(str(src_dir))
        except Exception as e:
            failed += 1
            details.append({"id": p.lib_id, "file": p.file_old,
                            "result": "fail", "reason": str(e)[:120]})

    # ── 清理整理后变空的源目录（2026-11-13 用户要求："整理文件也不清空文件夹"）──
    removed_dirs: list[str] = []
    root = paths.library_root().resolve()
    for d in emptied_dirs:
        p = Path(d)
        # 只清理素材库根之外的目录（素材库内部结构不动）
        try:
            if root in p.resolve().parents or root == p.resolve():
                continue
        except Exception:
            continue
        # 目录里没有文件了（空目录或只剩空子目录）→ 删
        try:
            if not p.exists():
                continue
            has_files = any(f for f in p.rglob("*") if f.is_file())
            if not has_files:
                shutil.rmtree(p, ignore_errors=True)
                removed_dirs.append(str(p))
        except Exception as e:
            log.debug("rmtree %s failed: %s", d, e)

    db.log_event(
        "ok" if not failed else "warn", "library",
        f"整理素材：移动 {moved}，改名 {renamed}，失败 {failed}，"
        f"清空源目录 {len(removed_dirs)}")

    return {"ok": failed == 0, "moved": moved, "renamed": renamed,
            "failed": failed, "total": len(plans),
            "removedDirs": removed_dirs,
            "root": str(paths.library_root()),
            "details": details[:120]}


class DramaLangReq(BaseModel):
    names: list[str] = Field(default_factory=list)
    lang: LangMode = "en"


@router.post("/library/organize/convert-names")
async def convert_names(req: DramaLangReq):
    """只做剧名转换预览（不碰文件）。"""
    out = []
    for n in req.names[:200]:
        out.append({"old": n, "new": convert_drama_name(n, req.lang)})
    return {"ok": True, "lang": req.lang, "items": out}


# ─────────────────────────────────────────────────────────────
# 剧名映射表（用户在软件里维护，2026-11-13 新增）
# ─────────────────────────────────────────────────────────────

class MapItem(BaseModel):
    cn: str
    en: str


class MapReq(BaseModel):
    items: list[MapItem] = Field(default_factory=list)


@router.get("/library/title-map")
async def title_map_list():
    """列出全部剧名映射。"""
    db.exec("""CREATE TABLE IF NOT EXISTS title_map(
                cn TEXT PRIMARY KEY,
                en TEXT NOT NULL,
                updated_at TEXT)""")
    rows = db.q("SELECT cn, en, updated_at FROM title_map ORDER BY cn")
    builtin = _load_title_map()
    return {"ok": True, "items": rows or [],
            "builtinCount": len(getattr(__import__(
                "app.services.reel_caption", fromlist=["CN_TITLE_MAP"]),
                "CN_TITLE_MAP", {})),
            "total": len(builtin)}


@router.post("/library/title-map")
async def title_map_save(req: MapReq):
    """批量保存映射（界面里编辑后整批提交）。"""
    n = 0
    for it in req.items[:500]:
        cn = (it.cn or "").strip()
        en = (it.en or "").strip()
        if cn and en:
            _save_title_map(cn, en)
            n += 1
    return {"ok": True, "saved": n}


@router.delete("/library/title-map")
async def title_map_delete(cn: str):
    db.exec("DELETE FROM title_map WHERE cn=?", (cn,))
    return {"ok": True}
