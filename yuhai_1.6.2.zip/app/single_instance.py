# -*- coding: utf-8 -*-
"""单实例保护 —— 防止用户多次点击打开多个软件。

2026-11-13 用户反馈："多次点击会打开多次软件，修复一下只能打开一个软件"

实现：
    Windows 上用命名互斥体（CreateMutexW）。名字里带一个稳定的 key
    （数据目录哈希），这样：
      · 同一份数据目录 → 只能跑一个实例
      · 换数据目录（多开测试）→ 仍可启动，不误锁

    已有实例在跑时：
      ① 尝试调用已运行实例的 /api/system/activate 让窗口置前
      ② 返回 False，调用方应当立即退出

⚠ 不用文件锁：崩溃后残留锁文件会让软件再也起不来。
  互斥体由内核持有，进程退出自动释放，最稳。
"""
from __future__ import annotations

import hashlib
import logging
import os
import sys

log = logging.getLogger("yuhai.single")

_MUTEX_HANDLE = None          # 必须持有全局引用，否则句柄被 GC 释放
ERROR_ALREADY_EXISTS = 183


def _lock_name() -> str:
    """按数据目录生成稳定的互斥体名。

    数据目录不同 → 名字不同 → 允许多开（开发/测试需要）。
    同一数据目录 → 名字相同 → 只能一个实例。
    """
    try:
        from app.paths import DATA_DIR
        key = str(DATA_DIR)
    except Exception:
        key = os.environ.get("YUHAI_DATA_DIR") or "default"
    h = hashlib.sha1(key.lower().encode("utf-8", "replace")).hexdigest()[:16]
    return f"Global\\YuhaiWorkbench-{h}"


def acquire() -> bool:
    """尝试取得单实例锁。

    返回 True  = 我是第一个实例，继续启动
    返回 False = 已有实例在跑，调用方应退出
    非 Windows / 发生异常 → 返回 True（宁可多开也不要起不来）
    """
    global _MUTEX_HANDLE

    if os.name != "nt":
        return True

    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [
            wintypes.LPCVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE

        name = _lock_name()
        handle = kernel32.CreateMutexW(None, True, name)
        err = ctypes.get_last_error()

        if not handle:
            log.warning("CreateMutex 失败（err=%s），跳过单实例检查", err)
            return True

        if err == ERROR_ALREADY_EXISTS:
            # 已有实例持有同名互斥体
            kernel32.CloseHandle(handle)
            log.info("检测到已有实例在运行（%s）", name)
            _activate_existing()
            return False

        _MUTEX_HANDLE = handle      # 持有到进程结束
        return True
    except Exception as e:
        log.warning("单实例检查异常，继续启动: %s", e)
        return True


def _activate_existing() -> None:
    """尽力把已运行实例的窗口调到前台（失败不影响退出）。"""
    try:
        import json
        import urllib.request
        port = int(os.environ.get("YUHAI_PORT", "8710"))
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/system/activate",
            data=b"{}", method="POST",
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as r:
            json.loads(r.read(200).decode("utf-8", "replace"))
    except Exception as e:
        log.debug("激活已有实例失败: %s", e)


def release() -> None:
    """显式释放（正常退出时调用；不调用也会由内核回收）。"""
    global _MUTEX_HANDLE
    if _MUTEX_HANDLE is None or os.name != "nt":
        return
    try:
        import ctypes
        ctypes.WinDLL("kernel32").CloseHandle(_MUTEX_HANDLE)
    except Exception:
        pass
    _MUTEX_HANDLE = None


def guard_or_exit() -> None:
    """一行接入：不是首实例就打印提示并退出（退出码 0，不算故障）。"""
    if acquire():
        return
    print("雨海工作台已在运行，本次启动已取消。", file=sys.stderr)
    sys.exit(0)
