"""雨海工作台 · 后端入口。

架构：
    uvicorn (127.0.0.1:8710)  →  FastAPI app
        ├─ /api/*        REST 接口
        ├─ /static/*     前端静态资源（生产模式下前端打包进 exe 内嵌目录）
        └─ /health       探活

仅监听 127.0.0.1，不对外暴露。C++ 外壳启动时 fork 本进程，退出时回收。
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
import traceback
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.db import db, now_iso
from app.logging_setup import setup_logging

log = logging.getLogger("yuhai.app")


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    log.info("starting yuhai-workbench backend")
    log.info("data dir = %s", settings.data_dir)
    log.info("db = %s", settings.db_path)
    await db.connect()
    # 僵尸任务清理：进程重启后，上次残留的 running 状态一律标为 failed
    try:
        n = db.exec(
            "UPDATE jobs SET status='failed', error='服务重启中断', ended_at=? "
            "WHERE status IN ('running','queued')", (now_iso(),))
        if n:
            log.warning("cleared %d stale jobs from previous run", n)
    except Exception as e:
        log.debug("clear stale jobs failed: %s", e)
    from app.services.scheduler import scheduler
    await scheduler.start()

    # TK短剧用的调试浏览器：空闲自动关闭（后台巡检）
    async def _tk_reaper():
        import asyncio as _aio
        from app.services import tk_browser
        while True:
            await _aio.sleep(30)
            try:
                if tk_browser.reap_if_idle():
                    log.info("tk browser auto-closed (idle)")
            except Exception as e:
                log.debug("tk reaper: %s", e)

    try:
        import asyncio as _aio
        _reaper_task = _aio.create_task(_tk_reaper())
    except Exception as e:
        log.warning("tk reaper start failed: %s", e)
        _reaper_task = None
    # 启动自检：accounts 表空了就从环境自动补建（否则视频数据全归到「未归属主页」）
    try:
        n_acc = db.q1("SELECT COUNT(*) c FROM accounts")["c"]
        n_env = db.q1("SELECT COUNT(*) c FROM envs WHERE status<>'removed'")["c"]
        if n_acc == 0 and n_env > 0:
            from app.api.accounts import from_envs
            r = await from_envs()
            log.info("auto-created %d accounts from envs", r.get("created", 0))
    except Exception as e:
        log.warning("auto account bootstrap failed: %s", e)
    # 评论区常驻轮询
    from app.services.comment_watch import watcher
    # 全自动总控：注入运行时句柄，开关才能真的启停任务
    from app.services import automation as au
    au.bind_runtime(comment_watcher=watcher, scheduler=scheduler)
    au.ensure_defaults()
    try:
        # 总开关关着就不启动评论轮询（用户要的是「一个开关管全部」）
        if au.is_on():
            await watcher.start()
        else:
            log.info("auto master is OFF -> comment watcher not started")
    except Exception as e:
        log.warning("comment watcher failed to start: %s", e)

    # MCP session manager 必须在 application lifespan 内运行
    # （否则 streamable-http 报 "Task group is not initialized"）
    # 关键：app 和 lifespan 必须用**同一个** Starlette 实例
    _mcp_cm = None
    try:
        from app.mcp_server import get_app as _mcp_get
        _mcp_app = _mcp_get()          # 复用已挂载的那个实例
        _mcp_cm = _mcp_app.router.lifespan_context(_mcp_app)
        await _mcp_cm.__aenter__()
        log.info("MCP session manager started")
    except Exception as e:
        log.warning("MCP lifespan start failed: %s", e)
        _mcp_cm = None

    # ⭐ 自动修复 DSH headless 配置
    #   不禁用它自带的 pwsh/fs 工具时，DSH 会空转 20+ 次不碰雨海 MCP。
    #   端口按实际监听端口写，换端口后自动跟上。
    try:
        from app.services import dsh_setup as _ds
        _port = int(os.environ.get("YUHAI_PORT", "") or settings.port or 8710)
        _r = _ds.install(port=_port)
        if _r.get("ok"):
            if _r.get("skipped"):
                log.info("DSH profile 已配置好 (port=%s)", _port)
            else:
                log.info("DSH profile 已修复 (port=%s)", _port)
        else:
            log.debug("DSH profile 跳过: %s", _r.get("error"))
    except Exception as _de:
        log.debug("DSH profile 配置失败: %s", _de)

    yield

    if _mcp_cm is not None:
        try:
            await _mcp_cm.__aexit__(None, None, None)
        except Exception:
            pass
    log.info("shutting down")
    from app.services.comment_watch import watcher as cw
    try:
        await cw.stop()
    except Exception:
        pass
    from app.services.scheduler import scheduler
    try:
        await scheduler.stop()
    except Exception as _e:
        log.warning("scheduler.stop 失败（忽略，不影响关闭）: %s", _e)
    try:
        await db.close()
    except Exception as _e:
        log.warning("db.close 失败（忽略）: %s", _e)


app = FastAPI(
    title="雨海工作台",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)

# WebView2 / 本地调试都需要；只监听回环，且允许 file:// null origin
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^(https?://(127\.0\.0\.1|localhost)(:\d+)?|file://.*|null)$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------- 全局异常包装 ----------------
@app.exception_handler(Exception)
async def on_error(request: Request, exc: Exception):
    tb = traceback.format_exc()
    log.error("unhandled error on %s %s\n%s", request.method, request.url.path, tb)
    return JSONResponse(
        status_code=500,
        content={"ok": False, "error": str(exc)[:400], "path": request.url.path},
    )


@app.middleware("http")
async def timing(request: Request, call_next):
    t0 = time.perf_counter()
    resp = await call_next(request)
    dt = (time.perf_counter() - t0) * 1000
    if dt > 800:
        log.warning("slow %.0fms %s %s", dt, request.method, request.url.path)
    resp.headers["X-Elapsed-Ms"] = f"{dt:.1f}"
    return resp


# ---------------- 路由 ----------------
from app.api import (  # noqa: E402
    envs, authz, pages, insights, publish, mail, library, schedule,
    integrations, jobs, system, videos, guard_api, ai, accounts, links, comments,
    video, captpl, slice as slice_api, auto as auto_api,
    platform as platform_api, reels as reels_api, update as update_api,
    agent as agent_api, dl as dl_api, groups as groups_api,
    organize as organize_api,
)
# grab 路由 2026-11-12 从 app/legacy/api/ 迁回正式目录。
# 它的实现一直是 app.services.grab（见文件里的 import），放 legacy 只是历史遗留。
try:
    from app.api import grab as grab_api
except Exception as _e:  # 抓剧功能缺依赖时不要让整个后端起不来
    grab_api = None
    log.warning("grab 路由加载失败（抓剧页不可用）: %s", _e)

for mod in (system, envs, pages, authz, insights, publish, mail, library,
            schedule, integrations, jobs, videos, guard_api, ai, accounts, links,
            comments, video, captpl, slice_api, auto_api, platform_api,
            reels_api, update_api, agent_api, dl_api, groups_api, organize_api):

    app.include_router(mod.router, prefix="/api")

if grab_api is not None:
    app.include_router(grab_api.router, prefix="/api")


@app.get("/health")
async def health():
    """健康检查。

    version 读 data/version.json（热更新后会自动更新），
    读不到才退回 FastAPI 的静态版本号。
    """
    ver = app.version
    updated = ""
    try:
        import json as _json
        from pathlib import Path as _P
        from app.services import updater as _up
        vf = _up.version_file()
        if vf.exists():
            d = _json.loads(vf.read_text(encoding="utf-8"))
            ver = d.get("version") or ver
            updated = d.get("updatedAt") or ""
    except Exception:
        pass
    return {"ok": True, "version": ver, "updatedAt": updated,
            "ts": int(time.time() * 1000)}


# ---------------- MCP 服务（供外部 Agent 连入） ----------------
# 必须在静态前端 "/" 之前挂载，否则会被 StaticFiles 吞掉
try:
    from app.mcp_server import get_app as _mcp_get_app
    # 自动注册：把所有 REST 端点变成 MCP 工具（新功能自动可用）
    try:
        from app.mcp_server import mcp as _mcp_obj
        from app import mcp_autoreg as _autoreg
        _r = _autoreg.register_all(
            app, _mcp_obj,
            skip_prefixes=["/api/agent"])   # agent 已有手写工具
        log.info("自动注册 %d 个端点工具", len(_r.get("registered") or []))
    except Exception as _ae:
        log.warning("自动注册失败: %s", _ae)

    # streamable_http_path="/" → 挂到 /mcp 后实际地址就是 /mcp
    app.mount("/mcp", _mcp_get_app())
    log.info("MCP mounted at /mcp")
except Exception as _e:
    log.warning("MCP mount failed: %s", _e)


def _real_port(request=None) -> int:
    """拿当前服务真实监听的端口。

    优先级：
      ① 请求的 Host 头 / server 元组（最准，反映实际监听端口）
      ② 环境变量 YUHAI_PORT
      ③ settings.port（兜底）
    """
    # ① 从请求里拿
    if request is not None:
        try:
            # scope["server"] = (host, port)
            srv = request.scope.get("server")
            if srv and len(srv) >= 2 and srv[1]:
                return int(srv[1])
        except Exception:
            pass
        try:
            host = request.headers.get("host", "")
            if ":" in host:
                return int(host.rsplit(":", 1)[1])
        except Exception:
            pass

    # ② 环境变量
    try:
        v = os.environ.get("YUHAI_PORT", "")
        if v:
            return int(v)
    except Exception:
        pass

    # ③ 兜底
    try:
        return int(settings.port)
    except Exception:
        return 8710


@app.get("/api/mcp/info")
async def mcp_info(request: Request):
    """给前端/用户看：MCP 地址 + 工具清单（用于接入外部 Agent）。"""
    try:
        from app.mcp_server import mcp as _m
        tools = await _m.list_tools()
        port = _real_port(request)
        return {
            "ok": True,
            "url": f"http://127.0.0.1:{port}/mcp/",
            "transport": "streamable-http",
            "tools": [{"name": t.name, "description": t.description}
                      for t in tools],
            "count": len(tools),
            "config_example": {
                "mcpServers": {
                    "yuhai": {
                        "url": f"http://127.0.0.1:{port}/mcp/",
                        "transport": "streamable-http",
                    }
                }
            },
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:120]}


# ---------------- 静态前端 ----------------
frontend = settings.frontend_dir
if frontend.exists():
    app.mount("/", StaticFiles(directory=str(frontend), html=True), name="web")
else:
    log.warning("frontend dir not found: %s", frontend)

    @app.get("/")
    async def root():
        return {"ok": True, "msg": "frontend not bundled", "api": "/api/docs"}


def main():
    import uvicorn
    # ⚠ 单实例保护（2026-11-13 用户要求"只能打开一个软件"）：
    #   已有实例在跑就直接退出，并尝试把那个窗口调到前台。
    from app.single_instance import guard_or_exit
    guard_or_exit()

    port = _real_port()
    if settings.is_frozen:
        # 打包后不开 reload、不写 access log
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
    else:
        uvicorn.run("app.main:app", host="127.0.0.1", port=port, reload=False,
                    log_level="info")


if __name__ == "__main__":
    main()
