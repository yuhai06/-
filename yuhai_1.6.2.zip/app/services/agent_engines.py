# -*- coding: utf-8 -*-
"""agent_engines.py — 多 agent 引擎驱动

支持在软件内直接指挥各种外部 agent CLI：

  dsh        DeepSeek Harness      dsh --profile headless --json "任务"
  claude     Claude Code            claude -p "任务" --output-format stream-json
  codex      Codex CLI              codex exec --json "任务"
  workbuddy  WorkBuddy              workbuddy ...
  aider      Aider                  aider --message "任务" --yes
  gemini     Gemini CLI             gemini -p "任务"

设计
----
每个引擎一个 spec：
  {
    "id": "dsh",
    "name": "DSH",
    "bin": ["dsh.cmd", "dsh"],          探测用的可执行名
    "args": [...],                        命令行模板，{task} 会替换
    "format": "ndjson" | "text",          输出格式
    "parse": fn(line) -> event | None     解析单行
    "env": {...}                          额外环境变量
  }

统一事件格式（与前端 SSE 一致）：
  ("session",  {"sessionId": ...})
  ("thinking", {"text": ...})
  ("tool_start", {"tool": ..., "args": {...}})
  ("tool_end",   {"tool": ..., "ok": bool, "ms": int, "result": str})
  ("reply",    {"content": ...})
  ("done",     {"ok": bool, "reply": ..., "sessionId": ...})
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path

log = logging.getLogger("yuhai.agent.engines")

# ── 运行状态 ──
# key = "<engine>:<chatId>"  →  每个对话一个独立进程，互不干扰
_STOP: dict = {}         # key -> threading.Event
_CUR: dict = {}          # key -> Popen
_LOCK = threading.Lock()


def _key(engine_id: str, chat_id: str = "") -> str:
    return "%s:%s" % (engine_id or "dsh", chat_id or "_default")


def _stop_evt(key: str) -> threading.Event:
    with _LOCK:
        ev = _STOP.get(key)
        if ev is None:
            ev = threading.Event()
            _STOP[key] = ev
        return ev


def _no_window() -> int:
    return 0x08000000 if os.name == "nt" else 0


def _find_bin(names: list[str]) -> str:
    """按候选名找可执行文件，返回完整路径或空串。"""
    for n in names:
        # 1) 常见安装位置
        cands = [
            os.path.expandvars(rf"%USERPROFILE%\.local\bin\{n}"),
            os.path.expandvars(rf"%APPDATA%\npm\{n}"),
            os.path.expandvars(rf"%LOCALAPPDATA%\Programs\{n}"),
        ]
        for c in cands:
            if os.path.isfile(c):
                return c
        # 2) PATH
        w = shutil.which(n)
        if w:
            return w
    return ""


# ══════════════════════════════════════════════════════════
# 引擎定义
# ══════════════════════════════════════════════════════════

def _parse_dsh(line: str) -> dict | None:
    """DSH --json：NDJSON 事件。"""
    try:
        ev = json.loads(line)
    except Exception:
        return None
    t = ev.get("type")
    if t == "session":
        return {"stage": "session",
                "payload": {"sessionId": ev.get("sessionId", "")}}
    if t == "thinking":
        txt = ev.get("text") or ""
        return {"stage": "thinking", "payload": {"text": txt[:2000]}} if txt else None
    if t == "tool_call":
        name = (ev.get("tool") or "").replace("mcp__yuhai__", "")
        return {"stage": "tool_start",
                "payload": {"tool": name, "args": ev.get("input") or {},
                            "callId": ev.get("callId", "")}}
    if t == "tool_result":
        res = ev.get("result")
        if isinstance(res, (dict, list)):
            res = json.dumps(res, ensure_ascii=False)
        return {"stage": "tool_end",
                "payload": {"tool": "", "ok": ev.get("status") != "failed",
                            "ms": 0, "result": str(res or "")[:4000],
                            "callId": ev.get("callId", "")}}
    if t == "text":
        txt = ev.get("text") or ""
        return {"stage": "reply", "payload": {"content": txt}} if txt else None
    if t == "final":
        reason = (ev.get("reason") or {}).get("kind") or ""
        return {"stage": "done",
                "payload": {"ok": reason in ("completed", "", "success"),
                            "reply": ev.get("text") or "",
                            "sessionId": ev.get("sessionId", ""),
                            "reason": reason}}
    if t == "error":
        return {"stage": "done",
                "payload": {"ok": False,
                            "error": str(ev.get("text") or ev.get("error") or "")[:300]}}
    return None


def _parse_claude(line: str) -> dict | None:
    """Claude Code --output-format stream-json。"""
    try:
        ev = json.loads(line)
    except Exception:
        return None
    t = ev.get("type")
    if t == "system" and ev.get("subtype") == "init":
        return {"stage": "session",
                "payload": {"sessionId": ev.get("session_id", "")}}
    if t == "assistant":
        msg = ev.get("message") or {}
        for blk in (msg.get("content") or []):
            if blk.get("type") == "tool_use":
                return {"stage": "tool_start",
                        "payload": {"tool": blk.get("name", ""),
                                    "args": blk.get("input") or {},
                                    "callId": blk.get("id", "")}}
            if blk.get("type") == "text" and blk.get("text"):
                return {"stage": "reply",
                        "payload": {"content": blk["text"]}}
    if t == "user":
        msg = ev.get("message") or {}
        for blk in (msg.get("content") or []):
            if blk.get("type") == "tool_result":
                c = blk.get("content")
                if isinstance(c, (dict, list)):
                    c = json.dumps(c, ensure_ascii=False)
                return {"stage": "tool_end",
                        "payload": {"tool": "", "ok": not blk.get("is_error"),
                                    "ms": 0, "result": str(c or "")[:4000],
                                    "callId": blk.get("tool_use_id", "")}}
    if t == "result":
        return {"stage": "done",
                "payload": {"ok": not ev.get("is_error"),
                            "reply": ev.get("result") or "",
                            "sessionId": ev.get("session_id", "")}}
    return None


def _parse_codex(line: str) -> dict | None:
    """Codex exec --json。"""
    try:
        ev = json.loads(line)
    except Exception:
        return None
    t = ev.get("type") or ev.get("event")
    if t in ("exec_begin", "thread.started"):
        return {"stage": "session",
                "payload": {"sessionId": ev.get("thread_id") or ev.get("id", "")}}
    if t == "item.started" or t == "exec_command_begin":
        it = ev.get("item") or {}
        return {"stage": "tool_start",
                "payload": {"tool": it.get("type") or "exec",
                            "args": it.get("command") or ev.get("command") or {},
                            "callId": it.get("id", "")}}
    if t == "item.completed" or t == "exec_command_end":
        it = ev.get("item") or {}
        if (it.get("type") == "agent_message") or ev.get("output"):
            txt = it.get("text") or ev.get("stdout") or ""
            if txt:
                return {"stage": "reply", "payload": {"content": str(txt)[:4000]}}
        return {"stage": "tool_end",
                "payload": {"tool": it.get("type") or "exec", "ok": True,
                            "ms": 0, "result": str(ev.get("stdout") or "")[:4000],
                            "callId": it.get("id", "")}}
    if t in ("turn.completed", "task_complete"):
        return {"stage": "done",
                "payload": {"ok": True,
                            "reply": ev.get("last_agent_message") or "",
                            "sessionId": ev.get("thread_id", "")}}
    return None


def _parse_text(line: str) -> dict | None:
    """纯文本流：每行当输出。"""
    s = line.strip()
    if not s:
        return None
    return {"stage": "reply", "payload": {"content": s}}


# 引擎清单
ENGINES: list[dict] = [
    {
        "id": "dsh", "name": "DSH",
        "desc": "DeepSeek Harness，走 MCP 116 工具",
        "bins": ["dsh.cmd", "dsh.exe", "dsh"],
        "args": ["--profile", "headless", "--approval-policy", "never", "--json", "{task}"],
        "argsWithSession": ["--profile", "headless", "--approval-policy", "never",
                            "--json", "--session-id", "{sid}", "{task}"],
        "parse": _parse_dsh,
        "needEnv": ["DEEPSEEK_API_KEY"],
        "setupHint": "改 ~/.dsh/profiles/headless/cordis.patch.yml 加 mcp-yuhai",
    },
    {
        "id": "claude", "name": "Claude Code",
        "desc": "Anthropic 官方 CLI",
        "bins": ["claude.cmd", "claude.exe", "claude"],
        "args": ["-p", "{task}", "--output-format", "stream-json",
                 "--verbose", "--dangerously-skip-permissions"],
        "argsWithSession": ["-p", "{task}", "--output-format", "stream-json",
                            "--verbose", "--dangerously-skip-permissions",
                            "--resume", "{sid}"],
        "parse": _parse_claude,
        "needEnv": ["ANTHROPIC_API_KEY"],
        "setupHint": "claude mcp add yuhai --transport http http://127.0.0.1:PORT/mcp/",
    },
    {
        "id": "codex", "name": "Codex CLI",
        "desc": "OpenAI Codex 命令行",
        "bins": ["codex.cmd", "codex.exe", "codex"],
        "args": ["exec", "--json", "--skip-git-repo-check", "{task}"],
        "argsWithSession": ["exec", "--json", "--skip-git-repo-check", "{task}"],
        "parse": _parse_codex,
        "needEnv": ["OPENAI_API_KEY"],
        "setupHint": "codex 配置里加 mcp_servers.yuhai",
    },
    {
        "id": "workbuddy", "name": "WorkBuddy",
        "desc": "独立审查/执行 agent",
        "bins": ["workbuddy.cmd", "workbuddy.exe", "workbuddy"],
        "args": ["--print", "{task}"],
        "argsWithSession": ["--print", "{task}"],
        "parse": _parse_text,
        "needEnv": [],
        "setupHint": "在 WorkBuddy 配置里挂 MCP",
    },
    {
        "id": "aider", "name": "Aider",
        "desc": "终端 AI 编程助手",
        "bins": ["aider.exe", "aider"],
        "args": ["--message", "{task}", "--yes", "--no-auto-commits"],
        "argsWithSession": ["--message", "{task}", "--yes", "--no-auto-commits"],
        "parse": _parse_text,
        "needEnv": [],
        "setupHint": "aider 不支持 MCP，只能读写文件",
    },
    {
        "id": "gemini", "name": "Gemini CLI",
        "desc": "Google Gemini 命令行",
        "bins": ["gemini.cmd", "gemini.exe", "gemini"],
        "args": ["-p", "{task}"],
        "argsWithSession": ["-p", "{task}"],
        "parse": _parse_text,
        "needEnv": ["GEMINI_API_KEY"],
        "setupHint": "gemini 配置里挂 MCP",
    },
]


def engine_by_id(eid: str) -> dict | None:
    for e in ENGINES:
        if e["id"] == eid:
            return e
    return None


def _api_key(engine_id: str = "dsh") -> str:
    """读 API key：环境变量 → 各家的凭据文件。"""
    e = engine_by_id(engine_id) or {}
    for k in (e.get("needEnv") or []):
        v = os.environ.get(k, "").strip()
        if v:
            return v
        # 从配置文件抠
        for p in [
            Path.home() / ".dsh" / ".credentials.yaml",
            Path.home() / ".config" / "claude" / "config.json",
            Path.home() / ".codex" / "config.toml",
        ]:
            if not p.exists():
                continue
            try:
                txt = p.read_text(encoding="utf-8", errors="replace")
                for ln in txt.split("\n"):
                    if k in ln:
                        val = ln.split(":", 1)[-1].strip().strip("'\"")
                        if val and len(val) > 8:
                            return val
            except Exception:
                pass
    return ""


def list_engines() -> list[dict]:
    """列出所有引擎及其可用状态。"""
    out = []
    for e in ENGINES:
        path = _find_bin(e["bins"])
        ok = bool(path)
        item = {
            "id": e["id"], "name": e["name"], "desc": e["desc"],
            "available": ok, "path": path or "",
            "needEnv": e.get("needEnv") or [],
            "hasKey": bool(_api_key(e["id"])) if e.get("needEnv") else True,
            "setupHint": e.get("setupHint") or "",
        }
        if ok:
            try:
                r = subprocess.run([path, "--version"], capture_output=True,
                                   text=True, timeout=12,
                                   creationflags=_no_window())
                item["version"] = (r.stdout or r.stderr or "").strip().split("\n")[0][:60]
            except Exception:
                item["version"] = ""
        out.append(item)
    return out


def _kill_tree(pid: int) -> bool:
    """按进程树强杀（Windows taskkill /T /F）。

    dsh.cmd 是批处理，真正干活的是它拉起的 node.exe 子进程。
    只 terminate 批处理父进程 → node 会变成孤儿继续跑，
    这就是"点了停止但任务还在继续"的原因。
    """
    if not pid:
        return False
    if os.name == "nt":
        try:
            r = subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True, text=True, timeout=10,
                creationflags=_no_window())
            ok = r.returncode == 0
            if not ok:
                log.debug("taskkill %s rc=%s %s", pid, r.returncode,
                          (r.stderr or r.stdout or "")[:120])
            return ok
        except Exception as e:
            log.debug("taskkill %s failed: %s", pid, e)
            return False
    else:
        try:
            os.killpg(os.getpgid(pid), 9)
            return True
        except Exception:
            try:
                os.kill(pid, 9)
                return True
            except Exception:
                return False


def _kill_stray_dsh() -> int:
    """清理所有 headless dsh 进程（含 node 子进程）。返回杀掉的数量。"""
    n = 0
    if os.name != "nt":
        return 0
    try:
        # ⚠ 只杀 headless 任务的进程。
        #   绝不能匹配 "dsh-primary-runtime.*node" —— 那是 DSH 本体的
        #   runtime，误杀会让用户正在用的 DSH 会话/工作台一起挂掉。
        ps = (
            "Get-CimInstance Win32_Process | "
            "Where-Object { "
            "  $_.Name -eq 'node.exe' -and "
            "  $_.CommandLine -match 'headless' -and "
            "  $_.CommandLine -notmatch 'DeepSeek Harness' "
            "} | ForEach-Object { $_.ProcessId }"
        )
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, text=True, timeout=15,
                           creationflags=_no_window())
        pids = [int(x.strip()) for x in (r.stdout or "").split()
                if x.strip().isdigit()]
        # 二次过滤：排除自己和自己所在的进程树
        try:
            my_pid = os.getpid()
            pids = [x for x in pids if x != my_pid]
        except Exception:
            pass
        for p_ in pids:
            try:
                subprocess.run(["taskkill", "/PID", str(p_), "/T", "/F"],
                               capture_output=True, timeout=8,
                               creationflags=_no_window())
                n += 1
            except Exception:
                pass
    except Exception as e:
        log.debug("kill stray: %s", e)
    return n


def request_stop(engine_id: str = "", reason: str = "用户停止",
                 chat_id: str = "") -> dict:
    """停止指定会话的当前任务。

    chat_id 给了 → 只停那个对话的进程
    chat_id 没给 → 停该引擎的所有会话

    顺序：
      1. 置停止标志（让读循环尽快退出）
      2. 按进程树强杀（父批处理 + node 子进程）
      3. 兜底清理残留 headless dsh
    """
    with _LOCK:
        if chat_id:
            k = _key(engine_id, chat_id)
            targets = [_CUR.get(k)]
            ev = _STOP.get(k)
            keys = [k]
        elif engine_id:
            keys = [k for k in _CUR if k.startswith(engine_id + ":")]
            targets = [_CUR.get(k) for k in keys]
            if not keys:
                targets = list(_CUR.values())
                keys = list(_CUR.keys())
        else:
            keys = list(_CUR.keys())
            targets = list(_CUR.values())

        for k in keys:
            e = _STOP.get(k)
            if e:
                e.set()

    killed = []
    for p in targets:
        if not p:
            continue
        pid = getattr(p, "pid", None)
        if not pid:
            continue
        # 先按树杀
        if _kill_tree(pid):
            killed.append(pid)
        # 再走 python 层兜底
        try:
            p.terminate()
            time.sleep(0.2)
            if p.poll() is None:
                p.kill()
        except Exception:
            pass
        killed.append(pid)

    # 兜底：清理所有残留（防止孤儿 node）
    stray = _kill_stray_dsh()

    log.warning("停止 agent(%s): %s | 杀进程 %s | 清理残留 %d",
                engine_id or "*", reason, killed, stray)

    return {"ok": True, "stopped": True,
            "killedPids": killed, "strayCleaned": stray}


def is_stopped(engine_id: str = "", chat_id: str = "") -> bool:
    """查是否被要求停止。不传参 = 任一会话在停。"""
    if engine_id or chat_id:
        ev = _STOP.get(_key(engine_id, chat_id))
        return bool(ev and ev.is_set())
    with _LOCK:
        return any(e.is_set() for e in _STOP.values())


def run(engine_id: str, task: str, session_id: str = "",
        on_event=None, timeout_s: int = 3600,
        chat_id: str = "") -> dict:
    """跑一次指定引擎的任务，逐事件回调。

    chat_id：会话标识。每个对话用独立键，
            这样同一引擎可以多对话并行、各停各的。
    """
    e = engine_by_id(engine_id)
    if not e:
        return {"ok": False, "error": "未知引擎: " + engine_id}

    path = _find_bin(e["bins"])
    if not path:
        return {"ok": False,
                "error": "%s 未安装（找不到 %s）" % (e["name"], e["bins"][0])}

    k = _key(engine_id, chat_id)

    # ⭐ 同一个对话不允许并发（不同对话可以并行）
    with _LOCK:
        running = _CUR.get(k)
    if running is not None:
        try:
            alive = running.poll() is None
        except Exception:
            alive = False
        if alive:
            return {
                "ok": False,
                "error": "这个对话的上一个任务还在跑（PID %s），"
                         "请先点停止或等它结束" % getattr(running, "pid", "?"),
                "busy": True, "chatId": chat_id,
            }
        else:
            with _LOCK:
                _CUR.pop(k, None)

    stop_evt = _stop_evt(k)
    stop_evt.clear()

    # ⭐ 约束放在任务后面（放前面会喧宾夺主，
    #   DSH 会把"规则"当成任务本身去确认，而不是执行真正的任务）
    #
    # 分工原则：不是"只能用雨海"，而是"各用各的强项"
    # ⭐ 约束放在任务后面（放前面会喧宾夺主，
    #   DSH 会把"规则"当成任务本身去确认，而不是执行真正的任务）
    #
    # 分工原则：不是"只能用雨海"，而是"各用各的强项"
    # ⭐ 工具使用优先级（用户明确要求）：
    #   1. 能用雨海工具就必须用雨海工具
    #   2. 雨海工具用不了 → 告诉用户，不能自己绕过去
    #   3. 雨海确实没有这个能力 → 才用电脑上的工具
    # ⭐ 工具使用优先级（用户明确要求的三级规则）：
    #   1. 雨海有 → 必须用雨海的
    #   2. 雨海有但失败了 → 停下告诉用户
    #   3. 雨海没有 → 自己判断，直接用电脑上的工具，不用问
    _RULES = [
        "",
        "---",
        "【工具使用优先级】",
        "",
        "① 雨海有这个能力 → 必须用雨海的，不要用电脑上的替代",
        "    下载剧集   → dl_tk_eps",
        "    切片出片   → slice_run（mode 传 auto）",
        "    发布视频   → publish_batch / publish_files",
        "    查主页     → publish_pages / page_list",
        "    数据采集   → data_collect / data_overview",
        "    读文件     → fs_read / fs_list / fs_grep / fs_table / fs_find",
        "    下载台账   → dl_ledger_of / dl_ledger_list",
        "    内核状态   → pub_state / pub_used_list / env_running",
        "    剧型判断   → drama_find / drama_stats",
        "",
        "② 雨海有、但调用失败 → 停下来告诉用户，不要自己绕路",
        "    报清楚：哪个工具、报了什么错、缺什么才能继续。",
        "    不准用 pwsh 拼命令行去模拟雨海工具的活（会绕过台账、去重、",
        "    文案模板、任务记录，等于白干）。",
        "    除非用户明确说「绕过它」，否则就是报告，不是绕路。",
        "",
        "③ 雨海根本没有这个能力 → 你自己判断就行，直接用电脑上的工具，不用问",
        "    这一类不需要请示，直接干：",
        "    · 打开/操作浏览器标签、CDP 脚本 → pwsh",
        "    · git / npm / pip / venv / uv → pwsh",
        "    · 批量重命名目录、清理磁盘、查系统信息、算文件哈希 → pwsh",
        "    · 查网上资料 → web_search / web_fetch",
        "    · 后台跑长任务 → job_list / job_output / job_kill",
        "    · 调外部命令行工具、跑你自己写的脚本 → pwsh",
        "",
        "怎么判断走哪条：先在雨海工具清单里找一遍。",
        "    找到了、能用     → 用雨海的（①）",
        "    找到了、报错了   → 告诉用户，等指示（②）",
        "    清单里根本没有   → 自己判断，直接用电脑工具（③，不用问）",
        "",
        "现在就动手做，不要只回复说准备好了。",
    ]
    SUFFIX = "\n".join(_RULES)
    SUFFIX = "\n".join(_RULES)
    SUFFIX = "\n".join(_RULES)
    full_task = task + SUFFIX

    # 命令
    template = e["argsWithSession"] if session_id else e["args"]
    cmd = [path]
    for a in template:
        a = a.replace("{task}", full_task).replace("{sid}", session_id)
        cmd.append(a)

    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    key = _api_key(engine_id)
    for k in (e.get("needEnv") or []):
        if key:
            env[k] = key

    def emit(stage, payload=None):
        if on_event:
            try:
                on_event(stage, payload or {})
            except Exception:
                pass

    # ⭐ 清理残留（上次被杀但 node 子进程没死透的）
    _stray = _kill_stray_dsh()
    if _stray:
        log.info("启动前清理 %d 个残留 dsh 进程", _stray)

    log.info("跑 %s: %s ...", engine_id, " ".join(cmd[:5]))

    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            bufsize=1, env=env, creationflags=_no_window())
    except Exception as ex:
        return {"ok": False, "error": "启动失败: " + str(ex)[:150]}

    with _LOCK:
        _CUR[k] = proc

    parser = e["parse"]
    final_text = ""
    new_sid = session_id
    ok = False
    error = ""
    tool_names: dict = {}      # callId -> tool name（tool_end 补名用）
    t0 = time.time()
    got_done = False

    try:
        for raw in proc.stdout:      # type: ignore
            if stop_evt.is_set():
                break
            if time.time() - t0 > timeout_s:
                error = "超时"
                try:
                    proc.kill()
                except Exception:
                    pass
                break

            line = (raw or "").strip()
            if not line:
                continue

            ev = parser(line)
            if not ev:
                continue

            st, pl = ev["stage"], ev["payload"]

            if st == "session":
                new_sid = pl.get("sessionId") or new_sid

            if st == "tool_start":
                tool_names[pl.get("callId", "")] = pl.get("tool", "")
            elif st == "tool_end":
                cid = pl.get("callId", "")
                if not pl.get("tool"):
                    pl["tool"] = tool_names.get(cid, "tool")

            emit(st, pl)

            if st == "reply":
                final_text = pl.get("content") or final_text
            elif st == "done":
                final_text = pl.get("reply") or final_text
                new_sid = pl.get("sessionId") or new_sid
                ok = pl.get("ok", True)
                error = pl.get("error") or error
                got_done = True
                break        # 收到结束立即退出，不等 EOF

    except Exception as ex:
        error = "%s: %s" % (type(ex).__name__, str(ex)[:150])
    finally:
        with _LOCK:
            _CUR.pop(k, None)

        # ⚠ 顺序很重要：必须先让进程退出，再关管道。
        #   反过来会 BrokenPipeError（进程还在写，管道已关），
        #   整个 run() 崩掉 → 前端看到"执行失败"。
        try:
            if proc.poll() is None:
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    try:
                        proc.wait(timeout=2)
                    except Exception:
                        pass
        except Exception:
            pass

        # 进程已退出，这时读 stderr 不会阻塞
        err_tail = ""
        if proc.stderr and not error:
            try:
                import threading as _th
                box = {}

                def _rd():
                    try:
                        box["v"] = proc.stderr.read() or ""
                    except Exception:
                        box["v"] = ""

                t = _th.Thread(target=_rd, daemon=True)
                t.start()
                t.join(timeout=2.0)
                err_tail = (box.get("v") or "").strip()
            except Exception:
                err_tail = ""

            if err_tail:
                for ln in err_tail.split("\n"):
                    ls = ln.strip()
                    if not ls:
                        continue
                    if any(k in ls for k in ("Error", "error", "MISSING",
                                             "not found", "failed", "Exception",
                                             "ENOENT", "ECONNREFUSED")):
                        error = error or ls[:280]
                        break

        # 关管道（进程已死，安全）
        for f in ("stdout", "stderr"):
            try:
                fp = getattr(proc, f, None)
                if fp:
                    fp.close()
            except Exception:
                pass

    if stop_evt.is_set():
        return {"ok": False, "stopped": True, "error": "已停止",
                "reply": final_text, "sessionId": new_sid}

    if not got_done and not final_text and not error:
        # 拿到退出码辅助判断
        try:
            rc = proc.returncode
        except Exception:
            rc = None
        error = "引擎没有返回内容" + (
            "（退出码 %s）" % rc if rc not in (None, 0) else "")

    return {"ok": ok or bool(final_text), "reply": final_text,
            "sessionId": new_sid, "error": error,
            "elapsed": round(time.time() - t0, 1)}
