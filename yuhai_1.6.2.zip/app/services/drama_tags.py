# -*- coding: utf-8 -*-
"""剧集自由打标签 —— 2026-11-13 用户需求。

用户原话：
    "判断的准吗，我建议不要局限于分类直接让模型自由判断打标签不要乱打
     看剧里面的全部视频内容的信息打，同一个剧可以打多个标签但是判断的要
     符合，类型绑定就直接选择有这个标签的"

设计要点：
    ① **不预设分类**：不给模型候选列表，让它自己总结标签
       （因为预设分类装不下真实内容，强行归类会打偏）
    ② **看全部内容**：喂给模型的是字幕/台词片段（转录产物），
       不是只看文件名或简介
    ③ **一剧多标签**：允许 3-8 个标签，覆盖不同维度
       （题材/人物关系/情绪/节奏/结局类型等）
    ④ **宁缺毋滥**：prompt 里明确"不确定就不要打"，
       标签必须能从内容里找到依据
    ⑤ 结果存 drama_tags 表，主页绑定按标签筛选（有交集即命中）

数据来源：
    · 转录文件（tools 产出的 *.txt / *.json 台词）
    · 没有转录时退回：剧名 + 集数 + 时长等元数据（并标记 confidence 低）
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.tags")

# 标签数量约束（自由生成，但防止模型乱刷）
MIN_TAGS = 3
MAX_TAGS = 8


def ensure_schema() -> None:
    """建表：一剧多行（每行一个标签），方便按标签反查主页。"""
    db.exec("""CREATE TABLE IF NOT EXISTS drama_tags(
                drama     TEXT NOT NULL,
                tag       TEXT NOT NULL,
                weight    REAL DEFAULT 1.0,
                reason    TEXT DEFAULT '',
                source    TEXT DEFAULT '',
                model     TEXT DEFAULT '',
                updated_at TEXT,
                PRIMARY KEY(drama, tag))""")
    db.exec("""CREATE INDEX IF NOT EXISTS idx_drama_tags_tag
               ON drama_tags(tag)""")


def _cache_dir() -> Path:
    """标签用的转录缓存目录（data/work/tags）。"""
    try:
        from app.paths import DATA_DIR
        d = Path(DATA_DIR) / "work" / "tags"
    except Exception:
        d = Path(".") / "_tags_cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


def transcribe_drama(drama: str, max_episodes: int = 2,
                     timeout: float = 600.0) -> str:
    """转录该剧的前几集，返回合并后的台词文本（并缓存）。

    2026-11-13：库里没有现成转录文件时，用 tools/transcribe_audio.py
    现场转录。只抽 1-2 集（足够判断题材，不必全转），结果缓存到
    data/work/tags/<剧名>.txt，下次直接用。

    ⚠ 用户要求"看剧里面的全部视频内容的信息打" —— 单集台词已经能
      覆盖题材/人物/冲突/情绪，比只看文件名可靠得多。全 20 集转录
      成本太高（每集约 2-3 分钟），这里默认抽 2 集。
    """
    safe = re.sub(r"[^\w\u4e00-\u9fff\-]+", "_", drama)[:80]
    cache = _cache_dir() / f"{safe}.txt"
    if cache.exists():
        try:
            txt = cache.read_text(encoding="utf-8", errors="replace")
            if len(txt.strip()) >= 200:
                return txt
        except Exception:
            pass

    # 找该剧的视频文件（取前 N 集）
    rows = db.q("""SELECT path FROM library
                    WHERE drama=? AND state='ready'
                      AND path IS NOT NULL AND path<>''
                    ORDER BY ep ASC LIMIT ?""", (drama, max_episodes))
    files = [r["path"] for r in rows if r.get("path") and Path(r["path"]).exists()]
    if not files:
        return ""

    script = None
    try:
        from app.paths import tools_dir
        for name in ("transcribe_audio.py", "transcribe.py"):
            p = tools_dir() / name
            if p.exists():
                script = p
                break
    except Exception:
        pass

    if not script:
        log.warning("找不到 transcribe_audio.py，无法现场转录")
        return ""

    import subprocess
    import sys as _sys

    out_dir = _cache_dir() / f"{safe}_raw"
    out_dir.mkdir(parents=True, exist_ok=True)

    texts: list[str] = []
    for f in files:
        try:
            cmd = [_sys.executable, str(script), f, "--out", str(out_dir)]
            r = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=timeout, encoding="utf-8",
                               errors="replace")
            if r.returncode != 0:
                log.debug("转录失败 %s: %s", Path(f).name, (r.stderr or "")[:200])
        except Exception as e:
            log.debug("转录异常 %s: %s", Path(f).name, e)

    # 从输出目录里收集文本
    for p in sorted(out_dir.glob("*")):
        try:
            if p.suffix.lower() == ".txt":
                texts.append(p.read_text(encoding="utf-8", errors="replace"))
            elif p.suffix.lower() == ".json":
                data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
                items = data if isinstance(data, list) else (
                    data.get("segments") or data.get("lines") or [])
                for it in items[:400]:
                    t = it.get("text", "") if isinstance(it, dict) else str(it)
                    if t.strip():
                        texts.append(t.strip())
        except Exception:
            continue

    merged = "\n".join(x.strip() for x in texts if x and x.strip())
    if merged:
        try:
            cache.write_text(merged, encoding="utf-8")
        except Exception:
            pass
    return merged


def _transcript_for(drama: str, auto_transcribe: bool = True) -> str:
    """找这部剧的转录文本（台词），返回前若干字符。

    优先级：
      ① tools 目录下 <剧名>*.txt / *.json（已转录的）
      ② data/work/tags/<剧名>.txt（本服务缓存）
      ③ 现场转录（auto_transcribe=True，抽 2 集）
    """
    try:
        from app.paths import tools_dir
    except Exception:
        tools_dir = None

    safe = re.sub(r"[^\w\u4e00-\u9fff\-]+", "_", drama)[:80]
    cands: list[Path] = []

    # ① 工具目录下的转录产物
    try:
        td = tools_dir()
        for pat in (f"{safe}*.txt", f"{safe}*.json",
                    f"*{safe}*transcript*.txt", f"*{safe}*lines*.json"):
            cands.extend(td.glob(pat))
    except Exception:
        pass

    # ② 本服务缓存
    try:
        cache_dir = _cache_dir()
        for pat in (f"{safe}.txt", f"{safe}.json"):
            cands.extend(cache_dir.glob(pat))
    except Exception:
        pass

    for p in cands:
        try:
            if p.suffix.lower() == ".json":
                data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
                items = data
                if isinstance(data, dict):
                    items = (data.get("segments") or data.get("lines")
                             or data.get("items") or [])
                if isinstance(items, list):
                    texts = []
                    for it in items[:300]:
                        if isinstance(it, dict):
                            t = it.get("text") or it.get("line") or ""
                        else:
                            t = str(it)
                        if t.strip():
                            texts.append(t.strip())
                    if texts:
                        return "\n".join(texts)
            else:
                txt = p.read_text(encoding="utf-8", errors="replace")
                if len(txt.strip()) >= 200:
                    return txt
        except Exception as e:
            log.debug("读转录 %s 失败: %s", p, e)
            continue

    # ③ 现场转录
    if auto_transcribe:
        try:
            return transcribe_drama(drama)
        except Exception as e:
            log.warning("现场转录 %s 失败: %s", drama, e)
    return ""


def build_tag_prompt(drama: str, transcript: str, meta: str = "") -> str:
    """构造自由打标签的 prompt。

    ⚠ 刻意**不给候选标签列表** —— 用户要的是"不要局限于分类"。
    但要给足约束，避免模型乱打：
        · 必须能从内容找到依据
        · 3-8 个，覆盖不同维度
        · 输出严格 JSON
    """
    head = f"""你是短剧内容分析员。请阅读下面这部剧的台词/内容片段，为它打标签。

剧名：{drama}
{meta}

要求：
1. 标签**由你自由总结**，不要套用固定的分类体系。可以描述题材、人物关系、
   核心冲突、情绪基调、节奏特点、结局类型、目标观众等任何有辨识度的特征。
2. 每部剧打 {MIN_TAGS}-{MAX_TAGS} 个标签，尽量覆盖不同维度（不要 8 个标签说同一件事）。
3. **每个标签都必须能从下面的内容里找到依据**。找不到依据的宁可不打，
   不确定就不要写。禁止凭剧名猜测。
4. 标签用简短的中文词或短语（2-6 个字最合适），同一部剧的标签不要重复近义。
5. 严格输出 JSON，不要任何解释文字：
{{"tags":[{{"tag":"标签","weight":0.9,"reason":"内容里的依据（一句话）"}}]}}

内容片段：
---
{transcript[:6000]}
---
"""
    return head


def parse_tags(text: str) -> list[dict]:
    """从模型输出里解析标签。

    模型常带 markdown 代码块或前后废话，这里做鲁棒提取。
    """
    if not text:
        return []
    s = text.strip()
    # 去 ```json ... ``` 包裹
    m = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", s, re.S)
    if m:
        s = m.group(1)
    else:
        # 抓第一个 { 到最后一个 }
        i, j = s.find("{"), s.rfind("}")
        if i >= 0 and j > i:
            s = s[i:j + 1]

    try:
        data = json.loads(s)
    except Exception:
        # 兜底：从文本里抓 "tag":"xxx"
        tags = re.findall(r'"tag"\s*:\s*"([^"]{1,20})"', text)
        return [{"tag": t, "weight": 1.0, "reason": ""} for t in tags[:MAX_TAGS]]

    items = []
    if isinstance(data, dict):
        items = data.get("tags") or data.get("labels") or []
    elif isinstance(data, list):
        items = data
    if not isinstance(items, list):
        return []

    out: list[dict] = []
    seen: set[str] = set()
    for it in items:
        if isinstance(it, str):
            tag, weight, reason = it, 1.0, ""
        elif isinstance(it, dict):
            tag = str(it.get("tag") or it.get("label") or "").strip()
            try:
                weight = float(it.get("weight") or 1.0)
            except Exception:
                weight = 1.0
            reason = str(it.get("reason") or "").strip()
        else:
            continue
        tag = tag.strip().strip("#.,，。、")
        if not tag or len(tag) > 20:
            continue
        if tag in seen:
            continue
        seen.add(tag)
        out.append({"tag": tag, "weight": max(0.1, min(1.0, weight)),
                    "reason": reason[:120]})
        if len(out) >= MAX_TAGS:
            break
    return out


def save_tags(drama: str, tags: list[dict], source: str = "",
              model: str = "") -> int:
    """写入标签（先清旧的，保证是这一轮的判断）。"""
    ensure_schema()
    db.exec("DELETE FROM drama_tags WHERE drama=?", (drama,))
    n = 0
    for t in tags:
        db.exec("""INSERT INTO drama_tags(drama, tag, weight, reason, source,
                   model, updated_at) VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(drama, tag) DO UPDATE SET
                   weight=excluded.weight, reason=excluded.reason,
                   updated_at=excluded.updated_at""",
                (drama, t["tag"], t.get("weight", 1.0), t.get("reason", ""),
                 source, model, now_iso()))
        n += 1
    return n


async def tag_drama(drama: str, model_id: str = "") -> dict:
    """给一部剧打标签（读转录 → 调模型 → 存库）。"""
    drama = (drama or "").strip()
    if not drama:
        return {"ok": False, "error": "剧名不能为空"}

    transcript = _transcript_for(drama)

    # 内容不足时不要硬打（用户明确"不要乱打"）
    if len(transcript.strip()) < 200:
        return {"ok": False, "drama": drama,
                "error": "找不到足够的台词内容（需要转录文件），"
                         "为避免乱打标签已跳过",
                "transcriptLen": len(transcript)}

    # 补充元数据（集数、时长），让模型有更多线索但不主导判断
    meta = ""
    try:
        r = db.q1("""SELECT COUNT(*) AS n, AVG(dur) AS avg_dur
                       FROM library WHERE drama=? AND state='ready'""", (drama,))
        if r and r.get("n"):
            meta = f"共有 {r['n']} 集，平均时长 {round(float(r.get('avg_dur') or 0))} 秒"
    except Exception:
        pass

    prompt = build_tag_prompt(drama, transcript, meta)
    try:
        from app.services import ai_analysis as ai
        text, used_model = await ai.call_model(prompt, model_id)
    except Exception as e:
        return {"ok": False, "drama": drama, "error": f"调用模型失败: {e}"}

    tags = parse_tags(text)
    if not tags:
        return {"ok": False, "drama": drama,
                "error": "模型未返回可用标签", "raw": (text or "")[:200]}

    n = save_tags(drama, tags, source="transcript", model=used_model)
    return {"ok": True, "drama": drama, "tags": tags, "count": n,
            "model": used_model, "transcriptLen": len(transcript)}


async def tag_all(model_id: str = "", only_missing: bool = True,
                  limit: int = 50) -> dict:
    """批量给所有剧打标签。

    only_missing=True 只处理还没打过标签的剧。
    """
    ensure_schema()
    rows = db.q("""SELECT drama, COUNT(*) AS n FROM library
                    WHERE state='ready' AND drama IS NOT NULL AND drama <> ''
                    GROUP BY drama ORDER BY n DESC""")
    dramas = [r["drama"] for r in rows]

    if only_missing:
        have = {r["drama"] for r in db.q("SELECT DISTINCT drama FROM drama_tags")}
        dramas = [d for d in dramas if d not in have]

    results = []
    for d in dramas[:limit]:
        try:
            r = await tag_drama(d, model_id)
        except Exception as e:
            r = {"ok": False, "drama": d, "error": str(e)[:120]}
        results.append(r)
        log.info("tag %s → %s", d, "ok" if r.get("ok") else r.get("error"))

    ok = sum(1 for x in results if x.get("ok"))
    return {"ok": True, "total": len(results), "tagged": ok,
            "failed": len(results) - ok, "items": results}


def list_tags() -> list[dict]:
    """所有剧的标签（按剧分组）。"""
    ensure_schema()
    rows = db.q("""SELECT t.drama, t.tag, t.weight, t.reason, t.updated_at,
                          (SELECT COUNT(*) FROM library l
                            WHERE l.drama=t.drama AND l.state='ready') AS eps
                     FROM drama_tags t ORDER BY t.drama, t.weight DESC""")
    grouped: dict[str, dict] = {}
    for r in rows:
        g = grouped.setdefault(r["drama"], {
            "drama": r["drama"], "eps": r["eps"],
            "tags": [], "updatedAt": r["updated_at"]})
        g["tags"].append({"tag": r["tag"], "weight": r["weight"],
                          "reason": r["reason"]})
    return list(grouped.values())


def dramas_with_tags(tags: list[str]) -> set[str]:
    """有这些标签的剧（任一交集即命中）—— 主页"按类型绑定"用这个。"""
    if not tags:
        return set()
    ensure_schema()
    ph = ",".join("?" * len(tags))
    rows = db.q(f"SELECT DISTINCT drama FROM drama_tags WHERE tag IN ({ph})",
                tuple(tags))
    return {r["drama"] for r in rows}
