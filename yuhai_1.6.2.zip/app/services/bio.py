"""主页简介（bio）生成。

需求（2026-11-12）：
    建主页时简介要能「模型自由发挥」或「用户自己填」，两种都支持：
      · 用户在弹窗里手填 → 原样使用，不调模型
      · 用户点「AI 生成」 → 按主页名 + 类别 + 可选提示词生成一条
      · 用户留空 → 创建时按主页名 + 类别自动生成（模型不可用时用规则兜底）

和 caption.generate_titles 保持一致的风格：
    · 先判断语言（主页名/类别里有汉字 → 中文简介，否则英文）
    · 提示词明确禁止夸张收益、外部链接、话题标签（平台合规）
    · 模型失败时用规则兜底，绝不返回空把建页卡住
"""
from __future__ import annotations

import logging
import re

from app.db import db

log = logging.getLogger("yuhai.bio")

MAX_LEN = 255          # FB 主页简介上限约 255 字符

# 类别 → 兜底模板（模型不可用时用）
_FALLBACK_CN = {
    "home": "专注分享实用的家居好物与布置灵感，让每个空间都更舒服一点。",
    "default": "每日分享精选内容，欢迎关注，一起发现更多精彩。",
}
_FALLBACK_EN = {
    "home": "Sharing practical home ideas and everyday picks that make a space feel better.",
    "default": "Fresh picks and ideas every day. Follow along for more.",
}


def _has_cn(text: str) -> bool:
    return len(re.findall(r"[\u4e00-\u9fff]", text or "")) >= 2


def _clean(text: str) -> str:
    """压成单行、去 emoji/链接/话题、限长。"""
    s = str(text or "").strip()
    s = re.sub(r"https?://\S+", "", s)
    s = re.sub(r"#\S+", "", s)
    s = re.sub(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]", "", s)
    s = re.sub(r"\s+", " ", s).strip(" -–—·.,，。、")
    return s[:MAX_LEN]


def _fallback(name: str, category: str) -> str:
    cn = _has_cn(f"{name}{category}")
    table = _FALLBACK_CN if cn else _FALLBACK_EN
    key = "home" if any(k in (category or "") for k in
                        ("家居", "家装", "家具", "home", "Home")) else "default"
    return table[key]


async def generate_bio(name: str, category: str = "", hint: str = "",
                       model_id: str = "") -> dict:
    """生成一条主页简介。

    返回 {bio, source}；source 形如 model:xxx / heuristic / manual。
    """
    from app.services import ai_analysis as ai

    name = (name or "").strip()
    category = (category or "").strip()
    hint = (hint or "").strip()

    if not name and not category and not hint:
        return {"bio": "", "source": "empty"}

    cn = _has_cn(f"{name}{category}{hint}")
    lang = "中文" if cn else "英文"
    limit_hint = ("40–70 个汉字" if cn else "80–160 characters")

    prompt = f"""你在为一个 Facebook 公共主页写「简介」（bio）。

主页名称：{name or '（未填）'}
主页类别：{category or '（未填）'}
{f'用户额外要求：{hint}' if hint else ''}

请用{lang}写 1 条简介，要求：
- 说明这个主页分享什么内容、对关注者有什么价值
- 语气自然、简洁，像真人写的，不要营销腔
- 长度 {limit_hint}
- 不要出现 emoji、链接、话题标签、平台名、时长
- 不要承诺收益、不要写"点击链接""立即购买"等行动号召
- 不要重复主页名称
- 只输出简介正文，不要引号、不要解释、不要代码块

只输出一段文字。"""

    try:
        text, used = await ai.call_model(prompt, model_id)
        bio = _clean(text)
        if bio:
            return {"bio": bio, "source": f"model:{used}", "lang": lang}
    except Exception as e:
        log.warning("generate_bio model failed: %s", e)

    return {"bio": _fallback(name, category), "source": "heuristic",
            "lang": lang}


async def ensure_bio(name: str, category: str = "", bio: str = "",
                     hint: str = "", model_id: str = "") -> dict:
    """建页前定稿简介。

    规则：
      · 用户填了 bio → 原样用（只做清洗，不改写）
      · 没填 → 调模型生成；失败用规则兜底
    """
    manual = _clean(bio)
    if manual:
        return {"bio": manual, "source": "manual"}
    return await generate_bio(name, category, hint, model_id)


def log_usage(page_name: str, bio: str, source: str) -> None:
    try:
        db.log_event("info", "create_page",
                     f"简介（{source}）：{page_name} → {bio[:120]}")
    except Exception:
        pass
