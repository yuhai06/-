# -*- coding: utf-8 -*-
"""portable.py — 跨机器可移植性支持

换电脑会遇到的硬编码问题，这里统一解决：
  1. ReelsPublisher 路径（写死 E:\ReelsPublisher-v19.7-Portable）
  2. 素材根目录（写死 E:\处理好素材 / E:\账号运营\素材）
  3. DSH 配置里的端口
  4. 发布日志路径（写死 E:\雨海工作台\_pub_log.jsonl）

做法
----
把可变路径集中到一个配置文件：
  <data>/portable.json
      {
        "reelsPublisher": "E:\\ReelsPublisher-v19.7-Portable",
        "materialRoots": ["E:\\处理好素材", "E:\\账号运营\\素材"],
        "toolsDir": "E:\\账号运营\\tools",
        "publishLog": ""
      }

所有服务统一调 portable.reels_root() / portable.material_roots() 等，
不再各自写死。找不到时返回空串，由上层给出明确提示。

首次运行自动探测常见位置，猜不到就留空让用户在设置里填。
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

log = logging.getLogger("yuhai.portable")

CONF_NAME = "portable.json"


def data_dir() -> Path:
    try:
        from app import paths
        return Path(paths.DATA_DIR)
    except Exception:
        p = Path(os.path.expanduser("~")) / ".yuhai"
        p.mkdir(parents=True, exist_ok=True)
        return p


def conf_path() -> Path:
    return data_dir() / CONF_NAME


def _load() -> dict:
    p = conf_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log.debug("读 portable.json 失败: %s", e)
        return {}


def _save(d: dict) -> bool:
    try:
        p = conf_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                     encoding="utf-8")
        return True
    except Exception as e:
        log.warning("写 portable.json 失败: %s", e)
        return False


# ── 自动探测候选位置 ──

def _guess_reels() -> str:
    cands = [
        Path(r"E:\ReelsPublisher-v19.7-Portable"),
        Path(r"D:\ReelsPublisher-v19.7-Portable"),
        Path(r"C:\ReelsPublisher-v19.7-Portable"),
        Path(os.path.expanduser("~")) / "ReelsPublisher-v19.7-Portable",
        Path(os.path.expanduser("~")) / "Desktop" / "ReelsPublisher-v19.7-Portable",
    ]
    for c in cands:
        if (c / "Reels Publisher.exe").exists():
            return str(c)
    return ""


def _guess_material_roots() -> list[str]:
    cands = [
        Path(r"E:\处理好素材"),
        Path(r"E:\账号运营\素材"),
        Path(r"E:\账号运营\素材库\原始素材"),
        Path(r"D:\处理好素材"),
        Path(os.path.expanduser("~")) / "Desktop" / "处理好素材",
    ]
    out = []
    for c in cands:
        if c.exists() and c.is_dir():
            out.append(str(c))
    return out


def _guess_tools() -> str:
    cands = [
        Path(r"E:\账号运营\tools"),
        Path(r"D:\账号运营\tools"),
        data_dir().parent / "tools",
        data_dir().parent.parent / "tools",
    ]
    for c in cands:
        if (c / "cut_ep2.py").exists():
            return str(c)
    return ""


def bootstrap(force: bool = False) -> dict:
    """首次运行自动探测并写入配置；已有配置就不动。"""
    cur = _load()
    if cur and not force:
        # 补缺的字段
        changed = False
        if not cur.get("reelsPublisher"):
            g = _guess_reels()
            if g:
                cur["reelsPublisher"] = g
                changed = True
        if not cur.get("materialRoots"):
            g = _guess_material_roots()
            if g:
                cur["materialRoots"] = g
                changed = True
        if not cur.get("toolsDir"):
            g = _guess_tools()
            if g:
                cur["toolsDir"] = g
                changed = True
        if changed:
            _save(cur)
        return cur

    d = {
        "reelsPublisher": _guess_reels(),
        "materialRoots": _guess_material_roots(),
        "toolsDir": _guess_tools(),
        "publishLog": "",
    }
    _save(d)
    log.info("portable.json 已生成: reels=%s materials=%d tools=%s",
             d["reelsPublisher"] or "(未找到)", len(d["materialRoots"]),
             d["toolsDir"] or "(未找到)")
    return d


# ── 对外取值接口（找不到返回空，不抛异常） ──

def reels_root() -> Path:
    d = _load()
    v = (d.get("reelsPublisher") or "").strip()
    if v and Path(v).exists():
        return Path(v)
    g = _guess_reels()
    if g:
        # 顺手修好配置
        d["reelsPublisher"] = g
        _save(d)
        return Path(g)
    return Path("")


def material_roots() -> list[Path]:
    d = _load()
    vs = d.get("materialRoots") or []
    out = []
    for v in vs:
        p = Path(str(v))
        if p.exists() and p.is_dir():
            out.append(p)
    if out:
        return out
    g = _guess_material_roots()
    if g:
        d["materialRoots"] = g
        _save(d)
        return [Path(x) for x in g]
    return []


def tools_dir() -> Path:
    d = _load()
    v = (d.get("toolsDir") or "").strip()
    if v and Path(v).exists():
        return Path(v)
    g = _guess_tools()
    if g:
        d["toolsDir"] = g
        _save(d)
        return Path(g)
    return Path("")


def publish_log() -> Path:
    d = _load()
    v = (d.get("publishLog") or "").strip()
    if v:
        return Path(v)
    # 默认放 data 目录，跟着数据走
    return data_dir() / "_pub_log.jsonl"


def status() -> dict:
    """给人看的状态：哪些找到了、哪些要手填。"""
    d = _load()
    rr = reels_root()
    mr = material_roots()
    td = tools_dir()
    missing = []
    if not rr:
        missing.append("reelsPublisher（ReelsPublisher 安装目录）")
    if not mr:
        missing.append("materialRoots（素材根目录）")
    if not td:
        missing.append("toolsDir（切片脚本目录）")

    return {
        "ok": not missing,
        "confPath": str(conf_path()),
        "confExists": conf_path().exists(),
        "reelsPublisher": str(rr) if rr else "",
        "reelsExists": bool(rr),
        "materialRoots": [str(x) for x in mr],
        "toolsDir": str(td) if td else "",
        "toolsExists": bool(td),
        "publishLog": str(publish_log()),
        "missing": missing,
        "hint": ("全部就绪" if not missing
                 else "缺: " + "；".join(missing) + "。用 portable_set 补上"),
        "raw": d,
    }


def set_paths(reelsPublisher: str = "", materialRoots: list[str] | None = None,
              toolsDir: str = "", publishLog: str = "") -> dict:
    """手动设置路径（设置页 / 工具调用）。"""
    d = _load()
    if reelsPublisher:
        if not Path(reelsPublisher).exists():
            return {"ok": False,
                    "error": "目录不存在: " + reelsPublisher}
        d["reelsPublisher"] = str(reelsPublisher)
    if materialRoots is not None:
        good = [str(x) for x in materialRoots if Path(str(x)).exists()]
        bad = [str(x) for x in materialRoots if not Path(str(x)).exists()]
        if bad:
            return {"ok": False, "error": "这些目录不存在: " + ", ".join(bad[:3])}
        d["materialRoots"] = good
    if toolsDir:
        if not Path(toolsDir).exists():
            return {"ok": False, "error": "目录不存在: " + toolsDir}
        d["toolsDir"] = str(toolsDir)
    if publishLog:
        d["publishLog"] = str(publishLog)

    if not _save(d):
        return {"ok": False, "error": "写配置失败"}
    return {"ok": True, **status()}
