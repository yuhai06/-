"""智能素材抓取：从 PineDrama 抓源片，优先抓当天热门。

数据链路（实测打通，来自 pd_drama.py）：
    ① 榜单   GET https://api.sansekai.my.id/api/pinedrama/foryou?cursor=N
    ② 剧信息 GET .../detail?collection_id=CID     -> title / total_episodes
    ③ 单集   GET .../get-episodes?collection_id=CID&episodeNumber=N
              -> best_url（HD_INDO，无 TikTok 水印，a=845221 就是 PineDrama 本体）
    ④ 下载   走本机 Clash（默认 127.0.0.1:7897），curl 直连

关键约束（实测踩过的坑）：
    · api.sansekai 用 httpx/requests 会被 TLS 指纹拦，**必须用 curl**
    · tiktokcdn 的 DNS 被污染，下载**必须走代理**
    · 上游限流 10 次/分钟，**7.5 秒间隔稳定**，6.5 秒会撞空 body
    · 分辨率上限 576×1024，部分集只有 SD

抓取策略（用户要求）：
    · 有分析数据 → 按 AI 给出的剧型/关键词优先挑
    · 没有数据 → 默认抓当天热门榜
    · 可指定「几部剧 × 每部几集」
    · 按榜单顺序抓
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys
import uuid
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso
from app import paths
from app import proc

log = logging.getLogger("yuhai.grab")

API = "https://api.sansekai.my.id/api/pinedrama"
UA = "okhttp/4.12.0"
# 上游限流 10 次/分钟 → 6 秒 = 10 次/分正好卡线，用 8 秒留余量
MIN_INTERVAL = float(os.environ.get("PD_INTERVAL", "8.0"))

_last = [0.0]


def _tools_dir() -> Path:
    """tools 目录（跨环境自动发现）。"""
    return paths.tools_dir()


def _grab_root(custom: str = "") -> Path:
    """抓下来的原始素材放这里。

    优先级：
        ① 本次任务显式指定的目录（custom）
        ② 用户在设置/抓取页保存的自定义素材目录（kv: grab.root）
        ③ 默认 <素材库>/原始素材
    """
    d = ""
    if custom:
        d = custom
    else:
        d = str(db.get_kv("grab.root", "") or "")
    p = Path(d) if d else paths.library_root() / "原始素材"
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_grab_root(path: str = "") -> Path:
    """当前生效的抓取根目录（path 非空则返回该路径，不写配置）。"""
    return _grab_root(path)


def set_grab_root(path: str) -> dict:
    """保存自定义原始素材目录（存 kv，空则恢复默认）。"""
    p = Path(path).expanduser() if path else None
    if p:
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return {"ok": False, "error": f"目录不可用：{e}"}
        db.set_kv("grab.root", str(p))
        return {"ok": True, "root": str(p), "custom": True}
    db.set_kv("grab.root", "")
    return {"ok": True, "root": str(paths.library_root() / "原始素材"),
            "custom": False}


def list_source_dirs() -> list[dict]:
    """可选的原始素材目录清单（自定义 + 默认 + 所有已知源目录）。

    前端用它渲染下拉，用户既能选已有目录，也能输新路径。
    """
    cur = str(db.get_kv("grab.root", "") or "")
    default_root = paths.library_root() / "原始素材"
    out: list[dict] = []

    def add(p: Path, tag: str) -> None:
        s = str(p)
        if any(x["path"] == s for x in out):
            return
        n = 0
        try:
            if p.is_dir():
                n = len(list(p.glob("*/")))
        except OSError:
            n = 0
        out.append({"path": s, "tag": tag, "exists": p.is_dir(),
                    "dramaCount": n, "custom": s == cur,
                    "default": s == str(default_root)})

    if cur:
        add(Path(cur), "自定义")
    add(default_root, "默认")
    for r in paths.source_roots():
        add(r, "源素材")
    for r in paths.asset_roots():
        add(r, "素材根")
    return out


def _proxy() -> str:
    """代理地址（没有代理返回空串 → 直连）。"""
    return paths.proxy()


def _curl_bin() -> str:
    c = paths.curl()
    return str(c) if c else "curl"


def _throttle() -> None:
    import time
    gap = time.time() - _last[0]
    if gap < MIN_INTERVAL:
        time.sleep(MIN_INTERVAL - gap)
    _last[0] = time.time()




def curl_json(url: str, tries: int = 8, use_proxy: bool = True) -> dict | None:
    """curl 拉 JSON。

    重要（实测）：
        · httpx/requests 会被 TLS 指纹拦 → 必须用 curl
        · 直连 IP 会被上游拉黑（403 blacklist）
        · 走代理时默认 HTTP/2 + TLS1.3 握不上手，必须 `--http1.1`
        · **代理出口 IP 会轮换**：撞到被拉黑的 IP 时，等一会儿换节点就能恢复
          所以遇到 403 要有耐心重试（内部退避 10→60 秒）
        · 上游限流 10 次/分钟，8 秒间隔留余量
    """
    import time

    px = _proxy()
    use_proxy = use_proxy and bool(px)
    mode = "proxy" if use_proxy else "direct"
    # 403 退避序列（秒）：越往后等越久，给代理换节点的时间
    backoff = [10, 15, 20, 30, 45, 60, 60, 90]

    for i in range(tries):
        _throttle()
        args = [_curl_bin(), "-sS", "--max-time", "40", "-A", UA,
                "-H", "Accept: application/json",
                "--ssl-no-revoke", "--http1.1"]
        if use_proxy:
            args += ["-x", px]
        args.append(url)
        try:
            p = proc.run(args, timeout=60)
            txt = p.stdout.decode("utf-8", "replace").strip()
            if txt.startswith("{") or txt.startswith("["):
                d = json.loads(txt)
                # 被拉黑 → 换模式再试；两种模式都不行就等（代理会换出口 IP）
                if isinstance(d, dict) and d.get("error") == "Forbidden":
                    alt = not use_proxy if px else False
                    if alt:
                        log.warning("403 via %s, switch to %s",
                                    mode, "direct" if use_proxy else "proxy")
                        use_proxy = alt
                        mode = "direct" if use_proxy is False else "proxy"
                        continue
                    wait = backoff[min(i, len(backoff) - 1)]
                    log.warning("403 blacklisted (try %d/%d), wait %ds for IP rotate",
                                i + 1, tries, wait)
                    time.sleep(wait)
                    continue
                return d
        except Exception as e:
            log.debug("curl_json %s: %s", url[:60], e)
        time.sleep(1.5 * (i + 1))
    return None


def _rows_from(items: list) -> list[dict]:
    """把 foryou 的 collections 数组转成带剧型的标准行。"""
    out = []
    for x in items or []:
        if not isinstance(x, dict):
            continue
        cid = (x.get("collection_id") or x.get("collectionId")
               or x.get("cid") or x.get("id"))
        if not cid:
            continue
        base = {
            "cid": str(cid),
            "title": x.get("title") or x.get("name") or "",
            "cover": x.get("cover") or x.get("cover_url") or "",
            "episodes": x.get("total_episodes") or x.get("episodes") or 0,
            "views": x.get("views") or 0,
            "categories": x.get("categories") or "",
            "tags": x.get("tags") or [],
            "hot": bool(x.get("label_hot")),
            "new": bool(x.get("label_new")),
            "limitedFree": bool(x.get("is_limited_free")),
            "desc": (x.get("description") or "")[:400],
        }
        en = enrich_info(base)
        out.append({
            **base,
            "categories": en["categories"],
            "tags": en["tags"],
            "categoryRaw": en["categoryRaw"],
            "dramaType": en["categoryMap"]["dramaType"],
            "typeZh": en["categoryMap"]["typeZh"],
            "typeTags": en["categoryMap"]["tags"],
            "typeConfidence": en["categoryMap"]["confidence"],
            "lang": en["lang"],
            "langName": en["langName"],
            "langConfidence": en["langConfidence"],
        })
    return out


def _rows_from_search(items: list) -> list[dict]:
    """把 search 端点返回的 results 转成标准行（结构同 collections，但标签含 <em>）。"""
    cleaned = []
    for x in items or []:
        if not isinstance(x, dict):
            continue
        y = dict(x)
        # search 会在命中词上加 <em> 高亮
        if isinstance(y.get("tags"), list):
            y["tags"] = [str(t).replace("<em>", "").replace("</em>", "")
                         for t in y["tags"]]
        if isinstance(y.get("categories"), str):
            y["categories"] = (y["categories"].replace("<em>", "")
                               .replace("</em>", ""))
        if isinstance(y.get("title"), str):
            y["title"] = y["title"].replace("<em>", "").replace("</em>", "")
        cleaned.append(y)
    return _rows_from(cleaned)


def search_dramas(keyword: str, pages: int = 1, per_page: int = 20) -> list[dict]:
    """**按关键词搜索剧**（这是抓百合这类小众题材的唯一途径）。

    为什么必须有这个：
        foryou 热门榜只推印尼语主流题材（24 个标签全是异性恋向），
        百合/GL 这类在榜上完全不出现，只能靠 search 关键词命中。

    实测有效关键词（百合）：
        sismance  → 19 部，全部带 Sismance 标签（真百合，最准）
        yuri      → 2 部（日系百合）
        百合 / 女同 → 3 / 19 部（中文/日文标题命中，需二次筛标签）

    注意：search 是**模糊匹配标题和标签**，所以会混进无关剧
    （比如 "girl" 搜出 20 部但基本不是百合）。要精确必须靠标签二次筛。
    """
    kw = (keyword or "").strip()
    if not kw:
        return []
    out: list[dict] = []
    seen: set[str] = set()
    import urllib.parse as _up
    enc = _up.quote(kw)
    for pg in range(1, max(1, pages) + 1):
        d = curl_json(f"{API}/search?query={enc}&page={pg}")
        if not d:
            break
        items = d.get("results") or d.get("data") or []
        rows = _rows_from_search(items[:per_page])
        added = 0
        for r in rows:
            if r["cid"] not in seen:
                seen.add(r["cid"])
                out.append(r)
                added += 1
        if not d.get("has_more") or added == 0:
            break
    return out


def list_hot(cursor: int = 1, limit: int = 20) -> list[dict]:
    """拉热门榜单（单页）。返回带剧类型。

    实测返回结构：{"has_more":true,"cursor":"1","collections":[{...}]}
    每部剧的字段：
        collection_id / title / total_episodes / views
        categories(逗号串) / tags(数组)   ← **剧类型在这里**
        label_hot / label_new / is_limited_free / cover
    """
    d = curl_json(f"{API}/foryou?cursor={cursor}")
    if not d:
        return []
    items = (d.get("collections") or d.get("data") or d.get("list")
             or d.get("results") or [])
    if isinstance(items, dict):
        items = items.get("list") or items.get("collections") or []
    return _rows_from(items[:limit])


def drama_detail(cid: str) -> dict | None:
    """剧信息（含类型）。

    detail 额外给：type（形态，如 "Mini Drama"）、description、
    channel_* （频道/地区/粉丝数）、cover_urls。
    但**没有 categories**，所以类型要靠 foryou 那份补。
    """


def list_hot_all(max_pages: int = 50, stop_empty: int = 2,
                 on_page=None) -> list[dict]:
    """把**当天热门榜全部**拉下来（自动翻页直到没有更多）。

    foryou 是无限翻页的（cursor 递增），has_more 代表还有。
    实测一页 15 部左右；stop_empty 连续几页空就停，防止死循环。
    """
    out: list[dict] = []
    seen_cids: set[str] = set()
    empty_streak = 0
    prev_cursor = -1
    cur = 1
    for _ in range(max_pages):
        d = curl_json(f"{API}/foryou?cursor={cur}")
        if not d:
            empty_streak += 1
            if empty_streak >= stop_empty:
                break
            cur += 1
            continue
        items = (d.get("collections") or d.get("data") or d.get("list")
                 or d.get("results") or [])
        if isinstance(items, dict):
            items = items.get("list") or items.get("collections") or []

        page_rows = _rows_from(items)
        added = 0
        for row in page_rows:
            if row["cid"] not in seen_cids:
                seen_cids.add(row["cid"])
                out.append(row)
                added += 1

        if on_page:
            try:
                on_page(cur, added, len(out))
            except Exception:
                pass

        # 没有新东西 + 没有更多 → 停
        nxt = d.get("cursor")
        has_more = d.get("has_more")
        if added == 0:
            empty_streak += 1
            if empty_streak >= stop_empty:
                break
        else:
            empty_streak = 0
        if has_more is False and added == 0:
            break
        try:
            cur = int(nxt) if nxt not in (None, "") else cur + 1
        except Exception:
            cur += 1
        if cur == prev_cursor:
            cur += 1
        prev_cursor = cur
    return out
    d = curl_json(f"{API}/detail?collection_id={cid}")
    if not d:
        return None
    x = d.get("data") or d.get("collection") or d
    if isinstance(x, list):
        x = x[0] if x else {}
    covers = x.get("cover_urls") or []
    base = {
        "cid": cid,
        "title": x.get("title") or x.get("name") or "",
        "episodes": int(x.get("total_episodes") or x.get("episodes") or 0),
        "cover": (covers[0] if isinstance(covers, list) and covers
                  else x.get("cover") or x.get("cover_url") or ""),
        "views": x.get("views") or 0,
        "categories": x.get("categories") or "",
        "tags": x.get("tags") or [],
        "formType": x.get("type") or "",
        "episodeLabel": x.get("episode_label") or "",
        "desc": (x.get("description") or "")[:400],
        "channel": x.get("channel") or "",
        "channelFollowers": x.get("channel_followers") or 0,
        "channelRegion": x.get("channel_region") or "",
    }
    en = enrich_info(base)
    return {
        **base,
        "categories": en["categories"],
        "tags": en["tags"],
        "categoryRaw": en["categoryRaw"],
        "dramaType": en["categoryMap"]["dramaType"],
        "typeZh": en["categoryMap"]["typeZh"],
        "typeTags": en["categoryMap"]["tags"],
        "typeConfidence": en["categoryMap"]["confidence"],
        "lang": en["lang"],
        "langName": en["langName"],
        "langConfidence": en["langConfidence"],
        "langBy": en["langBy"],
    }


def episode_url(cid: str, ep: int) -> str:
    """拿单集 CDN 地址（无 TikTok 水印）。

    实测返回结构含 best_url（HD_INDO，a=845221 就是 PineDrama 本体）。
    """
    d = curl_json(f"{API}/get-episodes?collection_id={cid}&episodeNumber={ep}")
    if not d:
        return ""
    x = d.get("data") or d.get("episode") or d
    if isinstance(x, list):
        x = x[0] if x else {}
    if not isinstance(x, dict):
        return ""
    for k in ("best_url", "url", "video_url", "play_url", "hd_url", "sd_url"):
        v = x.get(k)
        if v and isinstance(v, str) and v.startswith("http"):
            return v
    # 有些返回把 url 放在 sources 数组里
    for s in (x.get("sources") or x.get("urls") or []):
        if isinstance(s, dict):
            v = s.get("url") or s.get("src")
            if v and str(v).startswith("http"):
                return str(v)
    return ""


def download(url: str, dest: Path, tries: int = 3,
             progress_cb=None) -> bool:
    """下载（tiktokcdn 必须走代理，且要强制 HTTP/1.1）。

    窗口静默：子进程后台跑，界面上只看任务进度。
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    px = _proxy()
    for i in range(tries):
        args = [_curl_bin(), "-sS", "-L", "--ssl-no-revoke", "--http1.1",
                "--max-time", "600", "-A", UA, "--retry", "2"]
        if px:
            args += ["-x", px]
        args += ["-o", str(dest), url]
        try:
            p = proc.run(args, timeout=700)
            if dest.exists() and dest.stat().st_size > 50_000:
                if progress_cb:
                    try:
                        progress_cb(dest.stat().st_size)
                    except Exception:
                        pass
                return True
        except Exception as e:
            log.debug("download try %d: %s", i + 1, e)
        import time
        time.sleep(2)
    return False


def probe(path: Path) -> dict:
    from app.services import video_maker as vm
    return vm.probe(str(path))


def safe_name(s: str) -> str:
    s = re.sub(r'[<>:"/\\|?*\n\r\t]', "_", s or "untitled")
    return s.strip()[:60] or "untitled"


# ---------------- 剧类型映射 ----------------
# PineDrama 的 categories/tags 是印尼语，映射到内部的 7 种剧型 + 中文标签
# w = 权重：强特征标签（决定剧型）权重高，中性背景标签（都市生活这类）低，
#     否则「都市生活」会把「商战逆袭」冲掉，判型会飘。
CATEGORY_MAP: dict[str, dict] = {
    # 印尼语原文 → (内部剧型键, 中文名, 权重)
    "perang bisnis":         {"type": "punch",   "zh": "商战逆袭", "w": 3},
    "ketidakseimbangan kekuatan": {"type": "punch", "zh": "强弱反转", "w": 3},
    "dari miskin jadi kaya": {"type": "punch",   "zh": "草根逆袭", "w": 3},
    "pengkhianatan":         {"type": "ethics",  "zh": "背叛复仇", "w": 3},
    "keluarga dan etika":    {"type": "ethics",  "zh": "家族伦理", "w": 2},
    "cinta segitiga":        {"type": "ethics",  "zh": "三角恋纠葛", "w": 3},
    "masyarakat kelas atas": {"type": "backer",  "zh": "豪门上层", "w": 3},
    "cinta tuan dan pelayan": {"type": "backer", "zh": "主仆恋", "w": 2},
    "romansa penuh lika-liku": {"type": "backer", "zh": "虐恋曲折", "w": 2},
    "rekonsiliasi":          {"type": "backer",  "zh": "和解团圆", "w": 1},
    "salah identitas":       {"type": "suspense", "zh": "身份错位", "w": 3},
    "konspirasi":            {"type": "suspense", "zh": "阴谋悬疑", "w": 3},
    "petualangan":           {"type": "suspense", "zh": "冒险", "w": 2},
    "pascakiamat":           {"type": "suspense", "zh": "末世灾变", "w": 2},
    "lingkungan kerajaan":   {"type": "suspense", "zh": "王朝权谋", "w": 3},
    "fantasi":               {"type": "suspense", "zh": "幻想", "w": 2},
    "cinta posesif":         {"type": "tension",  "zh": "占有欲", "w": 3},
    "romansa kelam":         {"type": "tension",  "zh": "暗黑恋情", "w": 2},
    "bertahan hidup":        {"type": "tension",  "zh": "生存挣扎", "w": 2},
    "ikatan keluarga":       {"type": "sweet",    "zh": "亲情羁绊", "w": 2},
    "kehidupan sehari-hari": {"type": "sweet",    "zh": "日常温情", "w": 1},
    "kehidupan perkotaan":   {"type": "sweet",    "zh": "都市生活", "w": 1},
    "saling menyembuhkan":   {"type": "sweet",    "zh": "相互治愈", "w": 2},
    "kehidupan pedesaan":    {"type": "sweet",    "zh": "乡村生活", "w": 1},
    "aksi":                  {"type": "punch",    "zh": "动作爽片", "w": 2},
    "vampir":                {"type": "tension",  "zh": "吸血鬼", "w": 2},
    "cinta setelah menikah": {"type": "sweet",    "zh": "先婚后爱", "w": 2},
    # ★ 百合（GL）：上游唯一可靠的百合标签是 Sismance
    #   还有零星 yuri / femslash / womance / girl x girl，权重给高
    "sismance":              {"type": "tension",  "zh": "百合", "w": 5},
    "yuri":                  {"type": "tension",  "zh": "百合", "w": 5},
    "femslash":              {"type": "tension",  "zh": "百合", "w": 5},
    "womance":               {"type": "tension",  "zh": "百合", "w": 4},
    "girl x girl":           {"type": "tension",  "zh": "百合", "w": 4},
    "girls love":            {"type": "tension",  "zh": "百合", "w": 4},
    "sapphic":               {"type": "tension",  "zh": "百合", "w": 4},
    "百合":                   {"type": "tension",  "zh": "百合", "w": 5},
    "女同":                   {"type": "tension",  "zh": "百合", "w": 4},
    "lesbian":               {"type": "tension",  "zh": "百合", "w": 4},
    # 其他语种的同类标签（搜索会返回意/葡/法/土/日片源）
    "友達から恋へ":             {"type": "sweet",   "zh": "好友变情人", "w": 2},
    "friends to lovers":     {"type": "sweet",    "zh": "好友变情人", "w": 2},
    "enemies to lovers":     {"type": "sweet",    "zh": "敌对转恋", "w": 2},
    "敵対から恋へ":             {"type": "sweet",   "zh": "敌对转恋", "w": 2},
    "contract romance":      {"type": "sweet",    "zh": "契约恋爱", "w": 2},
    "契約恋愛":                {"type": "sweet",   "zh": "契约恋爱", "w": 2},
    "contract love":         {"type": "sweet",    "zh": "契约恋爱", "w": 2},
    "love after marriage":   {"type": "sweet",    "zh": "先婚后爱", "w": 2},
    "先婚後愛":                {"type": "sweet",   "zh": "先婚后爱", "w": 2},
    # 英文（部分剧用英文标签）
    "business war":          {"type": "punch",    "zh": "商战逆袭", "w": 3},
    "rags to riches":        {"type": "punch",    "zh": "草根逆袭", "w": 3},
    "power imbalance":       {"type": "punch",    "zh": "强弱反转", "w": 3},
    "betrayal":              {"type": "ethics",   "zh": "背叛复仇", "w": 3},
    "family ethics":         {"type": "ethics",   "zh": "家族伦理", "w": 2},
    "love triangle":         {"type": "ethics",   "zh": "三角恋纠葛", "w": 3},
    "upper class":           {"type": "backer",   "zh": "豪门上层", "w": 3},
    "rich family":           {"type": "backer",   "zh": "豪门上层", "w": 3},
    "romance":               {"type": "backer",   "zh": "虐恋曲折", "w": 2},
    "identity":              {"type": "suspense", "zh": "身份错位", "w": 3},
    "conspiracy":            {"type": "suspense", "zh": "阴谋悬疑", "w": 3},
    "adventure":             {"type": "suspense", "zh": "冒险", "w": 2},
    "fantasy":               {"type": "suspense", "zh": "幻想", "w": 2},
    "possessive":            {"type": "tension",  "zh": "占有欲", "w": 3},
    "survival":              {"type": "tension",  "zh": "生存挣扎", "w": 2},
    "family":                {"type": "sweet",    "zh": "亲情羁绊", "w": 2},
    "daily life":            {"type": "sweet",    "zh": "日常温情", "w": 1},
    "urban":                 {"type": "sweet",    "zh": "都市生活", "w": 1},
}

# 标题里的强特征词：分类标签不够用时兜底判型
TITLE_HINTS: list[tuple[str, str, str, int]] = [
    ("melawan",        "punch",   "商战逆袭", 3),
    ("penipu",         "punch",   "商战逆袭", 3),
    ("menghina",       "punch",   "强弱反转", 3),
    ("dihina",         "punch",   "强弱反转", 3),
    ("direndahkan",    "punch",   "强弱反转", 3),
    ("miskin",         "punch",   "草根逆袭", 2),
    ("jadi bos",       "punch",   "草根逆袭", 3),
    ("kembali",        "rebirth", "王者归来", 3),
    ("kebangkitan",    "rebirth", "王者归来", 3),
    ("rahasia",        "suspense", "身份错位", 2),
    ("raja",           "suspense", "王朝权谋", 2),
    ("pangeran",       "suspense", "王朝权谋", 2),
    ("mafia",          "tension", "暗黑恋情", 2),
    ("terlarang",      "tension", "暗黑恋情", 2),
    ("istri",          "ethics",  "家族伦理", 1),
    ("suami",          "ethics",  "家族伦理", 1),
    ("mantan",         "ethics",  "背叛复仇", 2),
    ("cerai",          "ethics",  "背叛复仇", 2),
    ("cinta",          "sweet",   "虐恋曲折", 1),
]


def split_categories(raw: Any) -> list[str]:
    """把 categories（逗号分隔字符串）或 tags（数组）拆成干净的标签列表。"""
    if not raw:
        return []
    if isinstance(raw, list):
        items = [str(x).strip() for x in raw if str(x).strip()]
    else:
        items = [x.strip() for x in str(raw).replace("，", ",").split(",")]
    return [x for x in items if x]


def map_categories(raw: Any, title: str = "") -> dict:
    """把上游分类 + 标题映射成内部剧型 + 中文标签。

    加权规则：
        · 每个命中的分类标签按 CATEGORY_MAP 的权重计分
        · 标题里的强特征词再加分（只在上游分类不够用时起作用）
        · 得分最高的剧型胜出；该剧型的最高分标签作为 typeZh

    返回:
        {
            "dramaType": "punch",            # 内部 7 型之一
            "typeZh": "商战逆袭",              # 该剧型的中文名
            "tags": ["商战逆袭", "都市生活"],   # 全部中文标签（存库/筛选用）
            "raw": ["Perang bisnis", ...],    # 上游原文
            "confidence": 0.8,
            "scores": {"punch": 4, ...},     # 各剧型得分（可追溯）
            "byTitle": true,                 # 是否靠标题兜底判出来的
        }
    """
    tags = split_categories(raw)
    from collections import defaultdict

    scores: dict[str, float] = defaultdict(float)
    hits: list[dict] = []
    for t in tags:
        key = t.lower().strip()
        hit = CATEGORY_MAP.get(key)
        if not hit:
            for k, v in CATEGORY_MAP.items():
                if k in key or key in k:
                    hit = v
                    break
        if hit:
            scores[hit["type"]] += hit.get("w", 1)
            hits.append({"raw": t, **hit})

    tlow = (title or "").lower()
    by_title = False
    if tlow:
        for word, dtype, zh, w in TITLE_HINTS:
            if word in tlow:
                scores[dtype] += w
                by_title = True

    if not scores:
        return {"dramaType": "", "typeZh": "", "tags": tags, "raw": tags,
                "confidence": 0.0, "scores": {}, "byTitle": False}

    best = max(scores.items(), key=lambda kv: kv[1])
    dtype = best[0]

    # typeZh：该剧型命中里权重最高的标签；标题兜底时用标题给的词
    same = [h for h in hits if h["type"] == dtype]
    if same:
        type_zh = max(same, key=lambda h: h.get("w", 1))["zh"]
    else:
        type_zh = next((zh for word, dt, zh, w in TITLE_HINTS
                        if dt == dtype and word in tlow), dtype)

    zh_tags: list[str] = []
    for h in sorted(hits, key=lambda x: -x.get("w", 1)):
        if h["zh"] and h["zh"] not in zh_tags:
            zh_tags.append(h["zh"])
    if type_zh and type_zh not in zh_tags:
        zh_tags.insert(0, type_zh)

    return {
        "dramaType": dtype,
        "typeZh": type_zh,
        "tags": zh_tags,
        "raw": tags,
        "confidence": round(min(1.0, best[1] / 5.0), 2),
        "scores": dict(scores),
        "byTitle": by_title,
    }


def enrich_info(info: dict, cand: dict | None = None) -> dict:
    """补全剧信息：分类归一化 + 语言识别。

    上游字段分布不均：
        foryou  → categories(逗号串) + tags(数组) + label_hot/new + is_limited_free
        detail  → type("Mini Drama") + description + channel_* + cover_urls
    两边都要吃，缺的用另一边补。语言只能从标题/描述推断（API 没这字段）。
    """
    from app.services import lang_detect as ld

    c = cand or {}
    out = dict(info or {})
    raw_cat = out.get("categories") or c.get("categories") or ""
    raw_tags = out.get("tags") or c.get("tags") or []
    merged: list[str] = []
    for x in split_categories(raw_cat):
        if x not in merged:
            merged.append(x)
    for x in split_categories(raw_tags):
        if x not in merged:
            merged.append(x)

    out["categories"] = ", ".join(merged)
    out["tags"] = merged
    out["categoryRaw"] = merged
    out["categoryMap"] = map_categories(merged, out.get("title") or c.get("title") or "")
    out["formType"] = out.get("formType") or c.get("formType") or ""
    out["hot"] = bool(out.get("hot") or c.get("hot"))
    out["new"] = bool(out.get("new") or c.get("new"))
    out["limitedFree"] = bool(out.get("limitedFree") or c.get("limitedFree"))

    # 语言
    lang = ld.detect_drama({**c, **out})
    out["lang"] = lang["lang"]
    out["langName"] = lang["name"]
    out["langConfidence"] = lang["confidence"]
    out["langBy"] = lang["by"]
    return out


# ---------------- 智能挑选 ----------------
def pick_by_analysis(candidates: list[dict], limit: int,
                     cfg: dict | None = None) -> list[dict]:
    """按 AI 分析 + 自定义条件排序挑剧。

    硬过滤（不通过的直接剔除）：
        ① 自定义剧型（customTypes，用户自己填的类型名）匹配不到就剔除
        ② 排除标签（excludeTags）
        ③ 语言（wantLangs + langMode）：include 只留想要的，exclude 剔掉这些
    软加分（排序用）：
        ④ 内部 7 型（wantTypes）             +100
        ⑤ 指定标签（wantTags）               +60
        ⑥ AI 分析出的主页偏好类型            +40
        ⑦ AI 关键词命中                       +10/个
        ⑧ 热门标记 / 播放量                  +5~15
    全都没有 → 原样返回（热门榜顺序）。
    """
    from app.services import lang_detect as ld

    cfg = cfg or {}
    want_types: list[str] = cfg.get("wantTypes") or []
    want_tags: list[str] = [str(x).strip().lower()
                            for x in (cfg.get("wantTags") or []) if str(x).strip()]
    excl_tags: list[str] = [str(x).strip().lower()
                            for x in (cfg.get("excludeTags") or []) if str(x).strip()]
    custom_types: list[str] = [str(x).strip().lower()
                               for x in (cfg.get("customTypes") or []) if str(x).strip()]
    want_langs: list[str] = cfg.get("wantLangs") or []
    lang_mode: str = str(cfg.get("langMode") or "include")

    # AI 分析出的偏好
    ai_types: set[str] = set()
    ai_kws: list[str] = []
    for f in db.q("SELECT * FROM page_fit"):
        if f["drama_type"]:
            ai_types.add(f["drama_type"])
        try:
            ai_kws.extend(json.loads(f["keywords"] or "[]"))
        except Exception:
            pass

    def tags_of(c: dict) -> list[str]:
        """这部剧的全部可匹配文本（中文标签 + 上游原文）。"""
        t: list[str] = []
        for k in ("typeTags", "tags", "categoryRaw"):
            v = c.get(k) or []
            if isinstance(v, list):
                t.extend(str(x).lower() for x in v)
            elif v:
                t.append(str(v).lower())
        return t

    def keep(c: dict) -> bool:
        """硬过滤：任何一条不满足就剔除。"""
        t = tags_of(c)
        title = (c.get("title") or "").lower()

        # 排除标签
        if excl_tags and any(e in x for x in t for e in excl_tags):
            return False

        # 自定义类型（用户自己填的名字，在标签或标题里找）
        if custom_types:
            if not any(ct in x for x in t for ct in custom_types) \
               and not any(ct in title for ct in custom_types):
                return False

        # 语言
        if want_langs:
            lang = c.get("lang") or "unknown"
            ok = ld.matches(lang, want_langs, lang_mode)
            # include 模式 + 明确判出语言 + 不在想要列表 → 剔除
            if lang_mode == "include" and lang != "unknown" and not ok:
                return False
            if lang_mode == "exclude" and lang != "unknown" and not ok:
                return False

        return True

    def score(c: dict) -> float:
        s = 0.0
        t = tags_of(c)
        title = (c.get("title") or "").lower()

        if want_types:
            dt = c.get("dramaType") or ""
            zh = (c.get("typeZh") or "").lower()
            if dt in want_types or zh in [w.lower() for w in want_types]:
                s += 100

        for w in want_tags:
            if any(w in x for x in t) or w in title:
                s += 60

        if custom_types:
            for ct in custom_types:
                if any(ct in x for x in t) or ct in title:
                    s += 80

        if ai_types and (c.get("dramaType") or "") in ai_types:
            s += 40

        for kw in ai_kws:
            if kw and (kw.lower() in title or any(kw.lower() in x for x in t)):
                s += 10

        if c.get("hot"):
            s += 8
        if c.get("new"):
            s += 4
        v = c.get("views") or 0
        if isinstance(v, (int, float)) and v > 0:
            s += min(15, v / 1_000_000)

        return s

    pool = [c for c in candidates if keep(c)]

    has_cond = bool(want_types or want_tags or excl_tags or custom_types
                    or want_langs or ai_types or ai_kws)
    if not has_cond:
        return pool[:limit]

    ranked = sorted(pool, key=score, reverse=True)
    return ranked[:limit]


async def run_grab(job_id: str, cfg: dict) -> None:
    """执行抓取任务。

    cfg:
        dramas       抓几部剧
        episodes     每部抓几集
        useAnalysis  是否按 AI 分析优先
        cids         指定 cid（优先于榜单，手动指定剧）
        wantTypes    指定剧型（punch/ethics/backer/suspense/tension/sweet/rebirth）
        wantTags     指定标签关键词（中文/印尼语/英文都行）
        excludeTags  排除标签
        cursorFrom   从第几页榜单开始翻
        cursorPages  翻几页榜单候选
        root         本次抓取落到哪个目录（自定义原始素材文件夹）
        startEp      从第几集开始抓
        orderBy      排序依据：hot（热度）/ newest（最新）/ list（榜序）
    """
    from app.services import grab_records as gr

    n_dramas = max(1, min(200, int(cfg.get("dramas") or 1)))
    n_eps = max(1, min(200, int(cfg.get("episodes") or 10)))
    use_analysis = bool(cfg.get("useAnalysis", True))
    cids = cfg.get("cids") or []
    start_ep = max(1, int(cfg.get("startEp") or 1))
    order_by = str(cfg.get("orderBy") or "list")
    cursor_from = max(1, int(cfg.get("cursorFrom") or 1))
    cursor_pages = max(1, min(60, int(cfg.get("cursorPages") or 1)))
    want_types = cfg.get("wantTypes") or []
    want_tags = cfg.get("wantTags") or []
    exclude_tags = cfg.get("excludeTags") or []
    custom_types = cfg.get("customTypes") or []
    want_langs = cfg.get("wantLangs") or []
    lang_mode = str(cfg.get("langMode") or "include")
    all_hot = bool(cfg.get("allHot", False))
    dedupe = bool(cfg.get("dedupe", True))
    skip_existing_eps = bool(cfg.get("skipExistingEps", True))
    # ★ 关键词搜索（百合这类小众题材只能靠这个）
    keywords = [str(x).strip() for x in (cfg.get("keywords") or []) if str(x).strip()]
    kw_pages = max(1, min(20, int(cfg.get("kwPages") or 3)))
    tag_filter = [str(x).strip().lower()
                  for x in (cfg.get("tagFilter") or []) if str(x).strip()]

    steps = [{"name": "拉热门榜", "state": "run", "note": ""}]
    db.exec("UPDATE jobs SET status='running',steps=?,started_at=? WHERE id=?",
            (json.dumps(steps, ensure_ascii=False), now_iso(), job_id))

    try:
        # ① 候选剧
        if cids:
            cands = [{"cid": str(c), "title": "", "episodes": 0} for c in cids]
            steps[0].update(state="done", note=f"指定 {len(cands)} 部")
        elif keywords:
            # ★ 关键词搜索：百合/GL 这类热门榜上没有的题材走这里
            cands = []
            seen_kw: set[str] = set()
            for kw in keywords:
                got = search_dramas(kw, kw_pages)
                new = [r for r in got if r["cid"] not in seen_kw]
                seen_kw |= {r["cid"] for r in got}
                cands.extend(new)
                steps[0].update(
                    note=f"关键词「{kw}」+{len(new)} 部 · 累计 {len(cands)} 部")
            steps[0].update(state="done",
                            note=f"搜索 {len(keywords)} 个词 → {len(cands)} 部")

            # 标签二次筛（search 是模糊匹配，会混进无关剧）
            if tag_filter:
                def _has_tag(c: dict) -> bool:
                    t = []
                    for k in ("typeTags", "tags", "categoryRaw"):
                        v = c.get(k) or []
                        t.extend([str(x).lower() for x in v] if isinstance(v, list)
                                 else [str(v).lower()])
                    return any(f in x for f in tag_filter for x in t)
                before = len(cands)
                cands = [c for c in cands if _has_tag(c)]
                steps.append({"name": "标签二次筛", "state": "done",
                              "note": f"{before} → {len(cands)} 部"
                                      f"（必须含 {', '.join(tag_filter)}）"})
        elif all_hot:
            # 拉当天全部热门（自动翻页）
            cands = list_hot_all(
                max_pages=cursor_pages if cursor_pages > 1 else 60,
                on_page=lambda pg, add, tot: steps[0].update(
                    note=f"第 {pg} 页 · 累计 {tot} 部"),
            )
            steps[0].update(state="done", note=f"全榜 {len(cands)} 部")
        else:
            cands = []
            for pg in range(cursor_from, cursor_from + cursor_pages):
                page = list_hot(pg, 30)
                if not page:
                    break
                cands.extend(page)
            steps[0].update(state="done",
                            note=f"{len(cands)} 部候选"
                                 + (f"（{cursor_pages} 页）" if cursor_pages > 1 else ""))
        if not cands:
            raise RuntimeError("榜单为空（接口可能限流，稍后重试）")

        # ② 排序依据
        if order_by == "hot":
            cands.sort(key=lambda x: (x.get("views") or 0), reverse=True)
            steps.append({"name": "按播放量排序", "state": "done", "note": ""})
        elif order_by == "newest":
            cands.sort(key=lambda x: (bool(x.get("new")), x.get("views") or 0),
                       reverse=True)
            steps.append({"name": "按最新优先", "state": "done", "note": ""})

        # ③ 去重：已经抓过的剧不再抓
        if dedupe:
            fresh, seen = gr.filter_new(cands, dedupe=True)
            steps.append({
                "name": "已抓去重", "state": "done",
                "note": f"跳过 {len(seen)} 部已抓 · 剩 {len(fresh)} 部可抓",
            })
            cands = fresh
            if not cands:
                res = {"dramas": 0, "ok": 0, "fail": 0, "skipped": len(seen),
                       "dir": str(_grab_root(cfg.get("root") or "")),
                       "details": [], "types": [],
                       "note": "全部已抓过，无需重复下载"}
                db.exec("UPDATE jobs SET status='done',steps=?,result=?,progress=100,"
                        "ended_at=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False),
                         json.dumps(res, ensure_ascii=False), now_iso(), job_id))
                db.log_event("ok", "grab",
                             f"去重命中 {len(seen)} 部，全部已抓过，没有新剧")
                return
        else:
            steps.append({"name": "去重已关闭", "state": "done", "note": "允许重抓"})

        # ④ 智能筛选
        conds = []
        if want_types:
            conds.append(f"剧型 {len(want_types)} 个")
        if custom_types:
            conds.append(f"自定类型 {len(custom_types)} 个")
        if want_tags:
            conds.append(f"标签 {len(want_tags)} 个")
        if exclude_tags:
            conds.append(f"排除 {len(exclude_tags)} 个")
        if want_langs:
            mode_zh = "只要" if lang_mode == "include" else "排除"
            conds.append(f"语言{mode_zh} {len(want_langs)} 种")
        if use_analysis and not cids:
            conds.append("AI 偏好")

        if conds or use_analysis:
            picked = pick_by_analysis(cands, n_dramas, {
                "wantTypes": want_types,
                "wantTags": want_tags,
                "excludeTags": exclude_tags,
                "customTypes": custom_types,
                "wantLangs": want_langs,
                "langMode": lang_mode,
            })
            steps.append({"name": "智能筛选", "state": "done",
                          "note": (", ".join(conds) or "无筛选")
                                  + f" → 选 {len(picked)} 部"})
        else:
            picked = cands[:n_dramas]
            steps.append({"name": "按榜单顺序", "state": "done",
                          "note": f"选 {len(picked)} 部"})

        if not picked:
            hint = "筛选后没有匹配的剧。"
            if want_langs:
                hint += "可以先试「语言不筛选」，或放宽剧型/标签限制。"
            hint += "也可以把「翻页数」调大拿更多候选。"
            raise RuntimeError(hint)

        root = _grab_root(cfg.get("root") or "")
        total_ok, total_fail, skipped_eps = 0, 0, 0
        details = []

        for i, c in enumerate(picked):
            cid = c["cid"]
            info = drama_detail(cid) or c
            info = enrich_info(info, c)
            title = info.get("title") or c.get("title") or cid
            eps = info.get("episodes") or c.get("episodes") or n_eps
            cm = info.get("categoryMap") or {}
            out_dir = root / f"{safe_name(title)}_{cid}"
            out_dir.mkdir(parents=True, exist_ok=True)

            # 该剧已抓过的集（来自台账）
            already = set(gr.grabbed_eps(cid)) if skip_existing_eps else set()
            # 磁盘上已有的也算
            disk = {int(f.stem[2:]) for f in out_dir.glob("EP*.mp4")
                    if f.stem[2:].isdigit() and f.stat().st_size > 50_000}
            already |= disk

            last_ep = min(start_ep + n_eps - 1, eps) if eps else (start_ep + n_eps - 1)
            want_range = list(range(start_ep, last_ep + 1))
            todo = [e for e in want_range if e not in already]
            ep_count = len(want_range)
            skipped_eps += len(want_range) - len(todo)
            type_tag = cm.get("typeZh") or ""

            steps.append({
                "name": f"《{title}》{len(todo)}/{ep_count} 集"
                        + (f" · {type_tag}" if type_tag else ""),
                "state": "run", "note": "",
            })
            si = len(steps) - 1
            db.exec("UPDATE jobs SET steps=? WHERE id=?",
                    (json.dumps(steps, ensure_ascii=False), job_id))

            ok_n = 0
            new_eps: list[int] = []
            for ep in todo:
                dest = out_dir / f"EP{ep:02d}.mp4"
                if dest.exists() and dest.stat().st_size > 50_000:
                    ok_n += 1
                    new_eps.append(ep)
                    continue      # 断点续传
                url = episode_url(cid, ep)
                if not url:
                    total_fail += 1
                    continue
                if download(url, dest):
                    ok_n += 1
                    total_ok += 1
                    new_eps.append(ep)
                    with open(out_dir / "manifest.jsonl", "a",
                              encoding="utf-8") as f:
                        f.write(json.dumps({"ep": ep, "url": url,
                                            "size": dest.stat().st_size},
                                           ensure_ascii=False) + "\n")
                else:
                    total_fail += 1
                db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False),
                         int(((i + (ep - start_ep + 1) / max(1, len(todo)))
                              / len(picked)) * 100), job_id))

            # 元信息（含类型）
            meta = {
                **info,
                "grabbed": ok_n,
                "startEp": start_ep,
                "lastEp": last_ep,
                "at": now_iso(),
            }
            (out_dir / "meta.json").write_text(
                json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
            (out_dir / "type.json").write_text(
                json.dumps({"dramaType": cm.get("dramaType", ""),
                            "typeZh": cm.get("typeZh", ""),
                            "tags": cm.get("tags", []),
                            "raw": cm.get("raw", []),
                            "confidence": cm.get("confidence", 0.0),
                            "categories": info.get("categories", ""),
                            "formType": info.get("formType", "")},
                           ensure_ascii=False, indent=2), encoding="utf-8")

            # 写台账（累加集号）
            gr.upsert(cid, title=title,
                      drama_type=cm.get("dramaType", ""),
                      type_zh=cm.get("typeZh", ""),
                      tags=cm.get("tags", []),
                      episodes=new_eps,
                      total_eps=int(eps or 0),
                      dir=str(out_dir))

            steps[si].update(state="done" if ok_n else "err",
                             note=f"{ok_n}/{len(todo)} 集"
                                  + (f" · 跳过 {len(want_range) - len(todo)}"
                                     if skipped_eps and len(want_range) != len(todo) else "")
                                  + (f" · {type_tag}" if type_tag else ""))
            details.append({"cid": cid, "title": title, "ok": ok_n,
                            "skipped": len(want_range) - len(todo),
                            "dir": str(out_dir),
                            "dramaType": cm.get("dramaType", ""),
                            "typeZh": cm.get("typeZh", ""),
                            "tags": cm.get("tags", [])})
            db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                    (json.dumps(steps, ensure_ascii=False),
                     int((i + 1) / len(picked) * 100), job_id))

        res = {"dramas": len(picked), "ok": total_ok, "fail": total_fail,
               "skippedEps": skipped_eps, "dir": str(root), "details": details,
               "types": sorted({d["typeZh"] for d in details if d.get("typeZh")})}
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "grab",
                     f"抓取完成：{len(picked)} 部 · {total_ok} 集成功 · {total_fail} 失败"
                     + (f" · 跳过已抓 {skipped_eps} 集" if skipped_eps else "")
                     + (f" · 类型 {', '.join(res['types'])}" if res["types"] else ""))
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "grab", str(e)[:200])


def list_grabbed(root: str = "") -> list[dict]:
    """已抓下来的剧（按文件夹扫，带剧类型）。"""
    r = _grab_root(root)
    out = []
    if not r.exists():
        return out
    for d in sorted(r.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        eps = list(d.glob("EP*.mp4"))
        if not eps and not (d / "meta.json").exists():
            continue
        total = sum(f.stat().st_size for f in eps)
        meta = {}
        tp = {}
        mp = d / "meta.json"
        if mp.exists():
            try:
                meta = json.loads(mp.read_text(encoding="utf-8"))
            except Exception:
                pass
        tpf = d / "type.json"
        if tpf.exists():
            try:
                tp = json.loads(tpf.read_text(encoding="utf-8"))
            except Exception:
                pass
        # 老数据没有 type.json → 用 meta 里的 categories 现算
        if not tp and meta.get("categories"):
            m = map_categories(meta["categories"])
            tp = {"dramaType": m["dramaType"], "typeZh": m["typeZh"],
                  "tags": m["tags"], "raw": m["raw"],
                  "confidence": m["confidence"]}
        out.append({
            "dir": str(d), "name": d.name,
            "title": meta.get("title") or d.name,
            "cid": meta.get("cid") or "",
            "episodes": len(eps),
            "sizeMb": round(total / 1048576, 1),
            "at": meta.get("at") or "",
            "dramaType": tp.get("dramaType", ""),
            "typeZh": tp.get("typeZh", ""),
            "typeTags": tp.get("tags", []),
            "rawTags": tp.get("raw", []),
            "categories": tp.get("categories") or meta.get("categories") or "",
            "confidence": tp.get("confidence", 0),
        })
    return out

# ══════════════════════════════════════════
#  快速失败版（给 MCP 工具用）
#  ⚠️ 原 curl_json 最长要等 8 分钟（8 次重试 + 退避），
#     MCP 调用会先超时。这里限制总时长，快速返回真实原因。
# ══════════════════════════════════════════
def _probe_proxy(timeout: int = 8) -> tuple[bool, str]:
    """快速探代理是否可用。返回 (可用, 说明)"""
    px = _proxy()
    if not px:
        return False, "没配代理"
    try:
        p = proc.run([_curl_bin(), "-sS", "--max-time", str(timeout),
                      "-x", px, "-o", "/dev/null", "-w", "%{http_code}",
                      "https://api.sansekai.my.id/api/pinedrama"],
                     timeout=timeout + 5, capture_output=True)
        code = (p.stdout or b"").decode("utf-8", "replace").strip()
        if code.startswith("2"):
            return True, f"代理可用（{px}）"
        if code.startswith("4"):
            return False, f"代理通但被上游拒绝（HTTP {code}），可能 IP 被拉黑"
        return False, f"代理返回异常（HTTP {code or '超时'}）"
    except Exception as e:
        return False, f"代理连不上: {str(e)[:60]}"


def list_hot_fast(cursor: int = 1, limit: int = 20,
                  total_timeout: int = 90) -> dict:
    """快速版热门榜单。

    返回 {ok, items, count, error, why, fix, retries}
    最长等 total_timeout 秒，超时立即返回原因。
    """
    import time
    t0 = time.time()

    # 先探代理（8 秒内给结论）
    ok_px, px_msg = _probe_proxy(8)
    if not ok_px:
        return {"ok": False, "items": [], "count": 0,
                "error": "代理不可用",
                "why": px_msg,
                "fix": "检查代理软件（127.0.0.1:7897）是否运行，"
                       "或换个能访问外网的节点",
                "retries": 0,
                "elapsed": round(time.time() - t0, 1)}

    px = _proxy()
    url = f"{API}/foryou?cursor={cursor}"
    attempt = 0
    last_code = ""
    last_err = ""

    while time.time() - t0 < total_timeout:
        attempt += 1
        args = [_curl_bin(), "-sS", "--max-time", "25", "-A", UA,
                "-H", "Accept: application/json",
                "--ssl-no-revoke", "--http1.1", "-x", px, url]
        try:
            p = proc.run(args, timeout=30, capture_output=True)
            txt = (p.stdout or b"").decode("utf-8", "replace").strip()
            if not txt:
                last_err = "空响应"
                time.sleep(2)
                continue
            if not (txt.startswith("{") or txt.startswith("[")):
                last_err = txt[:80]
                time.sleep(2)
                continue
            d = json.loads(txt)
            if isinstance(d, dict) and d.get("error") == "Forbidden":
                last_code = "403"
                # 等代理换出口 IP（最多 3 次，每次 8 秒）
                if attempt >= 3:
                    break
                time.sleep(8)
                continue
            items = (d.get("collections") or d.get("data")
                     or d.get("list") or d.get("results") or [])
            if isinstance(items, dict):
                items = items.get("list") or []
            return {"ok": True, "items": items, "count": len(items),
                    "retries": attempt - 1,
                    "elapsed": round(time.time() - t0, 1)}
        except Exception as e:
            last_err = str(e)[:80]
            time.sleep(2)

    # 失败：给明确原因
    if last_code == "403":
        why = ("代理出口 IP 被上游拉黑了（403 blacklisted）。"
               "这不是限流，是 IP 在黑名单里")
        fix = ("① 在代理软件里换节点（换到别的地区）再试  "
               "② 等 5-10 分钟（有的节点会自动换 IP）  "
               "③ 暂时用 grab_search 按剧名搜，不依赖榜单")
    else:
        why = f"请求失败: {last_err or '超时'}"
        fix = "检查代理；或等一会儿再试"

    return {"ok": False, "items": [], "count": 0,
            "error": "拉取失败",
            "why": why, "fix": fix,
            "retries": attempt,
            "elapsed": round(time.time() - t0, 1)}


def search_fast(keyword: str, pages: int = 1,
                total_timeout: int = 90) -> dict:
    """快速版搜索（同样的超时保护）。"""
    import time
    t0 = time.time()

    ok_px, px_msg = _probe_proxy(8)
    if not ok_px:
        return {"ok": False, "items": [], "count": 0,
                "error": "代理不可用", "why": px_msg,
                "fix": "检查代理软件是否运行",
                "retries": 0, "elapsed": round(time.time() - t0, 1)}

    px = _proxy()
    items_all = []
    attempt = 0
    for pg in range(1, pages + 1):
        if time.time() - t0 > total_timeout:
            break
        attempt += 1
        url = f"{API}/search?keyword={urllib.parse.quote(keyword)}&page={pg}"
        args = [_curl_bin(), "-sS", "--max-time", "25", "-A", UA,
                "-H", "Accept: application/json",
                "--ssl-no-revoke", "--http1.1", "-x", px, url]
        try:
            p = proc.run(args, timeout=30, capture_output=True)
            txt = (p.stdout or b"").decode("utf-8", "replace").strip()
            if not txt.startswith("{") and not txt.startswith("["):
                continue
            d = json.loads(txt)
            if isinstance(d, dict) and d.get("error") == "Forbidden":
                time.sleep(6)
                continue
            its = (d.get("collections") or d.get("data")
                   or d.get("list") or d.get("results") or [])
            if isinstance(its, dict):
                its = its.get("list") or []
            items_all.extend(its)
        except Exception:
            continue

    if not items_all:
        return {"ok": False, "items": [], "count": 0,
                "error": "搜不到", "why": "可能 IP 被拉黑或剧名不对",
                "fix": "换个关键词；或换代理节点",
                "retries": attempt,
                "elapsed": round(time.time() - t0, 1)}

    return {"ok": True, "items": items_all, "count": len(items_all),
            "retries": attempt - 1,
            "elapsed": round(time.time() - t0, 1)}

