"""建主页额度：按账号状态区分（新号 6-7 / 受限 1-2）。

用户实测结论：
    · 全新个号一天能建 6–7 个才开始被限
    · 一旦被限制，之后只能建 1–2 个

所以额度不是一个固定数字，而是跟着账号的「状态」走：
    new      新号，未触发过限制   → 6（保守值，可调到 7）
    limited  被限制过            → 2（保守值，可调到 1）
    blocked  禁建（限制严重）      → 0

状态推进规则（都是保守方向，宁可少建）：
    · 建主页累计 6 个以上 → 建议降级到 limited
    · 任何一次命中 action_block / rate_limit → 立即降级到 limited
    · 被判 checkpoint / suspicious → 降级到 blocked
    · 连续 7 天无风控 + 有成功建页 → 可以手动升回 new

所有判断集中在 resolve_quota()，调用方只读结果。
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from app.db import db, now_iso

log = logging.getLogger("yuhai.quota")

# 额度档位
QUOTA_LEVELS = {
    "new":     {"limit": 6, "max": 7, "label": "新号", "desc": "未触发过限制，可建 6–7 个"},
    "limited": {"limit": 2, "max": 2, "label": "受限", "desc": "被限制过，只能建 1–2 个"},
    "blocked": {"limit": 0, "max": 0, "label": "禁建", "desc": "限制严重，暂停建主页"},
}

# 降级用的风控类型
DOWNGRADE_TO_LIMITED = {"action_block", "rate_limit", "session_verify"}
DOWNGRADE_TO_BLOCKED = {"checkpoint", "captcha", "suspicious"}


def resolve_quota(account_id: str, override: str = "") -> dict:
    """算出这个号今天还能建几个主页。

    返回 {level, limit, usedToday, remaining, reason, ...}
    """
    acc = db.q1("SELECT * FROM accounts WHERE id=?", (account_id,))
    if not acc:
        return {"ok": False, "error": "号不存在", "level": "blocked",
                "limit": 0, "remaining": 0}

    level = (override or acc.get("page_quota") or "new").strip()
    if level not in QUOTA_LEVELS:
        level = "new"
    cfg = QUOTA_LEVELS[level]

    today = now_iso()[:10]
    cu = (acc.get("c_user") or "").strip()

    # 额度只按 account_id 统计。
    # 旧实现用 msg LIKE '%c_user%' 会串号：'61595...' 是 '615953...' 的前缀就一起算。
    used = db.q1(
        "SELECT COUNT(*) c FROM page_creates WHERE account_id=?"
        " AND substr(created_at,1,10)=? AND state IN ('reserved','ok')",
        (account_id, today))["c"]
    total = db.q1(
        "SELECT COUNT(*) c FROM page_creates WHERE account_id=? AND state='ok'",
        (account_id,))["c"]

    # 只有在**完全没有**建页记录时才退回历史事件统计。
    # 注意不能写成 total==0：新建任务全部是 reserved（还没成功）时 total 也是 0，
    # 那样会把刚预占的额度统计整个覆盖成 0，并发提交就能无限超额。
    has_records = db.q1(
        "SELECT COUNT(*) c FROM page_creates WHERE account_id=?",
        (account_id,))["c"]
    if not has_records and cu:
        total = db.q1(
            "SELECT COUNT(*) c FROM events WHERE source='create_page' AND level='ok'"
            " AND msg LIKE ?", (f"%c_user={cu}%",))["c"]
        used = db.q1(
            "SELECT COUNT(*) c FROM events WHERE source='create_page' AND level='ok'"
            " AND substr(ts,1,10)=? AND msg LIKE ?", (today, f"%c_user={cu}%"))["c"]

    # 最近风控（决定要不要降级）
    recent_guard = db.q("SELECT * FROM guard_events WHERE ts >= ? ORDER BY ts DESC",
                        ((datetime.now() - timedelta(days=7)).isoformat(),))
    kinds = {g["kind"] for g in recent_guard}

    suggest = level
    reason = cfg["desc"]
    if kinds & DOWNGRADE_TO_BLOCKED:
        suggest = "blocked"
        reason = f"近 7 天命中 {','.join(kinds & DOWNGRADE_TO_BLOCKED)}，建议暂停"
    elif kinds & DOWNGRADE_TO_LIMITED:
        suggest = "limited"
        reason = f"近 7 天命中 {','.join(kinds & DOWNGRADE_TO_LIMITED)}，额度降到 1–2"
    elif level == "new" and total >= cfg["limit"]:
        suggest = "limited"
        reason = f"已累计建 {total} 个，接近上限，建议降到受限档"

    limit = QUOTA_LEVELS[suggest]["limit"] if suggest != level else cfg["limit"]
    remaining = max(0, limit - used)

    return {
        "ok": True,
        "accountId": account_id,
        "label": acc["label"],
        "cUser": cu,
        "level": level,
        "suggestLevel": suggest,
        "limit": limit,
        "usedToday": used,
        "total": total,
        "remaining": remaining,
        "reason": reason,
        "guardKinds": sorted(kinds),
        "canCreate": remaining > 0,
    }


def set_quota(account_id: str, level: str, note: str = "") -> dict:
    if level not in QUOTA_LEVELS:
        return {"ok": False, "error": f"level 只能是 {list(QUOTA_LEVELS)}"}
    db.exec("UPDATE accounts SET page_quota=?,quota_note=?,quota_set_at=? WHERE id=?",
            (level, note or level, now_iso(), account_id))
    db.log_event("info", "quota",
                 f"号 {account_id} 建页额度设为 {QUOTA_LEVELS[level]['label']}（{note}）")
    return {"ok": True, "level": level, **QUOTA_LEVELS[level]}


def auto_downgrade(account_id: str, guard_kind: str) -> str | None:
    """风控命中后自动降级，返回新档位（没变化返回 None）。"""
    acc = db.q1("SELECT * FROM accounts WHERE id=?", (account_id,))
    if not acc:
        return None
    cur = acc.get("page_quota") or "new"
    if guard_kind in DOWNGRADE_TO_BLOCKED and cur != "blocked":
        set_quota(account_id, "blocked", f"命中 {guard_kind}")
        return "blocked"
    if guard_kind in DOWNGRADE_TO_LIMITED and cur == "new":
        set_quota(account_id, "limited", f"命中 {guard_kind}")
        return "limited"
    return None


def all_quotas() -> list[dict]:
    rows = db.q("SELECT id FROM accounts WHERE enabled=1 ORDER BY role, label")
    return [resolve_quota(r["id"]) for r in rows]
