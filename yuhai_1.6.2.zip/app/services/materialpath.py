# -*- coding: utf-8 -*-
"""素材路径的可移植解析 —— 2026-11-13 用户需求。

用户原话：
    "改一下不要管是哪个盘是软件里面目录的就行了"

问题：
    数据库里存的是绝对路径 E:\\雨海工作台\\素材库\\剧名\\xx.mp4。
    换台机器装到 D:\\软件\\ 下，全部失效。

方案：
    存**相对软件目录**的路径，读取时按当前软件目录拼回绝对路径。

    库里统一存：
        lib:素材库/剧名/xx.mp4
        out:处理好素材/单集_日期/剧名/xx.mp4
        src:视频素材/xx.mp4

    其中前缀表示属于哪个根（lib/out/src），后面是相对该根的路径。
    读取时：<当前软件目录>/<相对路径>

    这样：
      · 换盘/换目录 → 自动适配
      · 同一台机器移动软件文件夹 → 也能用
      · 旧数据的绝对路径 → 自动识别并转成相对形式

兼容：
    已经是绝对路径的记录（老数据）也能读：
      ① 文件存在 → 直接用
      ② 否则拆出相对部分（素材库/... 或 处理好素材/...）→ 拼当前软件目录
"""
from __future__ import annotations

import logging
import os
from pathlib import Path, PurePosixPath

log = logging.getLogger("yuhai.materialpath")

# 根前缀
PREFIX_LIB = "lib:"
PREFIX_OUT = "out:"
PREFIX_SRC = "src:"

# 已知的根目录名（用于把绝对路径反推成相对路径）
ROOT_NAMES = ("素材库", "处理好素材", "视频素材")


def _app_root() -> Path:
    """当前软件目录（三个素材根的共同父目录）。"""
    try:
        from app.paths import _app_root as ar
        return Path(ar())
    except Exception:
        return Path(__file__).resolve().parents[2]


def _roots() -> dict[str, Path]:
    """三个根目录的当前实际位置（始终基于 _app_root()）。"""
    base = Path(_app_root())
    return {
        "lib": base / "素材库",
        "out": base / "处理好素材",
        "src": base / "视频素材",
    }


def to_storable(abs_path: str) -> str:
    """绝对路径 → 可入库的相对形式（带根前缀）。

    已经带前缀的原样返回。无法归类的保持绝对路径（兜底）。
    """
    if not abs_path:
        return ""
    s = str(abs_path)
    if s.startswith((PREFIX_LIB, PREFIX_OUT, PREFIX_SRC)):
        return s

    p = Path(s)
    roots = _roots()
    for key, root in roots.items():
        try:
            rel = p.resolve().relative_to(Path(root).resolve())
        except Exception:
            continue
        return f"{key}:{rel.as_posix()}"

    # 文件不存在 / 不在已知根下：按路径片段猜（兼容老数据）
    parts = p.parts
    for name, key in (("素材库", "lib"), ("处理好素材", "out"),
                      ("视频素材", "src")):
        if name in parts:
            idx = len(parts) - 1 - parts[::-1].index(name)
            rest = parts[idx + 1:]
            if rest:
                return f"{key}:{'/'.join(rest)}"
    return s      # 归类不了，保持原样（resolve 时会按文件名兜底）


def to_absolute(stored: str) -> str | None:
    """库里存的值 → 当前机器上的绝对路径（不存在返回 None）。"""
    if not stored:
        return None
    s = str(stored)
    roots = _roots()

    # ① 带前缀：拼当前根
    for pre, key in ((PREFIX_LIB, "lib"), (PREFIX_OUT, "out"),
                     (PREFIX_SRC, "src")):
        if s.startswith(pre):
            rel = s[len(pre):]
            cand = Path(roots[key]) / PurePosixPath(rel)
            if cand.is_file():
                return str(cand)
            return None
    # ② 旧绝对路径：先试原路径
    p = Path(s)
    if p.is_file():
        return str(p)
    # ③ 旧绝对路径失效：拆出相对部分，拼当前根
    parts = p.parts
    for name, key in (("素材库", "lib"), ("处理好素材", "out"),
                      ("视频素材", "src")):
        if name in parts:
            idx = len(parts) - 1 - parts[::-1].index(name)
            rest = parts[idx + 1:]
            if rest:
                cand = Path(roots[key]) / Path(*rest)
                if cand.is_file():
                    return str(cand)
    return None


def rel_display(stored: str) -> str:
    """给人看的短路径（去掉前缀和软件目录）。"""
    s = str(stored or "")
    for pre in (PREFIX_LIB, PREFIX_OUT, PREFIX_SRC):
        if s.startswith(pre):
            return s[len(pre):].replace("/", os.sep)
    try:
        return str(Path(s).relative_to(_app_root()))
    except Exception:
        return s


def migrate_db_paths() -> dict:
    """把库里所有绝对路径统一转成相对形式（一次性迁移）。

    返回 {total, converted, unchanged, missing}
    """
    from app.db import db

    total = converted = unchanged = missing = 0
    rows = db.q("SELECT id, path FROM library WHERE path IS NOT NULL AND path<>''")
    for r in rows or []:
        total += 1
        old = str(r["path"])
        if old.startswith((PREFIX_LIB, PREFIX_OUT, PREFIX_SRC)):
            unchanged += 1
            continue
        new = to_storable(old)
        if new == old:
            # 归类不了：检查文件在不在
            if not Path(old).is_file():
                missing += 1
            else:
                unchanged += 1
            continue
        db.exec("UPDATE library SET path=? WHERE id=?", (new, r["id"]))
        converted += 1

    log.info("迁移素材路径：%d 条，转换 %d，未变 %d，找不到 %d",
             total, converted, unchanged, missing)
    return {"total": total, "converted": converted,
            "unchanged": unchanged, "missing": missing}
