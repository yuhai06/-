# -*- coding: utf-8 -*-
"""reel_caption.py — Reels 文案生成（固定模板 + 剧名替换）

用户规定
--------
模板（链接绝不能改）：

    🎬NEXT EPISODE👉🏻https://pinedrama.onelink.me/tR68/tq54sj7s
    🌟Watch all episodes for FREE
    🔍Title: "{{DRAMA}}".
    Click the link in the title to search the show name, don’t miss any episode!✨

规则：
1. {{DRAMA}} 必须替换成真实英文剧名
2. 链接固定，永不替换
3. 每条视频的文案必须不同（除了链接）

实现
----
为了让每条不同，模板主体保持不变，在「引导语」上做轮换：
    ✨ / 💫 / 🔥 / ⭐ …  以及若干等效引导句
这样既守住了链接和结构，又保证每条不重复。
"""
from __future__ import annotations

import hashlib
import logging

log = logging.getLogger("yuhai.reel.caption")

# ── 用户指定的固定链接（永不替换）──
FIXED_LINK = "https://pinedrama.onelink.me/tR68/tq54sj7s"

# ── 模板骨架（4 行结构固定）──
TEMPLATE = (
    "🎬NEXT EPISODE👉🏻{link}\n"
    "🌟Watch all episodes for FREE\n"
    '🔍Title: "{drama}".\n'
    "Click the link in the title to search the show name, don’t miss any episode!{end}"
)

# 结尾动效符号（用来区分每条，不影响结构）
ENDINGS = ["✨", "💫", "🔥", "⭐", "🌟", "💥", "🌠", "✨💫"]

# 前导 emoji 变体（首行）
LEADS = ["🎬", "🎥", "📺", "🎞️", "▶️", "🎦", "🍿", "📽️"]

# 引导句变体（替换最后一句，保持语义）
TAILS = [
    "Click the link in the title to search the show name, don’t miss any episode!",
    "Tap the link above and search the title — every episode is waiting for you!",
    "Search the show name from the link and binge all episodes for free!",
    "Find the show name through the link — don’t skip a single episode!",
    "Open the link and search the title to watch the whole story!",
    "Click through and search the show name to catch every episode!",
    "Use the link to look up the title — the full series is free to watch!",
    "Follow the link, search the show name, and enjoy all episodes!",
]


def build(drama_name: str, variant: int = -1, link: str = "") -> str:
    """生成一条英文文案。

    drama_name : 剧名（会替换 {{DRAMA}}）
    variant    : 指定变体序号（-1 = 按剧名自动挑）
    link       : 自定义链接（空 = 用 FIXED_LINK；链接池会从这里传）
    """
    name = (drama_name or "").strip() or "Untitled"
    if variant < 0:
        # 用剧名 hash 决定起始变体，保证同一部剧也有多种
        h = int(hashlib.md5(name.encode("utf-8")).hexdigest()[:8], 16)
        variant = h

    end = ENDINGS[variant % len(ENDINGS)]
    tail = TAILS[variant % len(TAILS)]

    # 前导 emoji 也轮换（结构不变，视觉不同）
    lead = LEADS[variant % len(LEADS)]

    body = TEMPLATE.format(link=(link or FIXED_LINK), drama=name, end=end)
    # 用 tail 替换默认引导句，保证正文也不同
    default_tail = ("Click the link in the title to search the show name, "
                    "don’t miss any episode!")
    body = body.replace(default_tail + end, tail + end, 1)
    # 首行 emoji 轮换
    body = body.replace("🎬NEXT EPISODE", lead + "NEXT EPISODE", 1)
    return body


# 中文模板（结构相同，链接同一个）
TEMPLATE_CN = (
    "🎬下一集👉🏻{link}\n"
    "🌟全集免费看\n"
    '🔍剧名：「{drama}」.\n'
    "点标题里的链接搜索剧名，一集都别错过！{end}"
)

TAILS_CN = [
    "点标题里的链接搜索剧名，一集都别错过！",
    "打开链接搜索剧名，全部剧集免费追！",
    "点击链接搜剧名，后面的剧情更精彩！",
    "从链接进去搜剧名，一次看完不留遗憾！",
    "跟着链接搜剧名，好戏一集不落！",
    "点链接搜索这个剧名，全集都在里面！",
    "复制剧名去链接里搜，马上接着看！",
    "顺着链接搜剧名，全集免费等你！",
]


def build_cn(drama_name: str, variant: int = -1, link: str = "") -> str:
    """生成一条中文文案（结构、链接与英文版完全一致）。"""
    name = (drama_name or "").strip() or "未命名"
    if variant < 0:
        h = int(hashlib.md5(name.encode("utf-8")).hexdigest()[:8], 16)
        variant = h
    end = ENDINGS[variant % len(ENDINGS)]
    tail = TAILS_CN[variant % len(TAILS_CN)]
    lead = LEADS[variant % len(LEADS)]

    body = TEMPLATE_CN.format(link=(link or FIXED_LINK), drama=name, end=end)
    body = body.replace("🎬下一集", lead + "下一集", 1)
    default_tail = "点标题里的链接搜索剧名，一集都别错过！"
    if tail != default_tail:
        body = body.replace(default_tail + end, tail + end, 1)
    return body


def build_many_auto(drama_name: str, n: int, lang: str = "",
                    links: list[str] | None = None) -> list[str]:
    """生成 n 条互不相同的文案，语言自动，链接可以逐条不同。"""
    out = []
    seen = set()
    i = 0
    guard = 0
    L = lang or detect_lang(drama_name)
    while len(out) < n and guard < n * 40:
        lk = ""
        if links:
            lk = links[i % len(links)]
        c = (build_cn(drama_name, variant=i, link=lk) if L == "cn"
             else build(drama_name, variant=i, link=lk))
        if c not in seen:
            seen.add(c)
            out.append(c)
        i += 1
        guard += 1
    return out


def build_many(drama_name: str, n: int) -> list[str]:
    """为同一个剧生成 n 条互不相同的文案。"""
    out = []
    seen = set()
    i = 0
    guard = 0
    while len(out) < n and guard < n * 40:
        c = build(drama_name, variant=i)
        if c not in seen:
            seen.add(c)
            out.append(c)
        i += 1
        guard += 1
    # 极端情况兜底：加序号（仍然保留链接和结构）
    while len(out) < n:
        out.append(build(drama_name, variant=len(out)))
    return out


def validate(caption: str) -> dict:
    """校验一条文案是否合规。

    返回 {ok, problems[]}
    """
    problems = []
    c = caption or ""

    # 链接：固定链接 或 链接池里任意一个
    has_link = FIXED_LINK in c
    if not has_link:
        try:
            from app.services import link_pool as lp
            for it in lp.list_all(enabled_only=True):
                if it.get("url") and it["url"] in c:
                    has_link = True
                    break
        except Exception:
            pass
    if not has_link:
        problems.append("缺少链接（固定链接或链接池里的都行）")
    if "{{DRAMA}}" in c:
        problems.append("{{DRAMA}} 未替换成剧名")
    if ('Title: "' not in c) and ("剧名：「" not in c):
        problems.append("缺少 🔍Title / 🔍剧名 行")
    if "Watch all episodes for FREE" not in c:
        problems.append("缺少 FREE 行")
    if len(c.strip()) < 80:
        problems.append("文案过短（可能被截断）")

    return {"ok": not problems, "problems": problems}


# 中文剧名 → 英文剧名映射（用户确认过的，发布到美区用）
CN_TITLE_MAP = {
    "大尺碼保母收服黑道教父": "The Plus-Size Nanny Takes On the Mafia Don",
    "帶五萌娃回來復仇": "Quintuplets and Revenge: The Return",
    "愛上我的惡霸萊坎王子": "Falling for the Rakan Prince",
    "狼人王的出逃月后": "The Werewolf King's Runaway Luna",
    "被棄歐米茄變萊肯王后": "Rejected Omega Becomes the Lycan Queen",
    "重生醫學天才反擊假千金": "Reborn Genius Doctor vs. the Fake Heiress",
    # 待切的 3 部
    "前男友逼我吻黑道教父": "My Ex Forced Me to Kiss the Mafia Don",
    "初遇即心動": "Love at First Hiss",
    "閨蜜改寫爛劇本": "Broke Besties Win Fate",
    # 已有的百合剧（英文名已知）
    "橄欖球MVP的害羞女友": "Fire: The Shy Girl Is MVP",
    "我的男人婆室友": "Say Yes to My Tomboy Roommate",
    "被背叛後我吻了吸血鬼女王": "I Kissed a Vampire Queen",
    "穿成惡毒女配的小跟班": "I'm the Villainess's Sidekick",
    "我的帥T室友": "Say Yes to My Tomboy Roommate",
}

# tkId → 英文名（老映射，保留兼容）
CN_TK_IDS = {
    "7696535483828065288": "The Plus-Size Nanny Takes On the Mafia Don",
    "7699020048173896722": "Quintuplets and Revenge: The Return",
}


def drama_name_from_dir(dirname: str) -> str:
    """从目录名推英文剧名。

    素材目录必须是英文剧名（worker 就是拿目录名当剧名）。
    形如 "1_Fire_The_Shy_Girl_Is_MVP" → "Fire The Shy Girl Is MVP"
    """
    import re as _re
    s = str(dirname or "").strip()
    # 去数字前缀 1_ 2_ 3.
    s = _re.sub(r"^\d+[_\.\-\s]+", "", s)
    # 去尾部 _tkId（15 位以上数字）
    s = _re.sub(r"[_\-][0-9]{15,}$", "", s)
    # 去常见 v2/_ITA/_CN 后缀
    s = _re.sub(r"[_\-](ITA|CN|EN|v\d+)$", "", s, flags=_re.I)
    # 下划线转空格
    s = s.replace("_", " ").strip()
    # 折叠空格
    s = _re.sub(r"\s{2,}", " ", s)
    return s


def has_chinese(s: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in (s or ""))


def ensure_english(name: str, tk_id: str = "") -> str:
    """把中文剧名转成英文（查映射）。

    ⚠ 只在【用户没指定语言、模板默认英文】时才该调用。
       用户给了文案/剧名就用他的语言，别强转。
    """
    n = (name or "").strip()
    if not n:
        return ""
    if not has_chinese(n):
        return n
    # ① 中文名直接查表
    if n in CN_TITLE_MAP:
        return CN_TITLE_MAP[n]
    # ② 去掉常见前缀/后缀再查一次
    import re as _re
    n2 = _re.sub(r"^(重生|穿越|穿成|重生之)", "", n)
    if n2 in CN_TITLE_MAP:
        return CN_TITLE_MAP[n2]
    # ③ tkId 映射兜底
    if tk_id and tk_id in CN_TK_IDS:
        return CN_TK_IDS[tk_id]
    return ""       # 查不到，让调用方决定


def detect_lang(text: str) -> str:
    """判断语言：cn / en / other"""
    s = text or ""
    cn = sum(1 for ch in s if "\u4e00" <= ch <= "\u9fff")
    en = sum(1 for ch in s if ch.isascii() and ch.isalpha())
    if cn and cn >= max(2, en * 0.15):
        return "cn"
    if en >= 3:
        return "en"
    return "other"


def build_auto(drama_name: str, variant: int = -1,
               lang: str = "", link: str = "") -> str:
    """按语言自动生成文案。

    lang 空 → 从剧名自动判断。
    cn  → 用中文模板（保留同样结构 + 同一个固定链接）
    en/other → 英文模板
    """
    L = lang or detect_lang(drama_name)
    if L == "cn":
        return build_cn(drama_name, variant=variant, link=link)
    return build(drama_name, variant=variant, link=link)


def template_preview() -> str:
    return build("Fire: The Shy Girl Is MVP", variant=0)
