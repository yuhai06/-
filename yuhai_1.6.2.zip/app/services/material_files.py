# -*- coding: utf-8 -*-
"""素材文件导出 / 导入 —— 2026-11-13 用户需求。

用户原话：
    "我要的不是导出/导入素材库是导出/导入素材没有库懂吗"

所以这里只做**文件搬动**，不碰数据库索引、不生成 json 清单：

    导出素材：把选中的视频文件复制到指定目录
              （保持 剧名/文件名 结构，方便对方直接看）

    导入素材：从指定目录（或单个文件）把视频复制进素材库
              → 复制完可选"自动扫描入库"，扫到就进库，扫不到也没关系
              → **不覆盖同名文件**

对比（避免混淆）：
    ✗ 导出/导入素材库 = 带 index.json、重建库记录（那是备份/迁移）
    ✓ 导出/导入素材   = 只搬 .mp4 文件本身（这个）
"""
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from app.db import db

log = logging.getLogger("yuhai.matfiles")

VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}


def _safe(name: str) -> str:
    """文件名安全化。"""
    bad = '<>:"|?*\0'
    s = "".join("_" if c in bad else c for c in str(name or ""))
    return s.strip(" .") or "unnamed"


def export_files(out_dir: Path, ids: list[str] | None = None,
                 dramas: list[str] | None = None,
                 flat: bool = False) -> dict:
    """把素材视频文件复制到 out_dir。

    out_dir  目标目录（不存在会创建）
    ids      指定素材条目（空=全部可用）
    dramas   只导这些剧
    flat     True=全部平铺到目标根；False=按 剧名/文件名 分目录

    返回 {ok, copied, skipped, failed, outDir, totalMb}
    """
    from app.services import materialpath as mp

    sql = "SELECT * FROM library WHERE state IN ('ready','used')"
    params: list = []
    if ids:
        sql += f" AND id IN ({','.join('?' * len(ids))})"
        params += ids
    if dramas:
        sql += f" AND drama IN ({','.join('?' * len(dramas))})"
        params += dramas
    rows = db.q(sql, params) or []

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    copied = skipped = failed = 0
    total_bytes = 0
    details: list[dict] = []

    for r in rows:
        real = mp.to_absolute(r["path"])
        if not real:
            skipped += 1
            details.append({"file": r["file"], "reason": "源文件不存在"})
            continue
        src = Path(real)
        if not src.is_file():
            skipped += 1
            details.append({"file": r["file"], "reason": "源文件不存在"})
            continue

        if flat:
            dst = out_dir / _safe(src.name)
        else:
            drama = _safe(r["drama"] or "未分类")
            dst = out_dir / drama / _safe(src.name)

        # 同名已存在：加序号，绝不覆盖
        if dst.exists():
            stem, suf = dst.stem, dst.suffix
            n = 2
            while dst.exists():
                dst = dst.parent / f"{stem}_{n}{suf}"
                n += 1

        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            copied += 1
            total_bytes += src.stat().st_size
        except Exception as e:
            failed += 1
            details.append({"file": src.name, "reason": str(e)[:100]})

    log.info("导出素材：复制 %d，跳过 %d，失败 %d → %s",
             copied, skipped, failed, out_dir)
    return {"ok": failed == 0, "copied": copied, "skipped": skipped,
            "failed": failed, "total": len(rows),
            "outDir": str(out_dir),
            "totalMb": round(total_bytes / 1048576, 1),
            "details": details[:20]}


def import_files(src_dir: Path, target: str = "素材库",
                 as_drama: str = "", auto_scan: bool = False) -> dict:
    """把 src_dir 里的视频文件复制进软件目录。

    src_dir   来源目录（递归找视频）或单个视频文件
    target    "素材库"（默认，按剧名分目录）或 "视频素材"（原始素材）
    as_drama  指定剧名（留空则用源目录名/文件名推断）
    auto_scan 复制完是否自动扫描入库

    返回 {ok, copied, skipped, failed, destDir, ...}
    """
    from app.paths import library_root, source_root

    p = Path(src_dir)
    if not p.exists():
        return {"ok": False, "error": f"路径不存在: {src_dir}"}

    # 收集文件
    files: list[Path] = []
    if p.is_file():
        if p.suffix.lower() in VIDEO_EXT:
            files.append(p)
    else:
        for f in p.rglob("*"):
            if f.is_file() and f.suffix.lower() in VIDEO_EXT:
                files.append(f)

    if not files:
        return {"ok": False, "error": "没找到视频文件（mp4/mov/mkv/webm）",
                "scanned": str(p)}

    # 目标根
    if target == "视频素材":
        base = Path(source_root())
    else:
        base = Path(library_root())
    base.mkdir(parents=True, exist_ok=True)

    copied = skipped = failed = 0
    total_bytes = 0
    details: list[dict] = []
    dest_dirs: set[str] = set()

    for f in files:
        # 推断剧名：as_drama > 父目录名 > 文件名去扩展名
        drama = (as_drama or "").strip()
        if not drama:
            drama = (f.parent.name if f.parent != p.parent or p.is_dir()
                     else f.stem)
            # 源目录名的常见噪声：日期目录、单集_xxx
            if drama and ("_" in drama and drama.split("_")[0] in
                          ("单集", "精品混剪", "混剪")):
                drama = f.parent.name if f.parent.name != drama else f.stem
        drama = _safe(drama or "未分类")

        if target == "视频素材":
            dst_dir = base
        else:
            dst_dir = base / drama
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst = dst_dir / _safe(f.name)

        # 同名跳过（不覆盖）
        if dst.exists():
            # 大小相同视为重复
            try:
                if dst.stat().st_size == f.stat().st_size:
                    skipped += 1
                    details.append({"file": f.name, "reason": "同名同大小，跳过"})
                    continue
            except Exception:
                pass
            stem, suf = dst.stem, dst.suffix
            n = 2
            while dst.exists():
                dst = dst_dir / f"{stem}_{n}{suf}"
                n += 1

        try:
            shutil.copy2(str(f), str(dst))
            copied += 1
            total_bytes += f.stat().st_size
            dest_dirs.add(str(dst_dir))
        except Exception as e:
            failed += 1
            details.append({"file": f.name, "reason": str(e)[:100]})

    result = {"ok": failed == 0, "copied": copied, "skipped": skipped,
              "failed": failed, "total": len(files),
              "destDir": str(base), "destDirs": sorted(dest_dirs),
              "totalMb": round(total_bytes / 1048576, 1),
              "details": details[:20]}

    # 复制完直接入库（素材库目标才扫）
    if auto_scan and copied and target != "视频素材":
        try:
            from app.services import scanner
            sc = scanner.scan_roots([base], min_duration=15.0)
            result["scanned"] = sc
        except Exception as e:
            result["scanError"] = str(e)[:120]

    log.info("导入素材：复制 %d，跳过 %d，失败 %d → %s",
             copied, skipped, failed, base)
    return result


def list_source_dirs() -> list[dict]:
    """可导入的候选目录（方便前端给建议）。"""
    from app.paths import source_root, library_root

    out = []
    for label, p in (
        ("视频素材（原始）", Path(source_root())),
        ("素材库", Path(library_root())),
    ):
        if not p.is_dir():
            continue
        n = sum(1 for f in p.rglob("*")
                if f.is_file() and f.suffix.lower() in VIDEO_EXT)
        out.append({"label": label, "path": str(p), "videos": n})
    return out
