r"""热更新系统——不重新打包也能更新代码。

原理：
    打包时把后端 app 代码和前端复制到 exe 同级目录：
        E:\雨海工作台\
            雨海工作台.exe
            app\           ← 后端代码（1.6 MB，可热替换）
            frontend\      ← 前端（4.3 MB，可热替换）
            data\          ← 数据库（不动）
    desktop.py 启动时优先加载这两个外部目录。
    更新时只覆盖 app\ 和 frontend\，然后重启程序即可。

版本管理：
    版本号存在 data/version.json：
        { "version": "1.0.0.20261107", "updatedAt": "...", "files": 42 }
    更新包是一个 zip，结构：
        manifest.json  { version, files: [{path, sha256, size}] }
        app/...
        frontend/...
    解压后逐文件校验 sha256，写回版本号。

安全：
    · 只接受 app/ 和 frontend/ 下的文件（防目录穿越）
    · 写之前先备份到 data/_backup_update/
    · 校验失败自动回滚
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

log = logging.getLogger("yuhai.update")

# 允许更新的顶级目录 / 文件
#
# 2026-11-13 扩展：新增 desktop.py
#   原因：desktop.py 是 PyInstaller 的入口脚本，被冻结进 exe。
#   但它是明文 .py，desktop.py 的 setup_env() 会**优先加载外部 app/**，
#   同理外部 desktop.py 也可以由 exe 引导逻辑读取（见 desktop.py 的
#   _single_instance_guard 说明）。允许它进更新包后，
#   单实例这类"入口级"修复就不用重新打包 344MB 的 exe。
#
#   ⚠ 只放行文件名完全匹配的白名单根文件，仍禁止任意根目录写入
#     （防目录穿越：不允许 ../、不允许其它根级 .py）。
ALLOWED_PREFIX = ("app/", "frontend/")
ALLOWED_ROOT_FILES = ("desktop.py",)

# 内核（ReelsPublisher worker）热修复目录
#
# 2026-11-13 用户要求"纳入"：
#   内核在 E:\ReelsPublisher-v19.7-Portable\resources\worker\src，
#   独立于 yuhai 的部署目录。排期控件这类修复必须改内核，
#   如果不纳入更新包，别人拿到更新也修不好。
#
#   目录约定：<程序目录>\worker\src\...
#   与 yuhai 自己的 app/ 分开，但仍然只允许 .mjs/.js，禁止任意文件。
KERNEL_PREFIX = "worker/src/"
KERNEL_EXTS = (".mjs", ".js", ".json")


def _is_allowed(path: str) -> bool:
    """路径是否允许写入。

    · app/ 或 frontend/ 下的文件：允许
    · 根级白名单文件（desktop.py）：允许
    · 内核目录 worker/src/ 下的 .mjs/.js/.json：允许
    · 其它（含 ../ 穿越、绝对路径、其它根文件）：拒绝
    """
    p = (path or "").replace("\\", "/").lstrip("/")
    if not p:
        return False
    # 禁止穿越与绝对路径
    if p.startswith("../") or "/../" in p or p in ("..", "."):
        return False
    if ":" in p.split("/")[0]:        # C:/ 这类
        return False
    # 内核文件（只允许脚本/配置，杜绝可执行文件）
    if p.startswith(KERNEL_PREFIX):
        rest = p[len(KERNEL_PREFIX):]
        if not rest or "/" not in rest and "." not in rest:
            return False
        return rest.lower().endswith(KERNEL_EXTS)
    if "/" not in p:
        return p in ALLOWED_ROOT_FILES
    return any(p.startswith(pre) for pre in ALLOWED_PREFIX)


def app_dir() -> Path:
    """程序根目录（放 app/ 和 frontend/ 的那一层）。

    优先级：
        ① YUHAI_APP_DIR 环境变量（部署时由 desktop.py 设置）
        ② 打包后：exe 所在目录
        ③ 开发时：仓库 backend 目录
    """
    import sys
    env = os.environ.get("YUHAI_APP_DIR", "").strip()
    if env:
        return Path(env)
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    # 开发模式：本文件在 <repo>/backend/app/services/updater.py → backend/
    return Path(__file__).resolve().parents[2]


def data_dir() -> Path:
    """数据目录。

    优先用 paths.DATA_DIR（它已经处理好开发/打包两种情况，
    开发时指向仓库根 data 目录，不会误建 backend/data）。
    """
    env = os.environ.get("YUHAI_DATA_DIR")
    if env:
        d = Path(env)
    else:
        try:
            from app import paths as _p
            d = _p.DATA_DIR
        except Exception:
            d = app_dir() / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def version_file() -> Path:
    return data_dir() / "version.json"


def current_version() -> dict:
    """当前版本信息。"""
    p = version_file()
    if not p.exists():
        return {"version": "1.0.0", "updatedAt": "", "files": 0}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return {
            "version": d.get("version") or "1.0.0",
            "updatedAt": d.get("updatedAt") or "",
            "files": int(d.get("files") or 0),
            "source": d.get("source") or "",
        }
    except Exception:
        return {"version": "1.0.0", "updatedAt": "", "files": 0}


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def scan_local() -> dict:
    """扫描本地热更新目录（app/ 与 frontend/）。"""
    base = app_dir()
    out: dict[str, dict] = {}
    for top in ("app", "frontend"):
        d = base / top
        if not d.exists():
            continue
        for f in d.rglob("*"):
            if not f.is_file():
                continue
            if "__pycache__" in f.parts:
                continue
            rel = f.relative_to(base).as_posix()
            out[rel] = {"sha256": _sha256(f), "size": f.stat().st_size}
    return out


def verify_package(zip_path: Path) -> dict:
    """校验更新包结构（不落盘）。"""
    if not zip_path.exists():
        return {"ok": False, "error": "更新包不存在"}
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            if "manifest.json" not in names:
                return {"ok": False, "error": "缺少 manifest.json"}
            man = json.loads(z.read("manifest.json").decode("utf-8"))
            bad = []
            for n in names:
                if n.endswith("/") or n == "manifest.json":
                    continue
                # 防目录穿越：不允许绝对路径或 ..
                if n.startswith("/") or ".." in Path(n).parts:
                    bad.append(n)
                    continue
                # 只允许 app/ 和 frontend/
                if not _is_allowed(n):
                    bad.append(n)
            if bad:
                return {"ok": False, "error": f"包含非法路径: {bad[:3]}",
                        "manifest": man}
            return {"ok": True, "manifest": man,
                    "fileCount": len([n for n in names if not n.endswith("/")]),
                    "version": man.get("version") or ""}
    except Exception as e:
        return {"ok": False, "error": f"解析失败: {e}"}


def kernel_dir() -> Path | None:
    """定位内核 worker/src 目录（2026-11-13 起更新包会带内核修复）。

    优先级：
      ① data/config.json 的 reels_env_dir
      ② 环境变量 YUHAI_REELS_ENV
      ③ 常见默认位置
    找不到返回 None（更新时跳过内核文件，不影响 yuhai 自身更新）。
    """
    import json as _json

    cands: list[Path] = []
    try:
        cfgp = data_dir() / "config.json"
        if cfgp.is_file():
            d = _json.loads(cfgp.read_text(encoding="utf-8"))
            v = (d.get("reels_env_dir") or "").strip()
            if v:
                cands.append(Path(v))
    except Exception:
        pass
    env = os.environ.get("YUHAI_REELS_ENV", "").strip()
    if env:
        cands.append(Path(env))
    cands.append(Path(r"E:\ReelsPublisher-v19.7-Portable\resources\worker\src"))

    for c in cands:
        try:
            if (c / "skill-runtime").is_dir():
                return c
        except Exception:
            continue
    return None


def apply_package(zip_path: Path, backup: bool = True) -> dict:
    """应用更新包。

    步骤：
        ① 校验包结构
        ② 备份现有 app/ 和 frontend/ 到 data/_backup_update/<时间戳>/
        ③ 解压覆盖
        ④ 逐文件校验 sha256
        ⑤ 写 version.json
        失败则回滚。
    """
    v = verify_package(zip_path)
    if not v.get("ok"):
        return v

    base = app_dir()
    man = v.get("manifest") or {}
    files = man.get("files") or []

    # ② 备份
    bak_root = data_dir() / "_backup_update" / datetime.now().strftime("%Y%m%d_%H%M%S")
    if backup:
        for top in ("app", "frontend"):
            src = base / top
            if src.exists():
                dst = bak_root / top
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copytree(src, dst)
                except Exception as e:
                    log.warning("backup %s failed: %s", top, e)
        # 根级白名单文件也要备份（desktop.py 等，2026-11-13）
        for name in ALLOWED_ROOT_FILES:
            src = base / name
            if src.is_file():
                try:
                    bak_root.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, bak_root / name)
                except Exception as e:
                    log.warning("backup %s failed: %s", name, e)

        # 内核也要备份（2026-11-13）：只备份 .mjs/.js/.json，别把小 3GB 模型带进去
        kroot = kernel_dir()
        if kroot:
            kbak = bak_root / "kernel"
            for f in kroot.rglob("*"):
                if not f.is_file() or f.suffix.lower() not in KERNEL_EXTS:
                    continue
                rel = f.relative_to(kroot)
                dst = kbak / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(f, dst)
                except Exception as e:
                    log.warning("backup kernel %s failed: %s", rel, e)
            log.info("kernel backed up -> %s", kbak)

        log.info("backup -> %s", bak_root)

    # ③ 解压（⚠ 必须先校验路径，防目录穿越写任意位置）
    written = 0
    kernel_written = 0
    try:
        with zipfile.ZipFile(zip_path) as z:
            for n in z.namelist():
                if n.endswith("/") or n == "manifest.json":
                    continue
                if not _is_allowed(n):
                    log.warning("跳过非法路径: %s", n)
                    continue

                # 内核文件要写到内核自己的目录，不是程序目录
                if n.startswith(KERNEL_PREFIX):
                    kroot = kernel_dir()
                    if not kroot:
                        log.warning("找不到内核目录，跳过: %s", n)
                        continue
                    rel = n[len(KERNEL_PREFIX):]
                    target = (kroot / rel).resolve()
                    try:
                        target.relative_to(kroot.resolve())
                    except ValueError:
                        log.warning("内核路径越界，跳过: %s", n)
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(n) as src, open(target, "wb") as dst:
                        dst.write(src.read())
                    kernel_written += 1
                    continue

                target = (base / n).resolve()
                # 双保险：解析后必须仍在 base 内
                try:
                    target.relative_to(base.resolve())
                except ValueError:
                    log.warning("路径越界，跳过: %s", n)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                written += 1
    except Exception as e:
        log.error("extract failed: %s", e)
        _rollback(bak_root, base)
        return {"ok": False, "error": f"解压失败: {e}", "rolledBack": True}

    # ④ 校验
    bad = []
    for item in files:
        rel = item.get("path") or ""
        if not rel or not _is_allowed(rel):
            continue
        f = base / rel
        if not f.exists():
            bad.append(f"{rel}: 缺失")
            continue
        want = item.get("sha256") or ""
        if want and _sha256(f) != want:
            bad.append(f"{rel}: hash 不符")
    if bad:
        log.error("verify failed: %s", bad[:5])
        _rollback(bak_root, base)
        return {"ok": False, "error": f"校验失败 {len(bad)} 个文件",
                "detail": bad[:10], "rolledBack": True}

    # ⑤ 写版本
    ver = {
        "version": man.get("version") or "1.0.0",
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "files": written,
        "source": str(zip_path),
    }
    version_file().write_text(json.dumps(ver, ensure_ascii=False, indent=1),
                              encoding="utf-8")

    # 清旧备份（只留最近 3 份）
    _prune_backups()

    log.info("update applied: %s (%d files, kernel %d)",
             ver["version"], written, kernel_written)
    return {"ok": True, "version": ver["version"], "files": written,
            "kernelFiles": kernel_written,
            "backup": str(bak_root) if backup else ""}


def _rollback(bak_root: Path, base: Path) -> None:
    """回滚：把备份覆盖回去（含根级白名单文件）。"""
    if not bak_root.exists():
        log.error("no backup to rollback")
        return
    for top in ("app", "frontend"):
        src = bak_root / top
        if not src.exists():
            continue
        dst = base / top
        try:
            if dst.exists():
                shutil.rmtree(dst, ignore_errors=True)
            shutil.copytree(src, dst)
            log.info("rolled back %s", top)
        except Exception as e:
            log.error("rollback %s failed: %s", top, e)
    # 根级文件（desktop.py 等）
    for name in ALLOWED_ROOT_FILES:
        src = bak_root / name
        if not src.is_file():
            continue
        try:
            shutil.copy2(src, base / name)
            log.info("rolled back %s", name)
        except Exception as e:
            log.error("rollback %s failed: %s", name, e)


def _prune_backups(keep: int = 3) -> None:
    root = data_dir() / "_backup_update"
    if not root.exists():
        return
    dirs = sorted([d for d in root.iterdir() if d.is_dir()],
                  key=lambda d: d.name, reverse=True)
    for d in dirs[keep:]:
        shutil.rmtree(d, ignore_errors=True)


def updates_dir() -> Path:
    """更新包存放目录（放在 data 目录下，跨环境一致）。"""
    d = data_dir() / "updates"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _parse_ver(v: str) -> tuple:
    """把版本号解析成可比较的元组。

    支持：
        1.0.0
        2026.11.07.2348
        test.1
    """
    out = []
    for part in str(v or "").replace("-", ".").split("."):
        part = part.strip()
        if part.isdigit():
            out.append((0, int(part)))
        elif part:
            out.append((1, part))
    return tuple(out)


def _ver_newer(a: str, b: str) -> bool:
    """a 是否比 b 新。"""
    return _parse_ver(a) > _parse_ver(b)


def check_local() -> dict:
    """扫描更新包目录，找比当前版本新的包。

    返回：
        {ok, current, latest, hasUpdate, package, version, sizeMb, candidates}
    """
    cur = current_version().get("version") or "0.0.0"
    d = updates_dir()
    cands = []
    for f in sorted(d.glob("*.zip")):
        try:
            v = verify_package(f)
            if not v.get("ok"):
                continue
            ver = v.get("version") or ""
            if not ver:
                continue
            cands.append({
                "path": str(f),
                "name": f.name,
                "version": ver,
                "fileCount": v.get("fileCount") or 0,
                "sizeMb": round(f.stat().st_size / 1048576, 1),
                "mtime": datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds"),
                "newer": _ver_newer(ver, cur),
            })
        except Exception as e:
            log.warning("skip %s: %s", f.name, e)

    cands.sort(key=lambda x: _parse_ver(x["version"]), reverse=True)
    newer = [c for c in cands if c["newer"]]
    latest = newer[0] if newer else (cands[0] if cands else None)

    return {
        "ok": True,
        "current": cur,
        "hasUpdate": bool(newer),
        "latest": latest,
        "package": (newer[0]["path"] if newer else ""),
        "version": (newer[0]["version"] if newer else cur),
        "dir": str(d),
        "candidates": cands[:8],
        "count": len(cands),
    }


def _fetch_manifest_via_api(url: str, timeout: float = 12):
    """把 raw.githubusercontent 链接换成 GitHub contents API 读取。

    raw 域名有几分钟 CDN 缓存，发布新 manifest 后客户端会读到旧版本，
    导致「检查更新」看不到新包。API 请求不经过 CDN，永远是最新提交。
    非 GitHub 域名返回 None（交由调用方走 raw）。
    """
    import re
    import urllib.request

    m = re.match(
        r"https?://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$",
        url or "")
    if not m:
        return None
    owner, repo, branch, path = m.group(1), m.group(2), m.group(3), m.group(4)

    api = "https://api.github.com/repos/%s/%s/contents/%s?ref=%s" % (
        owner, repo, path, branch)
    headers = {
        "User-Agent": "yuhai-updater",
        "Accept": "application/vnd.github.raw+json",
        "Cache-Control": "no-cache",
    }
    # 公开仓库不需要 token；有 token 时用它提升配额
    tok = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if not tok:
        try:
            from pathlib import Path as _P
            for c in (_P(__file__).resolve().parents[2] / "data" / "yuhai_token.txt",):
                if c.exists():
                    tok = c.read_text(encoding="utf-8").strip()
                    break
        except Exception:
            tok = None
    if tok:
        headers["Authorization"] = "Bearer " + tok

    try:
        req = urllib.request.Request(api, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        log.warning("API 读 manifest 失败，回退 raw: %s", e)
        return None


def check_remote(url: str, timeout: float = 12) -> dict:
    """远程更新源：URL 指向一个 manifest.json（含 version 和 package 直链）。

    manifest 格式：
        { "version": "1.2.3", "url": "https://.../update_1.2.3.zip", "note": "" }
    """
    if not url:
        return {"ok": False, "error": "未配置更新源"}
    import urllib.request

    man = None
    errors = []

    # ① 优先走 GitHub API（无 CDN 缓存，能立刻读到最新提交）
    api_man = _fetch_manifest_via_api(url, timeout)
    if api_man is not None:
        man = api_man

    # ② 回退：直连 raw（加时间戳绕缓存）
    if man is None:
        try:
            if "_t=" not in url:
                url = url + ("&" if "?" in url else "?") + "_t=%d" % int(__import__("time").time())
            req = urllib.request.Request(url, headers={
                "User-Agent": "yuhai-updater",
                "Cache-Control": "no-cache, no-store, max-age=0",
                "Pragma": "no-cache",
            })
            with urllib.request.urlopen(req, timeout=timeout) as r:
                man = json.loads(r.read().decode("utf-8"))
        except Exception as e:
            errors.append(str(e))

    if man is None:
        return {"ok": False, "error": "拉取更新源失败: " + ("; ".join(errors) or "未知")}

    cur = current_version().get("version") or "0.0.0"
    ver = str(man.get("version") or "")
    pkg = str(man.get("url") or "")
    return {
        "ok": True,
        "current": cur,
        "latest": {"version": ver, "package": pkg, "note": man.get("note") or "",
                   "sizeMb": man.get("sizeMb"), "newer": _ver_newer(ver, cur)},
        "hasUpdate": bool(ver) and _ver_newer(ver, cur),
        "package": pkg,
        "version": ver,
        "source": url,
    }


def download_package(url: str, timeout: float = 180) -> dict:
    """下载远程更新包到 _updates，返回本地路径。"""
    if not url:
        return {"ok": False, "error": "缺少下载地址"}
    import urllib.request
    name = Path(url.split("?")[0]).name or "update.zip"
    dst = updates_dir() / name
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "yuhai-updater",
            "Cache-Control": "no-cache, no-store, max-age=0",
        })
        with urllib.request.urlopen(req, timeout=timeout) as r, open(dst, "wb") as f:
            shutil.copyfileobj(r, f)
    except Exception as e:
        dst.unlink(missing_ok=True)
        return {"ok": False, "error": f"下载失败: {e}"}
    v = verify_package(dst)
    if not v.get("ok"):
        dst.unlink(missing_ok=True)
        return {"ok": False, "error": v.get("error") or "下载的包无效"}
    return {"ok": True, "path": str(dst), "version": v.get("version"),
            "fileCount": v.get("fileCount"),
            "sizeMb": round(dst.stat().st_size / 1048576, 1)}


def make_package(out_zip: Path, version: str,
                 src_app: Path | None = None,
                 src_frontend: Path | None = None,
                 src_root: Path | None = None,
                 src_kernel: Path | None = None) -> dict:
    """打更新包（开发机上用，或作为脚本）。

    src_root   根级白名单文件来源（desktop.py）
    src_kernel 内核 worker/src 目录（2026-11-13 新增）
               传了就一起打包，包内路径为 worker/src/...
    """
    base = app_dir()
    src_app = src_app or (base / "app")
    src_frontend = src_frontend or (base / "frontend")
    if src_root is None:
        src_root = Path(__file__).resolve().parents[2]
    if not src_app.exists():
        return {"ok": False, "error": f"app 目录不存在: {src_app}"}
    if not src_frontend.exists():
        return {"ok": False, "error": f"frontend 目录不存在: {src_frontend}"}

    files = []
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for top, src in (("app", src_app), ("frontend", src_frontend)):
            for f in src.rglob("*"):
                if not f.is_file():
                    continue
                if "__pycache__" in f.parts or f.suffix == ".pyc":
                    continue
                # ⚠ 跳过 app/frontend —— 那是前端旧副本（开发同步残留）
                _relparts = f.relative_to(src).parts
                if top == "app" and _relparts and _relparts[0] == "frontend":
                    continue
                rel = f"{top}/{f.relative_to(src).as_posix()}"
                z.write(f, rel)
                files.append({"path": rel, "sha256": _sha256(f),
                              "size": f.stat().st_size})

        # 根级白名单文件（desktop.py 等）
        for name in ALLOWED_ROOT_FILES:
            f = Path(src_root) / name
            if not f.is_file():
                continue
            z.write(f, name)
            files.append({"path": name, "sha256": _sha256(f),
                          "size": f.stat().st_size})

        # 内核 worker/src（2026-11-13）
        if src_kernel and Path(src_kernel).is_dir():
            kroot = Path(src_kernel)
            for f in kroot.rglob("*"):
                if not f.is_file():
                    continue
                if "__pycache__" in f.parts or f.suffix == ".pyc":
                    continue
                if not f.name.lower().endswith(KERNEL_EXTS):
                    continue
                rel = f"{KERNEL_PREFIX}{f.relative_to(kroot).as_posix()}"
                z.write(f, rel)
                files.append({"path": rel, "sha256": _sha256(f),
                              "size": f.stat().st_size})

        man = {"version": version,
               "createdAt": datetime.now().isoformat(timespec="seconds"),
               "hasKernel": bool(src_kernel and Path(src_kernel).is_dir()),
               "files": files}
        z.writestr("manifest.json",
                   json.dumps(man, ensure_ascii=False, indent=1))
    size = out_zip.stat().st_size / 1048576
    log.info("package created: %s (%.1f MB, %d files)", out_zip, size, len(files))
    return {"ok": True, "path": str(out_zip), "version": version,
            "files": len(files), "sizeMb": round(size, 1)}
