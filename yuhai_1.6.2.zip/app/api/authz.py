"""授权 API。

唯一原则：只用 profile 数字 ID 认定身份。
姓名 / 邮箱搜索一律不实现——同名的人不止一个，历史上已经授错过。
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, field_validator

from app.adapters.facebook import FB, FBError
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.authz")
router = APIRouter(tags=["authz"])


def _is_uid(v: str) -> bool:
    return bool(v) and v.isdigit() and 8 <= len(v) <= 20


@router.get("/authz")
async def matrix():
    pages = db.q("SELECT page_id,asset_id,name,drama,health FROM pages ORDER BY name")
    out = []
    for p in pages:
        roles = {r["c_user"]: r for r in db.q(
            "SELECT * FROM page_roles WHERE page_id=?", (p["page_id"],))}
        pub = roles.get(settings.fb_publisher_cuser)
        bak = roles.get(settings.fb_backup_cuser)
        out.append({
            "id": p["page_id"],
            "name": p["name"],
            "assetId": p["asset_id"],
            "drama": p["drama"],
            "publisher": {
                "present": bool(pub),
                "state": (pub or {}).get("state"),
                "grantedAt": (pub or {}).get("granted_at"),
            },
            "backup": {
                "present": bool(bak),
                "state": (bak or {}).get("state"),
                "grantedAt": (bak or {}).get("granted_at"),
                "checkedAt": (bak or {}).get("checked_at"),
            },
            "targetId": settings.fb_backup_cuser,
        })
    return {"items": out, "targetId": settings.fb_backup_cuser,
            "publisherId": settings.fb_publisher_cuser}


class GrantReq(BaseModel):
    pageIds: list[str]
    targetProfileId: str
    level: str = "full"
    stopOnMismatch: bool = True
    # 2026-11-12 新增：真正发起邀请
    #
    # 之前的实现只做核对：读权限列表 → 目标不在 → 记 pending + "需人工邀请"，
    # 从来没点过「添加人员」。用户问"怎么没有自动授权"就是这个原因。
    #
    # 现在默认 invite=True 真发起邀请；invite=False 退回旧的"只核对"行为。
    invite: bool = True
    # 邀请时用什么去搜人。留空用 targetProfileId（c_user）。
    # Meta 的搜索按邮箱/姓名匹配，光有数字 ID 常常搜不到 ——
    # 这时把邮箱填进来（accounts 表里有，或 mail_accounts 里的发件邮箱）。
    searchAs: str = ""
    # 要验证码时等多久（秒）。邮箱验证码一般 10-60 秒内到。
    waitCodeSec: float = 90.0
    # ---- 2026-11-12 新流程所需（旧流程的 searchAs 已不用于搜人）----
    # 对方的账号链接（profile.php?id=xxx 或用户名），新流程用它搜人
    targetLink: str = ""
    # 对方的显示名（如 "Yu Hai"），用于点搜索结果卡
    targetName: str = ""
    # 发起方（主页所属号）的登录密码，确认授权时要重输
    password: str = ""

    @field_validator("targetProfileId")
    @classmethod
    def _check(cls, v: str) -> str:
        if not _is_uid(v):
            raise ValueError("targetProfileId 必须是纯数字 profile ID（不接受姓名/邮箱）")
        return v


@router.post("/authz/grant")
async def grant(req: GrantReq):
    """发起授权。真实执行走 CDP 自动化，这里先校验前置条件并入队。"""
    if not req.pageIds:
        raise HTTPException(400, "pageIds 不能为空")

    row = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not row:
        raise HTTPException(400, "发布号环境未启动，先启动 1887976888")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = []
    for pid in req.pageIds:
        nm = (db.q1("SELECT name FROM pages WHERE page_id=?", (pid,)) or {}).get("name") or pid
        steps.append({"name": f"{nm} → {req.targetProfileId}", "state": "wait", "note": ""})
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "authz", f"授权 {len(req.pageIds)} 个主页", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_grant(job_id, req, int(row["cdp_port"])))
    return {"ok": True, "jobId": job_id}


async def _run_grant(job_id: str, req: GrantReq, port: int) -> None:
    steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))["steps"] or "[]")
    done = 0
    try:
        # 按主页分批：同一环境的主页共用一条 CDP 连接。
        #
        # ⚠ 不能用一个固定 port 处理所有主页（2026-11-12 实机踩坑）：
        #   req.pageIds 里可能混着不同环境的主页。用网易01 的标签去打开
        #   QQ02 主页的 asset_id，Meta 会返回错误页，权限读不到。
        #   这里先按 env_code 分组，每组用自己环境的端口连一次。
        by_env: dict[str, list[tuple[int, str]]] = {}
        for i, pid in enumerate(req.pageIds):
            page = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
            if not page or not page.get("asset_id"):
                steps[i].update(state="err", note="缺少 asset_id，无法定位权限页")
                done += 1
                continue
            ec = page.get("env_code") or ""
            by_env.setdefault(ec, []).append((i, pid))

        for env_code, pairs in by_env.items():
            # 该主页所属环境的端口
            env_row = None
            if env_code:
                env_row = db.q1(
                    "SELECT * FROM envs WHERE container_code=?", (env_code,))
            port_for_env = int((env_row or {}).get("cdp_port") or port)

            try:
                async with FB(port_for_env) as fb:
                    # ⚠ 不做 assert_identity：新流程第一步就是「切换到目标主页
                    #   身份」，切完身份会变，预检发布号身份没有意义。
                    #   （2026-11-12：切身份是 invite_member 内部流程的一部分）
                    for i, pid in pairs:
                        steps[i]["state"] = "run"
                        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                                (json.dumps(steps, ensure_ascii=False), job_id))
                        page = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
                        asset = page["asset_id"] if page else None
                        try:
                            members = await fb.list_roles(asset)
                            ids = {m.get("c_user") for m in members
                                   if m.get("c_user")}
                            # 已在列表 → 只更新状态
                            if req.targetProfileId in ids:
                                db.exec(
                                    "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                    " state='active',checked_at=excluded.checked_at",
                                    (pid, req.targetProfileId, req.level, "active",
                                     now_iso(), now_iso()))
                                steps[i].update(state="done", note="已在权限列表中")
                            elif req.invite:
                                # ★ 真正发起邀请（2026-11-12 新增）
                                steps[i].update(state="run",
                                                note="正在发起邀请…")
                                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                                        (json.dumps(steps, ensure_ascii=False),
                                         job_id))

                                from app.adapters.fb_invite import invite_member
                                search_as = (req.searchAs or "").strip() \
                                    or req.targetProfileId

                                # 取码函数：从 IMAP 抓最新的 Meta 验证码
                                async def _get_code():
                                    try:
                                        from app.api.mail import latest_code
                                        lm = await latest_code(
                                            mailbox="", max_age_sec=600)
                                        return (lm or {}).get("code") or ""
                                    except Exception as e:
                                        log.debug("取验证码失败: %s", e)
                                        return ""

                                try:
                                    # 复用当前已连接的 page（不要重连）
                                    pg = await fb.tab()
                                    iv = await invite_member(
                                        pg, page["name"],
                                        req.targetLink or search_as,
                                        target_name=req.targetName or "",
                                        password=req.password or "",
                                        code_getter=_get_code)
                                except Exception as e:
                                    iv = {"ok": False,
                                          "reason": f"{type(e).__name__}: {str(e)[:100]}"}

                                if iv.get("skipped"):
                                    db.exec(
                                        "INSERT INTO page_roles(page_id,c_user,role,state,checked_at,note)"
                                        " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                        " state='active',checked_at=excluded.checked_at,note=excluded.note",
                                        (pid, req.targetProfileId, req.level,
                                         "active", now_iso(), "已在权限列表中，跳过"))
                                    steps[i].update(state="done", note="已授权，跳过")
                                elif iv.get("ok"):
                                    db.exec(
                                        "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at,note)"
                                        " VALUES(?,?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                        " state='active',checked_at=excluded.checked_at,note=excluded.note",
                                        (pid, req.targetProfileId, req.level,
                                         "active", now_iso(), now_iso(),
                                         "邀请已提交并校验通过"))
                                    steps[i].update(
                                        state="done",
                                        note=f"邀请已提交（搜索用 {search_as}）"
                                             + ("· 待对方接受" if iv.get("pending") else ""))
                                else:
                                    db.exec(
                                        "INSERT INTO page_roles(page_id,c_user,role,state,checked_at,note)"
                                        " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                        " state='failed',checked_at=excluded.checked_at,note=excluded.note",
                                        (pid, req.targetProfileId, req.level,
                                         "failed", now_iso(),
                                         str(iv.get("reason"))[:120]))
                                    steps[i].update(
                                        state="err",
                                        note=str(iv.get("reason"))[:100])
                            else:
                                # 旧行为：只核对，记待办
                                db.exec(
                                    "INSERT INTO page_roles(page_id,c_user,role,state,checked_at,note)"
                                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                    " state='pending',checked_at=excluded.checked_at,note=excluded.note",
                                    (pid, req.targetProfileId, req.level, "pending",
                                     now_iso(), "只核对未邀请（invite=false）"))
                                steps[i].update(
                                    state="warn",
                                    note="只核对未邀请（invite=false）")
                        except FBError as e:
                            steps[i].update(state="err", note=str(e)[:80])
                        done += 1
                        db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                                (json.dumps(steps, ensure_ascii=False),
                                 int(done / len(req.pageIds) * 100), job_id))
                        await asyncio.sleep(3)
            except Exception as e:
                # 整个环境连不上：该组全部标错，不影响其他环境
                for i, pid in pairs:
                    steps[i].update(state="err",
                                    note=f"环境 {env_code} 连接失败: {str(e)[:60]}")
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False), job_id))

        db.exec("UPDATE jobs SET status='done',ended_at=? WHERE id=?", (now_iso(), job_id))
        db.log_event("ok", "authz", f"授权任务完成 {len(req.pageIds)} 个主页")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "authz", str(e)[:200])


class VerifyReq(BaseModel):
    pageId: str


@router.post("/authz/verify")
async def verify(req: VerifyReq):
    """读取真实权限列表并回写。

    ⚠ 环境必须按主页所属来取（2026-11-12 实机踩坑）：
        原来写的是
            SELECT * FROM envs WHERE role='publisher' AND status='running'
        q1 只返回第一行 —— 库里有两个发布环境（网易01 / QQ02），
        主页分属不同环境。拿错环境后，QQ02 的标签页去打开
        网易01 的 asset_id：
            business.facebook.com/.../page_roles?asset_id=<别的环境的>
        Meta 直接回 "很抱歉，目前无法显示内容 · 链接可能已过期"，
        权限列表永远读不到，被误判成"未授权"。
    """
    row = db.q1("SELECT * FROM pages WHERE page_id=?", (req.pageId,))
    if not row:
        raise HTTPException(404, "主页不存在")
    if not row["asset_id"]:
        raise HTTPException(400, "该主页缺少 asset_id")

    # 按主页所属环境取（没有 env_code 才退回第一个发布环境）
    env = None
    env_code = row.get("env_code") if isinstance(row, dict) else None
    if env_code:
        env = db.q1(
            "SELECT * FROM envs WHERE container_code=? AND status='running'",
            (env_code,))
        if not env:
            raise HTTPException(
                400, f"主页所属环境 {env_code} 未启动（先启动指纹浏览器）")
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    try:
        async with FB(int(env["cdp_port"])) as fb:
            members = await fb.list_roles(row["asset_id"])
    except (FBError, Exception) as e:
        raise HTTPException(500, f"读取权限列表失败: {str(e)[:200]}")

    ids = {m.get("c_user") for m in members if m.get("c_user")}
    ts = now_iso()
    for cu in (settings.fb_publisher_cuser, settings.fb_backup_cuser):
        if cu in ids:
            db.exec("INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                    " state='active',checked_at=excluded.checked_at",
                    (req.pageId, cu, "full", "active", ts, ts))
        else:
            db.exec("UPDATE page_roles SET state='missing',checked_at=? "
                    "WHERE page_id=? AND c_user=?", (ts, req.pageId, cu))
    return {"ok": True, "verified": sorted(ids), "members": members,
            "publisherPresent": settings.fb_publisher_cuser in ids,
            "backupPresent": settings.fb_backup_cuser in ids}
