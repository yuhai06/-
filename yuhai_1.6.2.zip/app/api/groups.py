# -*- coding: utf-8 -*-
"""账号分组：用户把每个号划到「发布号」或「授权号」。

═══════════════════════════════════════════════════════════════
用户需求（2026-11-12）：
    "能不能自定义分组啊，由用户把个号分成发布号和授权号，
     然后发布号用来显示在发布界面，授权号显示在授权界面"

设计：
    · envs.user_group   'publish' | 'auth' | ''
        空串 = 未分组，两个界面都显示（向后兼容现有数据）
    · pages.group_override  'publish' | 'auth' | ''
        单个主页可以覆盖所属环境的分组（比如某发布号下的某个主页只想当授权用）

接口：
    GET  /api/groups                 分组概况（每组几个号、几个主页）
    POST /api/groups/env             设置某个号的分组
    POST /api/groups/bulk            批量设置
    POST /api/groups/page            设置单个主页的分组覆盖
═══════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import logging
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.db import db, now_iso

log = logging.getLogger("yuhai.groups")
router = APIRouter()

GroupName = Literal["publish", "auth", ""]


def _norm(g: str) -> str:
    v = (g or "").strip().lower()
    return v if v in ("publish", "auth") else ""


@router.get("/groups")
async def list_groups():
    """分组概况：每组多少号、多少主页。"""
    try:
        envs = db.q(
            """SELECT e.container_code, e.name, e.role,
                      COALESCE(e.user_group,'') AS user_group,
                      e.status, e.c_user,
                      (SELECT COUNT(*) FROM pages p
                        WHERE p.env_code = e.container_code) AS pages
                 FROM envs e
                WHERE e.status <> 'removed'
                ORDER BY CASE COALESCE(e.user_group,'')
                           WHEN 'publish' THEN 0
                           WHEN 'auth' THEN 1 ELSE 2 END,
                         e.container_code""") or []
    except Exception as e:
        raise HTTPException(500, f"读环境失败: {e}")

    out: dict[str, list] = {"publish": [], "auth": [], "": []}
    for r in envs:
        g = _norm(r["user_group"])
        out.setdefault(g, []).append({
            "envCode": r["container_code"],
            "name": r["name"] or r["container_code"],
            "role": r["role"] or "",
            "status": r["status"] or "",
            "cUser": r["c_user"] or "",
            "pages": int(r["pages"] or 0),
            "userGroup": g,
        })

    return {
        "ok": True,
        "groupCounts": {
            "publish": len(out.get("publish") or []),
            "auth": len(out.get("auth") or []),
            "ungrouped": len(out.get("") or []),
        },
        "pageCounts": {
            "publish": sum(x["pages"] for x in (out.get("publish") or [])),
            "auth": sum(x["pages"] for x in (out.get("auth") or [])),
            "ungrouped": sum(x["pages"] for x in (out.get("") or [])),
        },
        "publish": out.get("publish") or [],
        "auth": out.get("auth") or [],
        "ungrouped": out.get("") or [],
    }


class SetEnvGroupReq(BaseModel):
    envCode: str
    group: str = ""            # publish | auth | ""（空 = 未分组）


@router.post("/groups/env")
async def set_env_group(req: SetEnvGroupReq):
    """设置单个号的分组。"""
    code = (req.envCode or "").strip()
    if not code:
        raise HTTPException(400, "envCode 不能为空")
    row = db.q1("SELECT container_code FROM envs WHERE container_code=?", (code,))
    if not row:
        raise HTTPException(404, f"环境 {code} 不存在")

    g = _norm(req.group)
    db.exec("UPDATE envs SET user_group=?, updated_at=? WHERE container_code=?",
            (g or None, now_iso(), code))
    db.log_event("ok", "groups",
                 f"{code} 分组设为「{g or '未分组'}」")
    return {"ok": True, "envCode": code, "group": g}


class BulkGroupReq(BaseModel):
    envCodes: list[str] = Field(default_factory=list)
    group: str = ""


@router.post("/groups/bulk")
async def set_bulk_group(req: BulkGroupReq):
    """批量设置分组。"""
    codes = [c.strip() for c in (req.envCodes or []) if c.strip()]
    if not codes:
        raise HTTPException(400, "envCodes 不能为空")
    g = _norm(req.group)
    n = 0
    for c in codes:
        try:
            db.exec("UPDATE envs SET user_group=?, updated_at=? "
                    "WHERE container_code=?", (g or None, now_iso(), c))
            n += 1
        except Exception as e:
            log.warning("设置 %s 分组失败: %s", c, e)
    db.log_event("ok", "groups", f"批量设置 {n} 个号为「{g or '未分组'}」")
    return {"ok": True, "updated": n, "group": g}


class SetPageGroupReq(BaseModel):
    pageId: str
    group: str = ""            # publish | auth | ""（空 = 跟随环境）


@router.post("/groups/page")
async def set_page_group(req: SetPageGroupReq):
    """单个主页的分组覆盖。

    用途：某个发布号下有个主页不想拿来发，只想挂在授权页。
    """
    pid = (req.pageId or "").strip()
    if not pid:
        raise HTTPException(400, "pageId 不能为空")
    row = db.q1("SELECT page_id FROM pages WHERE page_id=?", (pid,))
    if not row:
        raise HTTPException(404, f"主页 {pid} 不存在")

    g = _norm(req.group)
    db.exec("UPDATE pages SET group_override=? WHERE page_id=?",
            (g or None, pid))
    return {"ok": True, "pageId": pid, "group": g, "inherit": not g}


@router.post("/groups/auto-init")
async def auto_init_groups():
    """按现有 role 自动初始化一次分组（只填空的，不覆盖用户已设的）。

    publisher → publish
    backup / spare → auth
    """
    rows = db.q("SELECT container_code, role FROM envs "
                "WHERE status <> 'removed' "
                "AND (user_group IS NULL OR user_group='')") or []
    n = 0
    for r in rows:
        g = "publish" if (r["role"] or "") == "publisher" else "auth"
        try:
            db.exec("UPDATE envs SET user_group=?, updated_at=? "
                    "WHERE container_code=?", (g, now_iso(), r["container_code"]))
            n += 1
        except Exception as e:
            log.warning("初始化 %s 失败: %s", r["container_code"], e)
    db.log_event("ok", "groups", f"按 role 初始化 {n} 个号的分组")
    return {"ok": True, "initialized": n}
