"""发布链接提取：只提取「本批次刚发出去的」视频链接。

用户要求：
    · 手动点「提取」，不自动
    · 只提取本次发的这一批
    · 防止重复提取 —— 之前提取过但还没发布的，只补漏的

实现：
    用 batch_id 标记一次发布批次；提取时比对 units 表里该批次的 post_id，
    已提取过的跳过，只补没提取到的。
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import metrics as mx

log = logging.getLogger("yuhai.api.links")
router = APIRouter(tags=["links"])


@router.get("/links")
async def list_links(page_id: str = "", include_disabled: bool = False):
    sql = "SELECT * FROM promo_links WHERE 1=1"
    params: list[Any] = []
    if page_id:
        sql += " AND (page_id=? OR page_id='' OR page_id IS NULL)"
        params.append(page_id)
    if not include_disabled:
        sql += " AND enabled=1"
    sql += " ORDER BY page_id, created_at DESC"
    return {"items": db.q(sql, params)}


class LinkReq(BaseModel):
    label: str
    url: str
    pageId: str = ""
    weight: int = 1
    note: str = ""


@router.post("/links")
async def add_link(req: LinkReq):
    if not req.url.strip():
        raise HTTPException(400, "URL 不能为空")
    from app.services import caption
    lid = caption.add_link(req.label or req.url[:40], req.url.strip(),
                           req.pageId, req.weight, req.note)
    db.log_event("ok", "links", f"新增链接 {req.label} → {req.url[:60]}")
    return {"ok": True, "id": lid}


@router.delete("/links/{lid}")
async def del_link(lid: str):
    db.exec("DELETE FROM promo_links WHERE id=?", (lid,))
    return {"ok": True}


class LinkPatch(BaseModel):
    enabled: bool | None = None
    weight: int | None = None
    label: str | None = None


@router.patch("/links/{lid}")
async def patch_link(lid: str, p: LinkPatch):
    f = p.model_dump(exclude_none=True)
    if not f:
        return {"ok": True}
    sets = ",".join(f"{k}=?" for k in f)
    db.exec(f"UPDATE promo_links SET {sets} WHERE id=?", (*f.values(), lid))
    return {"ok": True}


# ---------------- 标题（按剧实时生成，不再落库）----------------
#
# 2026-11-12：标题池已废弃。原来的 /titles 系列接口读写 title_pool 表，
# 但实际场景是"每批发布不同的剧"，池子只会堆无关标题。
# 现在这些接口保留路径（避免前端 404），行为改成：
#   · GET  /titles          → 返回空列表 + 说明
#   · POST /titles/generate → 按剧名实时生成，**不落库**
#   · POST /titles/pick     → 按剧名实时生成一条
#   · POST /titles          → 不再支持手动入库（返回说明）
@router.get("/titles")
async def list_titles(page_id: str = "", drama: str = ""):
    from app.services import caption as cap
    return {
        "items": [],
        "reference": cap.REFERENCE_TITLE,
        "mode": "on_the_fly",
        "note": "标题已改为按剧实时生成，不再落库",
        "cache": cap.cache_stats(),
    }


class GenTitlesReq(BaseModel):
    pageId: str = ""
    drama: str = ""
    reference: str = ""
    n: int = 5
    model: str = ""
    save: bool = False        # 保留字段，但已不落库


@router.post("/titles/generate")
async def gen_titles(req: GenTitlesReq):
    from app.services import caption
    r = db.q1("SELECT name FROM pages WHERE page_id=?", (req.pageId,))
    page_name = (r or {}).get("name") or ""
    res = await caption.generate_titles(
        req.reference or caption.REFERENCE_TITLE,
        max(1, min(20, req.n)), req.model, page_name,
        drama=req.drama)
    return {"ok": True, "titles": res["titles"], "source": res["source"],
            "lang": res.get("lang"), "saved": 0,
            "note": "已改为实时生成，不写入数据库"}


@router.post("/titles/pick")
async def pick_title(page_id: str = "", reference: str = "", drama: str = ""):
    from app.services import caption
    r = await caption.generate_for_drama(drama, 1)
    titles = r.get("titles") or []
    return {"title": (titles[0] if titles else reference
                      or caption.REFERENCE_TITLE),
            "source": r.get("source") or "model"}


class TitleReq(BaseModel):
    pageId: str = ""
    title: str
    ref: str = ""


@router.post("/titles")
async def add_title(req: TitleReq):
    # 不再支持手动入库（没有池子了）
    return {"ok": True, "saved": 0,
            "note": "标题已改为按剧实时生成，不支持手动入库。"
                    "如需固定标题，请在发布页填「指定标题」。"}


@router.delete("/titles/{tid}")
async def del_title(tid: str):
    return {"ok": True, "note": "标题池已废弃，无需删除"}


# ---------------- 链接提取 ----------------
class ExtractLinksReq(BaseModel):
    pageIds: list[str] = []
    envCode: str = ""
    days: int = 7
    onlyMissing: bool = True      # 只补没提取过的
    batchId: str = ""


@router.post("/links/extract")
async def extract_links(req: ExtractLinksReq):
    """从 Business Suite 内容库提取已发布视频的 permalink。

    onlyMissing=True 时只补 units 表里还没 permalink 的那些。
    """
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的发布号环境")

    targets = req.pageIds or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]

    job_id = "job-" + uuid.uuid4().hex[:12]
    batch_id = req.batchId or ("b-" + uuid.uuid4().hex[:8])
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "extract_links", f"提取链接 {len(targets)} 个主页", "running", 0,
             json.dumps({**req.model_dump(), "batchId": batch_id}, ensure_ascii=False),
             now_iso(), now_iso()))
    asyncio.create_task(_run_extract(job_id, batch_id, targets, env,
                                     req.days, req.onlyMissing))
    return {"ok": True, "jobId": job_id, "batchId": batch_id}


async def _run_extract(job_id: str, batch_id: str, targets: list[str],
                       env: dict, days: int, only_missing: bool) -> None:
    from app.adapters.facebook import FB
    import httpx

    added, skipped, failed = 0, 0, 0
    details: list[dict] = []

    try:
        async with FB(int(env["cdp_port"])) as fb:
            for i, pid in enumerate(targets):
                row = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
                if not row or not row["asset_id"]:
                    failed += 1
                    continue

                # 该主页已有的 post_id（用于补漏）
                have = {r["post_id"] for r in db.q(
                    "SELECT post_id FROM units WHERE page_id=? AND post_id IS NOT NULL",
                    (pid,))}
                extracted = {r["post_id"] for r in db.q(
                    "SELECT post_id FROM link_extracts WHERE page_id=?", (pid,))}

                try:
                    rows = await mx.collect_via_suite(fb, row["asset_id"],
                                                      env["container_code"], pid)
                    # 同时尝试用 Graph API 拿 permalink（有 token 时最准）
                    perma = {}
                    try:
                        integ = db.q1("SELECT * FROM integrations WHERE id='graph'")
                        token = json.loads((integ or {}).get("config") or "{}").get("token")
                        if token:
                            async with httpx.AsyncClient(timeout=30) as c:
                                r = await c.get(
                                    f"https://graph.facebook.com/v21.0/{pid}/videos",
                                    params={"fields": "id,permalink_url",
                                            "limit": 100, "access_token": token})
                            if r.status_code == 200:
                                for v in (r.json().get("data") or []):
                                    if v.get("permalink_url"):
                                        perma[v["id"]] = v["permalink_url"]
                    except Exception as e:
                        log.debug("graph permalink failed: %s", e)

                    for x in rows:
                        if "_guard" in x:
                            details.append({"pageId": pid, "guard": x["_guard"]})
                            break
                        post_id = x.get("post_id")
                        if not post_id:
                            continue
                        if only_missing and (post_id in extracted or post_id in have):
                            skipped += 1
                            continue
                        url = perma.get(post_id) or x.get("permalink_url") or ""
                        if not url:
                            # 用 page_id + post_id 拼标准 permalink
                            url = (f"https://www.facebook.com/{row['asset_id']}"
                                   f"/videos/{post_id}" if post_id.isdigit()
                                   else f"https://www.facebook.com/watch/?v={post_id}")
                        lid = "le-" + uuid.uuid4().hex[:10]
                        try:
                            db.exec(
                                "INSERT INTO link_extracts(id,page_id,post_id,permalink,"
                                "title,published_date,batch_id,created_at)"
                                " VALUES(?,?,?,?,?,?,?,?)",
                                (lid, pid, post_id, url, (x.get("title") or "")[:200],
                                 x.get("published_date") or "", batch_id, now_iso()))
                            added += 1
                        except Exception:
                            skipped += 1
                        # 回写 units.perma
                        if x.get("published_date"):
                            try:
                                db.exec("UPDATE units SET permalink=? WHERE post_id=?",
                                        (url, post_id))
                            except Exception:
                                pass
                except Exception as e:
                    failed += 1
                    details.append({"pageId": pid, "error": str(e)[:100]})

                db.exec("UPDATE jobs SET progress=? WHERE id=?",
                        (int((i + 1) / len(targets) * 100), job_id))
                await asyncio.sleep(1.5)

        res = {"added": added, "skipped": skipped, "failed": failed,
               "batchId": batch_id, "details": details[:40]}
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps(res, ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "links",
                     f"链接提取完成：新增 {added}，跳过 {skipped}，失败 {failed}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "links", str(e)[:200])


@router.get("/links/extracted")
async def list_extracted(batch_id: str = "", page_id: str = "", limit: int = 200):
    sql = "SELECT * FROM link_extracts WHERE 1=1"
    params: list[Any] = []
    if batch_id:
        sql += " AND batch_id=?"
        params.append(batch_id)
    if page_id:
        sql += " AND page_id=?"
        params.append(page_id)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(min(limit, 1000))
    rows = db.q(sql, params)
    missing = db.q1(
        "SELECT COUNT(*) c FROM units WHERE permalink IS NULL OR permalink=''")
    return {"items": rows, "batches": db.q(
        "SELECT batch_id, COUNT(*) n, MAX(created_at) ts FROM link_extracts "
        "GROUP BY batch_id ORDER BY ts DESC LIMIT 20"),
        "missingInUnits": missing["c"] if missing else 0}
