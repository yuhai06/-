"""账号主体 API（多号架构）。

一个号 = FB 个人号 + Hubstudio 环境 + 名下一批主页。
支持继续增加：新增号 → 拉它的主页 → 授权给备份号。

结构：
    accounts（号）  1 ── n  pages（主页）  n ── n  accounts（授权关系）
"""
from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso

log = logging.getLogger("yuhai.api.accounts")
router = APIRouter(tags=["accounts"])


@router.get("/accounts")
async def list_accounts():
    from app.services import quota as q
    rows = db.q("SELECT * FROM accounts ORDER BY role, created_at")
    out = []
    for r in rows:
        pages = db.q1(
            "SELECT COUNT(*) c FROM pages WHERE env_code=?",
            (r["env_code"],)) if r["env_code"] else {"c": 0}
        qi = q.resolve_quota(r["id"])
        out.append({
            "id": r["id"], "label": r["label"], "role": r["role"],
            "cUser": r["c_user"], "email": r["email"],
            "envCode": r["env_code"], "groupName": r["group_name"],
            "enabled": bool(r["enabled"]), "note": r["note"],
            "pages": pages["c"] if pages else 0,
            "createdAt": r["created_at"],
            # 建页额度
            "quotaLevel": qi.get("level"),
            "quotaLabel": q.QUOTA_LEVELS.get(qi.get("level", "new"), {}).get("label", ""),
            "quotaLimit": qi.get("limit"),
            "quotaUsed": qi.get("usedToday"),
            "quotaRemaining": qi.get("remaining"),
            "quotaSuggest": qi.get("suggestLevel"),
            "quotaReason": qi.get("reason"),
        })
    groups: dict[str, int] = {}
    for r in out:
        g = r["groupName"] or "未分组"
        groups[g] = groups.get(g, 0) + 1
    return {"items": out, "groups": groups,
            "levels": q.QUOTA_LEVELS,
            "publishers": [r for r in out if r["role"] == "publisher"],
            "backups": [r for r in out if r["role"] == "backup"]}


@router.get("/accounts/quota")
async def all_quota():
    from app.services import quota as q
    return {"items": q.all_quotas(), "levels": q.QUOTA_LEVELS}


@router.get("/accounts/{aid}/quota")
async def one_quota(aid: str, override: str = ""):
    from app.services import quota as q
    return q.resolve_quota(aid, override)


class QuotaReq(BaseModel):
    level: str
    note: str = ""


@router.post("/accounts/{aid}/quota")
async def set_quota_api(aid: str, req: QuotaReq):
    """手动调整建页额度档位。

    new=新号6-7 / limited=受限1-2 / blocked=禁建
    """
    from app.services import quota as q
    r = q.set_quota(aid, req.level, req.note)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "设置失败")
    return r


class AccountReq(BaseModel):
    label: str
    role: str = "publisher"
    cUser: str = ""
    email: str = ""
    envCode: str = ""
    groupName: str = ""
    note: str = ""
    pageQuota: str = "new"


@router.post("/accounts")
async def add_account(req: AccountReq):
    from app.services import identity as ident
    if req.role not in ident.ACCOUNT_ROLES:
        raise HTTPException(400, "role 只能是 publisher 或 backup")
    if not req.label.strip():
        raise HTTPException(400, "label 不能为空")
    if req.pageQuota not in ident.QUOTA_LEVELS:
        raise HTTPException(400, "pageQuota 只能是 new / limited / blocked")
    c_user = ""
    if (req.cUser or "").strip():
        try:
            c_user = ident.normalize_profile_id(req.cUser, field="c_user")
        except ident.ValidationError as e:
            raise HTTPException(422, str(e))
        dup = db.q1("SELECT id,label FROM accounts WHERE c_user=? AND enabled=1",
                    (c_user,))
        if dup:
            raise HTTPException(409,
                f"profile ID {c_user} 已被「{dup['label']}」占用，不能重复绑定")
    aid = "acc-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO accounts(id,label,role,c_user,email,env_code,group_name,"
            "page_quota,enabled,note,created_at) VALUES(?,?,?,?,?,?,?,?,1,?,?)",
            (aid, req.label.strip(), req.role, c_user, req.email,
             req.envCode, req.groupName, req.pageQuota, req.note, now_iso()))
    db.log_event("ok", "accounts",
                 f"新增{'发布' if req.role == 'publisher' else '备份'}号 {req.label}"
                 f"（建页额度 {req.pageQuota}）")
    return {"ok": True, "id": aid}


class AccountPatch(BaseModel):
    label: str | None = None
    cUser: str | None = None
    email: str | None = None
    envCode: str | None = None
    groupName: str | None = None
    enabled: bool | None = None
    note: str | None = None


@router.patch("/accounts/{aid}")
async def patch_account(aid: str, p: AccountPatch):
    from app.services import identity as ident
    f = {k: v for k, v in p.model_dump(exclude_none=True).items()}
    if not f:
        return {"ok": True}
    if "cUser" in f:
        raw = (f["cUser"] or "").strip()
        if raw:
            try:
                f["cUser"] = ident.normalize_profile_id(raw, field="c_user")
            except ident.ValidationError as e:
                raise HTTPException(422, str(e))
            dup = db.q1("SELECT id,label FROM accounts WHERE c_user=? AND id<>?"
                        " AND enabled=1", (f["cUser"], aid))
            if dup:
                raise HTTPException(409,
                    f"profile ID {f['cUser']} 已被「{dup['label']}」占用")
        else:
            f["cUser"] = ""
    col = {"cUser": "c_user", "envCode": "env_code", "groupName": "group_name"}
    sets = ",".join(f"{col.get(k, k)}=?" for k in f)
    vals = [int(v) if k == "enabled" else v for k, v in f.items()]
    db.exec(f"UPDATE accounts SET {sets} WHERE id=?", (*vals, aid))
    return {"ok": True}


@router.delete("/accounts/{aid}")
async def del_account(aid: str):
    r = db.q1("SELECT * FROM accounts WHERE id=?", (aid,))
    if not r:
        raise HTTPException(404, "号不存在")
    db.exec("UPDATE accounts SET enabled=0 WHERE id=?", (aid,))
    db.log_event("warn", "accounts", f"停用号 {r['label']}")
    return {"ok": True}


# ---------------- 从环境自动建号 ----------------
# 环境表里 c_user 可能为空（登录态没探测到），用已知常量兜底
_KNOWN = {
    "publisher": {"email_prefix": "m19897410232", "c_user": "61595095770895"},
    "backup": {"email_prefix": "haiyu325355", "c_user": "61595415385701"},
}


@router.post("/accounts/from-envs")
async def from_envs():
    """按 Hubstudio 环境自动建/更新号记录。"""
    from app.config import settings
    envs = db.q("SELECT * FROM envs WHERE status<>'removed'")
    created, updated = 0, 0
    for e in envs:
        role = e["role"]
        if role not in ("publisher", "backup"):
            continue
        exist = db.q1("SELECT * FROM accounts WHERE env_code=?", (e["container_code"],))
        label = e["name"] or e["container_code"]

        # c_user 优先级：环境表 > 已知常量 > 留空
        cu = (e["c_user"] or "").strip()
        if not cu:
            if role == "publisher":
                cu = settings.fb_publisher_cuser or _KNOWN["publisher"]["c_user"]
            else:
                cu = settings.fb_backup_cuser or _KNOWN["backup"]["c_user"]

        if exist:
            db.exec("UPDATE accounts SET label=?,c_user=?,email=?,role=? WHERE id=?",
                    (label, cu, e["account"] or "", role, exist["id"]))
            updated += 1
        else:
            db.exec("INSERT INTO accounts(id,label,role,c_user,email,env_code,"
                    "group_name,enabled,note,created_at) VALUES(?,?,?,?,?,?,?,1,?,?)",
                    ("acc-" + uuid.uuid4().hex[:10], label, role, cu,
                     e["account"] or "", e["container_code"], "",
                     "自动从环境创建", now_iso()))
            created += 1
    return {"ok": True, "created": created, "updated": updated}


# ---------------- 多授权号矩阵 ----------------
@router.get("/accounts/matrix")
async def auth_matrix():
    """主页 × 号的授权矩阵（支持一个主页授给多个号）。"""
    accounts = db.q("SELECT * FROM accounts WHERE enabled=1 ORDER BY role, label")
    pages = db.q("SELECT page_id,name,asset_id,env_code,health FROM pages ORDER BY name")
    rows = []
    for p in pages:
        rec = {"pageId": p["page_id"], "pageName": p["name"],
               "assetId": p["asset_id"], "envCode": p["env_code"],
               "health": p["health"], "grants": []}
        for a in accounts:
            m = db.q1(
                "SELECT * FROM page_role_map WHERE page_id=? AND account_id=?",
                (p["page_id"], a["id"]))
            rec["grants"].append({
                "accountId": a["id"], "label": a["label"], "role": a["role"],
                "present": bool(m), "state": (m or {}).get("state"),
                "grantedAt": (m or {}).get("granted_at"),
            })
        rows.append(rec)
    return {"accounts": [
        {"id": a["id"], "label": a["label"], "role": a["role"],
         "cUser": a["c_user"], "groupName": a["group_name"]} for a in accounts],
        "rows": rows}


class GrantMultiReq(BaseModel):
    pageIds: list[str]
    accountIds: list[str]
    stopOnMismatch: bool = True


@router.post("/accounts/grant-multi")
async def grant_multi(req: GrantMultiReq):
    """把多个主页授权给多个号。

    安全约束继承：只用 profile ID；对不上立即中止。
    """
    if not req.pageIds or not req.accountIds:
        raise HTTPException(400, "pageIds / accountIds 不能为空")

    from app.services import identity as ident

    accs = []
    for aid in req.accountIds:
        try:
            accs.append(ident.require_account_for_write(aid))
        except ident.ValidationError as e:
            raise HTTPException(400, str(e))
    for pid in req.pageIds:
        try:
            ident.require_page(pid)
        except ident.ValidationError as e:
            raise HTTPException(400, str(e))

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = []
    for pid in req.pageIds:
        p = db.q1("SELECT name FROM pages WHERE page_id=?", (pid,))
        for a in accs:
            steps.append({"name": f"{(p or {}).get('name') or pid} → {a['label']}",
                          "state": "wait", "note": ""})
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "authz_multi",
             f"授权 {len(req.pageIds)} 主页 × {len(accs)} 号", "queued", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    import asyncio
    asyncio.create_task(_run_grant_multi(job_id, list(req.pageIds), accs))
    return {"ok": True, "jobId": job_id, "total": len(steps),
            "note": "已入队，正在用各号的环境读取真实权限列表"}


async def _run_grant_multi(job_id: str, page_ids: list[str], accs: list[dict]) -> None:
    """真实执行：逐号用自己的环境读取权限列表，据实写 active/pending。"""
    from app.adapters.facebook import FB, FBError
    from app.services import identity as ident

    def _steps() -> list[dict]:
        cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
        try:
            return json.loads((cur or {}).get("steps") or "[]")
        except Exception:
            return []

    def _save(arr: list[dict], progress: int) -> None:
        db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                (json.dumps(arr, ensure_ascii=False), progress, job_id))

    arr = _steps()
    idx = 0
    ok_n, fail_n = 0, 0
    try:
        for acc in accs:
            try:
                env = ident.require_account_env(acc)
            except ident.ValidationError as e:
                for pid in page_ids:
                    if idx < len(arr):
                        arr[idx].update(state="err", note=str(e)[:80])
                    idx += 1
                fail_n += len(page_ids)
                _save(arr, int(idx / max(1, len(arr)) * 100))
                continue
            try:
                async with FB(int(env["cdp_port"])) as fb:
                    await fb.assert_identity(acc["c_user"])
                    for pid in page_ids:
                        page = db.q1("SELECT name,asset_id FROM pages WHERE page_id=?",
                                     (pid,)) or {}
                        asset = page.get("asset_id")
                        note = ""
                        state = "pending"
                        if not asset:
                            state, note = "err", "缺少 asset_id，无法定位权限页"
                        else:
                            members = await fb.list_roles(asset)
                            ids = {m.get("c_user") for m in members if m.get("c_user")}
                            if acc["c_user"] in ids:
                                state, note = "done", "已在权限列表中"
                            else:
                                state, note = "warn", "未在权限列表，需人工邀请"
                        ts = now_iso()
                        if state == "done":
                            db.exec(
                                "INSERT INTO page_role_map(page_id,account_id,c_user,"
                                "role,state,granted_at,checked_at) VALUES(?,?,?,?,?,?,?)"
                                " ON CONFLICT(page_id,account_id) DO UPDATE SET"
                                " state='active',checked_at=excluded.checked_at",
                                (pid, acc["id"], acc["c_user"], "admin", "active", ts, ts))
                            db.exec(
                                "INSERT INTO page_roles(page_id,c_user,role,state,"
                                "granted_at,checked_at) VALUES(?,?,?,?,?,?)"
                                " ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                " state='active',checked_at=excluded.checked_at",
                                (pid, acc["c_user"], "full", "active", ts, ts))
                        elif state == "warn":
                            db.exec(
                                "INSERT INTO page_role_map(page_id,account_id,c_user,"
                                "role,state,granted_at,checked_at) VALUES(?,?,?,?,?,?,?)"
                                " ON CONFLICT(page_id,account_id) DO UPDATE SET"
                                " state='pending',checked_at=excluded.checked_at",
                                (pid, acc["id"], acc["c_user"], "admin", "pending", ts, ts))
                        if idx < len(arr):
                            arr[idx].update(state=state, note=note)
                        idx += 1
                        if state in ("done", "warn"):
                            ok_n += 1
                        else:
                            fail_n += 1
                        _save(arr, int(idx / max(1, len(arr)) * 100))
            except (FBError, Exception) as e:
                for pid in page_ids:
                    if idx < len(arr):
                        arr[idx].update(state="err", note=str(e)[:80])
                    idx += 1
                fail_n += len(page_ids)
                _save(arr, int(idx / max(1, len(arr)) * 100))
        status = "done" if fail_n == 0 else ("blocked" if ok_n else "failed")
        db.exec("UPDATE jobs SET status=?,result=?,progress=100,ended_at=? WHERE id=?",
                (status, json.dumps({"ok": ok_n, "fail": fail_n},
                                    ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok" if status == "done" else "warn", "authz",
                     f"多号授权完成：成功 {ok_n} / 失败 {fail_n}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


class MapReq(BaseModel):
    pageId: str
    accountId: str
    state: str = ""            # 空 = 由 confirmed 决定
    role: str = "admin"
    confirmed: bool = False    # 人工在浏览器里核对完权限后才置 True


@router.post("/accounts/map")
async def map_role(req: MapReq):
    """登记一条授权关系。

    语义修正：手工点「授」只是**登记**，记 pending；
    只有显式 confirmed=True（人工核对过）或 /authz/verify 的平台读取
    才能把状态写成 active。避免把本地登记当成 Meta 已授权。
    """
    from app.services import identity as ident

    try:
        page = ident.require_page(req.pageId)
        a = ident.require_account_for_write(req.accountId)
    except ident.ValidationError as e:
        raise HTTPException(400, str(e))
    if req.role not in ("admin", "editor"):
        raise HTTPException(400, "role 只能是 admin 或 editor")
    if req.state and req.state not in ident.AUTHZ_STATES:
        raise HTTPException(400, f"state 只能是 {sorted(ident.AUTHZ_STATES)}")

    state = req.state or ("active" if req.confirmed else "pending")
    if state == "active" and not req.confirmed:
        state = "pending"

    ts = now_iso()
    db.exec(
        "INSERT INTO page_role_map(page_id,account_id,c_user,role,state,granted_at,"
        "checked_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(page_id,account_id)"
        " DO UPDATE SET role=excluded.role,state=excluded.state,"
        " checked_at=excluded.checked_at",
        (page["page_id"], a["id"], a["c_user"], req.role, state, ts, ts))
    db.exec(
        "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
        " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
        " state=excluded.state,checked_at=excluded.checked_at",
        (page["page_id"], a["c_user"],
         "full" if req.role == "admin" else "partial", state, ts, ts))
    db.log_event("info", "authz",
                 f"{page['name']} ↔ {a['label']} 登记为 {state}"
                 f"（{'人工核对' if req.confirmed else '仅本地登记'}）")
    return {"ok": True, "state": state, "verified": state == "active"}


class BindReq(BaseModel):
    envCode: str
    pageIds: list[str] = []


@router.post("/accounts/bind-pages")
async def bind_pages(req: BindReq):
    """把一批主页归属到某个环境（即某个号）。

    这是「提取时一次同步全部信息」的归属步骤：
    提取到的主页按环境绑定，视频数据才能按号正确汇总。
    """
    if not req.envCode:
        raise HTTPException(400, "envCode 不能为空")
    env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        raise HTTPException(404, "环境不存在")

    ids = req.pageIds or [p["page_id"] for p in db.q("SELECT page_id FROM pages")]
    n = 0
    for pid in ids:
        r = db.q1("SELECT page_id FROM pages WHERE page_id=?", (pid,))
        if not r:
            continue
        db.exec("UPDATE pages SET env_code=? WHERE page_id=?", (req.envCode, pid))
        n += 1

    # 确保该环境有对应的号记录
    acc = db.q1("SELECT * FROM accounts WHERE env_code=?", (req.envCode,))
    if not acc and env["role"] in ("publisher", "backup"):
        import uuid as _u
        db.exec("INSERT INTO accounts(id,label,role,c_user,email,env_code,"
                "group_name,page_quota,enabled,note,created_at)"
                " VALUES(?,?,?,?,?,?,?,?,1,?,?)",
                ("acc-" + _u.uuid4().hex[:10], env["name"], env["role"],
                 env["c_user"] or "", env["account"] or "", req.envCode,
                 "", "new", "绑定主页时自动创建", now_iso()))

    db.log_event("ok", "accounts", f"{n} 个主页归属到 {env['name']}")
    return {"ok": True, "bound": n, "envCode": req.envCode}
