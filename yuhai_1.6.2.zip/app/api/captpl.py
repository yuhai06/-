"""发布文案模板 API：填一条参考文案 → 生成多个变体。"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import caption_tpl as ct

log = logging.getLogger("yuhai.api.captpl")
router = APIRouter(tags=["captpl"])


@router.get("/captions/templates")
async def list_tpl():
    return {"items": ct.list_templates(), "vars": ct.VARS,
            "default": ct.DEFAULT_BODY}


class TplReq(BaseModel):
    name: str = ""
    body: str
    id: str = ""


@router.post("/captions/templates")
async def save_tpl(req: TplReq):
    try:
        tid = ct.save_template(req.name, req.body, req.id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "id": tid}


@router.delete("/captions/templates/{tid}")
async def del_tpl(tid: str):
    db.exec("DELETE FROM caption_templates WHERE id=?", (tid,))
    return {"ok": True}


class GenReq(BaseModel):
    body: str = ""
    templateId: str = ""
    drama: str = ""
    pageId: str = ""
    n: int = 5
    model: str = ""


@router.post("/captions/generate")
async def gen(req: GenReq):
    """填一条参考文案 → 生成 N 个变体（链接原样保留）。"""
    body = req.body.strip()
    if not body and req.templateId:
        t = ct.get_template(req.templateId)
        body = (t or {}).get("body") or ""
    if not body:
        body = ct.DEFAULT_BODY

    r = await ct.generate_variants(body, req.drama, req.n, req.model,
                                   req.templateId, req.pageId)
    return r


@router.get("/captions/variants")
async def variants(pageId: str = "", limit: int = 100):
    return {"items": ct.list_variants(pageId, limit)}


@router.delete("/captions/variants/{vid}")
async def del_variant(vid: str):
    db.exec("DELETE FROM caption_variants WHERE id=?", (vid,))
    return {"ok": True}


@router.get("/captions/pool")
async def pool_status(pageId: str = "", drama: str = ""):
    """标题状态（2026-11-12 起改为按剧实时生成，不再有落库池）。

    保留这个端点是为了不让旧前端 404；返回缓存状态而不是池内条数。
    """
    from app.services import caption as cap
    st = cap.cache_stats()
    return {
        "ok": True,
        "mode": "on_the_fly",
        "count": sum(d.get("left", 0) for d in (st.get("dramas") or [])),
        "cache": st,
        "note": "标题按剧实时生成，不落库；这里是进程内缓存状态",
        "items": [],
    }


class AutoGenReq(BaseModel):
    pageId: str = ""
    drama: str = ""
    ref: str = ""
    want: int = 8
    model: str = ""


@router.post("/captions/pool/ensure")
async def pool_ensure(req: AutoGenReq):
    """按剧实时生成一批标题（不落库）。"""
    from app.services import caption as cap
    want = max(1, min(50, req.want or 8))
    r = await cap.generate_for_drama(req.drama, want, req.model)
    return {"ok": True,
            "generated": len(r.get("titles") or []),
            "source": r.get("source"),
            "drama": req.drama,
            "cached": r.get("cached"),
            "sample": (r.get("titles") or [])[:5]}


class PreviewReq(BaseModel):
    pageId: str = ""
    drama: str = ""
    link: str = ""
    ep: str = ""


@router.post("/captions/preview")
async def preview(req: PreviewReq):
    """预览最终文案（占位符已替换）。"""
    from app.services import caption as cap
    link = req.link
    if not link:
        picked = cap.pick_link(req.pageId)
        link = picked["url"] if picked else ""
    r = ct.pick_variant(req.pageId, req.drama, link, req.ep)
    return {"ok": True, "body": r["body"], "source": r["source"],
            "link": link}
