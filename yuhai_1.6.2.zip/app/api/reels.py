"""ReelsPublisher 内核发布 API（批量发布，走官方 worker）。"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import reels as rl

log = logging.getLogger("yuhai.api.reels")
router = APIRouter(tags=["reels"])


@router.get("/reels/status")
async def reels_status():
    """内核可用性 + 已规划主页。"""
    info = rl.available()
    return {**info, "pages": rl.plan_pages()}


@router.post("/reels/check")
async def reels_check():
    """检查每个环境是否有可用的 Meta 工作标签。"""
    r = await rl.check_browsers()
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "检查失败")
    return r


@router.get("/reels/materials")
async def reels_materials(directory: str = ""):
    """扫描素材目录（不启动发布）。"""
    from app import paths
    d = directory or str(paths.output_root())
    r = await rl.scan_materials(d)
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "扫描失败")
    return {"directory": d,
            "total": r.get("total") or 0,
            "folderCount": r.get("folderCount") or 0,
            "groups": r.get("groups") or [],
            "sampleTitle": r.get("sampleTitle") or "",
            "debug": r}


class ReelsPublishReq(BaseModel):
    directory: str = ""
    description: str = ""          # 固定标题模板（含链接占位）；titleMode=fixed 时使用
    linkPool: str = ""             # 链接池，每行一个；useRandomLink=False 时忽略
    clipsPerPage: int = 1
    concurrency: int = 1
    publishMode: str = "merge"     # merge | folders
    browserIds: list[str] = []
    autoPrepare: bool = True       # 自动开浏览器 + 开工作标签
    pages: list[str] = []          # 只发这些主页（pageId），空=全部
    materials: list[str] = []      # 只用这些素材（文件路径），空=全部

    # ---- 文案来源 ----
    # random : 从每个主页的标题变体池里随机取（多标题随机）
    # fixed  : 全部使用 description
    titleMode: str = "random"
    referenceTitle: str = ""       # 变体池为空时用这个当参考/兜底
    useRandomLink: bool = True     # 链接是否从链接池按主页随机
    fixedTitle: str = ""           # titleMode=fixed 时的标题正文（不含链接）
    uploadStallTimeoutSeconds: int = 180   # 上传卡住容忍秒数（60–3600）


@router.get("/reels/pages")
async def reels_pages():
    """可发布的主页清单（供前端勾选）。"""
    ps = rl.plan_pages()
    out = []
    for p in ps:
        row = db.q1("SELECT name, health, drama, genre FROM pages WHERE page_id=?",
                    (p.get("profileId"),))
        out.append({
            "pageId": p.get("pageId"),
            "pageName": p.get("pageName"),
            "profileId": p.get("profileId"),
            "environmentId": p.get("environmentId"),
            "health": (row or {}).get("health") or "ok",
            "drama": (row or {}).get("drama") or "",
            "genre": (row or {}).get("genre") or "",
            "selectable": ((row or {}).get("health") or "ok") == "ok",
        })
    out.sort(key=lambda x: str(x.get("pageName") or ""))
    return {"items": out, "total": len(out),
            "usable": sum(1 for x in out if x["selectable"])}


@router.get("/reels/files")
async def reels_files(directory: str = "", limit: int = 300):
    """素材文件清单（供前端勾选）。"""
    from app import paths
    d = directory or str(paths.output_root())
    root = Path(d)
    if not root.exists():
        return {"items": [], "total": 0, "directory": d}
    items = []
    for f in sorted(root.rglob("*.mp4")):
        is_mix = any(k in f.stem for k in ("主线版", "精品混剪", "混剪"))
        rel = str(f.relative_to(root))
        # 剧名 = 文件所在文件夹名（worker 也是这样取 title）
        # 前端按这个分组，不能让它从文件名猜
        folder = f.parent.name if f.parent != root else ""
        items.append({
            "path": str(f),
            "file": f.name,
            "rel": rel,
            "title": folder,          # ← 关键：剧名来源
            "folder": folder,
            "sizeMb": round(f.stat().st_size / 1048576, 1),
            "kind": "mix" if is_mix else "single",
        })
    # 默认只返回单集（混剪不参与发布）
    singles = [x for x in items if x["kind"] == "single"]
    return {"items": singles[:limit], "total": len(singles),
            "mixCount": len(items) - len(singles),
            "directory": d}


@router.post("/reels/stop")
async def reels_stop(jobId: str = ""):
    """停止发布（不传 jobId 就停全部）。"""
    r = rl.stop_worker(jobId)
    # 把还在 running 的任务标成 stopped
    if jobId:
        db.exec("UPDATE jobs SET status='stopped',ended_at=? WHERE id=? "
                "AND status IN ('running','queued')", (now_iso(), jobId))
    else:
        db.exec("UPDATE jobs SET status='stopped',ended_at=? "
                "WHERE status IN ('running','queued')", (now_iso(),))
    db.log_event("warn", "reels", f"停止发布: {r.get('note')}")
    return {**r, "ok": True}


@router.post("/reels/prepare")
async def reels_prepare(containerCode: str = ""):
    """手动触发：开浏览器 + 整理 Meta 工作标签 + 识别主页。"""
    from app.services import prepare as pz
    r = await pz.prepare_publish(containerCode)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "准备失败")
    return r


def _material_signature(req: ReelsPublishReq) -> str:
    import hashlib
    raw = json.dumps({"pages": sorted(req.pages or []),
                      "materials": sorted(req.materials or []),
                      "clips": req.clipsPerPage}, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _claim_signature(sig: str, job_id: str) -> str:
    """原子占位：同一签名在有活动任务时拒绝再次入队。

    · 检查与插入在同一个写事务里，避免两个并发请求同时通过。
    · 占位带租约：只有「任务已结束」且超过 LOCK_TTL_SEC 才允许接管，
      防止把刚失败的重复提交误判成僵尸；也防止进程崩溃后永久卡死。
    """
    from datetime import datetime, timedelta

    LOCK_TTL_SEC = 600
    now = datetime.now().astimezone()

    def _stale(holder_job: str, updated_at: str) -> bool:
        if not holder_job:
            return True
        row = db.q1("SELECT status FROM jobs WHERE id=?", (holder_job,))
        if not row:
            return True
        if str(row.get("status")) in ("queued", "running"):
            return False
        # 任务已结束：必须等满租约才能接管。
        # 用 since 计算，避免同一秒内 created/updated 相同导致误判「已过期」。
        try:
            t = datetime.fromisoformat(str(updated_at))
        except Exception:
            return True
        age = (now - t).total_seconds()
        return age > LOCK_TTL_SEC

    try:
        with db.tx() as cur:
            row = cur.execute(
                "SELECT job_id,status,updated_at FROM publish_locks WHERE signature=?",
                (sig,)).fetchone()
            if row:
                holder = str(row[0])
                if row[1] == "active" and not _stale(holder, str(row[2])):
                    return holder
                cur.execute(
                    "UPDATE publish_locks SET job_id=?,status='active',"
                    " updated_at=? WHERE signature=?",
                    (job_id, now_iso(), sig))
                return ""
            cur.execute(
                "INSERT INTO publish_locks(signature,job_id,status,created_at,updated_at)"
                " VALUES(?,?,'active',?,?)", (sig, job_id, now_iso(), now_iso()))
            return ""
    except sqlite3.IntegrityError:
        r = db.q1("SELECT job_id FROM publish_locks WHERE signature=?", (sig,))
        return (r or {}).get("job_id") or "?"


def _validate_materials(req: ReelsPublishReq) -> list[str]:
    """素材必须真实存在、是文件、且位于允许的素材根内。"""
    from app import paths

    roots = []
    base = Path(req.directory) if req.directory else Path(paths.output_root())
    for cand in (base, Path(paths.output_root()), Path(paths.library_root())):
        try:
            roots.append(cand.resolve())
        except Exception:
            continue
    out: list[str] = []
    for raw in req.materials or []:
        p = Path(raw)
        if not p.is_absolute():
            p = base / raw
        try:
            p = p.resolve(strict=True)
        except Exception:
            raise HTTPException(400, f"素材不存在: {raw}")
        if not p.is_file():
            raise HTTPException(400, f"素材不是文件: {raw}")
        if p.suffix.lower() not in (".mp4", ".mov", ".m4v"):
            raise HTTPException(400, f"素材不是视频: {raw}")
        if not any((p == r) or r in p.parents for r in roots):
            raise HTTPException(400, f"素材不在素材目录内: {raw}")
        out.append(str(p))
    return out


@router.post("/reels/publish")
async def reels_publish(req: ReelsPublishReq):
    """启动批量发布（后台跑，进度走 jobs）。

    autoPrepare=True 时会先自动：
        · 启动发布号浏览器（若没开）
        · 打开/整理唯一的 Meta 工作标签
        · 识别当前主页
    然后再交给 ReelsPublisher 内核发布。
    """
    from app import paths
    from app.services import automation as au

    # 只观察模式必须在这里也拦住（旧版只拦了 /publish，实际走的是这个入口）
    if au.observe_only():
        raise HTTPException(403,
            "当前是「只观察不动作」模式，发布已被拦截。"
            "去 概览 → 全自动 里关掉「只观察」，再发布。")

    info = rl.available()
    if not info.get("ok"):
        raise HTTPException(400, "ReelsPublisher 内核不可用")

    checked = _validate_materials(req)
    if checked:
        req = req.model_copy(update={"materials": checked})

    # 主页必须是当前内核真实识别的可发布主页。
    # 实机验证发现：传一个不存在的主页 ID 以前会 200 入队，
    # 直到 worker 阶段才悄悄失败；这里提前拒绝。
    if req.pages:
        known = {str(p.get("pageId")) for p in rl.plan_pages()
                 if p.get("pageId")}
        unknown = [pid for pid in req.pages if str(pid) not in known]
        if unknown:
            raise HTTPException(
                400, f"主页不在可发布清单中: {', '.join(unknown[:5])}"
                     f"（共 {len(unknown)} 个）")

    sig = _material_signature(req)
    owner_job = "job-" + uuid.uuid4().hex[:12]
    holder = _claim_signature(sig, owner_job)
    if holder:
        raise HTTPException(409,
            f"相同的发布任务仍在进行（{holder}），请等待完成或先点停止，避免重复发布")

    directory = req.directory or str(paths.output_root())
    from app.services import caption as cap
    from app.services import platform_cfg as pc

    description = req.description.strip()
    link_pool = req.linkPool.strip()

    # ---- 文案来源：random 走变体池随机，fixed 用固定模板 ----
    title_mode = (req.titleMode or "random").strip().lower()
    mode_note = ""

    if title_mode == "fixed":
        if not description:
            description = req.fixedTitle.strip() or cap.REFERENCE_TITLE
            if link_pool.split():
                pass  # 固定模式下由 worker 的 linkPool 自己轮换
        mode_note = "固定标题"
    else:
        # 多标题随机：按第一个目标主页取一条代表文案作为 worker 的模板基底，
        # 真正的逐条随机由下面的 per_page_captions 覆盖写入。
        probe_page = (req.pages or [""])[0] if req.pages else ""
        try:
            picked = cap.pick_caption(probe_page, req.referenceTitle or "")
            base_title = (picked or {}).get("title") or ""
        except Exception:
            base_title = ""
        base_title = base_title or req.referenceTitle.strip() or cap.REFERENCE_TITLE

        link = ""
        if req.useRandomLink:
            try:
                lk = cap.pick_link(probe_page)
                link = (lk or {}).get("url") or ""
            except Exception:
                link = ""
        if link:
            description = f"{base_title}\n\n{link}"
        else:
            description = base_title
        if not req.useRandomLink and link_pool:
            description = f"{base_title}\n\n{link_pool.split()[0]}"
        mode_note = "多标题随机"

    # 兜底：仍是空就退回参考标题
    if not description:
        description = cap.REFERENCE_TITLE

    job_id = owner_job
    steps = [{"name": "准备浏览器", "state": "wait", "note": ""},
             {"name": "检查浏览器", "state": "wait", "note": ""},
             {"name": "扫描素材", "state": "wait", "note": ""},
             {"name": "执行发布", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "reels", f"Reels 批量发布 · {req.clipsPerPage} 条/主页 · {mode_note}",
             "queued", 0, json.dumps(steps, ensure_ascii=False),
             json.dumps({**req.model_dump(),
                         "__signature": _material_signature(req)},
                        ensure_ascii=False), now_iso()))

    def _set_step(idx: int, state: str, note: str = "") -> None:
        """更新第 idx 步的状态（同时把之前未完成的标记 done）。"""
        cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
        try:
            arr = json.loads((cur or {}).get("steps") or "[]")
        except Exception:
            arr = list(steps)
        if not arr or idx >= len(arr):
            return
        for i in range(idx):
            if arr[i]["state"] in ("wait", "run"):
                arr[i]["state"] = "done"
        arr[idx]["state"] = state
        if note:
            arr[idx]["note"] = note[:70]
        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                (json.dumps(arr, ensure_ascii=False), job_id))

    async def _bg() -> None:
        def prog(msg: str) -> None:
            cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
            try:
                arr = json.loads((cur or {}).get("steps") or "[]")
            except Exception:
                arr = list(steps)
            if arr:
                arr[-1]["note"] = (msg or "")[:70]
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(arr, ensure_ascii=False), job_id))
        try:
            db.exec("UPDATE jobs SET status='running',started_at=? WHERE id=?",
                    (now_iso(), job_id))

            # ① 自动准备：开浏览器 + 开工作标签
            browser_ids = list(req.browserIds)
            if req.autoPrepare:
                _set_step(0, "run", "正在启动浏览器并打开工作页…")
                from app.services import prepare as pz
                pr = await pz.prepare_publish(browser_ids[0] if browser_ids else "")
                if not pr.get("ok"):
                    _set_step(0, "err", pr.get("error") or "准备失败")
                    db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? "
                            "WHERE id=?",
                            (f"[{pr.get('stage')}] {pr.get('error')}"[:400],
                             now_iso(), job_id))
                    return
                _set_step(0, "done", f"{pr.get('pageName') or '—'} @ CDP "
                                     f"{pr.get('cdpPort')}"
                                     f"{' (已启动)' if pr.get('started') else ''}")
                if not browser_ids and pr.get("code"):
                    browser_ids = [pr["code"]]
            else:
                _set_step(0, "done", "跳过自动准备")

            # ② 浏览器检查 + 发布
            # 实机验证：上一次失败会在内核留下 currentRun，导致此后所有
            # start 都被 RUN_ACTIVE 拒绝（表现为只返回 plan 快照、发不出去）。
            # 发布前先归档残留运行，把它变成历史记录，内核才能接受新任务。
            try:
                archived = await rl.archive_current_run()
                if archived:
                    _set_step(1, "run", "已归档上次未完成的运行")
            except Exception as e:
                log.warning("archive before publish failed: %s", e)

            _set_step(1, "run", "检查 Meta 工作标签…")
            r = await rl.publish(
                directory=directory,
                description=description,
                link_pool=link_pool,
                clips_per_page=req.clipsPerPage,
                concurrency=req.concurrency,
                publish_mode=req.publishMode,
                browser_ids=browser_ids,
                pages=req.pages or None,
                materials=req.materials or None,
                title_mode=title_mode,
                reference_title=req.referenceTitle,
                use_random_link=req.useRandomLink,
                fixed_title=req.fixedTitle,
                upload_stall_seconds=req.uploadStallTimeoutSeconds,
                on_progress=prog,
                job_id=job_id)
            ok = bool(r.get("ok"))
            value = r.get("result") or r
            # 实机验证：worker 的 ok=true 只代表命令跑完，不代表发出去。
            # 真正的结论在 _verdict（由 services/reels 根据 state/pages 判定）。
            verdict = r.get("_verdict") or {}
            if verdict:
                ok = bool(verdict.get("ok"))
            if ok:
                _set_step(3, "done", "发布完成")
            else:
                reason = (verdict.get("reason") or r.get("error")
                          or "发布未完成")
                _set_step(3, "err", reason[:120])
            db.exec("UPDATE jobs SET status=?,result=?,progress=100,ended_at=? WHERE id=?",
                    ("done" if ok else "failed",
                     json.dumps(value, ensure_ascii=False, default=str),
                     now_iso(), job_id))
            if ok:
                db.log_event("ok", "reels", "Reels 批量发布完成")
            else:
                db.log_event("err", "reels",
                             f"Reels 发布未完成：{(verdict.get('reason') or '')[:120]}")
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))
        finally:
            # 无论成功失败都释放幂等占位，下一次相同任务可以重新提交
            db.exec("UPDATE publish_locks SET status='done',updated_at=? "
                    "WHERE job_id=?", (now_iso(), job_id))

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id, "directory": directory,
            "clipsPerPage": req.clipsPerPage,
            "autoPrepare": req.autoPrepare,
            "note": "会自动开浏览器和页面，然后发布；素材成功后自动删除"}
