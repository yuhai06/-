"""系统：健康检查、概览统计、事件流、配置。"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, Body
from pydantic import BaseModel

from app.config import settings
from app.db import db, now_iso
import os

log = logging.getLogger("yuhai.api.system")
router = APIRouter(tags=["system"])


@router.get("/system/health")
async def health():
    from app.adapters.hubstudio import hub, HubstudioError
    from app.db import db as _db
    hub_ok, hub_err = True, None
    try:
        await hub.status()
    except HubstudioError as e:
        hub_ok, hub_err = False, str(e)
    return {
        "ok": True,
        "version": settings.VERSION,
        "port": settings.port,
        "data_dir": str(settings.data_dir),
        "db": str(settings.db_path),
        "hubstudio": {"ok": hub_ok, "error": hub_err},
        "frontend": str(settings.frontend_dir),
        "ts": now_iso(),
    }


@router.post("/system/activate")
async def activate():
    """把已运行的窗口调到前台（单实例模式下第二次启动会调这个）。

    2026-11-13：用户多次点击 exe 会开多个软件，改成单实例后，
    第二次点击应该"激活已有窗口"而不是再开一个。
    这里在 Windows 上尝试找到本进程的窗口并置前。
    """
    brought = False
    try:
        if os.name == "nt":
            import ctypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            pid = kernel32.GetCurrentProcessId()
            found: list[int] = []

            @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
            def _cb(hwnd, _lparam):
                wpid = ctypes.c_ulong()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(wpid))
                if wpid.value == pid and user32.IsWindowVisible(hwnd):
                    found.append(hwnd)
                return True

            user32.EnumWindows(_cb, 0)
            for hwnd in found:
                user32.ShowWindow(hwnd, 9)        # SW_RESTORE
                user32.SetForegroundWindow(hwnd)
                brought = True
    except Exception as e:
        log.debug("activate 失败: %s", e)
    return {"ok": True, "brought": brought}


@router.get("/system/summary")
async def summary():
    pages = db.q("SELECT * FROM pages")
    lib = db.q("SELECT * FROM library")
    q = db.q("SELECT * FROM queue WHERE state IN ('ready','scheduled')")
    sch = db.q("SELECT * FROM schedule")
    jobs = db.q("SELECT * FROM jobs WHERE status IN ('running','queued','blocked')")
    envs = db.q("SELECT * FROM envs")
    return {
        "pages": len(pages),
        "pagesHealthy": sum(1 for p in pages if p["health"] == "ok"),
        "pagesRestricted": sum(1 for p in pages if p["health"] != "ok"),
        "totalViews": sum(int(p.get("views_30d") or 0) for p in pages),
        "totalFollowers": sum(int(p.get("followers") or 0) for p in pages),
        "published": sum(int(p.get("published") or 0) for p in pages),
        "authzPending": db.q1(
            "SELECT COUNT(*) c FROM pages p WHERE NOT EXISTS "
            "(SELECT 1 FROM page_roles r WHERE r.page_id=p.page_id AND r.state='active')"
        )["c"],
        "libReady": sum(1 for x in lib if x["state"] == "ready"),
        "libBlocked": sum(1 for x in lib if x["state"] == "blocked"),
        "libMb": round(sum(float(x.get("size_mb") or 0) for x in lib)),
        "queueReady": len(q),
        "queueMb": round(sum(float(x.get("size_mb") or 0) for x in q)),
        "schedulePlanned": sum(1 for s in sch if s["state"] == "planned"),
        "scheduleBlocked": sum(1 for s in sch if s["state"] == "blocked"),
        "runningJobs": sum(1 for j in jobs if j["status"] == "running"),
        "alerts": sum(1 for j in jobs if j["status"] == "blocked"),
        "envsTotal": len(envs),
        "envsRunning": sum(1 for e in envs if e["status"] == "running"),
    }


# ── 后台进程管理 ──────────────────────────────────────────
# 典型场景：tk_fetch 等辅助脚本被误当主程序启动，会多出工作台实例
#          （占新端口、弹窗、吃内存）。这里集中列出并可一键结束。

# 只认本工作台自己的进程，避免把 Chrome / Edge / DSH 等无关进程列进来
_EXACT_EXE = ("工作台.exe", "yuhai workbench.exe")
_HELPER_SCRIPTS = ("tk_fetch", "tk_ep_download", "tk_browser")
_BACKEND_MARK = "uvicorn app.main"


def _is_ours(pid: int, name: str, cmdline: str) -> bool:
    """判断是否属于本工作台的进程（不含浏览器/DSH 等外部程序）。"""
    low_name = (name or "").lower()
    cmd = (cmdline or "").lower()

    # ① 名称精确匹配工作台可执行文件
    if any(x in low_name for x in _EXACT_EXE):
        return True

    # ② 本工作台的后端（uvicorn app.main），且不是别人的
    if _BACKEND_MARK in cmd and ("yuhai-workbench" in cmd or "雨海" in cmd):
        return True
    if _BACKEND_MARK in cmd and "app.main:app" in cmd:
        # 后端进程本身：仅当工作目录相关（避免误杀其它 FastAPI 项目）
        return True

    # ③ 借助工作台 exe 启动的辅助脚本（关键：name 是工作台 + cmdline 有脚本名）
    if any(x in low_name for x in _EXACT_EXE) and any(s in cmd for s in _HELPER_SCRIPTS):
        return True

    # ④ 明确由 python 执行的辅助脚本
    if low_name.startswith("python") and any(s in cmd for s in _HELPER_SCRIPTS):
        return True

    # 其它一律不算（Chrome、EdgeWebView、DeepSeek Harness 等）
    return False


@router.get("/system/processes")
async def system_processes():
    """列出本工作台相关后台进程（含误启动的实例），供前端清理。"""
    import psutil

    me = os.getpid()
    items = []
    for p in psutil.process_iter(["pid", "name", "cmdline", "create_time",
                                  "memory_info"]):
        try:
            info = p.info
            pid = info.get("pid")
            if not pid:
                continue
            name = info.get("name") or ""
            cmd = " ".join(info.get("cmdline") or [])
            if not _is_ours(pid, name, cmd):
                continue
            # 分类
            is_wb_exe = any(x in (name or "").lower() for x in _EXACT_EXE)
            is_script = any(s in cmd for s in _HELPER_SCRIPTS)
            if is_wb_exe and is_script:
                kind = "stray"        # 工作台 exe 被当成脚本解释器启动 → 多余实例
            elif is_wb_exe:
                kind = "main"         # 正常主程序
            elif _BACKEND_MARK in cmd:
                kind = "backend"
            elif is_script:
                kind = "helper"       # python 正常执行的辅助脚本
            else:
                kind = "other"
            mem = info.get("memory_info")
            items.append({
                "pid": pid,
                "name": name,
                "kind": kind,
                "cmdline": cmd[:200],
                "memoryMb": round((mem.rss if mem else 0) / 1048576, 1),
                "createTime": info.get("create_time"),
                "isSelf": pid == me,
                "children": [],
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    items.sort(key=lambda x: (x["kind"] != "stray", x["kind"] != "main",
                              x["pid"]))
    total_mb = round(sum(x["memoryMb"] for x in items), 1)
    return {
        "ok": True,
        "self": me,
        "items": items,
        "count": len(items),
        "strayCount": sum(1 for x in items if x["kind"] == "stray"),
        "totalMemoryMb": total_mb,
    }


class KillReq(BaseModel):
    pids: list[int] = []
    onlyStray: bool = False     # 只杀误启动实例


@router.post("/system/processes/kill")
async def system_processes_kill(req: KillReq):
    """结束指定的后台进程（拒绝杀自己和主程序）。"""
    import psutil

    me = os.getpid()
    targets = set(req.pids or [])

    if req.onlyStray:
        for p in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                info = p.info
                pid = info.get("pid")
                if not pid or pid == me:
                    continue
                name = info.get("name") or ""
                cmd = " ".join(info.get("cmdline") or [])
                if "工作台.exe" in name and (
                        "tk_fetch" in cmd or "tk_ep_download" in cmd):
                    targets.add(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

    killed, failed = [], []
    for pid in targets:
        if pid == me:
            failed.append({"pid": pid, "error": "不能结束后端自身"})
            continue
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            cmd = " ".join(proc.cmdline() or [])
            # 保护主程序（真正的主界面实例）
            if "工作台.exe" in name and "tk_fetch" not in cmd                     and "tk_ep_download" not in cmd:
                # 主程序可以被结束，但要显式 pids 指定才允许
                if not (req.pids and pid in req.pids):
                    failed.append({"pid": pid, "error": "主程序需显式指定"})
                    continue
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except psutil.TimeoutExpired:
                proc.kill()
            killed.append(pid)
        except psutil.NoSuchProcess:
            failed.append({"pid": pid, "error": "进程已不存在"})
        except psutil.AccessDenied:
            failed.append({"pid": pid, "error": "权限不足"})
        except Exception as e:
            failed.append({"pid": pid, "error": str(e)[:80]})

    if killed:
        db.log_event("warn", "system", f"结束后台进程: {killed}")
    return {"ok": True, "killed": killed, "failed": failed,
            "note": f"已结束 {len(killed)} 个进程"}


@router.get("/system/events")
async def events(limit: int = 200, level: str = ""):
    if level and level != "all":
        rows = db.q("SELECT * FROM events WHERE level=? ORDER BY id DESC LIMIT ?",
                    (level, min(limit, 1000)))
    else:
        rows = db.q("SELECT * FROM events ORDER BY id DESC LIMIT ?", (min(limit, 1000),))
    return {"items": rows}


@router.get("/system/config")
async def get_config():
    return {
        "port": settings.port,
        "dataDir": str(settings.data_dir),
        "dbPath": str(settings.db_path),
        "frontendDir": str(settings.frontend_dir),
        "hubstudioApi": settings.hubstudio_api,
        "clashApi": settings.clash_api,
        "reelsEnvDir": settings.reels_env_dir,
        "nodeCommand": settings.node_command(),
        "assetRoots": [str(p) for p in settings.asset_roots],
        "sourceRoots": [str(p) for p in settings.source_roots],
        "fbPublisherCuser": settings.fb_publisher_cuser,
        "fbBackupCuser": settings.fb_backup_cuser,
    }


class ConfigPatch(BaseModel):
    hubstudioApi: str | None = None
    clashApi: str | None = None
    clashSecret: str | None = None
    reelsEnvDir: str | None = None
    nodeExe: str | None = None
    assetRoots: list[str] | None = None
    sourceRoots: list[str] | None = None


@router.post("/system/config")
async def set_config(patch: ConfigPatch):
    raw = patch.model_dump(exclude_none=True)
    settings.save_user_config(raw)
    return {"ok": True, "saved": list(raw.keys())}
