# -*- coding: utf-8 -*-
"""主页授权（发邀请）—— 2026-11-12 实测通过的新流程。

正确流程（用户亲授，全自动跑通 4 个主页）：
  ① 必须先切换到目标主页身份（个人身份打不开授权界面！）
     成功标志：发帖框「{主页名}，分享你的新鲜事吧！」
  ② 打开 https://www.facebook.com/settings/?tab=profile_access
  ③ 若权限列表已有目标人 → 跳过（⚠ 已授权的人链接搜不到，别浪费时间）
  ④ 点「新增」→ 点「继续」（说明弹层）
  ⑤ 「按姓名或邮箱搜索」框 → insertText 填对方账号链接
  ⑥ 点搜索结果卡（对方姓名）
  ⑦ 点「授予权限」→ 密码框 Ctrl+A 清空 → insertText 输密码 → 点「确认」
  ⑧ 等「邀请将在 30 天后过期」出现 = 成功
     · 可能弹验证码 → code_getter 从 IMAP 抓
     · 可能触发"操作频繁"（灰色确认+无输入框）→ 10 小时冷却，标记 pending

旧流程（business.facebook.com/latest/settings/page_roles?asset_id=）已废弃：
那个说明弹层的「添加」永远禁用，链接搜索框是 _58al 影子输入框进不去字。
整套 CONFIRM_ROLE_DIALOG_JS / PRESS_ADD_IN_DIALOG_JS / FIND_ADD_BTN_JS 等已删。
"""
import asyncio
import json
import logging

log = logging.getLogger("yuhai.fb.invite")


class InviteError(RuntimeError):
    pass


# ---------- 通用 JS 片段 ----------

def _js_click(names: list[str], scope_dialog: bool = False) -> str:
    """点指定文案的按钮（精确/前缀匹配），JSON 安全内嵌。"""
    arr = json.dumps([str(n).lower() for n in names], ensure_ascii=False)
    sd = "true" if scope_dialog else "false"
    return f"""(() => {{
      const want = {arr};
      const boxes = ({sd})
        ? Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]'))
        : [document];
      for (const box of boxes) {{
        for (const el of box.querySelectorAll('[role="button"], button, a, [role="link"]')) {{
          const t = (el.innerText || el.getAttribute('aria-label') || '').trim().toLowerCase();
          if (!t) continue;
          if (!want.some(w => t === w || t.startsWith(w))) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 15 || r.height < 8) continue;
          const cs = getComputedStyle(el);
          if (cs.visibility === 'hidden' || cs.display === 'none') continue;
          if (el.getAttribute('aria-disabled') === 'true') continue;
          el.click();
          return {{ ok: true, text: t.slice(0, 24) }};
        }}
      }}
      return {{ ok: false }};
    }})()"""


async def _click_btn(page, names, scope_dialog=False, retries=1):
    for i in range(retries + 1):
        try:
            r = await page.eval(_js_click(names, scope_dialog)) or {}
        except Exception as e:
            r = {"ok": False, "reason": str(e)[:60]}
        if r.get("ok"):
            return r
        if i < retries:
            await asyncio.sleep(2)
    return r


async def _real_click(page, x, y):
    await page.send("Input.dispatchMouseEvent",
                    {"type": "mouseMoved", "x": x, "y": y})
    await page.send("Input.dispatchMouseEvent",
                    {"type": "mousePressed", "x": x, "y": y, "button": "left",
                     "buttons": 1, "clickCount": 1})
    await page.send("Input.dispatchMouseEvent",
                    {"type": "mouseReleased", "x": x, "y": y, "button": "left",
                     "buttons": 0, "clickCount": 1})


async def _type_real(page, text):
    for ch in text:
        await page.send("Input.dispatchKeyEvent",
                        {"type": "keyDown", "key": ch, "text": ch})
        await page.send("Input.dispatchKeyEvent",
                        {"type": "char", "key": ch, "text": ch})
        await page.send("Input.dispatchKeyEvent",
                        {"type": "keyUp", "key": ch})
        await asyncio.sleep(0.05)


async def _shot(page, path):
    try:
        res = await page.send("Page.captureScreenshot", {"format": "png"})
        open(path, "wb").write(base64.b64decode(res["data"]))
    except Exception:
        pass


import base64  # noqa: E402


# ---------- 主流程 ----------

async def switch_identity(page, name: str) -> bool:
    """切换到主页身份。成功标志 = 发帖框「{name}，分享你的新鲜事吧！」"""
    # 已在目标身份？
    try:
        await page.goto("https://www.facebook.com/", wait_until_loaded=15.0)
        await asyncio.sleep(3)
        if await page.eval(f"() => (document.body.innerText||'').includes('{name}，分享')"):
            return True
    except Exception:
        pass

    for _attempt in range(2):
        await page.eval(r"""(() => {
          for (const el of document.querySelectorAll('[role="button"], button, a')) {
            const t = (el.innerText || el.getAttribute('aria-label') || '').trim();
            if (/账户|Account/.test(t) && t.length < 25) {
              const rc = el.getBoundingClientRect();
              if (rc.width < 5 || rc.width > 90) continue;
              el.click(); return;
            }
          }
        })()""")
        await asyncio.sleep(3)
        await page.eval(f"""(() => {{
          for (const el of document.querySelectorAll('[role="button"], [role="menuitem"]')) {{
            const t = (el.innerText || '').trim();
            if (t === '{name}') {{
              const rc = el.getBoundingClientRect();
              if (rc.width < 10) continue;
              el.click(); return;
            }}
          }}
        }})()""")
        # 轮询发帖框（最多 12 秒）
        for _ in range(12):
            await asyncio.sleep(1)
            try:
                if await page.eval(f"() => (document.body.innerText||'').includes('{name}，分享')"):
                    return True
            except Exception:
                pass
        # 兜底：点「查看所有主页」再试
        await page.eval(r"""(() => {
          for (const el of document.querySelectorAll('[role="button"], [role="menuitem"]')) {
            if ((el.innerText || '').trim() === '查看所有主页') { el.click(); return; }
          }
        })()""")
        await asyncio.sleep(3)
    return False


async def invite_member(page, page_name: str, target_link: str,
                        target_name: str = "",
                        password: str = "",
                        code_getter=None) -> dict:
    """给一个主页发管理员邀请（新流程）。

    page        已连 CDP 的标签页
    page_name   主页名（用于切换身份）
    target_link 对方的账号链接（profile.php?id=xxx）
    target_name 对方显示名（如 "Yu Hai"），用于点结果卡
    password    发起方（主页所属号）的登录密码
    code_getter async () -> str 验证码抓取
    返回 {ok, reason?, rateLimited?, steps[]}
    """
    out: dict = {"ok": False, "steps": []}

    def step(name, ok, **kw):
        out["steps"].append({"step": name, "ok": ok, **kw})

    # ① 切身份
    ok = await switch_identity(page, page_name)
    step("切换主页身份", ok)
    if not ok:
        out["reason"] = f"切换到 {page_name} 身份失败"
        return out

    # ② 权限页
    await page.goto("https://www.facebook.com/settings/?tab=profile_access",
                    wait_until_loaded=18.0)
    await asyncio.sleep(6)
    body = await page.inner_text() or ""

    # ③ 已授权 → 跳过（链接搜不到已授权的人）
    if target_name and target_name in body:
        step("检查权限列表", True, skipped=True)
        out["ok"] = True
        out["skipped"] = True
        out["reason"] = "已在权限列表中，跳过"
        return out

    # ④ 新增 → 继续
    r = await _click_btn(page, ["新增", "添加", "Add"], retries=2)
    step("点「新增」", r.get("ok", False))
    if not r.get("ok"):
        out["reason"] = "找不到「新增」按钮"
        return out
    await asyncio.sleep(4)
    r = await _click_btn(page, ["继续", "下一步", "Continue"], retries=3)
    step("点「继续」", r.get("ok", False), note="有的账号没说明层，点不到也继续")
    await asyncio.sleep(6)

    # ⑤ 搜索框
    pos = None
    for _ in range(25):
        pos = await page.eval(r"""(() => {
          for (const el of document.querySelectorAll('input')) {
            if (/按姓名或邮箱/.test(el.placeholder || '')) {
              const r = el.getBoundingClientRect();
              if (r.width < 100) continue;
              return { x: Math.round(r.x + r.width/2),
                       y: Math.round(r.y + r.height/2) };
            }
          }
          return null;
        })()""") or {}
        if pos:
            break
        await asyncio.sleep(0.8)
    step("找搜索框", bool(pos))
    if not pos:
        out["reason"] = "搜索框 20 秒没出现（可能弹层没走完）"
        return out

    await _real_click(page, pos["x"], pos["y"])
    await asyncio.sleep(0.8)
    try:
        await page.send("Input.insertText", {"text": target_link})
        step("填链接", True, mode="insertText")
    except Exception:
        await _type_real(page, target_link)
        step("填链接", True, mode="keydown")
    await asyncio.sleep(5)

    # ⑥ 结果卡
    if not target_name:
        out["reason"] = "缺少 target_name，无法点结果卡"
        return out
    card = await page.eval(f"""(() => {{
      const cands = document.querySelectorAll(
        '[role="button"], [role="option"], [role="listitem"], li, div[tabindex]');
      for (const el of cands) {{
        const t = (el.innerText || '').trim();
        if (t !== '{target_name}' && !t.startsWith('{target_name}')) continue;
        const rc = el.getBoundingClientRect();
        if (rc.width < 40 || rc.height < 20) continue;
        return {{ x: Math.round(rc.x + rc.width/2),
                  y: Math.round(rc.y + rc.height/2) }};
      }}
      return null;
    }})()""") or {}
    step("找结果卡", bool(card))
    if not card:
        out["reason"] = "搜索结果里没有目标人（可能已授权，或链接不对）"
        return out
    await _real_click(page, card["x"], card["y"])
    await asyncio.sleep(5)

    # ⑦ 授予权限 → 密码
    grant_btn = await page.eval(r"""(() => {
      for (const el of document.querySelectorAll('[role="button"], button')) {
        const t = (el.innerText || '').trim();
        if (t.startsWith('授予权限') || t.startsWith('授权')) {
          const r = el.getBoundingClientRect();
          if (r.width < 20) continue;
          if (el.getAttribute('aria-disabled') === 'true')
            return { disabled: true };
          return { x: Math.round(r.x + r.width/2),
                   y: Math.round(r.y + r.height/2) };
        }
      }
      return null;
    })()""") or {}
    if grant_btn and grant_btn.get("x"):
        await _real_click(page, grant_btn["x"], grant_btn["y"])
        step("点「授予权限」", True)
        await asyncio.sleep(6)

    # 密码（可能被记住不用输）
    pwd = await page.eval(r"""(() => {
      for (const el of document.querySelectorAll('input[type="password"]')) {
        const r = el.getBoundingClientRect();
        if (r.width < 50) continue;
        return { x: Math.round(r.x + r.width/2),
                 y: Math.round(r.y + r.height/2) };
      }
      return null;
    })()""") or {}
    if pwd:
        if not password:
            out["reason"] = "需要密码但未提供"
            return out
        await _real_click(page, pwd["x"], pwd["y"])
        await asyncio.sleep(0.5)
        # Ctrl+A 清空 → insertText
        for ev in ({"type": "keyDown", "key": "a", "code": "KeyA",
                    "windowsVirtualKeyCode": 65, "modifiers": 2},
                   {"type": "keyUp", "key": "a", "code": "KeyA",
                    "windowsVirtualKeyCode": 65, "modifiers": 2}):
            await page.send("Input.dispatchKeyEvent", ev)
        await asyncio.sleep(0.15)
        for ev in ({"type": "keyDown", "key": "Delete", "code": "Delete",
                    "windowsVirtualKeyCode": 46},
                   {"type": "keyUp", "key": "Delete", "code": "Delete",
                    "windowsVirtualKeyCode": 46}):
            await page.send("Input.dispatchKeyEvent", ev)
        await asyncio.sleep(0.3)
        try:
            await page.send("Input.insertText", {"text": password})
            step("填密码", True, mode="insertText")
        except Exception:
            await _type_real(page, password)
            step("填密码", True, mode="keydown")
        await asyncio.sleep(0.8)

        # 密码长度校验
        chk = await page.eval(r"""(() => {
          for (const el of document.querySelectorAll('input[type="password"]')) {
            const r = el.getBoundingClientRect();
            if (r.width < 20) continue;
            return (el.value || '').length;
          }
          return 0;
        })()""") or 0
        if chk != len(password):
            out["reason"] = f"密码输入异常（长度 {chk}≠{len(password)}）"
            return out

        r = await _click_btn(page, ["确认", "Confirm"], scope_dialog=True)
        step("点「确认」", r.get("ok", False))
        if not r.get("ok"):
            out["reason"] = "找不到「确认」按钮"
            return out

    # ⑧ 等结果（成功 / 验证码 / 频繁 / 密码错）
    P_note = ""
    for i in range(25):
        await asyncio.sleep(3)
        st = await page.eval(r"""(() => {
          const body = document.body.innerText || '';
          let needCode = false, codeBox = null;
          for (const el of document.querySelectorAll('input')) {
            const p = (el.placeholder || el.getAttribute('aria-label') || '');
            if (/验证码|代码|code/i.test(p) || el.inputMode === 'numeric'
                || el.autocomplete === 'one-time-code') {
              const r = el.getBoundingClientRect();
              if (r.width > 30 && r.height > 8) {
                needCode = true;
                codeBox = { x: Math.round(r.x + r.width/2),
                            y: Math.round(r.y + r.height/2) };
              }
            }
          }
          const success = /30 天内|30天内|邀请已发送|已被邀请/.test(body);
          const err = /密码不正确|密码错误|incorrect|请重试/i.test(body);
          // 授权频繁：确认按钮变灰 + 弹窗无输入框 + 无成功/报错文案
          let rateLimited = false;
          const freqText = /操作频繁|过于频繁|稍后再试|请稍后|try again later|rate.?limit/i.test(body);
          const dlg = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]'))
            .filter(b => b.getBoundingClientRect().width > 80)[0];
          if (freqText) rateLimited = true;
          if (dlg && !success && !err) {
            let confirmDisabled = false;
            for (const el of dlg.querySelectorAll('[role="button"], button')) {
              const t = (el.innerText || '').trim();
              if (/确认|继续|添加|邀请|confirm/i.test(t)
                  && el.getAttribute('aria-disabled') === 'true') {
                confirmDisabled = true;
                break;
              }
            }
            if (confirmDisabled && !dlg.querySelector('input')) rateLimited = true;
          }
          return { needCode, codeBox, success, err, rateLimited,
                   snippet: body.replace(/\n+/g, ' | ').slice(0, 200) };
        })()""") or {}
        P_note = f"[{(i+1)*3}s] ok={st.get('success')} err={st.get('err')} code={st.get('needCode')} rate={st.get('rateLimited')}"
        log.info("invite wait %s", P_note)

        if st.get("success"):
            step("等结果", True, note="邀请已发出（30 天内有效）")
            out["ok"] = True
            return out

        if st.get("rateLimited"):
            step("等结果", False, note="授权频繁（约 10 小时恢复）")
            out["reason"] = "授权频繁，稍后重试"
            out["rateLimited"] = True
            return out

        if st.get("err"):
            step("等结果", False, note="密码不正确")
            out["reason"] = "密码不正确"
            return out

        if st.get("needCode") and code_getter:
            code = await code_getter()
            if code and st.get("codeBox"):
                cb = st["codeBox"]
                await _real_click(page, cb["x"], cb["y"])
                await asyncio.sleep(0.5)
                await _type_real(page, code)
                await _click_btn(page, ["确认", "提交", "继续"], scope_dialog=True)
                step("填验证码", True, code=code)
                continue
            if not code:
                out["reason"] = "验证码没收到"
                return out

    out["reason"] = "75 秒没等到明确结果"
    return out
