"""修复真实权限读取：从 SSR 预取的 page_roles.edges 中提取成员。

实机验证（2026-11-12）确认：
  · 权限页 https://business.facebook.com/latest/settings/page_roles?asset_id=X
  · 成员数据在 <script type="application/json"> 的 Relay 预取里，
    路径为 data.page.page_roles.edges[].node.user.id
  · 旧解析器只在 DOM 里找 div[role=row] / profile.php 链接，
    实测两者都不存在 → 永远返回 0 条，把真实有权限的人判成「未授权」
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any

from app.adapters.cdp import CDPError

log = logging.getLogger("yuhai.fb.roles")

# DOM 兜底：老版页面或结构变化时仍尝试从行文本 + 链接取
ROLES_JS = r"""
(() => {
  const out = [];
  const seen = new Set();
  const push = (name, uid, level) => {
    const key = uid || name;
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push({ name: (name||'').trim().slice(0,60), c_user: uid||null, level: level||null });
  };

  const rows = Array.from(document.querySelectorAll('div[role="row"], div[role="listitem"], li'));
  for (const row of rows) {
    const t = (row.innerText || '');
    if (!t || t.length > 400) continue;
    if (!/自定义|完全控制|部分控制|管理员|编辑/.test(t)) continue;
    const lines = t.split('\n').map(s=>s.trim()).filter(Boolean);
    const name = lines[0] || '';
    if (!name || name.length > 40) continue;
    const level = /完全控制/.test(t) ? 'full' : /部分控制/.test(t) ? 'partial' : 'custom';
    let uid = null;
    const a = row.querySelector('a[href*="profile.php?id="]');
    if (a) {
      const m = (a.getAttribute('href')||'').match(/profile\.php\?id=(\d{8,})/);
      if (m) uid = m[1];
    }
    push(name, uid, level);
  }

  const html = document.documentElement.innerHTML;
  const re = /\{"[^{}]{0,80}?"(?:name|display_name)":"([^"]{1,60})"[^{}]{0,300}?"id":"(\d{8,})"/g;
  let m;
  while ((m = re.exec(html))) push(m[1], m[2], null);

  return out;
})()
"""

# 主路径：从 Relay 预取的 page_roles.edges 里提取
SSR_ROLES_JS = r"""
(() => {
  const out = [];
  const seen = new Set();

  const push = (name, uid, roleValue, pending) => {
    const key = uid || name;
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push({
      name: (name || '').trim().slice(0, 60),
      c_user: uid || null,
      role_value: (roleValue === undefined ? null : roleValue),
      is_pending: !!pending,
      level: (roleValue === 7 ? 'full' : 'custom'),
    });
  };

  const walk = (node, depth) => {
    if (!node || depth > 12 || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const x of node) walk(x, depth + 1); return; }

    // 命中：page_roles.edges[]
    if (Array.isArray(node.edges)) {
      for (const e of node.edges) {
        const n = e && e.node;
        if (n && n.user && n.user.id) {
          push(n.user.name || '', String(n.user.id), n.role_value, n.is_pending);
        }
      }
    }
    // 直接命中 node.user
    if (node.user && node.user.id && (node.role_value !== undefined || node.__typename)) {
      push(node.user.name || '', String(node.user.id), node.role_value, node.is_pending);
    }
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (v && typeof v === 'object') walk(v, depth + 1);
    }
  };

  const scripts = Array.from(document.querySelectorAll('script[type="application/json"]'));
  const joined = scripts.map(s => s.textContent || '').join('\n');

  // ① 优先整体 JSON.parse（page_roles 可能跨多行，按行切会漏成员）
  for (const s of scripts) {
    const raw = s.textContent || '';
    if (!raw || raw.indexOf('page_roles') === -1) continue;
    try {
      walk(JSON.parse(raw), 0);
    } catch (e) {
      // 单个 script 里可能拼了多段 JSON：按 "}{" 边界粗切再试
      const parts = raw.split(/\}\s*\{/);
      for (let i = 0; i < parts.length; i++) {
        let p = parts[i];
        if (i > 0) p = '{' + p;
        if (i < parts.length - 1) p = p + '}';
        if (p.indexOf('page_roles') === -1) continue;
        try { walk(JSON.parse(p), 0); } catch (e2) { /* 跳过 */ }
      }
    }
  }

  // ② 仍为空时，用正则在原始文本里兜底匹配 user 结构
  if (!out.length) {
    const re = /"user":\{"id":"(\d{8,20})"(?:,"name":"([^"]{1,60})")?/g;
    let m;
    while ((m = re.exec(joined))) push(m[2] || '', m[1], null, false);
  }

  return out;
})()
"""


def _to_public(items: list[dict]) -> list[dict]:
    """统一成 {name, c_user, level}，过滤明显不是人的 ID。"""
    out = []
    for it in items or []:
        uid = str(it.get("c_user") or "").strip()
        name = str(it.get("name") or "").strip()
        if not uid:
            continue
        out.append({"name": name, "c_user": uid,
                    "level": it.get("level") or None,
                    "is_pending": bool(it.get("is_pending"))})
    return out


async def list_roles_with_ids(page, asset_id: str) -> list[dict]:
    """读取主页权限列表，返回 [{name, c_user, level}]。"""
    await page.goto(
        f"https://business.facebook.com/latest/settings/page_roles?asset_id={asset_id}",
        wait_until_loaded=12.0)

    # 预取数据是异步水合的：固定 sleep 容易只读到一部分成员。
    # 这里轮询到成员数连续多轮不变为止（最多 ~18 秒）。
    # 实测第一轮常常只水合出 1 个成员，随即增长到 2 个，所以不能用
    # “两轮相同即稳定”，要连 3 轮且提前多等一会儿。
    best: list[dict] = []
    stable = 0
    for i in range(18):
        await asyncio.sleep(1.0)
        if i in (2, 5, 8):
            try:
                await page.eval("window.scrollBy(0, window.innerHeight)")
            except CDPError:
                pass
        try:
            data = await page.eval(SSR_ROLES_JS) or []
        except CDPError as e:
            log.debug("SSR roles extract failed: %s", e)
            continue
        hits = _to_public(data)
        if len(hits) > len(best):
            best = hits
            stable = 0
            continue
        if best and len(hits) == len(best):
            stable += 1
            if stable >= 3:
                break
    if best:
        log.info("page_roles: %d members (asset=%s)", len(best), asset_id)
        return best

    # 兜底：DOM 解析
    try:
        data = await page.eval(ROLES_JS) or []
        hits = _to_public(data)
        if hits:
            log.info("page_roles via DOM fallback: %d members (asset=%s)",
                     len(hits), asset_id)
            return hits
    except CDPError as e:
        log.debug("DOM roles extract failed: %s", e)

    try:
        body = await page.inner_text()
        if "公共主页人员身份" not in (body or ""):
            log.warning("page_roles page not loaded properly (asset=%s)", asset_id)
    except Exception:
        pass
    return []
