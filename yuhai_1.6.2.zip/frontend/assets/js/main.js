/* 入口：路由、侧边栏、命令面板 */
import { hydrateIcons, icon } from './icons.js?v=202611120850';
import { $, $$, toast, closeAllModals } from './ui.js?v=202611120850';
import { store, paintGuardBadge } from './store.js?v=202611120850';

import * as dashboard from './pages/dashboard.js?v=202611120850';
import * as agent from './pages/agent.js?v=202611120850';
import * as pages from './pages/pages.js?v=202611120850';
import * as authz from './pages/authz.js?v=202611120850';
import * as analytics from './pages/analytics.js?v=202611120850';
import * as guard from './pages/guard.js?v=202611120850';
import * as comments from './pages/comments.js?v=202611120850';
import * as video from './pages/video.js?v=202611120850';
import * as dl from './pages/dl.js?v=202611120850';
import * as slice from './pages/slice.js?v=202611120850';
import * as publish from './pages/publish.js?v=202611120850';
import * as schedule from './pages/schedule.js?v=202611120850';
import * as library from './pages/library.js?v=202611120850';
import * as mail from './pages/mail.js?v=202611120850';
import * as integrations from './pages/integrations.js?v=202611120850';
import * as mcp from './pages/mcp.js?v=202611120850';
import * as envs from './pages/envs.js?v=202611120850';
import * as logs from './pages/logs.js?v=202611120850';
import * as settings from './pages/settings.js?v=202611120850';

const ROUTES = {
  agent: { mod: agent, title: '雨海 Agent' },
  dashboard: { mod: dashboard, title: '工作台概览' },
  envs: { mod: envs, title: '指纹浏览器' },
  authz: { mod: authz, title: '授权管理' },
  analytics: { mod: analytics, title: '视频数据' },
  guard: { mod: guard, title: '风控中心' },
  dl: { mod: dl, title: '短剧下载' },
  slice: { mod: slice, title: '短剧切片' },
  video: { mod: video, title: '视频制作' },
  comments: { mod: comments, title: '评论区维护' },
  publish: { mod: publish, title: '发布中心' },
  schedule: { mod: schedule, title: '排期与素材队列' },
  library: { mod: library, title: '素材库' },
  mail: { mod: mail, title: '邮箱与验证码' },
  integrations: { mod: integrations, title: '第三方对接' },
  mcp: { mod: mcp, title: 'MCP 接入' },
  logs: { mod: logs, title: '运行日志' },
  settings: { mod: settings, title: '设置' },
};

function currentRoute() {
  const h = location.hash.replace(/^#\/?/, '') || 'agent';
  return ROUTES[h] ? h : 'agent';
}

function navigate(name) {
  if (location.hash === `#/${name}`) renderRoute();
  else location.hash = `#/${name}`;
}

function renderRoute() {
  const name = currentRoute();
  const r = ROUTES[name];
  closeAllModals();
  $$('#nav .nav-item').forEach((el) => el.classList.toggle('active', el.dataset.route === name));
  $('#crumb-cur').textContent = r.title;
  document.title = `${r.title} · 雨海工作台`;
  const view = $('#view');
  view.scrollTop = 0;
  view.innerHTML = '';
  r.mod.render(view);
  hydrateIcons(view);
  syncBadges();
}

function syncBadges() {
  const s = store.loaded ? store.summary : {};
  const setB = (id, v, kind) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = v;
    el.style.display = '';
    el.className = 'nav-badge' + (kind ? ' ' + kind : '');
  };
  setB('nav-badge-pages', s.pages ?? store.pages.length);
  setB('nav-badge-library', s.libReady ?? 0, (s.libReady ? 'ok' : ''));
  setB('nav-badge-envs', s.envsRunning ?? 0, (s.envsRunning ? 'ok' : ''));
  setB('nav-badge-authz', s.authzPending ?? 0, (s.authzPending ? 'warn' : 'ok'));
  setB('nav-badge-publish', s.published ?? 0);
  setB('nav-badge-schedule', s.queueReady ?? 0, (s.queueReady ? 'ok' : ''));
  setB('nav-badge-mail', store.mails.filter((m) => m.code).length, 'ok');

  const gb = document.getElementById('nav-badge-guard');
  if (gb) {
    const n = (store.guard && store.guard.count) || 0;
    gb.style.display = n ? '' : 'none';
    gb.textContent = n;
  }

  const ct = document.getElementById('chip-tasks');
  if (ct) ct.innerHTML = `队列 <b>${(s.runningJobs ?? 0)}</b>`;
  const ca = document.getElementById('chip-alerts');
  if (ca) {
    ca.innerHTML = `告警 <b>${s.alerts ?? 0}</b>`;
    ca.className = 'chip' + ((s.alerts || 0) ? ' alarm' : '');
  }
  paintGuardBadge();
}

/* ---------- 启动时拉真实数据 ---------- */
async function boot() {
  try {
    await store.loadCore();
    await store.loadMail({ limit: 30 });
  } catch (e) {
    console.warn('boot load failed', e.message);
    toast('后端未连接', '请确认后端服务在 127.0.0.1:8710 运行', 'err', 6000);
  }
  syncBadges();
  // 风控轮询（30s）
  setInterval(async () => {
    try {
      const before = store.guard.count || 0;
      await store.loadGuard();
      if ((store.guard.count || 0) > before) {
        const v = store.guard.latest || {};
        if (v.tripped) raiseGuardFront(v);
      }
      syncBadges();
    } catch (e) { /* ignore */ }
  }, 30000);
}

function raiseGuardFront(v) {
  import('./store.js').then((m) => m.raiseGuard(v)).catch(() => {});
}

/* ---------- 侧边栏 ---------- */
$$('#nav .nav-item').forEach((el) => {
  el.addEventListener('click', () => navigate(el.dataset.route));
});

/* ---------- 顶栏 ---------- */
$('#btn-refresh').addEventListener('click', () => {
  renderRoute();
  toast('已刷新', '数据重新渲染', 'ok', 1600);
});
$('#btn-quick').addEventListener('click', () => openCmdk());

/* ---------- 时钟 ---------- */
function tickClock() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const el = document.getElementById('chip-clock');
  if (el) el.textContent = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
setInterval(tickClock, 1000);
tickClock();

/* ---------- 环境探针（前端阶段为静态） ---------- */
function paintEnv() {
  const set = (id, cls, txt) => {
    const d = document.getElementById(id);
    if (d) d.className = 'dot ' + cls;
    const b = document.getElementById('env-' + id.replace('dot-', ''));
    if (b && txt != null) b.textContent = txt;
  };
  set('dot-hub', 'ok', '在线');
  set('dot-proxy', 'warn', 'DE · 13.141');
  set('dot-resident', 'warn', '机房 IP');
}
paintEnv();

/* ---------- 命令面板 ---------- */
const CMDS = [
  ...[...Object.entries(ROUTES)].map(([k, v]) => ({ label: `跳转：${v.title}`, run: () => navigate(k), key: k })),
  { label: '操作：全量同步', run: () => toast('同步中', '三路并行', 'info') },
  { label: '操作：新建主页', run: () => navigate('pages') },
  { label: '操作：按 PID 提取主页', run: () => navigate('envs') },
  { label: '操作：启动发布号环境', run: () => toast('启动指令已发送', '网易01 / 1887976888', 'ok') },
  { label: '操作：发起授权', run: () => navigate('authz') },
  { label: '操作：立即发布', run: () => navigate('publish') },
  { label: '操作：处理新剧', run: () => navigate('library') },
  { label: '操作：查看处理管线', run: () => navigate('library') },
  { label: '操作：模型与技能适配', run: () => navigate('library') },
  { label: '操作：添加素材到队列', run: () => navigate('schedule') },
  { label: '操作：自动排期', run: () => navigate('schedule') },
  { label: '操作：拉取验证码', run: () => navigate('mail') },
  { label: '操作：查看日志', run: () => navigate('logs') },
  { label: '风格：切换浅色/夜间', run: () => document.getElementById('btn-theme')?.click() },
];

let cmdkOn = false;
let cmdSel = 0;

function openCmdk() {
  const box = document.getElementById('cmdk');
  box.hidden = false;
  cmdkOn = true;
  cmdSel = 0;
  const inp = document.getElementById('cmdk-input');
  inp.value = '';
  paintCmdk('');
  setTimeout(() => inp.focus(), 20);
}
function closeCmdk() {
  document.getElementById('cmdk').hidden = true;
  cmdkOn = false;
}
function paintCmdk(q) {
  const list = CMDS.filter((c) => !q || c.label.toLowerCase().includes(q.toLowerCase()));
  const el = document.getElementById('cmdk-list');
  if (!list.length) {
    el.innerHTML = `<div class="cmdk-empty">没有匹配项</div>`;
    return;
  }
  el.innerHTML = list.map((c, i) => `
    <div class="cmdk-item ${i === cmdSel ? 'on' : ''}" data-i="${i}" data-cmd="${escAttr(c.label)}">
      <span>${c.label}</span>
      <span class="k">${c.key || '↵'}</span>
    </div>`).join('');
  // 用 data 属性 + 闭包下标绑定，避免 HTML 注入与选择器转义问题
  el.querySelectorAll('[data-i]').forEach((it) => {
    it.onclick = () => { list[+it.dataset.i].run(); closeCmdk(); };
  });
  el._list = list;
}

function escAttr(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    cmdkOn ? closeCmdk() : openCmdk();
    return;
  }
  if (!cmdkOn) return;
  const inp = document.getElementById('cmdk-input');
  const el = document.getElementById('cmdk-list');
  const list = el._list || [];
  if (e.key === 'Escape') return closeCmdk();
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    cmdSel = Math.min(cmdSel + 1, Math.max(0, list.length - 1));
    paintCmdk(inp.value);
  }
  if (e.key === 'ArrowUp') {
    e.preventDefault();
    cmdSel = Math.max(cmdSel - 1, 0);
    paintCmdk(inp.value);
  }
  if (e.key === 'Enter') {
    e.preventDefault();
    const c = list[cmdSel];
    if (c) { c.run(); closeCmdk(); }
  }
});

$('#cmdk-input')?.addEventListener('input', (e) => {
  cmdSel = 0;
  paintCmdk(e.target.value);
});
$('#cmdk')?.addEventListener('click', (e) => {
  if (e.target.id === 'cmdk') closeCmdk();
});

/* ---------- 主题切换（B 浅色为默认，深色保留为夜间模式） ---------- */
const THEME_KEY = 'yuhai.theme';
const THEMES = [
  { id: 'light', label: '浅色', icon: 'sun' },
  { id: 'dark', label: '夜间', icon: 'moon' },
];

function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  const def = THEMES.find((x) => x.id === t) || THEMES[0];
  const lbl = document.getElementById('theme-label');
  const ico = document.querySelector('#btn-theme [data-icon]');
  if (lbl) lbl.textContent = def.label;
  if (ico) {
    ico.dataset.icon = def.icon;
    ico.innerHTML = icon(def.icon, 13);
  }
  const meta = document.querySelector('meta[name="color-scheme"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? 'dark' : 'light');
  try { localStorage.setItem(THEME_KEY, t); } catch (e) { /* file:// */ }
}

function initTheme() {
  let t = 'light';
  try { t = localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { /* ignore */ }
  if (!THEMES.some((x) => x.id === t)) t = 'light';
  applyTheme(t);
}

document.getElementById('btn-theme')?.addEventListener('click', () => {
  const cur = document.documentElement.dataset.theme || 'light';
  const i = THEMES.findIndex((x) => x.id === cur);
  const next = THEMES[(i + 1) % THEMES.length];
  applyTheme(next.id);
  // 图表颜色在渲染时确定，切主题后需要重绘当前页
  if (typeof renderRoute === 'function') renderRoute();
  toast(next.id === 'dark' ? '夜间模式' : '浅色模式', 'Ctrl+J 切换', 'info', 1500);
});

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
    e.preventDefault();
    document.getElementById('btn-theme')?.click();
  }
});

/* ---------- 启动 ---------- */
initTheme();
window.addEventListener('hashchange', renderRoute);
hydrateIcons(document);
renderRoute();
boot();

/* 预热：把图标塞进静态顶栏按钮 */
$$('.btn [data-icon], .nav-ico[data-icon], .ev [data-icon]').forEach((el) => {
  if (!el.innerHTML.trim()) el.innerHTML = icon(el.dataset.icon, 14);
});




