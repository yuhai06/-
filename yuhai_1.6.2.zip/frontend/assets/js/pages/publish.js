/* ============================================================
   发布中心 · 重写版
   —— 内部数据直连：素材从 library/queue 读、主页从 pages 读、
      标题从 title_pool 读、链接从 promo_links 读
   —— 单一真值源：所有状态在 state 里，渲染全从它派生
   —— 进度用 SSE，不用 setInterval 轮询
   —— 发送前必有预览：能看到每个主页将要发什么文案
   ============================================================ */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import { $, $$, toast, modal, emptyState, pageHead } from '../ui.js';
// 复用「主页与授权」页的主页详情弹窗，保证两处完全一致
import * as authzPage from './authz.js';

/* ─────────────────────────────────────────────────────────────
   状态：唯一真值源
   ───────────────────────────────────────────────────────────── */
const state = {
  // 数据
  sources: null,
  pages: [],          // [{pageId, pageName, selectable, health, assetId, envCode, published}]
  environments: [],   // [{envCode, envName, role, status, running, pageTotal, pageSelectable}]
  dramas: [],         // [{drama, n}]
  links: [],
  titles: { total: 0, global: 0 },

  // 用户选择
  pageIds: [],        // 显式数组（空 = 未选，不是"全部"）
  pageFilter: '',
  expandedEnvs: {},   // { envCode: true } 哪个环境展开了
  materialSource: 'library',   // library | queue
  sourcePicked: false,         // 首次是否已自动选过更充足的那个来源
  picked: {},         // { drama: 条数 }  空 = 自动均分
  clipsPerPage: 1,
  captionStyle: 'simple',
  allocMode: 'merge',
  fixedTitle: '',
  fixedLink: '',
  referenceTitle: '',
  concurrency: 1,
  uploadStallSeconds: 180,
  spacingMinutes: 30,          // 同一主页内多条视频的排期间隔（分钟）
  scheduleMode: 'even',        // even=等距 | custom=逐条自定义
  scheduleOffsets: [],         // custom 模式下逐条相对基线的分钟数
  regenTitles: false,          // 点「重新生成标题」时置 true

  // 预览与执行
  preview: null,      // {items:[], pageCount, itemCount, ...}
  previewErr: '',
  previewLoading: false,
  previewPage: 0,     // 当前预览第几个主页
  previewItem: 0,     // 当前预览该主页第几条
  order: null,        // 订单详情
  orderId: '',
  running: false,
  history: [],
};

let es = null;          // EventSource
let previewTimer = null;
let rootEl = null;

// 调试用：把 state 暴露到 window，方便排查"改了参数没生效"
try { window.__pubState = state; } catch { /* ignore */ }

/* ─────────────────────────────────────────────────────────────
   入口
   ───────────────────────────────────────────────────────────── */
export function render(root) {
  rootEl = root;
  root.innerHTML = `
    ${pageHead({
      title: '发布中心',
      desc: '素材、主页、标题、链接全部来自工作台内部数据，不再手动选文件。',
      actions: [
        `<button class="btn sm ghost" data-act="refresh">
           <span data-icon="refresh"></span>刷新</button>`,
      ],
    })}
    <div id="pub-root">
      <div class="card"><div class="card-body">
        <div class="pub-empty">${icon('hourglass', 26)}读取内部数据…</div>
      </div></div>
    </div>`;
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => loadAll(true)));
  loadAll(false);
}

async function loadAll(manual = false) {
  const box = $('#pub-root');
  if (manual && box) {
    box.innerHTML = `<div class="card"><div class="card-body">
      <div class="pub-empty">${icon('hourglass', 26)}刷新中…</div></div></div>`;
  }
  try {
    const [src, orders] = await Promise.all([
      api.publishSources(),
      api.publishOrders(20).catch(() => ({ items: [] })),
    ]);
    state.sources = src || {};
    state.dramas = (src && src.dramas) || [];
    state.links = (src && src.links) || [];
    state.titles = (src && src.titles) || { total: 0, global: 0 };
    state.environments = (src && src.environments) || [];
    state.pages = ((src.pages && src.pages.list) || []).map((p) => ({
      pageId: p.pageId,
      pageName: p.pageName || p.pageId,
      assetId: p.assetId || '',
      envCode: p.envCode || '',
      selectable: p.selectable !== false,
      health: p.health || 'ok',
      published: p.published || 0,
      blockReason: p.blockReason || '',
    }));
    state.history = (orders.items || []).slice(0, 8);

    // 账号展开态：**全部默认收起**（2026-11-12 用户明确要求）。
    //
    // 用户原话："你就只显示这个个号，主页不要显示，点击才出现"。
    // 原来的实现会自动展开第一个账号，导致一进来就看到一堆主页卡片，
    // 5 个账号铺满两三屏，反而看不清有哪些号。
    // 现在默认只有账号行（头像 + 名称 + 在线 + 计数），点一下才展开主页。
    // 注意：只在首次加载时初始化一次，之后用户手动展开/收起的状态要保留。
    if (!state._envExpandInit) {
      state._envExpandInit = true;
      state.expandedEnvs = {};
    }

    // 主页默认选择：只选「素材够发」的数量，不是无脑全选。
    //   以前全选 22 个主页，但素材只有 17 条 → 直接判素材不足，
    //   预览根本不发请求，用户既看不到文案也不知道该减几个。
    if (!state.pageIds.length) {
      const can = state.pages.filter((p) => p.selectable);
      const sup = supply();
      const clips = Math.max(1, state.clipsPerPage);
      const fitN = Math.max(1, Math.floor(sup / clips));
      const pick = can.slice(0, Math.min(fitN, can.length));
      state.pageIds = pick.map((p) => p.pageId);
    }
    // 清理已不存在的主页
    const alive = new Set(state.pages.map((p) => p.pageId));
    state.pageIds = state.pageIds.filter((id) => alive.has(id));

    // 素材来源：首次自动选可发更多的那个（库 vs 队列）
    if (!state.sourcePicked) {
      const libN = (src.library && src.library.usable) || 0;
      const qN = (src.queue && src.queue.ready) || 0;
      state.materialSource = qN > libN ? 'queue' : 'library';
      state.sourcePicked = true;
    }

    // 默认参考标题：取标题池第一条（不再拿整段模板当"一条钩子"）
    if (!state.referenceTitle && state.titles.global) {
      try {
        const pool = await api.captionPool('');
        const first = (pool.items || [])[0];
        if (first && first.title) state.referenceTitle = first.title;
      } catch { /* 可选 */ }
    }
  } catch (e) {
    toast('读取失败', e.message, 'err', 5000);
  }
  paint();
  schedulePreview();
}

/* ─────────────────────────────────────────────────────────────
   派生值
   ───────────────────────────────────────────────────────────── */
function selectedPages() {
  const set = new Set(state.pageIds);
  return state.pages.filter((p) => set.has(p.pageId));
}

/** 素材总需求：主页数 × 条数 */
function demand() {
  const n = state.pageIds.length;
  return n * state.clipsPerPage;
}

/** 可用素材量（与后端 resolve_materials 同一判据） */
function supply() {
  const s = state.sources || {};
  if (state.materialSource === 'queue') return (s.queue && s.queue.ready) || 0;
  return (s.library && s.library.usable != null)
    ? s.library.usable
    : ((s.library && s.library.ready) || 0);
}

function canSubmit() {
  if (!state.pageIds.length) return { ok: false, why: '先选择要发布的主页' };
  if (state.clipsPerPage < 1 || state.clipsPerPage > 20) {
    return { ok: false, why: '每主页条数需在 1–20 之间' };
  }
  if (state.running) return { ok: false, why: '当前有订单正在执行' };
  const d = demand();
  const s = supply();
  if (s < d) return { ok: false, why: `素材不足：需要 ${d} 条，可发 ${s} 条` };
  if (!state.preview) return { ok: false, why: '正在生成预览…' };
  if (state.previewErr) return { ok: false, why: state.previewErr };
  return { ok: true, why: `将发 ${state.pageIds.length} 个主页 × ${state.clipsPerPage} 条 = ${d} 条` };
}

/* ─────────────────────────────────────────────────────────────
   渲染
   ───────────────────────────────────────────────────────────── */
function paint() {
  const box = $('#pub-root');
  if (!box) return;
  const v = canSubmit();

  box.innerHTML = `
    <div class="pub-stats">${statsBar()}</div>
    <div class="pub-wrap">
      <div class="pub-main">
        ${stepPages()}
        ${stepMaterials()}
        ${stepPreview()}
        ${state.order ? runBlock() : ''}
      </div>
      <div class="pub-side">
        ${sideParams()}
        ${sideActions(v)}
        ${sideHistory()}
      </div>
    </div>`;
  bind();
}

/* ---------- 顶部指标 ---------- */
function statsBar() {
  const s = state.sources || {};
  const lib = s.library || {};
  const q = s.queue || {};
  const pg = s.pages || {};
  const env = s.envs || {};
  const d = demand();
  const sup = supply();
  const enough = sup >= d && d > 0;
  const usable = supply();
  const isQueue = state.materialSource === 'queue';
  const missing = isQueue ? (q.missingFiles || 0) : (lib.missingFiles || 0);
  const healed = isQueue ? 0 : (lib.healedFiles || 0);

  const cell = (cls, label, ico, val, unit, sub) => `
    <div class="pub-stat ${cls}">
      <div class="pub-stat-label">${icon(ico, 11)}<span>${label}</span></div>
      <div class="pub-stat-val">${val}${unit ? `<em>${unit}</em>` : ''}</div>
      <div class="pub-stat-sub">${sub}</div>
    </div>`;

  let srcSub;
  if (missing) {
    srcSub = `<span style="color:var(--danger)">${missing} 条找不到文件</span>`;
  } else if (healed) {
    srcSub = `<span style="color:var(--warn)">${healed} 条路径已自动修正</span>`;
  } else if (isQueue) {
    srcSub = '来自待发队列';
  } else {
    srcSub = `已用 ${lib.used || 0} · 混剪 ${lib.mix || 0}`;
  }

  return [
    cell(usable ? '' : 'warn', isQueue ? '队列可发' : '可发素材', 'layers', usable, '条', srcSub),
    cell(pg.selectable ? 'ok' : 'warn', '可发主页', 'users', pg.selectable || 0, '个',
      `共 ${pg.total || 0} · 环境在线 ${env.running || 0}`),
    cell(enough ? 'ok' : 'warn', '本轮需求', 'check', d, '条',
      enough ? `素材充足（${sup}）` : `还差 ${Math.max(0, d - sup)} 条`),
    cell('dim', '标题生成', 'terminal',
      state.titles && state.titles.cacheDramas ? state.titles.cacheDramas : 0,
      state.titles && state.titles.cacheDramas ? '部剧已备' : '实时生成',
      (state.titles && state.titles.cacheDramas)
        ? `缓存 ${state.titles.cacheLeft || 0} 条 · AI 按剧生成`
        : `AI 按剧名实时生成 · 链接 ${state.links.length}`),
  ].join('');
}

/* ---------- 步骤 1：按环境选主页 ---------- */
function stepPages() {
  // 只显示「发布号」分组的账号。
  // 用户可以把号划到「授权号」，那些号只在「主页与授权」页出现。
  // 未分组（userGroup 为空）视为发布号，兼容旧数据。
  const envs = (state.environments || []).filter((e) => {
    const g = (e.userGroup || '').toLowerCase();
    return g === '' || g === 'publish';
  });
  const pagesById = new Map(state.pages.map((p) => [p.pageId, p]));
  const sel = new Set(state.pageIds);
  const on = state.pageIds.length;
  const usable = state.pages.filter((p) => p.selectable).length;
  const done = on > 0;

  const cards = envs.map((env) => {
    const list = state.pages.filter((p) => (p.envCode || '') === (env.envCode || ''));
    const selectedN = list.filter((p) => sel.has(p.pageId)).length;
    const selectableN = list.filter((p) => p.selectable).length;
    const expanded = !!state.expandedEnvs[env.envCode];
    const allOn = list.length > 0 && selectedN === selectableN && selectedN > 0;
    const someOn = selectedN > 0 && !allOn;

    // 卡片标题只显示"账号名"。环境名在库里常是容器号（1887976888），
    // 对用户没意义；有绑定账号就显示账号标签。
    const title = env.accountLabel || env.envName || env.envCode;
    // 头像块用账号名的第一个字符（中文取首字，英文取首字母）
    const avatar = (String(title).trim()[0] || '?').toUpperCase();

    // 账号卡片样式参考「主页与授权」页的主页卡片：
    //   左侧方形头像块 + 名称/ID + 右侧状态徽章 + 底部标签行
    const stateBadge = env.running
      ? `<span class="pub-acc-badge ok"><i></i>在线</span>`
      : `<span class="pub-acc-badge off"><i></i>未启动</span>`;

    // 账号卡片：**只有账号这一行**，下面不铺主页列表。
    //
    // 用户要求（2026-11-12，改了三次才说清）：
    //   "只显示个号就是比如发布号有网易发布号和 QQ 发布号，那就只显示这两个，
    //    点击一下其中一个就弹出卡片样式的弹窗，不是排列在主页下面"
    // 所以：
    //   · 账号卡片只显示 头像 / 账号名 / 在线状态 / 选中计数
    //   · 点账号 → 弹出主页卡片网格（每张卡只有主页名字）
    //   · 主页一律不在账号下方内联展开
    return `
      <div class="pub-env ${selectedN ? 'has' : ''} ${env.running ? '' : 'offline'}"
           data-env="${esc(env.envCode)}">
        <div class="pub-env-head" data-env-toggle="${esc(env.envCode)}"
             title="点击打开该账号的主页">
          <span class="pub-env-cb ${allOn ? 'on' : ''} ${someOn ? 'part' : ''}"
                data-env-all="${esc(env.envCode)}"
                title="${allOn ? '取消全选' : '全选该账号下可发主页'}">
            ${icon('check', 10)}
          </span>

          <span class="pub-acc-avatar">${esc(avatar)}</span>

          <div class="pub-env-main">
            <div class="pub-env-name">
              <span class="pub-env-account">${esc(title)}</span>
            </div>
            <div class="pub-acc-meta">
              <span class="mono">${esc(env.cUser || env.envCode)}</span>
              <span class="dot-sep">·</span>
              <span>${env.pageTotal} 个主页</span>
              <span class="dot-sep">·</span>
              <span>可发 <b>${selectableN}</b></span>
              ${env.accountLabel ? '' : '<span class="pub-acc-nolink">未绑账号</span>'}
            </div>
          </div>

          ${stateBadge}

          <div class="pub-env-count">
            ${selectedN ? `<b>${selectedN}</b>/${selectableN}` : `${selectableN}`}
          </div>

          <button class="pub-acc-group" data-set-group="${esc(env.envCode)}"
                  data-cur-group="publish"
                  title="把这个号移到「授权号」分组，发布页不再显示">
            ${icon('arrowR', 10)}授权号
          </button>

          <span class="pub-acc-open" data-env-toggle="${esc(env.envCode)}"
                title="打开主页列表">
            ${icon('layers', 11)}主页
          </span>
        </div>
      </div>`;
  }).join('');

  return `
    <div class="pub-step ${done ? 'done' : 'on'}">
      <div class="pub-step-head">
        <span class="pub-step-no">${done ? icon('check', 10) : '1'}</span>
        <span class="pub-step-title">选择账号与主页
          <small>${on ? `已选 ${on} 个主页 / ${envs.length} 个账号` : `共 ${envs.length} 个账号，可发 ${usable} 个主页`}</small>
        </span>
        <div class="pub-tools">
          <button class="btn xs ghost" data-act="pages-all">全选可用</button>
          <span class="sep"></span>
          <button class="btn xs ghost" data-act="pages-none">清空</button>
          <span class="sep"></span>
          <button class="btn xs ghost" data-act="envs-expand">
            ${envs.every((e) => state.expandedEnvs[e.envCode]) ? '收起全部' : '展开全部'}
          </button>
        </div>
      </div>
      <div class="pub-step-body">
        ${state.pageFilter ? `
          <div class="pub-search" style="margin-bottom:9px">
            ${icon('search', 12)}
            <input id="pub-env-filter" type="text" placeholder="过滤环境或主页"
                   value="${esc(state.pageFilter)}" autocomplete="off" />
            <kbd>${envs.length}</kbd>
          </div>` : ''}
        ${envs.length ? `
          <div class="pub-envs">${cards}</div>
          <div class="pub-env-hint">
            ${icon('bolt', 11)}
            <span>点账号名展开该账号下的主页；点左侧方框全选该账号。
            ${state.pageIds.length ? `已选 ${on} 个主页 = ${on} × ${state.clipsPerPage} 条` : '至少选 1 个主页'}</span>
          </div>` : `<div class="pub-empty">${icon('users', 26)}
            <b>还没有指纹浏览器环境</b>先去「指纹浏览器」启动并绑定账号</div>`}
      </div>
    </div>`;
}

/** 只重绘步骤 1（不碰其他区块，避免输入框失焦） */
function repaintStep1() {
  const box = $('#pub-root');
  if (!box) return;
  const old = $$('.pub-step', box)[0];
  if (old) {
    const tmp = document.createElement('div');
    tmp.innerHTML = stepPages();
    old.replaceWith(tmp.firstElementChild);
    bind();
  }
}

/** 在已渲染的环境卡片上就地过滤，不重建 DOM（避免输入失焦） */
function applyEnvFilter(q) {
  const box = $('#pub-root');
  if (!box) return;
  $$('.pub-env', box).forEach((card) => {
    const code = card.dataset.env;
    const pages = $$('[data-page-card]', card);
    if (!q) {
      card.hidden = false;
      pages.forEach((p) => { p.hidden = false; });
      return;
    }
    const envHit = String(card.querySelector('.pub-env-name')?.innerText || '')
      .toLowerCase().includes(q)
      || String(code).includes(q);
    let anyPage = envHit;
    pages.forEach((p) => {
      const txt = p.innerText.toLowerCase();
      const hit = envHit || txt.includes(q);
      p.hidden = !hit;
      if (hit) anyPage = true;
    });
    card.hidden = !anyPage;
    if (anyPage && q) {
      const body = card.querySelector('.pub-env-body');
      if (body) body.hidden = false;
    }
  });
}

/* ---------- 步骤 2：素材来源 ---------- */
function stepMaterials() {
  const s = state.sources || {};
  const lib = s.library || {};
  const q = s.queue || {};
  const isLib = state.materialSource === 'library';
  const dramas = state.dramas;
  const pickedN = Object.values(state.picked).filter((n) => n > 0).length;
  const usable = lib.usable != null ? lib.usable : (lib.ready || 0);
  const qUsed = q.ready || 0;
  const done = isLib ? dramas.length > 0 : qUsed > 0;
  const missing = isLib ? (lib.missingFiles || 0) : (q.missingFiles || 0);
  const healed = isLib ? (lib.healedFiles || 0) : 0;

  return `
    <div class="pub-step ${done ? 'done' : 'on'}">
      <div class="pub-step-head">
        <span class="pub-step-no">${done ? icon('check', 10) : '2'}</span>
        <span class="pub-step-title">素材来源
          <small>${isLib
            ? `${dramas.length} 部剧 · ${usable} 条可发`
            : `${qUsed} 条待发队列`}</small>
        </span>
        <div class="pub-tools">
          ${isLib && dramas.length ? `
            <button class="btn xs ghost" data-act="pick-none">不指定</button>
            <span class="sep"></span>
            <button class="btn xs ghost" data-act="pick-all">全部勾选</button>` : ''}
        </div>
      </div>
      <div class="pub-step-body">
        <div class="pub-source-tabs">
          <button data-src="library" class="${isLib ? 'on' : ''}">
            ${icon('layers', 11)}素材库<span class="n">${usable}</span>
          </button>
          <button data-src="queue" class="${isLib ? '' : 'on'}">
            ${icon('clock', 11)}待发队列<span class="n">${qUsed}</span>
          </button>
        </div>

        ${missing ? `
          <div class="pub-note err" style="margin-top:10px">
            ${icon('warn', 12)}
            <div><b>${missing}</b> 条素材按文件名也找不到。
            ${lib.currentRoot ? `<br/>${esc(lib.currentRoot)}` : ''}
            <br/>去「素材库」重新扫描。</div>
          </div>` : ''}

        ${lib.healedFiles ? `
          <div class="pub-note" style="margin-top:10px">
            ${icon('refresh', 12)}
            <div>有 <b>${lib.healedFiles}</b> 条素材的库内路径已过期，
            已按文件名自动找回（目录被改名或搬移过）。建议去「素材库」重扫一次，把路径写回库里。</div>
          </div>` : ''}

        ${!isLib && q.missingFiles ? `
          <div class="pub-note err" style="margin-top:10px">
            ${icon('warn', 12)}
            <div>队列里有 <b>${q.missingFiles}</b> 条素材按文件名也找不到，
            需先重新入队或重扫素材库。</div>
          </div>` : ''}

        ${isLib ? materialsByDrama(dramas, pickedN) : `
          <div class="pub-note" style="margin-top:10px">
            ${icon('bolt', 12)}
            <div>从「排期与队列」里 <b>state=ready</b> 且文件存在的素材取，按加入时间先进先出。</div>
          </div>`}
      </div>
    </div>`;
}

function materialsByDrama(dramas, pickedN) {
  if (!dramas.length) {
    return `<div class="pub-empty" style="margin-top:8px">${icon('layers', 26)}
      <b>素材库没有可发的单集</b>
      先去「素材库」扫描并确认版权，或切到「待发队列」</div>`;
  }
  const clips = state.clipsPerPage;
  const rows = dramas.map((d) => {
    const nm = d.drama || '（未命名剧）';
    const total = d.n || 0;
    const on = (state.picked[nm] || 0) > 0;
    const short = total < clips;
    const n = state.picked[nm] || Math.min(clips, total);
    return `
      <div class="pub-drama ${on ? 'on' : ''}" data-drama="${esc(nm)}">
        <span class="pub-cb">${icon('check', 9)}</span>
        <div class="pub-drama-main">
          <div class="pub-drama-nm">${esc(nm)}</div>
          <div class="pub-drama-sub">
            ${total} 集${short ? ` <span class="cold">（不足 ${clips}）</span>` : ''}
          </div>
        </div>
        <div class="pub-drama-num">
          <input type="number" data-dn="${esc(nm)}" value="${n}"
                 min="1" max="${Math.min(20, total)}" ${on ? '' : 'disabled'} />
          <span>集</span>
        </div>
      </div>`;
  }).join('');

  return `
    <div style="display:flex;align-items:center;gap:6px;margin-top:10px;font-size:10px;color:var(--tx-3)">
      ${pickedN
        ? `已指定 ${pickedN} 部剧，其余按「每主页条数」自动从全库分配`
        : `未指定剧 → 全库按主页顺序自动分配（推荐）`}
    </div>
    <div class="pub-dramas">${rows}</div>`;
}

/* ---------- 步骤 3：预览 ---------- */
function stepPreview() {
  const p = state.preview;
  const done = !!(p && p.items && p.items.length);

  let body;
  if (state.previewLoading) {
    body = `<div class="pub-empty">${icon('hourglass', 26)}正在计算分配与文案…</div>`;
  } else if (state.previewErr) {
    body = `<div class="pub-note err">${icon('warn', 12)}<div>${esc(state.previewErr)}</div></div>`;
  } else if (!done) {
    body = `<div class="pub-empty">${icon('eye', 26)}
      <b>还没有预览</b>选好主页与条数后自动生成</div>`;
  } else {
    body = previewBody(p);
  }

  return `
    <div class="pub-step ${done ? 'done' : 'on'}">
      <div class="pub-step-head">
        <span class="pub-step-no">${done ? icon('check', 10) : '3'}</span>
        <span class="pub-step-title">发布预览
          <small>${done ? `${p.pageCount} 个主页 × ${p.clipsPerPage} 条 · 共 ${p.itemCount} 条` : '发送前可逐条核对'}</small>
        </span>
        ${done ? `<div class="pub-tools">
          <button class="btn xs ghost" data-act="copy-all">复制全部文案</button>
        </div>` : ''}
      </div>
      <div class="pub-step-body">${body}</div>
    </div>`;
}

function previewBody(p) {
  const byPage = new Map();
  for (const it of p.items) {
    if (!byPage.has(it.pageName)) byPage.set(it.pageName, []);
    byPage.get(it.pageName).push(it);
  }
  const names = [...byPage.keys()];
  const idx = Math.min(state.previewPage, names.length - 1);
  const cur = names[idx] || '';
  const rows = byPage.get(cur) || [];
  const itemIdx = Math.min(state.previewItem || 0, Math.max(0, rows.length - 1));
  const first = rows[itemIdx] || {};

  const tabs = names.map((nm, i) => `
    <button class="pub-prev-tab ${i === idx ? 'on' : ''}" data-prev="${i}">
      ${esc(nm)} <span style="opacity:.6">${(byPage.get(nm) || []).length}</span>
    </button>`).join('');

  const caption = highlightLinks(first.caption || '');

  const itemTabs = rows.length > 1 ? `
    <div class="pub-prev-tabs" style="margin-top:2px">
      ${rows.map((r, i) => `
        <button class="pub-prev-tab ${i === itemIdx ? 'on' : ''}" data-item="${i}">
          第 ${r.slot} 条
        </button>`).join('')}
    </div>` : '';

  return `
    <div class="pub-preview">
      <div class="pub-prev-tabs">${tabs}</div>
      ${itemTabs}
      <div class="pub-prev-body">${caption}</div>
      <div class="pub-prev-meta">
        <span>${icon('video', 9)}${esc(first.file || '')}</span>
        <span>${icon('link', 9)}${first.link ? esc(shortLink(first.link)) : '无链接'}</span>
        <span>${esc(first.captionSource || '')}</span>
      </div>
    </div>`;
}

function shortLink(u) {
  const s = String(u || '');
  return s.length > 44 ? `${s.slice(0, 41)}…` : s;
}

/* ---------- 右栏：参数 ---------- */
function sideParams() {
  return `
    <div class="pub-side-card">
      <div class="pub-side-head">${icon('cog', 11)}发布参数</div>
      <div class="pub-side-body">
        <div class="pub-field">
          <label>每主页条数 <b>${state.clipsPerPage}</b></label>
          <input type="number" id="pub-clips" value="${state.clipsPerPage}"
                 min="1" max="20" step="1" />
          <div class="tip">1 条即单条发布；素材消耗 = 主页数 × 条数</div>
        </div>

        <div class="pub-field">
          <label>文案来源</label>
          <div class="pub-seg">
            <button data-style="simple" class="${state.captionStyle === 'simple' ? 'on' : ''}">
              标题 + 链接</button>
            <button data-style="template" class="${state.captionStyle === 'template' ? 'on' : ''}">
              4 行模板</button>
          </div>
          <div class="tip">${state.captionStyle === 'simple'
            ? '标题从标题池按主页挑，链接从链接池按权重挑'
            : '固定 4 行结构，链接放首行，剧名进 Title 行'}</div>
        </div>

        <div class="pub-field">
          <label>文案模板 <span style="color:var(--tx-3);font-weight:400">（支持多行 / {{DRAMA}}）</span></label>
          <textarea id="pub-ref" rows="6"
            placeholder="留空 = AI 按剧名实时生成标题（同一批内每条不重复）&#10;&#10;想固定文案就粘贴整段模板，例如：&#10;🎬NEXT EPISODE👉🏻{链接}&#10;🌟Watch all episodes for FREE&#10;🔍Title: &quot;{{DRAMA}}&quot;.&#10;Click the link in the title to...">${esc(state.referenceTitle)}</textarea>
          <div class="tip">
            ${state.referenceTitle.trim()
              ? '填了就用这段（换行保留），AI 标题不生效'
              : '留空 → AI 按剧名生成，同批每条不重复'}
          </div>
          ${state.referenceTitle.trim() ? '' : `
            <button class="btn xs ghost" data-act="regen-titles" style="margin-top:4px">
              ${icon('refresh', 10)}重新生成标题
            </button>`}
        </div>

        <div class="pub-field">
          <label>指定标题 <span style="color:var(--tx-3);font-weight:400">（可选，覆盖上面）</span></label>
          <input type="text" id="pub-fixed-title" value="${esc(state.fixedTitle)}"
                 placeholder="填了就忽略标题池与模板" />
        </div>

        <div class="pub-field">
          <label>指定链接 <span style="color:var(--tx-3);font-weight:400">（可选）</span></label>
          <input type="text" id="pub-fixed-link" value="${esc(state.fixedLink)}"
                 placeholder="${state.links.length ? `留空则从 ${state.links.length} 条链接池随机` : '链接池为空，建议填一条'}" />
          ${state.links.length ? `<div class="tip">
            池：${state.links.slice(0, 2).map((l) => esc(l.label || '')).join(' · ')}
            ${state.links.length > 2 ? ` 等 ${state.links.length} 条` : ''}
          </div>` : ''}
        </div>

        <div class="pub-field">
          <label>分配方式</label>
          <div class="pub-seg">
            <button data-alloc="merge" class="${state.allocMode === 'merge' ? 'on' : ''}">
              全库均衡</button>
            <button data-alloc="per_drama" class="${state.allocMode === 'per_drama' ? 'on' : ''}">
              按剧匹配</button>
          </div>
          <div class="tip">${state.allocMode === 'merge'
            ? '所有单集洗牌后按主页顺序平均分'
            : '按主页的内容偏好（page_fit）挑剧'}</div>
        </div>

        <div class="pub-field">
          <label>上传卡住容忍 <b>${state.uploadStallSeconds}s</b></label>
          <input type="number" id="pub-stall" value="${state.uploadStallSeconds}"
                 min="60" max="3600" step="30" />
          <div class="tip">网络慢或大文件调到 300–600</div>
        </div>

        ${scheduleBlock()}
      </div>
    </div>`;
}

/* ---------- 右栏：排期设置 ---------- */
function scheduleBlock() {
  const clips = state.clipsPerPage;
  const even = state.scheduleMode === 'even';

  // 预览每条的实际偏移
  const offsets = effectiveOffsets();
  const previewRows = Array.from({ length: clips }, (_, i) => {
    const off = offsets[i] ?? 0;
    const label = i === 0
      ? '立即发布'
      : (off > 0 ? `+${off} 分钟` : '立即发布');
    return `
      <div class="pub-sched-row">
        <span class="pub-sched-idx">${i + 1}</span>
        <span class="pub-sched-lbl">${esc(label)}</span>
        ${even
          ? ''
          : `<input type="number" data-off="${i}" value="${off}"
                    min="0" max="10080" step="5"
                    style="width:58px;padding:2px 5px;font-size:10px" />`}
      </div>`;
  }).join('');

  return `
    <div class="pub-side-card">
      <div class="pub-side-head">${icon('clock', 11)}排期设置</div>
      <div class="pub-side-body">
        <div class="pub-field">
          <label>间隔方式</label>
          <div class="pub-seg">
            <button data-sched="even" class="${even ? 'on' : ''}">等距</button>
            <button data-sched="custom" class="${even ? '' : 'on'}">逐条调整</button>
          </div>
          <div class="tip">${even
            ? '第 1 条立即发，之后每条 +间隔分钟'
            : '每条单独设相对基线的分钟数'}</div>
        </div>

        ${even ? `
          <div class="pub-field">
            <label>每条间隔 <b>${state.spacingMinutes} 分钟</b></label>
            <input type="number" id="pub-spacing" value="${state.spacingMinutes}"
                   min="0" max="10080" step="5" />
            <div class="tip">同样的主页内的多条视频按此间隔错峰</div>
          </div>` : ''}

        ${clips > 1 ? `
          <div class="pub-field">
            <label>本轮排期预览 <span style="color:var(--tx-3);font-weight:400">（每主页 ${clips} 条）</span></label>
            <div class="pub-sched-list">${previewRows}</div>
          </div>` : `
          <div class="pub-note" style="margin:0">
            ${icon('bolt', 12)}
            <div>每主页只有 1 条，全部立即发布，不涉及排期。</div>
          </div>`}
      </div>
    </div>`;
}

/** 当前生效的逐条偏移数组 */
function effectiveOffsets() {
  const clips = Math.max(1, state.clipsPerPage);
  if (state.scheduleMode === 'custom' && state.scheduleOffsets.length) {
    const out = [];
    for (let i = 0; i < clips; i += 1) {
      out.push(Number(state.scheduleOffsets[i] ?? (i === 0 ? 0 : i * state.spacingMinutes)) || 0);
    }
    return out;
  }
  return Array.from({ length: clips }, (_, i) => i * state.spacingMinutes);
}

/* ---------- 右栏：预算 + 开始 ---------- */
function sideActions(v) {
  const d = demand();
  const s = supply();
  const pct = d > 0 ? Math.min(100, Math.round((s / d) * 100)) : 0;
  const cls = s >= d ? 'ok' : 'bad';
  const short = Math.max(0, d - s);
  const canFit = s > 0 && short > 0;

  return `
    <div class="pub-side-card">
      <div class="pub-side-head">${icon('bolt', 11)}执行</div>
      <div class="pub-side-body">
        <div class="pub-budget">
          <div class="pub-budget-row">
            <span>素材供给</span>
            <b>${s}</b>
          </div>
          <div class="pub-budget-row ${cls}">
            <span>本轮需要</span>
            <b>${d}</b>
          </div>
          <div class="pub-budget-bar ${cls}"><i style="width:${pct}%"></i></div>
        </div>

        ${canFit ? `
          <div class="pub-note warn" style="margin:0">
            ${icon('warn', 12)}
            <div>还差 <b>${short}</b> 条。可以让这轮少发几个主页，
            或减少每主页条数。</div>
          </div>
          <button class="btn ghost sm" data-act="fit" style="width:100%">
            按现有素材自动调整（${fitPlan().pages} 主页 × ${fitPlan().clips} 条）
          </button>` : ''}

        <button class="pub-go" id="pub-go" ${v.ok ? '' : 'disabled'}>
          ${icon('send', 14)}${state.running ? '执行中…' : '开始发布'}
        </button>
        <div class="pub-go-why ${v.ok ? '' : 'err'}">${esc(v.why)}</div>

        ${state.order && state.running ? `
          <button class="btn danger sm" data-act="cancel" style="width:100%">
            停止本轮（剩余标为跳过）</button>` : ''}
      </div>
    </div>`;
}

/** 按可用素材算出「最贴近的」主页数 × 条数，给一键适配用。 */
function fitPlan() {
  const s = supply();
  const nPages = state.pageIds.length || 1;
  const clips = state.clipsPerPage;
  if (s <= 0) return { pages: 0, clips };
  if (s >= nPages * clips) return { pages: nPages, clips };
  // 先试同条数少发几个主页
  const fitPages = Math.floor(s / clips);
  if (fitPages >= 1) return { pages: fitPages, clips };
  // 条数降不下来（clips=1）就只能减少主页
  return { pages: Math.min(nPages, s), clips: 1 };
}

/* ---------- 右栏：历史 ---------- */
function sideHistory() {
  if (!state.history.length) {
    return `
      <div class="pub-side-card">
        <div class="pub-side-head">${icon('clock', 11)}最近发布</div>
        <div class="pub-side-body">
          <div style="font-size:10.5px;color:var(--tx-3);text-align:center;padding:8px 0">
            还没有发布记录
          </div>
        </div>
      </div>`;
  }
  const rows = state.history.map((o) => `
    <div class="pub-hist-row" data-order="${esc(o.id)}">
      <span class="pub-hist-state ${esc(o.state)}">${esc(o.state)}</span>
      <span class="pub-hist-title">${esc(o.title || o.id)}</span>
      <span class="pub-hist-num">
        <span class="ok">${o.ok_count || 0}</span> / <span class="ng">${o.fail_count || 0}</span>
      </span>
      <span class="pub-hist-num">${esc((o.created_at || '').slice(5, 16).replace('T', ' '))}</span>
    </div>`).join('');

  return `
    <div class="pub-side-card">
      <div class="pub-side-head">${icon('clock', 11)}最近发布</div>
      <div class="pub-side-body" style="padding:10px">
        <div class="pub-hist">${rows}</div>
      </div>
    </div>`;
}

/* ---------- 执行进度块 ---------- */
function runBlock() {
  const o = state.order;
  if (!o) return '';
  const items = o.items || [];
  const counts = {};
  for (const it of items) counts[it.state] = (counts[it.state] || 0) + 1;
  const total = items.length || 1;
  const committed = counts.COMMITTED || 0;
  const pct = Math.round((o.progress || 0));

  // 按主页分组
  const byPage = new Map();
  for (const it of items) {
    const nm = it.page_name || it.page_id;
    if (!byPage.has(nm)) byPage.set(nm, []);
    byPage.get(nm).push(it);
  }

  const ringCls = o.state === 'COMPLETED' ? 'ok'
    : (o.state === 'FAILED' || o.state === 'BLOCKED') ? 'err' : '';

  const groups = [...byPage.entries()].map(([nm, list]) => {
    const c = list.filter((x) => x.state === 'COMMITTED').length;
    const bad = list.filter((x) => x.state === 'FAILED' || x.state === 'REJECTED').length;
    return `
      <div class="pub-grp">
        <span>${esc(nm)}</span>
        <span class="cnt">
          ${c}/${list.length} 完成${bad ? ` · ${bad} 失败` : ''}
        </span>
      </div>
      ${list.map((it) => {
        const cls = ({
          COMMITTED: 'committed', RUNNING: 'running', FAILED: 'failed',
          REJECTED: 'failed', ATTENTION: 'attention', BLOCKED: 'failed',
          SKIPPED: 'skipped',
        })[it.state] || '';
        const label = ({
          PENDING: '等待', RUNNING: '发送中', COMMITTED: '已发布',
          REJECTED: '被拒', FAILED: '失败', BLOCKED: '熔断',
          SKIPPED: '跳过', ATTENTION: '待确认',
        })[it.state] || it.state;
        return `
          <div class="pub-item ${cls}">
            <span class="pub-item-dot"></span>
            <div style="min-width:0">
              <div class="pub-item-file">${esc(it.file_name || it.file || '')}</div>
              ${it.error ? `<div class="pub-item-sub" style="color:var(--danger)">${esc(String(it.error).slice(0, 80))}</div>` : ''}
            </div>
            <span class="pub-item-state">${esc(label)}</span>
          </div>`;
      }).join('')}`;
  }).join('');

  return `
    <div class="pub-run">
      <div class="pub-run-head">
        <div class="pub-ring ${ringCls}" style="--p:${pct}"><b>${pct}%</b></div>
        <div class="pub-run-title">
          ${esc(o.stage || o.state)}
          <small>${esc(o.id)} · 成功 ${committed} / ${total}</small>
        </div>
        <button class="btn xs ghost" data-act="toggle-run">收起</button>
      </div>
      <div class="pub-run-body">${groups}</div>
    </div>`;
}

/* ─────────────────────────────────────────────────────────────
   事件绑定
   ───────────────────────────────────────────────────────────── */
function bind() {
  const box = $('#pub-root');
  if (!box) return;

  // 账号卡片：点击 → 弹出该账号的主页卡片网格
  //
  // 用户要求：点账号不是内联展开，是弹一个卡片式弹窗，
  // 弹窗里每个主页只显示名字（简洁）。
  $$('[data-env-toggle]', box).forEach((el) => {
    el.onclick = (e) => {
      if (e.target.closest('[data-env-all]')) return;   // 全选框单独处理
      if (e.target.closest('[data-set-group]')) return; // 分组按钮单独处理
      openAccountPages(el.dataset.envToggle);
    };
  });

  // 环境卡片：全选 / 取消该环境
  $$('[data-env-all]', box).forEach((el) => {
    el.onclick = (e) => {
      e.stopPropagation();
      const code = el.dataset.envAll;
      const list = state.pages.filter((p) => (p.envCode || '') === code && p.selectable);
      const sel = new Set(state.pageIds);
      const allOn = list.every((p) => sel.has(p.pageId)) && list.length > 0;
      if (allOn) {
        for (const p of list) { const i = state.pageIds.indexOf(p.pageId); if (i >= 0) state.pageIds.splice(i, 1); }
      } else {
        for (const p of list) if (!sel.has(p.pageId)) state.pageIds.push(p.pageId);
      }
      // 全选时自动展开，让用户看到选了什么
      if (!allOn) state.expandedEnvs[code] = true;
      paint();
      schedulePreview();
    };
  });

  // ── 账号 → 主页卡片弹窗 ──
  //
  // 用户要求（2026-11-12）："点击一下其中一个就弹出卡片样式的弹窗，
  // 里面的内容是一个个主页，每个主页只需要主页名字，简洁点就好"
  //
  // 所以这个弹窗：
  //   · 卡片网格（自适应列宽）
  //   · 每张卡只有主页名字 + 选中状态
  //   · 点卡片 = 选中/取消，不跳转
  //   · 长按/右侧小点 = 看主页详情（复用 authz 的详情窗）
  function openAccountPages(envCode) {
    const env = (state.environments || []).find((e) => e.envCode === envCode);
    if (!env) return;

    const list = state.pages.filter((p) => (p.envCode || '') === envCode);
    const sel = new Set(state.pageIds);
    const title = env.accountLabel || env.envName || envCode;

    const cardHtml = list.length
      ? list.map((p) => {
        const on = sel.has(p.pageId);
        const cls = ['pgcard', on ? 'on' : '', p.selectable ? '' : 'off']
          .filter(Boolean).join(' ');
        return `
          <div class="${cls}" data-pick="${esc(p.pageId)}"
               title="${esc(p.selectable ? '点击选择' : (p.blockReason || '不可发布'))}">
            <span class="pgcard-cb">${icon('check', 9)}</span>
            <span class="pgcard-name">${esc(p.pageName)}</span>
            <span class="pgcard-info" data-page-detail="${esc(p.pageId)}"
                  title="详情">${icon('eye', 10)}</span>
          </div>`;
      }).join('')
      : `<div class="pgcard-empty">该账号没有主页</div>`;

    const mask = document.createElement('div');
    mask.className = 'pub-modal-mask';
    mask.innerHTML = `
      <div class="pub-modal pgmodal" role="dialog" aria-modal="true">
        <div class="pgmodal-head">
          <div class="pgmodal-title">
            <span class="pgmodal-av">${esc((String(title)[0] || '?').toUpperCase())}</span>
            <div>
              <div class="pgmodal-name">${esc(title)}</div>
              <div class="pgmodal-sub">
                ${list.length} 个主页 · 已选 <b>${list.filter((p) => sel.has(p.pageId)).length}</b>
              </div>
            </div>
          </div>
          <button class="pgmodal-x" data-close>${icon('x', 13)}</button>
        </div>

        <div class="pgmodal-tools">
          <button class="btn xs ghost" data-all>全选可发</button>
          <button class="btn xs ghost" data-none>清空</button>
        </div>

        <div class="pgmodal-body">
          <div class="pgcard-grid">${cardHtml}</div>
        </div>

        <div class="pgmodal-foot">
          <button class="btn xs" data-close>完成</button>
        </div>
      </div>`;

    document.body.appendChild(mask);
    requestAnimationFrame(() => mask.classList.add('on'));

    const close = () => {
      mask.classList.remove('on');
      setTimeout(() => mask.remove(), 180);
    };
    mask.querySelectorAll('[data-close]').forEach((b) => { b.onclick = close; });
    mask.onclick = (e) => { if (e.target === mask) close(); };

    // 点卡片：选中 / 取消
    mask.querySelectorAll('[data-pick]').forEach((card) => {
      card.onclick = (e) => {
        if (e.target.closest('[data-page-detail]')) {
          e.preventDefault();
          e.stopPropagation();
          openPageDetail(card.dataset.pick);
          return;
        }
        const id = card.dataset.pick;
        const p = state.pages.find((x) => x.pageId === id);
        if (p && !p.selectable) {
          toast('该主页不可发', p.blockReason || '状态异常', 'warn', 2400);
          return;
        }
        const i = state.pageIds.indexOf(id);
        if (i >= 0) state.pageIds.splice(i, 1);
        else state.pageIds.push(id);
        // 就地更新这张卡，不重绘整个弹窗（否则会闪）
        const nowOn = state.pageIds.includes(id);
        card.classList.toggle('on', nowOn);
        const cnt = mask.querySelector('.pgmodal-sub b');
        if (cnt) {
          cnt.textContent = String(
            state.pages.filter((x) => x.envCode === envCode
              && state.pageIds.includes(x.pageId)).length);
        }
        repaintStep1();
        schedulePreview();
        refreshSide();
      };
    });

    // 全选可发
    const allBtn = mask.querySelector('[data-all]');
    if (allBtn) allBtn.onclick = () => {
      for (const p of list) {
        if (p.selectable && !state.pageIds.includes(p.pageId)) {
          state.pageIds.push(p.pageId);
        }
      }
      mask.querySelectorAll('[data-pick]').forEach((c) => c.classList.add('on'));
      toast('已全选该账号可发主页', 'ok', 1600);
      repaintStep1();
      schedulePreview();
      refreshSide();
      close();
    };

    // 清空
    const noneBtn = mask.querySelector('[data-none]');
    if (noneBtn) noneBtn.onclick = () => {
      const ids = new Set(list.map((p) => p.pageId));
      state.pageIds = state.pageIds.filter((x) => !ids.has(x));
      mask.querySelectorAll('[data-pick]').forEach((c) => c.classList.remove('on'));
      repaintStep1();
      schedulePreview();
      refreshSide();
    };
  }

  // 单个主页卡片：点一下选中/取消；点右侧「详情」打开弹窗
  $$('[data-page-card]', box).forEach((el) => {
    el.onclick = (e) => {
      // 点到详情按钮：打开详情，不切换选中
      if (e.target.closest('[data-page-detail]')) {
        e.preventDefault();
        e.stopPropagation();
        openPageDetail(el.dataset.pageCard);
        return;
      }
      e.preventDefault();
      const id = el.dataset.pageCard;
      const p = state.pages.find((x) => x.pageId === id);
      if (p && !p.selectable) {
        toast('该主页不可发', p.blockReason || '状态异常', 'warn', 2600);
        return;
      }
      const i = state.pageIds.indexOf(id);
      if (i >= 0) state.pageIds.splice(i, 1);
      else state.pageIds.push(id);
      repaintStep1();
      schedulePreview();
      refreshSide();
    };
  });

  // ── 主页详情弹窗 ──
  // 用户要求（2026-11-12）："不是点击展开主页，是点击打开主页卡片像这样"
  // 结构参照「主页与授权」页的详情弹窗：
  //   page_id / asset_id / 所属号 / 授权列表 / 操作按钮
  // 主页详情：直接复用「主页与授权」页的 openDetail，
  // 保证两处字段、布局、按钮完全一致（用户明确要求"就像这样"）。
  async function openPageDetail(pageId) {
    try {
      await authzPage.openDetail(pageId);
    } catch (e) {
      // 兜底：如果 authz 页加载失败，至少提示出来，不要静默
      toast('打开详情失败', String(e && e.message || e), 'err', 3000);
    }
  }

  // 环境搜索
  const envFilter = $('#pub-env-filter', box);
  if (envFilter) {
    envFilter.oninput = () => {
      const q = envFilter.value.trim().toLowerCase();
      // 有搜索词就展开命中环境
      if (q) {
        for (const env of state.environments) {
          const hit = String(env.envName).toLowerCase().includes(q)
            || state.pages.some((p) => p.envCode === env.envCode
              && (String(p.pageName).toLowerCase().includes(q)
                || String(p.pageId).includes(q)));
          if (hit) state.expandedEnvs[env.envCode] = true;
        }
      }
      applyEnvFilter(q);
    };
  }

  // 展开/收起全部
  const expAll = $('[data-act="envs-expand"]', box);
  if (expAll) expAll.onclick = () => {
    const allOpen = state.environments.every((e) => state.expandedEnvs[e.envCode]);
    state.expandedEnvs = {};
    if (!allOpen) for (const e of state.environments) state.expandedEnvs[e.envCode] = true;
    repaintStep1();
  };

  // 全选 / 清空主页
  const allBtn = $('[data-act="pages-all"]', box);
  if (allBtn) allBtn.onclick = () => {
    state.pageIds = state.pages.filter((p) => p.selectable).map((p) => p.pageId);
    for (const e of state.environments) state.expandedEnvs[e.envCode] = true;
    paint(); schedulePreview();
  };
  const noneBtn = $('[data-act="pages-none"]', box);
  if (noneBtn) noneBtn.onclick = () => {
    state.pageIds = [];
    paint(); schedulePreview();
  };

  // 素材来源切换
  $$('[data-src]', box).forEach((b) => {
    b.onclick = () => {
      state.materialSource = b.dataset.src;
      state.picked = {};
      paint(); schedulePreview();
    };
  });

  // 按剧勾选
  $$('.pub-drama', box).forEach((row) => {
    const nm = row.dataset.drama;
    row.onclick = (e) => {
      if (e.target.tagName === 'INPUT') return;
      const on = (state.picked[nm] || 0) > 0;
      if (on) delete state.picked[nm];
      else {
        const d = state.dramas.find((x) => x.drama === nm);
        state.picked[nm] = Math.min(state.clipsPerPage, (d && d.n) || 1);
      }
      paint(); schedulePreview();
    };
  });
  $$('[data-dn]', box).forEach((inp) => {
    inp.onclick = (e) => e.stopPropagation();
    inp.onchange = () => {
      const nm = inp.dataset.dn;
      const d = state.dramas.find((x) => x.drama === nm);
      const max = Math.min(20, (d && d.n) || 1);
      let v = parseInt(inp.value, 10);
      if (!Number.isFinite(v) || v < 1) v = 1;
      if (v > max) v = max;
      state.picked[nm] = v;
      inp.value = v;
      schedulePreview();
    };
  });

  const pickNone = $('[data-act="pick-none"]', box);
  if (pickNone) pickNone.onclick = () => { state.picked = {}; paint(); schedulePreview(); };
  const pickAll = $('[data-act="pick-all"]', box);
  if (pickAll) pickAll.onclick = () => {
    for (const d of state.dramas) {
      state.picked[d.drama] = Math.min(state.clipsPerPage, d.n || 1);
    }
    paint(); schedulePreview();
  };

  // 预览标签切换
  $$('[data-prev]', box).forEach((b) => {
    b.onclick = () => {
      state.previewPage = parseInt(b.dataset.prev, 10) || 0;
      state.previewItem = 0;
      repaintPreviewOnly();
    };
  });
  $$('[data-item]', box).forEach((b) => {
    b.onclick = () => {
      state.previewItem = parseInt(b.dataset.item, 10) || 0;
      repaintPreviewOnly();
    };
  });

  // 复制全部文案
  const copyBtn = $('[data-act="copy-all"]', box);
  if (copyBtn) copyBtn.onclick = () => {
    const p = state.preview;
    if (!p) return;
    const txt = p.items.map((i) =>
      `【${i.pageName}】${i.file}\n${i.caption}`).join('\n\n---\n\n');
    navigator.clipboard?.writeText(txt).then(
      () => toast('已复制', `${p.items.length} 条文案`, 'ok'),
      () => toast('复制失败', '浏览器拒绝剪贴板访问', 'err'));
  };

  // 参数
  const clips = $('#pub-clips', box);
  if (clips) clips.onchange = () => {
    let v = parseInt(clips.value, 10);
    if (!Number.isFinite(v)) v = 1;
    if (v < 1) v = 1;
    if (v > 20) v = 20;
    state.clipsPerPage = v;
    paint(); schedulePreview();
  };
  $$('[data-style]', box).forEach((b) => {
    b.onclick = () => { state.captionStyle = b.dataset.style; paint(); schedulePreview(); };
  });
  $$('[data-alloc]', box).forEach((b) => {
    b.onclick = () => { state.allocMode = b.dataset.alloc; paint(); schedulePreview(); };
  });
  // 文案模板：必须用 oninput，不能用 onchange
  //   onchange 只有失焦才触发，用户在 textarea 里打字/粘贴后
  //   没点别处就点「开始发布」时，输入的值从来没进 state，
  //   表现为"改了模板但文案没变"（线上真实反馈）。
  const ref = $('#pub-ref', box);
  if (ref) {
    const syncRef = () => {
      state.referenceTitle = ref.value;
      schedulePreview();
    };
    ref.oninput = syncRef;
    ref.onchange = syncRef;
    ref.onblur = syncRef;
  }
  // 重新生成标题：清掉按剧缓存，让 AI 重出一批
  const regen = $('[data-act="regen-titles"]', box);
  if (regen) regen.onclick = async () => {
    regen.disabled = true;
    regen.textContent = '生成中…';
    state.regenTitles = true;
    await runPreview();
    state.regenTitles = false;
    regen.disabled = false;
    regen.innerHTML = `${icon('refresh', 10)}重新生成标题`;
  };

  // ── 分组切换：把这个号移到「授权号」 ──
  $$('[data-set-group]', box).forEach((btn) => {
    btn.onclick = async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const code = btn.dataset.setGroup;
      const env = envs.find((e) => e.envCode === code);
      const name = (env && (env.accountLabel || env.envName)) || code;

      btn.disabled = true;
      btn.textContent = '移动中…';
      try {
        const r = await api.groupSetEnv({ envCode: code, group: 'auth' });
        if (r && r.ok) {
          toast(`${name} 已移到「授权号」，发布页不再显示`, 'ok');
          // 从本地状态里移除，避免整页重载
          state.environments = state.environments.filter(
            (e) => e.envCode !== code);
          state.pageIds = state.pageIds.filter((pid) => {
            const p = state.pages.find((x) => x.pageId === pid);
            return p && p.envCode !== code;
          });
          void refreshSource();
        } else {
          toast('移动失败', 'err');
          btn.disabled = false;
          btn.innerHTML = `${icon('arrowR', 10)}授权号`;
        }
      } catch (e) {
        toast(`移动失败：${e.message || e}`, 'err');
        btn.disabled = false;
        btn.innerHTML = `${icon('arrowR', 10)}授权号`;
      }
    };
  });

  const ft = $('#pub-fixed-title', box);
  if (ft) {
    const syncFt = () => { state.fixedTitle = ft.value; schedulePreview(); };
    ft.oninput = syncFt;
    ft.onchange = syncFt;
  }
  const fl = $('#pub-fixed-link', box);
  if (fl) {
    const syncFl = () => { state.fixedLink = fl.value; schedulePreview(); };
    fl.oninput = syncFl;
    fl.onchange = syncFl;
  }
  const stall = $('#pub-stall', box);
  if (stall) stall.onchange = () => {
    let v = parseInt(stall.value, 10);
    if (!Number.isFinite(v)) v = 180;
    v = Math.max(60, Math.min(3600, v));
    state.uploadStallSeconds = v;
    stall.value = v;
  };

  // ── 排期设置 ──
  $$('[data-sched]', box).forEach((b) => {
    b.onclick = () => {
      state.scheduleMode = b.dataset.sched;
      if (state.scheduleMode === 'custom' && !state.scheduleOffsets.length) {
        state.scheduleOffsets = effectiveOffsets();
      }
      repaintSideParams();
    };
  });

  const spacing = $('#pub-spacing', box);
  if (spacing) spacing.onchange = () => {
    let v = parseInt(spacing.value, 10);
    if (!Number.isFinite(v) || v < 0) v = 30;
    v = Math.min(10080, v);
    state.spacingMinutes = v;
    state.scheduleOffsets = [];      // 等距模式下清掉自定义
    repaintSideParams();
  };

  $$('[data-off]', box).forEach((inp) => {
    inp.onchange = () => {
      const i = parseInt(inp.dataset.off, 10);
      let v = parseInt(inp.value, 10);
      if (!Number.isFinite(v) || v < 0) v = 0;
      v = Math.min(10080, v);
      const arr = effectiveOffsets();
      arr[i] = v;
      state.scheduleOffsets = arr;
      inp.value = v;
      repaintSideParams();
    };
  });

  // 开始
  const go = $('#pub-go', box);
  if (go) go.onclick = () => confirmPublish();

  // 按素材自动适配
  const fit = $('[data-act="fit"]', box);
  if (fit) fit.onclick = () => {
    const plan = fitPlan();
    if (!plan.pages) { toast('没法适配', '当前没有可发素材', 'err'); return; }
    state.clipsPerPage = plan.clips;
    // 按当前勾选顺序保留前 plan.pages 个主页
    state.pageIds = state.pageIds.slice(0, plan.pages);
    toast('已适配',
      `${plan.pages} 个主页 × ${plan.clips} 条 = ${plan.pages * plan.clips} 条`,
      'ok', 2600);
    paint();
    schedulePreview();
  };

  // 取消
  const cancel = $('[data-act="cancel"]', box);
  if (cancel) cancel.onclick = () => doCancel();

  // 历史订单
  $$('[data-order]', box).forEach((row) => {
    row.onclick = () => openOrder(row.dataset.order);
  });

  // 收起进度
  const toggle = $('[data-act="toggle-run"]', box);
  if (toggle) toggle.onclick = () => {
    const body = toggle.closest('.pub-run').querySelector('.pub-run-body');
    const hidden = body.style.display === 'none';
    body.style.display = hidden ? '' : 'none';
    toggle.textContent = hidden ? '收起' : '展开';
  };
}

/* ─────────────────────────────────────────────────────────────
   预览（去抖 350ms，避免每敲一个字就发请求）
   ───────────────────────────────────────────────────────────── */
function schedulePreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(runPreview, 350);
}

function payloadBase() {
  return {
    pageIds: state.pageIds,
    clipsPerPage: state.clipsPerPage,
    materialSource: state.materialSource,
    allocMode: state.allocMode,
    captionStyle: state.captionStyle,
    fixedTitle: state.fixedTitle,
    fixedLink: state.fixedLink,
    referenceTitle: state.referenceTitle,
    regenTitles: !!state.regenTitles,
  };
}

async function runPreview() {
  if (!state.pageIds.length) {
    state.preview = null;
    state.previewErr = '';
    state.previewLoading = false;
    repaintPreviewOnly();
    return;
  }
  // 素材不足时仍然请求预览：
  //   · 让用户看见"这个主页会发什么文案"，而不是一个空白区
  //   · 后端会返回 shortage 说明，前端显示在错误条里
  //   · 「开始发布」按钮仍然禁用（由 canSubmit 管）
  state.previewLoading = true;
  state.previewErr = '';
  repaintPreviewOnly();

  try {
    const r = await api.publishPreview(payloadBase());
    state.preview = r;
    state.previewPage = Math.min(state.previewPage, Math.max(0,
      new Set((r.items || []).map((i) => i.pageName)).size - 1));
  } catch (e) {
    state.preview = null;
    state.previewErr = e.message || '预览失败';
  } finally {
    state.previewLoading = false;
    repaintPreviewOnly();
    // 预算与按钮状态也要跟着变
    refreshSide();
  }
}

/** 只重绘步骤 3，不碰其他区块（避免输入框失焦） */
function repaintPreviewOnly() {
  const box = $('#pub-root');
  if (!box) return;
  const old = $$('.pub-step', box)[2];
  if (old) {
    const tmp = document.createElement('div');
    tmp.innerHTML = stepPreview();
    old.replaceWith(tmp.firstElementChild);
    bind();
  }
}

/** 只重绘发布参数卡（排期设置在这里，改完要立刻看到预览更新） */
function repaintSideParams() {
  const box = $('#pub-root');
  if (!box) return;
  const side = $('.pub-side', box);
  if (!side) return;
  const card = side.firstElementChild;
  if (!card) return;
  const tmp = document.createElement('div');
  tmp.innerHTML = sideParams();
  const fresh = tmp.firstElementChild;
  if (fresh) card.replaceWith(fresh);
  bind();
}

function refreshSide() {
  const box = $('#pub-root');
  if (!box) return;

  // 只更新「执行」卡片和「最近发布」，绝不重建「发布参数」。
  //
  // 为什么：sideParams() 每次都用 state 重新渲染 textarea/input，
  // 用户正在打字时会被覆盖回旧值，并触发 oninput 形成回环，
  // 表现为"一改模板预览就消失"（线上真实问题）。
  const v = canSubmit();
  const side = $('.pub-side', box);
  if (!side) return;

  const act = $('.pub-side-card:nth-child(2)', side);   // 第 2 张卡 = 执行
  if (act) {
    const tmp = document.createElement('div');
    tmp.innerHTML = sideActions(v);
    const fresh = tmp.firstElementChild;
    if (fresh) act.replaceWith(fresh);
    bind();
    return;
  }
  // 兜底：整体重建（正常不会走到）
  side.innerHTML = `${sideParams()}${sideActions(v)}${sideHistory()}`;
  bind();
}

/* ─────────────────────────────────────────────────────────────
   确认 → 建单 → 订阅进度
   ───────────────────────────────────────────────────────────── */
function confirmPublish() {
  const v = canSubmit();
  if (!v.ok) { toast('还不能发布', v.why, 'err'); return; }
  const p = state.preview;
  if (!p) return;

  const body = document.createElement('div');
  body.className = 'pub-confirm';
  body.innerHTML = `
    <div class="pub-confirm-kv">
      <span class="k">主页</span><span class="v"><b>${state.pageIds.length}</b> 个</span>
      <span class="k">每主页</span><span class="v"><b>${state.clipsPerPage}</b> 条</span>
      <span class="k">素材总数</span><span class="v"><b>${p.itemCount}</b> 条（来自${state.materialSource === 'queue' ? '待发队列' : '素材库'}）</span>
      <span class="k">文案</span><span class="v">${state.captionStyle === 'simple' ? '标题 + 链接' : '4 行模板'}</span>
      <span class="k">分配</span><span class="v">${state.allocMode === 'merge' ? '全库均衡' : '按剧匹配'}</span>
    </div>
    <div class="pub-confirm-list">${confirmList(p)}</div>
    <div class="pub-note warn">
      ${icon('warn', 12)}
      <div><b>发布成功的素材会自动出库（标记 used）</b>，失败的原样保留。
      素材是通过 staging 目录发给内核的，母片不会被物理删除。</div>
    </div>`;

  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'btn ghost';
  cancelBtn.textContent = '再改改';
  cancelBtn.onclick = () => m.close();

  const okBtn = document.createElement('button');
  okBtn.className = 'btn primary';
  okBtn.textContent = '确认发布';
  okBtn.onclick = () => {
    m.close();
    startOrder();
  };

  const m = modal({
    title: '确认发布',
    body,
    footer: [cancelBtn, okBtn],
    width: '520px',
  });
}

function confirmList(p) {
  const byPage = new Map();
  for (const it of p.items) {
    const nm = it.pageName || it.pageId;
    if (!byPage.has(nm)) byPage.set(nm, []);
    byPage.get(nm).push(it);
  }
  return [...byPage.entries()].map(([nm, list]) => `
    <div class="grp">${esc(nm)} · ${list.length} 条</div>
    ${list.map((it) => `<div class="it">${esc(it.file)}</div>`).join('')}
  `).join('');
}

async function startOrder() {
  const go = $('#pub-go');
  if (go) { go.disabled = true; go.textContent = '提交中…'; }
  try {
    const r = await api.publishCreate({
      ...payloadBase(),
      concurrency: state.concurrency,
      uploadStallSeconds: state.uploadStallSeconds,
      spacingMinutes: state.spacingMinutes,
      // 逐条偏移：等距模式交给后端按 spacingMinutes 算；
      // 自定义模式把完整数组发过去（长度 = 每主页条数）
      scheduleOffsets: state.scheduleMode === 'custom'
        ? effectiveOffsets()
        : [],
    });
    state.orderId = r.orderId;
    state.running = true;
    toast('已提交', `订单 ${r.orderId} · ${r.itemCount} 条`, 'ok', 3000);
    subscribe(r.orderId);
    paint();
    // 拉到第一帧
    await refreshOrder(r.orderId);
    await loadHistoryOnly();
  } catch (e) {
    state.running = false;
    toast('提交失败', e.message, 'err', 6000);
    paint();
  }
}

/* ---------- SSE ---------- */
function subscribe(orderId) {
  unsubscribe();
  try {
    es = new EventSource(api.publishEventsUrl(orderId));
    es.onmessage = (ev) => {
      try {
        const d = JSON.parse(ev.data);
        if (d.error) { unsubscribe(); return; }
        applyEvent(d);
      } catch { /* 单帧解析失败忽略 */ }
    };
    es.onerror = () => {
      // EventSource 会自己重连；但订单结束就直接关掉
      if (state.order && ['COMPLETED', 'FAILED', 'CANCELLED', 'ATTENTION']
        .includes(state.order.state) && !state.running) {
        unsubscribe();
      }
    };
  } catch (e) {
    // 浏览器不支持 SSE → 退回一次拉取
    refreshOrder(orderId);
  }
}

function unsubscribe() {
  if (es) { try { es.close(); } catch { /* ignore */ } es = null; }
}

function applyEvent(d) {
  if (!state.order) state.order = { id: state.orderId, items: [] };
  state.order.state = d.state;
  state.order.stage = d.stage;
  state.order.progress = d.progress;
  state.order.ok_count = d.okCount;
  state.order.fail_count = d.failCount;
  if (Array.isArray(d.items)) {
    const old = new Map((state.order.items || []).map((i) => [i.id, i]));
    state.order.items = d.items.map((i) => ({
      ...(old.get(i.id) || {}),
      id: i.id, page_name: i.pageName, state: i.state,
      slot: i.slot, file_name: i.file, error: i.error,
    }));
  }
  state.running = !!d.running
    && !['COMPLETED', 'FAILED', 'CANCELLED'].includes(d.state);

  // 只重绘进度块与右栏按钮
  repaintRunBlock();
  refreshSide();

  if (['COMPLETED', 'FAILED', 'CANCELLED', 'ATTENTION'].includes(d.state) && !d.running) {
    state.running = false;
    unsubscribe();
    const okN = d.okCount || 0;
    const failN = d.failCount || 0;
    toast(
      d.state === 'COMPLETED' ? '发布完成' : '发布结束',
      `成功 ${okN} · 失败 ${failN}`,
      d.state === 'COMPLETED' ? 'ok' : (okN ? 'warn' : 'err'),
      6000,
    );
    loadHistoryOnly();
    refreshSourcesSoon();
  }
}

function repaintRunBlock() {
  const box = $('#pub-root');
  if (!box) return;
  const old = $('.pub-run', box);
  if (old) {
    const tmp = document.createElement('div');
    tmp.innerHTML = state.order ? runBlock() : '';
    const fresh = tmp.firstElementChild;
    if (fresh) old.replaceWith(fresh);
    else old.remove();
    bind();
  } else if (state.order) {
    const main = $('.pub-main', box);
    if (main) {
      const tmp = document.createElement('div');
      tmp.innerHTML = runBlock();
      if (tmp.firstElementChild) main.appendChild(tmp.firstElementChild);
      bind();
    }
  }
}

async function refreshOrder(orderId) {
  try {
    const d = await api.publishOrder(orderId);
    state.order = d;
    state.running = !!d.running
      && !['COMPLETED', 'FAILED', 'CANCELLED'].includes(d.state);
    paint();
  } catch (e) {
    toast('无法读取订单', e.message, 'warn');
  }
}

async function loadHistoryOnly() {
  try {
    const r = await api.publishOrders(20);
    state.history = (r.items || []).slice(0, 8);
    refreshSide();
  } catch { /* ignore */ }
}

function refreshSourcesSoon() {
  setTimeout(async () => {
    try {
      const s = await api.publishSources();
      state.sources = s;
      state.dramas = s.dramas || [];
      state.links = s.links || [];
      state.titles = s.titles || { total: 0, global: 0 };
      paint();
    } catch { /* ignore */ }
  }, 1200);
}

async function doCancel() {
  if (!state.orderId) return;
  try {
    const r = await api.publishCancel(state.orderId);
    toast('已取消', r.note || '', 'warn');
    state.running = false;
    unsubscribe();
    await refreshOrder(state.orderId);
  } catch (e) {
    toast('取消失败', e.message, 'err');
  }
}

/* ---------- 打开历史订单 ---------- */
async function openOrder(orderId) {
  try {
    const d = await api.publishOrder(orderId);
    state.order = d;
    state.orderId = orderId;
    state.running = !!d.running;
    paint();
    const box = $('#pub-root');
    if (box) box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (d.running) subscribe(orderId);
  } catch (e) {
    toast('读取失败', e.message, 'err');
  }
}

/* ─────────────────────────────────────────────────────────────
   工具
   ───────────────────────────────────────────────────────────── */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** 转义但保留换行（pre-wrap 已设，这里只需处理 HTML 特殊字符） */
function escKeep(s) {
  return esc(s);
}

/** 把文案里的 URL 包成高亮 span */
function highlightLinks(text) {
  const esc2 = esc(text);
  return esc2.replace(/(https?:\/\/[^\s<>"']+)/g,
    '<span class="lnk">$1</span>');
}

/* 离开页面时清理 */
window.addEventListener('hashchange', () => {
  unsubscribe();
  clearTimeout(previewTimer);
});

