# -*- coding: utf-8 -*-
"""雨海工作台 · 桌面入口。

打包后启动流程：
    1. 找空闲端口（默认 8710，被占则顺延）
    2. 后台线程起 uvicorn（同进程，无需外部 python）
    3. 用 pywebview 开一个原生窗口加载 Web UI
    4. 关窗口 = 退出整个程序（含后端 + 轮询）

开发模式（直接 python desktop.py）也是一样的行为。
"""
from __future__ import annotations

import logging
import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

APP_NAME = "雨海工作台"
DEFAULT_PORT = 8710


# ---------------- 路径 ----------------
def app_dir() -> Path:
    """程序所在目录（打包后是 exe 所在目录，开发时是 backend/）。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def resource_dir() -> Path:
    """只读资源目录（打包后是 _MEIPASS）。"""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", app_dir()))
    return Path(__file__).resolve().parent


def setup_env() -> None:
    """设置运行环境变量（必须在 import app.* 之前）。

    热更新支持：
        app 代码优先从 <程序目录>\\app 加载（如果有），
        其次才用 exe 内置的（PyInstaller 冻结的）。
        这样更新只需替换 <程序目录>\\app 下的 .py 文件，不用重新打包。
    """
    base = app_dir()
    os.environ["YUHAI_APP_DIR"] = str(base)      # 热更新系统用
    data = base / "data"
    try:
        data.mkdir(parents=True, exist_ok=True)
        # 探一下可写
        probe = data / ".write_test"
        probe.write_text("1", encoding="utf-8")
        probe.unlink()
    except Exception:
        data = Path(os.environ.get("LOCALAPPDATA", str(base))) / "YuhaiWorkbench"
        data.mkdir(parents=True, exist_ok=True)
    # 强制覆盖：绝不让 config 退回到 _internal/data
    os.environ["YUHAI_DATA_DIR"] = str(data)

    # ---- 首次启动：自动创建素材目录（2026-11-13 用户要求）----
    #    "下载安装后在目录里自动创建对应的文件夹"
    #    别人拿到空壳软件，双击就能用，不用手动建目录。
    #    ⚠ 只 mkdir(exist_ok=True)，绝不删除已有内容
    for sub in ("素材库", "视频素材", "处理好素材"):
        try:
            (base / sub).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    # 素材库里也预建"原始素材"（下载落地位置）
    try:
        (base / "素材库" / "原始素材").mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # ---- 热更新：外部 app 代码优先 ----
    ext_app = base / "app"
    if ext_app.is_dir() and (ext_app / "main.py").exists():
        # 插到 sys.path 最前面，让它优先于 exe 内置的 app 包
        p = str(base)
        if p not in sys.path:
            sys.path.insert(0, p)
        # 清掉可能已加载的内置 app（理论上此时还没 import）
        for m in list(sys.modules):
            if m == "app" or m.startswith("app."):
                del sys.modules[m]
        os.environ["YUHAI_EXT_APP"] = str(ext_app)

    # 前端目录：优先外部 frontend（可热替换），其次打包内置
    fe = base / "frontend"
    if not (fe / "index.html").exists():
        fe = resource_dir() / "frontend"
    if not fe.exists():
        fe = resource_dir().parent / "frontend"
    if fe.exists():
        os.environ["YUHAI_FRONTEND"] = str(fe)
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")


def pick_port(start: int = DEFAULT_PORT) -> int:
    """找可用端口。优先用环境变量指定的，被占则顺延。"""
    try:
        start = int(os.environ.get("YUHAI_PORT", start))
    except ValueError:
        pass
    for p in range(start, start + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


def log_path() -> Path:
    d = Path(os.environ["YUHAI_DATA_DIR"]) / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d / "desktop.log"


# ---------------- 后端 ----------------
class Backend:
    def __init__(self, port: int) -> None:
        self.port = port
        self.thread: threading.Thread | None = None
        self.ready = threading.Event()
        self.error: str | None = None

    def start(self) -> None:
        self.thread = threading.Thread(target=self._run, daemon=True,
                                       name="uvicorn")
        self.thread.start()

    def _run(self) -> None:
        try:
            import uvicorn
            from app.main import app
            cfg = uvicorn.Config(
                app, host="127.0.0.1", port=self.port,
                log_level="warning", access_log=False,
                log_config=None,
            )
            server = uvicorn.Server(cfg)
            # 标记就绪：uvicorn 会在 startup 完成后置位 started
            def watch():
                for _ in range(120):
                    if getattr(server, "started", False):
                        self.ready.set()
                        return
                    time.sleep(0.5)
            threading.Thread(target=watch, daemon=True).start()
            server.run()
        except Exception as e:
            self.error = str(e)
            self.ready.set()

    def wait(self, timeout: float = 90) -> bool:
        return self.ready.wait(timeout) and not self.error


def _show_window(window) -> None:
    """把窗口显示到前台（托盘点击时用）。"""
    try:
        window.show()
        window.restore() if hasattr(window, "restore") else None
    except Exception:
        pass
    try:
        # 抢焦点
        window.on_top = True
        window.on_top = False
    except Exception:
        pass


# ---------------- 系统托盘 ----------------
def find_icon() -> Path | None:
    """找一个可用的图标文件（ico 优先，其次 png）。"""
    cands = []
    base = app_dir()
    res = resource_dir()
    for root in (base, res, res / "frontend" / "assets",
                 base / "frontend" / "assets"):
        for name in ("icon.ico", "favicon.ico", "icon-256.png", "icon.png"):
            cands.append(root / name)
    for c in cands:
        if c.exists():
            return c
    return None


class Tray:
    """系统托盘图标。

    · 左键单击：显示/隐藏窗口
    · 右键菜单：显示窗口 / 在浏览器打开 / 打开数据目录 / 退出
    · 关闭窗口默认最小化到托盘（可在菜单里选真正退出）
    """

    def __init__(self, url: str, on_show=None, on_quit=None) -> None:
        self.url = url
        self._on_show = on_show
        self._on_quit = on_quit
        self._icon = None
        self._thread = None

    def start(self) -> bool:
        try:
            import pystray
            from PIL import Image
        except ImportError as e:
            logging.getLogger("yuhai.tray").warning(
                "托盘不可用（缺 pystray/Pillow）：%s", e)
            return False

        ico = find_icon()
        try:
            if ico:
                img = Image.open(str(ico))
                # 托盘图标建议 64x64
                img = img.convert("RGBA").resize((64, 64), Image.LANCZOS)
            else:
                img = Image.new("RGBA", (64, 64), (99, 102, 241, 255))
        except Exception as e:
            logging.getLogger("yuhai.tray").warning("图标加载失败: %s", e)
            img = Image.new("RGBA", (64, 64), (99, 102, 241, 255))

        def _show(icon=None, item=None):
            try:
                if self._on_show:
                    self._on_show()
            except Exception:
                pass

        def _browser(icon=None, item=None):
            try:
                webbrowser.open(self.url)
            except Exception:
                pass

        def _datadir(icon=None, item=None):
            try:
                d = Path(os.environ.get("YUHAI_DATA_DIR") or app_dir())
                os.startfile(str(d))
            except Exception:
                pass

        def _quit(icon=None, item=None):
            try:
                if self._icon:
                    self._icon.stop()
            except Exception:
                pass
            try:
                if self._on_quit:
                    self._on_quit()
            finally:
                # 硬退出，确保后台线程不残留
                os._exit(0)

        menu = pystray.Menu(
            pystray.MenuItem("显示窗口", _show, default=True),
            pystray.MenuItem("在浏览器打开", _browser),
            pystray.MenuItem("打开数据目录", _datadir),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("退出 " + APP_NAME, _quit),
        )
        try:
            self._icon = pystray.Icon(
                "yuhai_workbench", img, APP_NAME, menu)
            self._thread = threading.Thread(
                target=self._icon.run, daemon=True, name="tray")
            self._thread.start()
            logging.getLogger("yuhai.tray").info("托盘图标已启动")
            return True
        except Exception as e:
            logging.getLogger("yuhai.tray").warning("托盘启动失败: %s", e)
            return False

    def stop(self) -> None:
        try:
            if self._icon:
                self._icon.stop()
        except Exception:
            pass


# ---------------- 主流程 ----------------
def _single_instance_guard() -> bool:
    """单实例检查（2026-11-13）。

    ⚠ 为什么不用 app.single_instance：
        desktop.py 被 PyInstaller 冻结进 exe，热替换改不了它，
        但它在新版里要能调用到检查逻辑 —— 而旧 exe 的 app/ 目录
        可能还没有 single_instance.py。
        所以这里用**纯标准库**实现，任何版本都能跑。

    返回 True=可以启动；False=已有实例，应退出。
    """
    if os.name != "nt":
        return True
    try:
        import ctypes
        import hashlib
        from ctypes import wintypes

        # 用程序目录做 key：同一份安装只能跑一个
        key = str(app_dir()).lower()
        h = hashlib.sha1(key.encode("utf-8", "replace")).hexdigest()[:16]
        name = f"Global\\YuhaiWorkbench-{h}"

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [
            wintypes.LPCVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        handle = kernel32.CreateMutexW(None, True, name)
        err = ctypes.get_last_error()

        if not handle:
            return True     # 建不出互斥体就放行，不要因此起不来
        if err == 183:      # ERROR_ALREADY_EXISTS
            kernel32.CloseHandle(handle)
            # 尽力把已有窗口调到前台
            try:
                import urllib.request
                port = os.environ.get("YUHAI_PORT", str(DEFAULT_PORT))
                urllib.request.urlopen(
                    urllib.request.Request(
                        f"http://127.0.0.1:{port}/api/system/activate",
                        data=b"{}", method="POST",
                        headers={"Content-Type": "application/json"}),
                    timeout=3).read(200)
            except Exception:
                pass
            return False
        # 成功：句柄必须活到进程结束，挂到模块级
        globals()["_MUTEX"] = handle
        return True
    except Exception:
        return True


def main() -> int:
    setup_env()

    # ⚠ 单实例：必须在起后端、开窗口之前拦
    if not _single_instance_guard():
        print("雨海工作台已在运行，本次启动已取消。", file=sys.stderr)
        try:
            logging.getLogger("yuhai.desktop").info(
                "已有实例在运行，本次启动取消")
        except Exception:
            pass
        return 0

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[
            logging.FileHandler(log_path(), encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )
    log = logging.getLogger("yuhai.desktop")

    port = pick_port()
    url = f"http://127.0.0.1:{port}"
    log.info("%s starting on %s", APP_NAME, url)
    log.info("data dir = %s", os.environ["YUHAI_DATA_DIR"])

    be = Backend(port)
    be.start()

    no_window = os.environ.get("YUHAI_NO_WINDOW") == "1" or "--no-window" in sys.argv
    if no_window:
        log.info("no-window mode; open %s manually", url)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return 0

    if not be.wait(90):
        log.error("backend failed: %s", be.error or "timeout")
        try:
            import webview
            webview.create_window(
                f"{APP_NAME} · 启动失败",
                html=("<html><body style='font-family:sans-serif;padding:40px'>"
                      "<h2>后端启动失败</h2>"
                      f"<p>{be.error or '超时'}</p>"
                      f"<p>日志：{log_path()}</p></body></html>"),
                width=640, height=380,
            )
            webview.start()
        except Exception:
            pass
        return 1

    # 开原生窗口（加系统托盘图标）
    try:
        import webview
        window = webview.create_window(
            APP_NAME, url,
            width=1560, height=980,
            min_size=(1180, 760),
            background_color="#f6f7fb",
            text_select=True,
        )

        # 托盘：关窗口时最小化到托盘而不是退出，可从托盘菜单真正退出
        tray = Tray(
            url,
            on_show=lambda: _show_window(window),
            on_quit=lambda: log.info("quit from tray"),
        )
        if tray.start():
            def _on_closing():
                """点窗口 X：隐藏到托盘，程序继续在后台运行。"""
                try:
                    window.hide()
                except Exception:
                    pass
                return False     # False = 不关闭窗口/不退出进程
            try:
                window.events.closing += _on_closing
                log.info("已启用「关闭最小化到托盘」")
            except Exception as e:
                log.warning("closing 事件绑定失败: %s", e)
        else:
            log.warning("托盘未启动，关闭窗口将直接退出")

        webview.start(debug=False)
        log.info("window closed, exiting")
        tray.stop()
        return 0
    except Exception as e:
        log.warning("webview failed (%s), fallback to browser", e)
        webbrowser.open(url)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return 0


def _load_external_bootstrap() -> None:
    """优先使用程序目录下的新版 desktop.py（热更新支持）。

    ⚠ 2026-11-13 为什么需要这个：
        desktop.py 被 PyInstaller 冻结进 exe，改源码不会生效，
        每次修入口级问题（单实例、窗口行为）都得重新打包 344MB 的 exe。

        做法：exe 启动时先看 <程序目录>\\desktop.py 在不在、比自己的新，
        在就把执行权交给它（runpy 跑外部文件的 main）。

        安全：只有外部文件存在且能成功导入时才交权；
              任何异常都退回内置逻辑，不会让软件起不来。
    """
    try:
        base = Path(sys.executable).resolve().parent \
            if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
        ext = base / "desktop.py"
        if not ext.is_file():
            return
        # 别递归：外部文件自己也会调这个函数
        if os.environ.get("YUHAI_BOOTSTRAPPED") == "1":
            return
        if ext.resolve() == Path(__file__).resolve():
            return
        os.environ["YUHAI_BOOTSTRAPPED"] = "1"
        import runpy
        runpy.run_path(str(ext), run_name="__main__")
        sys.exit(0)
    except SystemExit:
        raise
    except Exception:
        # 外部脚本有问题就用内置的，不能因此起不来
        os.environ.pop("YUHAI_BOOTSTRAPPED", None)


if __name__ == "__main__":
    _load_external_bootstrap()
    sys.exit(main())
