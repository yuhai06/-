// Shared by the desktop shell and publishing worker; never hard-code in HTML.
export const RELEASE = Object.freeze({ version: 'V19.7', build: '20261002.2' });
