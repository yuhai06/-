import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from '../vendor/playwright-core/index.mjs';
import { AppError } from './errors.mjs';
import { discoverHubstudio } from './hubstudio.mjs';
import { isBlockedPageText } from './pages.mjs';
import { writeXlsx } from './xlsx.mjs';

// ─────────────────────────────────────────────────────────────
// 已导出链接台账：跨轮次、跨重启记录哪些 reel 链接已经导出过，
// 避免定时发布场景下反复提取同一批老链接。
// 存放于 dataDir/exported-links.json，按 reel 数字 ID 去重。
// ─────────────────────────────────────────────────────────────
const LEDGER_FILE = 'exported-links.json';
const LEDGER_VERSION = 1;
const REEL_ID = /\/(?:reel|videos)\/(\d+)/i;

export function reelIdOf(link) {
  const match = String(link || "").match(REEL_ID);
  return match ? match[1] : null;
}

function ledgerPath(dataDir) {
  return path.join(dataDir, LEDGER_FILE);
}

export async function readExportedLedger(dataDir) {
  if (!dataDir) return { version: LEDGER_VERSION, links: {} };
  try {
    const raw = JSON.parse(await fs.readFile(ledgerPath(dataDir), "utf8"));
    if (raw && raw.version === LEDGER_VERSION && raw.links && typeof raw.links === "object") return raw;
  } catch (error) {
    if (error.code !== "ENOENT" && !(error instanceof SyntaxError)) throw error;
  }
  return { version: LEDGER_VERSION, links: {} };
}

export async function writeExportedLedger(dataDir, ledger) {
  if (!dataDir) return;
  const links = (ledger && ledger.links) || {};
  const entries = Object.entries(links)
    .sort((left, right) => String((right[1] || {}).at || "").localeCompare(String((left[1] || {}).at || "")))
    .slice(0, 5000);
  const payload = { version: LEDGER_VERSION, updatedAt: new Date().toISOString(), links: Object.fromEntries(entries) };
  await fs.mkdir(dataDir, { recursive: true });
  const target = ledgerPath(dataDir);
  const temporary = target + ".tmp";
  await fs.writeFile(temporary, JSON.stringify(payload, null, 2), "utf8");
  await fs.rename(temporary, target).catch(async error => {
    if (!["EEXIST", "EPERM", "EACCES"].includes(error.code)) throw error;
    await fs.rm(target, { force: true });
    await fs.rename(temporary, target);
  });
}

/** 从链接台账中筛掉已导出的链接，返回 kept / skipped。 */
export function splitByLedger(rows, ledger) {
  const known = (ledger && ledger.links) || {};
  const kept = [];
  const skipped = [];
  for (const row of rows || []) {
    const id = reelIdOf(row.link);
    if (id && known[id]) skipped.push(Object.assign({}, row, { reelId: id, firstExportedAt: (known[id] || {}).at || null }));
    else kept.push(row);
  }
  return { kept, skipped };
}

/** 把本次导出的链接写入台账。 */
export function recordLedger(ledger, rows, options) {
  const opts = options || {};
  const at = new Date().toISOString();
  const links = Object.assign({}, (ledger && ledger.links) || {});
  for (const row of rows || []) {
    const id = reelIdOf(row.link);
    if (!id) continue;
    const entry = { link: row.link, pageName: row.pageName || "", profileId: row.profileId || "", at: at };
    if (opts.runId) entry.runId = opts.runId;
    if (opts.stamp) entry.stamp = opts.stamp;
    links[id] = entry;
  }
  return { version: LEDGER_VERSION, updatedAt: at, links: links };
}

import { UNAVAILABLE_CONTENT } from '../skill-runtime/meta_locale.mjs';

const MAX_LINKS_PER_PAGE = 50;
const MAX_SCROLL_ROUNDS = 8;
const FACEBOOK_HOST = /(?:^|\.)facebook\.com$/i;
const REEL_PATH = /^\/(?:reel|videos)\/(\d+)(?:\/|$)/i;
const LOGIN_PATH = /\/(?:checkpoint|login|two_step_verification)(?:\/|\.|$)/i;
const NAVIGATION_QUERY_MARKERS = ['notif_id=', 'notif_t=', 's=tab', 'ref=notif'];
const PAGE_NOT_FOUND_TEXT = /page\s+not\s+found|this\s+page\s+isn'?t\s+available|this\s+content\s+isn'?t\s+available|content\s+isn'?t\s+available|page\s+(?:is\s+)?unavailable|页面(?:无法显示|不存在|已被移除|已删除)|頁面(?:無法顯示|不存在|已被移除|已刪除)|链接可能(?:已失效|已损坏|已过期)|鏈接可能(?:已失效|已損壞|已過期)/i;

function cell(value) {
  return String(value ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

function submitted(page) {
  return page.state === 'completed' || page.state === 'cleanup_failed' || Boolean(page.acceptedAt);
}

function pageKey(page) {
  return `${page.environmentId}:${page.pageId}`;
}

function pad(value) {
  return String(value).padStart(2, '0');
}

function localStamp(date) {
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`;
}

function isLoginUrl(value) {
  try {
    const url = new URL(value);
    return FACEBOOK_HOST.test(url.hostname)
      && (LOGIN_PATH.test(url.pathname) || url.pathname.startsWith('/business/loginpage') || url.searchParams.has('checkpoint'));
  } catch { return false; }
}

function parseReelId(href) {
  try {
    const url = new URL(href, 'https://www.facebook.com');
    if (!FACEBOOK_HOST.test(url.hostname)) return null;
    const match = url.pathname.match(REEL_PATH);
    return match ? match[1] : null;
  } catch { return null; }
}

export function publicPageRef(page) {
  const profileId = String(page?.profileId ?? '').trim();
  if (profileId) return profileId;
  const pageId = String(page?.pageId ?? '').trim();
  return pageId || null;
}

export function isUnavailablePageText(text) {
  const body = String(text || '');
  return UNAVAILABLE_CONTENT.test(body) || PAGE_NOT_FOUND_TEXT.test(body);
}

function isExcludedNavigationHref(href) {
  const value = String(href || '').toLowerCase();
  if (value.includes('/notifications/')) return true;
  return NAVIGATION_QUERY_MARKERS.some(marker => value.includes(marker));
}

export function reelLinksFromHrefs(hrefs) {
  const ids = new Map();
  for (const href of hrefs || []) {
    if (isExcludedNavigationHref(href)) continue;
    const id = parseReelId(href);
    if (id && !ids.has(id)) ids.set(id, `https://www.facebook.com/reel/${id}/`);
  }
  return [...ids.values()];
}

export function linkSetSignature(links) {
  return (links || []).map(link => String(link)).join('\n');
}

export function rememberLinkSet(seen, links) {
  const signature = linkSetSignature(links);
  if (seen.has(signature)) return { duplicate: true, signature };
  seen.add(signature);
  return { duplicate: false, signature };
}

function describeError(error) {
  if (error?.name === 'TimeoutError' || /timeout|超时/i.test(error?.message || '')) return '页面加载或提取超时';
  return error?.message || String(error || '未知错误');
}

async function connectEnvironment(environment, connector) {
  const browser = await connector(environment.endpoint, { timeout: 15000, noDefaults: true });
  const contexts = browser.contexts();
  if (contexts.length !== 1) throw new AppError('UNSUPPORTED_CONTEXT', '该环境没有唯一的浏览器上下文。');
  return { browser, context: contexts[0] };
}

async function assertPageSafe(page) {
  if (isLoginUrl(page.url())) throw new AppError('LINK_EXPORT_LOGIN_REQUIRED', '页面跳转到登录或身份验证页，可能登录态已失效。');
  const body = await page.evaluate(() => (document.body?.innerText || '').slice(0, 200000));
  if (isBlockedPageText(body)) throw new AppError('LINK_EXPORT_RISK', '页面出现登录、验证码、身份验证或账号状态提示，可能触发风控。');
}

async function collectReelLinks(page) {
  const ids = new Map();
  let stagnantRounds = 0;
  for (let round = 0; round < MAX_SCROLL_ROUNDS && ids.size < MAX_LINKS_PER_PAGE; round += 1) {
    const hrefs = await page.evaluate(() => {
      const main = document.querySelector('main,[role="main"]');
      return [...(main || document).querySelectorAll('a[href]')].map(anchor => anchor.href);
    });
    const before = ids.size;
    for (const link of reelLinksFromHrefs(hrefs)) {
      const id = link.match(/\/reel\/(\d+)\//)?.[1];
      if (id && !ids.has(id)) ids.set(id, link);
    }
    if (ids.size >= MAX_LINKS_PER_PAGE) break;
    stagnantRounds = ids.size === before ? stagnantRounds + 1 : 0;
    if (stagnantRounds >= 3) break;
    await page.evaluate(() => window.scrollBy(0, Math.max(window.innerHeight, 800)));
    await page.waitForTimeout(1200);
    await assertPageSafe(page);
  }
  return [...ids.values()].slice(0, MAX_LINKS_PER_PAGE);
}

async function assertPageAvailable(page) {
  const content = await page.evaluate(() => ({
    title: document.title || '',
    text: (document.body?.innerText || '').slice(0, 200000),
  }));
  if (isUnavailablePageText(`${content.title}\n${content.text}`)) {
    throw new AppError('LINK_EXPORT_PAGE_NOT_FOUND', '目标主页页面不存在或内容不可用，已拒绝把导航区域链接当作本主页视频。');
  }
}

export async function extractPageLinks(connection, page) {
  const pageRef = typeof page === 'string' ? String(page).trim() : publicPageRef(page);
  if (!pageRef) throw new AppError('INVALID_PAGE_ID', '无法确定主页公开 ID（profileId）或资产 ID（pageId）。');
  const browserPage = await connection.context.newPage();
  try {
    await browserPage.goto(`https://www.facebook.com/${encodeURIComponent(pageRef)}/reels/`, { waitUntil: 'domcontentloaded', timeout: 45000 });
    await browserPage.waitForTimeout(2500);
    await assertPageSafe(browserPage);
    await assertPageAvailable(browserPage);
    const links = await collectReelLinks(browserPage);
    if (!links.length) throw new AppError('LINK_EXPORT_EMPTY', '未提取到 Reels 视频链接。');
    return links;
  } finally {
    await browserPage.close().catch(() => {});
  }
}

function pageEnvironmentId(page) {
  const direct = String(page?.environmentId ?? '').trim();
  if (direct) return direct;
  const environments = Array.isArray(page?.environments) ? page.environments : [];
  return String(environments[0]?.environmentId ?? environments[0]?.id ?? '').trim();
}

function failureRecord(page, error, reason) {
  return {
    pageId: String(page.pageId || publicPageRef(page) || ''),
    pageName: String(page.pageName || ''),
    profileId: String(page.profileId || ''),
    reason,
    code: error?.code || 'LINK_EXPORT_FAILED',
  };
}

async function extractLinksForPages(pages, {
  onProgress = () => {},
  discoverEnvironments = discoverHubstudio,
  connector = (...args) => chromium.connectOverCDP(...args),
  allowSingleEnvironmentFallback = false,
} = {}) {
  const rows = [];
  const failures = [];
  const pageResults = [];
  const processed = new Set();
  const usedLinkSets = new Set();
  const fail = (page, error, { notify = true } = {}) => {
    const key = pageKey(page);
    if (processed.has(key)) return false;
    processed.add(key);
    const reason = describeError(error);
    const failure = failureRecord(page, error, reason);
    failures.push(failure);
    if (notify) onProgress({
      environmentId: pageEnvironmentId(page),
      pageId: page.pageId,
      pageName: page.pageName,
      profileId: page.profileId,
      stage: `视频链接提取失败：${reason}`,
      error: { code: failure.code, message: reason },
    });
    return true;
  };

  onProgress({ stage: '正在提取视频链接' });
  if (!pages.length) return { rows, failures, pages: pageResults };

  try {
    const hub = await discoverEnvironments();
    const environments = new Map(hub.environments.map(environment => [String(environment.environmentId), environment]));
    const connections = new Map();
    for (const page of pages) {
      const key = pageKey(page);
      const pageRef = publicPageRef(page);
      if (!pageRef) { fail(page, new AppError('INVALID_PAGE_ID', '主页 ID 无效。')); continue; }
      const pageId = String(page.pageId || pageRef || '');
      const profileId = String(page.profileId || pageRef);
      const environmentId = pageEnvironmentId(page);
      const environment = environments.get(environmentId)
        || (allowSingleEnvironmentFallback && environments.size === 1 ? [...environments.values()][0] : null);
      if (!environment) { fail(page, new AppError('LINK_EXPORT_ENVIRONMENT_NOT_FOUND', `未找到浏览器环境 ${environmentId || '（空）'} 的调试连接。`)); continue; }
      const resolvedEnvironmentId = String(environment.environmentId);
      if (!connections.has(resolvedEnvironmentId)) {
        try { connections.set(resolvedEnvironmentId, { status: 'ready', ...(await connectEnvironment(environment, connector)) }); }
        catch (error) { connections.set(resolvedEnvironmentId, { status: 'failed', error }); }
      }
      const connection = connections.get(resolvedEnvironmentId);
      if (connection.status !== 'ready') { fail(page, connection.error); continue; }
      try {
        const links = await extractPageLinks(connection, page);
        const duplicate = rememberLinkSet(usedLinkSets, links);
        if (duplicate.duplicate) {
          throw new AppError('LINK_EXPORT_DUPLICATE_SET', '疑似未加载到本主页内容：提取结果与已处理主页的链接集合完全相同。');
        }
        for (const link of links) rows.push({ pageId, profileId, pageName: page.pageName, link, environmentId: resolvedEnvironmentId });
        pageResults.push({ pageName: String(page.pageName || ''), profileId, links: [...links] });
      } catch (error) { fail(page, error); }
      processed.add(key);
    }
  } catch (error) {
    const reason = describeError(error);
    let remaining = 0;
    for (const page of pages) if (fail(page, error, { notify: false })) remaining += 1;
    onProgress({
      stage: `视频链接提取失败：${reason}${remaining ? `（${remaining} 个主页未完成）` : ''}`,
      error: { code: error?.code || 'LINK_EXPORT_FAILED', message: reason },
    });
  }
  return { rows, failures, pages: pageResults };
}

function buildReport(run, rows, failures, generatedAt) {
  const lines = [
    '报告类型\t视频链接提取',
    ...(Array.isArray(run?.materialGroups) && run.materialGroups.length ? ['发布模式\t按文件夹独立任务'] : []),
    `Run ID\t${cell(run?.id)}`,
    `生成时间\t${generatedAt.toISOString()}`,
    `链接总数\t${rows.length}`,
    '',
    '主页ID\t主页名称\t视频链接',
    ...rows.map(row => [row.pageId, row.pageName, row.link].map(cell).join('\t')),
  ];
  if (failures.length) {
    lines.push('', '提取失败的主页', '主页ID\t主页名称\t原因',
      ...failures.map(item => [item.pageId, item.pageName, item.reason].map(cell).join('\t')));
  }
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

async function availableTarget(folder, stamp) {
  for (let index = 1; index <= 100; index += 1) {
    const name = index === 1 ? `视频链接-${stamp}.txt` : `视频链接-${stamp}-${index}.txt`;
    const target = path.join(folder, name);
    try {
      await fs.access(target);
    } catch {
      return target;
    }
  }
  throw new AppError('LINK_EXPORT_FILE_EXISTS', '无法生成不重复的视频链接报告文件名。');
}

async function writeReport(folder, run, rows, failures, generatedAt) {
  await fs.mkdir(folder, { recursive: true });
  const runDate = new Date(run?.createdAt);
  const target = await availableTarget(folder, localStamp(Number.isNaN(runDate.getTime()) ? generatedAt : runDate));
  const temporary = `${target}.tmp`;
  await fs.writeFile(temporary, buildReport(run, rows, failures, generatedAt), 'utf8');
  await fs.rename(temporary, target);
  return target;
}

export async function exportReelLinks(store, run, linkExport, {
  onProgress = () => {},
  discoverEnvironments = discoverHubstudio,
  connector = (...args) => chromium.connectOverCDP(...args),
} = {}) {
  const folder = typeof linkExport?.folder === 'string' && linkExport.folder.trim()
    ? path.resolve(linkExport.folder.trim())
    : null;
  if (!linkExport?.enabled || !folder) return { file: null, exported: 0, failed: 0, failures: [] };

  const successful = [];
  const seen = new Set();
  for (const page of run?.pages || []) {
    if (!submitted(page) || seen.has(pageKey(page))) continue;
    seen.add(pageKey(page));
    successful.push(page);
  }

  const extracted = await extractLinksForPages(successful, { onProgress, discoverEnvironments, connector });
  const rows = extracted.rows;
  const failures = extracted.failures.map(item => ({ pageId: item.pageId, pageName: item.pageName, reason: item.reason }));

  try {
    const generatedAt = new Date();
    const file = await writeReport(folder, run, rows, failures, generatedAt);
    onProgress({ stage: `已提取 ${rows.length} 条链接 → ${file}` });
    return { file, exported: rows.length, failed: failures.length, failures };
  } catch (error) {
    const reason = describeError(error);
    onProgress({ stage: `视频链接提取失败：${reason}`, error: { code: error?.code || 'LINK_EXPORT_FAILED', message: reason } });
    return { file: null, exported: 0, failed: successful.length, failures, error: reason };
  }
}

/** 把提取结果组装成 Excel 工作表。第一个表就是纯链接，方便全选复制。 */
function buildLinkWorkbookSheets({ pages, rows, failures, skipped = [], pageResults = [], generatedAt }) {
  const stampText = generatedAt instanceof Date ? generatedAt.toLocaleString("zh-CN", { hour12: false }) : String(generatedAt || "");
  const plainRows = [["视频链接", "主页名称", "主页公开ID"], ...rows.map(row => [row.link, row.pageName || "", row.profileId || ""])];
  const detailRows = [
    ["序号", "主页名称", "主页公开ID", "视频链接", "提取时间"],
    ...rows.map((row, index) => [String(index + 1), row.pageName || "", row.profileId || "", row.link, stampText]),
  ];
  const byPageRows = [["主页名称", "主页公开ID", "条数", "视频链接"]];
  for (const page of pageResults) {
    const links = page.links || [];
    for (const link of links) byPageRows.push([page.pageName || "", page.profileId || "", String(links.length), link]);
    if (!links.length) byPageRows.push([page.pageName || "", page.profileId || "", "0", "（无新增链接）"]);
  }
  const skippedRows = [["主页名称", "主页公开ID", "视频链接", "首次导出时间"]];
  for (const item of skipped) {
    const at = item.firstExportedAt ? new Date(item.firstExportedAt).toLocaleString("zh-CN", { hour12: false }) : "";
    skippedRows.push([item.pageName || "", item.profileId || "", item.link, at]);
  }
  const failureRows = [["主页名称", "主页公开ID", "原因"]];
  for (const item of failures) failureRows.push([item.pageName || "", item.profileId || "", item.reason || ""]);
  const summaryRows = [
    ["项目", "数值"],
    ["生成时间", stampText],
    ["提取主页数", String(pages.length)],
    ["新增链接数", String(rows.length)],
    ["跳过已导出", String(skipped.length)],
    ["失败主页数", String(failures.length)],
  ];

  const sheets = [
    { name: "纯链接", rows: plainRows, widths: [68, 16, 20], freezeHeader: true, autoFilter: false },
    { name: "链接明细", rows: detailRows, widths: [8, 16, 20, 68, 22], freezeHeader: true },
    { name: "分主页", rows: byPageRows, widths: [16, 20, 8, 68], freezeHeader: true },
  ];
  if (skipped.length) sheets.push({ name: "已跳过（旧链接）", rows: skippedRows, widths: [16, 20, 68, 22], freezeHeader: true });
  if (failures.length) sheets.push({ name: "失败主页", rows: failureRows, widths: [16, 20, 50], freezeHeader: true });
  sheets.push({ name: "统计", rows: summaryRows, widths: [18, 26], autoFilter: false });
  return sheets;
}
function buildManualReport(pages, rows, failures, generatedAt, skipped = []) {
  const lines = [
    '报告类型\t视频链接提取',
    `生成时间\t${generatedAt.toISOString()}`,
    `主页数\t${pages.length}`,
    `新增链接数\t${rows.length}`,
    `跳过已导出\t${skipped.length}`,
    `失败主页数\t${failures.length}`,
    '',
    '主页名称\t主页公开ID\t视频链接',
    ...rows.map(row => [row.pageName, row.profileId, row.link].map(cell).join('\t')),
  ];
  if (skipped.length) {
    lines.push('', '本次跳过的旧链接（此前已导出）', '主页名称\t主页公开ID\t视频链接\t首次导出时间',
      ...skipped.map(item => [item.pageName, item.profileId, item.link, item.firstExportedAt].map(cell).join('\t')));
  }
  if (failures.length) {
    lines.push('', '提取失败的主页', '主页名称\t主页公开ID\t原因',
      ...failures.map(item => [item.pageName, item.profileId, item.reason].map(cell).join('\t')));
  }
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

function buildPlainReport(rows) {
  const links = rows.map(row => row.link);
  return `\uFEFF${links.join('\r\n')}${links.length ? '\r\n' : ''}`;
}

function buildByPageReport(pageResults) {
  const lines = [];
  for (const page of pageResults) {
    lines.push(`【${cell(page.pageName)}】${page.links.length} 条`);
    for (const link of page.links) lines.push(`  ${link}`);
  }
  return `\uFEFF${lines.join('\r\n')}${lines.length ? '\r\n' : ''}`;
}

async function manualTargets(folder, stamp, reportPrefix) {
  for (let index = 1; index <= 100; index += 1) {
    const suffix = index === 1 ? '' : `-${index}`;
    const file = path.join(folder, `${reportPrefix}-${stamp}${suffix}.xlsx`);
    try {
      await fs.access(file);
    } catch {
      return { report: file, plain: file, byPage: file };
    }
  }
  throw new AppError('LINK_EXPORT_FILE_EXISTS', '无法生成不重复的链接导出文件名。');
}

export async function exportReelLinksForPages(pages, outputFolder, {
  onProgress = () => {},
  discoverEnvironments = discoverHubstudio,
  connector = (...args) => chromium.connectOverCDP(...args),
  fileNamePrefix = '视频链接',
  dataDir = null,
  skipExported = true,
  runId = null,
} = {}) {
  const folderValue = typeof outputFolder === 'string' ? outputFolder.trim() : '';
  if (!folderValue) throw new AppError('INVALID_OUTPUT_FOLDER', '请选择视频链接输出文件夹。');
  const folder = path.resolve(folderValue);
  try {
    await fs.mkdir(folder, { recursive: true });
  } catch (error) {
    throw new AppError('INVALID_OUTPUT_FOLDER', `无法创建或访问输出文件夹：${describeError(error)}`);
  }

  const uniquePages = [];
  const seen = new Set();
  for (const page of pages || []) {
    const key = pageKey(page);
    if (seen.has(key)) continue;
    seen.add(key);
    uniquePages.push(page);
  }
  if (!uniquePages.length) throw new AppError('LINK_EXPORT_NO_PAGES', '当前没有可提取的主页。请先获取 Page ID，或完成一轮发布后再试。');

  const extracted = await extractLinksForPages(uniquePages, { onProgress, discoverEnvironments, connector, allowSingleEnvironmentFallback: true });

  // 去重：跳过此前已经导出过的 reel 链接（定时发布场景下列表中会长期保留旧视频）。
  const ledger = await readExportedLedger(dataDir);
  let freshRows = extracted.rows;
  let skippedRows = [];
  if (skipExported) {
    const split = splitByLedger(extracted.rows, ledger);
    freshRows = split.kept;
    skippedRows = split.skipped;
    if (skippedRows.length) {
      onProgress({ stage: `已跳过 ${skippedRows.length} 条此前导出过的链接` });
    }
  }
  // 提取结果按主页分组时同样只保留新增链接
  const freshSet = new Set(freshRows.map(row => row.link));
  const freshPages = extracted.pages.map(page => ({
    ...page,
    links: page.links.filter(link => freshSet.has(link)),
  })).filter(page => page.links.length || extracted.pages.length <= uniquePages.length);
  const generatedAt = new Date();
  const reportPrefix = String(fileNamePrefix || '视频链接').trim() || '视频链接';
  const targets = await manualTargets(folder, localStamp(generatedAt), reportPrefix);
  // 输出为单个 Excel 工作簿：纯链接 / 明细 / 分主页 / 已跳过 四个工作表，便于直接整列复制。
  const workbookSheets = buildLinkWorkbookSheets({
    pages: uniquePages,
    rows: freshRows,
    failures: extracted.failures,
    skipped: skippedRows,
    pageResults: freshPages,
    generatedAt,
    materialRoot: null,
  });

  try {
    await writeXlsx(targets.report, workbookSheets);
  } catch (error) {
    await fs.rm(targets.report, { force: true }).catch(() => {});
    throw new AppError('LINK_EXPORT_WRITE_FAILED', `链接报告写入失败：${describeError(error)}`);
  }

  // 落盘台账：把本次新增链接记为已导出，供下次跳过。
  if (freshRows.length) {
    try {
      const nextLedger = recordLedger(ledger, freshRows, { runId, stamp: localStamp(generatedAt) });
      await writeExportedLedger(dataDir, nextLedger);
    } catch (error) {
      onProgress({ stage: `已导出链接台账写入失败（不影响报告）：${describeError(error)}` });
    }
  }

  const skippedNote = skippedRows.length ? `，跳过 ${skippedRows.length} 条旧链接` : '';
  onProgress({ stage: `已提取 ${freshRows.length} 条新链接${skippedNote} → ${targets.report}` });
  return {
    folder,
    files: targets,
    exported: freshRows.length,
    skipped: skippedRows.length,
    skippedLinks: skippedRows.map(row => ({ link: row.link, pageName: row.pageName, profileId: row.profileId, firstExportedAt: row.firstExportedAt })),
    failed: extracted.failures.length,
    failures: extracted.failures,
    pages: freshPages,
    totalFound: extracted.rows.length,
  };
}