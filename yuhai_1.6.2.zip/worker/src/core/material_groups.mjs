import { AppError } from './errors.mjs';
import { buildAssignments, listVideos, listVideosMulti, selectAvailableVideos } from './materials.mjs';
import { DEFAULT_CLIPS_PER_PAGE, normalizeClipsPerPage } from './batch_size.mjs';

function groupShortage(root, required, available) {
  return new AppError('MATERIAL_SHORTAGE_GROUP', `素材文件夹 ${root} 本轮需要 ${required} 个视频，只有 ${available} 个。`);
}

export function splitPagesByGroup(pages, roots) {
  if (!Array.isArray(roots) || !roots.length) throw new AppError('MATERIAL_GROUP_REQUIRED', '请至少添加一个素材文件夹。');
  const groups = roots.map(root => ({ root, pages: [] }));
  pages.forEach((page, index) => groups[index % groups.length].pages.push(page));
  return groups;
}

export async function pickGroupVideos({ root, videos, required, usedHashes = [], cache, onProgress = () => {} }) {
  const candidates = Array.isArray(videos) ? videos : [];
  if (candidates.length < required) throw groupShortage(root, required, candidates.length);
  const selection = await selectAvailableVideos(candidates, required, usedHashes, cache, onProgress);
  if (selection.videos.length < required) throw groupShortage(root, required, selection.videos.length);
  return selection;
}

function normalizeDirectories(directory, directories) {
  const values = (Array.isArray(directories) ? directories : [])
    .filter(item => typeof item === 'string' && item.trim())
    .map(item => item.trim());
  if (!values.length && typeof directory === 'string' && directory.trim()) values.push(directory.trim());
  if (!values.length) throw new AppError('INVALID_MATERIAL_DIRECTORY', '请选择有效的素材文件夹。');
  return values;
}

export async function selectRunMaterials({
  directory,
  directories,
  publishMode = 'merge',
  pages,
  description,
  usedHashes = [],
  cache,
  linkPool = [],
  pageCaptions = null,
  onProgress = () => {},
  clipsPerPage = DEFAULT_CLIPS_PER_PAGE,
}) {
  const clips = normalizeClipsPerPage(clipsPerPage);
  const inputs = normalizeDirectories(directory, directories);
  const mode = publishMode === 'per_folder' ? 'per_folder' : 'merge';
  if (inputs.length === 1 && mode === 'merge') {
    const material = await listVideos(inputs[0]);
    const required = pages.length * clips;
    if (material.videos.length < required) {
      throw new AppError('MATERIAL_SHORTAGE', `所选 ${pages.length} 个主页需要 ${required} 个视频，当前只有 ${material.videos.length} 个。`);
    }
    const selection = await selectAvailableVideos(material.videos, required, usedHashes, cache, onProgress);
    const assignments = await buildAssignments(selection.videos, pages, description, onProgress, linkPool, clips, pageCaptions);
    return {
      materialRoot: material.root,
      materialRoots: null,
      materialGroups: null,
      clipsPerPage: clips,
      assignments,
      pageFolders: new Map(),
      totalVideos: material.count,
    };
  }

  const material = await listVideosMulti(inputs);
  if (mode === 'merge') {
    const required = pages.length * clips;
    if (material.videos.length < required) {
      throw new AppError('MATERIAL_SHORTAGE', `所选 ${pages.length} 个主页需要 ${required} 个视频，当前只有 ${material.videos.length} 个。`);
    }
    const selection = await selectAvailableVideos(material.videos, required, usedHashes, cache, onProgress);
    const assignments = await buildAssignments(selection.videos, pages, description, onProgress, linkPool, clips, pageCaptions);
    return {
      materialRoot: material.roots.join(' | '),
      materialRoots: material.roots,
      materialGroups: null,
      clipsPerPage: clips,
      assignments,
      pageFolders: new Map(),
      totalVideos: material.total,
    };
  }

  if (pages.length < material.groups.length) {
    throw new AppError('MATERIAL_GROUP_PAGE_SHORTAGE', '每个文件夹至少要有 1 个主页。');
  }
  const pageGroups = splitPagesByGroup(pages, material.roots);
  const selectedHashes = new Set(usedHashes || []);
  const assignments = [];
  const materialGroups = [];
  const pageFolders = new Map();
  for (let index = 0; index < pageGroups.length; index += 1) {
    const pageGroup = pageGroups[index];
    const sourceGroup = material.groups[index];
    const required = pageGroup.pages.length * clips;
    const selection = await pickGroupVideos({
      root: pageGroup.root,
      videos: sourceGroup.videos,
      required,
      usedHashes: selectedHashes,
      cache,
      onProgress,
    });
    const groupAssignments = await buildAssignments(selection.videos, pageGroup.pages, description, onProgress, linkPool, clips, pageCaptions);
    for (const video of selection.videos) selectedHashes.add(video.sha256);
    for (const page of pageGroup.pages) pageFolders.set(String(page.pageId), pageGroup.root);
    assignments.push(...groupAssignments);
    materialGroups.push({ root: pageGroup.root, pageIds: pageGroup.pages.map(page => page.pageId), videoCount: groupAssignments.length });
  }
  return {
    materialRoot: material.roots.join(' | '),
    materialRoots: material.roots,
    materialGroups,
    clipsPerPage: clips,
    assignments,
    pageFolders,
    totalVideos: material.total,
  };
}