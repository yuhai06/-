import { chromium } from '../vendor/playwright-core/index.mjs';
import { AppError } from './errors.mjs';
import { BLOCKED_TEXT, META_LABELS } from '../skill-runtime/meta_locale.mjs';

const LIST_URL = 'https://www.facebook.com/pages/?category=your_pages';
const FACEBOOK_HOSTS = new Set(['facebook.com', 'www.facebook.com', 'business.facebook.com']);
const connections = new Map();

export function isBlockedPageText(text) { return BLOCKED_TEXT.test(String(text || '')); }

export function assignFixedBindings(pages, existing = {}) {
  const bindings = { ...existing };
  for (const page of pages) {
    if (bindings[page.pageId]) continue;
    const first = [...page.environments].sort((a, b) => a.environmentId.localeCompare(b.environmentId))[0];
    if (first) bindings[page.pageId] = first.environmentId;
  }
  return bindings;
}

function isFacebookPage(page) {
  try { return FACEBOOK_HOSTS.has(new URL(page.url()).hostname); } catch { return false; }
}

function isManagedList(page) {
  try {
    const url = new URL(page.url());
    return url.hostname === 'www.facebook.com' && /^\/pages\/?$/.test(url.pathname) && url.searchParams.get('category') === 'your_pages';
  } catch { return false; }
}

function assertSelectable(page) {
  const url = new URL(page.url());
  if (/\/(?:checkpoint|login|two_step_verification)(?:\/|\.|$)/i.test(url.pathname) || url.pathname.startsWith('/business/loginpage')) {
    throw new AppError('CHECKPOINT_REQUIRED', '当前环境处于登录或身份验证页面，已停止该环境。');
  }
  if (url.hostname === 'business.facebook.com' && url.pathname.startsWith('/latest/bulk_upload_composer')) {
    throw new AppError('WORK_TAB_BUSY', '当前 Meta 标签停留在批量上传编辑器，不能覆盖已有编辑现场。');
  }
  return page;
}

export function chooseExistingPage(pages) {
  const exact = pages.filter(page => !page.isClosed() && isManagedList(page));
  if (exact.length === 1) return assertSelectable(exact[0]);
  if (exact.length > 1) throw new AppError('AMBIGUOUS_WORK_TAB', '当前环境有多个“你管理的公共主页”标签，无法确定应复用哪一个。');
  const candidates = pages.filter(page => !page.isClosed() && isFacebookPage(page));
  const suite = candidates.filter(page => { try { return new URL(page.url()).hostname === 'business.facebook.com'; } catch { return false; } });
  if (suite.length === 1) return assertSelectable(suite[0]);
  if (candidates.length === 1) return assertSelectable(candidates[0]);
  throw new AppError('META_TAB_REQUIRED', candidates.length ? '当前环境有多个 Facebook/Meta 标签，无法安全选择。' : '当前环境没有已打开的 Facebook 或 Meta 工作标签。');
}

export function chooseExistingMetaWorkPage(pages) {
  const candidates = pages.filter(page => {
    if (page.isClosed()) return false;
    try {
      const url = new URL(page.url());
      return url.hostname === 'business.facebook.com' && url.pathname.startsWith('/latest/');
    } catch { return false; }
  });
  if (candidates.length === 1) return assertSelectable(candidates[0]);
  if (candidates.length > 1) throw new AppError('AMBIGUOUS_WORK_TAB', '当前环境有多个 Meta Business Suite 工作标签，无法安全选择。');
  throw new AppError('META_TAB_REQUIRED', '当前环境没有已打开的 Meta Business Suite 工作标签。');
}

async function targetId(context, page) {
  const session = await context.newCDPSession(page);
  try { return (await session.send('Target.getTargetInfo')).targetInfo.targetId; }
  finally { await session.detach(); }
}

async function assertNoPageRisk(page) {
  const state = await page.evaluate(pattern => ({
    blocked: new RegExp(pattern.source, pattern.flags).test(document.body?.innerText || '')
      || /\/(?:checkpoint|login|two_step_verification)(?:\/|\.|$)/i.test(location.pathname),
  }), { source: BLOCKED_TEXT.source, flags: BLOCKED_TEXT.flags });
  if (state.blocked) throw new AppError('CHECKPOINT_REQUIRED', '当前浏览器出现登录、验证或账号状态通知，已停止使用。');
}

export async function inspectExistingMetaTabs(environments, { connector = (...args) => chromium.connectOverCDP(...args) } = {}) {
  const results = [];
  for (const environment of environments) {
    try {
      const attached = await connect(environment, connector);
      const page = chooseExistingMetaWorkPage(attached.context.pages());
      await assertNoPageRisk(page);
      const url = new URL(page.url());
      const observedAssetId = url.searchParams.get('asset_id') || url.searchParams.get('page_id');
      results.push({
        environmentId: environment.environmentId,
        environmentName: environment.environmentName,
        targetId: await targetId(attached.context, page),
        observedAssetId: /^\d+$/.test(observedAssetId || '') ? observedAssetId : null,
        status: 'ready',
      });
    } catch (error) {
      results.push({ environmentId: environment.environmentId, environmentName: environment.environmentName, status: 'failed', error: error.message, code: error.code || 'BROWSER_CHECK_FAILED' });
    }
  }
  return { results };
}

async function pageState(page) {
  return page.evaluate(pattern => {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== 'hidden';
    };
    const body = document.body?.innerText || '';
    const blocked = new RegExp(pattern.source, pattern.flags).test(body)
      || /\/(?:checkpoint|login|two_step_verification)(?:\/|\.|$)/i.test(location.pathname);
    const main = document.querySelector('main,[role="main"]');
    const hasProfileLinks = Boolean(main?.querySelector('a[href*="profile.php?id="],a[href*="profile.php?"][href*="&id="]'));
    const ready = Boolean(main && (hasProfileLinks || new RegExp(pattern.managed, 'i').test(main.innerText || '')));
    const more = main ? [...main.querySelectorAll('button,[role="button"],a')].filter(visible).find(element =>
      new RegExp(pattern.more, 'i').test((element.innerText || element.getAttribute('aria-label') || '').trim())) : null;
    return { blocked, ready, hasMore: Boolean(more), loading: Boolean(main?.querySelector('[aria-busy="true"],[role="progressbar"]')) };
  }, { source: BLOCKED_TEXT.source, flags: BLOCKED_TEXT.flags, managed: META_LABELS.managedPages.source.replace(/^\^|\$$/g, ''), more: META_LABELS.loadMore.source });
}

async function uniqueProfileCount(page) {
  return page.evaluate(() => {
    const main = document.querySelector('main,[role="main"]');
    if (!main) return 0;
    const ids = [...main.querySelectorAll('a[href*="profile.php"]')].flatMap(anchor => {
      try {
        const id = new URL(anchor.href, location.href).searchParams.get('id');
        return /^\d+$/.test(id || '') ? [id] : [];
      } catch { return []; }
    });
    return new Set(ids).size;
  });
}

async function loadManagedPages(page) {
  if (!isManagedList(page)) await page.goto(LIST_URL, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(2000);
  for (let click = 0; click < 50; click += 1) {
    const state = await pageState(page);
    if (state.blocked) throw new AppError('CHECKPOINT_REQUIRED', '该环境出现登录、验证码、身份验证或账号状态通知，已停止读取。');
    if (!state.ready) throw new AppError('MANAGED_PAGES_UNAVAILABLE', '没有打开“你管理的公共主页”列表。');
    if (!state.hasMore) break;
    const before = await uniqueProfileCount(page);
    const clicked = await page.evaluate(morePattern => {
      const main = document.querySelector('main,[role="main"]');
      if (!main) return 0;
      const matches = [...main.querySelectorAll('button,[role="button"],a')].filter(element => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        const label = (element.innerText || element.getAttribute('aria-label') || '').trim();
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && new RegExp(morePattern, 'i').test(label);
      });
      if (matches.length === 1) matches[0].click();
      return matches.length;
    }, META_LABELS.loadMore.source);
    if (clicked !== 1) throw new AppError('LOAD_MORE_AMBIGUOUS', '“加载更多”控件不唯一，已停止该环境。');
    let progressed = false;
    for (let wait = 0; wait < 60; wait += 1) {
      await page.waitForTimeout(500);
      const current = await pageState(page);
      if (current.blocked) throw new AppError('CHECKPOINT_REQUIRED', '加载主页时出现登录、验证码、身份验证或账号状态通知。');
      const after = await uniqueProfileCount(page);
      if (after > before || !current.hasMore && !current.loading) { progressed = true; break; }
    }
    if (!progressed) throw new AppError('LOAD_MORE_STALLED', '公共主页列表未继续增加，已停止该环境。');
    await page.waitForTimeout(2000);
    if (click === 49 && (await pageState(page)).hasMore) throw new AppError('LOAD_MORE_LIMIT', '公共主页超过单次安全加载上限，已停止该环境。');
  }
}

async function extractRows(page) {
  return page.evaluate(() => {
    const visible = element => {
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== 'hidden';
    };
    const main = document.querySelector('main,[role="main"]');
    if (!main) return [];
    const param = (anchor, name) => { try { return new URL(anchor.href, location.href).searchParams.get(name); } catch { return null; } };
    const rows = [];
    for (const anchor of main.querySelectorAll('a[href*="profile.php"]')) {
      if (!visible(anchor)) continue;
      const profileId = param(anchor, 'id');
      const pageName = (anchor.innerText || '').trim();
      if (!/^\d+$/.test(profileId || '') || !pageName) continue;
      let ids = [];
      for (let node = anchor.parentElement, depth = 0; node && depth < 12; node = node.parentElement, depth += 1) {
        const profiles = new Set([...node.querySelectorAll('a[href*="profile.php"]')].map(item => param(item, 'id')).filter(Boolean));
        if (profiles.size > 1) break;
        ids = [...new Set([...node.querySelectorAll('a[href]')].flatMap(item => [param(item, 'asset_id'), param(item, 'page_id')]).filter(id => /^\d+$/.test(id || '')))];
        if (ids.length) break;
      }
      if (ids.length === 1) rows.push({ pageId: ids[0], profileId, pageName });
    }
    return rows;
  });
}

async function connect(environment, connector) {
  const cached = connections.get(environment.endpoint);
  if (cached?.browser?.isConnected?.()) return cached;
  const browser = await connector(environment.endpoint, { timeout: 15000, noDefaults: true });
  const contexts = browser.contexts();
  if (contexts.length !== 1) throw new AppError('UNSUPPORTED_CONTEXT', '该环境没有唯一的浏览器上下文。');
  const attached = { browser, context: contexts[0] };
  connections.set(environment.endpoint, attached);
  return attached;
}

export async function discoverManagedPages(environments, { connector = (...args) => chromium.connectOverCDP(...args), onProgress = () => {} } = {}) {
  const results = [];
  for (const environment of environments) {
    onProgress({ stage: '正在检查可用浏览器', environmentId: environment.environmentId });
    let browser;
    try {
      const attached = await connect(environment, connector); browser = attached.browser;
      const page = chooseExistingPage(attached.context.pages());
      await loadManagedPages(page);
      const first = await extractRows(page);
      await page.waitForTimeout(2000);
      const second = await extractRows(page);
      const signature = rows => JSON.stringify(rows.map(row => [row.pageId, row.profileId, row.pageName]).sort());
      if (signature(first) !== signature(second)) throw new AppError('PAGE_LIST_UNSTABLE', '公共主页列表仍在变化，请稍后刷新。');
      const unique = new Map();
      for (const row of second) if (!unique.has(row.pageId)) unique.set(row.pageId, row);
      results.push({ environmentId: environment.environmentId, environmentName: environment.environmentName, targetId: await targetId(attached.context, page), status: 'ready', pages: [...unique.values()] });
    } catch (error) {
      results.push({ environmentId: environment.environmentId, environmentName: environment.environmentName, status: 'failed', pages: [], error: error.message, code: error.code || 'DISCOVERY_FAILED' });
    } finally { browser = null; }
  }
  const variants = new Map();
  for (const result of results) for (const page of result.pages) {
    if (!variants.has(page.pageId)) variants.set(page.pageId, []);
    variants.get(page.pageId).push({ ...page, environmentId: result.environmentId, environmentName: result.environmentName, targetId: result.targetId });
  }
  return { results, pages: [...variants.entries()].map(([pageId, entries]) => ({
    pageId,
    pageName: entries[0].pageName,
    profileId: entries[0].profileId,
    environments: entries.map(item => ({ environmentId: item.environmentId, environmentName: item.environmentName, targetId: item.targetId })),
    conflict: entries.length > 1,
  })) };
}

export async function attachForPublication(environment, targetIdValue, { connector = (...args) => chromium.connectOverCDP(...args) } = {}) {
  const attached = await connect(environment, connector);
  for (const page of attached.context.pages()) {
    if (page.isClosed()) continue;
    if (await targetId(attached.context, page) === targetIdValue) return { ...attached, page };
  }
  throw new AppError('WORK_TAB_CHANGED', '自动发现后工作标签已改变，请刷新主页列表。');
}
