import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { AppError } from './errors.mjs';

const execFileAsync = promisify(execFile);
const STATUS_URL = 'http://127.0.0.1:6873/api/v1/browser/all-browser-status';
const FOREGROUND_URL = 'http://127.0.0.1:6873/api/v1/browser/foreground';

function validId(value) { return typeof value === 'string' && /^\d+$/.test(value); }

export function parseStatusResponse(payload) {
  if (!payload || payload.code !== 0 || !Array.isArray(payload.data?.containers)) {
    throw new AppError('HUBSTUDIO_STATUS_FAILED', payload?.msg || 'HubStudio 没有返回可用的环境状态。');
  }
  const seen = new Set();
  return payload.data.containers.flatMap(item => {
    const environmentId = String(item?.containerCode || '');
    const pid = Number(item?.pid);
    if (Number(item?.status) !== 0 || !validId(environmentId) || !Number.isInteger(pid) || pid <= 0 || seen.has(environmentId)) return [];
    seen.add(environmentId);
    return [{ environmentId, pid, environmentName: String(item?.containerName || item?.name || environmentId) }];
  });
}

async function statusRequest(fetchImpl) {
  let response;
  try {
    response = await fetchImpl(STATUS_URL, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}', redirect: 'error', signal: AbortSignal.timeout(10000) });
  } catch {
    throw new AppError('HUBSTUDIO_UNAVAILABLE', '无法连接 HubStudio。本程序只读取已经打开的环境，请先启动 HubStudio 和所需浏览器。');
  }
  if (!response.ok) throw new AppError('HUBSTUDIO_STATUS_FAILED', `HubStudio 状态接口返回 HTTP ${response.status}。`);
  return parseStatusResponse(await response.json());
}

export async function foregroundEnvironment(environmentId, { fetchImpl = fetch } = {}) {
  if (!validId(environmentId)) throw new AppError('INVALID_ENVIRONMENT_ID', '浏览器 ID 无效，无法切换窗口。');
  const environments = await statusRequest(fetchImpl);
  const environment = environments.find(item => item.environmentId === environmentId);
  if (!environment) throw new AppError('ENVIRONMENT_NOT_OPEN', `浏览器 ${environmentId} 未打开，请先在 HubStudio 中打开；切换不会启动环境。`);
  let response;
  try {
    response = await fetchImpl(FOREGROUND_URL, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ containerCode: environmentId }), redirect: 'error', signal: AbortSignal.timeout(10000),
    });
  } catch {
    throw new AppError('HUBSTUDIO_FOREGROUND_FAILED', `无法确认浏览器 ${environmentId} 的切换结果：HubStudio 连接失败或超时，请查看窗口后重试。`);
  }
  if (!response.ok) throw new AppError('HUBSTUDIO_FOREGROUND_FAILED', `HubStudio 切换接口返回 HTTP ${response.status}。`);
  let result;
  try { result = await response.json(); }
  catch { throw new AppError('HUBSTUDIO_FOREGROUND_FAILED', 'HubStudio 切换接口返回格式异常，无法确认是否成功。'); }
  if (result?.code !== 0 || ![0, '0'].includes(result.data?.statusCode) || result.data?.action !== 'ForegroundBrowser') {
    const reason = result?.code === 0 ? result.data?.err : result?.msg;
    throw new AppError('HUBSTUDIO_FOREGROUND_FAILED', `浏览器 ${environmentId} 切换失败：${String(reason || 'HubStudio 未确认窗口切换成功').slice(0, 300)}`);
  }
  return { environmentId, environmentName: environment.environmentName, pid: environment.pid };
}

async function listenersByPid(pids) {
  if (process.platform !== 'win32') throw new AppError('UNSUPPORTED_OS', '当前版本仅支持 Windows。');
  const pidList = pids.join(',');
  const script = `$ErrorActionPreference='Stop'; $wanted=@(${pidList}); $rows=@(Get-NetTCPConnection -State Listen | Where-Object { $wanted -contains [int]$_.OwningProcess -and @('127.0.0.1','0.0.0.0','::1','::') -contains $_.LocalAddress } | ForEach-Object { [pscustomobject]@{ pid=[int]$_.OwningProcess; port=[int]$_.LocalPort } }); ConvertTo-Json -InputObject $rows -Compress`;
  const { stdout } = await execFileAsync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {
    windowsHide: true, timeout: 20000, maxBuffer: 256 * 1024, encoding: 'utf8',
  });
  const parsed = JSON.parse(stdout.trim() || '[]');
  return Array.isArray(parsed) ? parsed : [parsed];
}

export async function discoverHubstudio({ fetchImpl = fetch, listenerReader = listenersByPid } = {}) {
  const environments = await statusRequest(fetchImpl);
  if (!environments.length) throw new AppError('NO_OPEN_ENVIRONMENTS', 'HubStudio 当前没有已打开的浏览器环境。');
  const listeners = await listenerReader(environments.map(item => item.pid));
  const usedPorts = new Set();
  const resolved = [];
  const failed = [];
  for (const environment of environments) {
    const ports = [...new Set(listeners.filter(row => Number(row.pid) === environment.pid).map(row => Number(row.port)).filter(Number.isInteger))];
    const endpoints = [];
    for (const port of ports.slice(0, 32)) {
      try {
        const response = await fetchImpl(`http://127.0.0.1:${port}/json/version`, { redirect: 'error', signal: AbortSignal.timeout(2500) });
        if (!response.ok) continue;
        const metadata = await response.json();
        const websocket = new URL(metadata.webSocketDebuggerUrl);
        if (websocket.protocol !== 'ws:' || websocket.hostname !== '127.0.0.1' || websocket.port !== String(port) || !/chrom(?:e|ium)/i.test(metadata.Browser || '')) continue;
        endpoints.push(websocket.href);
      } catch { /* The process may own unrelated local listeners. */ }
    }
    const unique = [...new Set(endpoints)];
    if (unique.length !== 1 || usedPorts.has(new URL(unique[0] || 'http://127.0.0.1').port)) {
      failed.push({ ...environment, reason: unique.length ? '调试端口重复' : '没有找到唯一的浏览器连接端口' });
      continue;
    }
    usedPorts.add(new URL(unique[0]).port);
    resolved.push({ ...environment, endpoint: unique[0] });
  }
  return { environments: resolved, failed, discoveredAt: new Date().toISOString() };
}
