import fs from 'node:fs/promises';
import path from 'node:path';

const EMPTY = { bindings: {}, plan: null, browserCheck: null, discovery: null, currentRun: null, history: [], usedHashes: [] };
const WINDOWS_REPLACE_RETRY_DELAYS = [50, 150, 500, 1_500, 3_000];

function historySignature(history) {
  return JSON.stringify((history || []).map(run => [
    run.id || null,
    run.state || null,
    run.archivedAt || null,
    run.supersededAt || null,
    run.pages?.length || 0,
    run.assignments?.length || 0,
  ]));
}

async function replaceStateFile(temporary, file, wait = ms => new Promise(resolve => setTimeout(resolve, ms))) {
  for (let attempt = 0; ; attempt += 1) {
    try {
      await fs.rename(temporary, file);
      return;
    } catch (error) {
      const retryable = process.platform === 'win32' && ['EPERM', 'EACCES', 'EBUSY'].includes(error.code);
      if (!retryable || attempt >= WINDOWS_REPLACE_RETRY_DELAYS.length) throw error;
      await wait(WINDOWS_REPLACE_RETRY_DELAYS[attempt]);
    }
  }
}

export class StateStore {
  constructor(dataDir) {
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'state.json');
    this.historyFile = path.join(dataDir, 'history.json');
    this.value = structuredClone(EMPTY);
    this.persistedHistorySignature = null;
    this.queue = Promise.resolve();
    this.persistTimer = null;
  }

  async load() {
    await fs.mkdir(this.dataDir, { recursive: true });
    try {
      const saved = JSON.parse(await fs.readFile(this.file, 'utf8'));
      let history = saved.history || [];
      try {
        const archived = JSON.parse(await fs.readFile(this.historyFile, 'utf8'));
        if (Array.isArray(archived)) history = archived;
        this.persistedHistorySignature = historySignature(history);
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
        // A legacy state.json is migrated on the next write.
        this.persistedHistorySignature = null;
      }
      delete saved.history;
      this.value = { ...structuredClone(EMPTY), ...saved, bindings: saved.bindings || {}, history, usedHashes: saved.usedHashes || [] };
      delete this.value.browserTargets;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    return this.snapshot();
  }

  snapshot() { return structuredClone(this.value); }

  project(projector) { return structuredClone(projector(this.value)); }

  async update(change) {
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    const operation = this.queue.catch(() => {}).then(async () => {
      const next = typeof change === 'function' ? change(this.snapshot()) : { ...this.value, ...change };
      this.value = next;
      await this.write(next);
      return this.snapshot();
    });
    this.queue = operation.catch(() => {});
    return operation;
  }

  async write(next) {
    const temporary = `${this.file}.tmp`;
    const { history = [], ...active } = next;
    await fs.writeFile(temporary, `${JSON.stringify(active)}\n`, 'utf8');
    await replaceStateFile(temporary, this.file);
    const signature = historySignature(history);
    if (signature !== this.persistedHistorySignature) {
      const historyTemporary = `${this.historyFile}.tmp`;
      await fs.writeFile(historyTemporary, `${JSON.stringify(history)}\n`, 'utf8');
      await replaceStateFile(historyTemporary, this.historyFile);
      this.persistedHistorySignature = signature;
    }
  }

  async updateCurrentRun(change) {
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    const operation = this.queue.catch(() => {}).then(async () => {
      const currentRun = change(structuredClone(this.value.currentRun));
      this.value = { ...this.value, currentRun };
      await this.write(this.value);
      return structuredClone(currentRun);
    });
    this.queue = operation.catch(() => {});
    return operation;
  }

  // High-frequency progress updates should not rewrite the complete state file.
  // Critical transitions continue to use update() and are persisted immediately.
  schedule(change, delay = 800) {
    this.value = typeof change === 'function' ? change(this.value) : { ...this.value, ...change };
    if (this.persistTimer) clearTimeout(this.persistTimer);
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      const operation = this.queue.catch(() => {}).then(() => this.write(this.value));
      this.queue = operation.catch(() => {});
    }, delay);
  }

  async flushScheduled() {
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
      const operation = this.queue.catch(() => {}).then(() => this.write(this.value));
      this.queue = operation.catch(() => {});
      await operation;
    }
    await this.queue;
    return this.snapshot();
  }
}
