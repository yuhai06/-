function replacementSources(history) {
  const sources = new Set();
  for (const run of [...(history || [])].reverse()) {
    for (const page of run.pages || []) {
      if (!['completed', 'cleanup_failed'].includes(page.state)) sources.add(page.environmentId);
    }
  }
  return [...sources];
}

export function projectUiRun(run) {
  if (!run) return null;
  const {
    assignments,
    delayHistory,
    recoveryHistory,
    ...summary
  } = run;
  return {
    ...summary,
    assignmentCount: assignments?.length || 0,
    delayCount: delayHistory?.length || 0,
    recoveryCount: recoveryHistory?.length || 0,
  };
}

export function projectUiState(state) {
  const historyCount = state.history?.length || 0;
  const hasStoredRecords = Boolean(
    state.currentRun
    || historyCount
    || state.plan
    || state.discovery
    || state.browserCheck
    || state.pageDiscovery
    || Object.keys(state.bindings || {}).length
    || state.usedHashes?.length
  );
  return {
    pageDiscovery: state.pageDiscovery || null,
    plan: state.plan || null,
    browserCheck: state.browserCheck || null,
    discovery: state.discovery || null,
    currentRun: projectUiRun(state.currentRun),
    historyCount,
    hasStoredRecords,
    replacementSources: replacementSources(state.history),
  };
}
