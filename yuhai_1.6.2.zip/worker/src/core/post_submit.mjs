import { ACCEPTANCE_RECEIPT, BLOCKED_TEXT, BULK_PROCESSING, CONTENT_FAILURE, SUBMIT_FAILURE, metaButton } from '../skill-runtime/meta_locale.mjs';

// A Publish click is not permission to discard an in-flight composer. Leave
// only after the platform receipt / completed bulk-upload dialog is visible.
export async function finishSubmittedPage(page, { assetId, shouldStop = () => false, timeoutMs = 60000 } = {}) {
  const home = new URL('https://business.facebook.com/latest/home/');
  home.searchParams.set('asset_id', assetId);
  const until = Date.now() + timeoutMs;
  do {
    if (shouldStop()) return { status: 'stopped', message: '用户已停止，保留当前页面。' };
    const current = new URL(page.url());
    if (current.hostname !== 'business.facebook.com') return { status: 'pending', message: '当前不在 Meta 工作页面，未自动跳转。' };
    const body = await page.locator('body').innerText();
    if (BLOCKED_TEXT.test(body) || /\/(?:checkpoint|login)(?:\/|\.|$)/.test(current.pathname)) return { status: 'pending', message: '当前页面需要验证或登录，未自动跳转。' };
    if (SUBMIT_FAILURE.test(body) || CONTENT_FAILURE.test(body)) return { status: 'pending', message: 'Meta 显示发布异常，保留现场供复核。' };
    if (current.searchParams.has('asset_id') && current.searchParams.get('asset_id') !== String(assetId)) return { status: 'pending', message: '当前主页已改变，未自动跳转。' };
    if (!current.pathname.startsWith('/latest/bulk_upload_composer')) {
      await page.goto(home.href, { waitUntil: 'domcontentloaded', timeout: 30000 });
      return { status: 'home' };
    }
    if (current.searchParams.get('asset_id') !== String(assetId)) return { status: 'pending', message: '当前主页已改变，未自动跳转。' };
    const dialogs = page.getByRole('dialog').and(page.locator(':visible'));
    const done = metaButton(dialogs, '完成');
    const receipt = ACCEPTANCE_RECEIPT.test(body);
    if (receipt || BULK_PROCESSING.test(body) && await done.count() === 1) {
      const count = await done.count();
      if (count > 1) return { status: 'pending', message: '提交完成按钮不唯一，保留现场供复核。' };
      if (count === 1) await done.click({ timeout: 5000 });
      await page.goto(home.href, { waitUntil: 'domcontentloaded', timeout: 30000 });
      return { status: 'home', platformReceipt: receipt };
    }
    if (Date.now() >= until) break;
    await page.waitForTimeout(500);
  } while (true);
  return { status: 'pending', message: '60 秒内未看到平台提交完成提示，保留页面，不覆盖处理中的任务。' };
}
