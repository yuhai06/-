export class AppError extends Error {
  constructor(code, message, details = null) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.details = details;
  }
}

export function publicError(error) {
  return { code: error?.code || 'APP_ERROR', message: error?.message || String(error || '操作失败。') };
}
