import fs from 'node:fs/promises';

export async function captureCurrentView(page, file) {
  try {
    await page.screenshot({ path: file, fullPage: false, animations: 'disabled', timeout: 5000 });
    return file;
  } catch (primaryError) {
    let session;
    try {
      session = await page.context().newCDPSession(page);
      const result = await session.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
      await fs.writeFile(file, Buffer.from(result.data, 'base64'));
      return file;
    } catch (fallbackError) {
      const error = new Error(`截图失败：${primaryError.message}; CDP 兜底失败：${fallbackError.message}`);
      error.cause = fallbackError;
      throw error;
    } finally {
      await session?.detach().catch(() => {});
    }
  }
}
