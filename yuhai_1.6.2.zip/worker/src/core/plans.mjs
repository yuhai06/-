import { AppError } from './errors.mjs';

function numeric(value) { return /^\d+$/.test(String(value || '')); }

export function assertCompleteDiscovery(discovery) {
  const results = new Map((discovery.results || []).map(result => [String(result.environmentId), result]));
  const failures = [];
  for (const environment of discovery.environments || []) {
    const environmentId = String(environment.environmentId);
    const result = results.get(environmentId);
    if (!result) failures.push({ environmentId, reason: '没有返回 Page ID 获取结果' });
    else if (result.status !== 'ready') failures.push({ environmentId, reason: result.error || result.code || 'Page ID 获取失败' });
    else if (!Array.isArray(result.pages) || result.pages.length === 0) failures.push({ environmentId, reason: '没有获取到任何公共主页' });
  }
  for (const failure of discovery.failedEnvironments || []) {
    const environmentId = String(failure.environmentId || '未知环境');
    if (!failures.some(item => item.environmentId === environmentId)) {
      failures.push({ environmentId, reason: failure.error || failure.code || 'Page ID 获取失败' });
    }
  }
  if (failures.length) {
    const detail = failures.map(item => `${item.environmentId}：${item.reason}`).join('；');
    const error = new AppError('PAGE_DISCOVERY_INCOMPLETE', `Page ID 获取不完整，未生成任务队列。${detail}`);
    error.failures = failures;
    throw error;
  }
  return true;
}

export function buildBalancedPlan({ discovery, openEnvironmentIds, mappingRows, overrides = [] }) {
  const environments = [...new Set(openEnvironmentIds.map(String))];
  const open = new Set(environments);
  const load = new Map(environments.map(environmentId => [environmentId, 0]));
  const pageById = new Map((discovery.pages || []).map(page => [String(page.pageId), page]));
  const busy = new Set((discovery.results || [])
    .filter(result => result.status === 'failed' && result.code === 'WORK_TAB_BUSY')
    .map(result => String(result.environmentId)));
  const overrideByPage = new Map(overrides.map(item => [String(item.pageId), { ...item, environmentId: String(item.environmentId), pageId: String(item.pageId) }]));
  const grouped = new Map();
  for (const row of mappingRows) {
    const environmentId = String(row.environmentId);
    const pageId = String(row.pageId);
    if (!open.has(environmentId)) continue;
    if (!grouped.has(pageId)) grouped.set(pageId, []);
    grouped.get(pageId).push({ ...row, environmentId, pageId });
  }
  for (const page of discovery.pages || []) {
    const pageId = String(page.pageId);
    if (page.environments?.some(item => open.has(String(item.environmentId))) && !grouped.has(pageId)) grouped.set(pageId, []);
  }
  for (const override of overrideByPage.values()) if (!grouped.has(override.pageId)) grouped.set(override.pageId, []);

  const tasks = [...grouped.entries()].map(([pageId, rows]) => {
    const override = overrideByPage.get(pageId);
    if (override && (!open.has(override.environmentId) || !numeric(override.pageId) || !override.pageName)) {
      throw new AppError('INVALID_PLAN_OVERRIDE', `公共主页 ${pageId} 的计划覆盖项无效。`);
    }
    const live = pageById.get(pageId);
    const liveCandidates = (live?.environments || []).map(item => String(item.environmentId)).filter(environmentId => open.has(environmentId));
    const busyCandidates = rows.map(row => row.environmentId).filter(environmentId => busy.has(environmentId));
    const candidates = [...new Set([...liveCandidates, ...busyCandidates, ...(override ? [override.environmentId] : [])])];
    if (!candidates.length) throw new AppError('PLAN_CANDIDATE_MISSING', `公共主页 ${pageId} 没有当前可用的授权环境。`);
    return { pageId, rows, override, live, candidates };
  }).sort((left, right) => left.candidates.length - right.candidates.length || left.pageId.localeCompare(right.pageId));

  const assignments = [];
  for (const task of tasks) {
    const mapped = new Set(task.rows.map(row => row.environmentId));
    const environmentId = [...task.candidates].sort((left, right) =>
      load.get(left) - load.get(right)
      || Number(!mapped.has(left)) - Number(!mapped.has(right))
      || left.localeCompare(right))[0];
    load.set(environmentId, load.get(environmentId) + 1);
    const mappedRow = task.rows.find(row => row.environmentId === environmentId) || task.rows[0];
    const override = task.override?.environmentId === environmentId ? task.override : null;
    assignments.push({
      environmentId,
      pageId: task.pageId,
      pageName: override?.pageName || task.live?.pageName || mappedRow?.pageName,
      profileId: override?.profileId || task.live?.profileId || null,
      evidence: override?.evidence || (task.live?.environments?.some(item => String(item.environmentId) === environmentId) ? 'live_discovery' : 'mapping_busy_environment'),
      authorizedEnvironmentCount: task.candidates.length,
    });
  }

  return {
    version: 1,
    createdAt: new Date().toISOString(),
    strategy: 'all_discovered_pages_deduplicated_balanced',
    assignments,
  };
}

export function mergePlanEvidence(discovery, plan) {
  const pages = structuredClone(discovery.pages || []);
  const byId = new Map(pages.map(page => [String(page.pageId), page]));
  for (const assignment of plan.assignments) {
    let page = byId.get(assignment.pageId);
    if (!page) {
      page = { pageId: assignment.pageId, pageName: assignment.pageName, profileId: assignment.profileId || null, environments: [], conflict: false };
      pages.push(page); byId.set(assignment.pageId, page);
    }
    if (!page.environments.some(item => String(item.environmentId) === assignment.environmentId)) {
      page.environments.push({ environmentId: assignment.environmentId, environmentName: assignment.environmentId, targetId: null, evidence: assignment.evidence });
    }
    page.conflict = page.environments.length > 1;
  }
  return { ...discovery, pages };
}

function hasPossibleSubmission(page) {
  return ['completed', 'cleanup_failed'].includes(page?.state)
    || Boolean(page?.submissionClickedAt)
    || Boolean(page?.acceptedAt)
    || Boolean(page?.reviewEvidence)
    || page?.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
    || /已点击发布|结果不确定/.test(page?.stage || '');
}

export function invalidatePlanForDiscovery(state, now = new Date().toISOString()) {
  const currentRun = state.currentRun;
  const releasableHashes = new Set();
  if (currentRun) {
    const pages = new Map((currentRun.pages || []).map(page => [String(page.pageId), page]));
    for (const assignment of currentRun.assignments || []) {
      if (!hasPossibleSubmission(pages.get(String(assignment.pageId)))) releasableHashes.add(assignment.sha256);
    }
  }
  const history = [...(state.history || [])];
  if (currentRun) {
    history.push({ ...currentRun, state: 'superseded', supersededAt: now, supersededReason: 'page_id_refresh_requested' });
  }
  return {
    ...state,
    browserCheck: null,
    discovery: null,
    plan: null,
    bindings: {},
    currentRun: null,
    history: history.slice(-20),
    usedHashes: (state.usedHashes || []).filter(hash => !releasableHashes.has(hash)),
    pageDiscovery: { status: 'running', startedAt: now },
  };
}

export function replacePlanFromDiscovery(state, discovery) {
  assertCompleteDiscovery(discovery);
  const openEnvironmentIds = (discovery.environments || []).map(item => String(item.environmentId));
  const plan = buildBalancedPlan({ discovery, openEnvironmentIds, mappingRows: [] });
  plan.browserCheckRequiredAt = plan.createdAt;
  plan.requiresAllEnvironments = true;
  const currentRun = state.currentRun;
  const releasableHashes = new Set();
  if (currentRun) {
    const pages = new Map((currentRun.pages || []).map(page => [String(page.pageId), page]));
    for (const assignment of currentRun.assignments || []) {
      if (!hasPossibleSubmission(pages.get(String(assignment.pageId)))) releasableHashes.add(assignment.sha256);
    }
  }
  const history = [...(state.history || [])];
  if (currentRun) {
    history.push({ ...currentRun, state: 'superseded', supersededAt: new Date().toISOString(), supersededReason: 'page_id_refresh' });
  }
  return {
    ...state,
    browserCheck: null,
    discovery,
    plan,
    bindings: Object.fromEntries(plan.assignments.map(item => [item.pageId, item.environmentId])),
    currentRun: null,
    history: history.slice(-20),
    usedHashes: (state.usedHashes || []).filter(hash => !releasableHashes.has(hash)),
    pageDiscovery: { status: 'ready', startedAt: state.pageDiscovery?.startedAt || plan.createdAt, completedAt: new Date().toISOString() },
  };
}
