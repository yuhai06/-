import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { processPublicPageBatch, DEFAULT_UPLOAD_STALL_TIMEOUT_SECONDS } from '../skill-runtime/browser_worker_lib.mjs';
import { cleanupSubmittedSourceMaterials } from '../skill-runtime/source_material_cleanup.mjs';
import { discoverHubstudio } from './hubstudio.mjs';
import { attachForPublication, isBlockedPageText } from './pages.mjs';
import { openMaterialHashCache, verifyMaterials } from './materials.mjs';
import { selectRunMaterials } from './material_groups.mjs';
import { AppError } from './errors.mjs';
import { DEFAULT_CLIPS_PER_PAGE, MAX_CLIPS_PER_PAGE, MIN_CLIPS_PER_PAGE, normalizeClipsPerPage } from './batch_size.mjs';
import { captureCurrentView } from './screenshot.mjs';
import { describeFailure } from './diagnostics.mjs';
import { finishSubmittedPage } from './post_submit.mjs';
import { preparePromotionLinks } from '../shared/promotion-links.mjs';

function riskCode(error) {
  const text = `${error?.code || ''} ${error?.message || error}`;
  if (/captcha|recaptcha|验证码|人机验证/i.test(text)) return 'CAPTCHA_REQUIRED';
  if (/checkpoint|登录|log\s*in|verify.{0,20}identity|验证身份|安全检查/i.test(text)) return 'CHECKPOINT_REQUIRED';
  if (/permission|access denied|无权|没有权限|权限不足/i.test(text)) return 'PERMISSION_DENIED';
  if (/rate.?limit|too many requests|频率|操作频繁|请稍后再试/i.test(text)) return 'RATE_LIMIT';
  if (/asset mismatch|identity mismatch|主页.*不一致/i.test(text)) return 'IDENTITY_MISMATCH';
  if (/work tab|Meta Business Suite work tab|工作标签/i.test(text)) return 'WORK_TAB_REQUIRED';
  return error?.code || 'PUBLICATION_FAILED';
}

const MAX_UPLOAD_RETRIES = 5;
const DEFAULT_ENVIRONMENT_CONCURRENCY = 3;
const DELETE_RETRY_DELAYS = [1_000, 3_000, 10_000];
const DEFAULT_INTER_PAGE_DELAY = { min: 15, max: 30 };
const STOP_POLL_INTERVAL_MS = 250;

export function clipsPerPageForRun(run) {
  const value = run?.clipsPerPage;
  return Number.isInteger(value) && value >= MIN_CLIPS_PER_PAGE && value <= MAX_CLIPS_PER_PAGE
    ? value
    : DEFAULT_CLIPS_PER_PAGE;
}

export function skipCopyrightCheckForRun(run) {
  return run?.skipCopyrightCheck === true;
}

/** 同一主页内多条视频的排期间隔（分钟），默认 30。 */
export function spacingMinutesForRun(run) {
  const value = Number(run?.spacingMinutes);
  return Number.isFinite(value) && value >= 0 ? Math.floor(value) : 30;
}

/** 逐条相对基线的分钟偏移；没有就返回 null（改用等距）。 */
export function scheduleOffsetsForRun(run) {
  const raw = run?.scheduleOffsets;
  if (!Array.isArray(raw) || !raw.length) return null;
  return raw.map(x => Math.max(0, Math.floor(Number(x) || 0)));
}

export function uploadStallTimeoutSecondsForRun(run) {  const value = Number(run?.uploadStallTimeoutSeconds);
  return Number.isFinite(value) && value > 0
    ? Math.floor(value)
    : DEFAULT_UPLOAD_STALL_TIMEOUT_SECONDS;
}

function isRiskFailure(error) {
  return new Set(['CAPTCHA_REQUIRED', 'CHECKPOINT_REQUIRED', 'PERMISSION_DENIED', 'RATE_LIMIT', 'IDENTITY_MISMATCH', 'WORK_TAB_REQUIRED']).has(riskCode(error));
}

function isRetryableUploadFailure(error, phase) {
  if (phase === 'submission_button_intent' || phase === 'upload_accepted' || phase === 'submitted') return false;
  if (isRiskFailure(error) || error?.code === 'SUBMISSION_NOT_ACCEPTED' || error?.code === 'PUBLICATION_PAUSED') return false;
  const message = String(error?.message || error);
  if (/"risky"\s*:\s*[1-9]|may be blocked|可能会被屏蔽|可能会受到限制/i.test(message)) return false;
  return /upload stalled|upload or copyright check incomplete|upload input|caption input|copyright check incomplete|upload.*(?:timeout|failed)|file row count mismatch/i.test(message);
}

function isPauseFailure(error) {
  return error?.code === 'PUBLICATION_PAUSED' || /PUBLICATION_PAUSED/.test(String(error?.message || error));
}

function isEnvironmentFatal(error, phase, page) {
  return isRiskFailure(error)
    || !page
    || page.isClosed?.()
    || phase === 'submission_button_intent'
    || phase === 'upload_accepted'
    || error?.code === 'SUBMISSION_NOT_ACCEPTED'
    || /Meta submission acknowledgement|Batch submit outcome|PUBLICATION_PAUSED|work tab was closed|environment.*closed/i.test(String(error?.message || error));
}

function hasPossibleSubmissionOutcome(page) {
  return ['completed', 'cleanup_failed'].includes(page?.state)
    || Boolean(page?.submissionClickedAt)
    || Boolean(page?.acceptedAt)
    || Boolean(page?.reviewEvidence)
    || page?.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
    || /已点击发布|结果不确定/.test(page?.stage || '');
}

function releasableHashesForRun(run) {
  const pages = new Map((run?.pages || []).map(page => [String(page.pageId), page]));
  return new Set((run?.assignments || [])
    .filter(assignment => !hasPossibleSubmissionOutcome(pages.get(String(assignment.pageId))))
    .map(assignment => assignment.sha256)
    .filter(Boolean));
}

export async function reclaimUnsubmittedArchivedHashes(store) {
  const state = store.snapshot();
  const releasable = new Set();
  const protectedHashes = new Set();
  for (const run of state.history || []) {
    const pages = new Map((run.pages || []).map(page => [String(page.pageId), page]));
    for (const assignment of run.assignments || []) {
      if (!assignment.sha256) continue;
      if (hasPossibleSubmissionOutcome(pages.get(String(assignment.pageId)))) protectedHashes.add(assignment.sha256);
      else if (run.state === 'archived') releasable.add(assignment.sha256);
    }
  }
  for (const assignment of state.currentRun?.assignments || []) {
    if (assignment.sha256) protectedHashes.add(assignment.sha256);
  }
  const usedHashes = (state.usedHashes || []).filter(hash => !(releasable.has(hash) && !protectedHashes.has(hash)));
  if (usedHashes.length === (state.usedHashes || []).length) return state;
  return store.update(current => ({ ...current, usedHashes }));
}

async function assertPageSafeForRetry(page) {
  if (!page || page.isClosed()) throw new AppError('WORK_TAB_REQUIRED', '发布工作标签已关闭，停止当前浏览器。');
  let state;
  try {
    state = await page.evaluate(() => ({ url: location.href, text: document.body?.innerText || '' }));
  } catch {
    throw new AppError('WORK_TAB_REQUIRED', '无法读取发布工作标签，停止当前浏览器。');
  }
  let pathname = '';
  try { pathname = new URL(state.url).pathname; } catch { /* Invalid URL is handled as an unsafe work tab. */ }
  if (/\/(?:checkpoint|login|two_step_verification)(?:\/|\.|$)/i.test(pathname) || isBlockedPageText(state.text)) {
    throw new AppError('CHECKPOINT_REQUIRED', '重试前发现登录、验证或账号状态异常，停止当前浏览器。');
  }
}

// Material integrity for recovery and replacement paths. Reuses the shared
// size + mtime cache so untouched files cost one stat() instead of a full
// re-read; a missing or changed file still fails the check.
async function verifyAssignmentRows(assignments, dataDir) {
  let cache = null;
  try { cache = await openMaterialHashCache(dataDir); }
  catch { cache = null; }
  try {
    return await verifyMaterials(assignments, cache);
  } finally {
    try { await cache?.flush(); } catch { /* the cache is an optimisation only. */ }
  }
}

export function resolvedPages(state, selectedBrowserIds) {
  const selected = [...new Set(selectedBrowserIds || [])];
  const ready = new Map((state.browserCheck?.results || []).filter(item => item.status === 'ready').map(item => [item.environmentId, item]));
  for (const environmentId of selected) {
    const browser = ready.get(environmentId);
    if (!browser?.targetId) throw new AppError('BROWSER_NOT_READY', `浏览器 ${environmentId} 当前不可用，请重新检查浏览器。`);
  }
  const selectedSet = new Set(selected);
  const planned = state.plan?.assignments;
  if (!Array.isArray(planned) || !planned.length) throw new AppError('PLAN_REQUIRED', '尚未导入发布计划。');
  const discovered = new Map((state.discovery?.pages || []).map(page => [page.pageId, page]));
  const seenPages = new Set();
  const pages = [];
  for (const assignment of planned) {
    const { pageId, environmentId } = assignment;
    if (!selectedSet.has(environmentId)) continue;
    if (seenPages.has(pageId)) throw new AppError('DUPLICATE_PAGE_TASK', `公共主页 ${pageId} 在任务中重复出现。`);
    seenPages.add(pageId);
    const page = discovered.get(pageId);
    if (!page) throw new AppError('INVALID_PLAN', `发布计划中的公共主页 ${pageId} 没有授权证据。`);
    if (!page.environments?.some(item => item.environmentId === environmentId)) {
      throw new AppError('INVALID_BINDING', `公共主页 ${pageId} 的浏览器归属已失效，请重新制定计划。`);
    }
    const browser = ready.get(environmentId);
    pages.push({ pageId, pageName: assignment.pageName || page.pageName, profileId: assignment.profileId || page.profileId || null, environmentId, targetId: browser.targetId });
  }
  return pages;
}

export async function createRun({ store, directory, directories, publishMode = 'merge', description, linkPool = '', pageCaptions = null, selectedBrowserIds, skippedPageIds = [], concurrency = null, clipsPerPage = DEFAULT_CLIPS_PER_PAGE, skipCopyrightCheck = false, uploadStallTimeoutSeconds = null, spacingMinutes = 30, scheduleOffsets = null, interPageDelaySeconds = DEFAULT_INTER_PAGE_DELAY, onProgress = () => {} }) {
  const normalizedClipsPerPage = normalizeClipsPerPage(clipsPerPage);
  const normalizedUploadStallTimeoutSeconds = Number.isFinite(Number(uploadStallTimeoutSeconds)) && Number(uploadStallTimeoutSeconds) > 0
    ? Math.floor(Number(uploadStallTimeoutSeconds))
    : null;
  const state = store.project(current => ({
    currentRun: current.currentRun,
    browserCheck: current.browserCheck,
    plan: current.plan,
    discovery: current.discovery,
    usedHashes: current.usedHashes,
  }));
  if (state.currentRun && !['completed', 'archived'].includes(state.currentRun.state)) throw new AppError('RUN_ACTIVE', '当前仍有一轮任务，不能重复创建。');
  if (!state.browserCheck?.results?.length) throw new AppError('BROWSER_CHECK_REQUIRED', '请先检查当前打开的浏览器。');
  if (state.plan?.browserCheckRequiredAt && new Date(state.browserCheck.checkedAt || 0) < new Date(state.plan.browserCheckRequiredAt)) {
    throw new AppError('BROWSER_CHECK_REQUIRED', '获取 Page ID 后必须重新检查浏览器，确认全部 Meta 工作标签可用。');
  }
  const skipped = new Set((skippedPageIds || []).map(String));
  const remainingPlan = (state.plan?.assignments || []).filter(item => !skipped.has(String(item.pageId)));
  if (state.plan?.requiresAllEnvironments) {
    const planned = [...new Set(remainingPlan.map(item => item.environmentId))];
    const ready = new Set(state.browserCheck.results.filter(item => item.status === 'ready' && item.targetId).map(item => item.environmentId));
    const selected = new Set(selectedBrowserIds || []);
    const unavailable = planned.filter(environmentId => !ready.has(environmentId));
    if (unavailable.length) throw new AppError('BROWSER_NOT_READY', `以下任务浏览器没有可用的 Meta 工作标签：${unavailable.join('、')}`);
    const omitted = planned.filter(environmentId => !selected.has(environmentId));
    if (omitted.length) throw new AppError('ALL_TASK_BROWSERS_REQUIRED', `必须选择计划中的全部浏览器：${omitted.join('、')}`);
  }
  const pages = resolvedPages({ ...state, plan: { ...state.plan, assignments: remainingPlan } }, selectedBrowserIds);
  if (!pages.length) throw new AppError('PAGE_TASK_REQUIRED', '所选浏览器没有已配置的公共主页任务，请先获取 Page ID。');
  const environmentCount = new Set(pages.map(page => page.environmentId)).size;
  const normalizedConcurrency = concurrency == null ? Math.min(DEFAULT_ENVIRONMENT_CONCURRENCY, environmentCount) : Number(concurrency);
  if (!Number.isInteger(normalizedConcurrency) || normalizedConcurrency < 1 || normalizedConcurrency > environmentCount) {
    throw new AppError('INVALID_CONCURRENCY', `并发数必须是 1 到 ${environmentCount} 之间的整数。`);
  }
  const delayMinimum = Number(interPageDelaySeconds?.min ?? DEFAULT_INTER_PAGE_DELAY.min);
  const delayMaximum = Number(interPageDelaySeconds?.max ?? DEFAULT_INTER_PAGE_DELAY.max);
  if (!Number.isInteger(delayMinimum) || !Number.isInteger(delayMaximum) || delayMinimum < 0 || delayMaximum < delayMinimum) {
    throw new AppError('INVALID_INTER_PAGE_DELAY', '主页间隔必须是有效的整数秒范围。');
  }
  const promotion = preparePromotionLinks(description, linkPool);
  const cache = await openMaterialHashCache(store.dataDir);
  const material = await selectRunMaterials({ directory, directories, publishMode, pages, description, usedHashes: state.usedHashes, cache, linkPool: promotion.links, clipsPerPage: normalizedClipsPerPage, pageCaptions, onProgress });
  const assignments = material.assignments;
  const run = {
    id: randomUUID(), createdAt: new Date().toISOString(), state: 'ready', materialRoot: material.materialRoot, description, skippedPageIds: [...skipped], concurrency: normalizedConcurrency, clipsPerPage: normalizedClipsPerPage, skipCopyrightCheck: skipCopyrightCheck === true,
    ...(normalizedUploadStallTimeoutSeconds ? { uploadStallTimeoutSeconds: normalizedUploadStallTimeoutSeconds } : {}),
    // 同一主页内多条视频的排期间隔（分钟）与逐条偏移
    spacingMinutes: Math.max(0, Math.floor(Number(spacingMinutes) || 30)),
    ...(Array.isArray(scheduleOffsets) && scheduleOffsets.length
      ? { scheduleOffsets: scheduleOffsets.map(x => Math.max(0, Math.floor(Number(x) || 0))) }
      : {}),
    ...(material.materialRoots?.length ? { materialRoots: material.materialRoots } : {}),
    ...(material.materialGroups?.length ? { materialGroups: material.materialGroups } : {}),
    ...(promotion.links.length ? { linkPool: promotion.links } : {}),
    interPageDelaySeconds: { min: delayMinimum, max: delayMaximum }, delayHistory: [],
    pages: pages.map(page => ({ ...page, state: 'ready', stage: '等待执行', error: null, cleanup: null, ...(material.pageFolders.has(String(page.pageId)) ? { materialFolder: material.pageFolders.get(String(page.pageId)) } : {}) })),
    assignments: assignments.map(item => ({ ...item, id: randomUUID(), state: 'ready' })),
  };
  await store.update(current => ({ ...current, currentRun: run, usedHashes: [...new Set([...current.usedHashes, ...assignments.map(item => item.sha256)])] }));
  return run;
}

async function updateRun(store, change) {
  return store.updateCurrentRun(change);
}

async function scheduleRun(store, change) {
  return store.schedule(state => {
    state.currentRun = change(state.currentRun);
    return state;
  });
}

async function pauseEnvironmentPages(store, environmentId, stage = '用户已停止该浏览器任务') {
  return updateRun(store, current => {
    const pageIds = new Set();
    for (const page of current.pages.filter(item => (
      item.environmentId === environmentId
      && ['ready', 'submission_intent', 'retrying', 'running', 'uploading'].includes(item.state)
    ))) {
      page.state = 'paused';
      page.stage = stage;
      page.error = null;
      pageIds.add(page.pageId);
    }
    for (const assignment of current.assignments.filter(item => pageIds.has(item.pageId) && item.state !== 'completed')) {
      assignment.state = 'paused';
    }
    return current;
  });
}

export async function requestEnvironmentStop(store, environmentId) {
  const run = store.project(state => state.currentRun);
  if (!run || run.state !== 'running') throw new AppError('RUN_NOT_RUNNING', '当前没有正在执行的任务。');
  if (!run.pages.some(page => page.environmentId === environmentId)) throw new AppError('ENVIRONMENT_NOT_IN_RUN', `当前任务不包含浏览器 ${environmentId}。`);
  await updateRun(store, current => {
    current.stopRequests ||= { global: false, environments: [] };
    current.stopRequests.environments = [...new Set([...current.stopRequests.environments, environmentId])];
    current.stopRequests.requestedAt = new Date().toISOString();
    return current;
  });
  await pauseEnvironmentPages(store, environmentId);
  return store.project(state => state.currentRun);
}

export async function requestGlobalStop(store) {
  const run = store.project(state => state.currentRun);
  if (!run || run.state !== 'running') throw new AppError('RUN_NOT_RUNNING', '当前没有正在执行的任务。');
  const environments = [...new Set(run.pages
    .filter(page => ['ready', 'submission_intent', 'retrying', 'running', 'uploading'].includes(page.state))
    .map(page => page.environmentId))];
  await updateRun(store, current => {
    current.stopRequests = { global: true, environments, requestedAt: new Date().toISOString() };
    return current;
  });
  for (const environmentId of environments) await pauseEnvironmentPages(store, environmentId, '用户已停止全部任务');
  return store.project(state => state.currentRun);
}

async function evidence(dataDir, runId, environmentId, pageId, page, error, details = {}) {
  const folder = path.join(dataDir, 'errors', runId);
  await fs.mkdir(folder, { recursive: true });
  const stamp = Date.now();
  const record = { at: new Date().toISOString(), environmentId, pageId, code: riskCode(error), ...describeFailure(error), ...details, screenshot: null };
  try {
    const file = path.join(folder, `${environmentId}-${pageId}-${stamp}.png`);
    if (page) record.screenshot = await captureCurrentView(page, file);
  } catch { /* Error log remains useful without a screenshot. */ }
  const log = path.join(folder, `${environmentId}-${pageId}-${stamp}.json`);
  await fs.writeFile(log, `${JSON.stringify(record, null, 2)}\n`, 'utf8');
  return { ...record, log };
}

export async function cleanupBatch(dataDir, run, page, rows, retryWait = ms => new Promise(resolve => setTimeout(resolve, ms))) {
  const folder = path.join(dataDir, 'cleanup');
  await fs.mkdir(folder, { recursive: true });
  const manifestPath = path.join(folder, `${run.id}-${page.pageId}.json`);
  const assignments = rows.map((item, index) => ({ page_key: page.pageId, slot: index + 1, status: index ? 'scheduled' : 'published', asset_id: page.pageId, clip_path: item.path, clip_sha256: item.sha256, file_size: item.bytes }));
  const runRoots = Array.isArray(run.materialRoots) && run.materialRoots.length ? run.materialRoots : run.materialRoot ? [run.materialRoot] : [];
  const groupRoots = (run.materialGroups || []).map(group => group.root).filter(Boolean);
  const rowRoots = rows.map(item => item.sourceRoot).filter(Boolean);
  const materialRoots = [...new Set([...runRoots, ...groupRoots, ...rowRoots])];
  await fs.writeFile(manifestPath, `${JSON.stringify({ round_id: run.id, clips_per_page: clipsPerPageForRun(run), material_roots: materialRoots, assignments }, null, 2)}\n`, { flag: 'wx' });
  let result = await cleanupSubmittedSourceMaterials({ manifestPath, pageKey: page.pageId, enabled: true });
  for (const delay of DELETE_RETRY_DELAYS) {
    if (!/^source_(?:delete|stat|hash_read)_failed:(?:EBUSY|EPERM|EACCES)/.test(result.reason || '')) break;
    await retryWait(delay);
    result = await cleanupSubmittedSourceMaterials({ manifestPath, pageKey: page.pageId, enabled: true });
  }
  return result;
}

async function waitInterruptibly(milliseconds, wait, shouldStop) {
  let remaining = milliseconds;
  while (remaining > 0) {
    if (shouldStop()) return false;
    const slice = Math.min(remaining, STOP_POLL_INTERVAL_MS);
    await wait(slice);
    remaining -= slice;
  }
  return !shouldStop();
}

async function waitBetweenPages({ store, run, environmentId, pageId, boundary, onProgress, delayWait, random, shouldStopEnvironment }) {
  const minimum = Number(run.interPageDelaySeconds?.min ?? DEFAULT_INTER_PAGE_DELAY.min);
  const maximum = Number(run.interPageDelaySeconds?.max ?? DEFAULT_INTER_PAGE_DELAY.max);
  const seconds = Math.floor(minimum + random() * (maximum - minimum + 1));
  const startedAt = new Date().toISOString();
  onProgress({ environmentId, pageId, stage: `主页完成，等待 ${seconds} 秒后继续`, delaySeconds: seconds, boundary });
  const completed = await waitInterruptibly(seconds * 1000, delayWait, () => shouldStopEnvironment(environmentId));
  if (!completed) {
    const interruptedAt = new Date().toISOString();
    await updateRun(store, current => {
      current.delayHistory ||= [];
      current.delayHistory.push({ environmentId, pageId, boundary, seconds, startedAt, interruptedAt });
      return current;
    });
    onProgress({ environmentId, pageId, stage: '主页间等待已中断，正在安全停止', delaySeconds: seconds, boundary });
    return false;
  }
  const completedAt = new Date().toISOString();
  await updateRun(store, current => {
    current.delayHistory ||= [];
    current.delayHistory.push({ environmentId, pageId, boundary, seconds, startedAt, completedAt });
    return current;
  });
  onProgress({ environmentId, pageId, stage: `已等待 ${seconds} 秒，继续下一主页`, delaySeconds: seconds, boundary });
  return true;
}

async function publishEnvironment({ store, dataDir, materialCache = null, run, environment, pages, skillPublisher, attach, finishPage, onProgress, retryWait = ms => new Promise(resolve => setTimeout(resolve, ms)), delayWait, random, shouldStopEnvironment = () => false }) {
  const clipsPerPage = clipsPerPageForRun(run);
  const skipCopyrightCheck = skipCopyrightCheckForRun(run);
  const uploadStallTimeoutSeconds = uploadStallTimeoutSecondsForRun(run);
  const emit = onProgress;
  onProgress = event => {
    const target = pages.find(item => item.pageId === event.pageId);
    emit({ environmentName: environment.environmentName, pageName: target?.pageName, profileId: target?.profileId, ...event });
  };
  let attached;
  let activePage = null;
  let completedAPage = false;
  let lastCompletedPageId = null;
  if (shouldStopEnvironment(environment.environmentId)) {
    await pauseEnvironmentPages(store, environment.environmentId);
    return { completedAPage, lastCompletedPageId };
  }
  try {
    attached = await attach(environment, pages[0].targetId);
    activePage = attached.page;
  } catch (error) {
    if (shouldStopEnvironment(environment.environmentId)) {
      await pauseEnvironmentPages(store, environment.environmentId);
      return { completedAPage, lastCompletedPageId };
    }
    const record = await evidence(dataDir, run.id, environment.environmentId, pages[0].pageId, activePage, error);
    await updateRun(store, current => {
      for (const page of current.pages.filter(item => item.environmentId === environment.environmentId && !['completed', 'cleanup_failed'].includes(item.state))) {
        page.state = 'halted'; page.stage = '当前浏览器已停止'; page.error = record;
      }
      return current;
    });
    onProgress({ environmentId: environment.environmentId, pageId: pages[0].pageId, stage: '当前浏览器已停止', error: record });
    return { completedAPage, lastCompletedPageId };
  }

  for (let pageIndex = 0; pageIndex < pages.length; pageIndex += 1) {
    const page = pages[pageIndex];
    let phase = 'upload';
    let attemptNumber = 0;
    let latestUpload = null;
    let lastFailure = null;
    if (shouldStopEnvironment(environment.environmentId)) {
      await pauseEnvironmentPages(store, environment.environmentId);
      onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '当前浏览器任务已停止' });
      return { completedAPage, lastCompletedPageId };
    }
    try {
      const rows = run.assignments.filter(item => item.pageId === page.pageId).sort((a, b) => a.slot - b.slot);
      if (rows.length !== clipsPerPage) throw new AppError('BATCH_SIZE', `主页 ${page.pageId} 没有完整的 ${clipsPerPage} 条素材。`);
      const materialFailure = await verifyMaterials(rows, materialCache);
      if (materialFailure) throw new AppError('MEDIA_CHANGED', `视频已改变或无法读取：${materialFailure.row.basename}`);
      await updateRun(store, current => {
        const target = current.pages.find(item => item.pageId === page.pageId);
        target.state = 'submission_intent'; target.stage = '已记录提交意图，开始连接 Meta';
        for (const item of current.assignments.filter(row => row.pageId === page.pageId)) item.state = 'submission_intent';
        return current;
      });
      onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: `开始上传${clipsPerPage}条视频` });
      const timezone = await activePage.evaluate(() => Intl.DateTimeFormat().resolvedOptions().timeZone);
      let result;
      let submissionClicked = false;
      let postSubmitReviewEvidence = null;
      for (let attempt = 0; attempt <= MAX_UPLOAD_RETRIES; attempt += 1) {
        if (shouldStopEnvironment(environment.environmentId)) throw new AppError('PUBLICATION_PAUSED', 'PUBLICATION_PAUSED');
        if (attempt > 0) {
          await assertPageSafeForRetry(activePage);
          // 网络不稳/大文件场景下重试间隔逐步拉长，给代理与上传通道恢复时间。
      const waitMs = attempt === 1 ? 30_000 : attempt === 2 ? 60_000 : attempt === 3 ? 120_000 : 180_000;
          onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: 'upload_retry_wait',
            attempt: attempt + 1, totalAttempts: MAX_UPLOAD_RETRIES + 1, waitSeconds: waitMs / 1000,
            error: lastFailure, retryReason: '上传阶段可重试错误，尚未点击发布' });
          await updateRun(store, current => {
            const target = current.pages.find(item => item.pageId === page.pageId);
            target.state = 'retrying'; target.stage = `等待第 ${attempt} 次上传重试`; target.retryCount = attempt;
            return current;
          });
          const completed = await waitInterruptibly(waitMs, retryWait, () => shouldStopEnvironment(environment.environmentId));
          if (!completed) throw new AppError('PUBLICATION_PAUSED', 'PUBLICATION_PAUSED');
          await assertPageSafeForRetry(activePage);
        }
        attemptNumber = attempt + 1;
        latestUpload = null;
        try {
          result = await skillPublisher({
            context: attached.context, page: activePage, fallbackPage: activePage, rows: rows.map(item => ({
              task_id: item.id, slot: item.slot, clip_path: item.path, file_name: item.basename,
              caption: item.description, title: item.title, description: item.description, asset_id: page.pageId,
            })), assetId: page.pageId, businessId: null, expectedPageName: null, composerOpenMode: 'direct', uploadInputMode: 'cdp_local_paths',
            // ⚠ 2026-11-12 从 'button_click' 改成 'receipt'。
            //
            // 原注释说"Meta 的提交后弹窗不是可靠回执，可靠信号是按钮点了"，
            // 但实机证明这个假设是错的：
            //   EP59 那次 state=completed、按钮确实点了，
            //   然而 returnHome={status:'pending', message:'60 秒内未看到平台提交完成提示'}，
            //   Meta 后台**查不到帖子**。yuhai 侧按 button_click 判成功，
            //   于是"界面显示发成功、后台没有"——这就是用户反复遇到的假成功。
            //
            // 'receipt' 模式会真正轮询平台回执（accepted_receipt / done /
            // redirected / reported_failed / composer 消失），
            // 90 秒内看不到就抛错，不再假报成功。
            scheduleTimeZone: timezone, submissionConfirmationMode: 'receipt',
            skipCopyrightCheck, uploadStallTimeoutSeconds,
            spacingMinutes: spacingMinutesForRun(run),
            scheduleOffsets: scheduleOffsetsForRun(run),
            shouldStop: () => shouldStopEnvironment(environment.environmentId),
            onProgress: async progress => {
              if (progress.submissionAttempted === true || progress.stage === 'submission_button_clicked') submissionClicked = true;
              phase = progress.submissionAttempted || progress.stage === 'submission_button_intent' ? 'submission_button_intent' : progress.stage;
              if (progress.stage === 'post_submit_failure_dialog_detected') {
                postSubmitReviewEvidence = await evidence(
                  dataDir,
                  run.id,
                  environment.environmentId,
                  page.pageId,
                  progress.evidencePage || activePage,
                  { code: 'POST_SUBMIT_REVIEW', message: '发布按钮已点击；Meta 提示无法处理部分 Reels，已在关闭前留存截图。' },
                );
              }
              const publicProgress = { ...progress };
              delete publicProgress.evidencePage;
              if (publicProgress.upload) latestUpload = publicProgress.upload;
              onProgress({ environmentId: environment.environmentId, pageId: page.pageId, attempt: attemptNumber, totalAttempts: MAX_UPLOAD_RETRIES + 1, ...publicProgress });
              const persistProgress = publicProgress.stage === 'submission_button_clicked' ? updateRun : scheduleRun;
              return persistProgress(store, current => {
                const target = current.pages.find(item => item.pageId === page.pageId);
                target.stage = publicProgress.stage;
                target.progressDetails = { ...publicProgress, attempt: attemptNumber, totalAttempts: MAX_UPLOAD_RETRIES + 1 };
                if (publicProgress.stage === 'submission_button_clicked') target.submissionClickedAt ||= new Date().toISOString();
                return current;
              });
            },
          });
          break;
        } catch (error) {
          if (submissionClicked && !isRiskFailure(error)) {
            result = {
              page: activePage,
              accepted: true,
              acceptance: 'upload_accepted',
              submitOutcome: 'button_clicked',
              postSubmitError: error.message,
            };
            break;
          }
          if (isPauseFailure(error) || shouldStopEnvironment(environment.environmentId)) {
            await pauseEnvironmentPages(store, environment.environmentId);
            onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '当前浏览器任务已停止' });
            return { completedAPage, lastCompletedPageId };
          }
          if (attempt < MAX_UPLOAD_RETRIES && isRetryableUploadFailure(error, phase)) {
            lastFailure = { at: new Date().toISOString(), attempt: attemptNumber, totalAttempts: MAX_UPLOAD_RETRIES + 1,
              phase, code: riskCode(error), ...describeFailure(error), upload: error.upload || latestUpload,
              uploadNetwork: error.uploadNetwork || null, batchSize: rows.length };
            await updateRun(store, current => {
              const target = current.pages.find(item => item.pageId === page.pageId);
              target.retryHistory ||= [];
              target.retryHistory.push(lastFailure);
              target.lastDiagnostic = lastFailure;
              return current;
            });
            onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: 'upload_attempt_failed',
              attempt: attemptNumber, totalAttempts: MAX_UPLOAD_RETRIES + 1, error: lastFailure });
            continue;
          }
          throw error;
        }
      }
      activePage = result.page || activePage;
      if (result.acceptance !== 'upload_accepted' || result.accepted !== true) throw new AppError('SUBMISSION_NOT_ACCEPTED', '未完成发布按钮提交，禁止自动重试。');
      let reviewEvidence = postSubmitReviewEvidence;
      if (['reported_failed', 'button_clicked'].includes(result.submitOutcome)) {
        reviewEvidence ||= await evidence(dataDir, run.id, environment.environmentId, page.pageId, activePage, {
          code: 'POST_SUBMIT_REVIEW',
          message: `发布按钮已点击；Meta 返回 ${result.submitOutcome}，仅留存截图供人工复核。`,
        });
      }
      let cleanup;
      try { cleanup = await cleanupBatch(dataDir, run, page, rows, retryWait); }
      catch (error) { cleanup = { status: 'partial_failure', reason: error.message }; }
      await updateRun(store, current => {
        const target = current.pages.find(item => item.pageId === page.pageId);
        const cleanupCompleted = ['completed', 'already_completed'].includes(cleanup.status);
        target.state = cleanupCompleted ? 'completed' : 'cleanup_failed';
        target.stage = cleanupCompleted
          ? (reviewEvidence ? '已点击发布，本地视频已删除，Meta 提示待人工复核' : '发布完成，本地视频已删除')
          : '发布成功，但本地视频删除失败';
        target.acceptedAt = new Date().toISOString(); target.cleanup = cleanup;
        if (reviewEvidence) target.reviewEvidence = reviewEvidence;
        for (const item of current.assignments.filter(row => row.pageId === page.pageId)) item.state = 'completed';
        return current;
      });
      completedAPage = true;
      lastCompletedPageId = page.pageId;
      if (pageIndex === pages.length - 1 && !shouldStopEnvironment(environment.environmentId)) {
        onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '等待平台提交完成，准备返回 Meta 首页' });
        let returned;
        try { returned = await finishPage(activePage, { assetId: page.pageId, shouldStop: () => shouldStopEnvironment(environment.environmentId) }); }
        catch (error) { returned = { status: 'pending', message: `返回首页未完成：${error.message}` }; }
        await updateRun(store, current => {
          current.pages.find(item => item.pageId === page.pageId).returnHome = { ...returned, at: new Date().toISOString() };
          return current;
        });
        onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: returned.status === 'home' ? '任务结束，已返回 Meta 首页' : returned.message });
      }
      if (pageIndex < pages.length - 1) {
        await waitBetweenPages({ store, run, environmentId: environment.environmentId, pageId: page.pageId, boundary: 'within_environment', onProgress, delayWait, random, shouldStopEnvironment });
      }
    } catch (error) {
      if (isPauseFailure(error) || shouldStopEnvironment(environment.environmentId)) {
        await pauseEnvironmentPages(store, environment.environmentId);
        onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '当前浏览器任务已停止' });
        return { completedAPage, lastCompletedPageId };
      }
      const record = await evidence(dataDir, run.id, environment.environmentId, page.pageId, activePage, error, {
        phase, attempt: attemptNumber, totalAttempts: MAX_UPLOAD_RETRIES + 1, upload: error.upload || latestUpload,
        uploadNetwork: error.uploadNetwork || null,
        batchSize: run.assignments.filter(item => item.pageId === page.pageId).length,
      });
      if (!isEnvironmentFatal(error, phase, activePage)) {
        await updateRun(store, current => {
          const target = current.pages.find(item => item.pageId === page.pageId);
          target.state = 'halted'; target.stage = '当前浏览器任务停止'; target.error = record;
          return current;
        });
        onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '当前浏览器任务停止', error: record });
        continue;
      }
      await updateRun(store, current => {
        for (const target of current.pages.filter(item => item.environmentId === environment.environmentId && !['completed', 'cleanup_failed'].includes(item.state))) {
          target.state = 'halted'; target.stage = '当前浏览器已停止'; target.error = record;
        }
        return current;
      });
      onProgress({ environmentId: environment.environmentId, pageId: page.pageId, stage: '当前浏览器已停止', error: record });
      return { completedAPage, lastCompletedPageId };
    }
  }
  attached = null;
  return { completedAPage, lastCompletedPageId };
}

export async function executeRun({ store, dataDir, concurrency: requestedConcurrency = null, executionControl = {}, finishPage = finishSubmittedPage, onProgress = () => {}, hubDiscovery = discoverHubstudio, attach = attachForPublication, skillPublisher = processPublicPageBatch, retryWait, delayWait = ms => new Promise(resolve => setTimeout(resolve, ms)), random = Math.random, shouldStopEnvironment = () => false }) {
  const run = store.project(state => state.currentRun);
  if (!run || run.state !== 'ready') throw new AppError('RUN_NOT_READY', '当前没有可执行的新任务。');
  const environmentCount = new Set(run.pages.map(page => page.environmentId)).size;
  const concurrency = Number(requestedConcurrency ?? run.concurrency ?? DEFAULT_ENVIRONMENT_CONCURRENCY);
  if (!Number.isInteger(concurrency) || concurrency < 1 || requestedConcurrency != null && concurrency > environmentCount) {
    throw new AppError('INVALID_CONCURRENCY', `并发数必须是 1 到 ${environmentCount} 之间的整数。`);
  }
  executionControl.activeEnvironments ||= new Set();
  executionControl.recoveringEnvironments ||= new Set();
  executionControl.running = true;
  // One cache per run: reused by every environment slot so material checks are
  // a stat() each instead of a full re-read of every video.
  let materialCache = null;
  try { materialCache = await openMaterialHashCache(store.dataDir); }
  catch { materialCache = null; }
  try {
    await updateRun(store, current => ({ ...current, concurrency, state: 'running', startedAt: new Date().toISOString(), stopRequests: { global: false, environments: [] } }));
    let live;
    try { live = await hubDiscovery(); }
    catch (error) {
      const record = { at: new Date().toISOString(), code: riskCode(error), message: error.message };
      await updateRun(store, current => {
        current.state = 'needs_attention'; current.finishedAt = new Date().toISOString();
        for (const page of current.pages) { page.state = 'halted'; page.stage = 'HubStudio 连接失败'; page.error = record; }
        return current;
      });
      onProgress({ stage: 'HubStudio 连接失败', error: record });
      return store.project(state => state.currentRun);
    }
    const byId = new Map(live.environments.map(item => [item.environmentId, item]));
    const groups = new Map();
    for (const page of run.pages.filter(item => item.state === 'ready')) {
      if (!byId.has(page.environmentId)) {
        const record = { at: new Date().toISOString(), code: 'ENVIRONMENT_CLOSED', message: `环境 ${page.environmentId} 已关闭。` };
        await updateRun(store, current => {
          const target = current.pages.find(item => item.pageId === page.pageId);
          target.state = 'halted'; target.stage = '环境已关闭'; target.error = record;
          return current;
        });
        onProgress({ environmentId: page.environmentId, pageId: page.pageId, stage: '环境已关闭', error: record });
        continue;
      }
      if (!groups.has(page.environmentId)) groups.set(page.environmentId, []);
      groups.get(page.environmentId).push(page);
    }
    const queue = [...groups.keys()];
    const active = executionControl.activeEnvironments;
    let wake;
    executionControl.wake = () => { const resolve = wake; wake = null; resolve?.(); };
    executionControl.enqueueEnvironment = environment => {
      const id = environment.environmentId;
      if (active.has(id)) throw new AppError('ENVIRONMENT_STOPPING', '该环境尚未安全停止，请稍后恢复。');
      byId.set(id, environment);
      if (!queue.includes(id)) queue.push(id);
      executionControl.wake();
    };
    while (queue.length || active.size || executionControl.recoveringEnvironments.size) {
      while (queue.length && active.size < concurrency) {
        const environmentId = queue.shift();
        // Recovery can change target IDs and ready pages after the run started.
        const pages = store.project(state => state.currentRun.pages.filter(page => page.environmentId === environmentId && page.state === 'ready'));
        if (!pages.length) continue;
        active.add(environmentId);
        (async () => {
          try {
            const [settled] = await Promise.allSettled([publishEnvironment({ store, dataDir, materialCache, run, environment: byId.get(environmentId), pages, skillPublisher, attach, finishPage, onProgress, retryWait, delayWait, random, shouldStopEnvironment })]);
            if (queue.length && settled.status === 'fulfilled' && settled.value?.completedAPage) {
              await waitBetweenPages({ store, run, environmentId, pageId: settled.value.lastCompletedPageId, boundary: 'between_environments', onProgress, delayWait, random, shouldStopEnvironment });
            }
          } finally {
            active.delete(environmentId);
            executionControl.wake();
            onProgress({ environmentId, stage: '环境执行槽已释放' });
          }
        })().catch(error => onProgress({ environmentId, stage: '环境收尾异常', error: { message: error.message } }));
      }
      if (active.size || executionControl.recoveringEnvironments.size) await new Promise(resolve => { wake = resolve; });
    }
    const final = store.project(state => state.currentRun);
    const state = final.pages.every(page => page.state === 'completed') ? 'completed' : 'needs_attention';
    await updateRun(store, current => ({ ...current, state, finishedAt: new Date().toISOString() }));
    return store.project(state => state.currentRun);
  } finally {
    executionControl.running = false;
    executionControl.enqueueEnvironment = null;
    executionControl.wake = null;
    try { await materialCache?.flush(); } catch { /* the cache is an optimisation only. */ }
  }
}

export async function archiveRun(store) {
  const current = store.project(state => state.currentRun);
  if (!current || current.state === 'running') throw new AppError('RUN_NOT_ARCHIVABLE', '正在执行的任务不能结束。');
  const releasable = releasableHashesForRun(current);
  return store.update(state => ({
    ...state,
    currentRun: null,
    usedHashes: (state.usedHashes || []).filter(hash => !releasable.has(hash)),
    history: [...state.history.slice(-19), { ...current, state: 'archived', archivedAt: new Date().toISOString() }],
  }));
}

export async function prepareSafeContinuation(store, { allowedEnvironmentIds = null } = {}) {
  const run = store.project(state => state.currentRun);
  if (!run || run.state !== 'needs_attention') throw new AppError('RUN_NOT_RECOVERABLE', '当前没有可安全恢复的已停止任务。');
  const allowed = allowedEnvironmentIds ? new Set(allowedEnvironmentIds) : null;
  const clipsPerPage = clipsPerPageForRun(run);
  const recoverablePageIds = [];
  const excluded = [];
  for (const page of run.pages.filter(item => item.state === 'halted' || item.state === 'paused')) {
    if (allowed && !allowed.has(page.environmentId)) {
      excluded.push({ pageId: page.pageId, reason: 'environment_not_ready' });
      continue;
    }
    const assignments = run.assignments.filter(item => item.pageId === page.pageId);
    const triggeredRisk = isRiskFailure(page.error) && String(page.error?.pageId || page.pageId) === String(page.pageId);
    const outcomeUnknown = page.submissionClickedAt || page.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
      || page.acceptedAt
      || page.reviewEvidence
      || /已点击发布|结果不确定/.test(page.stage || '');
    if (triggeredRisk || outcomeUnknown || assignments.length !== clipsPerPage) {
      excluded.push({ pageId: page.pageId, reason: triggeredRisk ? 'triggered_risk' : outcomeUnknown ? 'outcome_unknown' : 'incomplete_batch' });
      continue;
    }
    if (await verifyAssignmentRows(assignments, store.dataDir)) {
      excluded.push({ pageId: page.pageId, reason: 'material_missing_or_changed' });
      continue;
    }
    recoverablePageIds.push(page.pageId);
  }
  if (!recoverablePageIds.length) return { recovered: 0, pageIds: [], excluded };
  const recoveredAt = new Date().toISOString();
  const recoverable = new Set(recoverablePageIds);
  await updateRun(store, current => {
    current.state = 'ready';
    current.finishedAt = null;
    current.recoveredAt = recoveredAt;
    current.lastRecovery = { at: recoveredAt, recovered: recoverablePageIds.length, excluded: excluded.length, mode: 'unfinished_only' };
    current.recoveryHistory ||= [];
    current.recoveryHistory.push({ at: recoveredAt, pageIds: recoverablePageIds, excluded });
    for (const page of current.pages.filter(item => recoverable.has(item.pageId))) {
      page.state = 'ready';
      page.stage = '已核验素材，等待安全续跑';
      page.error = null;
      page.retryCount = 0;
    }
    for (const assignment of current.assignments.filter(item => recoverable.has(item.pageId))) assignment.state = 'ready';
    return current;
  });
  return { recovered: recoverablePageIds.length, pageIds: recoverablePageIds, excluded };
}

export async function prepareArchivedEnvironmentReplacement(store, { sourceEnvironmentId, targetEnvironmentId }) {
  const state = store.snapshot();
  if (state.currentRun) throw new AppError('RUN_ACTIVE', '当前已有一轮任务，请先结束后再替换失败浏览器。');
  if (!sourceEnvironmentId || !targetEnvironmentId || sourceEnvironmentId === targetEnvironmentId) {
    throw new AppError('INVALID_ENVIRONMENT_REPLACEMENT', '请选择不同的失败浏览器和接管浏览器。');
  }
  const browser = state.browserCheck?.results?.find(item => item.environmentId === targetEnvironmentId && item.status === 'ready' && item.targetId);
  if (!browser) throw new AppError('BROWSER_NOT_READY', `接管浏览器 ${targetEnvironmentId} 没有通过最新的 Meta 标签检查。`);
  if (state.pageDiscovery?.status !== 'ready' || !state.discovery?.pages?.length) {
    throw new AppError('PAGE_DISCOVERY_REQUIRED', '请先重新获取 Page ID，证明接管浏览器拥有待迁移主页。');
  }
  const sourceRun = [...(state.history || [])].reverse().find(run => (run.pages || []).some(page => (
    page.environmentId === sourceEnvironmentId && !['completed', 'cleanup_failed'].includes(page.state)
  )));
  if (!sourceRun) throw new AppError('SOURCE_RUN_NOT_FOUND', `历史中没有找到浏览器 ${sourceEnvironmentId} 的任务。`);
  const clipsPerPage = clipsPerPageForRun(sourceRun);
  const excluded = [];
  const candidates = [];
  for (const page of (sourceRun.pages || []).filter(item => item.environmentId === sourceEnvironmentId && !['completed', 'cleanup_failed'].includes(item.state))) {
    const triggeredRisk = isRiskFailure(page.error) && String(page.error?.pageId || page.pageId) === String(page.pageId);
    const outcomeUnknown = page.submissionClickedAt
      || page.acceptedAt
      || page.reviewEvidence
      || page.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
      || /已点击发布|结果不确定/.test(page.stage || '');
    const assignments = (sourceRun.assignments || []).filter(item => String(item.pageId) === String(page.pageId));
    if (triggeredRisk || outcomeUnknown || assignments.length !== clipsPerPage) {
      excluded.push({ pageId: page.pageId, reason: triggeredRisk ? 'triggered_risk' : outcomeUnknown ? 'outcome_unknown' : 'incomplete_batch' });
      continue;
    }
    candidates.push({ page, assignments });
  }
  if (!candidates.length) throw new AppError('NO_SAFE_CHECKPOINT', '该失败浏览器没有可安全迁移的未完成主页。');
  const discoveryByPage = new Map((state.discovery?.pages || []).map(page => [String(page.pageId), page]));
  const unauthorized = candidates.filter(({ page }) => !discoveryByPage.get(String(page.pageId))?.environments?.some(item => item.environmentId === targetEnvironmentId));
  if (unauthorized.length) {
    const sample = unauthorized.slice(0, 5).map(item => item.page.pageId).join('、');
    throw new AppError('REPLACEMENT_AUTHORIZATION_MISSING', `接管浏览器 ${targetEnvironmentId} 未证明授权 ${unauthorized.length} 个待迁移主页：${sample}${unauthorized.length > 5 ? '等' : ''}。`);
  }
  const invalidMaterials = [];
  for (const candidate of candidates) {
    if (await verifyAssignmentRows(candidate.assignments, store.dataDir)) invalidMaterials.push(candidate.page.pageId);
  }
  if (invalidMaterials.length) {
    throw new AppError('REPLACEMENT_MATERIAL_INVALID', `${invalidMaterials.length} 个待迁移主页的素材缺失或已改变，不能断点迁移。`);
  }
  const createdAt = new Date().toISOString();
  const pageIds = new Set(candidates.map(item => String(item.page.pageId)));
  const run = {
    id: randomUUID(),
    createdAt,
    state: 'ready',
    materialRoot: sourceRun.materialRoot,
    ...(Array.isArray(sourceRun.materialRoots) && sourceRun.materialRoots.length ? { materialRoots: sourceRun.materialRoots } : {}),
    ...(Array.isArray(sourceRun.materialGroups) && sourceRun.materialGroups.length ? { materialGroups: sourceRun.materialGroups } : {}),
    description: sourceRun.description,
    concurrency: 1,
    clipsPerPage,
    interPageDelaySeconds: sourceRun.interPageDelaySeconds || DEFAULT_INTER_PAGE_DELAY,
    delayHistory: [],
    replacement: { sourceRunId: sourceRun.id, sourceEnvironmentId, targetEnvironmentId, preparedAt: createdAt, excluded },
    pages: candidates.map(({ page }) => ({ ...page, environmentId: targetEnvironmentId, targetId: browser.targetId, state: 'ready', stage: '已迁移至接管浏览器，等待继续', error: null, retryCount: 0 })),
    assignments: (sourceRun.assignments || []).filter(item => pageIds.has(String(item.pageId))).map(item => ({ ...item, id: randomUUID(), state: 'ready' })),
  };
  await store.update(current => ({ ...current, currentRun: run }));
  return { run, recovered: candidates.length, excluded };
}

export async function prepareEnvironmentContinuation(store, { environmentId, targetId, allowRunning = false, assertRecoverable = () => {} }) {
  const run = store.project(state => state.currentRun);
  if (!run || run.state === 'running' && !allowRunning) throw new AppError('RUN_NOT_RECOVERABLE', '请先停止该环境或全部任务，再执行恢复。');
  if (run.pages.some(page => page.environmentId === environmentId && ['submission_intent', 'retrying', 'running', 'uploading'].includes(page.state))) throw new AppError('ENVIRONMENT_STOPPING', '该环境尚未安全停止，请稍后恢复。');
  assertRecoverable();
  if (!environmentId || !targetId) throw new AppError('BROWSER_NOT_READY', '该浏览器当前没有可用的 Meta 工作标签。');
  const clipsPerPage = clipsPerPageForRun(run);
  const recoverableCodes = new Set(['ENVIRONMENT_CLOSED', 'WORK_TAB_REQUIRED', 'WORK_TAB_CHANGED', 'PUBLICATION_PAUSED']);
  const candidates = run.pages.filter(page => (
    page.environmentId === environmentId
    && (page.state === 'paused' || (page.state === 'halted' && recoverableCodes.has(page.error?.code)))
  ));
  const pageIds = [];
  const excluded = [];
  for (const page of candidates) {
    const assignments = run.assignments.filter(item => item.pageId === page.pageId);
    const outcomeUnknown = page.submissionClickedAt
      || page.acceptedAt
      || page.reviewEvidence
      || page.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
      || /已点击发布|结果不确定/.test(page.stage || '');
    if (outcomeUnknown || assignments.length !== clipsPerPage) {
      excluded.push({ pageId: page.pageId, reason: outcomeUnknown ? 'outcome_unknown' : 'incomplete_batch' });
      continue;
    }
    if (await verifyAssignmentRows(assignments, store.dataDir)) {
      excluded.push({ pageId: page.pageId, reason: 'material_missing_or_changed' });
      continue;
    }
    pageIds.push(page.pageId);
  }
  if (!pageIds.length) throw new AppError('NO_SAFE_CHECKPOINT', `浏览器 ${environmentId} 没有可安全断点续传的任务。`);
  const recoveredAt = new Date().toISOString();
  const recoverable = new Set(pageIds);
  await updateRun(store, current => {
    assertRecoverable();
    if (current.id !== run.id) throw new AppError('RUN_NOT_RECOVERABLE', '任务已经改变，请重新检查。');
    if (current.state !== 'running') current.state = 'ready';
    current.finishedAt = null;
    current.recoveredAt = recoveredAt;
    current.recoveryHistory ||= [];
    current.recoveryHistory.push({ at: recoveredAt, environmentId, targetId, pageIds, excluded, mode: 'environment_checkpoint' });
    current.lastRecovery = { at: recoveredAt, environmentId, recovered: pageIds.length, excluded: excluded.length };
    current.stopRequests ||= { global: false, environments: [] };
    current.stopRequests.global = false;
    current.stopRequests.environments = current.stopRequests.environments.filter(id => id !== environmentId);
    for (const page of current.pages.filter(item => recoverable.has(item.pageId))) {
      page.state = 'ready';
      page.stage = '断点已恢复，等待继续';
      page.error = null;
      page.retryCount = 0;
      page.targetId = targetId;
    }
    for (const assignment of current.assignments.filter(item => recoverable.has(item.pageId))) assignment.state = 'ready';
    return current;
  });
  return { recovered: pageIds.length, pageIds, excluded };
}
