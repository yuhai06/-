import fs from 'node:fs/promises';
import path from 'node:path';

function cell(value) {
  return String(value ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

function submitted(page) {
  return page.state === 'completed' || page.state === 'cleanup_failed' || Boolean(page.acceptedAt);
}

function retryAllowed(page) {
  return !page.submissionClickedAt
    && !page.acceptedAt
    && !page.reviewEvidence
    && page.error?.code !== 'INTERRUPTED_OUTCOME_UNKNOWN'
    && !/已点击发布|结果不确定/.test(page.stage || '');
}

function report(run, pages, kind) {
  const lines = [
    `报告类型\t${kind}`,
    `Run ID\t${cell(run.id)}`,
    `生成时间\t${new Date().toISOString()}`,
    `数量\t${pages.length}`,
    '',
    '浏览器ID\t主页ID\t主页名称\t状态\t阶段\t错误代码\t错误说明\t已点击发布\t可安全重试',
    ...pages.map(page => [
      page.environmentId,
      page.pageId,
      page.pageName,
      page.state,
      page.stage,
      page.error?.code,
      page.error?.message,
      page.submissionClickedAt || page.acceptedAt ? '是' : '否',
      retryAllowed(page) ? '是' : '否',
    ].map(cell).join('\t')),
  ];
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

export async function writeRunReports(outputDir, run) {
  if (!outputDir || !run) return null;
  await fs.mkdir(outputDir, { recursive: true });
  const successful = (run.pages || []).filter(submitted);
  const failed = (run.pages || []).filter(page => !submitted(page));
  const files = [
    { name: '成功主页.txt', content: report(run, successful, '成功主页') },
    { name: '失败主页.txt', content: report(run, failed, '失败或未完成主页') },
  ];
  for (const item of files) {
    const target = path.join(outputDir, item.name);
    const temporary = `${target}.tmp`;
    await fs.writeFile(temporary, item.content, 'utf8');
    await fs.rename(temporary, target).catch(async error => {
      if (!['EEXIST', 'EPERM', 'EACCES'].includes(error.code)) throw error;
      await fs.rm(target, { force: true });
      await fs.rename(temporary, target);
    });
  }
  return {
    outputDir,
    successful: successful.length,
    failed: failed.length,
    files: files.map(item => path.join(outputDir, item.name)),
  };
}
