import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { AppError } from './errors.mjs';
import { DEFAULT_CLIPS_PER_PAGE, normalizeClipsPerPage } from './batch_size.mjs';
import { preparePromotionLinks, replacePromotionLink } from '../shared/promotion-links.mjs';

const EXTENSIONS = new Set(['.mp4', '.mov', '.m4v', '.webm']);
const TEMPLATE_TOKEN = /\{\{\s*([^{}\r\n]+?)\s*\}\}/gu;
const HASH_CACHE_MAX_ENTRIES = 50_000;
const HASH_CACHE_MAX_AGE_MS = 180 * 24 * 60 * 60 * 1000;

export function renderDramaTemplate(template, dramaTitle) {
  const rendered = template.replace(TEMPLATE_TOKEN, () => dramaTitle);
  const remainder = template.replace(TEMPLATE_TOKEN, '');
  if (remainder.includes('{{') || remainder.includes('}}')) {
    throw new AppError('INVALID_TEMPLATE_SYNTAX', '剧名占位符的花括号不完整，请使用 {{DRAMA}}、{{剧名}} 或其他完整的 {{占位符}}。');
  }
  return rendered;
}

export async function hashFile(file) {
  const digest = crypto.createHash('sha256');
  for await (const chunk of createReadStream(file)) digest.update(chunk);
  return digest.digest('hex');
}

function cacheKey(file) {
  const resolved = path.resolve(file);
  return process.platform === 'win32' ? resolved.toLocaleLowerCase('en-US') : resolved;
}

export async function openMaterialHashCache(dataDir, { hash = hashFile, now = () => Date.now() } = {}) {
  const file = path.join(dataDir, 'material-hash-cache.json');
  let entries = {};
  try {
    const saved = JSON.parse(await fs.readFile(file, 'utf8'));
    if (saved?.version === 1 && saved.entries && typeof saved.entries === 'object') entries = saved.entries;
  } catch (error) {
    if (!['ENOENT', 'SyntaxError'].includes(error.code) && !(error instanceof SyntaxError)) throw error;
  }
  let dirty = false;
  let hits = 0;
  let misses = 0;
  return {
    async digest(video) {
      const stat = await fs.stat(video.path);
      const key = cacheKey(video.path);
      const cached = entries[key];
      const seenAt = now();
      if (cached?.bytes === stat.size && cached?.mtimeMs === stat.mtimeMs && cached.sha256) {
        cached.lastSeenAt = seenAt;
        dirty = true;
        hits += 1;
        return { sha256: cached.sha256, bytes: stat.size, mtimeMs: stat.mtimeMs, cached: true };
      }
      const sha256 = await hash(video.path);
      entries[key] = { bytes: stat.size, mtimeMs: stat.mtimeMs, sha256, lastSeenAt: seenAt };
      dirty = true;
      misses += 1;
      return { sha256, bytes: stat.size, mtimeMs: stat.mtimeMs, cached: false };
    },
    async flush() {
      if (!dirty) return;
      const cutoff = now() - HASH_CACHE_MAX_AGE_MS;
      const retained = Object.entries(entries)
        .filter(([, entry]) => Number(entry.lastSeenAt || 0) >= cutoff)
        .sort((left, right) => Number(right[1].lastSeenAt || 0) - Number(left[1].lastSeenAt || 0))
        .slice(0, HASH_CACHE_MAX_ENTRIES);
      entries = Object.fromEntries(retained);
      await fs.mkdir(dataDir, { recursive: true });
      await fs.writeFile(file, `${JSON.stringify({ version: 1, entries })}\n`, 'utf8');
      dirty = false;
    },
    stats() { return { hits, misses, entries: Object.keys(entries).length }; },
  };
}

export async function listVideos(directory) {
  const root = await fs.realpath(directory).catch(() => null);
  if (!root || !(await fs.stat(root)).isDirectory()) throw new AppError('INVALID_MATERIAL_DIRECTORY', '请选择有效的素材文件夹。');
  const videos = [];
  async function visit(folder) {
    const entries = await fs.readdir(folder, { withFileTypes: true });
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      const file = path.join(folder, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) await visit(file);
      else if (entry.isFile() && EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
        const stat = await fs.stat(file);
        if (stat.size > 0) videos.push({ path: file, basename: entry.name, bytes: stat.size, title: path.basename(path.dirname(file)) });
      }
    }
  }
  await visit(root);
  return { root, videos, count: videos.length, dramaCount: new Set(videos.map(item => item.title)).size };
}

export async function listVideosMulti(directories) {
  const inputs = Array.isArray(directories) ? directories : [];
  const groups = [];
  const videos = [];
  const seenFiles = new Set();
  for (const input of inputs) {
    const listed = await listVideos(input);
    const group = { root: listed.root, videos: [], count: 0, dramaCount: 0 };
    for (const video of listed.videos) {
      const realPath = await fs.realpath(video.path).catch(() => video.path);
      const key = process.platform === 'win32' ? realPath.toLocaleLowerCase('en-US') : realPath;
      if (seenFiles.has(key)) continue;
      seenFiles.add(key);
      const item = { ...video, sourceRoot: listed.root };
      group.videos.push(item);
      videos.push(item);
    }
    group.count = group.videos.length;
    group.dramaCount = new Set(group.videos.map(item => item.title)).size;
    groups.push(group);
  }
  return {
    groups,
    videos,
    roots: groups.map(group => group.root),
    count: videos.length,
    total: videos.length,
    folderCount: groups.length,
    dramaCount: new Set(videos.map(item => item.title)).size,
  };
}

function shuffle(items) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = crypto.randomInt(index + 1);
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

export async function selectAvailableVideos(videos, required, usedHashes, cache, onProgress = () => {}) {
  const used = new Set(usedHashes || []);
  const seen = new Set();
  const available = [];
  const candidates = shuffle(videos);
  let scanned = 0;
  try {
    for (const video of candidates) {
      scanned += 1;
      const fingerprint = await cache.digest(video);
      if (!used.has(fingerprint.sha256) && !seen.has(fingerprint.sha256)) {
        seen.add(fingerprint.sha256);
        available.push({ ...video, ...fingerprint });
      }
      if (scanned === 1 || scanned % 25 === 0 || available.length >= required || scanned === candidates.length) {
        onProgress({ stage: 'preparing_materials', file: video.basename, current: scanned, total: candidates.length, selected: available.length, required });
      }
      if (available.length >= required) break;
    }
  } finally {
    try { await cache.flush(); }
    catch (error) { onProgress({ stage: 'hash_cache_write_failed', message: error.message }); }
  }
  return { videos: available, scanned, cache: cache.stats() };
}

// Pre-publish integrity check. The size + mtime cache keeps this cheap: files
// already hashed during selection are confirmed with a single stat() each
// instead of a full re-read. A cache miss (replaced, edited, truncated or
// deleted file) still falls back to a real hash. Set
// REELS_PUBLISHER_STRICT_MATERIAL_HASH=1 to always re-hash from disk, which is
// slower but immune to a file that preserved both size and mtime.
export const STRICT_MATERIAL_HASH = process.env.REELS_PUBLISHER_STRICT_MATERIAL_HASH === '1';

export async function verifyMaterials(rows, cache, { strict = STRICT_MATERIAL_HASH, concurrency = 4 } = {}) {
  const pending = [...rows];
  if (!pending.length) return null;
  let cursor = 0;
  let failure = null;
  const worker = async () => {
    while (!failure) {
      const index = cursor;
      cursor += 1;
      if (index >= pending.length) return;
      const row = pending[index];
      try {
        const sha256 = strict || !cache ? await hashFile(row.path) : (await cache.digest(row)).sha256;
        if (sha256 !== row.sha256) failure = { row, reason: 'changed', actualSha256: sha256 };
      } catch (error) {
        failure = { row, reason: 'unreadable', message: error.message };
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, pending.length) }, worker));
  return failure;
}

export async function buildAssignments(videos, pages, description, onProgress = () => {}, linkPool = '', clipsPerPage = DEFAULT_CLIPS_PER_PAGE, pageCaptions = null) {
  if (!description.trim()) throw new AppError('DESCRIPTION_REQUIRED', '请填写发布文案。');
  if (pages.length < 1) throw new AppError('PAGE_REQUIRED', '请至少选择一个浏览器。');
  clipsPerPage = normalizeClipsPerPage(clipsPerPage);
  if (videos.length < pages.length * clipsPerPage) throw new AppError('MATERIAL_SHORTAGE', `所选 ${pages.length} 个主页需要 ${pages.length * clipsPerPage} 个视频，当前只有 ${videos.length} 个。`);
  // 逐主页文案：pageCaptions = { [pageId]: "标题\n\n链接" }
  // 该主页已给出独立文案时优先使用，否则退回通用 description 模板。
  const captionMap = pageCaptions && typeof pageCaptions === 'object' ? pageCaptions : null;
  const templateForPage = pageId => {
    if (!captionMap) return description;
    const value = captionMap[String(pageId)];
    return typeof value === 'string' && value.trim() ? value : description;
  };
  const promotion = preparePromotionLinks(description, linkPool);
  const selected = shuffle(videos).slice(0, pages.length * clipsPerPage);
  const assignments = [];
  for (let index = 0; index < selected.length; index += 1) {
    const video = selected[index];
    const pageIndex = Math.floor(index / clipsPerPage);
    const ownerPageId = pages[pageIndex]?.pageId;
    // 逐主页文案已经带好链接时，不再做链接池替换，避免覆盖用户设定的链接。
    const baseTemplate = templateForPage(ownerPageId);
    const perPageCopy = captionMap && baseTemplate !== description;
    const promotionUrl = !perPageCopy && promotion.sourceUrl && promotion.links.length
      ? promotion.links[crypto.randomInt(promotion.links.length)]
      : null;
    const publishText = renderDramaTemplate(
      perPageCopy ? baseTemplate : replacePromotionLink(baseTemplate, promotion.sourceUrl, promotionUrl),
      video.title,
    );
    if (index === 0 || (index + 1) % 25 === 0 || index + 1 === selected.length) {
      onProgress({ stage: 'hashing', current: index + 1, total: selected.length, file: video.basename });
    }
    assignments.push({ ...video, dramaTitle: video.title, title: publishText, description: publishText, ...(promotionUrl ? { promotionUrl } : {}), ...(perPageCopy ? { captionSource: 'perPage' } : {}), sha256: video.sha256 || await hashFile(video.path), slot: index % clipsPerPage + 1, pageId: ownerPageId });
  }
  return assignments;
}
