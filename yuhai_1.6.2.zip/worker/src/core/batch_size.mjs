import { AppError } from './errors.mjs';

export const DEFAULT_CLIPS_PER_PAGE = 6;
export const MIN_CLIPS_PER_PAGE = 1;
export const MAX_CLIPS_PER_PAGE = 20;

export function normalizeClipsPerPage(value) {
  if (value === undefined || value === null || value === '') return DEFAULT_CLIPS_PER_PAGE;
  const clipsPerPage = Number(value);
  if (!Number.isInteger(clipsPerPage) || clipsPerPage < MIN_CLIPS_PER_PAGE || clipsPerPage > MAX_CLIPS_PER_PAGE) {
    throw new AppError('INVALID_CLIPS_PER_PAGE', `每主页条数必须是 ${MIN_CLIPS_PER_PAGE} 到 ${MAX_CLIPS_PER_PAGE} 之间的整数。`);
  }
  return clipsPerPage;
}
