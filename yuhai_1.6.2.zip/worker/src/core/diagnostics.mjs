// Diagnostics only: these classifications never decide retries or publication.
export function describeFailure(error) {
  const message = String(error?.message || error || '未知错误')
    .replace(/((?:access_token|token|api[_-]?key|password)\s*[=:]\s*)[^\s&,;]+/gi, '$1[已隐藏]')
    .replace(/((?:authorization|cookie|set-cookie)\s*:\s*)[^\r\n]+/gi, '$1[已隐藏]');
  const rules = [
    [/upload stalled/i, 'UPLOAD_STALLED', '上传进度连续 60 秒没有变化'],
    [/upload input|file input|CDP upload input/i, 'UPLOAD_INPUT_UNAVAILABLE', '没有找到唯一可用的视频上传入口'],
    [/"risky"\s*:\s*[1-9]/i, 'COPYRIGHT_RISK', '平台显示版权风险，未继续提交'],
    [/upload or copyright check incomplete/i, 'UPLOAD_CHECK_INCOMPLETE', '上传或版权检查未完成'],
    [/file row count mismatch|unique video row/i, 'VIDEO_ROW_UNRECOGNIZED', '无法识别文件对应的唯一视频行'],
    [/caption input/i, 'CAPTION_INPUT_UNAVAILABLE', '标题或描述输入框数量不符合预期'],
    [/ROUND_STOP_SCHEDULE_POLICY_REJECTED|Meta rejected the schedule/i, 'SCHEDULE_REJECTED', '平台拒绝排期输入或未启用更新按钮'],
    [/schedule.*(?:missing|ambiguous|did not accept)|Unsupported platform date/i, 'SCHEDULE_CONTROL_UNAVAILABLE', '排期控件无法识别或未接受输入'],
    [/timeout|timed out/i, 'PAGE_OPERATION_TIMEOUT', '页面操作超时，具体等待对象见技术详情'],
    [/closed|disconnected/i, 'BROWSER_CONNECTION_LOST', '浏览器页面已关闭或连接中断'],
  ];
  const matched = rules.find(([pattern]) => pattern.test(message));
  return { diagnosticCode: matched?.[1] || error?.code || 'PUBLICATION_FAILED', reason: matched?.[2] || message.split(/\r?\n/)[0], message };
}
