import path from 'node:path';
import { RELEASE } from './version.mjs';
import { StateStore } from './core/state.mjs';
import { publicError, AppError } from './core/errors.mjs';
import { discoverHubstudio, foregroundEnvironment } from './core/hubstudio.mjs';
import { discoverManagedPages, inspectExistingMetaTabs } from './core/pages.mjs';
import { listVideos, listVideosMulti } from './core/materials.mjs';
import { normalizeClipsPerPage } from './core/batch_size.mjs';
import { invalidatePlanForDiscovery, replacePlanFromDiscovery } from './core/plans.mjs';
import { writeRunReports } from './core/reports.mjs';
import { projectUiRun, projectUiState } from './core/ui_state.mjs';
import {
  archiveRun,
  createRun,
  executeRun,
  reclaimUnsubmittedArchivedHashes,
  prepareArchivedEnvironmentReplacement,
  prepareEnvironmentContinuation,
  prepareSafeContinuation,
  requestEnvironmentStop,
  requestGlobalStop,
} from './core/publisher.mjs';

const dataDir = process.env.REELS_PUBLISHER_DATA_DIR;
const outputDir = process.env.REELS_PUBLISHER_OUTPUT_DIR;
if (!dataDir || !process.send) throw new Error('Worker must be started by the desktop application.');
const store = new StateStore(path.resolve(dataDir));
await store.load();
await reclaimUnsubmittedArchivedHashes(store);
if (store.project(state => state.currentRun?.state) === 'running') {
  await store.update(state => {
    state.currentRun.interruptedAt = new Date().toISOString();
    for (const page of state.currentRun.pages.filter(item => ['submission_intent', 'retrying', 'running', 'uploading', 'halted', 'paused'].includes(item.state))) {
      // 只有"可能已经点过发布"的页才按结果不确定处理，避免重复发布。
      // 纯上传阶段中断（submissionClickedAt 为空、无 acceptedAt、无 reviewEvidence）
      // 并未对平台产生任何提交，应回到可安全重试的状态，否则会永久漏发该主页。
      const outcomeUnknown = page.state === 'submission_intent'
        || Boolean(page.submissionClickedAt)
        || Boolean(page.acceptedAt)
        || Boolean(page.reviewEvidence)
        || page.error?.code === 'INTERRUPTED_OUTCOME_UNKNOWN'
        || /已点击发布|结果不确定/.test(page.stage || '');
      // halted/paused 页只有在上传阶段（upload_progress）失败、且从未点过发布时才自动放行；
      // 其它失败原因（风控、登录失效、素材/批次异常）保持 halted，交由人工确认。
      const uploadOnlyFailure = ['halted', 'paused'].includes(page.state)
        && !outcomeUnknown
        && page.error?.phase === 'upload_progress';
      if (outcomeUnknown) {
        page.state = 'halted'; page.stage = '程序中断，结果不确定，禁止自动重传';
        page.error ||= { code: 'INTERRUPTED_OUTCOME_UNKNOWN', message: '上次执行在提交过程中中断。' };
      } else if (page.state === 'halted' || page.state === 'paused') {
        if (!uploadOnlyFailure) continue;
        page.state = 'ready'; page.stage = '上传阶段中断（未提交），可安全重试';
        page.error = null; page.retryCount = 0;
        for (const assignment of state.currentRun.assignments.filter(row => String(row.pageId) === String(page.pageId))) {
          if (assignment.state !== 'completed') assignment.state = 'ready';
        }
      } else {
        page.state = 'ready'; page.stage = '程序中断于上传阶段，可安全重试';
        page.error = null;
        page.retryCount = 0;
        for (const assignment of state.currentRun.assignments.filter(row => String(row.pageId) === String(page.pageId))) {
          if (assignment.state !== 'completed') assignment.state = 'ready';
        }
      }
    }
    state.currentRun.state = state.currentRun.pages.some(item => item.state === 'ready') ? 'ready' : 'needs_attention';
    return state;
  });
}
let busy = false;
let manualLinkExportBusy = false;
const executionControl = { globalStop: false, environments: new Set(), activeEnvironments: new Set(), recoveringEnvironments: new Set(), running: false };

function progress(event) { process.send?.({ type: 'progress', event: { at: new Date().toISOString(), ...event } }); }
function uiState() {
  const state = store.project(projectUiState);
  return { ...state, release: RELEASE,
    execution: { activeEnvironmentIds: [...executionControl.activeEnvironments], recoveringEnvironmentIds: [...executionControl.recoveringEnvironments] },
    hasStoredRecords: state.hasStoredRecords };
}

async function saveReports() {
  const run = store.project(state => state.currentRun);
  if (!run || run.state === 'running') return null;
  try {
    const report = await writeRunReports(outputDir, run);
    if (store.project(state => state.currentRun?.id) === run.id) {
      await store.updateCurrentRun(current => ({ ...current, report }));
    }
    return report;
  } catch (error) {
    progress({ stage: `TXT 报告生成失败：${error.message}`, error: { code: 'REPORT_WRITE_FAILED', message: error.message } });
    return null;
  }
}

await saveReports();

async function refreshBrowserState(environmentId = null) {
  const hub = await discoverHubstudio();
  const environments = environmentId ? hub.environments.filter(item => item.environmentId === environmentId) : hub.environments;
  const tabs = await inspectExistingMetaTabs(environments);
  await store.update(state => {
    const results = environmentId ? [...(state.browserCheck?.results || []).filter(item => item.environmentId !== environmentId), ...tabs.results] : tabs.results;
    const readyTargets = new Map(tabs.results.filter(item => item.status === 'ready').map(item => [item.environmentId, item.targetId]));
    const browserCheck = {
      environments: hub.environments.map(({ endpoint, ...item }) => item),
      results,
      failedEnvironments: [...hub.failed, ...results.filter(item => item.status === 'failed')],
      checkedAt: new Date().toISOString(),
    };
    const discovery = state.discovery ? {
      ...state.discovery,
      pages: state.discovery.pages.map(page => ({
        ...page,
        environments: page.environments.map(environment => readyTargets.has(environment.environmentId)
          ? { ...environment, targetId: readyTargets.get(environment.environmentId) }
          : environment),
      })),
    } : null;
    const currentRun = state.currentRun ? {
      ...state.currentRun,
      pages: state.currentRun.pages.map(page => readyTargets.has(page.environmentId) ? { ...page, targetId: readyTargets.get(page.environmentId) } : page),
    } : null;
    return { ...state, browserCheck, discovery, currentRun };
  });
  return { ...store.project(state => ({ browserCheck: state.browserCheck })), environments };
}

async function request(command, payload) {
  // Window focus is independent of the publishing queue and its busy lock.
  if (command === 'switchEnvironment') return foregroundEnvironment(payload.environmentId);
  if (command === 'stopEnvironment') {
    executionControl.environments.add(payload.environmentId);
    progress({ environmentId: payload.environmentId, stage: '正在停止当前浏览器任务' });
    await requestEnvironmentStop(store, payload.environmentId);
    return uiState();
  }
  if (command === 'stopAll') {
    executionControl.globalStop = true;
    progress({ stage: '正在停止全部任务' });
    await requestGlobalStop(store);
    return uiState();
  }
  if (command === 'bootstrap' || command === 'status') return uiState();
  if (command === 'checkBrowsers') {
    if (busy) throw new AppError('BUSY', '发布任务正在执行。');
    const state = store.project(current => ({ pageDiscovery: current.pageDiscovery, discovery: current.discovery }));
    if (state.pageDiscovery?.status !== 'ready' || !state.discovery?.pages?.length) {
      throw new AppError('PAGE_DISCOVERY_REQUIRED', '请先获取 Page ID，再检查浏览器。');
    }
    busy = true;
    try {
      progress({ stage: '正在检查当前打开的浏览器' });
      await refreshBrowserState();
      return uiState();
    } finally { busy = false; }
  }
  if (command === 'recoverEnvironment') {
    const whileRunning = executionControl.running;
    const environmentId = payload.environmentId;
    if (busy && !whileRunning) throw new AppError('BUSY', '请等待当前操作完成。');
    if (executionControl.recoveringEnvironments.has(environmentId)) throw new AppError('BUSY', '该环境正在恢复，请勿重复点击。');
    const assertRecoverable = () => {
      if (executionControl.activeEnvironments.has(environmentId)) throw new AppError('ENVIRONMENT_STOPPING', '该环境尚未安全停止，请稍后恢复；其他环境无需停止。');
      if (whileRunning && (executionControl.globalStop || !executionControl.enqueueEnvironment)) throw new AppError('BUSY', '调度器正在启动或全部停止中，请稍后恢复。');
    };
    assertRecoverable();
    executionControl.recoveringEnvironments.add(environmentId);
    if (!whileRunning) busy = true;
    try {
      progress({ environmentId: payload.environmentId, stage: '正在检查环境并恢复断点' });
      const snapshot = await refreshBrowserState(environmentId);
      const browser = snapshot.browserCheck?.results?.find(item => item.environmentId === payload.environmentId);
      if (browser?.status !== 'ready' || !browser.targetId) {
        throw new AppError('BROWSER_NOT_READY', browser?.error || `浏览器 ${payload.environmentId} 未打开，或没有唯一可用的 Meta 工作标签。`);
      }
      const recovery = await prepareEnvironmentContinuation(store, { environmentId, targetId: browser.targetId, allowRunning: whileRunning, assertRecoverable });
      executionControl.environments.delete(payload.environmentId);
      if (whileRunning) executionControl.enqueueEnvironment(snapshot.environments.find(item => item.environmentId === environmentId));
      else executionControl.globalStop = false;
      progress({ environmentId: payload.environmentId, stage: `已恢复 ${recovery.recovered} 个断点任务${whileRunning ? '，已加入当前并发队列' : ''}` });
      return uiState();
    } finally {
      executionControl.recoveringEnvironments.delete(environmentId);
      executionControl.wake?.();
      if (!whileRunning) busy = false;
    }
  }
  if (command === 'continueUnsuccessful') {
    if (busy) throw new AppError('BUSY', '请等待当前操作完成。');
    busy = true;
    try {
      progress({ stage: '正在检查浏览器并恢复本轮未成功任务' });
      const checked = await refreshBrowserState();
      const readyEnvironmentIds = (checked.browserCheck?.results || []).filter(item => item.status === 'ready' && item.targetId).map(item => item.environmentId);
      const recovery = await prepareSafeContinuation(store, { allowedEnvironmentIds: readyEnvironmentIds });
      if (!recovery.recovered) throw new AppError('NO_SAFE_CHECKPOINT', '本轮没有可安全重试的未成功主页；已点击发布或结果不确定的主页不会重复处理。');
      executionControl.globalStop = false;
      executionControl.environments.clear();
      progress({ stage: `已恢复 ${recovery.recovered} 个本轮未成功主页，成功主页已跳过` });
      return uiState();
    } finally { busy = false; }
  }
  if (command === 'replaceFailedEnvironment') {
    if (busy) throw new AppError('BUSY', '请等待当前操作完成。');
    busy = true;
    try {
      progress({ stage: `正在核验 ${payload.targetEnvironmentId} 接管 ${payload.sourceEnvironmentId} 的失败任务` });
      const result = await prepareArchivedEnvironmentReplacement(store, payload);
      progress({ stage: `已将 ${result.recovered} 个可安全重试主页迁移至 ${payload.targetEnvironmentId}` });
      return uiState();
    } finally { busy = false; }
  }
  if (command === 'discoverPages') {
    if (busy) throw new AppError('BUSY', '发布任务正在执行。');
    busy = true;
    let attemptedDiscovery = null;
    try {
      await store.update(state => invalidatePlanForDiscovery(state));
      progress({ stage: '正在读取 HubStudio 已打开环境' });
      const hub = await discoverHubstudio();
      const pages = await discoverManagedPages(hub.environments, { onProgress: progress });
      attemptedDiscovery = { ...pages, environments: hub.environments.map(({ endpoint, ...item }) => item), failedEnvironments: [...hub.failed, ...pages.results.filter(item => item.status === 'failed')], discoveredAt: hub.discoveredAt };
      await store.update(state => replacePlanFromDiscovery(state, attemptedDiscovery));
      return uiState();
    } catch (error) {
      await store.update(state => ({
        ...state,
        browserCheck: null,
        discovery: attemptedDiscovery,
        plan: null,
        bindings: {},
        currentRun: null,
        pageDiscovery: { ...state.pageDiscovery, status: 'failed', failedAt: new Date().toISOString(), code: error.code || 'PAGE_DISCOVERY_FAILED', message: error.message },
      }));
      throw error;
    } finally { busy = false; }
  }
  if (command === 'setBinding') {
    const page = store.project(state => state.discovery?.pages?.find(item => item.pageId === payload.pageId));
    if (!page?.environments.some(item => item.environmentId === payload.environmentId)) throw new AppError('INVALID_BINDING', '该主页不属于所选环境。');
    await store.update(state => ({ ...state, bindings: { ...state.bindings, [payload.pageId]: payload.environmentId } }));
    return uiState();
  }
  if (command === 'scanMaterials') {
    if (Array.isArray(payload.directories)) {
      const material = await listVideosMulti(payload.directories);
      return {
        groups: material.groups.map(group => ({ root: group.root, count: group.count, dramaCount: group.dramaCount, sampleTitle: group.videos[0]?.title || null })),
        total: material.total,
        folderCount: material.folderCount,
        sampleTitle: material.videos[0]?.title || null,
      };
    }
    const material = await listVideos(payload.directory);
    return { root: material.root, count: material.count, dramaCount: material.dramaCount, sampleTitle: material.videos[0]?.title || null };
  }
  if (command === 'start') {
    if (busy) throw new AppError('BUSY', '已有任务正在执行。');
    const clipsPerPage = normalizeClipsPerPage(payload.clipsPerPage);
    const skipCopyrightCheck = payload.skipCopyrightCheck === true;
    const uploadStallTimeoutSeconds = payload.uploadStallTimeoutSeconds;
    // 同一主页内多条视频的排期间隔（分钟）与逐条偏移
    const spacingMinutes = payload.spacingMinutes;
    const scheduleOffsets = payload.scheduleOffsets;
    busy = true;
    try {
      executionControl.globalStop = false;
      executionControl.environments.clear();
      if (store.project(state => state.currentRun?.state) !== 'ready') {
        await createRun({ store, directory: payload.directory, directories: payload.directories, publishMode: payload.publishMode, description: payload.description, linkPool: payload.linkPool, pageCaptions: payload.pageCaptions, selectedBrowserIds: payload.browserIds, skippedPageIds: payload.skippedPageIds, concurrency: payload.concurrency, clipsPerPage, skipCopyrightCheck, uploadStallTimeoutSeconds, spacingMinutes, scheduleOffsets, onProgress: progress });
      }
      const result = await executeRun({
        store,
        dataDir,
        concurrency: payload.concurrency,
        executionControl,
        onProgress: progress,
        shouldStopEnvironment: environmentId => executionControl.globalStop || executionControl.environments.has(environmentId),
      });
      await saveReports();
      let linkExport = null;
      if (payload.linkExport?.enabled && payload.linkExport.folder) {
        let run = null;
        try {
          run = store.project(state => state.currentRun);
          const { exportReelLinks } = await import('./core/link_export.mjs');
          linkExport = await exportReelLinks(store, run, payload.linkExport, { onProgress: progress });
        } catch (error) {
          progress({ stage: `视频链接提取失败：${error.message}`, error: { code: error.code || 'LINK_EXPORT_FAILED', message: error.message } });
          linkExport = {
            file: null, exported: 0, failures: [],
            failed: (run?.pages || []).filter(page => page.state === 'completed' || page.state === 'cleanup_failed' || page.acceptedAt).length,
            error: error.message,
          };
        }
      }
      const projected = projectUiRun(result);
      if (linkExport) projected.linkExport = linkExport;
      return projected;
    } finally { busy = false; }
  }
  if (command === 'exportReelLinksManual') {
    if (manualLinkExportBusy) throw new AppError('LINK_EXPORT_BUSY', '已有手动链接提取正在执行，请等待完成。');
    const outputFolder = typeof payload.outputFolder === 'string' ? payload.outputFolder.trim() : '';
    if (!outputFolder) throw new AppError('INVALID_OUTPUT_FOLDER', '请选择视频链接输出文件夹。');
    const projected = store.project(state => state.currentRun?.pages?.length ? state.currentRun.pages : state.discovery?.pages || []);
    const requestedIds = Array.isArray(payload.pageIds) ? new Set(payload.pageIds.map(String).filter(Boolean)) : null;
    let pages = [...projected];
    if (requestedIds?.size) {
      pages = pages.filter(page => requestedIds.has(String(page.pageId || '')) || requestedIds.has(String(page.profileId || '')));
    }
    if (payload.allCompletedOnly === true) {
      pages = pages.filter(page => page.state === 'completed' || page.state === 'cleanup_failed' || Boolean(page.acceptedAt));
    }
    if (!pages.length) {
      throw new AppError('LINK_EXPORT_NO_PAGES', requestedIds?.size
        ? '勾选的主页不在当前可提取列表中，请刷新后重试。'
        : '当前没有可提取的主页。请先获取 Page ID，或完成一轮发布后再试。');
    }
    manualLinkExportBusy = true;
    try {
      progress({ stage: `准备手动提取 ${pages.length} 个主页的链接`, source: 'manualLinkExport' });
      const { exportReelLinksForPages } = await import('./core/link_export.mjs');
      return await exportReelLinksForPages(pages, outputFolder, {
        onProgress: event => progress({ ...event, source: 'manualLinkExport' }),
        dataDir,
        // 默认跳过已导出过的链接；前端可显式传 skipExported:false 强制全量重导。
        skipExported: payload.skipExported !== false,
        runId: store.project(state => state.currentRun?.id || null),
      });
    } finally {
      manualLinkExportBusy = false;
    }
  }
  if (command === 'archiveRun') {
    await saveReports();
    await archiveRun(store);
    return uiState();
  }
  if (command === 'clearHistory') {
    if (busy) throw new AppError('BUSY', '发布任务正在执行，暂时不能清空全部记录。');
    await store.update(state => ({
      ...state,
      bindings: {},
      plan: null,
      browserCheck: null,
      discovery: null,
      pageDiscovery: null,
      currentRun: null,
      history: [],
      usedHashes: [],
    }));
    executionControl.globalStop = false;
    executionControl.environments.clear();
    return uiState();
  }
  if (command === 'shutdown') {
    await store.flushScheduled();
    return { stopped: true };
  }
  throw new AppError('UNKNOWN_COMMAND', '未知操作。');
}

process.on('message', async message => {
  if (!message || typeof message.id !== 'string') return;
  try {
    const value = await request(message.command, message.payload || {});
    if (message.command === 'shutdown') {
      process.send?.({ id: message.id, ok: true, value }, () => process.exit(0));
      return;
    }
    process.send?.({ id: message.id, ok: true, value });
  } catch (error) { process.send?.({ id: message.id, ok: false, error: publicError(error) }); }
});
process.send({ type: 'ready' });
