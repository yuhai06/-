// Shared by the form preview and task creation; never fetch or visit these URLs.
function invalid(message) {
  return Object.assign(new Error(message), { code: 'INVALID_LINK_POOL' });
}

export function preparePromotionLinks(template, input = '') {
  const lines = Array.isArray(input) ? input : typeof input === 'string' ? input.split(/\r?\n/) : null;
  if (!lines || lines.some(line => typeof line !== 'string')) throw invalid('推广链接池格式错误，请每行填写一个完整链接。');
  const links = [];
  for (const [index, line] of lines.entries()) {
    const value = line.trim();
    if (!value) continue;
    let url;
    try { url = new URL(value); } catch { /* Report the line number, not a potentially sensitive URL. */ }
    if (!/^https?:\/\//i.test(value) || /[\s<>"{}\\]/u.test(value) || !url?.hostname || url.username || url.password) {
      throw invalid(`推广链接池第 ${index + 1} 行无效：请只填写一个完整的 http:// 或 https:// 链接，不要填写说明或 Markdown。`);
    }
    if (!links.includes(value)) links.push(value);
  }
  if (!links.length) return { links, sourceUrl: null };
  // The template may or may not carry a promotion link. Without one the pool is
  // simply not applied: the original copy is used verbatim instead of failing.
  const matches = String(template).match(/https?:\/\/[^\s<>"{}\p{Extended_Pictographic}]+/giu) || [];
  const urls = [...new Set(matches.map(value => value.replace(/[.,!?;:，。！？；：、）)\]】]+$/u, '')))];
  if (urls.length > 1) throw invalid('文案包含多个不同链接，请只保留需要随机替换的一个推广链接。');
  if (!urls.length) return { links, sourceUrl: null };
  try {
    const url = new URL(urls[0]);
    if (!url.hostname || url.username || url.password || urls[0].includes('\\')) throw new Error();
  } catch { throw invalid('文案中的推广链接无效，请检查完整的 http:// 或 https:// 地址。'); }
  return { links, sourceUrl: urls[0] };
}

export function replacePromotionLink(template, sourceUrl, selectedUrl) {
  return sourceUrl && selectedUrl ? template.split(sourceUrl).join(selectedUrl) : template;
}
