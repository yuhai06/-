import { META_LABELS, ACTION_ALIASES, COPYRIGHT_SAFE, COPYRIGHT_RISK, metaButton } from './meta_locale.mjs';
import { normalizeDigits, scheduleControls, SCHEDULE_HOUR_LABEL } from './meta_schedule.mjs';

const DESCRIPTION = '[contenteditable="true"][role="textbox"]';
const TITLE = 'textarea:visible,input:not([type]):visible,input[type="text"]:visible';

export async function findVideoCard(page, row) {
  let node = page.getByText(row.file_name, { exact: true });
  if (await node.count() !== 1) throw new Error(`File row count mismatch: ${row.file_name}`);
  for (let level = 0; level < 14; level += 1) {
    const descriptions = await node.locator(DESCRIPTION).count();
    if (descriptions > 1) break; // Never climb into the whole batch.
    if (descriptions === 1 && await node.getByRole('button').count() > 0) return node;
    node = node.locator('..');
  }
  throw new Error(`Could not identify unique video row: ${row.file_name}`);
}

export async function captionFields(page, rows) {
  const result = [];
  for (const row of rows) {
    const card = await findVideoCard(page, row);
    const description = card.locator(`${DESCRIPTION}:visible`);
    const title = card.locator(TITLE);
    if (await description.count() !== 1 || await title.count() > 1) throw new Error('Caption input count mismatch inside video row');
    result.push({ description, title: await title.count() ? title : null });
  }
  return result;
}

export async function readComposerUpload(page, rows) {
  // One bounded DOM read per polling cycle; do not repeatedly lay out the whole
  // page or count copyright progress bars as separate uploaded videos.
  const observed = await page.evaluate(({ filenames, description }) => {
    const names = new Set(filenames);
    const matches = new Map();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const text = walker.currentNode.textContent.trim();
      if (names.has(text)) {
        const list = matches.get(text) || [];
        list.push(walker.currentNode.parentElement);
        matches.set(text, list);
      }
    }
    return filenames.map(filename => {
      const matchesForFile = matches.get(filename) || [];
      if (matchesForFile.length !== 1) return null;
      let row = matchesForFile[0];
      for (let depth = 0; row && depth < 14; depth += 1, row = row.parentElement) {
        const count = row.querySelectorAll(description).length;
        if (count > 1) return null;
        if (count !== 1 || !row.querySelector('button,[role="button"]')) continue;
        const clone = row.cloneNode(true);
        for (const field of clone.querySelectorAll(`${description},textarea,input`)) field.remove();
        const text = (clone.textContent || '').replace(filename, '');
        const progress = [...row.querySelectorAll('[role="progressbar"],progress')].flatMap(element => {
          const value = element.getAttribute('aria-valuenow') ?? element.getAttribute('value');
          return value === null || !value.trim() ? [] : [Number(value)];
        });
        return { text, progress };
      }
      return null;
    });
  }, { filenames: rows.map(row => row.file_name), description: DESCRIPTION });
  const percentages = [];
  const files = [];
  let safe = 0, risky = 0;
  for (const [index, row] of observed.entries()) {
    const fileName = rows[index].file_name;
    if (!row) { files.push({ fileName, percentage: null, issue: '未识别到唯一视频行' }); continue; }
    const text = normalizeDigits(row.text);
    const values = [...text.matchAll(/(?:^|[^\d])(\d{1,3})\s*[%٪]/g)].map(match => Number(match[1])).filter(value => value <= 100);
    // Exactly one percentage is the normal composer representation. A lone
    // progressbar supports layouts which omit the textual percentage.
    let percentage = null;
    if (values.length === 1) percentage = values[0];
    else if (!values.length && row.progress.length === 1 && Number.isFinite(row.progress[0])) percentage = row.progress[0];
    if (percentage !== null) percentages.push(percentage);
    files.push({ fileName, percentage, ...(percentage === null ? { issue: '上传进度缺失或不唯一' } : {}) });
    safe += [...text.matchAll(COPYRIGHT_SAFE)].length ? 1 : 0;
    risky += [...text.matchAll(COPYRIGHT_RISK)].length ? 1 : 0;
  }
  return { percentages, safe, risky, files };
}

/**
 * 把动作名编译成「允许被截断」的正则。
 *
 * ⚠ 2026-11-13 回退修正（用户："之前不是可以排期吗怎么现在不可以了"）：
 *   11-12 我加了这个函数替换 META_LABELS，本意是容忍 Meta 把
 *   「立即发布」渲染成「立即...」。但实测导致排期整批失败
 *   （Schedule trigger missing or ambiguous），原因：
 *     · labelPattern 用 `^(?:...)$` 全串锚定 + 只允许末尾省略号，
 *       而 META_LABELS 原本就带着 \u200b-\u200f 零宽字符容错，
 *       我又在正则里重复叠加，实际匹配行为反而变窄
 *     · 更关键：getByRole({name: RegExp}) 的匹配目标可能是
 *       accessible name，中间可能夹着图标文本，全串锚定就对不上
 *
 *   现在策略改成「双保险」：
 *     ① 首选 META_LABELS 的原始正则（已知可用）
 *     ② 匹配不到时，退回 labelPattern 的宽松版（容忍截断）
 *   两条都不中才报错，最大限度避免"以前能用现在不能"。
 */
function labelPattern(action) {
  const raw = ACTION_ALIASES[action] || (typeof action === 'string' ? [action] : []);
  const labels = Array.isArray(raw) ? raw : [String(raw)];
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*');
  const alts = labels.map(esc).join('|');
  // 不锚定结尾：允许「立即发布」被截断成「立即...」或后面跟图标文字
  return new RegExp(
    `^[\\s\\u200b-\\u200f]*(?:${alts})(?:[\\s\\u200b-\\u200f.,、…·]*|.*(?:\\.{2,}|…).*)$`,
    'i');
}

/** 组合：原始精确正则 + 宽松截断正则，任一命中即可 */
function labelAny(action) {
  const exact = META_LABELS[action];
  const loose = labelPattern(action);
  return { exact, loose };
}

/**
 * 拟人节奏参数。
 *
 * 实机反馈（2026-11-12）：排期那段脚本跑得太快 —— 点开下拉、选「定时发布」、
 * 立刻开始填日期时间，全程不到 1 秒。真人操作一个下拉至少要看一眼、停顿、
 * 再点；填时间也要一行行输入。太快会被平台的行为模型认出来。
 *
 * 这里给排期链路加三档随机停顿（三角分布，偏中值，比均匀分布更像人）：
 *   AFTER_OPEN   点开下拉后的阅读停顿
 *   BETWEEN_LINES 逐行处理多条视频之间的间隔
 *   BEFORE_TYPE  填日期/时间前的准备停顿
 */
const HUMAN_DELAY = {
  afterOpen: [900, 2200],
  afterSelect: [600, 1600],
  betweenLines: [1200, 3200],
  beforeType: [500, 1400],
  afterType: [400, 1100],
};

function humanJitter([lo, hi]) {
  // 三角分布，峰值在中点 —— 比均匀分布更接近真人的停顿分布
  const mid = (lo + hi) / 2;
  const u = Math.random();
  const c = (mid - lo) / (hi - lo);
  return u < c
    ? lo + Math.sqrt(u * (hi - lo) * (mid - lo))
    : hi - Math.sqrt((1 - u) * (hi - lo) * (hi - mid));
}

async function humanWait(page, key) {
  const range = HUMAN_DELAY[key];
  if (!range) return;
  const ms = Math.round(humanJitter(range));
  await page.waitForTimeout(ms);
}

/** 供 browser_worker_lib 复用（排期主循环的逐行间隔） */
export async function humanPace(page, key = 'betweenLines') {
  await humanWait(page, key);
}

/**
 * 稳健点击 + 拟人节奏。
 *
 * ⚠ 实机教训（2026-11-12）：
 *   Meta 的 <div role="button"> 带持续动画，`locator.click()` 会一直等
 *   "element is stable"（连续两帧 bounding box 不变），等不到就抛
 *   `locator.click: Timeout 120000ms exceeded`。
 *   这就是排期失败的真正原因 —— 不是选择器错了，是点击方式错了。
 *   报错日志里选择器明明 "locator resolved to"，卡在 click 上。
 *
 * 顺序：force click → 页面内派发完整指针事件 → 标准 click 兜底。
 */
async function robustClick(locator) {
  // 兼容 Locator 与 ElementHandle：两者都有 click/evaluate，但 evaluate 签名不同
  const isHandle = typeof locator.evaluate === 'function'
    && typeof locator.dispose === 'function';

  try {
    await locator.click({ timeout: 30000, force: true, noWaitAfter: true });
    return true;
  } catch { /* 走下一个 */ }
  try {
    if (isHandle) {
      const ok = await locator.evaluate(el => {
        el.scrollIntoView({ block: 'center', inline: 'center' });
        const r = el.getBoundingClientRect();
        const base = {
          bubbles: true, cancelable: true, view: window, button: 0,
          clientX: r.x + r.width / 2, clientY: r.y + r.height / 2,
        };
        el.dispatchEvent(new PointerEvent('pointerdown', { ...base, buttons: 1 }));
        el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
        el.dispatchEvent(new PointerEvent('pointerup', { ...base, buttons: 0 }));
        el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
        el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
        return true;
      });
      if (ok) return true;
    } else {
      const ok = await locator.evaluateAll(els => {
        if (els.length !== 1) return false;
        const el = els[0];
        el.scrollIntoView({ block: 'center', inline: 'center' });
        const r = el.getBoundingClientRect();
        const base = {
          bubbles: true, cancelable: true, view: window, button: 0,
          clientX: r.x + r.width / 2, clientY: r.y + r.height / 2,
        };
        el.dispatchEvent(new PointerEvent('pointerdown', { ...base, buttons: 1 }));
        el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
        el.dispatchEvent(new PointerEvent('pointerup', { ...base, buttons: 0 }));
        el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
        el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
        return true;
      });
      if (ok) return true;
    }
  } catch { /* 走下一个 */ }
  await locator.click({ timeout: 30000 });
  return true;
}

export async function openSchedulePanel(page, row) {
  const card = await findVideoCard(page, row);
  let trigger = card.locator('button[aria-haspopup],button[aria-expanded],[role="button"][aria-haspopup],[role="button"][aria-expanded]').and(card.locator(':visible'));

  // ⚠ 2026-11-13 双保险匹配（修"以前能排期现在不能"）：
  //   ① 先用 META_LABELS 的原始精确正则（已知可用）
  //   ② 没有命中再用 labelPattern 的宽松版（容忍截断）
  //   两条都试过才判定失败，并把实际找到的按钮名打印出来便于排查。
  const buildNamed = (pat) => card.getByRole('button', { name: pat })
    .or(card.getByRole('button', { name: pat }))
    .and(card.locator(':visible'));

  const variants = [];
  for (const action of ['publishNow', 'schedulingOptions', 'schedule', 'scheduled']) {
    const { exact, loose } = labelAny(action);
    if (exact) variants.push(exact);
    variants.push(loose);
  }
  let named = null;
  for (const pat of variants) {
    const cand = card.getByRole('button', { name: pat }).and(card.locator(':visible'));
    const n = await cand.count().catch(() => 0);
    if (n >= 1) { named = cand; break; }
  }
  if (!named) named = buildNamed(labelPattern('publishNow'));

  if (await trigger.count() !== 1 || await named.count() > 0 && await trigger.and(named).count() !== 1) {
    trigger = named;
  }
  if (await trigger.count() !== 1) {
    // 把当前卡片里所有按钮名 dump 出来，便于定位 Meta 到底渲染成了什么
    let found = [];
    try {
      found = await card.getByRole('button').evaluateAll(
        els => els.map(e => (e.getAttribute('aria-label') || e.innerText || '').trim())
                  .filter(Boolean).slice(0, 12));
    } catch { /* ignore */ }
    throw new Error(
      `Schedule trigger missing or ambiguous: ${row.file_name}; buttons=${JSON.stringify(found)}`);
  }

  const choiceVariants = [];
  {
    const { exact, loose } = labelAny('schedule');
    if (exact) choiceVariants.push(exact);
    choiceVariants.push(loose);
  }
  let choice = null;
  for (const pat of choiceVariants) {
    const cand = page.getByRole('button', { name: pat })
      .or(page.getByRole('radio', { name: pat }))
      .or(page.getByRole('menuitem', { name: pat }))
      .and(page.locator(':visible'));
    const n = await cand.count().catch(() => 0);
    if (n >= 1) { choice = cand; break; }
  }
  if (!choice) {
    choice = page.getByRole('button', { name: labelPattern('schedule') })
      .or(page.getByRole('radio', { name: labelPattern('schedule') }))
      .or(page.getByRole('menuitem', { name: labelPattern('schedule') }))
      .and(page.locator(':visible'));
  }
  const existing = await choice.elementHandles();
  try {
    // 点开下拉前先"看一眼"（拟人停顿）
    await humanWait(page, 'beforeType');
    await robustClick(trigger);
    // 点开后等面板渲染 + 阅读停顿（原来这里几乎立刻就去点选项，太快）
    await humanWait(page, 'afterOpen');
    const openedChoice = choice.and(page.locator('[data-testid="ContextualLayerRoot"] *,[role="dialog"] *,[role="menu"] *,[aria-pressed],[role="radio"],[role="menuitem"]'));
    // ⚠ 2026-11-13：原来只给 10 秒。但前面 beforeType(500-1400ms)
    //   + afterOpen(900-2200ms) 的拟人停顿就吃掉 2-4 秒，
    //   剩下 6 秒等 Meta 渲染下拉面板经常不够 → 报"没有选项出现"。
    //   放宽到 30 秒（只是上限，面板一出现立刻选中，不会真等满）。
    const deadline = Date.now() + 30000;
    let selected = false;
    while (Date.now() < deadline) {
      // Previously scheduled video rows also say Schedule/Programmer. Only
      // the opened layer or a mode toggle is a scheduling choice.
      const count = await openedChoice.count();
      if (count > 1) throw new Error(`Schedule option missing or ambiguous: ${count} choices in open panels`);
      if (count === 1) {
        await robustClick(openedChoice);
        selected = true;
        await humanWait(page, 'afterSelect');
        break;
      }
      // Legacy unlabelled popups: require the one newly visible element, not
      // a pre-existing row trigger, and never select by first/nth position.
      const candidates = await choice.elementHandles();
      try {
        const fresh = [];
        for (const candidate of candidates) {
          if (!await candidate.evaluate((element, previous) => previous.includes(element), existing)) fresh.push(candidate);
        }
        if (fresh.length > 1) throw new Error(`Schedule option missing or ambiguous: ${fresh.length} newly visible choices`);
        if (fresh.length === 1) {
          // 直接点这个元素句柄（robustClick 兼容 Locator 与 ElementHandle）
          await robustClick(fresh[0]);
          selected = true;
          await humanWait(page, 'afterSelect');
          break;
        }
      } finally { await Promise.all(candidates.map(candidate => candidate.dispose())); }
      await page.waitForTimeout(200);
    }
    if (!selected) throw new Error('Schedule option missing or ambiguous: no choice appeared in the opened panel');
  } finally { await Promise.all(existing.map(element => element.dispose())); }
  // The clock reader also accepts localized legacy text inputs. Do not apply a
  // second, Chinese/English-only filter before it gets to inspect the controls.
  await page.locator('input[role="spinbutton"],input[type="number"]')
    .or(page.getByLabel(SCHEDULE_HOUR_LABEL).and(page.locator('input')))
    .and(page.locator(':visible')).first().waitFor({ state: 'visible', timeout: 20000 });
}

export async function scheduleUpdateControl(page) {
  const controls = await scheduleControls(page);
  const ancestors = controls.date.locator('xpath=ancestor::*');
  const checked = [];
  // XPath results are in document order: inspect nearest ancestors first.
  // Real Meta puts Update 20 ancestors above the date. Bound this by the
  // composer/semantic panel, never an arbitrary number of wrapper divs.
  for (let index = await ancestors.count() - 1; index >= 0; index -= 1) {
    const panel = ancestors.nth(index);
    if (await panel.evaluate((element, description) => element.matches('body,html,main,[role="main"]')
      || Boolean(element.querySelector(description)), DESCRIPTION)) break;
    const inputs = panel.locator('input');
    if (!await inputs.and(controls.hour).count() || !await inputs.and(controls.minute).count()) continue;
    const named = metaButton(panel, 'update');
    const count = await named.count();
    if (count === 1) return { controls, panel, update: named };
    if (count > 1) throw new Error(`Schedule update button missing or ambiguous: ${count} matching Update buttons inside schedule panel`);
    // Toggle buttons select publishing mode. The sole remaining panel button
    // applies that mode. Never infer this from a button's screen position.
    const action = panel.getByRole('button').and(panel.locator(':not([aria-pressed]):not([aria-haspopup]):visible'));
    const actions = await action.count();
    const panelSemantics = await panel.locator('[aria-pressed],[role="radio"]').count()
      || await panel.evaluate(element => element.matches('section,[role="dialog"]'));
    if (actions === 1 && panelSemantics && !await action.and(metaButton(panel, '发布')).count()) return { controls, panel, update: action };
    if (actions) checked.push(await action.allTextContents());
    if (await panel.getAttribute('role') === 'dialog') break;
  }
  throw new Error(`Schedule update button missing or ambiguous: candidates=${JSON.stringify(checked).slice(0, 700)}`);
}

export async function updateSchedulePanel(page) {
  const { controls, panel, update } = await scheduleUpdateControl(page);
  const started = Date.now();
  while (Date.now() - started < 5000 && await update.isDisabled()) await page.waitForTimeout(100);
  if (await update.isDisabled()) {
    const message = (await panel.innerText()).slice(0, 1200);
    throw new Error(`ROUND_STOP_SCHEDULE_POLICY_REJECTED: Meta disabled the schedule update; ${message}`);
  }
  await update.click({ timeout: 10000 });
  // This confirms the editing action, not a new opinion about the target time.
  await controls.date.waitFor({ state: 'hidden', timeout: 10000 });
}
