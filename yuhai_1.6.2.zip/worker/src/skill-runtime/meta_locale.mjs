export { scheduleDateCandidates, fillScheduleInputs } from './meta_schedule.mjs';

// Text fallback for controls without unique structural semantics. Every alias
// uses the same workflow; page language never selects a different publishing flow.
export const ACTION_ALIASES = {
  publishNow: ['立即发布', '立即發佈', '立即發布', 'Publish now', 'Publicar ahora', 'Publicar agora', 'Terbitkan sekarang', 'Publikasikan sekarang', 'Đăng ngay', 'เผยแพร่ตอนนี้'],
  remove: ['移除', 'Remove', 'Eliminar', 'Quitar', 'Remover', 'Hapus', 'Xóa', 'นำออก', 'ลบ'],
  schedule: ['发定时帖', '排程', '排定發佈時間', 'Schedule', 'Schedule post', 'Programar', 'Programar publicación', 'Agendar', 'Programar publicação', 'Jadwalkan', 'Lên lịch', 'กำหนดเวลา'],
  schedulingOptions: ['发布选项', '發佈選項', 'Scheduling options', 'Opciones de programación', 'Opções de programação', 'Opsi penjadwalan', 'Tùy chọn lên lịch', 'ตัวเลือกการกำหนดเวลา'],
  update: ['更新', 'Update', 'Actualizar', 'Atualizar', 'Perbarui', 'Cập nhật', 'อัปเดต'],
  scheduled: ['已定时', '已排程', 'Scheduled', 'Programado', 'Programados', 'Programadas', 'Agendado', 'Agendados', 'Terjadwal', 'Đã lên lịch', 'กำหนดเวลาไว้'],
  发布: ['发布', '發佈', '發布', 'Publish', 'Publicar', 'Terbitkan', 'Publikasikan', 'Đăng', 'เผยแพร่'],
  关闭: ['关闭', '關閉', 'Close', 'Cerrar', 'Fechar', 'Tutup', 'Đóng', 'ปิด'],
  取消: ['取消', 'Cancel', 'Cancelar', 'Batal', 'Hủy', 'ยกเลิก'],
  完成: ['完成', 'Done', 'Listo', 'Concluir', 'Concluído', 'Selesai', 'Xong', 'เสร็จสิ้น'],
  more: ['更多', 'More', 'Más', 'Mais', 'Lainnya', 'Xem thêm', 'เพิ่มเติม'],
  create: ['创建', '建立', 'Create', 'Crear', 'Criar', 'Buat', 'Tạo', 'สร้าง'],
  bulk: ['批量上传 Reels', '批量上传 Reel', '大量上傳 Reels', '批次上傳 Reels', 'Bulk upload reels', 'Bulk upload reel', 'Subir reels en lote', 'Subir reels de forma masiva', 'Carga masiva de reels', 'Carregar reels em massa', 'Carregar reels em lote', 'Upload massal reel', 'Unggah reel secara massal', 'Tải lên hàng loạt thước phim', 'อัปโหลดคลิป Reels หลายรายการ'],
  loadMore: ['加载更多', '載入更多', 'Load more', 'Cargar más', 'Carregar mais', 'Muat lainnya', 'Muat lebih banyak', 'Tải thêm', 'โหลดเพิ่มเติม'],
  managedPages: ['你管理的公共主页', '管理的公共主页', '你管理的粉絲專頁', 'Pages you manage', 'Páginas que administras', 'Páginas que você gerencia', 'Halaman yang Anda kelola', 'Trang bạn quản lý', 'เพจที่คุณจัดการ'],
};

// French aliases include the labels captured from the failed live composer.
const french = {
  publishNow: ['Publier maintenant'], remove: ['Supprimer'], schedule: ['Programmer', 'Programmer une publication'],
  schedulingOptions: ['Options de programmation'], update: ['Mettre à jour'], scheduled: ['Programmé', 'Programmée'],
  发布: ['Publier'], 关闭: ['Fermer'], 取消: ['Annuler'], 完成: ['Terminé'],
  more: ['Plus'], create: ['Créer'], bulk: ['Importer des reels de façon groupée'],
  loadMore: ['Charger plus', 'Voir plus'], managedPages: ['Pages que vous gérez'],
};
for (const [name, labels] of Object.entries(french)) ACTION_ALIASES[name].push(...labels);

// Exact-label vocabulary, not proof of end-to-end support for every variant.
// Jadwal is from the user's Indonesian bulk-upload screenshot (2026-10-01).
// Keep short/full translations together; never broaden to substring matching
// or treat draft, save, next, share and publish as interchangeable actions.
const additionalAliases = {
  publishNow: ['马上发布', '即刻发布', '現在發佈', '立刻發佈', 'Post now', 'Publicar imediatamente', 'Đăng ngay bây giờ', 'เผยแพร่ทันที'],
  schedule: [
    '定时发布', '定时', '排期', '定時發佈', '定時發布', '排定', '排定時間', '排定發佈',
    'Schedule a post', 'Schedule publication', 'Schedule reel', 'Schedule reels',
    'Programar una publicación', 'Programar publicaciones', 'Agendar publicação', 'Agendar uma publicação',
    'Jadwal', 'Jadwalkan postingan', 'Jadwalkan reel', 'Lên lịch đăng', 'Lên lịch bài viết', 'Đặt lịch',
    'ตั้งเวลา', 'ตั้งเวลาเผยแพร่', 'Planifier', 'Planifier une publication',
  ],
  schedulingOptions: [
    '排期选项', '定时选项', '排程選項', '發佈選項和編輯', 'Publishing options', 'Publication options',
    'Opciones de publicación', 'Opções de publicação', 'Opções de agendamento',
    'Opsi penerbitan', 'Opsi publikasi', 'Tùy chọn đăng', 'Tùy chọn xuất bản', 'ตัวเลือกการเผยแพร่', 'Options de publication',
  ],
  update: ['更新排期', 'Update schedule', 'Actualizar programación', 'Atualizar agendamento', 'Perbarui jadwal', 'Mettre à jour la programmation'],
  scheduled: [
    '已排期', '已排定', '已排定時間', 'Programada', 'Agendada', 'Agendadas', 'Dijadwalkan', 'Sudah dijadwalkan',
    'Đã đặt lịch', 'ตั้งเวลาแล้ว', 'Programmés', 'Programmées', 'Planifié', 'Planifiée',
  ],
  完成: ['Finished', 'Completed', 'Finalizar', 'Finalizado', 'Concluída', 'Terminer', 'Terminée'],
  bulk: [
    '批量上传短视频', '大量上傳 Reel', '批次上傳 Reel', 'Upload reels in bulk',
    'Subida masiva de reels', 'Subir varios reels', 'Carregar vários reels', 'Carregamento de reels em massa',
    'Reel unggahan massal', 'Unggah massal reel', 'Unggah reels secara massal', 'Upload massal reels',
    'Tải lên hàng loạt reels', 'Tải lên hàng loạt video Reels', 'อัปโหลด Reels หลายรายการ', 'Importer des reels en masse',
  ],
  loadMore: ['显示更多', '顯示更多', 'View more', 'Show more', 'Mostrar más', 'Mostrar mais', 'Tampilkan lainnya', 'Tampilkan lebih banyak', 'Hiển thị thêm', 'แสดงเพิ่มเติม'],
};
for (const [name, labels] of Object.entries(additionalAliases)) ACTION_ALIASES[name].push(...labels);

const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*');
export const META_LABELS = Object.fromEntries(Object.entries(ACTION_ALIASES).map(([name, values]) =>
  [name, new RegExp(`^[\\s\\u200b-\\u200f]*(?:${values.map(escape).join('|')})[\\s\\u200b-\\u200f]*$`, 'i')]));

export const TITLE_SELECTOR = 'textarea[placeholder*="标题"],textarea[placeholder*="title" i],input[placeholder*="标题"],input[placeholder*="title" i],textarea[aria-label*="title" i],input[aria-label*="title" i]';
export const COPYRIGHT_SAFE = /未发现版权问题|未發現版權問題|No copyright (?:issues|problems)(?: (?:were )?(?:found|detected))?|No se (?:han )?(?:encontrado|detectado|encontraron|detectaron) problemas (?:de|relacionados con) derechos de autor|Nenhum problema de direitos autorais|Não (?:foram encontrados|há) problemas de direitos autorais|Tidak (?:ditemukan|ada) masalah hak cipta|Không (?:phát hiện|có) vấn đề (?:về )?bản quyền|ไม่พบปัญหาลิขสิทธิ์|Aucun problème de droits d['’]auteur (?:n['’]a été (?:trouvé|détecté)|détecté)/gi;
export const COPYRIGHT_RISK = /你的\s*Reels?\s*可能会被屏蔽|Reels?\s*可能会受到限制|可能會遭到封鎖|可能會受到限制|(?:Your\s+)?Reels?\s+may\s+be\s+(?:blocked|restricted)|reels?[^\n]{0,40}(?:bloquead[oa]s?|restringid[oa]s?|restrit[oa]s?)|reel[^\n]{0,40}(?:diblokir|dibatasi)|thước phim[^\n]{0,40}(?:bị chặn|bị hạn chế)|Reels[^\n]{0,40}(?:ถูกบล็อก|ถูกจำกัด)|(?:votre|vos)\s+reels?[^\n]{0,40}(?:bloqu[ée]s?|restreints?|limit[ée]s?)/gi;
export const SUBMIT_FAILURE = /无法处理你的所有\s*Reels|無法處理你(?:的)?所有\s*Reels|(?:we\s+)?(?:couldn['’]t|can['’]t|cannot|could not|unable to)\s+process\s+all\s+(?:of\s+)?your\s+reels|no (?:pudimos|podemos|se pudieron) procesar todos (?:tus|los) reels|não (?:foi possível|conseguimos) processar todos (?:os )?(?:seus )?reels|tidak dapat memproses semua reel|không thể xử lý tất cả (?:các )?thước phim|ไม่สามารถประมวลผลคลิป Reels ทั้งหมด/i;
export const BULK_PROCESSING = /批量上传处理中|大量上傳處理中|Bulk upload(?: is)?(?: being)? (?:in progress|processing|processed)|(?:carga|subida) (?:masiva|en lote)[^\n]{0,30}(?:procesando|proceso)|carregamento em (?:massa|lote)[^\n]{0,30}(?:processamento|andamento)|upload massal[^\n]{0,30}(?:diproses|berlangsung)|đang xử lý tải lên hàng loạt|กำลังประมวลผลการอัปโหลด/i;
export const CONTENT_FAILURE = /发布失败|發佈失敗|(?:failed to|couldn['’]t|could not) publish|publishing failed|not published|no se pudo publicar|error al publicar|falha (?:ao|na) publica[çc][ãa]o|não foi possível publicar|gagal (?:menerbitkan|dipublikasikan)|đăng không thành công|không thể đăng|เผยแพร่ไม่สำเร็จ/i;
export const ACCEPTANCE_RECEIPT = /你的\s*Reels?\s*将根据选定的发布选项分享|你的\s*Reels?\s*將根據選擇的發佈選項分享|正在处理你的帖子|正在處理你的帖子|请稍等\.{0,3}$|your\s+reels?\s+will\s+be\s+shared\s+(?:according\s+to\s+the|based\s+on\s+your)\s+selected\s+publishing\s+options|processing\s+your\s+post|tus reels se compartirán (?:según|de acuerdo con) las opciones de publicación seleccionadas|procesando tu publicación|seus reels serão compartilhados de acordo com as opções de publicação selecionadas|processando sua publicação|reel Anda akan dibagikan sesuai (?:dengan )?opsi penerbitan yang dipilih|memproses kiriman Anda|thước phim của bạn sẽ được chia sẻ theo (?:các )?tùy chọn đăng đã chọn|đang xử lý bài đăng của bạn|Vos reels seront partagés en fonction des options de publication que vous avez sélectionnées|traitement de votre publication/i;
export const BLOCKED_TEXT = /安全检查|安全檢查|验证身份|驗證身分|確認你的身分|确认你的身份|访问拒绝|拒絕存取|拒绝访问|验证码|驗證碼|你又可以使用 Facebook 了|账[户号](?:已恢复使用|暂时停用)|temporarily blocked|account.{0,20}(?:locked|suspended|restored)|you can use Facebook again|(?:confirm|verify) your identity|security check|access denied|captcha|(?:confirma|verifica) tu identidad|acceso denegado|confirme sua identidade|verifique sua identidade|acesso negado|konfirmasi identitas|verifikasi identitas|akses ditolak|xác (?:nhận|minh) danh tính|quyền truy cập bị từ chối|ยืนยันตัวตน|ถูกปฏิเสธการเข้าถึง/i;
export const UNAVAILABLE_CONTENT = /很抱歉[，,]?\s*目前无法显示内容|目前無法顯示此內容|链接可能已过期|Sorry,?\s*this content (?:isn't|is not) available|link you followed may have expired|(?:este )?contenido no está disponible|(?:este )?conteúdo não está disponível|konten ini tidak tersedia|nội dung này (?:hiện )?không (?:khả dụng|hiển thị)|เนื้อหานี้ไม่พร้อมใช้งาน/i;

export function metaButton(page, name) {
  return page.getByRole('button', { name: META_LABELS[name] || name, exact: true }).and(page.locator(':visible'));
}

/**
 * 点 Meta 的动作按钮（发布 / 分享 / 完成 …）。
 *
 * 为什么不能只用 Playwright 的 button.click()：
 *   Meta 的按钮是 <div role="button"> 套 <span> 文本，外层带 aria-busy
 *   和持续的 layout 动画。Playwright 的 click 会等 "element is stable"
 *   （连续两帧 bounding box 不变），在这种按钮上经常永远等不到 ——
 *   实机表现就是 120 秒超时，但截图里按钮明明是可见可点的。
 *
 * ★ 实机验证的关键发现（2026-11-12）：
 *   ① CDP Input.dispatchMouseEvent 发出的点击**不会触发 Meta 的提交**
 *      （坐标正确、按钮可点，但页面毫无反应，等 20 秒也没变）
 *   ② Playwright click() 在稳定性检查上卡死
 *   ③ DOM el.click() 同样不触发提交
 *   → 唯一有效的是 Playwright 的 click，但必须先绕过稳定性检查。
 *     因此这里用 noWaitAfter + 短超时 + force 组合。
 *
 * 另外：点完之后必须**验证**，不能假设成功。
 *   以前点一下就 return，结果按钮没被真正按下，内核照样报
 *   submission_button_clicked，把失败当成功（假成功）。
 *
 * 策略：
 *   ① Playwright force click（跳过稳定性和可操作性检查，这是唯一真能触发的）
 *   ② 若 ① 抛错，用 elementHandle + evaluate 在页面里派发完整的
 *      指针事件序列（pointerdown/mousedown/pointerup/mouseup/click）
 *   ③ 最后退回不加 force 的标准 click（长超时兜底）
 *
 * 唯一性判据保持不变：count !== 1 直接抛错，绝不按位置猜按钮。
 */
export async function clickMetaButton(page, name) {
  const button = metaButton(page, name);
  const count = await button.count();
  if (count !== 1) throw new Error(`${name} button count mismatch: ${count}`);

  // ① Playwright force click —— 实机唯一有效的路径
  try {
    await button.first().click({ timeout: 30000, force: true, noWaitAfter: true });
    await page.waitForTimeout(800);
    return { method: 'playwright-force' };
  } catch (e1) {
    // 落到 ②
  }

  // ② 页面内派发完整指针事件序列（不是裸 el.click()，那不管用）
  try {
    const ok = await button.evaluateAll(els => {
      if (els.length !== 1) return false;
      const el = els[0];
      el.scrollIntoView({ block: 'center', inline: 'center' });
      const r = el.getBoundingClientRect();
      const x = r.x + r.width / 2;
      const y = r.y + r.height / 2;
      const base = { bubbles: true, cancelable: true, clientX: x, clientY: y,
                     view: window, button: 0, buttons: 1 };
      el.dispatchEvent(new PointerEvent('pointerover', base));
      el.dispatchEvent(new PointerEvent('pointerenter', base));
      el.dispatchEvent(new MouseEvent('mouseover', base));
      el.dispatchEvent(new MouseEvent('mouseenter', base));
      el.dispatchEvent(new PointerEvent('pointerdown', base));
      el.dispatchEvent(new MouseEvent('mousedown', base));
      el.dispatchEvent(new PointerEvent('pointerup', { ...base, buttons: 0 }));
      el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
      el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
      return true;
    });
    if (ok) {
      await page.waitForTimeout(800);
      return { method: 'pointer-sequence' };
    }
  } catch { /* 走 ③ */ }

  // ③ 标准 click，长超时兜底
  await button.first().click({ timeout: 90000 });
  return { method: 'playwright-standard' };
}

export function displayedScheduleLabels(parts) {
  const hour = Number(parts.hour);
  const date = new Date(`${parts.year}-${parts.month}-${parts.day}T12:00:00Z`);
  const dates = [ `${Number(parts.month)}月${Number(parts.day)}日`, ...['en-US', 'en-GB', 'es', 'pt-BR', 'id', 'vi', 'th'].flatMap(locale =>
    ['short', 'long'].map(month => new Intl.DateTimeFormat(locale, { timeZone: 'UTC', calendar: 'gregory', month, day: 'numeric' }).format(date))) ];
  const times = [`${parts.hour}:${parts.minute}`, `${hour}:${parts.minute}`, `${hour % 12 || 12}:${parts.minute} ${hour >= 12 ? 'PM' : 'AM'}`];
  return dates.flatMap(day => [' ', ', ', ' at '].flatMap(separator => times.map(time => `${day}${separator}${time}`)));
}

export function matchesDisplayedSchedule(text, labels) {
  const normalized = String(text).replace(/\s+/g, ' ').toLowerCase();
  return labels.some(label => {
    const index = normalized.indexOf(label.toLowerCase());
    const end = index + label.length;
    return index >= 0 && (index === 0 || !/[\d\w]/.test(normalized[index - 1]))
      && (end === normalized.length || !/\d/.test(normalized[end]))
      && (/ (?:AM|PM)$/.test(label) || !/^\s*(?:am|pm)\b/.test(normalized.slice(end)));
  });
}
