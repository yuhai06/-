import fs from 'node:fs';
import path from 'node:path';
import { META_LABELS, SUBMIT_FAILURE, BULK_PROCESSING, CONTENT_FAILURE, ACCEPTANCE_RECEIPT, UNAVAILABLE_CONTENT, metaButton, clickMetaButton, displayedScheduleLabels, matchesDisplayedSchedule } from './meta_locale.mjs';
import { captionFields, readComposerUpload, openSchedulePanel, updateSchedulePanel, humanPace } from './meta_controls.mjs';
import { readPlatformSchedule, addPlatformMinutes, platformDateTime, fillScheduleInputs } from './meta_schedule.mjs';

const DEFAULT_SCHEDULE_TIME_ZONE = process.env.FB_SCHEDULE_TIME_ZONE || 'America/New_York';
const COPYRIGHT_CHECK_TIMEOUT_MS = 300_000;
export const DEFAULT_UPLOAD_STALL_TIMEOUT_SECONDS = 180;

export function evaluateUploadCopyrightGate({ percentages, safe, risky, batchSize, copyrightCheckStartedAt = null, now = Date.now(), skipCopyrightCheck = false }) {
  const allUploadsComplete = percentages.length >= batchSize && percentages.every((value) => value === 100);
  if (risky > 0) return { status: 'risky', copyrightCheckStartedAt };
  if (!allUploadsComplete) return { status: 'uploading', copyrightCheckStartedAt: null };
  if (skipCopyrightCheck) return { status: 'safe', copyrightCheckStartedAt };
  if (safe >= batchSize) return { status: 'safe', copyrightCheckStartedAt };
  const startedAt = copyrightCheckStartedAt ?? now;
  return {
    status: now - startedAt >= COPYRIGHT_CHECK_TIMEOUT_MS ? 'timeout' : 'pending',
    copyrightCheckStartedAt: startedAt,
  };
}

async function uploadNetworkSnapshot(page) {
  try {
    return await page.evaluate(() => performance.getEntriesByType('resource')
      .filter((entry) => ['xmlhttprequest', 'fetch'].includes(entry.initiatorType))
      .filter((entry) => /upload|rupload/i.test(entry.name))
      .slice(-20)
      .map((entry) => {
        let name = entry.name;
        try { const url = new URL(entry.name); name = `${url.origin}${url.pathname}`; } catch { /* Keep the original value. */ }
        return {
          name, initiatorType: entry.initiatorType, startTime: Math.round(entry.startTime),
          duration: Math.round(entry.duration), transferSize: entry.transferSize,
          encodedBodySize: entry.encodedBodySize, decodedBodySize: entry.decodedBodySize,
        };
      }));
  } catch { return []; }
}

async function setLocalInputFilesOverCdp(context, page, filePaths) {
  const session = await context.newCDPSession(page);
  try {
    const document = await session.send('DOM.getDocument', { depth: 1, pierce: true });
    const input = await session.send('DOM.querySelector', {
      nodeId: document.root.nodeId,
      selector: 'input[type="file"]',
    });
    if (!input.nodeId) throw new Error('CDP upload input node is unavailable');
    await session.send('DOM.setFileInputFiles', { files: filePaths, nodeId: input.nodeId });
  } finally {
    await session.detach().catch(() => {});
  }
}

function zonedDateTimeParts(date, timeZone) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  return Object.fromEntries(parts.map((part) => [part.type, part.value]));
}

function displayedScheduleTimeZone(bodyText, fallback) {
  const timeZones = bodyText.match(/\b(?:Africa|America|Antarctica|Arctic|Asia|Atlantic|Australia|Europe|Indian|Pacific)\/[A-Za-z0-9_+\-/]+\b/g) || [];
  return timeZones.at(-1) || fallback;
}

function recordedScheduleParts(record) {
  if (record.target_kind !== 'platform_local') return zonedDateTimeParts(new Date(record.target_at), record.time_zone);
  const [year, month, day] = record.date.split('-');
  return { year, month, day, hour: String(record.hour).padStart(2, '0'), minute: String(record.minute).padStart(2, '0') };
}

async function applyPlatformSchedule(page, target, timeZone) {
  await fillScheduleInputs(page, target);
  await updateSchedulePanel(page);
  return {
    target_at: platformDateTime(target), target_kind: 'platform_local',
    time_zone: timeZone, date: `${target.year}-${target.month}-${target.day}`,
    hour: Number(target.hour), minute: Number(target.minute),
  };
}

async function clickExactRoleButton(page, text) {
  await clickMetaButton(page, text);
}

async function dismissReportedFailureAndCancelComposer(page, progress) {
  await progress('post_submit_failure_dialog_detected', { uploadAttempted: true, submissionAttempted: true, evidencePage: page });
  await clickExactRoleButton(page, '关闭');
  await progress('post_submit_failure_dialog_closed', { uploadAttempted: true, submissionAttempted: true });
  await page.waitForTimeout(500);
  await clickExactRoleButton(page, '取消');
  await progress('post_submit_composer_cancelled', { uploadAttempted: true, submissionAttempted: true });
  await page.waitForTimeout(1200);
}

async function waitForUploadInput(page, timeoutMs = 30000) {
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    if (await page.locator('input[type="file"]').count() === 1) return true;
    await page.waitForTimeout(1000);
  }
  return false;
}

async function waitForVisibleCandidate(page, candidates, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const locator of candidates) {
      const visible = locator.and(page.locator(':visible'));
      const count = await visible.count().catch(() => 0);
      if (count > 1) throw new Error('Meta action is ambiguous; refusing to select a button by position');
      if (count === 1) return visible;
    }
    await page.waitForTimeout(500);
  }
  return null;
}

async function isUnavailableContentPage(page) {
  const body = await page.locator('body').innerText().catch(() => '');
  return UNAVAILABLE_CONTENT.test(body);
}

async function waitForUploadInputOrUnavailable(page, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await page.locator('input[type="file"]').count() === 1) return 'input';
    if (await isUnavailableContentPage(page)) return 'unavailable';
    await page.waitForTimeout(750);
  }
  return 'timeout';
}

async function visibleAssetName(page) {
  const combos = page.getByRole('combobox');
  const count = await combos.count();
  if (!count) return null;
  const index = await combos.evaluateAll((elements) => elements.findIndex((element) => {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.left < 320 && rect.top < 200;
  }));
  if (index >= 0) return (await combos.nth(index).innerText()).trim();
  if (count === 1) return (await combos.first().innerText()).trim();
  return null;
}

async function openBulkComposerFromMenu(
  context,
  errorPage,
  assetId,
  businessId,
  verifiedHomePage = null,
  expectedPageName = null,
  expectedTimeZone = DEFAULT_SCHEDULE_TIME_ZONE,
) {
  const home = businessId
    ? `https://business.facebook.com/latest/?asset_id=${assetId}&business_id=${businessId}&global_scope_id=${businessId}`
    : `https://business.facebook.com/latest/?asset_id=${assetId}`;
  let homePage = verifiedHomePage && !verifiedHomePage.isClosed()
    ? verifiedHomePage
    : context.pages().find((candidate) => (
      candidate !== errorPage
      && candidate.url().includes('business.facebook.com/latest/')
      && !candidate.url().includes('bulk_upload_composer')
    ));
  if (!homePage || homePage.isClosed()) {
    // Reuse the current tab when it is the only live tab. Closing it before
    // opening a replacement can make HubStudio terminate the environment.
    homePage = !errorPage.isClosed() ? errorPage : null;
  }
  if (!homePage) throw new Error('The existing Meta Business Suite work tab is unavailable');
  homePage.setDefaultTimeout(120000);
  await homePage.goto(home, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await homePage.waitForTimeout(4000);

  const currentUrl = new URL(homePage.url());
  const currentAssetId = currentUrl.searchParams.get('asset_id') || currentUrl.searchParams.get('page_id');
  if (currentAssetId !== String(assetId)) {
    throw new Error(`Public Page home asset mismatch before bulk-upload fallback: expected ${assetId}, got ${currentAssetId || 'missing'}`);
  }
  if (businessId) {
    const expectedBusinessId = String(businessId);
    const currentBusinessId = currentUrl.searchParams.get('business_id');
    const currentGlobalScopeId = currentUrl.searchParams.get('global_scope_id');
    const observedBusinessIds = [currentBusinessId, currentGlobalScopeId].filter(Boolean);
    if (
      !observedBusinessIds.includes(expectedBusinessId)
      || observedBusinessIds.some((value) => value !== expectedBusinessId)
    ) {
      throw new Error(
        `Business portfolio mismatch before bulk-upload fallback: expected ${expectedBusinessId}, `
        + `business_id=${currentBusinessId || 'missing'}, global_scope_id=${currentGlobalScopeId || 'missing'}`,
      );
    }
  }
  if (expectedPageName) {
    const observedPageName = await visibleAssetName(homePage);
    if (observedPageName !== expectedPageName) {
      throw new Error(
        `Public Page visible identity mismatch before bulk-upload fallback: expected ${expectedPageName}, `
        + `got ${observedPageName || 'missing'}`,
      );
    }
  }

  // On the current Page home, Meta normally exposes Bulk upload Reels under
  // “更多 / More”. Some layouts still expose the same item under “创建 / Create”.
  // Prefer the user-confirmed More menu and retain Create only as a layout fallback.
  const menuButton = await waitForVisibleCandidate(homePage, [
    homePage.getByRole('button', { name: META_LABELS.more }),
    homePage.getByRole('link', { name: META_LABELS.more }),
    homePage.getByRole('button', { name: META_LABELS.create }),
    homePage.getByRole('link', { name: META_LABELS.create }),
  ], 20000);
  if (!menuButton) throw new Error('More/Create menu button missing for bulk-upload fallback');
  await menuButton.click();

  const batchUpload = await waitForVisibleCandidate(homePage, [
    homePage.locator('a[href*="/latest/bulk_upload_composer"]'),
    homePage.getByRole('menuitem', { name: META_LABELS.bulk }),
    homePage.getByRole('button', { name: META_LABELS.bulk }),
    homePage.getByRole('link', { name: META_LABELS.bulk }),
  ], 15000);
  if (!batchUpload) throw new Error('Bulk upload Reels menu item missing after opening More/Create menu');
  const pagesBefore = new Set(context.pages());
  await batchUpload.click();
  await homePage.waitForTimeout(1500);

  let composerPage = homePage;
  const openedPage = context.pages().find((candidate) => !pagesBefore.has(candidate));
  if (openedPage) composerPage = openedPage;
  composerPage.setDefaultTimeout(120000);
  if (!await waitForUploadInput(composerPage, 30000)) {
    throw new Error('Bulk upload Reels menu opened, but upload input did not appear');
  }
  return composerPage;
}

export async function processPublicPageBatch({
  context,
  rows,
  assetId,
  businessId,
  page: suppliedPage = null,
  fallbackPage = null,
  expectedPageName = null,
  uploadInputMode = 'playwright_transfer',
  composerOpenMode = 'direct',
  singleRowScheduleTarget = null,
  scheduleTimeZone = DEFAULT_SCHEDULE_TIME_ZONE,
  onProgress = null,
  shouldStop = null,
  submissionConfirmationMode = 'receipt',
  stopBeforeSubmit = false,
  skipCopyrightCheck = false,
  uploadStallTimeoutSeconds = DEFAULT_UPLOAD_STALL_TIMEOUT_SECONDS,
  publishAllNow = false,
  spacingMinutes = 30,
  scheduleOffsets = null,
}) {
  const batchSize = rows.length;
  if (!context || batchSize < 1 || !assetId) throw new Error('Invalid page batch input');
  if (singleRowScheduleTarget && batchSize !== 1) {
    throw new Error('singleRowScheduleTarget requires exactly one recovery row');
  }
  if (!suppliedPage || suppliedPage.isClosed()) {
    throw new Error('The existing Meta Business Suite work tab is required');
  }
  let page = suppliedPage;
  const progress = async (stage, details = {}) => onProgress?.({ stage, ...details });
  const assertRunning = async () => {
    if (await shouldStop?.()) throw new Error('PUBLICATION_PAUSED');
  };
  await assertRunning();
  await progress('selecting_existing_meta_tab');
  page.setDefaultTimeout(120000);
  let effectiveBusinessId = businessId || null;
  const composerUrl = (portfolioId) => portfolioId
    ? `https://business.facebook.com/latest/bulk_upload_composer?asset_id=${assetId}&business_id=${portfolioId}&global_scope_id=${portfolioId}`
    : `https://business.facebook.com/latest/bulk_upload_composer?asset_id=${assetId}`;
  let menuFallbackError = null;
  let directOpenError = null;
  let composerState = null;
  let inputReady = false;
  let composer = composerUrl(effectiveBusinessId);
  if (composerOpenMode === 'menu_first') {
    try {
      page = await openBulkComposerFromMenu(
        context,
        page,
        assetId,
        effectiveBusinessId,
        fallbackPage,
        expectedPageName,
        scheduleTimeZone,
      );
      inputReady = true;
    } catch (error) {
      menuFallbackError = String(error?.message || error);
      if (page.isClosed()) throw new Error('The existing Meta Business Suite work tab was closed');
    }
  } else {
    try {
      await page.goto(composer, { waitUntil: 'domcontentloaded', timeout: 60000 });
      composerState = await waitForUploadInputOrUnavailable(page, 30000);
      inputReady = composerState === 'input';
      if (!inputReady) directOpenError = `Direct bulk-upload composer state: ${composerState}`;
    } catch (error) {
      directOpenError = `Direct bulk-upload composer failed: ${String(error?.message || error)}`;
    }
    if (!inputReady) {
      // The direct URL is not reliable for every Page. Return to the exact
      // Page inside the original business portfolio and use More/Create ->
      // Bulk upload Reels exactly once. Never discard business_id and retry.
      try {
        page = await openBulkComposerFromMenu(
          context,
          page,
          assetId,
          effectiveBusinessId,
          fallbackPage,
          expectedPageName,
          scheduleTimeZone,
        );
        inputReady = true;
      } catch (error) {
        menuFallbackError = String(error?.message || error);
        if (page.isClosed()) throw new Error('The existing Meta Business Suite work tab was closed');
      }
    }
  }
  await page.waitForTimeout(1200);

  const fileInput = page.locator('input[type="file"]');
  if (await fileInput.count() !== 1) {
    throw new Error(
      `Upload input count mismatch`
      + `${directOpenError ? `; ${directOpenError}` : ''}`
      + `${menuFallbackError ? `; one-time exact-portfolio menu fallback failed: ${menuFallbackError}` : ''}`,
    );
  }
  try {
    await assertRunning();
    await progress('upload_intent', { uploadAttempted: true, files: rows.map((row) => row.file_name || path.basename(row.clip_path)) });
    const uploadSourceRoot = process.env.FB_UPLOAD_SOURCE_ROOT
      ? path.resolve(process.env.FB_UPLOAD_SOURCE_ROOT)
      : null;
    const uploadAliasRoot = process.env.FB_UPLOAD_PATH_ALIAS_ROOT
      ? path.resolve(process.env.FB_UPLOAD_PATH_ALIAS_ROOT)
      : null;
    const filePaths = rows.map((row) => {
      const originalPath = path.resolve(row.clip_path);
      if (!uploadSourceRoot || !uploadAliasRoot) return originalPath;
      const relativePath = path.relative(uploadSourceRoot, originalPath);
      if (!relativePath || relativePath.startsWith('..') || path.isAbsolute(relativePath)) {
        throw new Error(`Upload alias cannot map source file: ${originalPath}`);
      }
      const aliasPath = path.join(uploadAliasRoot, relativePath);
      if (!fs.existsSync(aliasPath) || fs.statSync(aliasPath).size !== fs.statSync(originalPath).size) {
        throw new Error(`Upload alias file mismatch: ${aliasPath}`);
      }
      return aliasPath;
    });
    if (uploadInputMode === 'cdp_local_paths') {
      await setLocalInputFilesOverCdp(context, page, filePaths);
    } else {
      await fileInput.setInputFiles(filePaths, { timeout: 120000 });
    }
  } catch (error) {
    if (await page.locator('[contenteditable="true"][role="textbox"]').count() !== batchSize) throw error;
  }
  await progress('upload_files_set', { uploadAttempted: true, files: rows.map(row => row.file_name) });

  const uploadStartedAt = Date.now();
  let lastUploadLogAt = 0;
  let lastUploadLogSignature = null;
  let lastIncompletePercentages = null;
  let noProgressStartedAt = Date.now();
  let copyrightCheckStartedAt = null;
  let copyrightCheckTimedOut = false;
  let uploadState = {};
  const uploadStallTimeoutMs = Math.max(1, Number(uploadStallTimeoutSeconds) || DEFAULT_UPLOAD_STALL_TIMEOUT_SECONDS) * 1000;
  // Incomplete uploads retry after 60 seconds without progress. Once every
  // upload reaches 100%, copyright checks may wait up to five minutes. An
  // explicit risk warning still stops the batch; a silent timeout proceeds.
  while (true) {
    await assertRunning();
    uploadState = await readComposerUpload(page, rows);
    const { percentages, safe, risky } = uploadState;
    const gate = evaluateUploadCopyrightGate({ percentages, safe, risky, batchSize, copyrightCheckStartedAt, skipCopyrightCheck });
    copyrightCheckStartedAt = gate.copyrightCheckStartedAt;
    const now = Date.now();
    const logSignature = JSON.stringify([gate.status, percentages, safe, risky]);
    if (!lastUploadLogAt || now - lastUploadLogAt >= 30_000
      || logSignature !== lastUploadLogSignature && now - lastUploadLogAt >= 10_000) {
      await progress(gate.status === 'pending' ? 'copyright_check' : 'upload_progress', {
        uploadAttempted: true, upload: uploadState, batchSize,
        elapsedSeconds: Math.floor((now - uploadStartedAt) / 1000),
        copyrightWaitSeconds: copyrightCheckStartedAt === null ? 0 : Math.floor((now - copyrightCheckStartedAt) / 1000),
      });
      lastUploadLogAt = now; lastUploadLogSignature = logSignature;
    }
    if (gate.status === 'risky' || gate.status === 'safe') break;
    if (gate.status === 'timeout') {
      copyrightCheckTimedOut = true;
      uploadState.copyrightCheckTimedOut = true;
      await progress('copyright_check_timeout', { uploadAttempted: true, timeoutSeconds: COPYRIGHT_CHECK_TIMEOUT_MS / 1000 });
      break;
    }

    const hasCompletePercentageSet = percentages.length >= batchSize;
    const allUploadsComplete = hasCompletePercentageSet
      && percentages.every((value) => value === 100);
    if (!allUploadsComplete) {
      const signature = hasCompletePercentageSet
        ? percentages.join(',')
        : `visible-percentages:${percentages.join(',')}`;
      if (signature !== lastIncompletePercentages) {
        lastIncompletePercentages = signature;
        noProgressStartedAt = Date.now();
      } else if (Date.now() - noProgressStartedAt >= uploadStallTimeoutMs) {
        const error = new Error(`Upload stalled without progress for ${uploadStallTimeoutMs / 1000} seconds: ${JSON.stringify(uploadState)}`);
        error.upload = uploadState;
        error.uploadNetwork = await uploadNetworkSnapshot(page);
        throw error;
      }
    } else {
      lastIncompletePercentages = null;
      noProgressStartedAt = null;
    }
    // Keep the existing four-second cadence. Row-scoped snapshots avoid
    // forcing repeated full-page layouts in Meta's large composer.
    await page.waitForTimeout(4000);
  }
  if (
    uploadState.percentages?.length < batchSize
    || !uploadState.percentages.every((value) => value === 100)
    || uploadState.risky > 0
    || (uploadState.safe < batchSize && !copyrightCheckTimedOut && !skipCopyrightCheck)
  ) {
    const error = new Error(`Upload or copyright check incomplete: ${JSON.stringify(uploadState)}`);
    error.upload = uploadState;
    throw error;
  }
  await progress('upload_complete', { uploadAttempted: true, copyrightCheckTimedOut, upload: uploadState, batchSize });

  const fields = await captionFields(page, rows);
  const titleCount = fields.filter(field => field.title).length;
  if (![0, batchSize].includes(titleCount)) throw new Error(`Caption input count mismatch: titles=${titleCount}`);
  for (let index = 0; index < batchSize; index += 1) {
    const caption = rows[index].caption;
    const configuredTitle = typeof rows[index].title === 'string' && rows[index].title.trim()
      ? rows[index].title
      : null;
    const title = configuredTitle || (caption.length > 240 ? 'Watch the full series' : caption);
    const description = typeof rows[index].description === 'string' && rows[index].description.trim()
      ? rows[index].description
      : caption;
    if (title.length > 240) throw new Error(`Configured Reel title exceeds 240 characters: ${title.length}`);
    if (titleCount === batchSize) {
      await fields[index].title.fill(title);
    }
    await fields[index].description.fill(description);
  }
  await progress('captions_complete', { uploadAttempted: true });

  // Read Meta's original schedule control values once. Every subsequent slot
  // is that same wall-clock baseline + N intervals, irrespective of local
  // computer time, language, timezone or the time spent editing other rows.
  const schedule = [];
  let effectiveScheduleTimeZone = null;
  if (singleRowScheduleTarget) {
    // An explicitly requested recovery target retains its existing meaning.
    const requested = new Date(singleRowScheduleTarget);
    if (Number.isNaN(requested.getTime())) throw new Error('Invalid single-row recovery schedule target');
    await openSchedulePanel(page, rows[0]);
    const bodyText = await page.locator('body').innerText();
    const timeZone = displayedScheduleTimeZone(bodyText, scheduleTimeZone);
    const configured = await applyPlatformSchedule(page, zonedDateTimeParts(requested, timeZone), timeZone);
    effectiveScheduleTimeZone = timeZone;
    schedule.push({ ...configured, recovery_single_row: true });
  } else if (batchSize > 1 && !publishAllNow) {
    // 逐行设排期：第 2..N 条 = 平台基线 + slot × spacingMinutes
    //
    // spacingMinutes 由上层传入（默认 30）。用户可以在发布页按每个视频调整，
    // 例如 1 条立即发、第 2 条 +30min、第 3 条 +90min（不要求等距）。
    // scheduleOffsets 优先于 spacingMinutes：它是「第 i 条相对基线的分钟数」数组。
    const offsets = Array.isArray(scheduleOffsets) && scheduleOffsets.length
      ? scheduleOffsets
      : null;
    let base = null;
    for (let slot = 1; slot < batchSize; slot += 1) {
      await assertRunning();

      // 逐行之间插入拟人停顿（第一条不插，避免还没开始就等）
      if (slot > 1) await humanPace(page, 'betweenLines');

      await progress('schedule_intent', {
        uploadAttempted: true, slot: slot + 1, fileName: rows[slot].file_name,
      });
      await openSchedulePanel(page, rows[slot]);
      if (!base) {
        base = await readPlatformSchedule(page);
        effectiveScheduleTimeZone = displayedScheduleTimeZone(
          await page.locator('body').innerText(), null);
      }
      const offset = offsets
        ? Number(offsets[slot] ?? offsets[offsets.length - 1] ?? 30)
        : slot * spacingMinutes;
      const target = addPlatformMinutes(base, offset);
      const configured = await applyPlatformSchedule(page, target, effectiveScheduleTimeZone);
      schedule.push({
        ...configured, base_at: platformDateTime(base),
        base_source: 'platform_controls',
        spacing_minutes: spacingMinutes,
        effective_offset_minutes: offset,
      });
      await progress('schedule_updated', {
        uploadAttempted: true, slot: slot + 1,
        targetAt: configured.target_at, baseAt: platformDateTime(base),
      });
      // 填完一行后稍等再处理下一行
      await humanPace(page, 'afterType');
    }
  } else if (batchSize > 1 && publishAllNow) {
    await progress('schedule_skipped_all_now', {
      uploadAttempted: true, batchSize,
      note: '按 publishAllNow 跳过排期，全部立即发布',
    });
  }

  if (titleCount === batchSize) {
    for (let index = 0; index < batchSize; index += 1) {
      if (await fields[index].title.getAttribute('aria-invalid') === 'true') {
        await fields[index].title.fill(rows[index].title || rows[index].caption);
      }
    }
  }
  await assertRunning();
  if (stopBeforeSubmit) {
    await progress('ready_for_submission', { uploadAttempted: true, submissionAttempted: false });
    return {
      accepted: false,
      acceptance: 'prepared_not_submitted',
      page,
      schedule,
      submittedAt: null,
      submitOutcome: 'not_submitted',
    };
  }
  await progress('submission_button_intent', { uploadAttempted: true, submissionAttempted: false });
  await clickExactRoleButton(page, '发布');
  await progress('submission_button_clicked', { uploadAttempted: true, submissionAttempted: true });
  await page.waitForTimeout(1200);
  if (titleCount === batchSize) {
    let corrected = false;
    for (let index = 0; index < batchSize; index += 1) {
      if (await fields[index].title.getAttribute('aria-invalid') === 'true') {
        await fields[index].title.fill(rows[index].title || rows[index].caption);
        corrected = true;
      }
    }
    if (corrected) await clickExactRoleButton(page, '发布');
  }
  const submitStartedAt = Date.now();
  let outcome = null;
  let reportedFailureAt = null;
  const acceptanceReceipt = ACCEPTANCE_RECEIPT;
  while (Date.now() - submitStartedAt < 180000) {
    await assertRunning();
    if (page.url().includes('/content_calendar')) {
      outcome = 'redirected';
      break;
    }
    const body = await page.locator('body').innerText();
    if (submissionConfirmationMode === 'button_click') {
      // ⚠ 实机教训（2026-11-12，连发 3 条只有 1 条真的发出去）：
      //
      // 以前这里点完按钮等 1.2s，读一次 body 就 break，读不到任何回执时
      // 用 'button_clicked' 兜底，然后无条件 accepted:true。
      // 结果：按钮点空（没真按下去）、或编辑器残留导致 Meta 静默拒绝，
      // 全部被当成"发布成功"，Business Suite 里查不到，本地却删了母片。
      //
      // 现在改成：
      //   ① 循环轮询最多 90 秒，等真实回执（受理/处理中/完成/失败）
      //   ② 等到回执 → 按回执判定
      //   ③ 90 秒什么都没等到 → outcome = 'no_receipt'，不再当成成功
      //
      // Meta 批量上传器的可观测信号（按出现顺序）：
      //   "正在处理你的帖子 / 请稍等..."   ← 受理（遮罩出现）
      //   "你的 Reels 将根据选定的发布选项分享" ← 明确受理回执
      //   "批量上传处理中"                  ← 队列处理中
      //   "无法处理你的所有 Reels"          ← 明确失败
      const deadline = Date.now() + 90_000;
      let sawComposerGone = false;
      while (Date.now() < deadline) {
        await assertRunning();
        const u = page.url();
        if (u.includes('/content_calendar')) { outcome = 'redirected'; break; }
        if (!u.includes('bulk_upload_composer')) { sawComposerGone = true; }
        let text = '';
        try {
          text = await page.locator('body').innerText();
        } catch { /* 页面可能在导航，下一轮再读 */ }
        if (acceptanceReceipt.test(text)) { outcome = 'accepted_receipt'; break; }
        if (SUBMIT_FAILURE.test(text)) {
          outcome = 'reported_failed';
          await dismissReportedFailureAndCancelComposer(page, progress);
          break;
        }
        if (BULK_PROCESSING.test(text)) { outcome = 'done'; break; }
        // 编辑器消失也说明提交被接受（Meta 会跳到已发布列表或首页）
        if (sawComposerGone) { outcome = 'accepted_receipt'; break; }
        await page.waitForTimeout(1500);
      }
      if (!outcome) outcome = 'no_receipt';
      break;
    }
    if (acceptanceReceipt.test(body)) {
      outcome = 'accepted_receipt';
      break;
    }
    if (SUBMIT_FAILURE.test(body)) {
      reportedFailureAt ??= Date.now();
    }
    const doneCount = await metaButton(page, '完成').count();
    if (BULK_PROCESSING.test(body) && doneCount === 1) {
      outcome = 'done';
      break;
    }
    // Meta can retain an old “cannot process all Reels” banner even when this
    // batch was accepted. Give the current submission time to settle, then
    // verify the exact immediate caption and all scheduled captions/times.
    if (reportedFailureAt && Date.now() - reportedFailureAt >= 10_000) {
      outcome = 'reported_failed';
      break;
    }
    await page.waitForTimeout(1500);
  }
  if (submissionConfirmationMode === 'receipt' && outcome !== 'accepted_receipt') {
    throw new Error(`Meta submission acknowledgement was not observed; outcome=${outcome}`);
  }
  if (!['accepted_receipt', 'done', 'redirected', 'reported_failed', 'no_receipt'].includes(outcome)) throw new Error(`Batch submit outcome: ${outcome}`);

  // ⚠ no_receipt = 点了按钮但 90 秒内没等到任何回执。
  //   这种情况**必须报错**，不能当成"提交成功"——
  //   实机证明它可能意味着：按钮没真按下去、编辑器残留导致 Meta 静默拒绝。
  //   报错后上层会进 needs_attention，人工去 Business Suite 核对，
  //   而不是误以为发成功、把母片删掉。
  if (outcome === 'no_receipt') {
    throw new Error(
      'Meta submission acknowledgement was not observed within 90s after clicking publish '
      + '(no receipt: neither processing banner nor published confirmation appeared). '
      + 'The click may not have registered, or the composer was in a stale state. '
      + 'Verify in Business Suite before retrying.');
  }

  const submittedAt = new Date();
  if (submissionConfirmationMode === 'button_click' || outcome === 'accepted_receipt') {
    await progress('upload_accepted', { uploadAttempted: true, submissionAttempted: true, acceptance: 'upload_accepted' });
    const items = rows.map((row, index) => ({
      taskId: row.task_id || row.taskId || null,
      slot: Number(row.slot || index + 1),
      mode: index === 0 && !singleRowScheduleTarget ? 'immediate' : 'scheduled',
      targetAt: index === 0 && !singleRowScheduleTarget ? null : (singleRowScheduleTarget ? schedule[0]?.target_at : schedule[index - 1]?.target_at),
      timezone: schedule[index - 1]?.time_zone || effectiveScheduleTimeZone,
    }));
    return {
      page,
      assetId,
      businessId: effectiveBusinessId,
      businessIdUsed: effectiveBusinessId,
      contentId: null,
      submittedAt: submittedAt.toISOString(),
      schedule,
      items,
      acceptance: 'upload_accepted',
      accepted: true,
      receipt: outcome === 'accepted_receipt' ? 'meta_reels_selected_publishing_options' : null,
      submitOutcome: outcome,
    };
  }
  if (outcome === 'done') await clickExactRoleButton(page, '完成');
  await page.waitForTimeout(2200);

  const postsUrl = effectiveBusinessId
    ? `https://business.facebook.com/latest/posts/published_posts/?asset_id=${assetId}&business_id=${effectiveBusinessId}`
    : `https://business.facebook.com/latest/posts/published_posts/?asset_id=${assetId}`;
  await page.goto(postsUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
  let contentId = null;
  if (singleRowScheduleTarget) {
    const scheduledTarget = schedule[0];
    const parts = recordedScheduleParts(scheduledTarget);
    const expectedDisplayedTimes = displayedScheduleLabels(parts);
    const expectedCaption = String(rows[0].caption || '').replace(/\s+/g, ' ').trim();
    let exactScheduledRowFound = false;
    const verificationStartedAt = Date.now();
    while (Date.now() - verificationStartedAt < 45_000) {
      let scheduledTab = page.getByRole('tab', { name: META_LABELS.scheduled, exact: true });
      if (await scheduledTab.count() !== 1) {
        scheduledTab = metaButton(page, 'scheduled');
      }
      if (await scheduledTab.count() === 1) {
        await scheduledTab.click();
        await page.waitForTimeout(3500);
        const roleRows = await page.locator('[role="row"]').allInnerTexts().catch(() => []);
        const exactRowIndex = roleRows.findIndex((roleRow, index) => {
          const normalized = String(roleRow || '').replace(/\s+/g, ' ').trim();
          return index > 0
            && normalized.includes(expectedCaption)
            && matchesDisplayedSchedule(normalized, expectedDisplayedTimes)
            && !CONTENT_FAILURE.test(normalized);
        });
        if (exactRowIndex > 0) {
          const idLabels = await page.locator('input[aria-label]').evaluateAll(
            (elements) => elements.map((element) => element.getAttribute('aria-label')),
          );
          contentId = idLabels[exactRowIndex]?.match(/\d+/)?.[0] || null;
          exactScheduledRowFound = true;
          break;
        }
      }
      await page.goto(postsUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
      await page.waitForTimeout(2500);
    }
    if (!exactScheduledRowFound) {
      throw new Error('exact single-row scheduled recovery verification failed');
    }
    return {
      page,
      assetId,
      businessId: effectiveBusinessId,
      businessIdUsed: effectiveBusinessId,
      contentId,
      submittedAt: submittedAt.toISOString(),
      schedule,
      submitOutcome: outcome,
      scheduledOnlyRecovery: true,
    };
  }
  let exactImmediateRowFound = false;
  const immediateRecoveryTimeLabels = batchSize === 1
    ? Array.from({ length: 11 }, (_, index) => {
      const parts = zonedDateTimeParts(
        new Date(submittedAt.getTime() + (index - 5) * 60_000),
        scheduleTimeZone,
      );
      return displayedScheduleLabels(parts);
    }).flat()
    : [];
  const contentStartedAt = Date.now();
  while (Date.now() - contentStartedAt < 45000) {
    await page.waitForTimeout(3500);
    const roleRows = await page.locator('[role="row"]').allInnerTexts().catch(() => []);
    const expectedCaption = String(rows[0].caption || '').replace(/\s+/g, ' ').trim();
    const exactRowIndex = roleRows.findIndex((roleRow, index) => {
      const normalized = String(roleRow || '').replace(/\s+/g, ' ').trim();
      return index > 0
        && normalized.includes(expectedCaption)
        && (!immediateRecoveryTimeLabels.length
          || matchesDisplayedSchedule(normalized, immediateRecoveryTimeLabels));
    });
    const idLabels = await page.locator('input[aria-label]').evaluateAll(
      (elements) => elements.map((element) => element.getAttribute('aria-label')),
    );
    exactImmediateRowFound = exactRowIndex > 0;
    contentId = exactImmediateRowFound
      ? idLabels[exactRowIndex]?.match(/\d+/)?.[0] || null
      : null;
    if (contentId) break;
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 60000 });
  }
  if (!contentId || !exactImmediateRowFound) {
    throw new Error(
      `${outcome === 'reported_failed' ? 'Batch submit outcome: failed; ' : ''}`
      + 'exact immediate published content ID not found',
    );
  }

  if (outcome === 'reported_failed' && schedule.length) {
    let scheduledTab = page.getByRole('tab', { name: META_LABELS.scheduled, exact: true });
    if (await scheduledTab.count() !== 1) {
      scheduledTab = metaButton(page, 'scheduled');
    }
    if (await scheduledTab.count() !== 1) {
      throw new Error('Batch submit outcome: failed; exact scheduled-post verification tab missing');
    }
    await scheduledTab.click();
    await page.waitForTimeout(5000);
    const scheduledRoleRows = await page.locator('[role="row"]').allInnerTexts().catch(() => []);
    for (let index = 0; index < schedule.length; index += 1) {
      const scheduledCaption = String(rows[index + 1].caption || '').replace(/\s+/g, ' ').trim();
      const scheduledTarget = schedule[index];
      const parts = recordedScheduleParts(scheduledTarget);
      const expectedDisplayedTimes = displayedScheduleLabels(parts);
      const matches = scheduledRoleRows.filter((roleRow) => {
        const normalized = String(roleRow || '').replace(/\s+/g, ' ').trim();
        return normalized.includes(scheduledCaption) && matchesDisplayedSchedule(normalized, expectedDisplayedTimes);
      });
      if (
        matches.length !== 1
        || CONTENT_FAILURE.test(matches[0])
      ) {
        throw new Error(
          `Batch submit outcome: failed; exact scheduled row verification failed for slot ${index + 2}`,
        );
      }
    }
  }

  return {
    page,
    assetId,
    businessId: effectiveBusinessId,
    businessIdUsed: effectiveBusinessId,
    contentId,
    submittedAt: submittedAt.toISOString(),
    schedule,
    submitOutcome: outcome,
  };
}
