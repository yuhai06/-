import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

async function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(filePath, { highWaterMark: 4 * 1024 * 1024 })) hash.update(chunk);
  return hash.digest('hex').toUpperCase();
}

function isWithinRoot(filePath, rootPath) {
  const relative = path.relative(path.resolve(rootPath), path.resolve(filePath));
  return Boolean(relative) && !relative.startsWith('..') && !path.isAbsolute(relative);
}

function materialRoots(manifest) {
  const roots = Array.isArray(manifest.material_roots) && manifest.material_roots.length
    ? manifest.material_roots.map((item) => typeof item === 'string' ? item : item.root)
    : [manifest.material_root];
  return roots.filter(Boolean).map((root) => path.resolve(root));
}

function cleanupState(manifest, enabled) {
  const existing = manifest.source_material_cleanup || {};
  return {
    ...existing,
    mode: 'immediate_after_submission',
    enabled,
    status: enabled ? (existing.status || 'active') : 'disabled',
    files_deleted: Number(existing.files_deleted || 0),
    batches_processed: Number(existing.batches_processed || 0),
    failures: Array.isArray(existing.failures) ? existing.failures : [],
  };
}

async function writeCleanupState(manifestPath, manifest, state, updatedAt) {
  manifest.source_material_cleanup = { ...state, updated_at: updatedAt };
  manifest.last_execution_update = updatedAt;
  await fsp.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
}

async function recordFailure({ manifestPath, manifest, state, pageKey, result, at }) {
  state.status = 'partial_failure';
  state.batches_processed += 1;
  state.failures.push({ page_key: pageKey, ...result, at });
  await writeCleanupState(manifestPath, manifest, state, at);
  return result;
}

export function sourceMaterialDeletionEnabled(config = {}) {
  if (config.delete_source_after_submission === false) {
    throw new Error('The current workflow requires delete_source_after_submission=true');
  }
  return true;
}

export async function cleanupSubmittedSourceMaterials({ manifestPath, pageKey, enabled }) {
  const manifest = JSON.parse(await fsp.readFile(manifestPath, 'utf8'));
  const rows = manifest.assignments
    .filter((row) => row.page_key === pageKey)
    .sort((left, right) => left.slot - right.slot);
  const state = cleanupState(manifest, enabled);
  const now = new Date().toISOString();
  if (!enabled) return { status: 'disabled', files_deleted: 0 };
  if (!rows.length) return { status: 'skipped', files_deleted: 0, reason: 'page_assignments_not_found' };
  if (rows.length !== Number(manifest.clips_per_page || 6)) {
    return recordFailure({
      manifestPath, manifest, state, pageKey, at: now,
      result: { status: 'skipped', files_deleted: 0, reason: 'incomplete_page_batch' },
    });
  }
  if (rows.some((row) => !['published', 'scheduled'].includes(row.status))) {
    return { status: 'skipped', files_deleted: 0, reason: 'page_not_submitted_successfully' };
  }

  const roots = materialRoots(manifest);
  const candidates = new Map();
  for (const row of rows) {
    const rawPath = String(row.clip_path || '').trim();
    if (!rawPath) {
      return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: { status: 'skipped', files_deleted: 0, reason: 'clip_path_missing' },
      });
    }
    const clipPath = path.resolve(rawPath);
    const key = clipPath.toLocaleLowerCase('en-US');
    const entry = candidates.get(key) || { clipPath, rows: [] };
    entry.rows.push(row);
    candidates.set(key, entry);
  }

  const toDelete = [];
  for (const entry of candidates.values()) {
    if (entry.rows.every((row) => row.source_deleted_at)) continue;
    if (!roots.some((root) => isWithinRoot(entry.clipPath, root))) {
    return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: { status: 'skipped', files_deleted: 0, reason: 'clip_path_outside_material_roots', clip_path: entry.clipPath },
      });
    }
    let stat;
    try {
      stat = await fsp.stat(entry.clipPath);
    } catch (error) {
      return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: { status: 'skipped', files_deleted: 0, reason: `source_stat_failed:${error.code || error.message}`, clip_path: entry.clipPath },
      });
    }
    const expectedSizes = entry.rows.map((row) => Number(row.file_size)).filter(Number.isFinite);
    const expectedHashes = [...new Set(entry.rows.map((row) => String(row.clip_sha256 || '').toUpperCase()).filter(Boolean))];
    let actualHash = null;
    if (stat.isFile() && expectedHashes.length === 1) {
      try {
        actualHash = await sha256File(entry.clipPath);
      } catch (error) {
        return await recordFailure({
          manifestPath, manifest, state, pageKey, at: now,
          result: { status: 'skipped', files_deleted: 0, reason: `source_hash_read_failed:${error.code || error.message}`, clip_path: entry.clipPath },
        });
      }
    }
    const invalidReason = !stat.isFile()
      ? 'source_is_not_regular_file'
      : expectedSizes.some((size) => stat.size !== size)
        ? 'source_size_changed'
        : expectedHashes.length !== 1 || actualHash !== expectedHashes[0]
          ? 'source_hash_changed'
          : null;
    if (invalidReason) {
      return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: {
          status: 'skipped', files_deleted: 0, reason: invalidReason, clip_path: entry.clipPath,
          ...(invalidReason === 'source_size_changed' ? { expected_size: expectedSizes[0], actual_size: stat.size } : {}),
          ...(invalidReason === 'source_hash_changed' ? { expected_sha256: expectedHashes[0] || null, actual_sha256: actualHash } : {}),
        },
      });
    }
    toDelete.push(entry);
  }

  if (!toDelete.length) return { status: 'already_completed', files_deleted: 0 };

  const ledgerPath = path.join(path.dirname(manifestPath), 'source_material_deletion.jsonl');
  let filesDeleted = 0;
  for (const entry of toDelete) {
    try {
      // Keep deletion itself synchronous so a confirmed unlink is recorded
      // before the next ledger entry; the expensive hashing remains async.
      fs.unlinkSync(entry.clipPath);
    } catch (error) {
      state.files_deleted += filesDeleted;
      return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: { status: 'partial_failure', files_deleted: filesDeleted, reason: `source_delete_failed:${error.code || error.message}`, clip_path: entry.clipPath },
      });
    }
    filesDeleted += 1;
    for (const row of entry.rows) {
      row.source_deleted_at = now;
      row.source_deletion_method = 'source_material_unlinked_after_submission';
    }
    try {
      await fsp.appendFile(ledgerPath, `${JSON.stringify({
        round_id: manifest.round_id,
        page_key: pageKey,
        asset_id: entry.rows[0].asset_id,
        deleted_at: now,
        clip_path: entry.clipPath,
        deletion_method: 'source_material_unlinked_after_submission',
      })}\n`, 'utf8');
    } catch (error) {
      state.files_deleted += filesDeleted;
      return await recordFailure({
        manifestPath, manifest, state, pageKey, at: now,
        result: { status: 'partial_failure', files_deleted: filesDeleted, reason: `deletion_ledger_write_failed:${error.code || error.message}`, clip_path: entry.clipPath },
      });
    }
  }

  state.files_deleted += filesDeleted;
  state.batches_processed += 1;
  state.status = manifest.assignments.every((row) => Boolean(row.source_deleted_at)) ? 'completed' : 'active';
  await writeCleanupState(manifestPath, manifest, state, now);
  return { status: 'completed', files_deleted: filesDeleted, completed_at: now, deletion_ledger: ledgerPath };
}

export function summarizeSourceMaterialCleanup(manifest, enabled) {
  const assignments = Array.isArray(manifest.assignments) ? manifest.assignments : [];
  const state = cleanupState(manifest, enabled);
  const submittedRows = assignments.filter((row) => ['published', 'scheduled'].includes(row.status));
  const pendingRows = assignments.filter((row) => !['published', 'scheduled'].includes(row.status));
  const undeletedSubmittedRows = submittedRows.filter((row) => !row.source_deleted_at);
  const status = !enabled
    ? 'disabled'
    : !assignments.length
      ? 'no_assignments'
      : undeletedSubmittedRows.length || pendingRows.length
        ? (state.failures.length ? 'partial_failure' : 'active')
        : 'completed';
  return {
    ...state,
    status,
    pending_submission_assignments: pendingRows.length,
    submitted_assignments_without_source_deletion: undeletedSubmittedRows.length,
  };
}
