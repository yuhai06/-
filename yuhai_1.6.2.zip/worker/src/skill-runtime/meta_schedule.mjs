// Calendar arithmetic on Meta's displayed wall time. Never use the machine's
// clock or convert the control's time into another timezone to plan a batch.
export const SCHEDULE_HOUR_LABEL = /^(?:小时|小時|Hours?|Heures?|Horas?|Jam|Giờ|ชั่วโมง)$/i;

export function normalizeDigits(value) {
  return String(value).normalize('NFKC').replace(/[\u0660-\u0669\u06f0-\u06f9\u0e50-\u0e59]/g, character => {
    const code = character.charCodeAt(0);
    return String(code - (code >= 0x0e50 ? 0x0e50 : code >= 0x06f0 ? 0x06f0 : 0x0660));
  }).replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, '').trim();
}

function calendar(parts) {
  const values = ['year', 'month', 'day', 'hour', 'minute'].map(key => Number(parts[key] ?? 0));
  const [year, month, day, hour, minute] = values;
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute));
  if (!values.every(Number.isInteger) || year < 1900 || year > 9999
    || date.getUTCFullYear() !== year || date.getUTCMonth() + 1 !== month || date.getUTCDate() !== day
    || date.getUTCHours() !== hour || date.getUTCMinutes() !== minute) throw new Error('Invalid platform calendar fields');
  return date;
}

function partsOf(date) {
  return Object.fromEntries([
    ['year', date.getUTCFullYear()], ['month', date.getUTCMonth() + 1], ['day', date.getUTCDate()],
    ['hour', date.getUTCHours()], ['minute', date.getUTCMinutes()],
  ].map(([key, value]) => [key, String(value).padStart(key === 'year' ? 4 : 2, '0')]));
}

export function addPlatformMinutes(base, minutes) {
  if (!Number.isInteger(minutes) || minutes < 0) throw new Error('Invalid schedule increment');
  // UTC here is only a calendar arithmetic container, not the platform timezone.
  return partsOf(new Date(calendar(base).getTime() + minutes * 60_000));
}

export function platformDateTime(parts) {
  calendar(parts);
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:00`;
}

function dateOrder(metadata) {
  if (metadata.type === 'date') return ['year', 'month', 'day'];
  const placeholder = normalizeDigits(metadata.placeholder || '').toLowerCase().replace(/\s/g, '');
  // The words used for day/year differ by locale. Their positions are explicit.
  const tokens = placeholder.match(/yyyy|aaaa|jjjj|bbbb|พ\.ศ\.|ปปปป|yy|mm|dd|jj|tt|gg|aa|วว|m|d/g);
  if (!tokens || tokens.length !== 3) return null;
  const order = tokens.map(token => /^(yyyy|aaaa|jjjj|bbbb|พ\.ศ\.|ปปปป|yy|aa)$/.test(token) ? 'year'
    : /^m{1,2}$/.test(token) ? 'month' : 'day');
  return new Set(order).size === 3 ? order : null;
}

export function parsePlatformDate(value, metadata = {}) {
  const text = normalizeDigits(value);
  let match = text.match(/^(\d{4})\s*(?:年|[-/.])\s*(\d{1,2})\s*(?:月|[-/.])\s*(\d{1,2})日?$/);
  let parts;
  if (match) parts = { year: match[1], month: match[2], day: match[3] };
  else {
    const numbers = text.match(/\d+/g);
    const order = dateOrder(metadata);
    if (numbers?.length === 3 && order && /^[\d\s/.-]+$/.test(text)) {
      parts = Object.fromEntries(order.map((key, index) => [key, numbers[index]]));
    } else {
      // Parse month words through the actual page locale, not English Date.parse.
      const locales = [...new Set([metadata.locale, 'en-US'].filter(Boolean))];
      for (const locale of locales) {
        for (let month = 1; month <= 12 && !parts; month += 1) {
          for (const width of ['long', 'short']) {
            const name = new Intl.DateTimeFormat(locale, { month: width, timeZone: 'UTC', calendar: 'gregory' })
              .format(new Date(Date.UTC(2026, month - 1, 15))).replace(/\.$/, '').toLocaleLowerCase(locale);
            const lowered = text.toLocaleLowerCase(locale);
            const index = lowered.indexOf(name);
            if (index < 0 || /^\d+$/.test(name)) continue;
            const remaining = `${lowered.slice(0, index)} ${lowered.slice(index + name.length)}`.match(/\d+/g);
            if (remaining?.length !== 2) continue;
            const year = remaining.find(number => number.length === 4);
            const day = remaining.find(number => number !== year);
            if (year && day) parts = { year, month: String(month), day };
          }
        }
        if (parts) break;
      }
    }
  }
  if (!parts) throw new Error(`Unsupported platform date format: ${metadata.placeholder || text}`);
  calendar(parts);
  return { year: parts.year.padStart(4, '0'), month: parts.month.padStart(2, '0'), day: parts.day.padStart(2, '0') };
}

export function scheduleDateCandidates(parts, metadata = {}) {
  const { year, month, day } = parts;
  calendar({ year, month, day });
  const iso = `${year}-${month}-${day}`;
  if (metadata.type === 'date') return [iso];
  if (/年.*月.*日/.test(metadata.placeholder || '') || /年.*月.*日/.test(metadata.value || '')) {
    return [`${year}年${Number(month)}月${Number(day)}日`, iso];
  }
  const order = dateOrder(metadata);
  if (order) {
    const separator = (metadata.placeholder || '').match(/[/.\-]/)?.[0] || '/';
    return [order.map(key => parts[key]).join(separator)];
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(metadata.value || '')) return [iso];
  if (/\p{L}/u.test(metadata.value || metadata.placeholder || '')) {
    const date = calendar({ year, month, day });
    return ['short', 'long'].map(width => new Intl.DateTimeFormat(metadata.locale || 'en-US', {
      timeZone: 'UTC', calendar: 'gregory', year: 'numeric', month: width, day: 'numeric',
    }).format(date));
  }
  throw new Error(`Unsupported schedule date format: ${metadata.placeholder || metadata.value || 'missing format'}`);
}

async function unique(locator, name) {
  if (await locator.count() !== 1) throw new Error(`${name} missing or ambiguous`);
  return locator;
}

// A schedule panel has one date input and numeric hour/minute controls. Match
// numeric ranges first; translated labels only support older control variants.
export async function scheduleControls(page) {
  const inputs = page.locator('input:visible');
  const candidates = await inputs.evaluateAll(elements => elements.flatMap((element, index) => {
    const placeholder = element.getAttribute('placeholder') || '';
    if (element.type === 'date' || /(?:y{2,4}|a{2,4}|j{4}|b{4}|年|ปปปป).*(?:m|月)|(?:m|d|j|t|g|ว).*(?:y{2,4}|a{2,4}|j{4}|b{4}|年|ปปปป)/i.test(placeholder)) return [index];
    return [];
  }));
  const date = candidates.length === 1 ? inputs.nth(candidates[0])
    : await unique(page.getByLabel(/^(?:Date|日期|日期選擇器|Date picker|Fecha|Data|Tanggal|Ngày|วันที่)$/i).and(inputs), 'Schedule date input');
  const spins = page.locator('input[role="spinbutton"]:visible,input[type="number"]:visible');
  let hour = spins.filter({ visible: true }).and(page.locator('[aria-valuemax="12"],[aria-valuemax="23"],input[max="12"],input[max="23"]'));
  let minute = spins.and(page.locator('[aria-valuemax="59"],input[max="59"]'));
  if (!await hour.count()) hour = page.getByLabel(SCHEDULE_HOUR_LABEL).and(inputs);
  if (!await minute.count()) minute = page.getByLabel(/^(?:分钟|分鐘|Minutes?|Minutos?|Menit|Phút|นาที)$/i).and(inputs);
  await unique(hour, 'Schedule hour input');
  await unique(minute, 'Schedule minute input');
  let period = spins.and(page.locator('[aria-valuemin="0"][aria-valuemax="1"]'));
  if (!await period.count()) period = page.getByLabel(/^(?:AM\s*\/\s*PM|Meridiem|Period|上午\/下午|上午／下午)$/i)
    .or(page.locator('select:has(option[value="AM" i]):has(option[value="PM" i])')).and(page.locator(':visible'));
  const periodCount = await period.count();
  if (periodCount > 1) throw new Error('Schedule AM/PM control is ambiguous');
  const max = await hour.getAttribute('aria-valuemax') || await hour.getAttribute('max');
  if (max === '12' && !periodCount) throw new Error('Schedule AM/PM control missing');
  return { date, hour, minute, period: periodCount ? period : null };
}

async function numberValue(input) {
  const value = normalizeDigits(await input.getAttribute('aria-valuenow') ?? await input.inputValue());
  return /^\d+$/.test(value) ? Number(value) : NaN;
}

async function periodIndex(control) {
  return control.evaluate(element => {
    const numeric = element.getAttribute('aria-valuenow');
    if (element.getAttribute('role') === 'spinbutton' && element.getAttribute('aria-valuemax') === '1'
      && (numeric === '0' || numeric === '1')) return Number(numeric);
    const value = String(element.getAttribute('aria-valuetext') || element.value || element.innerText || '').replace(/[.\s]/g, '').toUpperCase();
    return value === 'AM' ? 0 : value === 'PM' ? 1 : null;
  });
}

export async function readPlatformSchedule(page) {
  const controls = await scheduleControls(page);
  const locale = await page.locator('html').getAttribute('lang') || 'en';
  // Focusing Meta's date control reveals its numeric editing representation.
  await controls.date.click();
  const metadata = await controls.date.evaluate(element => ({ type: element.type, placeholder: element.placeholder, value: element.value }));
  const date = parsePlatformDate(metadata.value, { ...metadata, locale });
  await controls.date.press('Tab');
  await controls.date.blur();
  let hour = await numberValue(controls.hour);
  const minute = await numberValue(controls.minute);
  if (controls.period) {
    const period = await periodIndex(controls.period);
    if (period === null || hour < 1 || hour > 12) throw new Error('Unsupported platform day period');
    hour = hour % 12 + period * 12;
  }
  return addPlatformMinutes({ ...date, hour, minute }, 0);
}

async function enterNumber(input, value) {
  await input.click();
  await input.press('Control+A');
  await input.pressSequentially(String(value));
  await input.press('Tab');
}

export async function fillScheduleInputs(page, target) {
  calendar(target);
  const controls = await scheduleControls(page);
  const locale = await page.locator('html').getAttribute('lang') || 'en';
  await controls.date.click();
  const metadata = await controls.date.evaluate(element => ({ type: element.type, placeholder: element.placeholder, value: element.value }));
  const date = scheduleDateCandidates(target, { ...metadata, locale })[0];
  if (metadata.type === 'date') { await controls.date.fill(date); await controls.date.blur(); }
  else await enterNumber(controls.date, date);
  // Meta formats dates after blur. That presentation is not a reason to reject
  // the user's schedule. Only the control's actual validation state matters.
  if (await controls.date.getAttribute('aria-invalid') === 'true') throw new Error('Meta rejected the schedule date input');
  // Compare calendar components in the focused editing representation, not the
  // localized display string. This detects a field silently reverting its input.
  await controls.date.click();
  const acceptedDate = parsePlatformDate(await controls.date.inputValue(), { ...metadata, locale });
  await controls.date.press('Tab');
  await controls.date.blur();
  if (['year', 'month', 'day'].some(key => Number(acceptedDate[key]) !== Number(target[key]))) {
    throw new Error('Schedule date input did not accept the requested value');
  }
  const hour = Number(target.hour);
  await enterNumber(controls.hour, controls.period ? hour % 12 || 12 : hour);
  await enterNumber(controls.minute, Number(target.minute));
  if (controls.period) {
    const desired = hour >= 12 ? 1 : 0;
    const isBinary = await controls.period.getAttribute('role') === 'spinbutton'
      && await controls.period.getAttribute('aria-valuemax') === '1';
    if (isBinary) {
      if (await periodIndex(controls.period) !== desired) {
        await controls.period.click();
        await controls.period.press(desired ? 'ArrowUp' : 'ArrowDown');
        await controls.period.press('Tab');
      }
    } else if (await controls.period.evaluate(element => element.tagName) === 'SELECT') {
      const option = await controls.period.locator('option').evaluateAll((options, value) =>
        options.find(item => item.textContent.replace(/[.\s]/g, '').toUpperCase() === value)?.value, desired ? 'PM' : 'AM');
      if (option === undefined) throw new Error('Schedule AM/PM option missing');
      await controls.period.selectOption(option);
    } else await enterNumber(controls.period, desired ? 'PM' : 'AM');
    if (await periodIndex(controls.period) !== desired) throw new Error('Schedule AM/PM input did not accept the requested value');
  }
  if (await numberValue(controls.hour) !== (controls.period ? hour % 12 || 12 : hour)
    || await numberValue(controls.minute) !== Number(target.minute)) throw new Error('Schedule time input did not accept the requested value');
}
