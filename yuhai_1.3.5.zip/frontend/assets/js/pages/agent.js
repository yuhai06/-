/* 雨海 Agent — 方案 C 卡片流
   检测本机 Agent → 接入 → 显示全部模型（DSH订阅 + 网关全量）→ 对话操作 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { pageHead, $, $$, toast, ts, emptyState } from '../ui.js';

let ov = null;
let detecting = false;
let chatHistory = [];      // [{role, content, trace, error}]
let chatting = false;
let tab = 'chat';          // chat | models
let filterCh = '';         // 模型渠道筛选
let showGateway = true;    // 是否显示网关全量
let curChatId = '';        // 当前会话 id
let chatList = [];         // 会话列表
let sideOpen = true;       // 侧栏展开
let lastUsage = null;      // 最近一次 token 用量
let lastSpeed = 0;         // tok/s
let curSummary = '';       // 当前会话摘要
let curSummaryMsgs = 0;    // 摘要覆盖条数
let memList = [];          // 长期记忆

// 工具名 → 中文（进度显示用）
const TOOL_CN = {
  // 切片
  slice_env_check: '检查切片环境',
  slice_env_install: '安装缺失依赖',
  slice_list_dramas: '列出可切剧',
  slice_run: '开始切片',
  slice_status: '查任务进度',
  slice_result: '查成片',
  slice_verify: '校验成片',
  slice_judge: '模型判型',
  drama_type_of: '查剧型',
  drama_set_type: '指定剧型',
  drama_judge_by_model: '模型判型',
  drama_judge_batch: '批量判型',
  drama_type_report: '剧型报告',
  drama_types: '列剧型',
  // 抓取
  grab_hot: '拉热门榜单',
  grab_search: '搜剧',
  grab_run: '开始抓剧',
  grab_records: '查抓取记录',
  grab_download: '下载素材',
  // 账号/主页/授权
  account_list: '列账号',
  account_create: '新建账号',
  account_update: '改账号',
  account_from_envs: '从环境补建账号',
  account_quota: '查账号配额',
  page_list: '列主页',
  page_create: '建主页',
  page_update: '改主页',
  page_skip_publish: '设主页跳过',
  page_extract: '提取主页',
  authz_matrix: '查授权矩阵',
  authz_grant: '授权主页',
  authz_grant_multi: '批量授权',
  authz_verify: '校验授权',
  // 环境
  env_list: '列指纹环境',
  env_start: '启动环境',
  env_stop: '停止环境',
  env_sync: '同步环境',
  env_test_proxy: '测代理',
  // 发布
  publish_run: '发布视频',
  publish_reels: '发 Reels',
  publish_history: '查发布历史',
  publish_reels_status: '查 Reels 状态',
  // 素材
  library_list: '列素材',
  library_scan: '扫素材库',
  library_qc: '素材质检',
  // 视频工具
  video_env: '检查视频工具',
  video_probe: '看视频信息',
  video_clip: '切视频段',
  video_concat: '拼接视频',
  video_vertical: '转竖屏',
  video_burn_subs: '加字幕',
  video_speed: '变速',
  video_normalize: '调音量',
  video_make: '多步处理视频',
  video_list_out: '看视频产出',
  video_browse: '找视频素材',
  // 邮箱
  mail_kinds: '看邮箱接入方式',
  mail_channels: '列邮箱通道',
  mail_add_channel: '新增邮箱通道',
  mail_test_channel: '测邮箱连接',
  mail_pull: '拉取邮件',
  mail_latest_code: '取最新验证码',
  mail_manual: '录验证码',
  mail_inbox: '看收件箱',
  mail_del_channel: '删邮箱通道',
  // 系统
  system_health: '系统健康检查',
  system_logs: '查日志',
  system_failures: '查失败原因',
  system_guard: '查风控状态',
  // 数据
  data_overview: '数据总览',
  data_page_fit: '主页数据分析',
  data_collect: '采集数据',
  // 记忆
  memory_set: '写记忆',
  memory_get: '读记忆',
  memory_list: '列记忆',
  // 排期
  schedule_list: '列排期',
  schedule_queue: '列队列',
  schedule_capacity: '查今日容量',
};

// 工具名 → 中文（查不到就原样显示）
function toolCN(name) {
  if (!name) return '';
  if (TOOL_CN[name]) return TOOL_CN[name];
  // 自动注册的工具：get_api_xxx → 去掉前缀美化
  const m = /^(get|post|put|patch|delete)_api_(\w+)$/.exec(name);
  if (m) {
    const verb = { get: '查', post: '建', put: '改', patch: '改',
                   delete: '删' }[m[1]] || '';
    return verb + m[2].replace(/_/g, ' ');
  }
  return name;
}


const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

const nl = (s) => esc(s).replace(/\n/g, '<br>');

const short = (p) => {
  const s = String(p || '');
  if (s.length < 46) return s;
  return s.slice(0, 20) + '…' + s.slice(-22);
};

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '雨海 Agent',
      desc: '接入本机 Agent，用它的模型驱动工作台',
      actions: [
        `<button class="btn sm" data-act="detect"><span data-icon="refresh"></span>重新检测</button>`,
        `<button class="btn sm ghost" data-act="deep">深度扫描</button>`,
      ],
    })}
    <div id="ag-body"></div>
  `;
  $$('[data-act="detect"]', root).forEach((b) => (b.onclick = () => detect(root)));
  $$('[data-act="deep"]', root).forEach((b) => (b.onclick = () => deepScan(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try { ov = await api.agentOverview(); } catch { ov = null; }
  paint(root);
}

async function detect(root) {
  if (detecting) return;
  detecting = true;
  const box = $('#ag-body', root);
  if (box) box.innerHTML = renderDetecting();
  try {
    const r = await api.agentDetect();
    toast(r.ok ? '检测完成' : '未找到 Agent', `${r.installed} 个可用`,
          r.ok ? 'ok' : 'warn');
    await load(root);
  } catch (e) { toast('检测失败', e.message, 'err'); }
  detecting = false;
}

async function deepScan(root) {
  toast('深度扫描中', '逐个磁盘找，可能几十秒', 'info');
  try {
    const r = await api.agentDeepScan();
    toast(`找到 ${r.count} 个`, (r.found || []).slice(0, 3).join('\n') || '无', 'ok');
  } catch (e) { toast('扫描失败', e.message, 'err'); }
}

/* ══════════════════════════════════════════
   检测中：骨架动画
   ══════════════════════════════════════════ */
function renderDetecting() {
  return `
    <style>${CARD_CSS}</style>
    <div class="ag-pane" style="height:auto;min-height:300px">
      <div class="ag-bg"></div>
      <div style="position:relative;padding:60px 24px;text-align:center">
        <div class="ag-scan"></div>
        <div style="font-size:14px;color:var(--tx-0);font-weight:600;margin-bottom:8px">
          正在扫描本机 Agent</div>
        <div style="font-size:11px;color:var(--tx-2);line-height:1.9">
          DSH · Codex · Claude · Cursor · Ollama · WorkBuddy<br>
          Windsurf · Cline · Continue · Trae
        </div>
      </div>
    </div>`;
}

/* ══════════════════════════════════════════
   未接入：Agent 选择卡片（重点重做）
   ══════════════════════════════════════════ */
function renderPicker(ov) {
  const list = (ov && ov.detected) || [];
  const found = list.filter((a) => a.installed);
  const missing = list.filter((a) => !a.installed);

  const card = (a) => {
    const on = ov && ov.connected === a.id;
    const n = (a.models || []).length;
    const gw = a.gatewayCount || 0;
    return `
      <div class="ag-agent-card ${on ? 'on' : ''} ${a.installed ? '' : 'off'}"
           data-pick="${esc(a.id)}" data-installed="${a.installed ? 1 : 0}">
        <div class="ag-agent-top">
          <div class="ag-agent-ico">${esc(a.name.slice(0, 2))}</div>
          <div class="ag-agent-name">${esc(a.name)}</div>
          ${on ? '<div class="ag-agent-badge">使用中</div>' : ''}
        </div>
        <div class="ag-agent-why">${esc(a.why || '')}</div>
        <div class="ag-agent-stat">
          ${a.installed
            ? `<span class="ag-ok">●</span> 已安装 · ${n} 个模型${gw ? ` <span style="opacity:.6">(网关 ${gw})</span>` : ''}`
            : `<span class="ag-dim">○</span> 未检测到`}
        </div>
        ${a.installed ? '' : `
          <div class="ag-agent-dl" data-dl="${esc(a.download || '')}">
            ${a.download ? '点击下载 →' : '需手动安装'}
          </div>`}
      </div>`;
  };

  return `
    <style>${CARD_CSS}</style>
    <div style="margin-bottom:14px">
      <div style="font-size:13px;font-weight:600;color:var(--tx-1);margin-bottom:4px">
        选择要接入的 Agent</div>
      <div style="font-size:10.5px;color:var(--tx-3);line-height:1.8">
        只显示接入的 Agent 自己的模型 · 点卡片切换 · 灰色的是未安装
      </div>
    </div>

    <div class="ag-agent-grid">
      ${found.map(card).join('')}
      ${missing.length ? `
        <div class="ag-agent-divider">未安装（共 ${missing.length} 个）</div>
        ${missing.map(card).join('')}` : ''}
    </div>
  `;
}

/* ══════════════════════════════════════════
   主渲染
   ══════════════════════════════════════════ */
function paint(root) {
  const box = $('#ag-body', root);
  if (!box) return;

  if (!ov) { box.innerHTML = renderPicker(null); bindPicker(root); return; }
  if (!ov.connected) { box.innerHTML = renderPicker(ov); bindPicker(root); return; }

  const ms = ov.models || [];
  const visible = ms.filter((m) => !m.hidden);
  const gwCount = ms.filter((m) => m.inGateway).length;

  // ── 顶栏只在结构变化时重建（chat/models/mem 切换不重建它，避免闪动）
  const topbarHtml = `
    <div class="ag-topbar">
      <div class="ag-dot"></div>
      <div class="ag-topname">${esc(ov.name || ov.connected)}</div>
      <div class="ag-topmeta">${visible.length} 个模型${
        gwCount ? ` · 网关 ${gwCount}` : ''}</div>
      <div class="ag-topsep"></div>
      ${renderStats()}
      <div class="ag-chatsel" id="ag-chat-sel">
        <span class="ag-cs-cur">${esc(curChatTitle())}</span>
        <span class="ag-sel-arr">▾</span>
        <div class="ag-cs-pop" id="ag-cs-pop">
          <div class="ag-cs-new" id="ag-cs-new">＋ 新建对话</div>
          ${chatList.length ? chatList.slice(0, 20).map((c) => `
            <div class="ag-cs-row ${c.id === curChatId ? 'on' : ''}"
                 data-cs="${esc(c.id)}">
              <span class="ag-cs-nm">${esc(c.title || '新对话')}</span>
              <span class="ag-cs-meta">${c.msgCount || 0}</span>
              <span class="ag-cs-del" data-csdel="${esc(c.id)}">×</span>
            </div>`).join('')
            : '<div class="ag-cs-empty">还没有对话</div>'}
        </div>
      </div>
      <div class="ag-modelsel" id="ag-model-sel">
        <span class="ag-sel-cur" title="${esc(ov.model || '')}">${
          esc(shortModel(ov.model || '（默认）'))}</span>
        <span class="ag-sel-arr">▾</span>
        <div class="ag-sel-pop" id="ag-sel-pop">
          ${visible.map((m) => `
            <div class="ag-sel-row ${m.id === ov.model ? 'on' : ''}"
                 data-pick-m="${esc(m.id)}">
              <span class="ag-sel-nm">${esc(m.id)}</span>
              ${m.vision ? '<i class="ag-tag v">视</i>' : ''}
            </div>`).join('')}
        </div>
      </div>
      <button class="ag-tbtn ${tab === 'chat' ? 'on' : ''}" data-tab="chat">
        对话</button>
      <button class="ag-tbtn ${tab === 'models' ? 'on' : ''}" data-tab="models">
        模型 <span class="ag-cnt">${visible.length}</span></button>
      <button class="ag-tbtn ${tab === 'mem' ? 'on' : ''}" data-tab="mem">
        记忆 <span class="ag-cnt">${memList.length}</span></button>
      <button class="ag-tbtn ghost" data-act="switch">切换</button>
    </div>`;

  // ── 确保 <style> 一定存在（不依赖任何标志位，按 DOM 实况判断）
  // 页面切换会让 #ag-body 重新生成，此时旧标志会误导，所以必须每次核对
  if (!document.getElementById('ag-cardcss')) {
    const st = document.createElement('style');
    st.id = 'ag-cardcss';
    st.textContent = CARD_CSS;
    box.appendChild(st);
  }

  // ── 首次渲染：搭骨架（顶栏 + 内容槽）
  let topbar = $('#ag-topbar', root);
  if (!topbar) {
    const skeleton = document.createElement('div');
    skeleton.innerHTML = '<div id="ag-topbar"></div><div id="ag-slot"></div>';
    box.appendChild(skeleton);
    topbar = $('#ag-topbar', root);
  }
  // 顶栏整体替换（体量小，代价可忽略）
  topbar.innerHTML = topbarHtml;

  // ── 内容槽：只重绘这一块
  // 输入区用独立容器 #ag-inputhost，位于 slot 之外，永远不被重绘销毁
  const slot = $('#ag-slot', root);
  if (slot) {
    const contentHtml = (tab === 'mem')
      ? renderMem()
      : (tab === 'chat'
        ? '<div class="ag-withside">'
          + (sideOpen ? renderSidebar() : '')
          + '<div class="ag-main">' + renderChat(ov) + '</div>'
          + '</div>'
        : renderModels(ov));
    slot.innerHTML = contentHtml;
  }

  // 输入区宿主：chat 时显示，其它 tab 隐藏（但不销毁，保留用户已输入内容）
  let host = $('#ag-inputhost', root);
  if (!host) {
    const wrap = document.createElement('div');
    wrap.id = 'ag-inputhost';
    wrap.innerHTML = inputAreaHtml(ov);
    const body = $('#ag-body', root);
    if (body) body.appendChild(wrap);
    host = $('#ag-inputhost', root);
  }
  if (host) host.style.display = (tab === 'chat') ? '' : 'none';


  // tab 切换
  $$('[data-tab]', root).forEach((b) => {
    b.onclick = () => { tab = b.dataset.tab; paint(root); };
  });
  const sw = $('[data-act="switch"]', root);
  if (sw) sw.onclick = async () => {
    try { await api.agentConnect(''); await load(root); }
    catch (e) { toast('切换失败', e.message, 'err'); }
  };

  if (tab === 'chat') {
    ensureInputArea(root, ov);
    bindChat(root);
    bindSidebar(root);
    bindChatSel(root);
    if (!chatList.length) loadChats(root);
  } else if (tab === 'mem') {
    bindMem(root);
    loadMem(root);
  } else bindModels(root);
}

function curChatTitle() {
  const c = chatList.find(function (x) { return x.id === curChatId; });
  const t = c ? c.title : '';
  if (!t) return '新对话';
  return t.length > 14 ? t.slice(0, 13) + '…' : t;
}

function renderStats() {
  const u = lastUsage;
  if (!u) {
    return '<div class="ag-stats dim">'
      + '<span class="ag-stat"><span class="ag-si">⚡</span>—</span>'
      + '<span class="ag-stat"><span class="ag-si">💾</span>—</span>'
      + '<span class="ag-stat"><span class="ag-si">◐</span>—</span>'
      + '</div>';
  }
  const cache = u.prompt ? Math.round((u.cached / u.prompt) * 100) : 0;
  const pct = u.ctxPct || 0;
  const col = pct >= 80 ? 'var(--danger)'
    : pct >= 50 ? 'var(--warn)' : 'var(--ok)';
  return '<div class="ag-stats">'
    + '<span class="ag-stat" title="生成速度"><span class="ag-si">⚡</span>'
    + (lastSpeed ? lastSpeed + ' tok/s' : '—') + '</span>'
    + '<span class="ag-stat" title="缓存命中"><span class="ag-si">💾</span>'
    + cache + '%</span>'
    + '<span class="ag-stat" title="上下文 ' + pct + '%">'
    + ringSvg(pct, col) + pct + '%</span>'
    + '</div>';
}

function ringSvg(pct, col) {
  const r = 7;
  const c = 2 * Math.PI * r;
  const on = c * Math.min(100, Math.max(0, pct)) / 100;
  return '<svg width="18" height="18" viewBox="0 0 18 18" '
    + 'style="vertical-align:middle">'
    + '<circle cx="9" cy="9" r="' + r + '" fill="none" '
    + 'stroke="var(--line)" stroke-width="2.5"/>'
    + '<circle cx="9" cy="9" r="' + r + '" fill="none" stroke="' + col + '" '
    + 'stroke-width="2.5" stroke-dasharray="' + on + ' ' + (c - on) + '" '
    + 'stroke-dashoffset="' + (c / 4) + '"/>'
    + '</svg>';
}

function bindPicker(root) {
  $$('[data-pick]', root).forEach((c) => {
    c.onclick = async () => {
      const id = c.dataset.pick;
      if (c.dataset.installed !== '1') {
        const dl = c.querySelector('[data-dl]');
        const url = dl && dl.dataset.dl;
        if (url) { window.open(url, '_blank'); toast('下载页已打开', '', 'ok'); }
        else toast('未安装', '需要手动装这个 Agent', 'warn');
        return;
      }
      try {
        const r = await api.agentConnect(id);
        toast('已接入', r.note || r.name || id, 'ok');
        await load(root);
      } catch (e) { toast('接入失败', e.message, 'err'); }
    };
  });
}

/* ══════════════════════════════════════════
   对话（方案 C）
   ══════════════════════════════════════════ */
function renderChat(ov) {
  const memTip = curSummary
    ? '<div class="ag-memtip"><span>🧠</span>'
      + '<span><b>已记住前面 ' + curSummaryMsgs + ' 条对话</b> · '
      + esc(curSummary.slice(0, 60)) + '…</span>'
      + '<span class="ag-memx" id="ag-memx">×</span></div>'
    : '';
  const cards = chatHistory.map((m) => {
    if (m.role === 'user') {
      const at = (m.atts || []).map((a) => `
        <span class="ag-att-chip">${a.kind === 'image' ? '🖼' : '📄'}
          ${esc(a.name)}</span>`).join('');
      return `<div class="ag-card me">${nl(m.content)}
        ${at ? `<div class="ag-att-row">${at}</div>` : ''}</div>`;
    }
    return liveCardHtml(m, ov);
  }).join('');

  const empty = `
    ${sideOpen ? '' : '<button class="ag-unfold" id="ag-unfold" title="展开会话">▶</button>'}
    <div class="ag-empty">
      <div class="ag-empty-ico">雨</div>
      <div class="ag-empty-t">直接说话就能操作工作台</div>
      <div class="ag-empty-hints">
        ${[
          '现在有哪些剧可以切？',
          '给网易发布号01 建个主页 Y20，授权给它',
          '检查一下环境有没有问题',
          '上次切到哪了？',
        ].map((h) => `<div class="ag-hint-item" data-hint="${esc(h)}">
            <span class="ag-hint-arr">›</span>${esc(h)}</div>`).join('')}
      </div>
    </div>`;

  // 注意：输入区不再随每次 paint 重建（会销毁 textarea 导致焦点丢失、
  // 键盘打不了字）。这里只输出消息区，输入区由 ensureInputArea() 常驻插入。
  return `
    <div class="ag-chatwrap">
      ${memTip}
      <div id="ag-chat" class="ag-chatbody">
        ${cards || empty}
        ${chatting ? `<div class="ag-card ai">
          <div class="ag-ai-head">
            <div class="ag-avatar">雨</div>
            <div class="ag-ai-name">正在思考…</div>
          </div>
          <div class="ag-typing"><span></span><span></span><span></span></div>
        </div>` : ''}
      </div>
    </div>`;
}

/* 输入区 HTML：只在首次渲染时插入一次，之后复用同一个 DOM 节点 */
function inputAreaHtml(ov) {
  return `
    <div class="ag-inputarea" id="ag-inputarea">
      <div class="ag-attbar" id="ag-attbar"></div>
      <div class="ag-inputbox">
        <textarea id="ag-input" rows="2"
          placeholder="说要做什么…（Enter 发送 · Shift+Enter 换行 · 可直接粘贴截图）"></textarea>
        <div class="ag-actions">
          <button class="ag-uploadb" id="ag-upload" title="上传文件/图片">
            <span>＋</span></button>
          <input type="file" id="ag-file" multiple
            accept="image/*,.txt,.md,.json,.csv,.log,.py,.js,.html,.pdf,.zip"
            style="display:none" />
          <button class="ag-mini" id="ag-clear">清空</button>
          <div class="ag-hintline">${esc(ov.name || '')} · ${esc(shortModel(ov.model || ''))}</div>
          <button class="ag-sendbtn" id="ag-send" ${chatting ? 'disabled' : ''}>
            ${chatting ? '…' : '发送'}</button>
        </div>
      </div>
    </div>`;
}

/* 输入区常驻在 #ag-inputhost（paint 只改 slot，不动 host）*/
function ensureInputArea(root, ov) {
  let host = $('#ag-inputhost', root);
  if (!host) {
    const body = $('#ag-body', root);
    if (!body) return null;
    const wrap = document.createElement('div');
    wrap.id = 'ag-inputhost';
    wrap.innerHTML = inputAreaHtml(ov);
    body.appendChild(wrap);
    host = $('#ag-inputhost', root);
  }
  if (host && !$('#ag-inputarea', root)) {
    host.innerHTML = inputAreaHtml(ov);
  }
  return $('#ag-input', root);
}

let attachments = [];      // 待发送附件

function shortModel(m) {
  const x = String(m || '');
  if (!x) return '（默认）';
  return x.length > 28 ? x.slice(0, 26) + '…' : x;
}

function bindChat(root) {
  const inp = $('#ag-input', root);

  // ---- 模型下拉 ----
  const sel = $('#ag-model-sel', root);
  const pop = $('#ag-sel-pop', root);
  if (sel && pop) {
    sel.onclick = (e) => {
      e.stopPropagation();
      pop.classList.toggle('open');
    };
    document.addEventListener('click', () => pop.classList.remove('open'), {
      once: true,
    });
    $$('[data-pick-m]', root).forEach((r) => {
      r.onclick = async (e) => {
        e.stopPropagation();
        pop.classList.remove('open');
        const mid = r.dataset.pickM;
        try {
          await api.agentSelectModel({ agentId: ov.connected, modelId: mid });
          toast('已切换模型', mid, 'ok');
          await load(root);
        } catch (err) { toast('切换失败', err.message, 'err'); }
      };
    });
  }

  // ---- 上传 ----
  const upb = $('#ag-upload', root);
  const fin = $('#ag-file', root);
  if (upb && fin) {
    upb.onclick = () => fin.click();
    fin.onchange = async () => {
      const files = Array.from(fin.files || []);
      fin.value = '';
      for (const f of files) await addAttachment(root, f);
    };
  }

  // ---- 粘贴截图 ----
  if (inp) {
    inp.onpaste = async (e) => {
      const items = (e.clipboardData || {}).items || [];
      for (const it of items) {
        if (it.type && it.type.startsWith('image/')) {
          e.preventDefault();
          const blob = it.getAsFile();
          if (blob) {
            await addAttachment(root, new File([blob],
              'paste_' + Date.now() + '.png', { type: blob.type }));
          }
        }
      }
    };
  }

  paintAtts(root);
  const btn = $('#ag-send', root);
  if (btn) btn.onclick = () => send(root);
  if (inp) {
    try {
      const pre = sessionStorage.getItem('agent_prefill');
      if (pre && !inp.value) {
        inp.value = pre;
        sessionStorage.removeItem('agent_prefill');
      }
    } catch (e) { /* ignore */ }
    inp.onkeydown = (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(root); }
    };
    // 只在输入框未获得焦点时补一次（避免每次重绘抢焦点、导致输入中断）
    if (document.activeElement !== inp) {
      try { inp.focus(); } catch (e) { /* ignore */ }
    }
  }
  $$('[data-hint]', root).forEach((h) => {
    h.onclick = () => {
      const i = $('#ag-input', root);
      if (i) { i.value = h.dataset.hint; i.focus(); }
      if (h.dataset.hint) send(root);
    };
  });
  const clr = $('#ag-clear', root);
  if (clr) clr.onclick = async () => {
    try {
      const r = await api.agentChatNew({
        agent: (ov && ov.connected) || '', model: (ov && ov.model) || '',
      });
      curChatId = r.id;
      chatHistory = [];
      chatList.unshift({ id: r.id, title: '新对话', msgCount: 0, updatedAt: '' });
      paint(root);
    } catch (e) { chatHistory = []; paint(root); }
  };
  scrollBottom(root);
}

async function addAttachment(root, file) {
  toast('上传中', file.name, 'info');
  try {
    const r = await api.agentUpload(file);
    if (!r.ok) { toast('上传失败', r.error || '', 'err'); return; }
    attachments.push(r);
    paintAtts(root);
    toast('已添加', `${r.name} (${r.sizeMb}MB)`, 'ok');
  } catch (e) { toast('上传失败', e.message, 'err'); }
}

function paintAtts(root) {
  const bar = $('#ag-attbar', root);
  if (!bar) return;
  if (!attachments.length) { bar.innerHTML = ''; bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  bar.innerHTML = attachments.map((a, i) => `
    <div class="ag-att ${a.kind === 'image' ? 'img' : ''}" data-attidx="${i}">
      ${a.kind === 'image' && a.dataUri
        ? `<img src="${a.dataUri}" alt="" />`
        : `<span class="ag-att-ico">📄</span>`}
      <span class="ag-att-nm">${esc(a.name)}</span>
      <span class="ag-att-sz">${a.sizeMb}MB</span>
      <span class="ag-att-x" data-attdel="${i}">×</span>
    </div>`).join('');
  $$('[data-attdel]', bar).forEach((b) => {
    b.onclick = () => {
      attachments.splice(Number(b.dataset.attdel), 1);
      paintAtts(root);
    };
  });
}

function scrollBottom(root) {
  const c = $('#ag-chat', root);
  if (c) c.scrollTop = c.scrollHeight;
}

/* ══════════════════════════════════════════
   会话历史侧栏
   ══════════════════════════════════════════ */
function renderSidebar() {
  const rows = chatList.map((c) => `
    <div class="ag-chatrow ${c.id === curChatId ? 'on' : ''}"
         data-chat="${esc(c.id)}">
      <div class="ag-crow-top">
        ${c.pinned ? '<span class="ag-pin">📌</span>' : ''}
        <span class="ag-crow-t">${esc(c.title || '新对话')}</span>
      </div>
      <div class="ag-crow-meta">
        ${c.msgCount || 0} 条 · ${esc(shortTime(c.updatedAt))}
      </div>
      <div class="ag-crow-act">
        <span data-crename="${esc(c.id)}" title="重命名">✎</span>
        <span data-cpin="${esc(c.id)}" data-to="${c.pinned ? 0 : 1}"
          title="置顶">${c.pinned ? '★' : '☆'}</span>
        <span data-cdel="${esc(c.id)}" title="删除">×</span>
      </div>
    </div>`).join('');

  return `
    <div class="ag-side">
      <div class="ag-side-head">
        <button class="ag-newbtn" id="ag-new">＋ 新建对话</button>
        <button class="ag-sidefold" id="ag-fold" title="收起">◀</button>
      </div>
      <div class="ag-side-search">
        <input id="ag-search" placeholder="搜索对话…" />
      </div>
      <div class="ag-side-list" id="ag-side-list">
        ${rows || `<div class="ag-side-empty">还没有对话<br><span
          style="font-size:9px">点上面「新建对话」开始</span></div>`}
      </div>
    </div>`;
}

function shortTime(t) {
  if (!t) return '';
  const d = new Date(t);
  if (Number.isNaN(d.getTime())) return String(t).slice(0, 16);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toTimeString().slice(0, 5);
  const diff = (now - d) / 86400000;
  if (diff < 7) return Math.floor(diff) + ' 天前';
  return (d.getMonth() + 1) + '/' + d.getDate();
}

async function loadChats(root) {
  try {
    const r = await api.agentChats(40);
    chatList = r.items || [];
  } catch (e) { chatList = []; }
  const sideWrap = root.querySelector('.ag-side');
  if (sideWrap) {
    const tmp = document.createElement('div');
    tmp.innerHTML = renderSidebar();
    const nl = tmp.querySelector('.ag-side-list');
    const old = sideWrap.querySelector('.ag-side-list');
    if (nl && old) old.innerHTML = nl.innerHTML;
    bindSidebar(root);
  } else {
    paint(root);
  }
}

function bindChatSel(root) {
  const sel = $('#ag-chat-sel', root);
  const pop = $('#ag-cs-pop', root);
  if (sel && pop) {
    sel.onclick = function (e) {
      const tg = e.target;
      if (tg.dataset && (tg.dataset.cs || tg.dataset.csdel)) return;
      e.stopPropagation();
      pop.classList.toggle('open');
    };
    pop.onclick = function (e) { e.stopPropagation(); };
  }

  const nb = $('#ag-cs-new', root);
  if (nb) nb.onclick = async function (e) {
    e.stopPropagation();
    try {
      const r = await api.agentChatNew({
        agent: (ov && ov.connected) || '', model: (ov && ov.model) || '',
      });
      curChatId = r.id;
      chatHistory = [];
      lastUsage = null; lastSpeed = 0;
      await loadChats(root);
      paint(root);
    } catch (err) { toast('新建失败', err.message, 'err'); }
  };

  $$('[data-cs]', root).forEach(function (row) {
    row.onclick = async function (e) {
      if (e.target.dataset && e.target.dataset.csdel) return;
      e.stopPropagation();
      const id = row.dataset.cs;
      try {
        const r = await api.agentChatGet(id);
        curChatId = id;
        lastUsage = null; lastSpeed = 0;
        chatHistory = (r.messages || []).map(function (m) {
          return { role: m.role, content: m.content, trace: m.trace,
                   atts: m.atts, model: m.model, error: m.error };
        });
        paint(root);
      } catch (err) { toast('读取失败', err.message, 'err'); }
    };
  });

  $$('[data-csdel]', root).forEach(function (b) {
    b.onclick = async function (e) {
      e.stopPropagation();
      if (!confirm('删除这个对话？')) return;
      try {
        await api.agentChatDel(b.dataset.csdel);
        if (curChatId === b.dataset.csdel) { curChatId = ''; chatHistory = []; }
        await loadChats(root);
        paint(root);
      } catch (err) { /* ignore */ }
    };
  });
}

function bindSidebar(root) {
  const nb = $('#ag-new', root);
  if (nb) nb.onclick = async () => {
    try {
      const r = await api.agentChatNew({
        agent: (ov && ov.connected) || '',
        model: (ov && ov.model) || '',
      });
      curChatId = r.id;
      chatHistory = [];
      await loadChats(root);
      paint(root);
      toast('已新建对话', '', 'ok');
    } catch (e) { toast('新建失败', e.message, 'err'); }
  };

  const fold = $('#ag-fold', root);
  if (fold) fold.onclick = () => { sideOpen = false; paint(root); };

  const unfold = $('#ag-unfold', root);
  if (unfold) unfold.onclick = () => { sideOpen = true; paint(root); };

  const srch = $('#ag-search', root);
  if (srch) {
    let tm = null;
    srch.oninput = () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        try {
          const r = await api.agentChats(40, srch.value.trim());
          chatList = r.items || [];
          await loadChats(root);
        } catch (e) { /* ignore */ }
      }, 260);
    };
  }

  $$('[data-chat]', root).forEach((row) => {
    row.onclick = async (e) => {
      const tg = e.target;
      if (tg.dataset && (tg.dataset.crename || tg.dataset.cpin || tg.dataset.cdel)) return;
      const id = row.dataset.chat;
      try {
        const r = await api.agentChatGet(id);
        curChatId = id;
        lastUsage = null; lastSpeed = 0;
        api.agentChatSummary(id).then((sr) => {
          curSummary = (sr && sr.summary) || '';
          curSummaryMsgs = Math.max(0, (r.messages || []).length - 8);
          paint(root);
        }).catch(() => {});
        chatHistory = (r.messages || []).map((m) => ({
          role: m.role, content: m.content, trace: m.trace, atts: m.atts,
          model: m.model, error: m.error,
        }));
        paint(root);
      } catch (err) { toast('读取失败', err.message, 'err'); }
    };
  });

  $$('[data-cdel]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      if (!confirm('删除这个对话？')) return;
      try {
        await api.agentChatDel(b.dataset.cdel);
        if (curChatId === b.dataset.cdel) { curChatId = ''; chatHistory = []; }
        await loadChats(root);
        paint(root);
      } catch (err) { toast('删除失败', err.message, 'err'); }
    };
  });

  $$('[data-cpin]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      try {
        await api.agentChatPin(b.dataset.cpin, b.dataset.to === '1');
        await loadChats(root);
      } catch (err) { /* ignore */ }
    };
  });

  $$('[data-crename]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const id = b.dataset.crename;
      const cur = (chatList.find((x) => x.id === id) || {}).title || '';
      const t = prompt('新标题', cur);
      if (!t) return;
      try {
        await api.agentChatRename(id, t);
        await loadChats(root);
      } catch (err) { toast('改名失败', err.message, 'err'); }
    };
  });
}

async function send(root) {
  if (chatting) return;
  const inp = $('#ag-input', root);
  const text = (inp && inp.value || '').trim();
  if (!text) return;
  inp.value = '';
  const atts = attachments.slice();
  attachments = [];

  // 没会话就自动建一个
  if (!curChatId) {
    try {
      const nr = await api.agentChatNew({
        title: text.slice(0, 28),
        agent: (ov && ov.connected) || '',
        model: (ov && ov.model) || '',
      });
      curChatId = nr.id;
      chatList.unshift({ id: nr.id, title: text.slice(0, 28),
        msgCount: 1, updatedAt: '' });
    } catch (e) { /* ignore */ }
  }

  const userAt = atts.map((a) => ({ name: a.name, kind: a.kind }));
  chatHistory.push({ role: 'user', content: text, atts: userAt });
  if (curChatId) {
    api.agentChatAppend(curChatId, {
      role: 'user', content: text, atts: userAt,
    }).catch(() => {});
    // 自动抽取重要事实存进长期记忆
    api.agentMemAuto(text).catch(() => {});
  }

  // 实时进度占位
  const live = {
    role: 'assistant', content: '', trace: [], steps: [],
    model: (ov && ov.model) || '', thinking: true,
    startedAt: Date.now(),
  };
  chatHistory.push(live);
  chatting = true;
  paint(root);

  try {
    await api.agentChatStream({
      message: text,
      chatId: curChatId,
      history: chatHistory.slice(0, -2)
        .map((h) => ({ role: h.role, content: h.content })),
      autoRunTools: true,
      attachments: atts,
    }, (stage, ev) => {
      if (stage === 'thinking') {
        live.thinking = true;
        live.round = ev.round;
        repaintLive(root, live);
      } else if (stage === 'tool_start') {
        live.thinking = false;
        live.steps.push({ tool: ev.tool, ok: null, ms: null });
        repaintLive(root, live);
      } else if (stage === 'tool_end') {
        const st = live.steps.find((x) => x.tool === ev.tool && x.ok === null);
        if (st) { st.ok = ev.ok; st.ms = ev.ms; }
        else live.steps.push({ tool: ev.tool, ok: ev.ok, ms: ev.ms });
        live.trace.push({ tool: ev.tool, ok: ev.ok, ms: ev.ms });
        repaintLive(root, live);
      } else if (stage === 'reply') {
        live.thinking = false;
        live.content = ev.content || '';
        if (ev.usage) {
          lastUsage = Object.assign({}, ev.usage, { ctxPct: ev.ctxPct || 0 });
          const secs = (Date.now() - live.startedAt) / 1000;
          if (secs > 0 && ev.usage.completion) {
            lastSpeed = Math.round(ev.usage.completion / secs);
          }
        }
        repaintLive(root, live);
      } else if (stage === 'done') {
        live.thinking = false;
        live.model = ev.model || live.model;
        live.rounds = ev.rounds;
        if (ev.usage) {
          lastUsage = Object.assign({}, ev.usage,
            { ctxPct: ev.ctxPct || lastUsage && lastUsage.ctxPct || 0 });
        }
        if (ev.ok === false) {
          live.error = true;
          live.content = ev.error || '执行失败';
        } else {
          if (!live.content) live.content = ev.reply || '';
          if (ev.trace && ev.trace.length) live.trace = ev.trace;
        }
      }
    });
    live.thinking = false;
    live.elapsed = Math.round((Date.now() - live.startedAt) / 1000);
    if (!live.content && !live.error) live.content = '（无回复）';
  } catch (e) {
    live.thinking = false;
    live.error = true;
    live.content = '请求失败: ' + e.message;
  }

  // 存 AI 回复
  if (curChatId) {
    api.agentChatAppend(curChatId, {
      role: 'assistant', content: live.content || '',
      model: live.model || '', trace: live.trace || [],
      error: !!live.error,
    }).then(() => loadChats(root)).catch(() => {});
  }
  chatting = false;
  paint(root);
}


/* ══════════════════════════════════════════
   单条卡片渲染（实时进度复用）
   ══════════════════════════════════════════ */
function liveCardHtml(m, ov) {
  const name = (ov && ov.name) || '雨海 Agent';
  const model = m.model || (ov && ov.model) || '';
  const head = m.thinking
    ? `<div class="ag-think"><span class="ag-think-dot"></span>
       正在思考${m.round ? '（第 ' + m.round + ' 轮）' : ''}…</div>`
    : '';
  const steps = (m.steps || []).map((t) => `
    <div class="ag-tool ${t.ok === null ? 'run' : t.ok ? '' : 'fail'}">
      <span class="ag-tic">${t.ok === null ? '◌' : t.ok ? '✓' : '✗'}</span>
      <span class="ag-tnm">${esc(toolCN(t.tool))}</span>
      <span class="ag-tms">${t.ms == null ? '运行中…' : t.ms + 'ms'}</span>
    </div>`).join('');
  const tr = (m.trace || []).length && !steps
    ? (m.trace || []).map((t) => `
      <div class="ag-tool ${t.ok ? '' : 'fail'}">
        <span class="ag-tic">${t.ok ? '✓' : '✗'}</span>
        <span class="ag-tnm">${esc(toolCN(t.tool))}</span>
        <span class="ag-tms">${t.ms}ms</span>
      </div>`).join('')
    : '';
  const body = m.error
    ? `<div style="color:var(--danger);font-size:11px">${nl(m.content)}</div>`
    : (m.content ? nl(m.content) : '');
  return `
    <div class="ag-card ai">
      <div class="ag-ai-head">
        <div class="ag-avatar">雨</div>
        <div class="ag-ai-name">${esc(name)}</div>
        <div class="ag-ai-model">${esc(shortModel(model))}${
          m.elapsed ? ' · ' + m.elapsed + 's' : ''}</div>
      </div>
      ${head}
      ${body}
      ${steps ? `<div class="ag-tools">${steps}</div>` : ''}
      ${tr ? `<div class="ag-tools">${tr}</div>` : ''}
    </div>`;
}

/* 只重绘最后一条 AI 卡片（不整体重排，避免滚动跳动） */
let repaintScheduled = false;
let pendingLive = null;

/* 流式回复期间高频调用：合并到下一帧，避免每个 token 都重建 DOM。
   同时不整页 paint（那样会销毁输入框）。 */
function repaintLive(root, live) {
  pendingLive = live;
  if (repaintScheduled) return;
  repaintScheduled = true;
  const run = () => {
    repaintScheduled = false;
    const box = $('#ag-chat', root);
    if (!box) return;               // 不在对话页时不重建整页
    const cards = box.querySelectorAll('.ag-card.ai');
    const last = cards[cards.length - 1];
    if (!last) return;
    const wrap = document.createElement('div');
    wrap.innerHTML = liveCardHtml(pendingLive || live, ov);
    const fresh = wrap.firstElementChild;
    if (fresh && !last.contains(document.activeElement)) {
      last.replaceWith(fresh);      // 输入框不在卡片内，安全替换
    }
    scrollBottom(root);
  };
  if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
  else setTimeout(run, 16);
}

/* ══════════════════════════════════════════
   模型（带自动隐藏 + 网关开关）
   ══════════════════════════════════════════ */
function renderModels(ov) {
  const all = ov.models || [];
  const ms = showGateway ? all : all.filter((m) => !m.inGateway || m.inDsh);

  const groups = {};
  for (const m of ms) {
    const g = m.channel || m.source || (m.id.includes('/') ? m.id.split('/')[0] : '其它');
    (groups[g] = groups[g] || []).push(m);
  }

  const gwTotal = all.filter((m) => m.inGateway).length;
  const dshTotal = all.filter((m) => m.inDsh).length;

  const chips = Object.keys(groups).sort().map((g) => {
    const n = groups[g].length;
    const hid = groups[g].filter((x) => x.hidden).length;
    const allHid = hid === n;
    return `<button class="ag-chip ${allHid ? 'ghost' : ''}"
      data-hidech="${esc(g)}" data-to="${allHid ? '0' : '1'}">
      ${esc(g)} ${n}${hid ? `<span class="ag-chip-dim">隐${hid}</span>` : ''}</button>`;
  }).join('');

  const rowHtml = (m) => {
    const t = (ov.tested || {})[m.id];
    const st = t ? (t.ok ? 'ok' : 'bad') : '';
    return `<div class="ag-mrow">
      <div class="ag-mname" title="${esc(m.id)}">${esc(m.id)}</div>
      <div class="ag-mtags">
        ${m.inDsh ? '<i class="ag-tag dsh">dsh</i>' : ''}
        ${m.inGateway && !m.inDsh ? '<i class="ag-tag gw">网关</i>' : ''}
        ${m.vision ? '<i class="ag-tag v">视觉</i>' : ''}
      </div>
      <div class="ag-mstat ${st}">
        ${st === 'ok' ? '✓' : st === 'bad' ? '✗ ' + esc((t.error || '').slice(0, 14)) : ''}
      </div>
      <button class="ag-mbtn" data-test="${esc(m.id)}">测</button>
      <button class="ag-mbtn" data-hide="${esc(m.id)}"
        data-to="${m.hidden ? 0 : 1}">${m.hidden ? '显' : '隐'}</button>
    </div>`;
  };

  const sections = Object.keys(groups).sort().map((g) => {
    const list = groups[g];
    const shown = list.filter((m) => !m.hidden);
    return `<div class="ag-mgroup">
      <div class="ag-mghead">${esc(g)}
        <span class="ag-mgcnt">${shown.length}/${list.length}</span></div>
      ${shown.map(rowHtml).join('')}
      ${list.length - shown.length > 0
        ? `<div class="ag-mhidden">另有 ${list.length - shown.length} 个已隐藏</div>`
        : ''}
    </div>`;
  }).join('');

  const hiddenCount = all.filter((m) => m.hidden).length;

  return `
    <div class="ag-models">
      <div class="ag-mtop">
        <div class="ag-mmeta">
          端点 ${esc(short(ov.endpoint) || '本地')}<br>
          DSH 订阅 ${dshTotal} · 网关全量 ${gwTotal} · 隐藏 ${hiddenCount}
        </div>
        <div class="ag-mctl">
          <button class="ag-tbtn ${showGateway ? 'on' : ''}" data-act="gwtoggle">
            ${showGateway ? '显示网关全量' : '只看 DSH 订阅'}</button>
          <button class="ag-tbtn" data-act="testall">全测</button>
          <button class="ag-tbtn" data-act="autohide">测+自动隐藏坏的</button>
        </div>
      </div>
      <div class="ag-chips">${chips}</div>
      <div class="ag-mlist">${sections}</div>
    </div>`;
}

function bindModels(root) {
  const gwT = $('[data-act="gwtoggle"]', root);
  if (gwT) gwT.onclick = () => { showGateway = !showGateway; paint(root); };

  $$('[data-hide]', root).forEach((b) => {
    b.onclick = () => toggleHide(root, b.dataset.hide, b.dataset.to === '1');
  });
  $$('[data-hidech]', root).forEach((b) => {
    b.onclick = () => hideChannel(root, b.dataset.hidech, b.dataset.to === '1');
  });
  $$('[data-test]', root).forEach((b) => {
    b.onclick = () => testModel(root, b.dataset.test);
  });

  const ta = $('[data-act="testall"]', root);
  if (ta) ta.onclick = async () => {
    ta.disabled = true; ta.textContent = '测试中…';
    toast('批量测试', '逐个验证，较慢', 'info');
    try {
      const r = await api.agentTestAll({ agentId: ov.connected });
      toast('完成', `${r.passed} 可用 / ${r.failed} 不可用`, 'ok');
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    ta.disabled = false; ta.textContent = '全测';
  };

  const ah = $('[data-act="autohide"]', root);
  if (ah) ah.onclick = async () => {
    if (!confirm('会逐个实测全部模型，失败的自动隐藏。\n模型多时可能要几分钟，继续？')) return;
    ah.disabled = true; ah.textContent = '实测中…';
    toast('自动隐藏', '实测全部模型，失败的重试一次', 'info');
    try {
      const r = await api.agentTestAll({
        agentId: ov.connected, autoHide: true,
      });
      toast('完成',
        `${r.passed} 可用 / ${r.failed} 不可用，已隐藏 ${r.autoHidden || 0} 个`,
        (r.passed || 0) > 0 ? 'ok' : 'warn', 8000);
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    ah.disabled = false; ah.textContent = '测+自动隐藏坏的';
  };
}

async function toggleHide(root, mid, hidden) {
  try {
    await api.agentHide({ agentId: ov.connected, modelId: mid, hidden });
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function hideChannel(root, ch, hidden) {
  try {
    const r = await api.agentHideChannel({ agentId: ov.connected, channel: ch, hidden });
    toast(hidden ? '已隐藏' : '已显示', `${ch} ${r.count || ''} 个`, 'ok');
    await load(root);
  } catch (e) { toast('操作失败', e.message, 'err'); }
}

async function testModel(root, mid) {
  toast('测试中', mid, 'info');
  try {
    const r = await api.agentTest({ agentId: ov.connected, modelId: mid });
    toast(r.ok ? '可用' : '不可用',
      r.ok ? (r.reply || '').slice(0, 30) : (r.error || ''),
      r.ok ? 'ok' : 'err', 6000);
    await load(root);
  } catch (e) { toast('失败', e.message, 'err'); }
}

/* ══════════════════════════════════════════
   样式（方案 C）
   ══════════════════════════════════════════ */
const CARD_CSS = `
.ag-pane{position:relative;background:var(--bg-1);border:1px solid var(--line);
  border-radius:12px;overflow:hidden}
.ag-bg{position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(circle at 15% 5%,color-mix(in srgb, var(--ac) 10%, transparent),transparent 42%),
  radial-gradient(circle at 88% 90%,color-mix(in srgb, var(--ok) 8%, transparent),transparent 38%)}

/* ---- 顶部状态条 ---- */
.ag-topbar{display:flex;align-items:center;gap:9px;padding:11px 14px;
  background:var(--bg-2);border:1px solid var(--line);border-radius:9px;
  margin-bottom:11px}
.ag-dot{width:7px;height:7px;border-radius:50%;background:var(--ok);
  box-shadow:0 0 6px color-mix(in srgb, var(--ok) 53%, transparent);flex-shrink:0}
.ag-topname{font-size:12.5px;font-weight:600;color:var(--tx-0)}
.ag-topmeta{font-size:10px;color:var(--tx-2)}
.ag-topsep{flex:1}
.ag-tbtn{background:var(--bg-3);border:1px solid var(--line);border-radius:6px;
  color:var(--tx-2);font-size:10px;padding:4px 10px;cursor:pointer;
  font-family:inherit;transition:.15s}
.ag-tbtn:hover{background:var(--line);color:var(--tx-1)}
.ag-tbtn.on{background:color-mix(in srgb, var(--ac) 13%, transparent);border-color:color-mix(in srgb, var(--ac) 40%, transparent);color:var(--ac)}
.ag-tbtn.ghost{background:none}
.ag-cnt{opacity:.6;font-size:9px}

/* ---- 卡片 ---- */
.ag-chatwrap{border:1px solid var(--line);border-radius:11px;
  background:var(--bg-1);overflow:hidden;position:relative}
.ag-chatbody{height:calc(100vh - 320px);min-height:300px;overflow-y:auto;
  padding:15px;display:flex;flex-direction:column;gap:11px;
  background:radial-gradient(circle at 12% 0%,color-mix(in srgb, var(--ac) 8%, transparent),transparent 40%)}
.ag-card{border-radius:10px;padding:11px 13px;font-size:12px;line-height:1.72;
  animation:agIn .22s ease}
@keyframes agIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.ag-card.me{background:linear-gradient(135deg,color-mix(in srgb, var(--ac) 15%, transparent),color-mix(in srgb, var(--ac) 5%, transparent));
  border:1px solid color-mix(in srgb, var(--ac) 30%, transparent);align-self:flex-end;max-width:82%;color:var(--ac)}
.ag-card.ai{background:var(--bg-2);border:1px solid var(--bg-3);max-width:92%;
  color:var(--tx-1)}
.ag-ai-head{display:flex;align-items:center;gap:7px;margin-bottom:7px;
  padding-bottom:7px;border-bottom:1px solid var(--bg-3)}
.ag-avatar{width:20px;height:20px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:9px;color:#fff;
  font-weight:600}
.ag-ai-name{font-size:10.5px;color:var(--tx-0);font-weight:600}
.ag-ai-model{font-size:9px;color:var(--tx-3);margin-left:auto;
  font-family:var(--mono);max-width:55%;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}

/* ---- 工具链 ---- */
.ag-tools{margin-top:9px;display:flex;flex-direction:column;gap:4px}
.ag-tool{display:flex;align-items:center;gap:7px;background:var(--bg-1);
  border:1px solid var(--bg-3);border-left:2px solid var(--ok);border-radius:5px;
  padding:5px 9px;font-size:10px}
.ag-tool.fail{border-left-color:var(--danger)}
.ag-tic{color:var(--ok);flex-shrink:0}
.ag-tool.fail .ag-tic{color:var(--danger)}
.ag-tnm{color:var(--tx-1);font-size:10.5px;flex:1;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ag-tms{margin-left:auto;color:var(--tx-3)}

/* ---- 输入 ---- */
.ag-inputarea{padding:11px 13px 13px;border-top:1px solid var(--bg-3);
  background:color-mix(in srgb, var(--bg-2) 60%, transparent)}
.ag-inputbox{background:var(--bg-1);border:1px solid var(--line);border-radius:9px;
  padding:9px 11px;transition:.15s}
.ag-inputbox:focus-within{border-color:var(--ac);
  box-shadow:0 0 0 2px color-mix(in srgb, var(--ac) 13%, transparent)}
.ag-inputbox textarea{width:100%;background:none;border:none;outline:none;
  color:var(--tx-1);font-size:12px;resize:none;font-family:inherit;
  line-height:1.6}
.ag-inputbox textarea::placeholder{color:var(--tx-3)}
.ag-actions{display:flex;align-items:center;gap:8px;margin-top:7px}
.ag-mini{background:none;border:none;color:var(--tx-3);font-size:9.5px;
  cursor:pointer;padding:2px 4px;font-family:inherit}
.ag-mini:hover{color:var(--tx-1)}
.ag-hintline{flex:1;font-size:9px;color:var(--tx-3);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-sendbtn{background:linear-gradient(135deg,var(--ac),var(--ac-2));border:none;
  border-radius:6px;color:#fff;font-size:11px;font-weight:500;
  padding:5px 15px;cursor:pointer;font-family:inherit}
.ag-sendbtn:disabled{opacity:.5;cursor:default}

/* ---- 空状态 ---- */
.ag-empty{display:flex;flex-direction:column;align-items:center;
  justify-content:center;flex:1;padding:26px 14px;text-align:center}
.ag-empty-ico{width:44px;height:44px;border-radius:50%;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:17px;color:#fff;
  font-weight:600;margin-bottom:13px;
  box-shadow:0 4px 18px color-mix(in srgb, var(--ac) 27%, transparent)}
.ag-empty-t{font-size:12.5px;color:var(--tx-0);font-weight:600;margin-bottom:14px}
.ag-empty-hints{display:flex;flex-direction:column;gap:6px;width:100%;
  max-width:420px}
.ag-hint-item{text-align:left;font-size:11px;color:var(--tx-2);
  background:var(--bg-2);border:1px solid var(--bg-3);border-radius:7px;
  padding:7px 11px;cursor:pointer;transition:.15s}
.ag-hint-item:hover{background:color-mix(in srgb, var(--ac) 10%, transparent);border-color:color-mix(in srgb, var(--ac) 30%, transparent);
  color:var(--ac);transform:translateX(2px)}
.ag-hint-arr{color:var(--ac);margin-right:6px;font-weight:600}

/* ---- 打字动画 ---- */
.ag-typing{display:flex;gap:4px;padding:4px 0}
.ag-typing span{width:5px;height:5px;border-radius:50%;background:var(--ac);
  animation:agBlink 1.3s infinite}
.ag-typing span:nth-child(2){animation-delay:.18s}
.ag-typing span:nth-child(3){animation-delay:.36s}
@keyframes agBlink{0%,60%,100%{opacity:.25}30%{opacity:1}}

/* ---- 扫描动画 ---- */
.ag-scan{width:60px;height:60px;margin:0 auto 18px;border-radius:50%;
  border:2px solid color-mix(in srgb, var(--ac) 20%, transparent);position:relative}
.ag-scan:after{content:'';position:absolute;inset:-2px;border-radius:50%;
  border:2px solid transparent;border-top-color:var(--ac);
  animation:agSpin 1s linear infinite}
@keyframes agSpin{to{transform:rotate(360deg)}}

/* ---- Agent 选择卡片 ---- */
.ag-agent-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));
  gap:10px}
.ag-agent-card{position:relative;background:var(--bg-2);border:1px solid var(--line);
  border-radius:10px;padding:12px 13px;cursor:pointer;transition:.18s;
  overflow:hidden}
.ag-agent-card:hover{border-color:color-mix(in srgb, var(--ac) 40%, transparent);transform:translateY(-2px);
  box-shadow:0 6px 20px var(--sh-2)}
.ag-agent-card.on{border-color:color-mix(in srgb, var(--ok) 53%, transparent);background:var(--bg-2);
  box-shadow:0 0 0 1px color-mix(in srgb, var(--ok) 20%, transparent) inset}
.ag-agent-card.on:before{content:'';position:absolute;left:0;top:0;bottom:0;
  width:3px;background:linear-gradient(180deg,var(--ok),var(--ok))}
.ag-agent-card.off{opacity:.5}
.ag-agent-card.off:hover{opacity:.75}
.ag-agent-top{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.ag-agent-ico{width:26px;height:26px;border-radius:7px;flex-shrink:0;
  background:linear-gradient(135deg,var(--ac),var(--purple));display:flex;
  align-items:center;justify-content:center;font-size:10px;color:#fff;
  font-weight:600}
.ag-agent-card.on .ag-agent-ico{background:linear-gradient(135deg,var(--ok),#2a9d5c)}
.ag-agent-name{font-size:12px;font-weight:600;color:var(--tx-0)}
.ag-agent-badge{font-size:8.5px;padding:2px 6px;border-radius:4px;
  background:color-mix(in srgb, var(--ok) 15%, transparent);border:1px solid color-mix(in srgb, var(--ok) 33%, transparent);color:var(--ok);
  margin-left:auto}
.ag-agent-why{font-size:10px;color:var(--tx-2);line-height:1.6;margin-bottom:6px;
  min-height:28px}
.ag-agent-stat{font-size:10px;color:var(--tx-2)}
.ag-ok{color:var(--ok)}.ag-dim{color:var(--tx-3)}
.ag-agent-dl{font-size:9.5px;color:var(--ac);margin-top:5px;
  text-decoration:underline}
.ag-agent-divider{grid-column:1/-1;font-size:10px;color:var(--tx-3);
  padding:9px 0 3px;border-bottom:1px solid var(--bg-3);margin-bottom:2px}

/* ---- 模型列表 ---- */
.ag-models{}
.ag-mtop{display:flex;align-items:center;gap:10px;background:var(--bg-2);
  border:1px solid var(--line);border-radius:9px;padding:10px 13px;
  margin-bottom:10px}
.ag-mmeta{font-size:9.5px;color:var(--tx-2);line-height:1.8}
.ag-mctl{margin-left:auto;display:flex;gap:6px;flex-wrap:wrap}
.ag-chips{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:11px}
.ag-chip{background:var(--bg-2);border:1px solid var(--line);border-radius:12px;
  color:var(--tx-2);font-size:9.5px;padding:3px 9px;cursor:pointer;
  font-family:inherit;transition:.15s}
.ag-chip:hover{background:color-mix(in srgb, var(--ac) 10%, transparent);border-color:color-mix(in srgb, var(--ac) 33%, transparent);color:var(--ac)}
.ag-chip.ghost{opacity:.42}
.ag-chip-dim{opacity:.45;margin-left:3px}
.ag-mlist{max-height:calc(100vh - 380px);overflow-y:auto;padding-right:3px}
.ag-mgroup{margin-bottom:12px}
.ag-mghead{font-size:9.5px;color:var(--tx-3);font-family:var(--mono);
  margin-bottom:5px;letter-spacing:.3px}
.ag-mgcnt{opacity:.55;margin-left:5px}
.ag-mrow{display:flex;align-items:center;gap:7px;padding:5px 9px;
  background:var(--bg-2);border:1px solid var(--bg-3);border-radius:6px;
  margin-bottom:3px;transition:.12s}
.ag-mrow:hover{border-color:var(--line);background:var(--bg-3)}
.ag-mname{font-size:10px;color:var(--tx-1);font-family:var(--mono);flex:1;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ag-mtags{display:flex;gap:3px;flex-shrink:0}
.ag-tag{font-size:8px;padding:1px 5px;border-radius:3px;font-style:normal}
.ag-tag.dsh{background:color-mix(in srgb, var(--ok) 15%, transparent);color:var(--ok)}
.ag-tag.gw{background:color-mix(in srgb, var(--purple) 15%, transparent);color:var(--purple)}
.ag-tag.v{background:color-mix(in srgb, var(--ac) 15%, transparent);color:var(--ac)}
.ag-mstat{font-size:9px;flex-shrink:0;max-width:100px;overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-mstat.ok{color:var(--ok)}.ag-mstat.bad{color:var(--danger)}
.ag-mbtn{background:var(--bg-3);border:1px solid var(--line);border-radius:4px;
  color:var(--tx-2);font-size:9px;padding:2px 7px;cursor:pointer;
  font-family:inherit;flex-shrink:0}
.ag-mbtn:hover{background:var(--line);color:var(--tx-1)}
.ag-mhidden{font-size:9px;color:var(--tx-3);padding:4px 0 0 9px}

/* ---- 模型下拉 ---- */
.ag-modelsel{position:relative;display:flex;align-items:center;gap:5px;
  background:var(--bg-3);border:1px solid var(--line);border-radius:6px;
  padding:4px 9px;cursor:pointer;font-size:10px;max-width:220px}
.ag-modelsel:hover{border-color:var(--ac-line)}
.ag-sel-cur{color:var(--tx-1);font-family:var(--mono);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap}
.ag-sel-arr{color:var(--tx-3);font-size:8px;flex-shrink:0}
.ag-sel-pop{display:none;position:absolute;top:calc(100% + 4px);right:0;
  width:340px;max-height:320px;overflow-y:auto;background:var(--bg-2);
  border:1px solid var(--line);border-radius:8px;padding:5px;
  box-shadow:var(--sh-3);z-index:200}
.ag-sel-pop.open{display:block}
.ag-sel-row{display:flex;align-items:center;gap:6px;padding:5px 8px;
  border-radius:5px;cursor:pointer;font-size:10px}
.ag-sel-row:hover{background:var(--ac-dim)}
.ag-sel-row.on{background:var(--ac-dim);color:var(--ac)}
.ag-sel-nm{font-family:var(--mono);color:var(--tx-1);flex:1;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ---- 上传 ---- */
.ag-uploadb{width:24px;height:24px;border-radius:6px;background:var(--bg-3);
  border:1px solid var(--line);color:var(--tx-2);cursor:pointer;
  font-size:13px;line-height:1;flex-shrink:0;padding:0}
.ag-uploadb:hover{background:var(--ac-dim);border-color:var(--ac-line);
  color:var(--ac)}
.ag-attbar{display:none;flex-wrap:wrap;gap:6px;padding:0 0 7px}
.ag-att{display:flex;align-items:center;gap:6px;background:var(--bg-2);
  border:1px solid var(--line);border-radius:7px;padding:4px 7px;
  font-size:9.5px;max-width:230px}
.ag-att.img{border-color:var(--ac-line)}
.ag-att img{width:26px;height:26px;object-fit:cover;border-radius:4px}
.ag-att-ico{font-size:13px}
.ag-att-nm{color:var(--tx-1);overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap;max-width:130px}
.ag-att-sz{color:var(--tx-3);flex-shrink:0}
.ag-att-x{color:var(--tx-3);cursor:pointer;padding:0 3px;flex-shrink:0;
  font-size:11px}
.ag-att-x:hover{color:var(--danger)}
.ag-att-row{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;
  padding-top:6px;border-top:1px solid var(--ac-line)}
.ag-att-chip{font-size:9px;background:var(--ac-dim);color:var(--ac);
  border-radius:4px;padding:2px 6px}

/* ---- 会话下拉（DSH 右边） ---- */
.ag-chatsel{position:relative;display:flex;align-items:center;gap:5px;
  background:var(--bg-3);border:1px solid var(--line);border-radius:6px;
  padding:4px 9px;cursor:pointer;font-size:10px;max-width:170px}
.ag-chatsel:hover{border-color:var(--ac-line)}
.ag-cs-cur{color:var(--tx-1);overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap}
.ag-cs-pop{display:none;position:absolute;top:calc(100% + 4px);left:0;
  width:250px;max-height:340px;overflow-y:auto;background:var(--bg-2);
  border:1px solid var(--line);border-radius:8px;padding:5px;
  box-shadow:var(--sh-3);z-index:210}
.ag-cs-pop.open{display:block}
.ag-cs-new{font-size:10px;color:var(--ac);padding:7px 9px;cursor:pointer;
  border-bottom:1px solid var(--line);margin-bottom:4px}
.ag-cs-new:hover{background:var(--ac-dim)}
.ag-cs-row{display:flex;align-items:center;gap:6px;padding:5px 8px;
  border-radius:5px;cursor:pointer;font-size:10px}
.ag-cs-row:hover{background:var(--ac-dim)}
.ag-cs-row.on{background:var(--ac-dim);color:var(--ac)}
.ag-cs-nm{flex:1;color:var(--tx-1);overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap}
.ag-cs-meta{font-size:8.5px;color:var(--tx-3);flex-shrink:0}
.ag-cs-del{font-size:10px;color:var(--tx-3);padding:0 3px;flex-shrink:0}
.ag-cs-del:hover{color:var(--danger)}
.ag-cs-empty{font-size:9.5px;color:var(--tx-3);padding:14px;text-align:center}

/* ---- 摘要/记忆提示 ---- */
.ag-memtip{display:flex;align-items:center;gap:6px;background:var(--info-dim);
  border:1px solid var(--line);border-left:2px solid var(--info);
  border-radius:6px;padding:6px 10px;margin-bottom:9px;font-size:10px;
  color:var(--tx-2);line-height:1.6}
.ag-memtip b{color:var(--tx-1)}
.ag-memtip .ag-memx{margin-left:auto;color:var(--tx-3);cursor:pointer}

/* ---- 顶部统计 ---- */
.ag-stats{display:flex;align-items:center;gap:9px;margin-right:4px}
.ag-stats.dim{opacity:.42}
.ag-stat{display:flex;align-items:center;gap:4px;font-size:10px;
  color:var(--tx-2);font-family:var(--mono);white-space:nowrap}
.ag-si{font-size:10px;opacity:.75}

/* ---- 会话侧栏 ---- */
.ag-withside{display:flex;gap:11px;align-items:flex-start}
.ag-side{width:196px;flex-shrink:0;background:var(--bg-2);
  border:1px solid var(--line);border-radius:10px;overflow:hidden;
  display:flex;flex-direction:column;height:calc(100vh - 320px);
  min-height:300px}
.ag-side-head{display:flex;align-items:center;gap:5px;padding:8px}
.ag-newbtn{flex:1;background:var(--ac);border:none;border-radius:6px;
  color:#fff;font-size:10.5px;padding:6px 0;cursor:pointer;
  font-family:inherit;font-weight:500}
.ag-newbtn:hover{background:var(--ac-2)}
.ag-sidefold{background:var(--bg-3);border:1px solid var(--line);
  border-radius:5px;color:var(--tx-3);font-size:9px;padding:5px 6px;
  cursor:pointer;font-family:inherit}
.ag-side-search{padding:0 8px 8px}
.ag-side-search input{width:100%;background:var(--bg-1);
  border:1px solid var(--line);border-radius:5px;padding:4px 7px;
  font-size:9.5px;color:var(--tx-1);outline:none;font-family:inherit}
.ag-side-list{flex:1;overflow-y:auto;padding:0 6px 6px}
.ag-side-empty{text-align:center;color:var(--tx-3);font-size:10px;
  padding:28px 8px;line-height:1.9}
.ag-chatrow{position:relative;background:var(--bg-1);
  border:1px solid var(--line-soft);border-radius:7px;padding:7px 9px;
  margin-bottom:4px;cursor:pointer;transition:.13s}
.ag-chatrow:hover{border-color:var(--ac-line);background:var(--bg-3)}
.ag-chatrow.on{border-color:var(--ac);background:var(--ac-dim)}
.ag-crow-top{display:flex;align-items:center;gap:4px;margin-bottom:3px}
.ag-pin{font-size:8px;flex-shrink:0}
.ag-crow-t{font-size:10px;color:var(--tx-1);font-weight:500;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.ag-chatrow.on .ag-crow-t{color:var(--ac)}
.ag-crow-meta{font-size:8.5px;color:var(--tx-3)}
.ag-crow-act{position:absolute;right:5px;top:5px;display:none;gap:4px}
.ag-chatrow:hover .ag-crow-act{display:flex}
.ag-crow-act span{font-size:9px;color:var(--tx-3);cursor:pointer;padding:0 2px}
.ag-crow-act span:hover{color:var(--ac)}
.ag-crow-act span[data-cdel]:hover{color:var(--danger)}
.ag-unfold{position:absolute;left:8px;top:8px;z-index:10;
  background:var(--bg-3);border:1px solid var(--line);border-radius:5px;
  color:var(--tx-2);font-size:9px;padding:4px 7px;cursor:pointer;
  font-family:inherit}
.ag-main{flex:1;min-width:0}

/* ---- 思考中 / 工具运行中 ---- */
.ag-think{display:flex;align-items:center;gap:7px;font-size:11px;
  color:var(--tx-2);padding:3px 0}
.ag-think-dot{width:6px;height:6px;border-radius:50%;background:var(--ac);
  animation:agPulse 1.1s ease-in-out infinite;flex-shrink:0}
@keyframes agPulse{0%,100%{opacity:.3;transform:scale(.85)}
  50%{opacity:1;transform:scale(1.15)}}
.ag-tool.run{border-left-color:var(--warn)}
.ag-tool.run .ag-tic{color:var(--warn)}
.ag-tool.run .ag-tms{color:var(--warn)}
`;

/* ══════════════════════════════════════════
   长期记忆面板
   ══════════════════════════════════════════ */
function renderMem() {
  if (!memList.length) {
    return `
      <div class="ag-mempane">
        <div class="ag-memhead">
          <div>
            <div class="ag-memt">长期记忆</div>
            <div class="ag-memd">存在这里的话，每次对话都会带给模型</div>
          </div>
          <button class="ag-tbtn on" data-act="memnew">＋ 新增记忆</button>
        </div>
        <div class="ag-memempty">
          <div style="font-size:26px;opacity:.35">🧠</div>
          <div style="margin-top:9px">还没有记忆</div>
          <div style="font-size:10px;color:var(--tx-3);margin-top:5px;
            line-height:1.8">
            在对话里说「记住 xxx」会自动存一条<br>
            或者点上面「新增记忆」手动加
          </div>
        </div>
      </div>`;
  }

  const rows = memList.map((m) => `
    <div class="ag-memrow" data-mkey="${esc(m.key)}">
      <div class="ag-memk">${esc(m.key)}</div>
      <div class="ag-memv">${esc(m.value)}</div>
      <button class="ag-membtn" data-memedit="${esc(m.key)}">改</button>
      <button class="ag-membtn danger" data-memdel="${esc(m.key)}">删</button>
    </div>`).join('');

  return `
    <div class="ag-mempane">
      <div class="ag-memhead">
        <div>
          <div class="ag-memt">长期记忆 <span class="ag-memcnt">${memList.length}</span></div>
          <div class="ag-memd">
            存在这里的话，每次对话都会带给模型。写错的会一直影响判断，慎用。
          </div>
        </div>
        <button class="ag-tbtn on" data-act="memnew">＋ 新增记忆</button>
      </div>
      <div class="ag-memlist">${rows}</div>
    </div>`;
}

function bindMem(root) {
  $$('[data-memdel]', root).forEach((b) => {
    b.onclick = async () => {
      const k = b.dataset.memdel;
      if (!confirm('删掉这条记忆？\n\n' + k)) return;
      try {
        await api.agentMemDelete(k);
        toast('已删除', k, 'ok');
        await loadMem(root);
      } catch (e) { toast('删除失败', e.message, 'err'); }
    };
  });

  $$('[data-memedit]', root).forEach((b) => {
    b.onclick = async () => {
      const k = b.dataset.memedit;
      const cur = (memList.find((x) => x.key === k) || {}).value || '';
      const v = prompt('修改内容：\n' + k, cur);
      if (v == null) return;
      try {
        await api.agentMemSet(k, v);
        toast('已更新', k, 'ok');
        await loadMem(root);
      } catch (e) { toast('更新失败', e.message, 'err'); }
    };
  });

  $$('[data-act="memnew"]', root).forEach((b) => {
    b.onclick = async () => {
      const k = prompt('记忆的键（简短英文，如 publish_account）：', 'my_rule');
      if (!k) return;
      const v = prompt('内容（要模型遵守的规则或事实）：', '');
      if (v == null || !v) return;
      try {
        await api.agentMemSet(k, v);
        toast('已添加', k, 'ok');
        await loadMem(root);
      } catch (e) { toast('添加失败', e.message, 'err'); }
    };
  });
}

async function loadMem(root) {
  try {
    const r = await api.agentMemList();
    memList = r.items || [];
  } catch (e) { memList = []; }
  const box = $('#ag-body', root);
  if (box && tab === 'mem') {
    // 只重绘记忆区
    const pane = box.querySelector('.ag-mempane');
    if (pane) {
      const wrap = document.createElement('div');
      wrap.innerHTML = renderMem();
      const fresh = wrap.querySelector('.ag-mempane');
      if (fresh) pane.replaceWith(fresh);
      bindMem(root);
    } else {
      paint(root);
    }
  }
}

