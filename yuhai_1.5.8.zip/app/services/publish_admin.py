# -*- coding: utf-8 -*-
"""publish_admin.py — 发布内核管理工具

补齐 MCP 缺的三个能力（agent 没有它们就会卡死）：

  pub_state()          查内核状态：currentRun 是否被锁、哪些页面 halted、
                       哪些 assignment 停在 submission_intent（结果不确定）
  pub_unlock()         解除 needs_attention 锁（归档/结束本轮）
  pub_resolve()        标记某条 assignment 的结果（发成功 / 没发出去），
                       用于解决「点了发布但结果不确定」

为什么必须有
------------
ReelsPublisher 内核用 state.json 的 currentRun 记录本轮发布。
如果某条 assignment 停在 submission_intent（已点发布按钮但没拿到结果），
currentRun.state 会变 needs_attention，之后 createRun 直接抛 RUN_ACTIVE，
**所有后续发布全部被拦**。

原来只能人工到工作台 GUI 点「结束本轮/归档」才能解，
MCP 没这个工具，agent 就彻底卡住。
"""
from __future__ import annotations

import json
import logging
import shutil
import time
from pathlib import Path

log = logging.getLogger("yuhai.publish.admin")

# submission_intent = 已点击发布但未确认（结果不确定）
# halted            = 该主页被中止
# needs_attention   = 整个 run 需要人工介入
RISKY_STATES = ("submission_intent", "submitting", "publishing")


def state_path() -> Path:
    """state.json 的位置。"""
    from app.services import reels as rl
    try:
        return Path(rl.data_dir()) / "state.json"
    except Exception:
        pass
    p = Path(r"E:\ReelsPublisher-v19.7-Portable\resources\data\state.json")
    return p


def _load() -> dict:
    p = state_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log.debug("read state: %s", e)
        return {}


def _save(d: dict, backup: bool = True) -> str:
    p = state_path()
    bak = ""
    if backup and p.exists():
        try:
            bak = str(p.with_name(
                "state.json.bak-%s" % time.strftime("%Y%m%d-%H%M%S")))
            shutil.copy2(p, bak)
        except Exception:
            bak = ""
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return bak


def summary() -> dict:
    """查内核当前状态。"""
    d = _load()
    cr = d.get("currentRun") or {}
    state = cr.get("state") or ""
    pages = cr.get("pages") or []
    assigns = cr.get("assignments") or []

    halted = [{"pageId": p.get("pageId"), "name": p.get("name"),
               "state": p.get("state")}
              for p in pages if p.get("state") == "halted"]

    risky = []
    for a in assigns:
        st = str(a.get("state") or "")
        if st in RISKY_STATES or st in ("halted", "failed"):
            risky.append({
                "pageId": a.get("pageId"),
                "file": a.get("file") or a.get("source") or "",
                "state": st,
            })

    locked = state in ("needs_attention", "running", "paused") or bool(risky)

    return {
        "ok": True,
        "statePath": str(state_path()),
        "stateExists": state_path().exists(),
        "runId": cr.get("id"),
        "runState": state,
        "startedAt": cr.get("startedAt"),
        "materialRoot": cr.get("materialRoot"),
        "description": (cr.get("description") or "")[:120],
        "clipsPerPage": cr.get("clipsPerPage"),
        "pageCount": len(pages),
        "assignmentCount": len(assigns),
        "haltedPages": halted,
        "riskyAssignments": risky,
        "locked": locked,
        "needUnlock": state == "needs_attention" or bool(risky),
        "hint": ("内核被锁，需要 pub_unlock 解除"
                 if locked else "内核空闲，可以发布"),
    }


def unlock(resolve_as: str = "unknown", note: str = "") -> dict:
    """解除 needs_attention 锁。

    resolve_as:
      unknown   - 结果不确定（默认，最保守：当作已发，不重发）
      sent      - 确认发出去了
      failed    - 确认没发出去（会允许重发）

    做法：把 currentRun 归档到 history，清空 currentRun，
         并清理 risky assignment。
    """
    d = _load()
    if not d:
        return {"ok": False, "error": "state.json 不存在或读不了"}

    cr = d.get("currentRun")
    if not cr:
        return {"ok": True, "skipped": True, "reason": "没有 currentRun，本来就是空的"}

    before = {
        "runState": cr.get("state"),
        "runId": cr.get("id"),
        "assignments": len(cr.get("assignments") or []),
    }

    # 归档
    hist = d.setdefault("history", [])
    archived = dict(cr)
    archived["_archivedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    archived["_resolvedAs"] = resolve_as
    archived["_note"] = note
    hist.append(archived)
    if len(hist) > 50:
        d["history"] = hist[-50:]

    # 清理 currentRun
    d["currentRun"] = None

    # resolve_as=failed → 把这些素材从 usedHashes 里摘掉，允许重发。
    # ⚠ usedHashes 实际是 list[str]（sha256 列表），不是 dict。
    #   之前按 dict 处理导致清理从来没生效过（用户踩到的坑）。
    if resolve_as == "failed":
        try:
            used = d.get("usedHashes")
            if isinstance(used, dict):          # 兼容万一有人改成 dict
                used = list(used.keys())
            if not isinstance(used, list):
                used = []

            drop = set()
            for a in (cr.get("assignments") or []):
                # 各种可能的字段名都试一遍
                for k in ("hash", "sha", "sha256", "hashValue", "fileHash"):
                    v = a.get(k)
                    if v and isinstance(v, str) and len(v) >= 32:
                        drop.add(v)
                # 有些版本把 hash 记在 material / source 里
                for k in ("material", "source", "file"):
                    v = a.get(k)
                    if isinstance(v, dict):
                        for kk in ("hash", "sha", "sha256"):
                            vv = v.get(kk)
                            if vv:
                                drop.add(str(vv))

            # 如果 assignment 里没有 hash 字段，按路径算一遍
            if not drop:
                try:
                    import hashlib
                    from pathlib import Path
                    for a in (cr.get("assignments") or []):
                        fp = a.get("file") or a.get("source") or a.get("path")
                        if not fp:
                            continue
                        pf = Path(str(fp))
                        if pf.exists() and pf.is_file():
                            h = hashlib.sha256()
                            with open(pf, "rb") as fh:
                                for chunk in iter(lambda: fh.read(1 << 20), b""):
                                    h.update(chunk)
                            drop.add(h.hexdigest())
                except Exception as e:
                    log.debug("算 hash 失败: %s", e)

            before = len(used)
            if drop:
                d["usedHashes"] = [x for x in used if str(x) not in drop]
                removed = before - len(d["usedHashes"])
                log.warning("usedHashes 清理: %d → %d（移除 %d 个）",
                            before, len(d["usedHashes"]), removed)
            else:
                log.warning("usedHashes 未清理：assignment 里找不到任何 hash，"
                            "也无法从路径算（共 %d 条记录保留）", before)
        except Exception as e:
            log.warning("usedHashes 清理失败: %s", e)

    bak = _save(d)
    log.warning("发布内核解锁: %s → %s (resolveAs=%s)", before, "idle", resolve_as)

    return {
        "ok": True,
        "archived": before,
        "resolveAs": resolve_as,
        "backup": bak,
        "state": summary(),
    }


def resolve_assignment(page_id: str = "", file_hint: str = "",
                       result: str = "sent", note: str = "") -> dict:
    """标记某条 assignment 的最终结果，不用整体解锁。

    result: sent（发出去了）/ failed（没发出去）
    """
    d = _load()
    cr = d.get("currentRun") or {}
    assigns = cr.get("assignments") or []
    if not assigns:
        return {"ok": False, "error": "没有 currentRun.assignments"}

    hit = []
    for a in assigns:
        if page_id and str(a.get("pageId")) != str(page_id):
            continue
        f = str(a.get("file") or a.get("source") or "")
        if file_hint and file_hint not in f:
            continue
        hit.append(a)

    if not hit:
        return {"ok": False,
                "error": "没找到匹配的 assignment（pageId=%s file=%s）"
                         % (page_id, file_hint)}

    for a in hit:
        a["state"] = "done" if result == "sent" else "failed"
        a["_resolvedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        a["_resolveNote"] = note

    # 如果所有 assignment 都落定了，顺手解锁
    still_risky = [a for a in assigns
                   if str(a.get("state")) in RISKY_STATES]
    if not still_risky and cr.get("state") == "needs_attention":
        cr["state"] = "completed"

    bak = _save(d)
    return {
        "ok": True,
        "resolved": len(hit),
        "result": result,
        "stillRisky": len(still_risky),
        "backup": bak,
        "state": summary(),
    }


def hash_of_file(path: str) -> str:
    """算文件 sha256（跟 worker 一致的算法）。"""
    import hashlib
    from pathlib import Path
    pf = Path(str(path or ""))
    if not pf.exists() or not pf.is_file():
        return ""
    h = hashlib.sha256()
    with open(pf, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def used_hashes() -> list[str]:
    d = _load()
    uh = d.get("usedHashes")
    if isinstance(uh, dict):
        return [str(k) for k in uh.keys()]
    if isinstance(uh, list):
        return [str(x) for x in uh]
    return []


def release_hash(file_path: str = "", hash_value: str = "") -> dict:
    """从 usedHashes 里放出某个文件（允许重发）。

    两个入口：
      file_path   传文件路径 → 自动算 sha256 再释放
      hash_value  直接传 sha256
    """
    d = _load()
    if not d:
        return {"ok": False, "error": "state.json 读不到"}

    uh = d.get("usedHashes")
    is_dict = isinstance(uh, dict)
    cur = used_hashes()
    if not cur:
        return {"ok": True, "skipped": True, "reason": "usedHashes 本来就是空的"}

    target = (hash_value or "").strip().lower()
    if not target:
        target = hash_of_file(file_path).lower()
        if not target:
            return {"ok": False,
                    "error": "算不出 hash：文件不存在或路径错误 %r" % (file_path,)}

    if target not in cur:
        return {"ok": True, "skipped": True,
                "reason": "这个 hash 不在 usedHashes 里",
                "hash": target, "usedCount": len(cur)}

    if is_dict:
        uh.pop(target, None)
        # 大小写不敏感的兜底
        for k in list(uh.keys()):
            if str(k).lower() == target:
                uh.pop(k, None)
    else:
        d["usedHashes"] = [x for x in cur if str(x).lower() != target]

    bak = _save(d)
    left = len(used_hashes())
    log.warning("释放 hash %s...  usedHashes %d → %d",
                target[:16], len(cur), left)

    return {"ok": True, "released": target, "before": len(cur),
            "after": left, "backup": bak}


def list_used(limit: int = 0) -> dict:
    """列 usedHashes，并尽量反查对应文件。"""
    from pathlib import Path
    d = _load()
    cur = used_hashes()
    # 从 _pub_log.jsonl 反查 hash → 文件
    mapping = {}
    log_path = Path(r"E:\雨海工作台\_pub_log.jsonl")
    if log_path.exists():
        try:
            import json as _j
            for ln in log_path.read_text(encoding="utf-8", errors="replace").split("\n"):
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    o = _j.loads(ln)
                except Exception:
                    continue
                h = str(o.get("hash") or o.get("sha256") or "").lower()
                if h:
                    mapping[h] = {
                        "file": o.get("src") or o.get("file") or "",
                        "page": o.get("pageName") or o.get("pageId") or "",
                        "drama": o.get("drama") or "",
                        "at": o.get("at") or o.get("ts") or "",
                    }
        except Exception:
            pass

    items = []
    for h in cur:
        info = mapping.get(h.lower()) or {}
        items.append({"hash": h[:24] + "...", "hashFull": h,
                      "file": info.get("file", ""),
                      "page": info.get("page", ""),
                      "drama": info.get("drama", ""),
                      "at": info.get("at", "")})
    if limit:
        items = items[:int(limit)]
    return {"ok": True, "count": len(cur), "items": items,
            "logFound": bool(mapping)}


def _read_max_clips() -> int:
    """从 worker 源码读真实的 MAX_CLIPS_PER_PAGE。读不到就返回 20。"""
    import re as _re
    from pathlib import Path
    cands = [
        Path(r"E:\ReelsPublisher-v19.7-Portable\resources\worker\src"
             r"\core\batch_size.mjs"),
        Path(r"E:\ReelsPublisher-v19.7-Portable\resources\worker\src"
             r"\batch_size.mjs"),
    ]
    for c in cands:
        if not c.exists():
            continue
        try:
            txt = c.read_text(encoding="utf-8", errors="replace")
            m = _re.search(r"MAX_CLIPS_PER_PAGE\s*=\s*(\d+)", txt)
            if m:
                return int(m.group(1))
        except Exception:
            pass
    return 20


def publish_delay_options() -> dict:
    """说明定时发布的能力边界（Meta 原生排定）。"""
    return {
        "ok": True,
        "mode": "meta_native_scheduling",
        "rule": ("同一主页一次提交多条（clipsPerPage>1）时启用原生定时："
                 "第 1 条立即发，之后每条按 intervalMinutes 递增。"
                 "例：clipsPerPage=6, intervalMinutes=30 → "
                 "0/30/60/90/120/150 分钟"),
        "clipsPerPage1": "clipsPerPage=1 是全部即时发，不做定时",
        "maxPerBatch": _read_max_clips(),
        "defaultClips": 6,
        "defaultIntervalMinutes": 30,
        "intervalsFormula": "offset = slot * intervalMinutes（slot 从 1 起）",
        "alternative": ("需要 120 分钟以上的间隔，走工作台「排期与队列」"
                        "（schedule_queue），那条链路独立于本次发布"),
        "titleSource": ("🔍Title 里的剧名由 worker 用【视频所在文件夹名】替换，"
                        "所以素材目录名必须是英文剧名才能得到英文标题"),
    }
