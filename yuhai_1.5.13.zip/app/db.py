"""SQLite 访问层。WAL 模式，单写多读，全部走 aiosqlite 之外的轻封装（同步连接 + 线程锁）。

表设计见 SCHEMA。所有时间戳统一 ISO8601 带时区（Asia/Shanghai）。
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Sequence

from app.config import settings

log = logging.getLogger("yuhai.db")


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

-- 指纹浏览器环境
CREATE TABLE IF NOT EXISTS envs (
  container_code TEXT PRIMARY KEY,
  container_id   TEXT,
  name           TEXT NOT NULL,
  role           TEXT NOT NULL DEFAULT 'spare',   -- publisher | backup | spare
  account        TEXT,
  c_user         TEXT,
  display_name   TEXT,
  profile_dir    TEXT,
  proxy_type     TEXT,
  proxy_host     TEXT,
  proxy_port     INTEGER,
  proxy_kind     TEXT,                            -- datacenter | residential
  status         TEXT NOT NULL DEFAULT 'closed',  -- running | closed
  pid            INTEGER,
  cdp_port       INTEGER,
  egress_ip      TEXT,
  egress_country TEXT,
  kernel         TEXT,
  login_valid    INTEGER,                          -- 1/0/NULL
  last_checked   TEXT,
  raw            TEXT,
  updated_at     TEXT NOT NULL
);

-- 公共主页
CREATE TABLE IF NOT EXISTS pages (
  page_id      TEXT PRIMARY KEY,          -- 真实 profile id
  asset_id     TEXT,                      -- Business Suite asset id
  name         TEXT NOT NULL,
  drama        TEXT,
  genre        TEXT,
  followers    INTEGER DEFAULT 0,
  views_30d    INTEGER DEFAULT 0,
  published    INTEGER DEFAULT 0,
  health       TEXT NOT NULL DEFAULT 'ok', -- ok | restricted | pending
  env_code     TEXT,
  skip_publish INTEGER NOT NULL DEFAULT 0, -- 1 = 自动发布跳过（我手动发过的）
  skip_reason  TEXT,
  created_at   TEXT,
  last_seen    TEXT,
  raw          TEXT
);
CREATE INDEX IF NOT EXISTS idx_pages_env ON pages(env_code);

-- 主页授权
CREATE TABLE IF NOT EXISTS page_roles (
  page_id    TEXT NOT NULL,
  c_user     TEXT NOT NULL,              -- 被授权账号
  role       TEXT NOT NULL DEFAULT 'full',
  state      TEXT NOT NULL DEFAULT 'active', -- active | pending | missing
  granted_at TEXT,
  checked_at TEXT,
  note       TEXT,
  PRIMARY KEY (page_id, c_user)
);

-- 播放量快照（按主页按天）
CREATE TABLE IF NOT EXISTS insights (
  page_id   TEXT NOT NULL,
  date      TEXT NOT NULL,
  views     INTEGER DEFAULT 0,
  reach     INTEGER DEFAULT 0,
  minutes   INTEGER DEFAULT 0,
  reactions INTEGER DEFAULT 0,
  comments  INTEGER DEFAULT 0,
  shares    INTEGER DEFAULT 0,
  collected_at TEXT,
  PRIMARY KEY (page_id, date)
);

-- 素材库（成品）
CREATE TABLE IF NOT EXISTS library (
  id         TEXT PRIMARY KEY,
  path       TEXT NOT NULL,
  file       TEXT NOT NULL,
  drama      TEXT,
  dtype      TEXT,
  line       TEXT NOT NULL DEFAULT 'single',  -- single | premium
  ep         TEXT,
  dur        REAL,
  size_mb    REAL,
  width      INTEGER,
  height     INTEGER,
  made_at    TEXT,
  state      TEXT NOT NULL DEFAULT 'ready',   -- ready | used | blocked
  qc_lines   INTEGER,
  qc_no_overlap INTEGER,
  qc_no_silence INTEGER,
  qc_loudness   REAL,
  qc_complete   INTEGER,
  block_reason  TEXT,
  used_by    TEXT,
  tags       TEXT,                            -- JSON 数组，含剧名
  day_dir    TEXT,                            -- 日期文件夹名
  copyright_ok INTEGER,                       -- 1 通过 / 0 不过 / NULL 未检
  copyright_note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lib_drama ON library(drama);

-- 待发队列
CREATE TABLE IF NOT EXISTS queue (
  id       TEXT PRIMARY KEY,
  lib_id   TEXT,
  path     TEXT NOT NULL,
  file     TEXT NOT NULL,
  drama    TEXT,
  ep       TEXT,
  page     TEXT,
  dur      REAL,
  size_mb  REAL,
  state    TEXT NOT NULL DEFAULT 'ready',  -- ready | scheduled | publishing | done | failed
  added_at TEXT NOT NULL,
  note     TEXT
);

-- 发布幂等占位（同一批主页+素材+条数只能有一个活动任务）
CREATE TABLE IF NOT EXISTS publish_locks (
  signature  TEXT PRIMARY KEY,
  job_id     TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- 建页记录（按号精确统计额度，取代 events 文本 LIKE 匹配）
CREATE TABLE IF NOT EXISTS page_creates (
  id         TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  c_user     TEXT,
  page_id    TEXT,
  name       TEXT,
  state      TEXT NOT NULL DEFAULT 'reserved',  -- reserved | ok | failed
  job_id     TEXT,
  note       TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pc_acct ON page_creates(account_id, created_at);
CREATE INDEX IF NOT EXISTS idx_pc_job  ON page_creates(job_id);

-- 排期
CREATE TABLE IF NOT EXISTS schedule (
  id       TEXT PRIMARY KEY,
  page     TEXT NOT NULL,
  date     TEXT NOT NULL,
  time     TEXT NOT NULL,
  drama    TEXT,
  ep       TEXT,
  queue_id TEXT,
  state    TEXT NOT NULL DEFAULT 'planned', -- planned | running | done | blocked | skipped
  created_at TEXT NOT NULL,
  note     TEXT
);
CREATE INDEX IF NOT EXISTS idx_sched_date ON schedule(date, time);

-- 任务（长期执行的作业）
CREATE TABLE IF NOT EXISTS jobs (
  id        TEXT PRIMARY KEY,
  kind      TEXT NOT NULL,          -- create_pages | authz | extract | publish | pipeline | scan
  title     TEXT NOT NULL,
  status    TEXT NOT NULL DEFAULT 'queued', -- queued | running | done | failed | blocked | cancelled
  progress  INTEGER DEFAULT 0,
  steps     TEXT,                   -- JSON [{name,state,note}]
  payload   TEXT,
  result    TEXT,
  error     TEXT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  ended_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at);

-- 邮件
CREATE TABLE IF NOT EXISTS mails (
  id        TEXT PRIMARY KEY,
  mailbox   TEXT NOT NULL,
  source    TEXT NOT NULL,           -- imap | api | webhook | browser | manual
  sender    TEXT,
  subject   TEXT,
  body      TEXT,
  code      TEXT,
  received_at TEXT,
  fetched_at  TEXT,
  seen      INTEGER DEFAULT 0,
  matched   TEXT,
  uid       TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_mail_uid ON mails(mailbox, uid);
CREATE INDEX IF NOT EXISTS idx_mail_time ON mails(received_at DESC);

-- 邮箱通道配置
CREATE TABLE IF NOT EXISTS mail_accounts (
  id       TEXT PRIMARY KEY,
  kind     TEXT NOT NULL,            -- imap | graph | gmail | webhook | browser | manual
  label    TEXT NOT NULL,
  enabled  INTEGER NOT NULL DEFAULT 1,
  config   TEXT,                     -- JSON
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- 第三方对接
CREATE TABLE IF NOT EXISTS integrations (
  id       TEXT PRIMARY KEY,
  kind     TEXT NOT NULL,
  label    TEXT NOT NULL,
  enabled  INTEGER NOT NULL DEFAULT 0,
  config   TEXT,
  state    TEXT NOT NULL DEFAULT 'unconfigured',
  last_test TEXT,
  last_error TEXT,
  updated_at TEXT NOT NULL
);

-- 事件流（前端日志页用）
CREATE TABLE IF NOT EXISTS events (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  ts     TEXT NOT NULL,
  level  TEXT NOT NULL,              -- info | ok | warn | err
  source TEXT,
  msg    TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts DESC);

-- 风控事件（跳脸 / 限流 / 验证）
CREATE TABLE IF NOT EXISTS guard_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  ts         TEXT NOT NULL,
  kind       TEXT NOT NULL,          -- checkpoint|captcha|action_block|session_verify|rate_limit|suspicious
  severity   TEXT NOT NULL,          -- critical|high|medium
  scope      TEXT NOT NULL,          -- page|account|global
  env_code   TEXT,
  page_id    TEXT,
  message    TEXT,
  matched    TEXT,
  url        TEXT,
  resolved   INTEGER NOT NULL DEFAULT 0,
  resolved_at TEXT,
  note       TEXT
);
CREATE INDEX IF NOT EXISTS idx_guard_open ON guard_events(resolved, ts DESC);

-- 发布单元（一次发布的独立记录；推广矩阵下剧名可有可无）
CREATE TABLE IF NOT EXISTS units (
  id          TEXT PRIMARY KEY,
  page_id     TEXT NOT NULL,
  asset_id    TEXT,
  video_hash  TEXT,
  file        TEXT,
  title       TEXT,                  -- 文案标题，不是剧名
  caption     TEXT,
  tags        TEXT,
  published_at TEXT,                 -- 原始文本（如「11月5日 03:40」）
  published_date TEXT,               -- 解析后的 ISO 日期，用于 30 天窗口
  post_id     TEXT,
  tracker     TEXT,                  -- 追踪短链/参数
  state       TEXT NOT NULL DEFAULT 'pending', -- pending|published|failed|blocked
  error       TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_units_page ON units(page_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_units_time ON units(published_at DESC);

-- 单条视频指标快照（核心表：按 unit 按天）
CREATE TABLE IF NOT EXISTS unit_metrics (
  unit_id    TEXT NOT NULL,
  date       TEXT NOT NULL,
  plays      INTEGER DEFAULT 0,
  reach      INTEGER DEFAULT 0,
  reactions  INTEGER DEFAULT 0,
  comments   INTEGER DEFAULT 0,
  shares     INTEGER DEFAULT 0,
  saves      INTEGER DEFAULT 0,
  watch_sec  INTEGER DEFAULT 0,
  avg_watch  REAL DEFAULT 0,
  completion REAL DEFAULT 0,         -- 完播率 0-1
  clicks     INTEGER DEFAULT 0,      -- 出站点击（追踪链）
  collected_at TEXT,
  source     TEXT,                   -- cdp | graph | manual
  PRIMARY KEY (unit_id, date)
);
CREATE INDEX IF NOT EXISTS idx_um_date ON unit_metrics(date DESC);

-- 账号主体（多号架构：一个号 = 一个 FB 个人号 + 一个环境 + 若干主页）
CREATE TABLE IF NOT EXISTS accounts (  id         TEXT PRIMARY KEY,
  label      TEXT NOT NULL,          -- 显示名，如「发布号01」
  role       TEXT NOT NULL,          -- publisher | backup
  c_user     TEXT,                   -- FB 个人号 id
  email      TEXT,
  env_code   TEXT,                   -- 关联 Hubstudio 环境
  group_name TEXT,                   -- 分组（如「组A」多号时用）
  page_quota TEXT NOT NULL DEFAULT 'new',  -- new(新号6-7) | limited(受限1-2) | blocked(禁建)
  quota_note TEXT,                   -- 额度变更原因
  quota_set_at TEXT,                 -- 最近一次额度变更时间
  enabled    INTEGER NOT NULL DEFAULT 1,
  note       TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_acct_role ON accounts(role, enabled);

-- 主页授权记录（多授权号：一个主页可授给多个号）
CREATE TABLE IF NOT EXISTS page_role_map (
  page_id    TEXT NOT NULL,
  account_id TEXT NOT NULL,
  c_user     TEXT,
  role       TEXT NOT NULL DEFAULT 'admin',  -- admin | editor
  state      TEXT NOT NULL DEFAULT 'active', -- active | pending | missing
  granted_at TEXT,
  checked_at TEXT,
  PRIMARY KEY (page_id, account_id)
);

-- 键值设置
CREATE TABLE IF NOT EXISTS kv (
  k TEXT PRIMARY KEY,
  v TEXT
);

-- 发布文案模板（可填一条参考文案，让模型生成多个变体）
CREATE TABLE IF NOT EXISTS caption_templates (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  body       TEXT NOT NULL,          -- 参考文案，含 {{DRAMA}} {{LINK}} 占位
  vars       TEXT,                   -- JSON: 可用变量说明
  enabled    INTEGER NOT NULL DEFAULT 1,
  used_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- 生成好的文案变体
CREATE TABLE IF NOT EXISTS caption_variants (
  id         TEXT PRIMARY KEY,
  template_id TEXT,
  page_id    TEXT,
  body       TEXT NOT NULL,
  source     TEXT,                   -- model:xxx | manual
  enabled    INTEGER NOT NULL DEFAULT 1,
  used_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- AI 分析结果（主页受众画像 + 内容适配建议）
CREATE TABLE IF NOT EXISTS ai_analysis (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  scope      TEXT NOT NULL,          -- page | global
  target     TEXT,                   -- page_id（global 时为空）
  kind       TEXT NOT NULL,          -- audience | content_fit | summary
  model      TEXT,
  input_json TEXT,
  result     TEXT,
  confidence REAL,
  sample_size INTEGER,
  ts         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_scope ON ai_analysis(scope, target, ts DESC);

-- 主页内容适配偏好（AI 产出，发布选素材时匹配）
CREATE TABLE IF NOT EXISTS page_fit (
  page_id    TEXT PRIMARY KEY,
  drama_type TEXT,                   -- 偏好的剧型 id
  keywords   TEXT,                   -- JSON 数组，偏好的内容关键词
  avoid      TEXT,                   -- JSON 数组，应避开的
  reason     TEXT,
  confidence REAL,
  sample_size INTEGER,
  model      TEXT,
  ts         TEXT NOT NULL
);

-- 推广链接池（多链接随机）
CREATE TABLE IF NOT EXISTS promo_links (
  id         TEXT PRIMARY KEY,
  label      TEXT NOT NULL,
  url        TEXT NOT NULL,
  page_id    TEXT,                   -- 空 = 全局可用
  weight     INTEGER NOT NULL DEFAULT 1,
  enabled    INTEGER NOT NULL DEFAULT 1,
  note       TEXT,
  used_count INTEGER NOT NULL DEFAULT 0,
  last_used  TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_link_page ON promo_links(page_id, enabled);

-- 标题池（大模型生成的多版本标题）
CREATE TABLE IF NOT EXISTS title_pool (
  id         TEXT PRIMARY KEY,
  page_id    TEXT NOT NULL,
  title      TEXT NOT NULL,
  ref        TEXT,                   -- 参考标题
  source     TEXT,                   -- generated | manual | reference
  enabled    INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_title_page ON title_pool(page_id, enabled);

-- 发布链接提取记录（本次提取了哪些，防止重复提取）
CREATE TABLE IF NOT EXISTS link_extracts (  id         TEXT PRIMARY KEY,
  page_id    TEXT NOT NULL,
  post_id    TEXT,
  permalink  TEXT NOT NULL,
  title      TEXT,
  published_date TEXT,
  batch_id   TEXT,                   -- 本次提取批次
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_extract_batch ON link_extracts(batch_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_extract_post ON link_extracts(page_id, post_id);

-- 评论操作记录（回复/删除，防重复 + 额度统计）
CREATE TABLE IF NOT EXISTS comment_actions (
  id         TEXT PRIMARY KEY,
  account_id TEXT,
  page_id    TEXT NOT NULL,
  comment_id TEXT,
  action     TEXT NOT NULL,          -- reply | delete | skip
  category   TEXT,
  comment_text TEXT,
  reply_text TEXT,
  permalink  TEXT,
  dry        INTEGER NOT NULL DEFAULT 0,
  ts         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ca_page ON comment_actions(page_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_ca_acct ON comment_actions(account_id, action, ts DESC);
"""

MIGRATIONS = [
    "ALTER TABLE events ADD COLUMN src TEXT",
    "ALTER TABLE library ADD COLUMN tags TEXT",
    "ALTER TABLE library ADD COLUMN day_dir TEXT",
    "ALTER TABLE library ADD COLUMN copyright_ok INTEGER",
    "ALTER TABLE library ADD COLUMN copyright_note TEXT",
    "ALTER TABLE units ADD COLUMN tags TEXT",
    "ALTER TABLE units ADD COLUMN published_date TEXT",
    "ALTER TABLE units ADD COLUMN link_id TEXT",
    "ALTER TABLE units ADD COLUMN title_id TEXT",
    "ALTER TABLE units ADD COLUMN permalink TEXT",
    "ALTER TABLE envs ADD COLUMN account_id TEXT",
    "ALTER TABLE accounts ADD COLUMN page_quota TEXT NOT NULL DEFAULT 'new'",
    "ALTER TABLE accounts ADD COLUMN quota_note TEXT",
    "ALTER TABLE accounts ADD COLUMN quota_set_at TEXT",
    "ALTER TABLE pages ADD COLUMN skip_publish INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE pages ADD COLUMN skip_reason TEXT",
    # 素材类型：single（单集）| mix（混剪/主线版）——用于把混剪和单集分开排期发布
    "ALTER TABLE queue ADD COLUMN kind TEXT NOT NULL DEFAULT 'single'",
    "ALTER TABLE schedule ADD COLUMN kind TEXT NOT NULL DEFAULT 'single'",
    "ALTER TABLE library ADD COLUMN kind TEXT NOT NULL DEFAULT 'single'",
]

# 迁移之后才能建（依赖新加列）
POST_MIGRATION_SQL = [
    # ---- Agent 会话历史 ----
    """CREATE TABLE IF NOT EXISTS agent_chats (
        id TEXT PRIMARY KEY,
        title TEXT DEFAULT '',
        agent TEXT DEFAULT '',
        model TEXT DEFAULT '',
        created_at TEXT DEFAULT '',
        updated_at TEXT DEFAULT '',
        msg_count INTEGER DEFAULT 0,
        pinned INTEGER DEFAULT 0,
        summary TEXT DEFAULT ''
    )""",
    """CREATE TABLE IF NOT EXISTS agent_msgs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT DEFAULT '',
        model TEXT DEFAULT '',
        trace TEXT DEFAULT '[]',
        atts TEXT DEFAULT '[]',
        error INTEGER DEFAULT 0,
        created_at TEXT DEFAULT ''
    )""",
    "CREATE INDEX IF NOT EXISTS idx_amsg_chat ON agent_msgs(chat_id)",
    "CREATE INDEX IF NOT EXISTS idx_achat_upd ON agent_chats(updated_at DESC)",
    # 老库补列（CREATE TABLE IF NOT EXISTS 不会给已存在的表加列）
    "ALTER TABLE agent_chats ADD COLUMN summary TEXT DEFAULT ''",
    "CREATE INDEX IF NOT EXISTS idx_lib_copyright ON library(copyright_ok)",
    "CREATE INDEX IF NOT EXISTS idx_queue_kind ON queue(kind)",
    "CREATE INDEX IF NOT EXISTS idx_sched_kind ON schedule(kind)",
    # 老数据回填：路径里带「精品混剪 / 主线版」的算混剪
    "UPDATE queue SET kind='mix' WHERE kind='single' AND ("
    " file LIKE '%主线版%' OR file LIKE '%精品混剪%' OR path LIKE '%精品混剪%')",
    "UPDATE library SET kind='mix' WHERE kind='single' AND ("
    " file LIKE '%主线版%' OR file LIKE '%精品混剪%' OR path LIKE '%精品混剪%')",
    # ---- 标题池轮转所需的列（原来代码 UPDATE title_pool SET used_count 一直静默失败）----
    "ALTER TABLE title_pool ADD COLUMN used_count INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE title_pool ADD COLUMN last_used TEXT",
    "CREATE INDEX IF NOT EXISTS idx_title_used ON title_pool(page_id, used_count)",
    # ---- 标题按「剧」缓存（2026-11-12）----
    #
    # 用户实际场景：每批发布的都是**不同的剧**，所以"全局标题池"没有意义 ——
    # 拿《A剧》的标题去发《B剧》的素材，内容完全对不上。
    #
    # 现在改成：按剧名缓存标题。发某个剧时：
    #   ① 库里已有这部剧的标题 → 直接用
    #   ② 没有 → 用大模型按剧名生成一批，写入缓存
    # 这样同一个剧第二次发就省掉生成开销，不同剧之间互不污染。
    "ALTER TABLE caption_variants ADD COLUMN drama TEXT",
    "CREATE INDEX IF NOT EXISTS idx_variant_drama "
    "ON caption_variants(drama, enabled)",
    "ALTER TABLE caption_variants ADD COLUMN kind TEXT",
    # ---- 用户自定义分组（2026-11-12）----
    #
    # 用户需求："让用户把个号分成发布号和授权号，发布号显示在发布界面，
    #           授权号显示在授权界面"
    #
    # 为什么不复用 envs.role：
    #   role 是内核编排逻辑在用的（只有 publisher 参与发布），不能乱改。
    #   用户分组是纯展示概念，两者语义不同。
    #   publish  → 发布号，只在「发布中心」出现
    #   auth     → 授权号，只在「主页与授权」出现
    #   空串     → 未分组，两处都显示（默认，向后兼容）
    "ALTER TABLE envs ADD COLUMN user_group TEXT",
    "CREATE INDEX IF NOT EXISTS idx_env_group ON envs(user_group)",
    # 某个主页可以单独归到别的组（覆盖所属环境的分组）
    "ALTER TABLE pages ADD COLUMN group_override TEXT",
    # ---- 发布订单：一条订单 = 一次用户意图（N 主页 × K 条）----
    """CREATE TABLE IF NOT EXISTS publish_orders (
        id            TEXT PRIMARY KEY,
        idem_key      TEXT NOT NULL UNIQUE,
        job_id        TEXT,
        title         TEXT DEFAULT '',
        env_code      TEXT DEFAULT '',
        account_id    TEXT DEFAULT '',
        state         TEXT NOT NULL DEFAULT 'CREATED',
        clips_per_page INTEGER NOT NULL DEFAULT 1,
        caption_style TEXT NOT NULL DEFAULT 'simple',
        material_source TEXT NOT NULL DEFAULT 'library',
        alloc_mode    TEXT NOT NULL DEFAULT 'merge',
        item_count    INTEGER NOT NULL DEFAULT 0,
        ok_count      INTEGER NOT NULL DEFAULT 0,
        fail_count    INTEGER NOT NULL DEFAULT 0,
        progress      INTEGER NOT NULL DEFAULT 0,
        stage         TEXT DEFAULT '',
        payload       TEXT DEFAULT '{}',
        result        TEXT DEFAULT '{}',
        error         TEXT,
        created_at    TEXT NOT NULL,
        started_at    TEXT,
        ended_at      TEXT
    )""",
    "CREATE INDEX IF NOT EXISTS idx_po_state ON publish_orders(state, created_at DESC)",
    "CREATE INDEX IF NOT EXISTS idx_po_job ON publish_orders(job_id)",
    # ---- 发布明细：一条素材 → 一个主页，文案/链接逐条固化 ----
    """CREATE TABLE IF NOT EXISTS publish_items (
        id          TEXT PRIMARY KEY,
        order_id    TEXT NOT NULL,
        page_id     TEXT NOT NULL,
        page_name   TEXT DEFAULT '',
        asset_id    TEXT DEFAULT '',
        lib_id      TEXT DEFAULT '',
        queue_id    TEXT DEFAULT '',
        file        TEXT NOT NULL,
        file_name   TEXT DEFAULT '',
        file_sha256 TEXT DEFAULT '',
        drama       TEXT DEFAULT '',
        ep          TEXT DEFAULT '',
        slot        INTEGER NOT NULL DEFAULT 1,
        title       TEXT DEFAULT '',
        link        TEXT DEFAULT '',
        caption     TEXT DEFAULT '',
        title_id    TEXT DEFAULT '',
        link_id     TEXT DEFAULT '',
        state       TEXT NOT NULL DEFAULT 'PENDING',
        acceptance  TEXT DEFAULT '',
        error       TEXT,
        created_at  TEXT NOT NULL,
        ended_at    TEXT
    )""",
    "CREATE INDEX IF NOT EXISTS idx_pi_order ON publish_items(order_id, slot)",
    "CREATE INDEX IF NOT EXISTS idx_pi_page ON publish_items(page_id, created_at DESC)",
    "CREATE INDEX IF NOT EXISTS idx_pi_hash ON publish_items(file_sha256)",
]


def _run_migrations(conn: sqlite3.Connection) -> None:
    """幂等补列：老库缺列时加上，已存在就忽略。"""
    for sql in MIGRATIONS:
        try:
            conn.execute(sql)
        except sqlite3.OperationalError:
            pass
    conn.commit()
    for sql in POST_MIGRATION_SQL:
        try:
            conn.execute(sql)
        except sqlite3.OperationalError:
            pass
    conn.commit()


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.RLock()

    async def connect(self) -> None:
        await asyncio.to_thread(self._connect)

    def _connect(self) -> None:
        conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.executescript(SCHEMA)
        conn.commit()
        _run_migrations(conn)
        self._conn = conn
        log.info("db connected: %s", self.path)

    async def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # ---------------- 基础 ----------------
    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("database not connected")
        return self._conn

    @contextmanager
    def tx(self):
        with self._lock:
            cur = self.conn.cursor()
            try:
                yield cur
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
            finally:
                cur.close()

    def q(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        with self._lock:
            cur = self.conn.execute(sql, params)
            rows = [dict(r) for r in cur.fetchall()]
            cur.close()
            return rows

    def q1(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        r = self.q(sql, params)
        return r[0] if r else None

    def exec(self, sql: str, params: Sequence[Any] = ()) -> int:
        with self.tx() as cur:
            cur.execute(sql, params)
            return cur.rowcount

    def execl(self, sql: str, seq: Iterable[Sequence[Any]]) -> int:
        with self.tx() as cur:
            cur.executemany(sql, list(seq))
            return cur.rowcount

    # ---------------- 便捷 ----------------
    def log_event(self, level: str, source: str, msg: str) -> None:
        try:
            self.exec(
                "INSERT INTO events(ts,level,source,msg) VALUES(?,?,?,?)",
                (now_iso(), level, source, str(msg)[:2000]),
            )
        except Exception:
            pass

    def get_kv(self, k: str, default: Any = None) -> Any:
        r = self.q1("SELECT v FROM kv WHERE k=?", (k,))
        if not r:
            return default
        try:
            return json.loads(r["v"])
        except Exception:
            return r["v"]

    def set_kv(self, k: str, v: Any) -> None:
        self.exec(
            "INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            (k, json.dumps(v, ensure_ascii=False)),
        )


db = Database(settings.db_path)
