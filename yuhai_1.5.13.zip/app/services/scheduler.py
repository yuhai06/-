"""排期执行引擎：每分钟扫一次，到点把排期的素材推入发布任务。

规则：
  · 只处理 state='planned' 且 queue_id 非空、时间已到
  · 主页受限 → 标 blocked，不执行
  · 素材文件不存在 → 标 blocked
  · 发布成功 → 排期 done，队列条目删除（连同文件，按规则）
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.scheduler")


async def publish_api_close_composer(env_code: str) -> int:
    """关掉该环境残留的 bulk_upload_composer 标签。

    为什么排期也要做：Meta 的批量上传器发布完不清空自己，
    残留的编辑器会让下一次提交静默失败（按钮能点、进度 100%、就是不发布）。
    手动发布那边已经有这个处理，排期是同一套环境，同样需要。
    """
    import httpx
    if not env_code:
        return 0
    row = db.q1("SELECT cdp_port FROM envs WHERE container_code=?", (env_code,))
    port = int((row or {}).get("cdp_port") or 0)
    if not port:
        return 0
    closed = 0
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.get(f"http://127.0.0.1:{port}/json/list")
            tabs = r.json() if r.status_code == 200 else []
            for t in tabs:
                u = t.get("url") or ""
                if t.get("type") == "page" and "bulk_upload_composer" in u:
                    try:
                        await c.get(f"http://127.0.0.1:{port}/json/close/{t['id']}")
                        closed += 1
                    except Exception:
                        pass
    except Exception as e:
        log.debug("list tabs failed: %s", e)
    return closed


class Scheduler:
    def __init__(self, interval: float = 60.0) -> None:
        self.interval = interval
        self._task: asyncio.Task | None = None
        self._stop = False
        # 串行发布锁：防止两轮 tick 重叠，也防止并发开多个 CDP 连接
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop = False
        self._task = asyncio.create_task(self._loop())
        log.info("scheduler started (interval=%ss)", self.interval)

    async def stop(self) -> None:
        self._stop = True
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except Exception:
                pass
            self._task = None
        log.info("scheduler stopped")

    async def _loop(self) -> None:
        while not self._stop:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.exception("scheduler tick failed: %s", e)
            await asyncio.sleep(self.interval)

    async def tick(self) -> int:
        """执行到点的排期。返回启动的任务数。

        expireMin（默认 180 分钟）：排期时间超过这么多分钟仍未执行，
        **转为手动发布**（不回队列、不丢弃），理由：
            · 用户关软件几小时后重开，不该一次性涌出十几条旧排期
              （那是明显的非人类行为，极易触发风控）
            · 但素材是辛苦抓+切的，不能浪费 → 转 missed 后仍留在队列里，
              用户在「发布中心 → 待手动」能看到，挑合适的时机自己发
        设 expireMin=0 可关闭此限制（全部按时补发）。

        状态流转：
            planned --(到点)--> running --> done（成功）
            planned --(超时)--> missed（转手动，素材保留在队列 ready）
            planned --(失败)--> blocked（素材回队列 ready，可重试）
        """
        R = {**(db.get_kv("schedule.rules") or {})}
        delete_after = R.get("deleteAfterPublish", True)
        expire_min = int(R.get("expireMin", 180))
        to_manual = R.get("expireToManual", True)   # 超时是否转手动

        now = datetime.now()
        horizon = (now + timedelta(minutes=1)).strftime("%H:%M")
        today = now.strftime("%Y-%m-%d")

        due = db.q(
            "SELECT * FROM schedule WHERE state='planned' AND date=? AND time<=?",
            (today, horizon))

        # 过期检查：超出 expireMin 的转手动（不自动补发）
        if expire_min > 0:
            expired = []
            for s in due:
                try:
                    t = s["time"]
                    h, m = t.split(":")[:2]
                    sched_dt = now.replace(hour=int(h), minute=int(m),
                                           second=0, microsecond=0)
                    if (now - sched_dt).total_seconds() > expire_min * 60:
                        expired.append(s)
                except Exception:
                    continue
            for s in expired:
                if to_manual:
                    # 转手动：排期标 missed，素材退回队列 ready（可手动发）
                    db.exec("UPDATE schedule SET state='missed',note=? WHERE id=?",
                            (f"超时 {expire_min} 分钟，已转手动发布", s["id"]))
                    if s["queue_id"]:
                        db.exec("UPDATE queue SET state='ready' WHERE id=?",
                                (s["queue_id"],))
                    db.log_event("warn", "schedule",
                                 f"{s['page']} {s['time']} 超时 → 转手动发布"
                                 f"（素材保留，可在发布中心手动发）")
                else:
                    db.exec("UPDATE schedule SET state='missed',note=? WHERE id=?",
                            (f"超过 {expire_min} 分钟未执行，跳过补发", s["id"]))
                    db.log_event("warn", "schedule",
                                 f"{s['page']} {s['time']} 已过期 {expire_min} 分钟，"
                                 f"标记 missed（不补发）")
            due = [s for s in due if s not in expired]

        started = 0
        todo: list[tuple] = []
        for s in due:
            q = db.q1("SELECT * FROM queue WHERE id=?", (s["queue_id"],)) if s["queue_id"] else None
            if not q:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("缺少素材", s["id"]))
                db.log_event("warn", "schedule", f"{s['page']} {s['time']} 缺少素材")
                continue
            path = Path(q["path"])
            if not path.exists():
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("素材文件不存在", s["id"]))
                db.log_event("warn", "schedule", f"{q['file']} 不存在")
                continue

            # 主页查找：排期里可能存的是主页名（Y01）也可能是 page_id
            # （数字 ID）。必须两种都能匹配，否则整批排期会卡在「主页不存在」
            page = db.q1(
                "SELECT * FROM pages WHERE page_id=? OR name=?", (s["page"], s["page"]))
            if not page:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("主页不存在", s["id"]))
                continue
            if page["health"] != "ok":
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        (f"主页状态 {page['health']}", s["id"]))
                db.log_event("warn", "schedule",
                             f"{page['name']} 受限，跳过 {s['time']} 排期")
                continue
            if not page["asset_id"]:
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        ("缺少 asset_id", s["id"]))
                continue

            # ⚠ 环境必须按主页所属来取，不能随便拿一个 publisher。
            #
            # 实机教训（2026-11-12）：
            #   原来这里写的是
            #       SELECT * FROM envs WHERE role='publisher' AND status='running'
            #   q1 只返回第一行 —— 而库里有两个 publisher 环境
            #   （1887976888 网易01 / 1932079482 QQ02），主页分属不同环境。
            #   拿错环境后，内核在 checkBrowsers 里看不到目标主页的浏览器，
            #   remainingPlan 被 skippedPageIds 清空 → 报
            #       PLAN_REQUIRED: 尚未导入发布计划。
            #   这个报错信息完全看不出"环境选错了"，极难排查。
            env_code = page.get("env_code") or ""
            if env_code:
                env = db.q1(
                    "SELECT * FROM envs WHERE container_code=? AND status='running'",
                    (env_code,))
                if not env:
                    db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                            (f"主页所属环境 {env_code} 未启动", s["id"]))
                    continue
            else:
                env = db.q1(
                    "SELECT * FROM envs WHERE role='publisher' AND status='running'")
                if not env:
                    db.log_event("warn", "schedule", "发布号环境未启动，排期等待")
                    continue
                db.exec("UPDATE pages SET env_code=? WHERE page_id=?",
                        (env["container_code"], page["page_id"]))

            db.exec("UPDATE schedule SET state='running' WHERE id=?", (s["id"],))
            db.exec("UPDATE queue SET state='publishing' WHERE id=?", (q["id"],))
            todo.append((s, q, page, env))
            started += 1

        # **串行发布**：一个 CDP 连接一个浏览器，同时开 18 个任务
        # 必然 CDP handshake 超时（实测 Page.enable / Runtime.enable timeout）。
        # 用一个后台队列顺序跑，每条发布完再下一条。
        if todo:
            async with self._lock:
                for s, q, page, env in todo:
                    try:
                        await self._publish_one(s, q, page, env, delete_after)
                    except Exception as e:
                        log.exception("serial publish failed: %s", e)
                        db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                                (f"{type(e).__name__}: {e}"[:120], s["id"]))
                        db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
                    await asyncio.sleep(8)   # 两条之间间隔，模拟人操作节奏
        return started

    async def _publish_one(self, sched: dict, q: dict, page: dict,
                           env: dict, delete_after: bool) -> None:
        """到点发布一条排期。

        走新的发布编排层（publish_engine + 内核 worker），不再用旧的
        adapters/facebook.publish_reel —— 那条链是自研 CDP 直发，
        缺少版权门禁、回执校验、素材去重，和「发布中心」行为不一致。

        现在的行为与发布中心完全一致：
          · 文案由 build_caption 统一生成（标题池 + 链接池 + 占位符替换）
          · 素材走 staging 目录（硬链接，母片不动）
          · 内核负责上传 / 版权检查 / 点发布 / 等回执
          · 成功才标 queue=done + pages.published+1
        """
        from app.services import publish_engine as pe
        from app.services import prepare as pz
        from app.services import reels as rl
        from pathlib import Path as _Path
        import shutil as _shutil

        page_id = page["page_id"]
        env_code = env.get("container_code") or page.get("env_code") or ""
        order_id = "sched-" + sched["id"][:12]
        stage_dir = _Path(pe._stage_root()) / order_id / pe._safe(
            page.get("name") or page_id)

        try:
            # ① 关掉残留 composer，把环境摆到可发布状态
            try:
                await publish_api_close_composer(env_code)
            except Exception as e:
                log.debug("close composer failed: %s", e)
            pr = await pz.prepare_publish(env_code)
            if not pr.get("ok"):
                raise RuntimeError(f"环境 {env_code} 未就绪：{pr.get('error')}")

            # ② staging（硬链接，不复制大文件）
            _shutil.rmtree(stage_dir, ignore_errors=True)
            stage_dir.mkdir(parents=True, exist_ok=True)
            src = _Path(q["path"])
            if not src.is_file():
                raise RuntimeError(f"素材不存在：{src}")
            dst = stage_dir / src.name
            pe._link_or_copy(src, dst)

            # ②b 把本次素材 hash 从内核 usedHashes 里放行
            #
            # 内核的 selectAvailableVideos 会严格跳过 usedHashes 里的文件：
            #     if (!used.has(fingerprint.sha256)) available.push(...)
            # staging 目录里只有这一条素材，只要它在 usedHashes 里，
            # 可用数就是 0 → 报 MATERIAL_SHORTAGE: 当前只有 0 个。
            # 发布中心那边已经有这个处理，排期是同一套环境，同样需要。
            try:
                h = pe._sha256(str(dst))
                core_used = set(rl.state_snapshot().get("usedHashes") or [])
                if h in core_used:
                    log.info("排期: 放行已用素材 hash %s", h[:12])
                    await rl.release_hashes([h])
            except Exception as e:
                log.warning("排期 release_hashes 失败: %s", e)

            # ③ 文案（与发布中心同一套）
            cap = pe.build_caption(
                page_id=page_id,
                drama=(q.get("drama") or page.get("drama") or "").strip(),
                ep=(q.get("ep") or "").strip(),
                style="simple",
            )

            # ④ 确保内核有 plan（不是直接 archive）
            #
            # ⚠ 实机教训（2026-11-12，两次踩同一个坑）：
            #   archiveRun 会**连同 plan 一起清掉**（内核行为）。
            #   所以顺序必须是：先归档 → 再 ensure_plan。
            #   反过来（ensure_plan 后 archive）会把刚拿到的 plan 清掉，
            #   紧接着 start 报 PLAN_REQUIRED: 尚未导入发布计划。
            #
            #   另一个坑：如果一个环境抓不到主页，discoverPages 会返回
            #   PAGE_DISCOVERY_INCOMPLETE **并把已有 plan 一起清成 0**。
            #   所以只有当 plan 真的不存在时才去抓，不能无脑 force。
            st = await rl.status()
            cur = st.get("currentRun") if st.get("ok") else None
            cur_state = str((cur or {}).get("state") or "").lower()
            need_archive = bool(cur) and cur_state not in (
                "completed", "archived", "running", "queued", "publishing")

            if need_archive:
                await rl.archive_current_run()

            plan_info = await rl.ensure_plan(
                container_code="", force=False, on_progress=None)
            if not plan_info.get("ok"):
                # plan 拿不到时不要硬发，直接给明确原因
                raise RuntimeError(
                    f"内核发布计划不可用：{plan_info.get('error') or '未知'}")

            # 目标主页必须在内核 plan 里，否则 rl.publish 的 skippedPageIds
            # 会把它也排除掉 → remainingPlan 为空 → PLAN_REQUIRED。
            asset_id = str(page.get("asset_id") or "")
            plan_pages = {str(p.get("pageId")) for p in rl.plan_pages()}
            if asset_id and asset_id not in plan_pages:
                raise RuntimeError(
                    f"主页 {page.get('name')}（asset {asset_id}）不在内核发布计划里。"
                    f"去「发布中心」跑一次环境准备，或检查该环境是否有这个主页的管理权限。")

            # 归档后如果 plan 是刚抓的，工作标签会被导到 pages 列表，
            # 需要归位 + 重查浏览器，否则 start 报 BROWSER_NOT_READY。
            if need_archive or not plan_info.get("reused"):
                await rl.reprepare_all(on_progress=None)
                await rl.check_browsers()

            asset_id = str(page.get("asset_id") or "")
            res = await rl.publish(
                directory=str(stage_dir),
                description=cap.body,
                link_pool="",
                clips_per_page=1,
                concurrency=1,
                publish_mode="merge",
                browser_ids=[env_code] if env_code else None,
                pages=[asset_id or page_id],
                materials=None,
                title_mode="fixed",
                fixed_title=cap.body,
                auto_prepare=False,
            )
            verdict = res.get("_verdict") or {}
            ok = bool(verdict.get("ok"))

            if ok:
                db.exec("UPDATE schedule SET state='done',note=? WHERE id=?",
                        (verdict.get("state") or "completed", sched["id"]))
                db.exec("UPDATE queue SET state='done' WHERE id=?", (q["id"],))
                db.exec("UPDATE pages SET published=COALESCE(published,0)+1 "
                        "WHERE page_id=?", (page_id,))
                # units + 标题/链接轮转（和发布中心一致）
                try:
                    from app.db import db as _db
                    import uuid as _uuid
                    from datetime import datetime as _dt
                    ts = _dt.now().astimezone().isoformat(timespec="seconds")
                    _db.exec(
                        """INSERT INTO units
                           (id,page_id,asset_id,video_hash,file,title,caption,tags,
                            published_at,published_date,post_id,tracker,state,
                            created_at,link_id,title_id,permalink)
                           VALUES (?,?,?,?,?,?,?,'',?,?,NULL,'','published',?,?,?,NULL)""",
                        ("u-" + _uuid.uuid4().hex[:12], page_id, asset_id,
                         (q.get("sha256") or ""), q.get("file") or src.name,
                         cap.title, cap.body, ts, ts[:10], ts,
                         cap.link_id or None, cap.title_id or None))
                except Exception as e:
                    log.debug("write units failed: %s", e)
                db.log_event("ok", "schedule",
                             f"{page['name']} 发布成功 · {verdict.get('state')}")
                if delete_after:
                    try:
                        src.unlink()
                        db.exec("DELETE FROM queue WHERE id=?", (q["id"],))
                        db.log_event("ok", "schedule", f"素材已删 {q['file']}")
                    except Exception as e:
                        log.debug("unlink failed: %s", e)
            else:
                err = (verdict.get("reason") or res.get("error") or "发布失败")
                db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                        (str(err)[:160], sched["id"]))
                db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
                db.log_event("err", "schedule",
                             f"{page['name']} 发布失败: {str(err)[:100]}")
        except Exception as e:
            log.exception("publish one failed")
            db.exec("UPDATE schedule SET state='blocked',note=? WHERE id=?",
                    (f"{type(e).__name__}: {e}"[:160], sched["id"]))
            db.exec("UPDATE queue SET state='ready' WHERE id=?", (q["id"],))
        finally:
            _shutil.rmtree(stage_dir.parent, ignore_errors=True)

scheduler = Scheduler()
