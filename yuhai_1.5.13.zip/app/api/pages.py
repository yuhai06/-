"""公共主页 API：列表、按 PID 提取、创建、详情。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel

from app.adapters import hubstudio as hs
from app.adapters.facebook import FB, FBError, PageRow, upsert_pages
from app.adapters.hubstudio import hub, HubstudioError
from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.api.pages")
router = APIRouter(tags=["pages"])


async def _pid_by_port(port: int) -> int | None:
    """按 CDP 端口反查真实 PID（containerId 不是进程 PID）。"""
    if not port:
        return None
    import psutil
    try:
        for c in psutil.net_connections(kind="inet"):
            if c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == port and c.pid:
                return int(c.pid)
    except (psutil.AccessDenied, PermissionError):
        try:
            r = proc.run(["netstat", "-ano", "-p", "TCP"], capture_output=True,
                               text=True, timeout=15, encoding="utf-8", errors="replace")
            for line in (r.stdout or "").splitlines():
                parts = line.split()
                if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
                    return int(parts[4])
        except Exception:
            pass
    return None


def _row(r: dict) -> dict:
    roles = {x["c_user"]: x for x in db.q(
        "SELECT * FROM page_roles WHERE page_id=?", (r["page_id"],))}
    return {
        "id": r["page_id"],
        "name": r["name"],
        "profileId": r["page_id"],
        "assetId": r["asset_id"],
        "drama": r["drama"] or "",
        "genre": r["genre"] or "",
        "followers": r["followers"] or 0,
        "views30d": r["views_30d"] or 0,
        "published": r["published"] or 0,
        "health": r["health"] or "ok",
        "envCode": r["env_code"],
        "skipPublish": bool(r["skip_publish"]) if "skip_publish" in r.keys() else False,
        "skipReason": r["skip_reason"] if "skip_reason" in r.keys() else None,
        "authz": {
            "publisher": {
                "present": settings.fb_publisher_cuser in roles,
                "level": (roles.get(settings.fb_publisher_cuser) or {}).get("role"),
                "grantedAt": (roles.get(settings.fb_publisher_cuser) or {}).get("granted_at"),
            },
            "backup": {
                "present": settings.fb_backup_cuser in roles,
                "level": (roles.get(settings.fb_backup_cuser) or {}).get("role"),
                "grantedAt": (roles.get(settings.fb_backup_cuser) or {}).get("granted_at"),
            },
        },
    }


@router.get("/pages")
async def list_pages():
    rows = db.q("SELECT * FROM pages ORDER BY name")
    return {"items": [_row(r) for r in rows]}


@router.get("/pages/{page_id}")
async def page_detail(page_id: str):
    r = db.q1("SELECT * FROM pages WHERE page_id=?", (page_id,))
    if not r:
        raise HTTPException(404, "主页不存在")
    d = _row(r)
    d["insights"] = db.q(
        "SELECT date,views,reach,minutes FROM insights WHERE page_id=? ORDER BY date DESC LIMIT 30",
        (page_id,))
    d["roles"] = db.q("SELECT * FROM page_roles WHERE page_id=?", (page_id,))
    return d


# ---------------- 按 PID 提取 ----------------
class ExtractReq(BaseModel):
    pids: list[str] = []
    parallel: int = 2
    createMissing: bool = True
    markMissing: bool = True
    pullInsights: bool = False


@router.post("/pages/extract")
async def extract(req: ExtractReq):
    """按 PID 提取该号名下全部主页。

    硬约束：
      · 每个 PID 先反查 CDP，读 c_user 确认身份
      · profile id 与 c_user 不一致 → 该 PID 标记「身份未校验」并跳过，不入库
    """
    pids = [p.strip() for p in req.pids if p.strip()]
    if not pids:
        raise HTTPException(400, "PID 不能为空")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [
        {"name": "反查 PID 监听端口", "state": "wait", "note": ""},
        {"name": "探测 CDP", "state": "wait", "note": ""},
        {"name": "读取当前身份 c_user", "state": "wait", "note": ""},
        {"name": "解析主页列表", "state": "wait", "note": ""},
        {"name": "与台账做差集", "state": "wait", "note": ""},
        {"name": "写库", "state": "wait", "note": ""},
    ]
    db.exec(
        "INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
        " VALUES(?,?,?,?,?,?,?,?,?)",
        (job_id, "extract", f"按 PID 提取主页（{len(pids)} 个）", "running", 0,
         json.dumps(steps, ensure_ascii=False),
         json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))

    # 异步跑，前端轮询 /api/jobs/{id}
    asyncio.create_task(_run_extract(job_id, pids, req.parallel))
    return {"ok": True, "jobId": job_id}


async def _run_extract(job_id: str, pids: list[str], parallel: int) -> None:
    def upd(i: int, state: str, note: str = "", progress: int = -1):
        steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))["steps"] or "[]")
        if i < len(steps):
            steps[i]["state"] = state
            if note:
                steps[i]["note"] = note
        patch = {"steps": json.dumps(steps, ensure_ascii=False)}
        if progress >= 0:
            patch["progress"] = progress
        sets = ",".join(f"{k}=?" for k in patch)
        db.exec(f"UPDATE jobs SET {sets} WHERE id=?", (*patch.values(), job_id))

    sem = asyncio.Semaphore(max(1, min(8, parallel)))
    results: list[dict] = []

    async def one(pid: str) -> None:
        async with sem:
            rec = {"pid": pid, "known": False, "cUser": None, "pages": 0,
                   "envName": "", "error": None, "skipped": False}
            try:
                ports = hub.listening_ports(int(pid))
                if not ports:
                    rec["error"] = "无监听端口"
                    rec["skipped"] = True
                    results.append(rec)
                    return
                cdp = await hub.resolve_cdp(int(pid))
                if not cdp:
                    rec["error"] = "未发现 CDP"
                    rec["skipped"] = True
                    results.append(rec)
                    return

                env = await hub.find_env_by_pid(int(pid))
                env_code = env["container_code"] if env else ""
                rec["known"] = bool(env)
                rec["envName"] = (db.q1("SELECT name FROM envs WHERE container_code=?",
                                        (env_code,)) or {}).get("name") or env_code

                async with FB(cdp["port"]) as fb:
                    cur = await fb.c_user()
                    rec["cUser"] = cur
                    if not cur:
                        rec["error"] = "读取 c_user 失败"
                        rec["skipped"] = True
                        results.append(rec)
                        return
                    rows = await fb.extract_pages(cur)
                    rec["pages"] = len(rows)
                    if rows:
                        upsert_pages(rows, env_code)
                        # 补 page_roles：当前身份即管理员
                        for r in rows:
                            db.exec(
                                "INSERT INTO page_roles(page_id,c_user,role,state,checked_at)"
                                " VALUES(?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                " role=excluded.role,state='active',checked_at=excluded.checked_at",
                                (r.page_id, cur, "full", "active", now_iso()))
                        db.exec("UPDATE pages SET env_code=?,last_seen=? WHERE page_id IN (%s)" %
                                ",".join("?" * len(rows)),
                                (env_code, now_iso(), *[r.page_id for r in rows]))
                db.log_event("ok", "extract", f"PID {pid} 提取 {rec['pages']} 个主页")
            except (HubstudioError, FBError) as e:
                rec["error"] = str(e)[:200]
                db.log_event("err", "extract", f"PID {pid}: {e}")
            except Exception as e:
                rec["error"] = f"{type(e).__name__}: {e}"[:200]
                log.exception("extract pid %s", pid)
            results.append(rec)

    try:
        upd(0, "done", f"{len(pids)} 个 PID")
        upd(1, "run")
        await asyncio.gather(*(one(p) for p in pids))
        upd(1, "done")
        upd(2, "done")
        upd(3, "done", f"{sum(r['pages'] for r in results)} 个主页")
        upd(4, "done")
        upd(5, "done", "提交完成")

        total = db.q1("SELECT COUNT(*) c FROM pages")["c"]
        status = "done" if all(not r["error"] for r in results) else "blocked"
        db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? WHERE id=?",
                (status, json.dumps({"results": results, "total": total}, ensure_ascii=False),
                 now_iso(), job_id))
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


# ---------------- 单 PID / 端口 即时提取（同步版，前端弹窗用） ----------------
@router.get("/extract/pages")
async def extract_sync(pid: int = 0, port: int = 0):
    if pid and not port:
        ports = hub.listening_ports(pid)
        if not ports:
            return {"ok": False, "error": "该 PID 无监听端口（containerId 不是进程 PID，请改用 port）",
                    "pid": pid, "ports": []}
        cdp = await hub.resolve_cdp(pid)
    elif port:
        cdp = await hub.probe_cdp(port)
        if not cdp:
            return {"ok": False, "error": f"端口 {port} 不是 Chromium CDP", "pid": pid, "ports": []}
    else:
        return {"ok": False, "error": "需要 pid 或 port"}

    if not cdp:
        return {"ok": False, "error": "未发现 CDP", "pid": pid, "ports": []}
    real_pid = pid or await _pid_by_port(cdp["port"])
    env = await hub.find_env_by_pid(real_pid) if real_pid else None
    env_code = env["container_code"] if env else ""
    try:
        async with FB(cdp["port"]) as fb:
            cur = await fb.c_user()
            if not cur:
                return {"ok": False, "error": "该环境未登录 Facebook（读不到 c_user）",
                        "pid": real_pid, "cdpPort": cdp["port"], "cUser": None,
                        "pages": [], "count": 0}
            rows = await fb.extract_pages(cur)
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "pid": real_pid,
                "cdp": cdp, "env": env}
    if rows:
        upsert_pages(rows, env_code)
        # 能提取到主页 → 当前 c_user 就是这些主页的管理员，直接落 page_roles
        ts = now_iso()
        for r in rows:
            db.exec(
                "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                " role='full', state='active', checked_at=excluded.checked_at",
                (r.page_id, cur, "full", "active", ts, ts))
        db.log_event("info", "pages",
                     f"c_user {cur} 标记为 {len(rows)} 个主页的管理员")
    return {"ok": True, "pid": real_pid, "cUser": cur, "env": env,
            "cdpPort": cdp["port"], "pages": [r.__dict__ for r in rows],
            "count": len(rows)}

# ---------------- 创建主页 ----------------
class CreateReq(BaseModel):
    name: str
    category: str
    bio: str = ""
    bioMode: str = "auto"     # auto=留空则由模型生成 / manual=只用用户填的
    bioHint: str = ""         # 给模型的额外要求（可选）
    bioModel: str = ""        # 指定模型，空=默认
    count: int = 1
    accountId: str = ""
    dailyLimit: int = 0        # 0 = 由 quota 自动决定
    gapSec: int = 420
    quotaOverride: str = ""    # 强制指定档位（new/limited/blocked）


_CREATE_LOCK: "asyncio.Lock | None" = None


def _create_lock() -> "asyncio.Lock":
    global _CREATE_LOCK
    if _CREATE_LOCK is None:
        _CREATE_LOCK = asyncio.Lock()
    return _CREATE_LOCK


@router.post("/pages/create")
async def create_pages(req: CreateReq):
    """创建主页。

    修复点：
      ① 必须用「选中的那个号」的身份与环境建页（旧版忽略 accountId，
         永远用配置里的发布号身份）
      ② 额度在锁内校验并预占，避免并发重复提交冲破额度
      ③ 建页记录落到 page_creates，额度按 account_id 统计
    """
    from app.services import automation as au
    from app.services import identity as ident
    from app.services import quota as q

    if au.observe_only():
        raise HTTPException(403,
            "当前是「只观察不动作」模式，建主页已被拦截。"
            "去 概览 → 全自动 里关掉「只观察」再操作。")

    name = (req.name or "").strip()
    if not name:
        raise HTTPException(400, "主页名称不能为空")
    if len(name) > 60:
        raise HTTPException(400, "主页名称不能超过 60 个字符")
    if req.count < 1 or req.count > 20:
        raise HTTPException(400, "本次数量必须在 1–20 之间")
    if req.gapSec < 30 or req.gapSec > 3600:
        raise HTTPException(400, "主页间隔必须在 30–3600 秒之间")

    try:
        if req.accountId:
            acc = ident.require_account_for_write(req.accountId, role="publisher")
        else:
            pubs = db.q("SELECT id FROM accounts WHERE role='publisher' AND enabled=1")
            if len(pubs) != 1:
                raise ident.ValidationError(
                    f"请先选择用哪个发布号建主页（当前有 {len(pubs)} 个发布号）")
            acc = ident.require_account_for_write(pubs[0]["id"], role="publisher")
        env = ident.require_account_env(acc)
    except ident.ValidationError as e:
        raise HTTPException(400, str(e))

    # 简介定稿：用户填了就用用户的，留空则让模型按主页名+类别生成。
    # 放在入队前做，模型慢也不占建页锁。
    from app.services import bio as bio_svc
    bio_res = await bio_svc.ensure_bio(
        name=name, category=req.category, bio=req.bio,
        hint=req.bioHint, model_id=req.bioModel)
    final_bio = bio_res.get("bio") or ""
    bio_svc.log_usage(name, final_bio, bio_res.get("source") or "none")
    req = req.model_copy(update={"bio": final_bio})

    async with _create_lock():
        info = q.resolve_quota(acc["id"], req.quotaOverride)
        if not info.get("ok"):
            raise HTTPException(400, info.get("error") or "额度查询失败")
        limit = info["limit"]
        if info["suggestLevel"] != info["level"] and not req.quotaOverride:
            raise HTTPException(400,
                f"该号额度建议降到「{info['suggestLevel']}」：{info['reason']}。"
                "请先在号管理里确认档位，或传 quotaOverride 强制。")
        if req.count > limit:
            raise HTTPException(400,
                f"本次要建 {req.count} 个，超过该号额度 {limit} 个"
                f"（{info.get('level')} 档）。{info.get('reason', '')}")
        if info["remaining"] < req.count:
            raise HTTPException(400,
                f"今日已建 {info['usedToday']} 个，额度 {limit}，"
                f"最多还能建 {info['remaining']} 个")

        job_id = "job-" + uuid.uuid4().hex[:12]
        steps = [{"name": f"创建 {i+1}/{req.count}: {name}",
                  "state": "wait", "note": ""} for i in range(req.count)]
        payload = {**req.model_dump(), "resolvedLimit": limit,
                   "accountId": acc["id"], "accountLabel": acc["label"],
                   "accountCUser": acc["c_user"],
                   "envCode": env["container_code"]}
        ts = now_iso()
        db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
                "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (job_id, "create", f"创建主页 {name} × {req.count}", "running", 0,
                 json.dumps(steps, ensure_ascii=False),
                 json.dumps(payload, ensure_ascii=False), ts, ts))
        for i in range(req.count):
            db.exec("INSERT INTO page_creates(id,account_id,c_user,page_id,name,"
                    "state,job_id,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                    ("pc-" + uuid.uuid4().hex[:12], acc["id"], acc["c_user"], None,
                     name if req.count == 1 else f"{name}{i+1:02d}",
                     "reserved", job_id, "", ts))
        remaining = info["remaining"] - req.count

    asyncio.create_task(_run_create(job_id, req, acc, env))
    return {"ok": True, "jobId": job_id, "limit": limit,
            "account": acc["label"], "accountId": acc["id"],
            "cUser": acc["c_user"], "envCode": env["container_code"],
            "remaining": remaining,
            "bio": final_bio, "bioSource": bio_res.get("source")}


class BioReq(BaseModel):
    name: str = ""
    category: str = ""
    hint: str = ""
    model: str = ""


@router.post("/pages/bio-preview")
async def bio_preview(req: BioReq):
    """生成一条主页简介供预览（不建页、不落库）。

    用户在弹窗里点「AI 生成」时调用；不满意可以再点一次换一条，
    也可以直接手改输入框（手改的内容创建时原样使用）。
    """
    from app.services import bio as bio_svc
    r = await bio_svc.generate_bio(req.name, req.category, req.hint, req.model)
    return {"ok": True, **r}


async def _run_create(job_id: str, req: CreateReq, acc: dict, env: dict) -> None:
    """用指定号的真实身份建页，并回读主页清单确认确实建成了。"""
    from app.services import quota as q

    acc_id = acc["id"]
    c_user = acc["c_user"]
    env_code = env["container_code"]

    def _note(idx: int, state: str, note: str = "") -> None:
        cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
        try:
            arr = json.loads((cur or {}).get("steps") or "[]")
        except Exception:
            arr = []
        if not arr or idx >= len(arr):
            return
        arr[idx]["state"] = state
        if note:
            arr[idx]["note"] = note[:120]
        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                (json.dumps(arr, ensure_ascii=False), job_id))

    def _release(note: str) -> None:
        db.exec("UPDATE page_creates SET state='failed',note=? "
                "WHERE job_id=? AND state='reserved'", (note[:120], job_id))

    try:
        port = int(env["cdp_port"])
    except Exception:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                ("该号环境没有可用 CDP 端口", now_iso(), job_id))
        _release("环境无 CDP 端口")
        return

    ok_n, fail_n = 0, 0
    created: list[dict] = []
    downgraded = None
    try:
        async with FB(port) as fb:
            # ① 身份必须是选中的那个号，不是全局配置里的发布号
            await fb.assert_identity(c_user)
            await fb.ensure_personal_identity(env.get("display_name") or acc["label"])
            before = {r.page_id for r in await fb.extract_pages(c_user)}

            for i in range(req.count):
                nm = req.name if req.count == 1 else f"{req.name}{i+1:02d}"
                _note(i, "run", "正在提交创建…")
                res = await fb.create_page(nm, req.category, req.bio)

                if res.get("guard"):
                    g = res["guard"] or {}
                    downgraded = q.auto_downgrade(acc_id, g.get("kind") or "")
                    _note(i, "err", f"⚠ {g.get('message')}（已熔断）")
                    _release(f"guard:{g.get('kind')}")
                    db.exec("UPDATE jobs SET status='blocked',result=?,ended_at=?"
                            " WHERE id=?",
                            (json.dumps({"ok": ok_n, "fail": fail_n + 1,
                                         "guard": g, "downgraded": downgraded},
                                        ensure_ascii=False), now_iso(), job_id))
                    db.log_event("err", "create_page",
                                 f"检测到 {g.get('kind')}，批次中止；"
                                 f"{'额度降级到 ' + downgraded if downgraded else '额度未变'}")
                    return

                if not res.get("ok"):
                    fail_n += 1
                    err = (res.get("error") or "失败")[:120]
                    _note(i, "err", err)
                    db.exec("UPDATE page_creates SET state='failed',note=? "
                            "WHERE job_id=? AND state='reserved' AND name=?",
                            (err, job_id, nm))
                    db.log_event("warn", "create_page", f"{nm}: {err}")
                    if not res.get("transient"):
                        downgraded = q.auto_downgrade(acc_id, "action_block") or downgraded
                        break
                    continue

                # ② 回读清单：页面提示成功但没新增主页 → 按失败处理
                after_rows = await fb.extract_pages(c_user)
                fresh = [r for r in after_rows if r.page_id not in before]
                if not fresh:
                    fail_n += 1
                    _note(i, "err", "页面提示成功，但主页清单没有新增，按失败处理")
                    db.exec("UPDATE page_creates SET state='failed',note=? "
                            "WHERE job_id=? AND state='reserved' AND name=?",
                            ("未检测到新主页", job_id, nm))
                    db.log_event("warn", "create_page",
                                 f"{nm}: 未检测到新主页，按失败处理")
                    break

                upsert_pages(fresh, env_code)
                ts = now_iso()
                for r in fresh:
                    db.exec(
                        "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,"
                        "checked_at) VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user)"
                        " DO UPDATE SET role='full',state='active',"
                        " checked_at=excluded.checked_at",
                        (r.page_id, c_user, "full", "active", ts, ts))
                before = {r.page_id for r in after_rows}
                ok_n += 1
                _note(i, "done", f"创建成功 · {fresh[0].page_id}")
                db.exec("UPDATE page_creates SET state='ok',page_id=?,note=? "
                        "WHERE job_id=? AND state='reserved' AND name=?",
                        (fresh[0].page_id, "created", job_id, nm))
                created.append({"pageId": fresh[0].page_id, "name": fresh[0].name})
                db.log_event("ok", "create_page",
                             f"{nm} 创建成功 c_user={c_user} page_id={fresh[0].page_id}")
                db.exec("UPDATE jobs SET progress=? WHERE id=?",
                        (int((ok_n + fail_n) / req.count * 100), job_id))
                if i < req.count - 1:
                    await asyncio.sleep(req.gapSec)

        if acc_id and ok_n >= 6:
            downgraded = q.auto_downgrade(acc_id, "rate_limit") or downgraded

        _release("未执行")
        status = "done" if (fail_n == 0 and ok_n == req.count) else (
            "blocked" if ok_n else "failed")
        db.exec("UPDATE jobs SET status=?,result=?,progress=100,ended_at=? WHERE id=?",
                (status,
                 json.dumps({"ok": ok_n, "fail": fail_n, "downgraded": downgraded,
                             "pages": created}, ensure_ascii=False),
                 now_iso(), job_id))
    except Exception as e:
        _release(str(e)[:120])
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "create_page", str(e)[:200])


class SyncAllReq(BaseModel):
    envCode: str = ""
    pageIds: list[str] = []
    includeInsights: bool = True


@router.post("/pages/sync-all")
async def sync_all_pages(req: SyncAllReq):
    """一次同步全部主页信息。

    做四件事：
        ① 重新提取主页清单（拿 asset_id）
        ② 核对授权关系（发布号/备份号）
        ③ 抓粉丝数与 30 天播放（Business Suite insights）
        ④ 更新健康状态

    提取主页后调这个，就不用再分几次跑了。
    """
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的环境")

    targets = req.pageIds or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]
    if not targets:
        return {"ok": True, "note": "没有可同步的主页", "pages": 0}

    from app.adapters.facebook import FB
    from app.adapters import guard as gd
    from app.adapters import humanize as hz

    out = {"pages": len(targets), "asset": 0, "authz": 0, "insights": 0,
           "failed": 0, "guard": None, "details": []}

    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()

            # ① 先重新提取一遍，确保 asset_id 齐全
            try:
                rows = await fb.extract_pages()
                if rows:
                    upsert_pages(rows, env["container_code"])
                    out["asset"] = len(rows)
            except Exception as e:
                log.debug("extract during sync failed: %s", e)

            # ② 逐个核对授权
            for pid in targets:
                v = await gd.check(page, env["container_code"], pid)
                if v and v.tripped:
                    out["guard"] = v.as_dict()
                    break
                try:
                    r = await fb.list_roles(
                        (db.q1("SELECT asset_id FROM pages WHERE page_id=?",
                               (pid,)) or {}).get("asset_id") or "")
                    # 记录角色
                    ts = now_iso()
                    for role in (r or []):
                        cu = role.get("c_user")
                        if not cu:
                            continue
                        db.exec(
                            "INSERT INTO page_roles(page_id,c_user,role,state,"
                            "granted_at,checked_at) VALUES(?,?,?,?,?,?)"
                            " ON CONFLICT(page_id,c_user) DO UPDATE SET"
                            " state=excluded.state, checked_at=excluded.checked_at",
                            (pid, cu, role.get("level") or "partial",
                             "active", ts, ts))
                    out["authz"] += 1
                except Exception as e:
                    out["failed"] += 1
                    out["details"].append({"pageId": pid, "authz": str(e)[:80]})
                await hz.human_delay("nav")

            # ③ 抓 insights（粉丝 + 播放）
            if req.includeInsights:
                try:
                    from app.api.insights import NUM_JS
                    for pid in targets[:20]:
                        row = db.q1("SELECT asset_id FROM pages WHERE page_id=?", (pid,))
                        if not row or not row["asset_id"]:
                            continue
                        v = await gd.check(page, env["container_code"], pid)
                        if v and v.tripped:
                            out["guard"] = v.as_dict()
                            break
                        await page.goto(
                            f"https://business.facebook.com/latest/insights/overview"
                            f"?asset_id={row['asset_id']}", wait_until_loaded=9.0)
                        await hz.human_delay("read")
                        data = await page.eval(NUM_JS) or {}
                        if data.get("views") is not None:
                            from datetime import date as _d
                            today = _d.today().isoformat()
                            db.exec(
                                "INSERT INTO insights(page_id,date,views,reach,minutes,"
                                "reactions,comments,shares,collected_at)"
                                " VALUES(?,?,?,?,?,?,?,?,?)"
                                " ON CONFLICT(page_id,date) DO UPDATE SET"
                                " views=excluded.views, reach=excluded.reach,"
                                " minutes=excluded.minutes, reactions=excluded.reactions,"
                                " collected_at=excluded.collected_at",
                                (pid, today, data.get("views") or 0,
                                 data.get("reach") or 0, data.get("minutes") or 0,
                                 data.get("reactions") or 0, 0, 0, now_iso()))
                            db.exec("UPDATE pages SET views_30d=? WHERE page_id=?",
                                    (data.get("views") or 0, pid))
                            out["insights"] += 1
                        await hz.human_delay("nav")
                except Exception as e:
                    out["details"].append({"insights": str(e)[:100]})

            # 收尾清理多余标签
            try:
                await fb.prune_tabs(keep=1)
            except Exception:
                pass
    except Exception as e:
        raise HTTPException(500, f"同步失败：{str(e)[:200]}")

    db.log_event("ok" if not out["guard"] else "warn", "pages",
                 f"全量同步：{out['pages']} 页 · asset {out['asset']} "
                 f"· 授权 {out['authz']} · insights {out['insights']}")
    return {"ok": True, **out}


class SkipReq(BaseModel):
    skip: bool
    reason: str = ""


@router.post("/pages/{page_id}/skip-publish")
async def set_skip_publish(page_id: str, req: SkipReq):
    """标记主页是否参与自动发布。

    有些主页你会手动发，自动发布要跳过它们，否则会重复发。
    """
    r = db.q1("SELECT name FROM pages WHERE page_id=?", (page_id,))
    if not r:
        raise HTTPException(404, "主页不存在")
    db.exec("UPDATE pages SET skip_publish=?,skip_reason=? WHERE page_id=?",
            (1 if req.skip else 0, req.reason or None, page_id))
    db.log_event("info", "pages",
                 f"{r['name']} {'跳过' if req.skip else '恢复'}自动发布"
                 + (f"（{req.reason}）" if req.reason else ""))
    return {"ok": True, "skip": req.skip}


class SkipBatchReq(BaseModel):
    pageIds: list[str]
    skip: bool
    reason: str = ""


@router.post("/pages/skip-publish-batch")
async def set_skip_batch(req: SkipBatchReq):
    n = 0
    for pid in req.pageIds:
        if db.q1("SELECT 1 FROM pages WHERE page_id=?", (pid,)):
            db.exec("UPDATE pages SET skip_publish=?,skip_reason=? WHERE page_id=?",
                    (1 if req.skip else 0, req.reason or None, pid))
            n += 1
    return {"ok": True, "updated": n}


class PagePatch(BaseModel):
    drama: str | None = None
    genre: str | None = None
    health: str | None = None


@router.patch("/pages/{page_id}")
async def patch_page(page_id: str, p: PagePatch):
    fields = {k: v for k, v in p.model_dump(exclude_none=True).items()}
    if not fields:
        return {"ok": True}
    col = {"drama": "drama", "genre": "genre", "health": "health"}
    sets = ",".join(f"{col[k]}=?" for k in fields)
    db.exec(f"UPDATE pages SET {sets} WHERE page_id=?", (*fields.values(), page_id))
    return {"ok": True}
