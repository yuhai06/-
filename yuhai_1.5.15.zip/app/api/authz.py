"""授权 API。

唯一原则：只用 profile 数字 ID 认定身份。
姓名 / 邮箱搜索一律不实现——同名的人不止一个，历史上已经授错过。
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, field_validator

from app.adapters.facebook import FB, FBError
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.authz")
router = APIRouter(tags=["authz"])


def _is_uid(v: str) -> bool:
    return bool(v) and v.isdigit() and 8 <= len(v) <= 20


@router.get("/authz")
async def matrix():
    pages = db.q("SELECT page_id,asset_id,name,drama,health FROM pages ORDER BY name")
    out = []
    for p in pages:
        roles = {r["c_user"]: r for r in db.q(
            "SELECT * FROM page_roles WHERE page_id=?", (p["page_id"],))}
        pub = roles.get(settings.fb_publisher_cuser)
        bak = roles.get(settings.fb_backup_cuser)
        out.append({
            "id": p["page_id"],
            "name": p["name"],
            "assetId": p["asset_id"],
            "drama": p["drama"],
            "publisher": {
                "present": bool(pub),
                "state": (pub or {}).get("state"),
                "grantedAt": (pub or {}).get("granted_at"),
            },
            "backup": {
                "present": bool(bak),
                "state": (bak or {}).get("state"),
                "grantedAt": (bak or {}).get("granted_at"),
                "checkedAt": (bak or {}).get("checked_at"),
            },
            "targetId": settings.fb_backup_cuser,
        })
    return {"items": out, "targetId": settings.fb_backup_cuser,
            "publisherId": settings.fb_publisher_cuser}


class GrantReq(BaseModel):
    pageIds: list[str]
    targetProfileId: str
    level: str = "full"
    stopOnMismatch: bool = True

    @field_validator("targetProfileId")
    @classmethod
    def _check(cls, v: str) -> str:
        if not _is_uid(v):
            raise ValueError("targetProfileId 必须是纯数字 profile ID（不接受姓名/邮箱）")
        return v


@router.post("/authz/grant")
async def grant(req: GrantReq):
    """发起授权。真实执行走 CDP 自动化，这里先校验前置条件并入队。"""
    if not req.pageIds:
        raise HTTPException(400, "pageIds 不能为空")

    row = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not row:
        raise HTTPException(400, "发布号环境未启动，先启动 1887976888")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = []
    for pid in req.pageIds:
        nm = (db.q1("SELECT name FROM pages WHERE page_id=?", (pid,)) or {}).get("name") or pid
        steps.append({"name": f"{nm} → {req.targetProfileId}", "state": "wait", "note": ""})
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "authz", f"授权 {len(req.pageIds)} 个主页", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_grant(job_id, req, int(row["cdp_port"])))
    return {"ok": True, "jobId": job_id}


async def _run_grant(job_id: str, req: GrantReq, port: int) -> None:
    steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))["steps"] or "[]")
    done = 0
    try:
        # 按主页分批：同一环境的主页共用一条 CDP 连接。
        #
        # ⚠ 不能用一个固定 port 处理所有主页（2026-11-12 实机踩坑）：
        #   req.pageIds 里可能混着不同环境的主页。用网易01 的标签去打开
        #   QQ02 主页的 asset_id，Meta 会返回错误页，权限读不到。
        #   这里先按 env_code 分组，每组用自己环境的端口连一次。
        by_env: dict[str, list[tuple[int, str]]] = {}
        for i, pid in enumerate(req.pageIds):
            page = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
            if not page or not page.get("asset_id"):
                steps[i].update(state="err", note="缺少 asset_id，无法定位权限页")
                done += 1
                continue
            ec = page.get("env_code") or ""
            by_env.setdefault(ec, []).append((i, pid))

        for env_code, pairs in by_env.items():
            # 该主页所属环境的端口
            env_row = None
            if env_code:
                env_row = db.q1(
                    "SELECT * FROM envs WHERE container_code=?", (env_code,))
            port_for_env = int((env_row or {}).get("cdp_port") or port)

            try:
                async with FB(port_for_env) as fb:
                    await fb.assert_identity(settings.fb_publisher_cuser)
                    for i, pid in pairs:
                        steps[i]["state"] = "run"
                        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                                (json.dumps(steps, ensure_ascii=False), job_id))
                        page = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
                        asset = page["asset_id"] if page else None
                        try:
                            members = await fb.list_roles(asset)
                            ids = {m.get("c_user") for m in members
                                   if m.get("c_user")}
                            # 已在列表 → 只更新状态，不再发邀请
                            if req.targetProfileId in ids:
                                db.exec(
                                    "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                    " state='active',checked_at=excluded.checked_at",
                                    (pid, req.targetProfileId, req.level, "active",
                                     now_iso(), now_iso()))
                                steps[i].update(state="done", note="已在权限列表中")
                            else:
                                # 真实邀请流程需要人机交互（密码 + 邮箱码），这里记录待办
                                db.exec(
                                    "INSERT INTO page_roles(page_id,c_user,role,state,checked_at,note)"
                                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                    " state='pending',checked_at=excluded.checked_at,note=excluded.note",
                                    (pid, req.targetProfileId, req.level, "pending",
                                     now_iso(), "等待在浏览器内完成邀请（需密码+邮箱码）"))
                                steps[i].update(
                                    state="warn",
                                    note="需在浏览器完成邀请（密码 + 邮箱验证码）")
                        except FBError as e:
                            steps[i].update(state="err", note=str(e)[:80])
                        done += 1
                        db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                                (json.dumps(steps, ensure_ascii=False),
                                 int(done / len(req.pageIds) * 100), job_id))
                        await asyncio.sleep(3)
            except Exception as e:
                # 整个环境连不上：该组全部标错，不影响其他环境
                for i, pid in pairs:
                    steps[i].update(state="err",
                                    note=f"环境 {env_code} 连接失败: {str(e)[:60]}")
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False), job_id))

        db.exec("UPDATE jobs SET status='done',ended_at=? WHERE id=?", (now_iso(), job_id))
        db.log_event("ok", "authz", f"授权任务完成 {len(req.pageIds)} 个主页")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "authz", str(e)[:200])


class VerifyReq(BaseModel):
    pageId: str


@router.post("/authz/verify")
async def verify(req: VerifyReq):
    """读取真实权限列表并回写。

    ⚠ 环境必须按主页所属来取（2026-11-12 实机踩坑）：
        原来写的是
            SELECT * FROM envs WHERE role='publisher' AND status='running'
        q1 只返回第一行 —— 库里有两个发布环境（网易01 / QQ02），
        主页分属不同环境。拿错环境后，QQ02 的标签页去打开
        网易01 的 asset_id：
            business.facebook.com/.../page_roles?asset_id=<别的环境的>
        Meta 直接回 "很抱歉，目前无法显示内容 · 链接可能已过期"，
        权限列表永远读不到，被误判成"未授权"。
    """
    row = db.q1("SELECT * FROM pages WHERE page_id=?", (req.pageId,))
    if not row:
        raise HTTPException(404, "主页不存在")
    if not row["asset_id"]:
        raise HTTPException(400, "该主页缺少 asset_id")

    # 按主页所属环境取（没有 env_code 才退回第一个发布环境）
    env = None
    env_code = row.get("env_code") if isinstance(row, dict) else None
    if env_code:
        env = db.q1(
            "SELECT * FROM envs WHERE container_code=? AND status='running'",
            (env_code,))
        if not env:
            raise HTTPException(
                400, f"主页所属环境 {env_code} 未启动（先启动指纹浏览器）")
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    try:
        async with FB(int(env["cdp_port"])) as fb:
            members = await fb.list_roles(row["asset_id"])
    except (FBError, Exception) as e:
        raise HTTPException(500, f"读取权限列表失败: {str(e)[:200]}")

    ids = {m.get("c_user") for m in members if m.get("c_user")}
    ts = now_iso()
    for cu in (settings.fb_publisher_cuser, settings.fb_backup_cuser):
        if cu in ids:
            db.exec("INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                    " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                    " state='active',checked_at=excluded.checked_at",
                    (req.pageId, cu, "full", "active", ts, ts))
        else:
            db.exec("UPDATE page_roles SET state='missing',checked_at=? "
                    "WHERE page_id=? AND c_user=?", (ts, req.pageId, cu))
    return {"ok": True, "verified": sorted(ids), "members": members,
            "publisherPresent": settings.fb_publisher_cuser in ids,
            "backupPresent": settings.fb_backup_cuser in ids}
