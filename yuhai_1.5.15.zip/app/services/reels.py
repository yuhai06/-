"""ReelsPublisher 内核对接——通过 Node worker 的 IPC 批量发布。

为什么用这个：
    自研 CDP 直接发 Reels 不稳（reels_composer 页面会让浏览器内核卡死，
    且上传 input 是动态创建的，直接 querySelector 找不到）。
    ReelsPublisher v19.7 已经有成熟的批量发布链路：
        playwright-core 连接 Hubstudio CDP →
        skill-runtime 的 publisher 完成「打开 composer → 塞视频 →
        填标题 → 点发布 → 提取回执 → 清理素材」
    我们直接复用它的 worker IPC。

通信方式：
    worker.mjs 必须由父进程 fork，且 process.send 存在。
    命令：status / checkBrowsers / start / discoverPages / shutdown
    资源：REELS_PUBLISHER_DATA_DIR（state.json 与历史记录）
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.reels")

# ---------- 路径 ----------
def reels_root() -> Path:
    """ReelsPublisher 安装根目录。"""
    env = os.environ.get("YUHAI_REELS_ROOT", "").strip()
    if env:
        return Path(env)
    # 从 reels_env_dir（.../resources/worker/src）上溯三级
    p = Path(settings.reels_env_dir)
    for _ in range(3):
        p = p.parent
    return p


def worker_entry() -> Path:
    return Path(settings.reels_env_dir) / "worker.mjs"


def data_dir() -> Path:
    """worker 的 state/history 目录。"""
    env = os.environ.get("YUHAI_REELS_DATA", "").strip()
    if env:
        d = Path(env)
    else:
        d = reels_root() / "resources" / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def node_cmd() -> list[str]:
    """拿一个可用的 node 命令前缀。"""
    n = shutil.which("node")
    if n:
        return [n]
    # 用 Electron 二进制当 node
    exe = Path(os.environ.get("YUHAI_ELECTRON_NODE",
                              r"E:\ReelsPublisher-v19.7-Portable\Reels Publisher.exe"))
    if exe.exists():
        return [str(exe)]
    return ["node"]


def available() -> dict:
    """内核可用性检查。"""
    w = worker_entry()
    d = data_dir()
    node = node_cmd()
    st = d / "state.json"
    plan = {}
    disc = {}
    if st.exists():
        try:
            s = json.loads(st.read_text(encoding="utf-8"))
            plan = s.get("plan") or {}
            disc = s.get("discovery") or {}
        except Exception:
            pass
    return {
        "ok": w.exists() and len(node) > 0,
        "worker": str(w),
        "workerExists": w.exists(),
        "dataDir": str(d),
        "node": node[0] if node else "",
        "planPages": len((plan.get("assignments") or [])),
        "discoveredPages": len((disc.get("pages") or [])),
        "hasState": st.exists(),
        "version": "v19.7",
    }


# ---------- 单次调用（不常驻） ----------
# 正在跑的 worker 进程（jobId → Popen），用于「停止」
RUNNING: dict[str, "subprocess.Popen"] = {}


async def call_worker(commands: list[dict], timeout_s: float = 180,
                      on_progress=None, job_id: str = "") -> dict:
    """一次性启动 worker，按顺序执行 commands，返回最后一次结果。

    commands: [{"id":"c1","command":"status","payload":{}}, ...]
    最后会自动 shutdown。

    job_id 非空时会把进程登记到 RUNNING，供 stop_worker 停止。
    """
    w = worker_entry()
    if not w.exists():
        return {"ok": False, "error": f"worker 不存在: {w}"}

    d = data_dir()
    nc = node_cmd()

    # 写一个临时驱动脚本，避免复杂 IPC 编码问题
    drv = d / f"_drv_{uuid.uuid4().hex[:8]}.mjs"
    drv.write_text(_driver_js(str(w), str(d), commands), encoding="utf-8")

    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NO_WINDOW | \
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    proc = subprocess.Popen(nc + [str(drv)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, **kw)
    if job_id:
        RUNNING[job_id] = proc

    # ⚠ 必须把阻塞式的 stdout 读取丢到线程池。
    #
    # 这是 async def，但以前直接 `for raw in proc.stdout` 是同步阻塞读取：
    # 发布一条视频要 3-5 分钟，这期间整个 asyncio 事件循环被占死，
    # uvicorn 无法处理任何其它请求 —— 前端轮询超时、SSE 断流、
    # 连 /health 都不响应。实机表现就是"点了发布后界面卡死"。
    out_lines: list[str] = []

    def _pump() -> None:
        """在线程里逐行读 stdout，同时推进度。"""
        try:
            for raw in proc.stdout:  # type: ignore
                line = raw.decode("utf-8", "replace").rstrip()
                out_lines.append(line)
                if on_progress and line.startswith("[progress]"):
                    try:
                        on_progress(line[10:].strip())
                    except Exception:
                        pass
        except Exception as e:
            out_lines.append(f"[err] stdout read failed: {e}")

    try:
        await asyncio.to_thread(_pump)
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"ok": False, "error": "worker 超时", "log": out_lines[-30:]}
    finally:
        RUNNING.pop(job_id, None)
        try:
            drv.unlink()
        except Exception:
            pass

    # 解析最后一行 JSON
    result = {}
    for line in reversed(out_lines):
        if line.startswith("[result]"):
            try:
                result = json.loads(line[8:].strip())
                break
            except Exception:
                pass
    # 把 [err] 行单独提出来，方便上层给出可读的失败原因
    errs = [ln[6:].strip() for ln in out_lines if ln.startswith("[err]")]
    return {"ok": True, "result": result, "log": out_lines[-40:],
            "stderr": errs[-10:]}


def _driver_js(worker: str, data: str, commands: list[dict]) -> str:
    """生成驱动脚本（fork worker，顺跑命令，输出 [result] JSON）。"""
    return f"""
import {{ fork }} from 'node:child_process';
const WORKER = {json.dumps(worker)};
const DATA = {json.dumps(data)};
const CMDS = {json.dumps(commands, ensure_ascii=False)};

let seq = 0;
const pending = new Map();
const child = fork(WORKER, [], {{
  env: {{ ...process.env,
    REELS_PUBLISHER_DATA_DIR: DATA,
    REELS_PUBLISHER_OUTPUT_DIR: DATA }},
  stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
}});

function call(command, payload, timeoutMs) {{
  return new Promise((resolve, reject) => {{
    const id = 'r' + (++seq);
    pending.set(id, {{ resolve, reject }});
    child.send({{ id, command, payload: payload || {{}} }});
    setTimeout(() => {{
      if (pending.has(id)) {{ pending.delete(id); reject(new Error('timeout:' + command)); }}
    }}, timeoutMs || 180000);
  }});
}}

child.on('message', (m) => {{
  if (m.type === 'ready') {{ run(); return; }}
  if (m.type === 'progress') {{
    const e = m.event || {{}};
    if (e.stage) console.log('[progress] ' + e.stage);
    return;
  }}
  if (m.id && pending.has(m.id)) {{
    const {{ resolve, reject }} = pending.get(m.id);
    pending.delete(m.id);
    if (m.ok) resolve(m.value);
    else reject(new Error((m.error?.code || 'ERR') + ': ' + (m.error?.message || '')));
  }}
}});
child.stderr?.on('data', (d) => {{
  const s = d.toString().trim();
  if (s) console.log('[err] ' + s.slice(0, 300));
}});

async function run() {{
  let last = null;
  try {{
    for (const c of CMDS) {{
      last = await call(c.command, c.payload, c.timeout || 180000);
    }}
  }} catch (e) {{
    // ⚠ 必须 return：以前这里没 return，出错后仍会往下打印一条
    //   [result] {{ok:true, value:last}}，而 last 是上一个命令的结果。
    //   call_worker 只取最后一条 [result]，于是 start 的失败被
    //   checkBrowsers 的快照顶掉，表现为"内核未执行发布（只返回了计划快照）"。
    console.log('[result] ' + JSON.stringify({{ ok: false, error: e.message }}));
    try {{ await call('shutdown', {{}}, 20000); }} catch {{}}
    child.kill();
    setTimeout(() => process.exit(0), 300);
    return;
  }}
  console.log('[result] ' + JSON.stringify({{ ok: true, value: last }}));
  try {{ await call('shutdown', {{}}, 20000); }} catch {{}}
  child.kill();
  setTimeout(() => process.exit(0), 500);
}}
setTimeout(() => {{ console.log('[result] ' + JSON.stringify({{ ok: false, error: 'global timeout' }})); child.kill(); process.exit(1); }}, 3600000);
"""


# ---------- 高层操作 ----------
async def discover_pages(container_code: str = "", timeout_s: float = 300) -> dict:
    """抓 Page ID 并写入内核 state.json。

    为什么必须显式调：
        内核的 checkBrowsers / start 都要求 state.json 里已经有
        plan.assignments 与 pageDiscovery.status='ready'（见 worker.mjs:150-152）。
        只调 checkBrowsers 会得到 PLAN_REQUIRED / PAGE_DISCOVERY_REQUIRED。
        以前没有这一步，所以每次发布都报"内核未执行发布（只返回了计划/发现快照）"。
    """
    r = await call_worker(
        [{"command": "discoverPages", "payload": {}, "timeout": int(timeout_s * 1000)}],
        timeout_s=timeout_s + 60)
    if not r.get("ok"):
        return r
    raw = r.get("result") or {}
    if raw.get("ok") is False:
        err = str(raw.get("error") or "Page ID 获取失败")
        return {"ok": False, "error": err, "log": r.get("log") or [],
                "stderr": r.get("stderr") or []}
    v = raw.get("value") if isinstance(raw.get("value"), dict) else raw
    v = v or {}
    disc = v.get("discovery") or {}
    plan = v.get("plan") or {}
    return {
        "ok": True,
        "pages": len(disc.get("pages") or []),
        "assignments": len(plan.get("assignments") or []),
        "failedEnvironments": disc.get("failedEnvironments") or [],
        "pageDiscovery": v.get("pageDiscovery") or {},
    }


async def ensure_plan(*, container_code: str = "", force: bool = False,
                      on_progress=None) -> dict:
    """确保内核 state.json 里有可用的 plan（发布前的硬前置）。

    重要副作用（实机踩坑）：
        discoverPages 会把工作标签导航到 facebook.com/pages/?category=your_pages
        去抓 Page ID。抓完这张标签就**不是** business.facebook.com/latest/ 了，
        紧接着的 checkBrowsers 会报 META_TAB_REQUIRED。

        所以调用方必须在 ensure_plan 之后**重新 prepare_publish**，
        把工作标签导航回 Meta Business Suite。publish() 里的顺序就是：
            prepare → discoverPages → prepare(again) → checkBrowsers → start
    """
    st = await status()
    if not st.get("ok"):
        return {"ok": False, "error": st.get("error") or "内核不可用",
                "stage": "status"}

    plan = (st.get("plan") or {}).get("assignments") or []
    pd = st.get("pageDiscovery") or {}
    disc = st.get("discovery") or {}

    if not force and plan and pd.get("status") == "ready" and (disc.get("pages") or []):
        return {"ok": True, "reused": True, "assignments": len(plan),
                "pages": len(disc.get("pages") or [])}

    if on_progress:
        try:
            on_progress("内核没有可用的发布计划，正在抓取 Page ID…")
        except Exception:
            pass

    r = await discover_pages(container_code)
    if not r.get("ok"):
        return {"ok": False, "stage": "discover", **r}

    if not r.get("assignments"):
        return {"ok": False, "stage": "discover",
                "error": "抓到 0 个可发布主页（检查浏览器是否登录、是否有主页权限）"}

    return {"ok": True, "reused": False,
            "assignments": r["assignments"], "pages": r["pages"]}


async def release_hashes(hashes: list[str]) -> dict:
    """把指定的素材 hash 从内核 usedHashes 里放出来（允许重发）。

    为什么需要：内核的 selectAvailableVideos 会严格跳过 usedHashes 里的文件：
        if (!used.has(fingerprint.sha256)) available.push(...)
    yuhai 侧有自己的去重（units + publish_items），两边的判据不同步时，
    staging 目录里的文件会被内核全部过滤掉，报
        MATERIAL_SHORTAGE: 所选 N 个主页需要 M 个视频，当前只有 0 个
    前端显示"素材充足"却发不出去，且错误信息完全看不出原因。

    实现：内核没有 releaseHash 命令，直接改 state.json 的 usedHashes。
    复用 services/publish_admin.py 里已经验证过的 release_hash（它做了
    备份、大小写兜底、list/dict 两种形态兼容）。
    """
    want = [str(h).strip().lower() for h in (hashes or []) if str(h).strip()]
    if not want:
        return {"ok": True, "released": 0}

    from app.services import publish_admin as pa

    released = 0
    for h in want:
        try:
            r = pa.release_hash(hash_value=h)
            if r.get("ok") and not r.get("skipped"):
                released += 1
        except Exception as e:
            log.warning("release hash %s failed: %s", h[:12], e)

    if released:
        log.info("released %d hashes from kernel usedHashes", released)
    return {"ok": True, "released": released}


async def reprepare_all(on_progress=None) -> dict:
    """把每个运行中环境的工作标签导航回 Meta Business Suite。

    discoverPages 抓完 Page ID 后，工作标签停在 facebook.com/pages/，
    必须重新导航回 business.facebook.com/latest/ 才能通过 checkBrowsers。
    """
    from app.services import prepare as pz
    envs = _prepare_targets(None)
    ok_n = 0
    failed: list[dict] = []
    for code in envs:
        pr = await pz.prepare_publish(code)
        if pr.get("ok"):
            ok_n += 1
        else:
            failed.append({"environmentId": code, "error": pr.get("error")})
    if on_progress:
        try:
            on_progress(f"工作标签已归位 {ok_n}/{len(envs)} 个环境")
        except Exception:
            pass
    return {"ok": ok_n > 0, "ready": ok_n, "total": len(envs), "failed": failed}


async def prepare_publish_ready(*, on_progress=None) -> dict:
    """发布前的一次性总准备。做完这一步，后续 start 就不会再报前置错误。

    完整顺序（缺任何一步都会失败，都是实机踩出来的）：
        ① prepare 每个环境   → 工作标签导航到 business.facebook.com/latest/home
                               缺这步 → checkBrowsers 报 META_TAB_REQUIRED
        ② 检查/抓 plan       → 没有 plan 就 discoverPages
                               缺这步 → start 报 PLAN_REQUIRED
        ③ 再 prepare 一遍    → discoverPages 会把标签导到 facebook.com/pages/
                               不归位 → checkBrowsers 又报 META_TAB_REQUIRED
        ④ checkBrowsers      → 必须排在 ③ 之后
                               缺这步 → start 报 BROWSER_NOT_READY
                               且 browserCheck.checkedAt 必须晚于 browserCheckRequiredAt

    返回值里带 environments 明细，前端可以显示"哪个环境没准备好"。
    """
    from app.services import prepare as pz

    # ① 先把所有环境接到 Meta Business Suite
    envs = _prepare_targets(None)
    if not envs:
        return {"ok": False, "stage": "env", "error": "没有运行中的发布环境",
                "environments": []}

    if on_progress:
        try:
            on_progress(f"准备浏览器（{len(envs)} 个环境）…")
        except Exception:
            pass

    env_ready: list[dict] = []
    for i, code in enumerate(envs, 1):
        pr = await pz.prepare_publish(code)
        env_ready.append({
            "environmentId": code,
            "ok": bool(pr.get("ok")),
            "assetId": pr.get("assetId") or "",
            "pageName": pr.get("pageName") or "",
            "cdpPort": pr.get("cdpPort"),
            "error": (pr.get("error") or "")[:160],
        })
        if on_progress:
            try:
                on_progress(
                    f"环境 {i}/{len(envs)} {code} "
                    f"{'就绪' if pr.get('ok') else '失败：' + (pr.get('error') or '')[:60]}")
            except Exception:
                pass

    if not any(e["ok"] for e in env_ready):
        return {"ok": False, "stage": "prepare",
                "error": "所有环境都无法打开 Meta 工作标签",
                "environments": env_ready}

    # ② 抓 plan（已有就复用）
    if on_progress:
        try:
            on_progress("检查发布计划…")
        except Exception:
            pass
    plan_info = await ensure_plan(container_code="", on_progress=on_progress)
    if not plan_info.get("ok"):
        return {"ok": False, "stage": "plan",
                "error": plan_info.get("error") or "获取 Page ID 失败",
                "environments": env_ready}

    # ③ 抓完 Page ID 后标签被导航走了，必须再归位一次
    if not plan_info.get("reused"):
        if on_progress:
            try:
                on_progress("抓完 Page ID，正在把工作标签归位…")
            except Exception:
                pass
        rp = await reprepare_all(on_progress=on_progress)
        if not rp.get("ready"):
            return {"ok": False, "stage": "reprepare",
                    "error": "工作标签无法归位到 Meta Business Suite",
                    "environments": env_ready}

    # ④ 检查浏览器（必须最后）
    if on_progress:
        try:
            on_progress("检查 Meta 工作标签…")
        except Exception:
            pass
    cb = await check_browsers()
    results = cb.get("results") or []
    ready_n = sum(1 for x in results if x.get("status") == "ready")
    if not ready_n:
        detail = "；".join(
            f"{x.get('environmentId')}: {x.get('error') or x.get('code') or '未知'}"
            for x in results[:3])
        return {"ok": False, "stage": "check",
                "error": f"没有可用的 Meta 工作标签（{detail}）",
                "environments": env_ready,
                "browserCheck": results}

    if on_progress:
        try:
            on_progress(f"准备完成：{ready_n} 个环境可用，"
                        f"计划 {plan_info.get('assignments')} 个主页")
        except Exception:
            pass

    return {"ok": True,
            "environments": env_ready,
            "browserCheck": results,
            "readyEnvironments": ready_n,
            "planAssignments": plan_info.get("assignments") or 0,
            "reusedPlan": bool(plan_info.get("reused"))}


async def status() -> dict:
    r = await call_worker([{"command": "status", "payload": {}, "timeout": 60000}],
                          timeout_s=90)
    if not r.get("ok"):
        return r
    raw = r.get("result") or {}
    # 驱动脚本把命令返回值包在 {ok:true, value:{...}} 里；
    # 以前这里直接 {...r["result"]} 展开，得到的是 {ok, value}，
    # 于是调用方 st.get("plan") 永远 None —— plan 明明存在却当成不存在，
    # 导致每次都重新抓 Page ID、且 ensure_plan 判定"没有计划"。
    if raw.get("ok") is False:
        return {"ok": False, "error": str(raw.get("error") or "内核状态读取失败"),
                "stderr": r.get("stderr") or []}
    v = raw.get("value") if isinstance(raw.get("value"), dict) else raw
    return {"ok": True, **(v or {})}


async def check_browsers() -> dict:
    r = await call_worker(
        [{"command": "checkBrowsers", "payload": {}, "timeout": 120000}],
        timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{browserCheck:{...}}}
    if "value" in v and isinstance(v.get("value"), dict):
        v = v["value"]
    bc = (v.get("browserCheck") or {})
    return {"ok": True, "results": bc.get("results") or [],
            "environments": bc.get("environments") or []}


async def scan_materials(directory: str) -> dict:
    r = await call_worker(
        [{"command": "scanMaterials",
          "payload": {"directory": directory, "directories": [directory]},
          "timeout": 120000}], timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{groups,total,folderCount,sampleTitle}}
    if "value" in v and isinstance(v.get("value"), dict):
        return {"ok": True, **(v["value"])}
    return {"ok": True, **v}


async def publish(directory: str, description: str, link_pool: str,
                  clips_per_page: int = 1, concurrency: int = 1,
                  publish_mode: str = "merge",
                  browser_ids: list[str] | None = None,
                  pages: list[str] | None = None,
                  materials: list[str] | None = None,
                  title_mode: str = "random",
                  reference_title: str = "",
                  use_random_link: bool = True,
                  fixed_title: str = "",
                  timeout_s: float = 3600, on_progress=None,
                  job_id: str = "",
                  interval_minutes: int = 30,
                  upload_stall_seconds: int = 180,
                  spacing_minutes: int = 30,
                  schedule_offsets: list[int] | None = None,
                  auto_prepare: bool = True) -> dict:
    """批量发布。description 是标题模板，link_pool 是链接池（每行一个）。

    pages     : 限定发哪些主页（pageId 列表，空=全部）
    materials : 限定用哪些素材（文件路径列表，空=目录里全部）
    auto_prepare : 是否自动把浏览器摆到可发布状态（开环境 + 开 Meta 工作标签）

    完整前置链（缺一步都会失败，这是实机踩出来的顺序）：
        ① prepare_publish  → 开环境、导航到 business.facebook.com/latest/home
                             缺这步 → checkBrowsers 报 META_TAB_REQUIRED
        ② discoverPages    → 抓 Page ID 写 plan
                             缺这步 → start 报 PLAN_REQUIRED
        ③ checkBrowsers    → 校验每个环境恰好一个 Meta 工作标签
                             缺这步 → start 报 BROWSER_NOT_READY
        ④ start            → 真正发布

    on_progress 会收到每一步的说明，前端能看出卡在哪。
    """
    # ① 自动准备：把**每个**运行中的发布环境都摆到"有 Meta 工作标签"的状态。
    #
    # 为什么必须逐个准备：
    #   plan.requiresAllEnvironments=True（见 core/plans.mjs:151），
    #   checkBrowsers 只要有一个环境 META_TAB_REQUIRED 就整体不可用。
    #   以前只 prepare 第一个环境，第二个环境没开工作标签，
    #   于是任何发布都报 BROWSER_NOT_READY —— 这是实机踩到的坑。
    if auto_prepare:
        envs = _prepare_targets(browser_ids)
        if not envs:
            return {
                "ok": False, "error": "没有运行中的发布环境", "stage": "prepare",
                "_verdict": {"ok": False, "state": "prepare-failed",
                             "reason": "没有运行中的发布环境"},
                "log": [],
            }
        from app.services import prepare as pz
        for i, code in enumerate(envs, 1):
            if on_progress:
                try:
                    on_progress(f"准备浏览器 {i}/{len(envs)} · 环境 {code}…")
                except Exception:
                    pass
            pr = await pz.prepare_publish(code)
            if not pr.get("ok"):
                # 单个环境准备失败不立刻中断：其余环境仍可能可用，
                # 让 checkBrowsers 给出完整清单，前端一次看清哪些不行。
                if on_progress:
                    try:
                        on_progress(f"环境 {code} 准备失败：{pr.get('error')}")
                    except Exception:
                        pass
                continue
            if on_progress:
                try:
                    on_progress(
                        f"环境 {code} 就绪 · 当前主页 "
                        f"{pr.get('pageName') or pr.get('assetId') or '—'}")
                except Exception:
                    pass

    # ② 确保 plan 存在（内核的硬前置）
    plan_info = await ensure_plan(
        container_code="",
        on_progress=on_progress,
    )
    if not plan_info.get("ok"):
        return {
            "ok": False,
            "error": plan_info.get("error") or "内核发布计划不可用",
            "stage": plan_info.get("stage") or "plan",
            "_verdict": {"ok": False, "state": "plan-unavailable",
                         "reason": plan_info.get("error") or "内核发布计划不可用"},
            "log": [],
        }

    # ③ 抓完 plan 后必须重新检查浏览器：worker.mjs:188 要求
    #    browserCheck.checkedAt >= plan.browserCheckRequiredAt
    #    但 discoverPages 把标签导到了 facebook.com/pages/，
    #    必须先把它导航回 business.facebook.com/latest/，否则必报 META_TAB_REQUIRED。
    if auto_prepare:
        if on_progress:
            try:
                on_progress("抓完 Page ID，正在把工作标签归位到 Meta Business Suite…")
            except Exception:
                pass
        rp = await reprepare_all(on_progress=on_progress)
        if not rp.get("ready"):
            return {
                "ok": False,
                "error": "抓完 Page ID 后无法把工作标签归位到 Meta Business Suite"
                         + (f"（{rp['failed'][0]['error']}）" if rp.get("failed") else ""),
                "stage": "reprepare",
                "_verdict": {"ok": False, "state": "prepare-failed",
                             "reason": "工作标签无法归位到 Meta Business Suite"},
                "log": [],
            }

    cmds: list[dict] = []
    cmds.append({"command": "checkBrowsers", "payload": {}, "timeout": 180000})

    payload = {
        "directory": directory,
        "directories": [directory],
        "publishMode": publish_mode,
        "clipsPerPage": clips_per_page,
        "concurrency": concurrency,
        "browserIds": browser_ids or [],
        "description": description,
        "linkPool": link_pool,
        "interPageDelaySeconds": {"min": max(0, int(interval_minutes or 30)) * 60,
                                  "max": max(0, int(interval_minutes or 30)) * 60},
        # 上传卡住容忍：之前这个参数在 API 层就被丢掉了，worker 只能吃默认值
        "uploadStallTimeoutSeconds": max(60, min(3600, int(upload_stall_seconds or 180))),
        # 同一主页内多条视频的排期间隔（分钟），以及逐条不等距偏移
        "spacingMinutes": max(0, int(spacing_minutes or 30)),
        "scheduleOffsets": [int(x) for x in (schedule_offsets or []) if x is not None],
    }

    # 多标题：为每个目标主页分配一条独立文案，交给 worker 按主页替换。
    #
    # 2026-11-12 重写：不再走标题池，改成按剧实时生成 + 批内不重复。
    #   旧逻辑基于 caption_variants 表，池子里堆的是别的剧的标题；
    #   而且 random.choice 会让多个主页抽到同一条。
    #   现在按"本轮涉及的剧"算需求，一次性分配，每主页拿到的标题都不同。
    if (title_mode or "random").lower() == "random":
        try:
            from app.services import caption as cap
            targets = list(pages) if pages else [p.get("pageId") for p in plan_pages()]
            page_captions: dict[str, str] = {}

            if on_progress:
                try:
                    on_progress("按剧生成标题…")
                except Exception:
                    pass

            # 本轮素材涉及的剧 → 每剧需要的条数（等距取多，宁可多生成）
            drama_counts: dict[str, int] = {}
            try:
                mats = _materials_for_titles(directory)
                per_drama = max(1, int(clips_per_page or 1))
                for m in mats:
                    d = (getattr(m, "drama", "") or "").strip()
                    if d:
                        drama_counts[d] = drama_counts.get(d, 0) + 1
            except Exception as e:
                log.debug("统计剧名失败: %s", e)

            titles_map = await cap.assign_batch_titles(drama_counts) if drama_counts else {}

            # 把每部剧的标题按顺序分给各主页（主页循环取，跨剧轮流）
            flat: list[tuple[str, str]] = []      # [(drama, title)]
            for d, lst in titles_map.items():
                for t in lst:
                    flat.append((d, t))

            for i, pid in enumerate([t for t in targets if t]):
                title = ""
                if flat:
                    title = flat[i % len(flat)][1]
                if not title:
                    title = reference_title.strip() or cap.REFERENCE_TITLE

                link_url = ""
                manual_links = [x for x in (link_pool or "").split() if x.strip()]
                if manual_links and use_random_link:
                    import random as _rnd
                    link_url = _rnd.choice(manual_links)
                elif use_random_link:
                    try:
                        lk = cap.pick_link(str(pid))
                        link_url = (lk or {}).get("url") or ""
                        if lk and lk.get("id"):
                            cap.mark_link_used(lk["id"])
                    except Exception:
                        link_url = ""
                else:
                    link_url = manual_links[0] if manual_links else ""

                # 与发布中心一致的组装：标题 + 空行 + 引导语 + 链接
                from app.services import publish_engine as _pe
                page_captions[str(pid)] = _pe._compose_simple(title, link_url)

            if page_captions:
                payload["pageCaptions"] = page_captions
        except Exception as e:
            print(f"[reels] 逐主页文案生成失败，退回单一模板: {e}")
    elif fixed_title.strip():
        payload["description"] = fixed_title.strip()
    # 限定主页：worker 支持 skippedPageIds（反向排除）
    if pages:
        from app.services.reels import plan_pages as _pp
        all_ids = [p.get("pageId") for p in _pp()]
        skip = [x for x in all_ids if x and x not in set(pages)]
        if skip:
            payload["skippedPageIds"] = skip

    # 只在部分环境下发布：必须把**其它环境的全部主页**都塞进 skippedPageIds。
    #
    # 为什么：
    #   内核的 plan.requiresAllEnvironments 硬编码为 true（core/plans.mjs:151），
    #   publisher.mjs:192-200 要求"计划里出现的每个环境都必须被选中"，
    #   否则报 ALL_TASK_BROWSERS_REQUIRED。
    #
    #   但那个校验的判据是「remainingPlan 里还有哪些 environmentId」：
    #       remainingPlan = plan.assignments 去掉 skippedPageIds
    #   所以只要把不参与的环境的主页全部 skip 掉，它们就从计划里消失了，
    #   requiresAllEnvironments 这道校验自然通过 —— 不需要改内核源码。
    if browser_ids:
        keep_envs = {str(x) for x in browser_ids if str(x).strip()}
        if keep_envs:
            from app.services.reels import plan_pages as _pp2
            extra = []
            for p in _pp2():
                pid = str(p.get("pageId") or "")
                env = str(p.get("environmentId") or "")
                if pid and env and env not in keep_envs:
                    extra.append(pid)
            if extra:
                merged = list(dict.fromkeys(
                    (payload.get("skippedPageIds") or []) + extra))
                payload["skippedPageIds"] = merged
    # 限定素材：worker 支持 selectedFiles
    if materials:
        payload["selectedFiles"] = materials

    cmds.append({"command": "start", "payload": payload,
                 "timeout": int(timeout_s * 1000)})

    r = await call_worker(cmds, timeout_s=timeout_s + 120, on_progress=on_progress,
                          job_id=job_id)
    if not r.get("ok"):
        return r

    # 驱动脚本自己报错了（例如 start 抛错）→ 直接把真实原因透出，
    # 不要退回到"看快照"那条路，否则用户只能看到"内核未执行发布"。
    raw = r.get("result") or {}
    if raw.get("ok") is False:
        err = str(raw.get("error") or "")
        stderr = r.get("stderr") or []
        if stderr and err and stderr[-1] not in err:
            err = f"{err}（{stderr[-1]}）"
        return {"ok": False, "error": err or "内核命令失败",
                "log": r.get("log") or [], "_verdict": {
                    "ok": False, "state": "command-failed",
                    "reason": err or "内核命令失败"}}

    v = r.get("result") or {}
    value = v.get("value") if isinstance(v.get("value"), dict) else v
    value = value or {}

    # 实机验证（2026-11-12）：
    # worker 的 start 回执里 ok=true 只代表「命令执行完毕」，不代表发布成功。
    # 真正的结果在 value.state（如 needs_attention）和 value.pages[].state/error 里。
    # 旧实现只看 ok，导致：
    #   state=needs_attention / PAGE_OPERATION_TIMEOUT / halted
    # 被判成「发布完成、进度 100%」，界面显示成功但视频根本没发出去。
    verdict = _judge_publish_result(value)
    return {"ok": verdict["ok"], **value, "_verdict": verdict}


def _judge_publish_result(value: dict) -> dict:
    """根据 worker 真实回执判定发布是否成功。

    成功必须同时满足：
      · 顶层 state 不是 needs_attention / failed / halted
      · 每个已分配主页的 state 是 published/done/success
      · 没有 PUBLICATION_FAILED 之类错误
    """
    if not isinstance(value, dict):
        return {"ok": False, "reason": "worker 未返回可解析结果"}

    state = str(value.get("state") or "").lower()
    if state in ("needs_attention", "failed", "halted", "error", "stopped"):
        errs = []
        for p in (value.get("pages") or []):
            e = p.get("error") or {}
            if isinstance(e, dict) and (e.get("message") or e.get("reason")):
                errs.append(f"{p.get('pageName') or p.get('pageId')}: "
                            f"{e.get('reason') or e.get('message')}")
            elif p.get("error"):
                errs.append(f"{p.get('pageName') or p.get('pageId')}: {p['error']}")
        return {"ok": False, "state": state,
                "reason": "; ".join(errs)[:300] or f"发布未完成（state={state}）"}

    pages = value.get("pages") or []
    if not pages:
        # 没有页面明细有两种情况：
        #   a) 老版 worker 只回 ok
        #   b) 返回的是 plan/pageDiscovery 快照（= 本次没真正执行发布）
        # 后者必须判失败，否则又会变成假成功。
        has_plan = isinstance(value.get("plan"), dict)
        has_disc = isinstance(value.get("pageDiscovery"), dict)
        if has_plan or has_disc:
            return {"ok": False, "state": state or "not-executed",
                    "reason": "内核未执行发布（只返回了计划/发现快照）"}
        return {"ok": bool(value.get("ok")), "state": state or "unknown",
                "reason": "" if value.get("ok") else "无页面执行明细"}

    ok_states = {"published", "done", "success", "completed", "ok"}
    bad = []
    ok_n = 0
    for p in pages:
        ps = str(p.get("state") or "").lower()
        if ps not in ok_states or p.get("error"):
            e = p.get("error") or {}
            msg = (e.get("reason") or e.get("message")) if isinstance(e, dict) else str(e)
            bad.append(f"{p.get('pageName') or p.get('pageId')}"
                       f"[{ps or 'unknown'}]{': ' + str(msg)[:80] if msg else ''}")
            continue

        # ⚠ 光看 state=completed 不够（2026-11-12 实机踩坑）。
        #
        # 内核有两条"完成"路径：
        #   ① 真发布：returnHome={status:'home', platformReceipt:true}
        #   ② 只点了按钮、平台没回执：state 也是 completed，
        #      但 returnHome={status:'pending', message:'60 秒内未看到平台提交完成提示'}
        #      并留下 POST_SUBMIT_REVIEW 证据。
        #
        # 第二种在 Meta 后台**查不到帖子**，之前被当成成功上报，
        # 造成"界面显示发成功、后台没有"的假成功。
        # 这里补一道：有 returnHome 且状态不是 home → 判失败。
        rh = p.get("returnHome")
        if isinstance(rh, dict):
            rh_status = str(rh.get("status") or "").lower()
            receipt = rh.get("platformReceipt")
            if rh_status and rh_status != "home":
                bad.append(
                    f"{p.get('pageName') or p.get('pageId')}"
                    f"[{ps}]{': 平台未确认（returnHome=' + rh_status + '）'}"
                    f"{'：' + str(rh.get('message'))[:60] if rh.get('message') else ''}")
                continue
            if receipt is False:
                bad.append(
                    f"{p.get('pageName') or p.get('pageId')}"
                    f"[{ps}]: 平台未返回提交回执（platformReceipt=false）")
                continue
        ok_n += 1

    if bad:
        return {"ok": False, "state": state or "partial",
                "okPages": ok_n, "failedPages": len(bad),
                "reason": "; ".join(bad)[:300]}
    return {"ok": True, "state": state or "published", "okPages": ok_n,
            "failedPages": 0, "reason": ""}


async def archive_current_run() -> dict | None:
    """归档内核里残留的 currentRun。

    实机验证（2026-11-12）：内核 start 命令在存在未归档运行时会返回

        RUN_ACTIVE: 当前仍有一轮任务，不能重复创建。

    而失败（needs_attention / halted）的运行不会自动归档，结果是
    一次失败之后所有发布都发不出去，界面还显示「发布完成」。
    发布前先调 archiveRun 把它转成历史记录。
    """
    try:
        st = await call_worker(
            [{"command": "status", "payload": {}, "timeout": 60000}], timeout_s=90)
    except Exception as e:
        log.warning("archive_current_run status failed: %s", e)
        return None

    v = (st.get("result") or {}).get("value") or {}
    cur = v.get("currentRun")
    if not cur:
        return None

    state = str(cur.get("state") or "").lower()
    # 还在跑的不要动
    if state in ("running", "queued", "publishing") and not state.count("attention"):
        pass

    try:
        r = await call_worker(
            [{"command": "archiveRun", "payload": {}, "timeout": 120000}],
            timeout_s=180)
        log.info("archived stale run %s (state=%s)", cur.get("id"), state)
        return {"archived": cur.get("id"), "state": state, "ok": r.get("ok")}
    except Exception as e:
        log.warning("archiveRun failed: %s", e)
        return None


def stop_worker(job_id: str = "") -> dict:
    targets = []
    if job_id:
        p = RUNNING.get(job_id)
        if p:
            targets.append((job_id, p))
    else:
        targets = list(RUNNING.items())

    if not targets:
        # 兜底：扫系统里所有 _drv 驱动的 node 进程
        killed = _kill_stray()
        return {"ok": True, "stopped": killed,
                "note": "没有登记的进程，已清理遗留节点" if killed else "没有正在跑的发布"}

    out = []
    for jid, p in targets:
        try:
            # 杀进程树（Node 的子进程一起）
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
                               capture_output=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                               timeout=15)
            else:
                p.kill()
            out.append(jid)
        except Exception as e:
            log.warning("stop %s failed: %s", jid, e)
    # 再清一遍遗留
    stray = _kill_stray()
    for jid in out:
        RUNNING.pop(jid, None)
    return {"ok": True, "stopped": out, "strayCleaned": stray,
            "note": f"已停止 {len(out)} 个任务"}


def _kill_stray() -> int:
    """清理遗留的 _drv 驱动 node 进程。"""
    if os.name != "nt":
        return 0
    n = 0
    try:
        r = subprocess.run(
            ["wmic", "process", "where", "name='node.exe'", "get",
             "ProcessId,CommandLine", "/format:csv"],
            capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for line in (r.stdout or "").splitlines():
            if "_drv_" in line and "worker" in line.lower() or "_drv_" in line:
                parts = [x for x in line.split(",") if x.strip()]
                pid = parts[-1].strip()
                if pid.isdigit():
                    subprocess.run(["taskkill", "/F", "/T", "/PID", pid],
                                   capture_output=True,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                                   timeout=10)
                    n += 1
    except Exception:
        pass
    return n


def state_snapshot() -> dict:
    """读 state.json 里的计划/发现数据（不启动 worker，快）。"""
    st = data_dir() / "state.json"
    if not st.exists():
        return {}
    try:
        return json.loads(st.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _materials_for_titles(directory: str) -> list:
    """扫一下目录里的素材，用于统计本轮涉及哪些剧。

    只读文件名和父目录（剧名 = 父目录名），不做 hash，很快。
    """
    from pathlib import Path as _P
    out = []
    try:
        root = _P(directory)
        if not root.is_dir():
            return out
        for f in root.rglob("*"):
            if f.suffix.lower() in (".mp4", ".mov", ".m4v", ".webm"):
                drama = f.parent.name if f.parent != root else ""
                out.append(type("M", (), {"drama": drama, "path": str(f)})())
    except Exception:
        pass
    return out


def _prepare_targets(browser_ids: list[str] | None) -> list[str]:
    """要准备哪些环境。

    必须准备**所有运行中的环境**，不能用 browser_ids 收窄：
        discoverPages 会把每个环境的主页都写进 plan，
        plan.requiresAllEnvironments=True，
        checkBrowsers 只要有一个环境没有 Meta 工作标签就整体判失败。
        实机表现：只准备 1 个环境 → 另一个环境 META_TAB_REQUIRED
        → 任何发布都报 BROWSER_NOT_READY。
    """
    try:
        rows = db.q("SELECT container_code FROM envs "
                    "WHERE status='running' AND cdp_port IS NOT NULL "
                    "AND role IN ('publisher','backup') "
                    "ORDER BY CASE role WHEN 'publisher' THEN 0 ELSE 1 END, "
                    "container_code")
        out = [r["container_code"] for r in rows if r["container_code"]]
        if out:
            return out
    except Exception:
        pass
    try:
        rows = db.q("SELECT container_code FROM envs WHERE status='running' "
                    "AND cdp_port IS NOT NULL ORDER BY container_code")
        return [r["container_code"] for r in rows if r["container_code"]]
    except Exception:
        return []


def plan_pages() -> list[dict]:
    """当前 plan 里的主页清单。"""
    s = state_snapshot()
    out = []
    for a in (s.get("plan") or {}).get("assignments") or []:
        out.append({
            "pageId": a.get("pageId"),
            "pageName": a.get("pageName"),
            "profileId": a.get("profileId"),
            "environmentId": a.get("environmentId"),
        })
    return out
