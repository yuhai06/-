# -*- coding: utf-8 -*-
"""标题生成：按剧实时生成，批内不重复，不落库。

═══ 2026-11-12 重构说明 ═══

用户需求："标题池删了吧，反正又不发重复，直接让 AI 生成就行了"

被删掉的东西（标题池）：
    · caption_variants / title_pool 两张表的读写
    · pool_size / list_title_pool / pick_caption / save_titles / ensure_title_pool
    · used_count 轮转机制

为什么删：
    标题池的前提是"同一批标题反复用"，而实际场景是**每批发布不同的剧**。
    池子里的《A 剧》标题拿去发《B 剧》的素材，内容完全对不上；
    前端还显示"文案池 672 条"这种没人看得懂的数字。

现在的做法：
    · 每批发布前，按本轮涉及的剧，实时让 AI 生成一批标题
    · **批内每条视频标题不同**（同剧 6 条 = 6 个不同标题）
    · 进程内保留 6 分钟缓存，避免改个参数就重新调一次模型
    · 用掉的标题从缓存里摘掉，下一批不会重复

数据库里那张表仍然保留（不 DROP），只是不再读写 ——
这样万一要回滚旧代码，数据还在。
"""
from __future__ import annotations

import hashlib
import logging
import random
import time as _time

log = logging.getLogger("yuhai.caption")


# ─────────────────────────────────────────────────────────────
# 参考标题（AI 没配好时的兜底）
# ─────────────────────────────────────────────────────────────

REFERENCE_TITLE = (
    "When she walked into the banquet, everyone laughed at her cheap dress — "
    "until the CEO stood up and called her 'mother'."
)


# ─────────────────────────────────────────────────────────────
# 进程内标题缓存（按剧）
# ─────────────────────────────────────────────────────────────

_TITLE_CACHE: dict[str, dict] = {}     # {drama: {"titles": [...], "at": ts}}
_TITLE_CACHE_TTL = 360                 # 6 分钟


def _cache_get(drama: str) -> list[str]:
    item = _TITLE_CACHE.get(drama)
    if not item:
        return []
    if _time.time() - item["at"] > _TITLE_CACHE_TTL:
        _TITLE_CACHE.pop(drama, None)
        return []
    return list(item["titles"])


def _cache_put(drama: str, titles: list[str]) -> None:
    _TITLE_CACHE[drama] = {"titles": list(titles), "at": _time.time()}


def clear_title_cache(drama: str = "") -> None:
    """清空缓存（前端点「重新生成标题」时调用）。"""
    if drama:
        _TITLE_CACHE.pop(drama, None)
    else:
        _TITLE_CACHE.clear()


def cache_stats() -> dict:
    """缓存概况（给前端显示"已为 N 部剧备好标题"）。"""
    now = _time.time()
    items = []
    for d, v in _TITLE_CACHE.items():
        if now - v["at"] <= _TITLE_CACHE_TTL:
            items.append({"drama": d, "left": len(v["titles"])})
    return {"dramas": items, "ttlSeconds": _TITLE_CACHE_TTL}


# ─────────────────────────────────────────────────────────────
# 启发式变体（AI 不可用时的兜底，保证流程不中断）
# ─────────────────────────────────────────────────────────────

_HOOKS = [
    "Everyone laughed at her…",
    "She thought he was nobody.",
    "They humiliated her in public.",
    "Nobody knew who she really was.",
    "The moment he stood up, everything changed.",
    "Her cheap dress hid a secret.",
    "They called her a fraud. Then the truth came out.",
    "He said one word and the whole room went silent.",
    "She walked away. That's when he realized.",
    "One phone call changed everything.",
]


def _heuristic_variants(drama: str, n: int, page_name: str = "") -> list[str]:
    """无模型时的规则变体：换开头钩子句式，正文用剧名。"""
    name = (drama or "").strip() or "this story"
    out: list[str] = []
    for i in range(max(1, n)):
        hook = _HOOKS[i % len(_HOOKS)]
        v = f"{hook} {name.replace('_', ' ')}"
        if page_name:
            v = v  # 主页名不参与，避免标题带账号信息
        out.append(v[:180])
    return out


# ─────────────────────────────────────────────────────────────
# AI 生成
# ─────────────────────────────────────────────────────────────

async def generate_titles(ref: str, n: int = 5, model_id: str = "",
                          page_name: str = "", drama: str = "") -> dict:
    """基于剧名生成 N 个不同标题；失败退回规则变体。

    提示词要点（2026-11-12 重写，原版有三个问题）：
        ① 原版写死"英文标题" → 中文剧名生成的标题被翻成英文，
           与 🔍Title 行的中文剧名对不上
        ② 原版要求"60-140 字符" → 中文来说太长，放不进 Reels 首行
        ③ 原版完全没提剧名 → 模型不知道在写哪部剧，标题和素材无关
           （用户反馈"AI 生成的标题有问题"就是这个原因）
    """
    from app.services import ai_analysis as ai

    import re as _re
    # 判断语言：剧名里有汉字 → 中文标题，否则英文
    cn = len(_re.findall(r"[\u4e00-\u9fff]", drama or ref or ""))
    lang = "中文" if cn >= 2 else "英文"
    length_hint = ("20–45 个汉字" if lang == "中文" else "60–140 个字符")

    drama_line = f"这部剧的剧名是：「{drama}」。" if drama else ""
    ref_line = (f"参考标题（只借鉴风格，不要照抄）：\n「{ref}」\n"
                if ref and ref.strip() and ref.strip() != (drama or "").strip()
                else "")

    prompt = f"""你在给一部短剧写 Facebook Reels 的推广标题。
{drama_line}{ref_line}
请生成 {n} 个{lang}标题，要求：
- 必须围绕上面这部剧的内容与剧名，不要编造无关剧情
- 每条都要有强钩子：悬念 / 反差 / 打脸 / 身份揭露 / 意外转折
- 长度 {length_hint}，适合放在 Reels 首行展示
- 每条的第一句不能重复，不要都用同一个开头短语
- 不要出现 emoji、链接、话题标签、时长、平台名
- 不要写"点击链接""立即观看"这类行动号召（链接会单独放在正文后面）
- 只输出 JSON 数组，形如 ["标题1", "标题2", ...]，不要任何解释或代码块标记
"""
    try:
        text, used = await ai.call_model(prompt, model_id)
        data = ai.extract_json(text)
        if isinstance(data, dict):
            data = (data.get("titles") or data.get("result")
                    or data.get("data") or [])
        if isinstance(data, list) and data:
            titles: list[str] = []
            for x in data:
                t = str(x).strip().strip('"').strip("'")
                t = _re.sub(r"\s+", " ", t)
                if t and t not in titles:
                    titles.append(t)
            titles = titles[:n]
            if titles:
                return {"titles": titles, "source": f"model:{used}",
                        "lang": lang}
    except Exception as e:
        log.warning("generate_titles model failed: %s", e)

    return {"titles": _heuristic_variants(drama or ref, n, page_name),
            "source": "heuristic", "lang": lang}


# ─────────────────────────────────────────────────────────────
# 按剧生成 + 批内分配
# ─────────────────────────────────────────────────────────────

async def generate_for_drama(drama: str, need: int,
                             model_id: str = "") -> dict:
    """为一部剧备好至少 need 条标题（缓存优先，不落库）。

    返回 {titles: [...], source, cached}。
    """
    key = (drama or "").strip()
    if not key:
        return {"titles": [], "source": "none", "cached": False}

    cached = _cache_get(key)
    if len(cached) >= need:
        return {"titles": cached, "source": "cache", "cached": True}

    # 不够就多生成一些（一次 8 条起，减少调用次数）
    want = max(need, 8)
    try:
        r = await generate_titles(ref="", n=want, model_id=model_id, drama=key)
        fresh = [t for t in (r.get("titles") or []) if t.strip()]
    except Exception as e:
        log.warning("按剧生成标题失败 %s: %s", key, e)
        fresh = []
        r = {"source": "heuristic"}

    if fresh:
        merged = list(dict.fromkeys([*cached, *fresh]))
        _cache_put(key, merged)
        return {"titles": merged, "source": r.get("source") or "model",
                "cached": False}

    # 模型失败：规则变体兜底，保证发布不中断
    fallback = _heuristic_variants(key, want)
    _cache_put(key, fallback)
    return {"titles": fallback, "source": "heuristic", "cached": False}


async def assign_batch_titles(drama_counts: dict[str, int],
                              model_id: str = "",
                              force_regenerate: bool = False) -> dict[str, list[str]]:
    """给一批发布分配标题：每部剧按需生成，**批内不重复**。

    drama_counts = {"Kill_me_Love_me": 6, "How_to_tame_a_bad_boy": 3}
    → {"Kill_me_Love_me": [6 条互不相同], ...}

    这就是用户要的"不发重复"：同一批里同一部剧的 N 条视频，
    拿到的是 N 个不同的标题。
    """
    out: dict[str, list[str]] = {}
    for drama, n in (drama_counts or {}).items():
        d = (drama or "").strip()
        if not d or n <= 0:
            continue
        if force_regenerate:
            clear_title_cache(d)

        r = await generate_for_drama(d, n, model_id)
        titles = list(dict.fromkeys(r.get("titles") or []))
        if not titles:
            out[d] = [d.replace("_", " ")] * n
            continue

        picked: list[str] = []
        for i in range(n):
            if i < len(titles):
                picked.append(titles[i])
            else:
                base = titles[i % len(titles)]
                picked.append(f"{base} (Part {i // len(titles) + 1})")
        out[d] = picked

        # 用掉的从缓存里摘掉，下一批不重复
        remain = [t for t in titles if t not in picked]
        if remain:
            _cache_put(d, remain)
        else:
            _TITLE_CACHE.pop(d, None)
    return out


# ─────────────────────────────────────────────────────────────
# 链接池（promo_links 表）—— 这部分没有改动，只是原先和标题函数
# 混在同一个文件里，重写时被误删，现在补回来。
# ─────────────────────────────────────────────────────────────

def list_links(page_id: str = "", include_disabled: bool = False) -> list[dict]:
    """可用推广链接。全局链接（page_id 为空）对所有主页生效。"""
    from app.db import db
    try:
        sql = "SELECT * FROM promo_links WHERE 1=1"
        params: list = []
        if not include_disabled:
            sql += " AND enabled=1"
        sql += " ORDER BY weight DESC, used_count ASC"
        rows = db.q(sql, params) or []
        if page_id:
            own = [r for r in rows if (r.get("page_id") or "") == page_id]
            glob = [r for r in rows if not (r.get("page_id") or "")]
            return own + glob
        return rows
    except Exception as e:
        log.warning("读 promo_links 失败: %s", e)
        return []


def pick_link(page_id: str = "") -> dict | None:
    """按权重随机挑一条链接，优先用没怎么用过的。

    权重 weight 的意义：美国主链可以设成 3，备用链设成 1，
    这样 3:1 的概率分配到主链。
    """
    import random
    pool = list_links(page_id)
    if not pool:
        return None

    # 三重加权：weight 越大越容易被选；used_count 越小越优先
    weighted: list[dict] = []
    for r in pool:
        w = max(1, int(r.get("weight") or 1))
        used = int(r.get("used_count") or 0)
        # used 越多，权重衰减越快，保证轮转
        score = w * 100 // (1 + used)
        weighted.extend([r] * max(1, min(50, score // 10)))

    pick = random.choice(weighted if weighted else pool)
    return {
        "id": pick.get("id"),
        "url": (pick.get("url") or "").strip(),
        "label": pick.get("label") or "",
        "page_id": pick.get("page_id") or "",
    }


def mark_link_used(link_id: str) -> None:
    """标记链接用过（used_count +1），供权重轮转。"""
    from app.db import db, now_iso
    if not link_id:
        return
    try:
        db.exec(
            "UPDATE promo_links SET used_count=COALESCE(used_count,0)+1, "
            "last_used=? WHERE id=?", (now_iso(), link_id))
    except Exception as e:
        log.warning("标记链接已用失败: %s", e)


def reference_title() -> str:
    """当前参考标题（兼容旧调用）。"""
    return REFERENCE_TITLE


# ─────────────────────────────────────────────────────────────
# 兼容层：标题池已废弃，但有些旧调用还在引用这些函数名。
# 统一返回空/无害值，避免 AttributeError 把接口打成 500。
# ─────────────────────────────────────────────────────────────

def _attach_used_counts(items: list[dict]) -> list[dict]:
    """（兼容）标题不再落库，没有 used_count 概念，原样补 0。"""
    return [{**it, "used": int(it.get("used") or 0)} for it in (items or [])]


def list_title_pool(page_id: str = "", drama: str = "") -> list[dict]:
    """（兼容）标题池已废弃，恒返回空列表。"""
    return []


def pool_size(page_id: str = "", drama: str = "") -> int:
    """（兼容）标题池已废弃，恒返回 0。"""
    return 0


def pick_caption(page_id: str, ref: str = "", n: int = 5,
                 drama: str = "") -> dict:
    """（兼容）同步取一条标题。

    新代码请用 async 的 generate_for_drama / assign_batch_titles。
    这里给旧调用一个能用的兜底：有缓存就拿第一条，没有就用剧名。
    """
    cached = _cache_get((drama or "").strip())
    if cached:
        return {"title": cached[0], "source": "cache", "titleId": None}
    return {"title": (ref or drama or REFERENCE_TITLE),
            "source": "reference", "titleId": None}


def mark_title_used(title_id: str, kind: str = "") -> None:
    """（兼容）标题不再落库，无操作。"""
    return None


def save_titles(page_id: str, titles: list[str], ref: str = "",
                source: str = "") -> int:
    """（兼容）不再支持手动入库，返回 0。"""
    return 0


async def ensure_title_pool(page_id: str = "", ref: str = "",
                            want: int = 8, model_id: str = "",
                            drama: str = "") -> dict:
    """（兼容）改成按剧实时生成，不再落库。"""
    r = await generate_for_drama(drama or ref or "", want, model_id)
    return {"generated": len(r.get("titles") or []),
            "total": len(r.get("titles") or []),
            "source": r.get("source") or "model",
            "drama": drama, "reused": bool(r.get("cached"))}
