"""CDP 客户端：直连 Chromium DevTools，不依赖 Playwright。

为什么不用 Playwright：
    指纹浏览器内核是定制版 Chromium（152），Playwright 的 connectOverCDP 会注入
    自己的 Runtime 域命令，个别版本上会与定制内核冲突。这里只用最原始的
    WebSocket + Runtime.evaluate / Network.getAllCookies，兼容性最好。

能力：
    · cookie 读取（校验 c_user）
    · 页面 JS 执行（提取 DOM 里的主页列表）
    · 新开标签 / 关闭标签
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Any

import httpx
import websockets

log = logging.getLogger("yuhai.cdp")


class CDPError(RuntimeError):
    pass


class CDP:
    """一个 CDP 连接（一个浏览器 target）。"""

    def __init__(self, ws_url: str, timeout: float = 20.0) -> None:
        self.ws_url = ws_url
        self.timeout = timeout
        self._ws: Any = None
        self._id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._reader: asyncio.Task | None = None

    # ---------------- 生命周期 ----------------
    async def __aenter__(self) -> "CDP":
        await self.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def connect(self) -> None:
        self._ws = await websockets.connect(self.ws_url, max_size=64 * 1024 * 1024)
        self._reader = asyncio.create_task(self._read_loop())
    async def close(self) -> None:
        # 先关 ws（让 read_loop 自然结束），再 cancel，避免 CancelledError 冒泡
        ws = self._ws
        self._ws = None
        if ws is not None:
            try:
                await ws.close()
            except Exception:
                pass
        task = self._reader
        self._reader = None
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        for fut in self._pending.values():
            if not fut.done():
                fut.cancel()
        self._pending.clear()

    async def _read_loop(self) -> None:
        ws = self._ws
        if ws is None:
            return
        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except Exception:
                    continue
                mid = msg.get("id")
                if mid is not None and mid in self._pending:
                    fut = self._pending.pop(mid)
                    if not fut.done():
                        if "error" in msg:
                            fut.set_exception(CDPError(str(msg["error"])))
                        else:
                            fut.set_result(msg.get("result") or {})
        except asyncio.CancelledError:
            return
        except Exception as e:
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(CDPError(f"ws closed: {e}"))
            self._pending.clear()

    async def send(self, method: str, params: dict | None = None,
                   timeout: float | None = None) -> dict:
        if self._ws is None:
            raise CDPError("not connected")
        self._id += 1
        mid = self._id
        fut = asyncio.get_running_loop().create_future()
        self._pending[mid] = fut
        await self._ws.send(json.dumps({"id": mid, "method": method,
                                        "params": params or {}}))
        try:
            return await asyncio.wait_for(fut, timeout or self.timeout)
        except asyncio.TimeoutError as e:
            self._pending.pop(mid, None)
            raise CDPError(f"{method} timeout") from e

    # ---------------- 高层 ----------------
    async def eval(self, expr: str, await_promise: bool = True,
                   timeout: float | None = None) -> Any:
        res = await self.send("Runtime.evaluate", {
            "expression": expr,
            "returnByValue": True,
            "awaitPromise": await_promise,
            "userGesture": True,
        }, timeout=timeout)
        if res.get("exceptionDetails"):
            det = res["exceptionDetails"]
            raise CDPError(str(det.get("text") or det.get("exception", {}).get("description"))[:400])
        return (res.get("result") or {}).get("value")

    async def cookies(self, url: str | None = None) -> list[dict]:
        params = {"urls": [url]} if url else {}
        try:
            res = await self.send("Network.getAllCookies", params)
        except CDPError:
            # 部分定制内核需要先 enable
            try:
                await self.send("Network.enable")
            except CDPError:
                pass
            res = await self.send("Network.getAllCookies", params)
        return res.get("cookies") or []

    async def get_cookie(self, name: str, domain_hint: str = "facebook") -> str | None:
        cookies = await self.cookies()
        for c in cookies:
            if c.get("name") == name and domain_hint in (c.get("domain") or ""):
                return c.get("value")
        return None

    async def get_fb_identity(self) -> str | None:
        """取 facebook.com 域下的 c_user（先 getAllCookies，失败退 Storage.getCookies）。"""
        for method in ("Network.getAllCookies", "Storage.getCookies"):
            try:
                res = await self.send(method)
            except CDPError:
                continue
            for c in res.get("cookies") or []:
                dom = c.get("domain") or ""
                if c.get("name") == "c_user" and "facebook" in dom:
                    return c.get("value")
        return None

    async def navigate(self, url: str, wait_ms: int = 6000) -> None:
        await self.send("Page.enable")
        await self.send("Page.navigate", {"url": url})
        await asyncio.sleep(wait_ms / 1000)


# ---------------- 浏览器级 ----------------
class Browser:
    """一个 CDP 浏览器实例（/devtools/browser/...）。可开新标签。"""

    def __init__(self, port: int, timeout: float = 20.0) -> None:
        self.port = port
        self.timeout = timeout
        self.ws_url = ""
        self.browser_name = ""

    async def __aenter__(self) -> "Browser":
        await self.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        pass

    async def connect(self) -> None:
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.get(f"http://127.0.0.1:{self.port}/json/version")
        if r.status_code != 200:
            raise CDPError(f"CDP {self.port} not reachable")
        d = r.json()
        self.ws_url = d.get("webSocketDebuggerUrl") or ""
        self.browser_name = d.get("Browser") or ""
        if not self.ws_url:
            raise CDPError("no webSocketDebuggerUrl")

    async def targets(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.get(f"http://127.0.0.1:{self.port}/json/list")
        return r.json() if r.status_code == 200 else []

    async def new_page(self, url: str = "about:blank") -> "Page":
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.put(f"http://127.0.0.1:{self.port}/json/new?{url}")
            if r.status_code != 200:
                r = await c.get(f"http://127.0.0.1:{self.port}/json/new?{url}")
        d = r.json()
        ws = d.get("webSocketDebuggerUrl")
        if not ws:
            raise CDPError("cannot create page")
        pg = Page(ws, self.timeout)
        await pg.connect()
        return pg


class Page(CDP):
    """一个具体标签页。"""

    async def goto(self, url: str, wait_until_loaded: float = 8.0) -> None:
        await self.send("Page.enable")
        await self.send("Runtime.enable")
        await self.send("Page.navigate", {"url": url})
        await asyncio.sleep(wait_until_loaded)

    async def wait_text(self, contains: str, timeout: float = 30.0,
                        interval: float = 1.0) -> bool:
        end = time.time() + timeout
        while time.time() < end:
            try:
                body = await self.eval("document.body?document.body.innerText:''")
                if contains in (body or ""):
                    return True
            except CDPError:
                pass
            await asyncio.sleep(interval)
        return False

    async def inner_text(self) -> str:
        return (await self.eval("document.body?document.body.innerText:''")) or ""

    async def html(self) -> str:
        return (await self.eval("document.documentElement.outerHTML")) or ""

    async def click_text(self, text: str, exact: bool = False) -> bool:
        expr = r"""
        (() => {
          const want = %s, exact = %s;
          const els = Array.from(document.querySelectorAll('*'));
          for (const el of els) {
            const t = (el.innerText || '').trim();
            const hit = exact ? (t === want) : t.includes(want);
            if (!hit) continue;
            if (el.children.length > 2) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) continue;
            el.click();
            return true;
          }
          return false;
        })()
        """ % (json.dumps(text), "true" if exact else "false")
        return bool(await self.eval(expr))
