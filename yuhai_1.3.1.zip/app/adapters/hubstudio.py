"""Hubstudio 指纹浏览器适配层。

实测过的接口（2026-11 Hubstudio 桌面版）：
    POST /api/v1/browser/all-browser-status   {}                  -> 已开环境 + pid
    POST /api/v1/browser/start                {"containerCode":…} -> 含 debuggingPort
    POST /api/v1/browser/stop                 {"containerCode":…}
    POST /api/v1/env/list                     {}                  -> 环境清单

PID → CDP 端口：
    先按 pid 找监听端口（psutil），再逐个 GET /json/version 确认 Browser 含 "Chrom"。
    这一步不能用「Guess 端口范围」，环境重启后端口会变。

环境信息（账号 / 代理 / profile 目录）从 env/list 拿；登录态用 CDP 读 cookie 校验。
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import sqlite3
import tempfile
import shutil
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import httpx
import psutil

from app.config import settings

log = logging.getLogger("yuhai.hubstudio")


@dataclass
class EnvInfo:
    container_code: str
    container_id: str = ""
    name: str = ""
    role: str = "spare"
    account: str = ""
    c_user: str = ""
    display_name: str = ""
    profile_dir: str = ""
    proxy_type: str = ""
    proxy_host: str = ""
    proxy_port: int = 0
    proxy_kind: str = ""
    status: str = "closed"
    pid: int = 0
    cdp_port: int = 0
    egress_ip: str = ""
    egress_country: str = ""
    kernel: str = ""
    login_valid: int | None = None
    last_checked: str = ""
    raw: dict = field(default_factory=dict)


class HubstudioError(RuntimeError):
    pass


class Hubstudio:
    def __init__(self, base: str | None = None) -> None:
        self.base = (base or settings.hubstudio_api).rstrip("/")

    # ---------------- 低层 ----------------
    async def _post(self, path: str, body: dict | None = None, timeout: float = 20.0) -> dict:
        url = f"{self.base}{path}"
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.post(url, json=body or {})
        except httpx.ConnectError as e:
            raise HubstudioError(f"Hubstudio 未启动或端口不通: {url}") from e
        except httpx.TimeoutException as e:
            raise HubstudioError(f"Hubstudio 接口超时: {path}") from e
        if r.status_code != 200:
            raise HubstudioError(f"Hubstudio {path} HTTP {r.status_code}")
        try:
            data = r.json()
        except Exception as e:
            raise HubstudioError(f"Hubstudio {path} 返回非 JSON") from e
        if str(data.get("code")) not in ("0", "200"):
            raise HubstudioError(f"Hubstudio {path} 失败: {data.get('msg')} ({data.get('code')})")
        return data

    # ---------------- 状态 ----------------
    async def status(self) -> dict[str, dict]:
        """返回 {containerCode: {status, pid}}"""
        data = await self._post("/api/v1/browser/all-browser-status")
        out: dict[str, dict] = {}
        for c in (data.get("data") or {}).get("containers") or []:
            code = str(c.get("containerCode") or "")
            if not code:
                continue
            out[code] = {
                "status": "running" if int(c.get("pid") or 0) else "closed",
                "pid": int(c.get("pid") or 0),
            }
        return out

    async def env_list(self) -> list[dict]:
        data = await self._post("/api/v1/env/list")
        return list((data.get("data") or {}).get("list") or [])

    # ---------------- 生命周期 ----------------
    async def start(self, container_code: str) -> dict:
        data = await self._post("/api/v1/browser/start",
                                {"containerCode": container_code}, timeout=120)
        d = data.get("data") or {}
        log.info("start %s -> port=%s pid=%s", container_code,
                 d.get("debuggingPort"), d.get("containerId"))
        return d

    async def stop(self, container_code: str) -> dict:
        data = await self._post("/api/v1/browser/stop", {"containerCode": container_code})
        return data

    # ---------------- 环境增删 ----------------
    async def create_env(self, name: str, proxy_type: str = "Socks5",
                         proxy_server: str = "", proxy_port: int = 0,
                         proxy_account: str = "", proxy_password: str = "",
                         remark: str = "") -> dict:
        """创建环境。

        实测字段名（Hubstudio 用 proxyServer，不是 proxyHost）：
            containerName   环境名（必填）
            proxyTypeName   Socks5 / SOCKS5 / http / https
            proxyServer     代理主机（必填，否则 E110076）
            proxyPort       端口
            proxyAccount / proxyPassword
        返回 {code, msg, data:{containerCode}}
        """
        if not name.strip():
            raise HubstudioError("环境名不能为空")
        if not proxy_server.strip():
            raise HubstudioError("代理主机不能为空（Hubstudio 必填）")
        body = {
            "containerName": name.strip(),
            "proxyTypeName": proxy_type or "Socks5",
            "proxyServer": proxy_server.strip(),
            "proxyPort": int(proxy_port or 0),
        }
        if proxy_account:
            body["proxyAccount"] = proxy_account
        if proxy_password:
            body["proxyPassword"] = proxy_password
        if remark:
            body["remark"] = remark
        data = await self._post("/api/v1/env/create", body, timeout=40.0)
        code = str(data.get("code") or "")
        if code not in ("0", "success", ""):
            raise HubstudioError(f"{code}: {data.get('msg') or '创建失败'}")
        return data

    async def delete_env(self, container_codes: list[str | int]) -> dict:
        """删除环境（一次可传多个）。实测路径是 /api/v1/env/del。"""
        if not container_codes:
            raise HubstudioError("containerCodes 为空")
        codes = [int(c) if str(c).isdigit() else c for c in container_codes]
        data = await self._post("/api/v1/env/del", {"containerCodes": codes},
                                timeout=40.0)
        code = str(data.get("code") or "")
        if code not in ("0", "success", ""):
            raise HubstudioError(f"{code}: {data.get('msg') or '删除失败'}")
        return data

    async def modify_env(self, container_code: str, **fields) -> dict:
        """改环境（代理、名称等）。字段名同 create。"""
        body = {"containerCode": container_code, **fields}
        data = await self._post("/api/v1/env/modify", body, timeout=30.0)
        code = str(data.get("code") or "")
        if code not in ("0", "success", ""):
            raise HubstudioError(f"{code}: {data.get('msg') or '修改失败'}")
        return data

    async def version(self) -> dict:
        """探测 Hubstudio 版本与 API 可用性（判断升级后是否还连得上）。"""
        out = {"apiOk": False, "envListOk": False, "statusOk": False,
               "createOk": None, "delOk": None, "envCount": 0,
               "error": None}
        try:
            envs = await self.env_list()
            out["apiOk"] = True
            out["envListOk"] = True
            out["envCount"] = len(envs)
        except Exception as e:
            out["error"] = f"env/list 失败: {e}"
            return out
        try:
            await self.status()
            out["statusOk"] = True
        except Exception as e:
            out["error"] = f"status 失败: {e}"
        # 探测写接口是否存在（不实际创建，只看路径是否可用）
        for path, key in (("/api/v1/env/create", "createOk"),
                          ("/api/v1/env/del", "delOk")):
            try:
                d = await self._post(path, {}, timeout=10.0)
                code = str(d.get("code") or "")
                # E010006 = 路径不存在；其它错误码说明接口在
                out[key] = code != "E010006"
            except Exception:
                out[key] = None
        return out

    # ---------------- PID → CDP ----------------
    @staticmethod
    def listening_ports(pid: int) -> list[int]:
        ports: list[int] = []
        try:
            proc = psutil.Process(pid)
            for c in proc.net_connections(kind="inet"):
                if c.status == psutil.CONN_LISTEN and c.laddr:
                    ports.append(int(c.laddr.port))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return []
        # 子进程也要找（Chromium 主进程可能不是监听者）
        try:
            for child in psutil.Process(pid).children(recursive=True):
                try:
                    for c in child.net_connections(kind="inet"):
                        if c.status == psutil.CONN_LISTEN and c.laddr:
                            ports.append(int(c.laddr.port))
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        return sorted(set(ports))

    @staticmethod
    async def probe_cdp(port: int, timeout: float = 3.0) -> dict | None:
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.get(f"http://127.0.0.1:{port}/json/version")
            if r.status_code != 200:
                return None
            d = r.json()
            if "Chrom" in (d.get("Browser") or ""):
                return {"port": port, **d}
        except Exception:
            return None
        return None

    async def resolve_cdp(self, pid: int, hint_port: int = 0) -> dict | None:
        """PID → {port, Browser, webSocketDebuggerUrl}"""
        if hint_port:
            hit = await self.probe_cdp(hint_port)
            if hit:
                return hit
        for p in self.listening_ports(pid):
            hit = await self.probe_cdp(p)
            if hit:
                return hit
        return None

    async def find_env_by_pid(self, pid: int) -> dict | None:
        st = await self.status()
        for code, info in st.items():
            if info.get("pid") == pid:
                return {"container_code": code, **info}
        return None

    # ---------------- 本地 profile 读取（仅登录邮箱，不碰密码） ----------------
    @staticmethod
    def hubstudio_cache_root() -> Path:
        appdata = os.environ.get("APPDATA") or str(Path.home() / "AppData/Roaming")
        return Path(appdata) / "hubstudio-client" / "sdk" / "cache"

    def read_login_emails(self, profile_dir: str) -> list[str]:
        """从 Login Data 读已保存的登录邮箱（username_value 是明文）。"""
        root = self.hubstudio_cache_root()
        p = root / profile_dir / "Default" / "Login Data"
        if not p.exists():
            return []
        tmp = Path(tempfile.gettempdir()) / f"ld_{abs(hash(profile_dir))}.db"
        try:
            shutil.copy2(p, tmp)
            con = sqlite3.connect(str(tmp))
            rows = con.execute(
                "SELECT origin_url, username_value FROM logins WHERE origin_url LIKE '%facebook%'"
            ).fetchall()
            con.close()
            return [u for _, u in rows if u]
        except Exception as e:
            log.debug("read login data failed: %s", e)
            return []
        finally:
            try:
                tmp.unlink()
            except Exception:
                pass

    # ---------------- 汇总 ----------------
    async def collect(self) -> list[EnvInfo]:
        """合并 env/list + all-browser-status，产出完整环境列表。"""
        envs_raw = await self.env_list()
        try:
            st = await self.status()
        except HubstudioError:
            st = {}

        out: list[EnvInfo] = []
        for e in envs_raw:
            code = str(e.get("containerCode") or "")
            if not code:
                continue
            info = EnvInfo(
                container_code=code,
                container_id=str(e.get("containerId") or code),
                name=e.get("containerName") or code,
                proxy_type=(e.get("proxyTypeName") or "").upper(),
                proxy_host=e.get("proxyHost") or "",
                proxy_port=int(e.get("proxyPort") or 0),
                raw=e,
            )
            s = st.get(code)
            if s:
                info.status = s["status"]
                info.pid = s["pid"]
            out.append(info)
        return out


hub = Hubstudio()


# ---------------- 环境信息补全 ----------------
_PUB = settings.fb_publisher_cuser
_BAK = settings.fb_backup_cuser


def classify_role(email: str, name: str) -> str:
    if email and email.startswith("m19897410232"):
        return "publisher"
    if email and email.startswith("haiyu325355"):
        return "backup"
    if "网易" in name:
        return "publisher"
    if "谷歌" in name:
        return "backup"
    return "spare"


async def enrich(info: EnvInfo) -> EnvInfo:
    """用本地 profile + CDP 把账号、登录态、CDP 端口、内核补上。"""
    # 1) profile 目录
    root = hub.hubstudio_cache_root()
    if info.container_id and root.exists():
        cand = root / f"chromium_{info.container_id}"
        if cand.exists():
            info.profile_dir = cand.name
    if not info.profile_dir and root.exists():
        for d in root.iterdir():
            if d.is_dir() and d.name.startswith("chromium_"):
                ld = d / "Default" / "Login Data"
                if ld.exists():
                    emails = hub.read_login_emails(d.name)
                    if emails and info.account and emails[0] == info.account:
                        info.profile_dir = d.name
                        break

    # 2) 登录邮箱
    if info.profile_dir:
        emails = hub.read_login_emails(info.profile_dir)
        if emails:
            info.account = emails[0]

    info.role = classify_role(info.account, info.name)

    # 3) 运行中 → CDP + 内核 + c_user
    if info.status == "running" and info.pid:
        cdp = await hub.resolve_cdp(info.pid, info.cdp_port)
        if cdp:
            info.cdp_port = cdp["port"]
            info.kernel = cdp.get("Browser") or ""
            info.login_valid = 1
    return info


async def dump_to_db(infos: list[EnvInfo]) -> int:
    from app.db import db, now_iso
    ts = now_iso()
    n = 0
    for i in infos:
        db.exec(
            """INSERT INTO envs(container_code,container_id,name,role,account,c_user,
                    display_name,profile_dir,proxy_type,proxy_host,proxy_port,proxy_kind,
                    status,pid,cdp_port,egress_ip,egress_country,kernel,login_valid,
                    last_checked,raw,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(container_code) DO UPDATE SET
                    container_id=excluded.container_id, name=excluded.name,
                    role=excluded.role, account=excluded.account, c_user=excluded.c_user,
                    display_name=excluded.display_name, profile_dir=excluded.profile_dir,
                    proxy_type=excluded.proxy_type, proxy_host=excluded.proxy_host,
                    proxy_port=excluded.proxy_port, proxy_kind=excluded.proxy_kind,
                    status=excluded.status, pid=excluded.pid, cdp_port=excluded.cdp_port,
                    egress_ip=excluded.egress_ip, egress_country=excluded.egress_country,
                    kernel=excluded.kernel, login_valid=excluded.login_valid,
                    last_checked=excluded.last_checked, raw=excluded.raw,
                    updated_at=excluded.updated_at""",
            (i.container_code, i.container_id, i.name, i.role, i.account, i.c_user,
             i.display_name, i.profile_dir, i.proxy_type, i.proxy_host, i.proxy_port,
             i.proxy_kind, i.status, i.pid or None, i.cdp_port or None,
             i.egress_ip, i.egress_country, i.kernel,
             i.login_valid if i.login_valid is not None else None,
             i.last_checked, json.dumps(i.raw, ensure_ascii=False), ts),
        )
        n += 1
    return n
