"""插播：把 FB.list_roles 升级为返回带 c_user 的成员（授权判定必须靠 ID，不能靠名字）。"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any

from app.adapters.cdp import CDPError

log = logging.getLogger("yuhai.fb.roles")

# 从权限页里抽成员：优先内嵌 JSON 的 profile id，其次 DOM 上的 profile 链接
ROLES_JS = r"""
(() => {
  const out = [];
  const seen = new Set();
  const push = (name, uid, level) => {
    const key = uid || name;
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push({ name: (name||'').trim().slice(0,60), c_user: uid||null, level: level||null });
  };

  // 1) 权限行：名字 + 右侧「自定义 / 完全控制权」
  const rows = Array.from(document.querySelectorAll('div[role="row"], div[role="listitem"], li'));
  for (const row of rows) {
    const t = (row.innerText || '');
    if (!t || t.length > 400) continue;
    if (!/自定义|完全控制|部分控制|管理员|编辑/.test(t)) continue;
    const lines = t.split('\n').map(s=>s.trim()).filter(Boolean);
    const name = lines[0] || '';
    if (!name || name.length > 40) continue;
    const level = /完全控制/.test(t) ? 'full' : /部分控制/.test(t) ? 'partial' : 'custom';
    // 行内链接里找 profile id
    let uid = null;
    const a = row.querySelector('a[href*="profile.php?id="]');
    if (a) {
      const m = (a.getAttribute('href')||'').match(/profile\.php\?id=(\d{8,})/);
      if (m) uid = m[1];
    }
    push(name, uid, level);
  }

  // 2) 内嵌 JSON：{...,"name":"Hai Yu",...,"id":"61595095770895",...}
  const html = document.documentElement.innerHTML;
  const re = /\{"[^{}]{0,80}?"(?:name|display_name)":"([^"]{1,60})"[^{}]{0,300}?"id":"(\d{8,})"/g;
  let m;
  while ((m = re.exec(html))) push(m[1], m[2], null);

  return out;
})()
"""


async def list_roles_with_ids(page, asset_id: str) -> list[dict]:
    """读取主页权限列表，返回 [{name, c_user, level}]。"""
    await page.goto(f"https://business.facebook.com/latest/settings/page_roles?asset_id={asset_id}",
                    wait_until_loaded=9.0)
    # 权限页有懒加载，滚动两次
    for _ in range(2):
        await page.eval("window.scrollBy(0, window.innerHeight)")
        await asyncio.sleep(0.8)
    data = await page.eval(ROLES_JS)
    return data or []
