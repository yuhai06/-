"""IMAP 适配：多邮箱并行拉取 + 验证码提取。

已知坑（163）：
    SELECT INBOX 前必须先发 ID 命令，否则
    server responds: command SEARCH illegal in state AUTH
"""
from __future__ import annotations

import email
import imaplib
import logging
import re
import socket
import ssl
from dataclasses import dataclass
from datetime import datetime, timedelta
from email.header import decode_header
from email.utils import parsedate_to_datetime
from typing import Any

from imapclient import IMAPClient

log = logging.getLogger("yuhai.mail.imap")

CODE_RE = re.compile(r"\b(\d{6,8})\b")

PRESETS = {
    "163":  {"host": "imap.163.com", "port": 993, "need_id": True},
    "126":  {"host": "imap.126.com", "port": 993, "need_id": True},
    "qq":   {"host": "imap.qq.com", "port": 993, "need_id": True},
    "gmail": {"host": "imap.gmail.com", "port": 993, "need_id": False},
    "outlook": {"host": "outlook.office365.com", "port": 993, "need_id": False},
    "yahoo": {"host": "imap.mail.yahoo.com", "port": 993, "need_id": False},
}

# 163/126 必须的 ID 命令
ID_CMD = {
    "name": "YuhaiWorkbench",
    "version": "1.0.0",
    "vendor": "local",
    "support-email": "local@localhost",
}


def guess_provider(address: str) -> str:
    dom = address.split("@")[-1].lower() if "@" in address else ""
    if "163" in dom:
        return "163"
    if "126" in dom:
        return "126"
    if "qq" in dom:
        return "qq"
    if "gmail" in dom:
        return "gmail"
    if "outlook" in dom or "hotmail" in dom or "live" in dom:
        return "outlook"
    if "yahoo" in dom:
        return "yahoo"
    return ""


def _decode(s: Any) -> str:
    if not s:
        return ""
    out = []
    for part, enc in decode_header(str(s)):
        if isinstance(part, bytes):
            try:
                out.append(part.decode(enc or "utf-8", errors="replace"))
            except Exception:
                out.append(part.decode("utf-8", errors="replace"))
        else:
            out.append(part)
    return "".join(out)


def _body_text(msg: email.message.Message, limit: int = 20000) -> str:
    chunks: list[str] = []
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_maintype() == "multipart":
                continue
            ctype = part.get_content_type()
            if ctype not in ("text/plain", "text/html"):
                continue
            try:
                payload = part.get_payload(decode=True) or b""
                cs = part.get_content_charset() or "utf-8"
                chunks.append(payload.decode(cs, errors="replace"))
            except Exception:
                continue
    else:
        try:
            payload = msg.get_payload(decode=True) or b""
            cs = msg.get_content_charset() or "utf-8"
            chunks.append(payload.decode(cs, errors="replace"))
        except Exception:
            pass
    text = "\n".join(chunks)
    # 去 HTML 标签
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&nbsp;?", " ", text)
    text = re.sub(r"&amp;?", "&", text)
    text = re.sub(r"[ \t]+", " ", text)
    return text[:limit]


def extract_code(text: str) -> str | None:
    """从主题+正文里提验证码。优先「验证码/安全码/确认码」附近的 6-8 位数字。"""
    if not text:
        return None
    for kw in ("验证码", "安全码", "确认码", "verification code", "security code",
               "your code", "code is", "码"):
        m = re.search(kw + r"[^\d]{0,24}(\d{6,8})", text, re.I)
        if m:
            return m.group(1)
    m = CODE_RE.search(text)
    return m.group(1) if m else None


@dataclass
class FetchedMail:
    uid: str
    mailbox: str
    sender: str
    subject: str
    body: str
    code: str | None
    received_at: str


class ImapClient:
    def __init__(self, host: str, port: int, user: str, password: str,
                 need_id: bool = False, ssl_mode: bool = True) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.need_id = need_id
        self.ssl_mode = ssl_mode

    def _connect(self) -> IMAPClient:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        c = IMAPClient(self.host, port=self.port, ssl=self.ssl_mode, ssl_context=ctx,
                       timeout=25)
        try:
            c.login(self.user, self.password)
        except Exception as e:
            raise RuntimeError(f"IMAP 登录失败: {str(e)[:120]}")
        if self.need_id:
            try:
                # 163 必须发 ID，否则 SEARCH 报 illegal in state AUTH
                c._imap._simple_command("ID", '("name" "YuhaiWorkbench" '
                                              '"version" "1.0.0" "vendor" "local")')
                c._imap._untagged_response("OK", [b"ID"], b"ID")
            except Exception as e:
                log.debug("ID command failed (may be unnecessary): %s", e)
        return c

    def fetch(self, since_minutes: int = 1440, limit: int = 30,
              mailbox: str = "INBOX") -> list[FetchedMail]:
        out: list[FetchedMail] = []
        c = self._connect()
        try:
            c.select_folder(mailbox, readonly=True)
            since = datetime.now() - timedelta(minutes=since_minutes)
            uids = c.search(["SINCE", since.strftime("%d-%b-%Y")])
            if not uids:
                return []
            uids = uids[-limit:]
            data = c.fetch(uids, ["RFC822", "INTERNALDATE"])
            for uid, d in data.items():
                raw = d.get(b"RFC822")
                if not raw:
                    continue
                msg = email.message_from_bytes(raw)
                subject = _decode(msg.get("Subject"))
                sender = _decode(msg.get("From"))
                body = _body_text(msg)
                code = extract_code(subject + "\n" + body)
                try:
                    dt = parsedate_to_datetime(msg.get("Date"))
                    ts = dt.astimezone().isoformat(timespec="seconds")
                except Exception:
                    idt = d.get(b"INTERNALDATE")
                    ts = idt.isoformat() if hasattr(idt, "isoformat") else datetime.now().isoformat()
                out.append(FetchedMail(uid=str(uid), mailbox=self.user, sender=sender,
                                       subject=subject, body=body, code=code,
                                       received_at=ts))
        finally:
            try:
                c.logout()
            except Exception:
                pass
        return out

    def test(self) -> dict:
        try:
            c = self._connect()
            try:
                info = c.select_folder("INBOX", readonly=True)
                total = int(info.get(b"EXISTS") or 0)
            finally:
                c.logout()
            return {"ok": True, "messages": total, "user": self.user}
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}


def build_client(cfg: dict) -> ImapClient:
    addr = cfg.get("user") or cfg.get("address") or ""
    prov = cfg.get("provider") or guess_provider(addr)
    preset = PRESETS.get(prov, {})
    host = cfg.get("host") or preset.get("host") or f"imap.{addr.split('@')[-1]}"
    port = int(cfg.get("port") or preset.get("port") or 993)
    need_id = bool(cfg.get("needId", preset.get("need_id", False)))
    return ImapClient(host, port, addr, cfg.get("password") or "",
                      need_id=need_id)
