"""反自动化检测：拟人化交互原语。

为什么需要这一层：
    FB 的自动化识别不只看 navigator.webdriver，还看**行为特征**：
      · 点击坐标瞬移（无鼠标轨迹）
      · 固定间隔的机械操作
      · 页面加载后立刻操作（无阅读停顿）
      · 滚动是整数步长而非惯性
      · 同一秒内多个请求

本模块只做一件事：把「机器节奏」换成「人类节奏」。
所有平台操作必须经过这里，不允许直接 send 点击/滚动。
"""
from __future__ import annotations

import asyncio
import math
import random
import time
from dataclasses import dataclass
from typing import Any

# ---------------- 节奏参数（按 FB 实测调过） ----------------
# 单步操作间隔：太快像脚本，太慢效率低
OP_DELAY = (0.35, 1.4)
# 阅读停顿：页面加载完到开始操作
READ_DELAY = (1.8, 4.5)
# 页面之间的切换间隔
NAV_DELAY = (3.0, 7.0)
# 同一账号连续操作的最小间隔
BURST_GAP = (2.5, 6.0)
# 每 N 次操作强制一次长休息
LONG_REST_EVERY = 12
LONG_REST = (18.0, 45.0)


def jitter(a: float, b: float) -> float:
    """区间内随机，偏向中值（三角分布），比均匀分布更像人。"""
    return random.triangular(a, b, (a + b) / 2)


async def human_delay(kind: str = "op") -> float:
    """按类型 sleep 一段拟人时长，返回实际睡了多久。"""
    table = {
        "op": OP_DELAY,
        "read": READ_DELAY,
        "nav": NAV_DELAY,
        "burst": BURST_GAP,
        "rest": LONG_REST,
    }
    lo, hi = table.get(kind, OP_DELAY)
    d = jitter(lo, hi)
    await asyncio.sleep(d)
    return d


# ---------------- 鼠标轨迹 ----------------
# 三次贝塞尔 + 微抖动，模拟手抖与加速度
def bezier_points(x0: float, y0: float, x1: float, y1: float,
                  steps: int = 0) -> list[tuple[float, float]]:
    if steps <= 0:
        dist = math.hypot(x1 - x0, y1 - y0)
        # 距离越远步数越多，但封顶
        steps = max(12, min(48, int(dist / 18)))
    # 控制点：偏离直线，制造弧线
    dx, dy = x1 - x0, y1 - y0
    perp = (-dy, dx)
    n = math.hypot(*perp) or 1
    perp = (perp[0] / n, perp[1] / n)
    bow = random.uniform(0.08, 0.26) * math.hypot(dx, dy)
    cx = (x0 + x1) / 2 + perp[0] * bow
    cy = (y0 + y1) / 2 + perp[1] * bow

    pts = []
    for i in range(steps + 1):
        t = i / steps
        # ease-out：先快后慢，落点更稳
        e = 1 - (1 - t) ** 2
        bx = (1 - e) ** 2 * x0 + 2 * (1 - e) * e * cx + e ** 2 * x1
        by = (1 - e) ** 2 * y0 + 2 * (1 - e) * e * cy + e ** 2 * y1
        # 手抖
        bx += random.uniform(-0.8, 0.8)
        by += random.uniform(-0.8, 0.8)
        pts.append((bx, by))
    return pts


async def move_mouse(page: Any, x: float, y: float,
                     from_xy: tuple[float, float] | None = None) -> None:
    """把鼠标从当前位置沿曲线移到 (x, y)。"""
    sx, sy = from_xy or (random.uniform(120, 900), random.uniform(120, 600))
    for bx, by in bezier_points(sx, sy, x, y):
        try:
            await page.send("Input.dispatchMouseEvent", {
                "type": "mouseMoved", "x": round(bx, 1), "y": round(by, 1),
                "buttons": 0})
        except Exception:
            break
        await asyncio.sleep(random.uniform(0.006, 0.022))


async def human_click(page: Any, x: float, y: float,
                      from_xy: tuple[float, float] | None = None) -> None:
    """曲线移动 → 悬停 → 按下 → 抬起。"""
    await move_mouse(page, x, y, from_xy)
    await asyncio.sleep(random.uniform(0.08, 0.3))     # 落点悬停
    try:
        await page.send("Input.dispatchMouseEvent", {
            "type": "mousePressed", "x": round(x, 1), "y": round(y, 1),
            "button": "left", "clickCount": 1, "buttons": 1})
        await asyncio.sleep(random.uniform(0.05, 0.14))  # 按压时长
        await page.send("Input.dispatchMouseEvent", {
            "type": "mouseReleased", "x": round(x, 1), "y": round(y, 1),
            "button": "left", "clickCount": 1, "buttons": 0})
    except Exception:
        pass


async def human_click_el(page: Any, selector: str) -> bool:
    """按选择器点击：先取元素中心，再走曲线点击。"""
    pos = await page.eval(f"""
    (() => {{
      const el = document.querySelector({selector!r});
      if (!el) return null;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return null;
      return {{x: r.x + r.width/2 + (Math.random()-0.5)*6,
               y: r.y + r.height/2 + (Math.random()-0.5)*6}};
    }})()
    """)
    if not pos:
        return False
    await human_click(page, pos["x"], pos["y"])
    return True


# ---------------- 滚动 ----------------
async def human_scroll(page: Any, total_px: int | None = None,
                       direction: str = "down") -> None:
    """惯性滚动：分多段，每段距离递减，段间有停顿。"""
    remain = total_px or random.randint(400, 1100)
    sign = 1 if direction == "down" else -1
    while remain > 0:
        step = min(remain, random.randint(90, 260))
        await page.eval(f"window.scrollBy(0, {sign * step})")
        remain -= step
        await asyncio.sleep(random.uniform(0.05, 0.18))
        if random.random() < 0.22:
            await asyncio.sleep(random.uniform(0.3, 0.9))   # 停顿看内容


async def human_scroll_until_stable(page: Any, rounds: int = 25) -> int:
    """滚到底直到不再增长，返回滚动次数。"""
    last = -1
    n = 0
    for i in range(rounds):
        h = await page.eval("document.body ? document.body.scrollHeight : 0") or 0
        if h == last:
            break
        last = h
        await human_scroll(page)
        n += 1
        await asyncio.sleep(jitter(0.4, 1.1))
    return n


# ---------------- 打字 ----------------
async def human_type(page: Any, text: str) -> None:
    """逐字输入，带偶发停顿与快慢变化。"""
    for ch in text:
        await page.send("Input.insertText", {"text": ch})
        base = random.uniform(0.045, 0.16)
        if ch in " ,.，。":
            base += random.uniform(0.05, 0.2)
        await asyncio.sleep(base)


# ---------------- 节奏节流器 ----------------
@dataclass
class PaceState:
    ops: int = 0
    last_ts: float = 0.0


class Pacer:
    """每个环境一个节流器：保证不会出现机械式高频操作。"""

    def __init__(self) -> None:
        self.state: dict[str, PaceState] = {}

    async def wait(self, key: str) -> None:
        st = self.state.setdefault(key, PaceState())
        now = time.time()
        if st.last_ts:
            gap = jitter(*BURST_GAP)
            elapsed = now - st.last_ts
            if elapsed < gap:
                await asyncio.sleep(gap - elapsed)
        st.ops += 1
        if st.ops % LONG_REST_EVERY == 0:
            await asyncio.sleep(jitter(*LONG_REST))
        st.last_ts = time.time()

    def reset(self, key: str) -> None:
        self.state.pop(key, None)


pacer = Pacer()
