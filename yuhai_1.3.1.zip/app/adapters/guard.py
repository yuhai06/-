"""风控检测层：识别「跳脸」信号，命中即熔断并告警。

「跳脸」在 FB 上有明确的页面特征，本项目把它们归成 6 类：
    1. checkpoint      —— 要求验证身份 / 上传证件 / 自拍
    2. captcha         —— reCAPTCHA / Arkose 挑战
    3. action_block    —— 「你暂时无法执行此操作」/「操作过于频繁」
    4. session_verify  —— 「请确认是你本人」/ 新设备验证
    5. rate_limit      —— 「你已达到上限」/ 稍后再试
    6. suspicious      —— 「我们发现异常活动」

设计原则：
    · 只在**页面文本/URL 已稳定**后判定，避免误报
    · 命中即返回结构化信号，由调用方决定熔断粒度（单页 / 单号 / 全局）
    · 任何一次命中都要落库 + 告警，不允许静默继续
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.guard")

# ---------------- 签名库 ----------------
# (类别, 严重度, 中文说明, 正则)
SIGNATURES: list[tuple[str, str, str, re.Pattern]] = [
    ("checkpoint", "critical", "账号被要求身份验证（checkpoint）",
     re.compile(r"确认你的身份|上传.{0,6}身份证|请输入.{0,4}验证码以继续|"
                r"confirm your identity|we need to confirm it'?s you", re.I)),
    ("captcha", "critical", "出现人机验证（CAPTCHA）",
     re.compile(r"进行人机身份验证|我不是机器人|选择所有包含|"
                r"security check|verify you'?re human|arkose|funcaptcha", re.I)),
    ("action_block", "critical", "操作被阻止",
     re.compile(r"你暂时无法执行此操作|此操作已被阻止|你无法执行此操作|"
                r"temporarily blocked|you can'?t do that right now|"
                r"action (?:is )?blocked", re.I)),
    ("session_verify", "high", "要求确认本人 / 新设备验证",
     re.compile(r"请确认是你本人|这是一次正常的登录|我们无法确认你本人|"
                r"confirm this was you|new device|unusual login", re.I)),
    ("rate_limit", "high", "触发频率限制",
     re.compile(r"你已达到.{0,8}上限|操作过于频繁|请稍后再试|"
                r"you'?ve reached.{0,20}limit|too many (?:requests|attempts)|"
                r"try again later|rate limit", re.I)),
    ("suspicious", "high", "疑似异常活动",
     re.compile(r"我们发现.{0,10}异常活动|可疑活动|账号已被限制|"
                r"suspicious activity|unusual activity|account (?:has been )?restricted", re.I)),
]

# URL 特征（比文本更早命中）
URL_SIGNATURES = [
    ("checkpoint", "critical", "/checkpoint/"),
    ("session_verify", "high", "/two_step_verification/"),
    ("session_verify", "high", "/login/device-based/"),
    ("action_block", "high", "/help/contact/"),
]


@dataclass
class Verdict:
    tripped: bool = False
    kind: str = ""
    severity: str = ""
    message: str = ""
    matched: str = ""
    url: str = ""
    # 建议的熔断粒度
    scope: str = ""      # page | account | global
    extra: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "tripped": self.tripped, "kind": self.kind, "severity": self.severity,
            "message": self.message, "matched": self.matched, "url": self.url,
            "scope": self.scope,
        }


def _scope_for(kind: str) -> str:
    """按类别决定熔断粒度。"""
    if kind in ("checkpoint", "session_verify"):
        return "account"      # 账号级：这个号需要人工处理
    if kind in ("captcha", "action_block"):
        return "account"
    if kind == "rate_limit":
        return "page"         # 只是这个主页被限流
    return "account"


async def check(page: Any, env_code: str = "", page_id: str = "") -> Verdict:
    """检查当前页面是否出现跳脸信号。"""
    v = Verdict()
    try:
        url = await page.eval("location.href") or ""
        v.url = url
    except Exception:
        return v

    for kind, sev, frag in URL_SIGNATURES:
        if frag in url:
            v.tripped = True
            v.kind = kind
            v.severity = sev
            v.message = f"URL 命中 {frag}"
            v.matched = frag
            v.scope = _scope_for(kind)
            _record(v, env_code, page_id)
            return v

    try:
        body = await page.inner_text()
    except Exception:
        return v
    if not body:
        return v

    for kind, sev, msg, rx in SIGNATURES:
        m = rx.search(body)
        if m:
            v.tripped = True
            v.kind = kind
            v.severity = sev
            v.message = msg
            v.matched = m.group(0)[:80]
            v.scope = _scope_for(kind)
            _record(v, env_code, page_id)
            return v
    return v


def _record(v: Verdict, env_code: str, page_id: str) -> None:
    detail = f"[{v.kind}] {v.message} · 命中「{v.matched}」 · {v.url[:90]}"
    db.log_event("err", "guard", detail)
    db.exec(
        "INSERT INTO guard_events(ts,kind,severity,scope,env_code,page_id,"
        "message,matched,url) VALUES(?,?,?,?,?,?,?,?,?)",
        (now_iso(), v.kind, v.severity, v.scope, env_code, page_id,
         v.message, v.matched, v.url))
    log.warning("GUARD TRIPPED %s", detail)


# ---------------- 熔断状态 ----------------
def is_blocked(env_code: str = "", page_id: str = "") -> dict | None:
    """查该环境/主页是否处于熔断中。"""
    now = now_iso()
    rows = db.q(
        "SELECT * FROM guard_events WHERE resolved=0 AND ("
        " (scope='global') OR"
        " (scope='account' AND env_code=? AND env_code<>'') OR"
        " (scope='page' AND page_id=? AND page_id<>'')"
        ") ORDER BY id DESC LIMIT 1", (env_code, page_id))
    return rows[0] if rows else None


def resolve(guard_id: int, note: str = "") -> None:
    db.exec("UPDATE guard_events SET resolved=1, resolved_at=?, note=? WHERE id=?",
            (now_iso(), note, guard_id))
    db.log_event("ok", "guard", f"解除熔断 #{guard_id}: {note}")


async def guard(page: Any, env_code: str = "", page_id: str = "") -> Verdict:
    """带熔断前置检查的包装：已熔断直接返回，不碰页面。"""
    b = is_blocked(env_code, page_id)
    if b:
        return Verdict(tripped=True, kind=b["kind"], severity=b["severity"],
                       message=f"已熔断：{b['message']}", matched=b["matched"],
                       url=b["url"], scope=b["scope"])
    return await check(page, env_code, page_id)
