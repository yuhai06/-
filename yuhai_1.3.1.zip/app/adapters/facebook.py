"""Facebook 主页适配层。

三条硬规则（从实战教训固化）：
  1. 身份只用 profile 数字 ID 认定，绝不用显示名搜索（同名会授给陌生人）。
  2. 创建主页前必须切回个人身份，否则 pages/create 返回「内容暂时无法显示」。
  3. 发布只认 Meta 的受理回执，看不到回执一律判失败，素材不删。

ID 体系（两套，不能混）：
  page_id  = profile.php?id=<数字>          用于打开主页、授权
  asset_id = business.facebook.com 的资产 id  用于发布、看 insights
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass
from typing import Any

from app.adapters.cdp import Browser, CDPError, Page
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.fb")

FB_BASE = "https://www.facebook.com"
BIZ_BASE = "https://business.facebook.com"

# 从页面里抽主页列表的 JS。
# 实测结论（2026-11，发布号 61595095770895，18 个主页全部命中）：
#   · business.facebook.com/latest/settings/pages → ERR_TOO_MANY_REDIRECTS，不可用
#   · business.facebook.com/latest/?asset_id=     → 只给当前主页 + 部分 asset
#   · facebook.com/bookmarks/pages                → 稳定，且 page_id 与 asset_id 可精确配对
#
# 配对算法：从 profile.php?id= 链接向上找 5 层祖先，第一个含 asset_id 链接的祖先
# 就是「同一个主页卡片」的边界，其 asset_id 即该主页的 asset（实测 18/18 全对）。
EXTRACT_PAGES_JS = r"""
(() => {
  const main = document.querySelector('div[role="main"]') || document.body;
  const links = Array.from(main.querySelectorAll('a[href]'));
  const cards = [];
  const seen = new Set();

  for (const a of links) {
    const h = a.getAttribute('href') || '';
    const m = h.match(/profile\.php\?id=(\d{8,})/);
    if (!m) continue;
    const pid = m[1];
    if (seen.has(pid)) continue;

    let el = a, asset = null;
    for (let lv = 1; lv <= 5 && el; lv++) {
      el = el.parentElement;
      if (!el || !el.querySelectorAll) break;
      const inner = el.querySelectorAll('a[href*="asset_id="]');
      if (inner.length) {
        const ah = inner[0].getAttribute('href') || '';
        const am = ah.match(/asset_id=(\d{10,})/);
        if (am) { asset = am[1]; break; }
      }
    }
    seen.add(pid);
    // 名字：卡片里最靠前的短文本
    let name = '';
    if (el) {
      const t = (el.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      if (t.length) name = t[0].slice(0, 40);
    }
    cards.push({ page_id: pid, asset_id: asset, name: name });
  }
  return cards;
})()
"""


@dataclass
class PageRow:
    page_id: str
    asset_id: str | None = None
    name: str = ""


class FBError(RuntimeError):
    pass


class FB:
    """一个已连接的浏览器上下文。

    标签页管理策略（重要）：
      · 每个 FB 实例**只持有一个工作标签**（self._tab），复用于所有页面导航
      · 不再「每操作一次开一个标签」——18 个主页采集会开出 18 个标签，
        既增加内存/CPU 痕迹，也更容易触发行为异常检测
      · 需要独立标签的极少数场景（发布）由调用方显式 new_page / close
    """

    def __init__(self, port: int) -> None:
        self.port = port
        self.browser: Browser | None = None
        self._tab: Page | None = None
        self._own_tab = False

    async def __aenter__(self) -> "FB":
        self.browser = Browser(self.port)
        await self.browser.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close_tab()

    # ---------------- 单标签复用 ----------------
    async def tab(self) -> Page:
        """取（或创建）本实例唯一的工作标签。"""
        if self._tab is not None:
            try:
                await self._tab.eval("1")
                return self._tab
            except Exception:
                # 标签已失效，重建
                self._tab = None
                self._own_tab = False

        # 优先复用浏览器里已有的 facebook 标签，避免净增标签数
        for t in await self.browser.targets():
            u = t.get("url") or ""
            if t.get("type") == "page" and "facebook.com" in u:
                pg = Page(t["webSocketDebuggerUrl"])
                await pg.connect()
                self._tab = pg
                self._own_tab = False
                return pg

        self._tab = await self.browser.new_page()
        self._own_tab = True
        return self._tab

    async def close_tab(self) -> None:
        """只关闭自己开的标签；复用来的不关。"""
        if self._tab is None:
            return
        if self._own_tab:
            try:
                await self._tab.close()
            except Exception:
                pass
        else:
            try:
                await self._tab.close_conn() if hasattr(self._tab, "close_conn") else None
            except Exception:
                pass
        self._tab = None
        self._own_tab = False

    async def tab_count(self) -> int:
        """当前浏览器里 FB 标签数量（用于自检，防止泄漏）。"""
        ts = await self.browser.targets()
        return sum(1 for t in ts
                   if t.get("type") == "page" and "facebook.com" in (t.get("url") or ""))

    async def prune_tabs(self, keep: int = 1) -> int:
        """关掉多余的 FB 标签，只留 keep 个（默认 1 个）。

        每次操作后调用一次，防止历史遗留标签堆积。
        返回关掉了几个。
        """
        try:
            ts = await self.browser.targets()
        except Exception:
            return 0
        fbs = [t for t in ts
               if t.get("type") == "page" and "facebook.com" in (t.get("url") or "")]
        if len(fbs) <= keep:
            return 0

        # 保留当前工作标签
        keep_urls = set()
        if self._tab is not None:
            try:
                keep_urls.add(self._tab.target_id)
            except Exception:
                pass

        closed = 0
        for t in fbs:
            if len(fbs) - closed <= keep:
                break
            tid = t.get("id")
            if tid and tid in keep_urls:
                continue
            try:
                pg = Page(t["webSocketDebuggerUrl"])
                await pg.connect()
                await pg.close()
                closed += 1
            except Exception:
                pass
        if closed:
            log.info("pruned %d extra FB tabs", closed)
        return closed

    # ---------------- 身份 ----------------
    async def c_user(self, page: Page | None = None) -> str | None:
        """读 c_user。复用工作标签，不再每次新开。"""
        p = page or await self.tab()
        for _ in range(5):
            cu = await p.get_fb_identity()
            if cu:
                return cu
            await asyncio.sleep(1.2)
        return None

    async def assert_identity(self, expect: str) -> str:
        """校验当前登录 c_user 是否等于 expect，不等直接抛错。"""
        cur = await self.c_user()
        if not cur:
            raise FBError("读取 c_user 失败，可能未登录")
        if str(cur) != str(expect):
            raise FBError(f"身份不符：期望 c_user={expect}，实际 {cur}")
        return cur

    # ---------------- 提取主页 ----------------
    async def extract_pages(self, c_user: str | None = None) -> list[PageRow]:
        """按当前登录身份拉取该号名下全部主页（page_id + asset_id）。

        实测只有 bookmarks/pages 稳定可用；其它入口保留为兜底但会快速失败。
        """
        page = await self.tab()   # 复用唯一工作标签
        rows: dict[str, PageRow] = {}
        try:
            urls = [
                f"{FB_BASE}/bookmarks/pages",          # 主力入口：page_id 与 asset_id 成对出现
                f"{BIZ_BASE}/latest/?asset_id=",       # 兜底：只给当前主页
            ]
            for u in urls:
                try:
                    await page.goto(u, wait_until_loaded=9.0)
                    cur_url = await page.eval("location.href")
                    if "chrome-error" in (cur_url or ""):
                        log.debug("skip %s (chrome error)", u)
                        continue
                    # 滚动触发懒加载，主页多时需要多滚几次
                    for _ in range(10):
                        before = len(rows)
                        await page.eval("window.scrollBy(0, window.innerHeight*1.2)")
                        await asyncio.sleep(0.9)
                        data = await page.eval(EXTRACT_PAGES_JS) or []
                        for d in data:
                            pid = str(d.get("page_id") or "")
                            if not pid:
                                continue
                            r = rows.get(pid) or PageRow(page_id=pid)
                            r.asset_id = r.asset_id or d.get("asset_id")
                            r.name = r.name or (d.get("name") or "")
                            rows[pid] = r
                        if len(rows) == before and len(rows) > 0:
                            break
                    if len(rows) > 0:
                        break
                except Exception as e:
                    log.debug("extract from %s failed: %s", u, e)
                    continue
            return list(rows.values())
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 授权 ----------------
    async def list_roles(self, asset_id: str) -> list[dict]:
        """读取某主页的公共主页人员身份列表（带 c_user，判定只认 ID）。"""
        from app.adapters.fb_roles import list_roles_with_ids
        page = await self.tab()   # 复用唯一工作标签
        try:
            return await list_roles_with_ids(page, asset_id)
        except CDPError as e:
            log.debug("list_roles failed: %s", e)
            return []
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 创建主页 ----------------
    async def ensure_personal_identity(self, display_name: str) -> bool:
        """切回个人身份。主页身份下无法创建新主页。"""
        page = await self.tab()
        try:
            await page.goto(f"{FB_BASE}/", wait_until_loaded=6.0)
            await asyncio.sleep(2.0)
            ok = await page.eval(r"""
            (() => {
              // 右上角头像菜单
              const btn = document.querySelector('[aria-label*="帐号"],[aria-label*="账户"],[aria-label*="Account"]');
              if (btn) { btn.click(); return true; }
              return false;
            })()
            """)
            if not ok:
                return False
            await asyncio.sleep(1.5)
            clicked = await page.click_text(display_name, exact=True)
            await asyncio.sleep(4.0)
            return bool(clicked)
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    async def create_page(self, name: str, category: str, bio: str = "") -> dict:
        """创建主页。返回 {ok, error, code, transient}。"""
        page = await self.tab()   # 复用唯一工作标签
        errors: list[dict] = []
        try:
            await page.goto(f"{FB_BASE}/pages/create", wait_until_loaded=7.0)
            body = await page.inner_text()
            if "内容暂时无法显示" in body or "暂时无法" in body:
                return {"ok": False, "error": "pages/create 不可用（身份未切回个人 或 配额已满）",
                        "code": None, "transient": False}

            # 填名称
            await page.eval(r"""
            (() => {
              const inp = document.querySelector('input[type="text"]');
              if (inp) { inp.focus(); }
            })()
            """)
            await page.send("Input.insertText", {"text": name})
            await asyncio.sleep(1.0)

            # 类别（React 下拉，用文字点选）
            await page.click_text("类别", exact=False)
            await asyncio.sleep(1.0)
            await page.click_text(category, exact=True)
            await asyncio.sleep(1.0)

            if bio:
                await page.eval("""
                (() => {
                  const tas = Array.from(document.querySelectorAll('textarea, div[contenteditable="true"]'));
                  if (tas.length) tas[0].focus();
                })()
                """)
                await page.send("Input.insertText", {"text": bio})
                await asyncio.sleep(0.6)

            # 提交
            await page.click_text("创建公共主页", exact=True)
            await asyncio.sleep(6.0)

            after = await page.inner_text()
            if "出错了" in after or "请确保你遵守" in after:
                return {"ok": False, "error": "服务端拒绝：创建公共主页时出错了（多为当日配额已满）",
                        "code": 1675030, "transient": False}
            if "内容暂时无法显示" in after:
                return {"ok": False, "error": "内容暂时无法显示", "code": None, "transient": False}
            return {"ok": True, "error": None, "code": None, "transient": False}
        except CDPError as e:
            return {"ok": False, "error": f"CDP: {e}", "code": None, "transient": True}
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    # ---------------- 发布 ----------------
    async def _find_upload_input(self, page, timeout_s: float = 30.0) -> int:
        """找 reels_composer 的视频上传 input，返回 nodeId（找不到返回 0）。

        **实测关键发现**（2026-11-07）：
            reels_composer 页面上 `input[type=file]` 数量为 **0**。
            input 是**点击「添加视频」按钮后才动态创建**的，不是预先存在于 DOM。
            之前直接 querySelector 必然失败 → 报「未找到上传输入框」。

        另外：页面上可能有封面照片的 input（accept=image/*），
        必须**排除它**，只认 accept 含 video 的。

        策略（按顺序）：
            ① 先看已有 video input（有的版本会预建）
            ② 点「添加视频 / Add video / 上传视频」按钮 → 等 input 出现
            ③ 兜底：点整个「影音内容」区块里的按钮
            ④ 遍历 iframe
        每步都校验 accept 含 video，避免抓到封面图的 input。
        """
        import asyncio as _a

        VIDEO_SELS = [
            'input[type="file"][accept*="video"]',
            'input[type="file"][accept*="mp4"]',
        ]

        async def _probe() -> int:
            """返回第一个 accept 含 video 的 input nodeId，没有则 0。"""
            try:
                doc = await page.send("DOM.getDocument", {"depth": -1})
                root_id = doc["root"]["nodeId"]
                # 逐个 file input 检查 accept
                r = await page.send("DOM.querySelectorAll", {
                    "nodeId": root_id, "selector": 'input[type="file"]'})
                ids = (r or {}).get("nodeIds") or []
                for nid in ids:
                    try:
                        # 取该节点的 accept 属性
                        attr = await page.send("DOM.getAttributes", {"nodeId": nid})
                        attrs = attr.get("attributes") or []
                        # attributes 是 [name, value, name, value...]
                        d = dict(zip(attrs[0::2], attrs[1::2]))
                        acc = (d.get("accept") or "").lower()
                        if "video" in acc or "mp4" in acc:
                            return int(nid)
                    except Exception:
                        continue
            except Exception as e:
                log.debug("probe input: %s", e)
            return 0

        async def _click_add_video() -> None:
            """点「添加视频」按钮，触发 input 创建。"""
            js = """(() => {
                const texts = ['添加视频', 'Add video', '上传视频', 'Upload video',
                               '添加影音内容', 'Add media'];
                const all = [...document.querySelectorAll(
                    'div[role=button], button, [aria-label], span')];
                for (const el of all) {
                    const t = (el.innerText || el.getAttribute('aria-label') || '').trim();
                    if (texts.some(x => t === x || t.startsWith(x))) {
                        if (el.tagName === 'SPAN' && el.parentElement) {
                            el.parentElement.click();
                        } else {
                            el.click();
                        }
                        return t;
                    }
                }
                return '';
            })()"""
            try:
                hit = await page.eval(js)
                if hit:
                    log.info("clicked add-video button: %s", hit)
            except Exception as e:
                log.debug("click add video: %s", e)

        deadline = _a.get_running_loop().time() + timeout_s

        # ① 已有 video input？
        nid = await _probe()
        if nid:
            log.info("video input already present")
            return nid

        # ② 点添加视频 → 轮询等 input
        await _click_add_video()
        while _a.get_running_loop().time() < deadline:
            await _a.sleep(1.5)
            nid = await _probe()
            if nid:
                log.info("video input created after click")
                return nid
            # 页面可能因为点击又渲染了一次，再试一次点击
            await _click_add_video()

        # ③ iframe 兜底
        try:
            frames = await page.send("Page.getFrameTree") or {}

            def walk(ft: dict) -> list[str]:
                out = [ft["frame"]["id"]]
                for c in (ft.get("childFrames") or []):
                    out.extend(walk(c))
                return out

            for fid in walk(frames.get("frameTree") or {}):
                try:
                    d2 = await page.send("DOM.getDocument",
                                         {"depth": -1, "frameId": fid})
                    rid = d2["root"]["nodeId"]
                    for sel in VIDEO_SELS:
                        r2 = await page.send("DOM.querySelector", {
                            "nodeId": rid, "selector": sel})
                        n2 = (r2 or {}).get("nodeId")
                        if n2:
                            log.info("video input found in frame %s", fid)
                            return int(n2)
                except Exception:
                    continue
        except Exception as e:
            log.debug("iframe probe: %s", e)

        return 0

    async def publish_reel(self, asset_id: str, video_path: str,
                           caption: str, page_label: str,
                           env_code: str = "", page_id: str = "") -> dict:
        """走 reels_composer 单条链路：创建 → 编辑 → 分享，只认受理回执。

        全程拟人化 + 每步过 guard；命中跳脸立即返回，不再继续。
        """
        from app.adapters import humanize as hz
        from app.adapters import guard as gd

        page = await self.tab()   # 复用唯一工作标签
        try:
            await hz.pacer.wait(env_code or asset_id)
            await page.goto(f"{BIZ_BASE}/latest/reels_composer?asset_id={asset_id}",
                            wait_until_loaded=10.0)
            await hz.human_delay("read")

            # 先过 guard：如果打开就是验证页，立刻中止
            v = await gd.guard(page, env_code, page_id)
            if v.tripped:
                return {"ok": False, "error": v.message, "stage": "guard",
                        "guard": v.as_dict()}

            # 发布位置校验（更稳健的两级判断）
            #
            # 之前只做 `page_label in body` 文本匹配，有两个问题：
            #   ① 主页名很短的（Y01）会误命中页面里任何含该串的文本
            #   ② reels_composer 的 UI 不一定把主页名渲染成可匹配文本，
            #      导致明明切对了也判失败（实测 18 条全是「位置不是 Yxx」）
            #
            # 现在的判据：
            #   ① URL 里带了正确的 asset_id          → 直接通过（最可靠）
            #   ② 页面文本含主页名                   → 通过
            #   ③ 页面文本含 "无法发布/No permission" → 明确失败
            body = await page.inner_text()
            try:
                url_now = await page.eval("location.href") or ""
            except Exception:
                url_now = ""
            url_hit = bool(asset_id) and str(asset_id) in str(url_now)

            if not url_hit and page_label:
                # 主页名匹配：要求独立出现（前后不是字母数字，避免 Y01 命中 Y012）
                import re as _re
                pat = _re.compile(
                    r"(?<![A-Za-z0-9])" + _re.escape(page_label) + r"(?![A-Za-z0-9])")
                if not pat.search(body or ""):
                    # 再给一次机会：页面里有没有明确的"无权限"提示
                    if _re.search(r"没有权限|无法发布|No permission|can't post",
                                  body or "", _re.I):
                        return {"ok": False,
                                "error": f"{page_label} 无发布权限（{asset_id}）",
                                "stage": "locate"}
                    # 文本没命中但 URL 也没命中 → 记录但不阻断，
                    # 因为 reels_composer 的渲染方式可能不含主页名。
                    # 真正的发布结果由「受理回执」判定（create→share 后的回执）。
                    log.warning("publish_reel: 位置文本未命中 %s (asset=%s)，"
                                "继续按 asset 发布", page_label, asset_id)

            # 上传：设置 file input（内核级操作，无法拟人化）
            #
            # 实测问题：reels_composer 的 input 常常是**延迟渲染**或**在 iframe 里**，
            # 一次性 querySelector 会失败（报「未找到上传输入框」）。
            # 改成：轮询等它出现 → 主文档查不到就遍历所有 iframe → 都查不到再给一次重载机会。
            node_id = await self._find_upload_input(page)
            if not node_id:
                return {"ok": False, "error": "未找到上传输入框（等了 20 秒）",
                        "stage": "upload"}
            await page.send("DOM.setFileInputFiles", {
                "nodeId": node_id, "files": [video_path]})
            await hz.human_delay("op")

            # 等处理完成（轮询期间也过 guard，防止中途被跳脸）
            ready = False
            for _ in range(60):
                await asyncio.sleep(6.0)
                t = await page.inner_text()
                if re.search(r"处理失败|上传失败|couldn't upload", t, re.I):
                    return {"ok": False, "error": "视频上传/处理失败", "stage": "process"}
                no_pct = not re.search(r"\d{1,3}\s*%", t)
                if no_pct and ("下一页" in t or "分享" in t):
                    ready = True
                    break
                if re.search(r"\b100\s*%", t):
                    await asyncio.sleep(15.0)
                    ready = True
                    break
            if not ready:
                return {"ok": False, "error": "视频处理超时", "stage": "process"}

            v = await gd.guard(page, env_code, page_id)
            if v.tripped:
                return {"ok": False, "error": v.message, "stage": "guard",
                        "guard": v.as_dict()}

            # 描述：拟人打字
            if caption:
                await page.eval(r"""
                (() => {
                  const b = document.querySelector('div[contenteditable="true"]');
                  if (b) b.focus();
                })()
                """)
                await hz.human_type(page, caption)
                await hz.human_delay("op")

            # 必须点顶部「分享」步骤（不是「下一页」）—— 用拟人点击
            await self._click_text_human(page, "分享")
            await hz.human_delay("read")

            # 底部「分享」按钮：走曲线点击
            pos = await page.eval(r"""
            (() => {
              const btns = Array.from(document.querySelectorAll('[role="button"]'));
              const hits = btns.filter(e => (e.innerText||'').trim() === '分享');
              for (const el of hits) {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.y > 600)
                  return {x: r.x + r.width/2, y: r.y + r.height/2};
              }
              return null;
            })()
            """)
            if pos:
                await hz.human_click(page, pos["x"], pos["y"])
            await hz.human_delay("op")

            # 等受理回执
            for _ in range(40):
                await asyncio.sleep(5.0)
                t = await page.inner_text()
                if re.search(r"正在处理\s*Reels|处理完成后，Reels\s*便会发布", t):
                    return {"ok": True, "acceptance": "processing", "stage": "accepted"}
                if re.search(r"Reels\s*已发布|发布成功|已分享|Published", t):
                    return {"ok": True, "acceptance": "published", "stage": "accepted"}
                if re.search(r"无法处理你的所有|无法根据选定发布选项分享", t):
                    return {"ok": False,
                            "error": "Meta 拒绝发布（无法处理你的所有 Reels）",
                            "stage": "rejected"}
                if re.search(r"发生错误|出错了|Something went wrong", t):
                    v = await gd.check(page, env_code, page_id)
                    return {"ok": False, "error": "Meta 报错" + (
                        f"（{v.message}）" if v.tripped else ""),
                        "stage": "rejected", "guard": v.as_dict() if v.tripped else None}
            return {"ok": False, "error": "未观察到受理回执", "stage": "no_receipt"}
        except CDPError as e:
            return {"ok": False, "error": f"CDP: {e}", "stage": "cdp"}
        finally:
            pass  # 标签由 FB.close_tab() 统一处理

    async def _click_text_human(self, page, text: str) -> bool:
        """按文字找元素，用曲线鼠标点击。"""
        from app.adapters import humanize as hz
        pos = await page.eval(r"""
        (() => {
          const want = %s;
          const els = Array.from(document.querySelectorAll('*'));
          for (const el of els) {
            const t = (el.innerText || '').trim();
            if (t !== want) continue;
            if (el.children.length > 2) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) continue;
            return {x: r.x + r.width/2, y: r.y + r.height/2,
                    top: r.y, h: r.height};
          }
          return null;
        })()
        """ % json.dumps(text))
        if not pos:
            return False
        await hz.human_click(page, pos["x"], pos["y"])
        return True


# ---------------- 入库 ----------------
def upsert_pages(rows: list[PageRow], env_code: str = "") -> int:
    ts = now_iso()
    n = 0
    for r in rows:
        db.exec(
            """INSERT INTO pages(page_id,asset_id,name,health,env_code,last_seen)
               VALUES(?,?,?,'ok',?,?)
               ON CONFLICT(page_id) DO UPDATE SET
                 asset_id=COALESCE(excluded.asset_id, pages.asset_id),
                 name=CASE WHEN excluded.name<>'' THEN excluded.name ELSE pages.name END,
                 env_code=CASE WHEN excluded.env_code<>'' THEN excluded.env_code ELSE pages.env_code END,
                 last_seen=excluded.last_seen""",
            (r.page_id, r.asset_id, r.name or "", env_code, ts),
        )
        n += 1
    return n
