# -*- coding: utf-8 -*-
"""mcp_video.py — 视频制作的 MCP 工具（让 Agent 能手动剪辑）

不进 GUI，Agent 直接调用：
  video_probe       看视频信息（时长/分辨率/码率）
  video_clip        切一段
  video_concat      拼接多个
  video_vertical    转竖屏 9:16
  video_burn_subs   烧字幕
  video_speed       变速
  video_normalize   音量标准化
  video_make        多步串起来
  video_list_out    看产出
  video_env         环境检查
"""
from __future__ import annotations

import json
import logging

log = logging.getLogger("yuhai.mcp.video")


def register(mcp):
    """把视频工具注册到 MCPServer。"""

    def _ok(**kw):
        return {"ok": True, **kw}

    def _err(msg, **kw):
        return {"ok": False, "error": msg, **kw}

    # ═══════════════════════════════════════
    #  环境 / 探测
    # ═══════════════════════════════════════
    @mcp.tool(description="视频工具环境检查（ffmpeg/ffprobe 是否就绪）")
    def video_env() -> dict:
        from app.services import video_maker as vm
        try:
            r = vm.env_check()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"检查失败: {str(e)[:120]}")

    @mcp.tool(
        description="看视频信息：时长、分辨率、码率、音轨。"
                    "用于决定切哪段、要不要转竖屏。path 传绝对路径")
    def video_probe(path: str) -> dict:
        from app.services import video_maker as vm
        try:
            r = vm.probe(path)
            if not r.get("ok"):
                return _err(r.get("error") or "探测失败", path=path)
            return _ok(path=path,
                       duration=r.get("dur"), durationSec=r.get("dur"),
                       width=r.get("w"), height=r.get("h"),
                       fps=r.get("fps"), hasAudio=r.get("audio"),
                       sizeMb=r.get("size_mb"),
                       isVertical=(r.get("h") or 0) > (r.get("w") or 0))
        except Exception as e:
            return _err(f"探测失败: {str(e)[:130]}", path=path)

    # ═══════════════════════════════════════
    #  单步操作
    # ═══════════════════════════════════════
    @mcp.tool(
        description="切一段视频。start/end 是秒数（如 start=12.5 end=30）。"
                    "name 可指定输出文件名")
    def video_clip(path: str, start: float, end: float,
                   name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            if start < 0 or end <= start:
                return _err("时间不对：要 0 <= start < end")
            r = vm.clip(path, start, end, name)
            if not r.get("ok"):
                return _err(r.get("error") or "切片失败")
            return _ok(output=r.get("path") or r.get("output") or "",
                       duration=round(end - start, 2),
                       note=f"切了 {start}s → {end}s")
        except Exception as e:
            return _err(f"切片失败: {str(e)[:130]}")

    @mcp.tool(
        description="拼接多个视频（按数组顺序）。paths 传绝对路径列表")
    def video_concat(paths: str, name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            ps = paths if isinstance(paths, list) else json.loads(paths)
            if not isinstance(ps, list) or len(ps) < 2:
                return _err("至少要 2 个视频")
            r = vm.concat(ps, name)
            if not r.get("ok"):
                return _err(r.get("error") or "拼接失败")
            return _ok(output=r.get("path") or "", count=len(ps),
                       note=f"拼了 {len(ps)} 个")
        except Exception as e:
            return _err(f"拼接失败: {str(e)[:130]}")

    @mcp.tool(
        description="转竖屏（默认 9:16）。适合发 Reels/TikTok。"
                    "ratio 可传 9:16 / 4:5 / 1:1")
    def video_vertical(path: str, ratio: str = "9:16",
                       name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            r = vm.to_vertical(path, name, ratio)
            if not r.get("ok"):
                return _err(r.get("error") or "转竖屏失败")
            return _ok(output=r.get("path") or "", ratio=ratio)
        except Exception as e:
            return _err(f"转竖屏失败: {str(e)[:130]}")

    @mcp.tool(
        description="烧字幕到视频上。text 是字幕内容，fontSize 默认 42")
    def video_burn_subs(path: str, text: str, font_size: int = 42,
                        color: str = "white", name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            if not text.strip():
                return _err("字幕内容为空")
            r = vm.burn_subs(path, text, name, font_size, color)
            if not r.get("ok"):
                return _err(r.get("error") or "加字幕失败")
            return _ok(output=r.get("path") or "",
                       textLen=len(text), fontSize=font_size)
        except Exception as e:
            return _err(f"加字幕失败: {str(e)[:130]}")

    @mcp.tool(description="变速（speed=2 是 2 倍速，0.5 是慢放）")
    def video_speed(path: str, speed: float, name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            if speed <= 0:
                return _err("speed 必须大于 0")
            r = vm.change_speed(path, speed, name)
            if not r.get("ok"):
                return _err(r.get("error") or "变速失败")
            return _ok(output=r.get("path") or "", speed=speed)
        except Exception as e:
            return _err(f"变速失败: {str(e)[:130]}")

    @mcp.tool(
        description="音量标准化到目标 LUFS（Facebook/Reels 建议 -14）")
    def video_normalize(path: str, lufs: float = -14.0,
                        name: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            r = vm.normalize_audio(path, lufs, name)
            if not r.get("ok"):
                return _err(r.get("error") or "音量标准化失败")
            return _ok(output=r.get("path") or "", lufs=lufs)
        except Exception as e:
            return _err(f"标准化失败: {str(e)[:130]}")

    # ═══════════════════════════════════════
    #  多步串联（一次做完）
    # ═══════════════════════════════════════
    @mcp.tool(
        description=(
            "多步处理一条视频，一次做完。steps 是 JSON 数组，每步一个对象：\n"
            '  [{"op":"clip","start":12,"end":30},\n'
            '   {"op":"vertical","ratio":"9:16"},\n'
            '   {"op":"subtitle","text":"标题","fontSize":42},\n'
            '   {"op":"normalize","lufs":-14}]\n'
            "op 支持 clip / vertical / subtitle / speed / normalize"))
    def video_make(path: str, steps: str, title: str = "") -> dict:
        from app.services import video_maker as vm
        try:
            st = steps if isinstance(steps, list) else json.loads(steps)
            if not isinstance(st, list) or not st:
                return _err("steps 要是非空数组")
            # 串行跑
            cur = path
            done = []
            for i, step in enumerate(st):
                op = (step.get("op") or "").lower()
                if op == "clip":
                    r = vm.clip(cur, float(step.get("start") or 0),
                                float(step.get("end") or 0),
                                step.get("name") or "")
                elif op in ("vertical", "v"):
                    r = vm.to_vertical(cur, step.get("name") or "",
                                       step.get("ratio") or "9:16")
                elif op in ("subtitle", "subs", "burn"):
                    r = vm.burn_subs(cur, step.get("text") or "",
                                     step.get("name") or "",
                                     int(step.get("fontSize") or 42),
                                     step.get("color") or "white")
                elif op == "speed":
                    r = vm.change_speed(cur, float(step.get("speed") or 1),
                                        step.get("name") or "")
                elif op == "normalize":
                    r = vm.normalize_audio(cur,
                                           float(step.get("lufs") or -14),
                                           step.get("name") or "")
                else:
                    return _err(f"第 {i+1} 步 op 不认识: {op}",
                                supported=["clip", "vertical", "subtitle",
                                           "speed", "normalize"])
                if not r.get("ok"):
                    return _err(f"第 {i+1} 步({op})失败: "
                                + (r.get("error") or ""), step=i + 1)
                nxt = r.get("path") or ""
                if nxt:
                    cur = nxt
                done.append({"step": i + 1, "op": op,
                             "output": cur})
            return _ok(output=cur, steps=done, total=len(done),
                       note=f"完成 {len(done)} 步处理")
        except json.JSONDecodeError as e:
            return _err(f"steps JSON 解析失败: {str(e)[:80]}",
                        hint='格式如 [{"op":"clip","start":12,"end":30}]')
        except Exception as e:
            return _err(f"处理失败: {str(e)[:130]}")

    # ═══════════════════════════════════════
    #  产出 / 浏览
    # ═══════════════════════════════════════
    @mcp.tool(description="列出视频工具产出的文件")
    def video_list_out(limit: int = 30) -> dict:
        from app.services import video_maker as vm
        try:
            d = vm.out_dir()
            files = sorted(d.glob("*.mp4"),
                           key=lambda p: p.stat().st_mtime, reverse=True)
            out = []
            for f in files[:limit]:
                out.append({"name": f.name, "path": str(f),
                            "sizeMb": round(f.stat().st_size / 1048576, 1),
                            "at": __import__("datetime").datetime.fromtimestamp(
                                f.stat().st_mtime).strftime("%m-%d %H:%M")})
            return _ok(dir=str(d), count=len(out), items=out)
        except Exception as e:
            return _err(f"列出失败: {str(e)[:120]}")

    @mcp.tool(
        description="浏览可用的源视频（找要处理的素材）。"
                    "dir 传目录，留空看默认源目录")
    def video_browse(dir: str = "", limit: int = 40) -> dict:
        from pathlib import Path
        try:
            d = Path(dir) if dir else None
            if d is None:
                from app import paths
                for c in (paths.source_roots() or []):
                    if Path(c).exists():
                        d = Path(c)
                        break
                if d is None:
                    d = paths.DATA_DIR
            if not d.exists():
                return _err(f"目录不存在: {d}")
            vids = []
            for ext in ("*.mp4", "*.mov", "*.mkv", "*.avi"):
                vids.extend(d.glob(ext))
            vids.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            out = [{"name": f.name, "path": str(f),
                    "sizeMb": round(f.stat().st_size / 1048576, 1)}
                   for f in vids[:limit]]
            return _ok(dir=str(d), count=len(out), items=out)
        except Exception as e:
            return _err(f"浏览失败: {str(e)[:120]}")

    return mcp
