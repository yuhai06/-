"""全局配置。全部走环境变量 + 用户数据目录下的 config.json 双层覆盖。

优先级：环境变量 > config.json > 默认值
数据目录：%LOCALAPPDATA%\\YuhaiWorkbench（打包后）或仓库 backend/data（开发）
"""
from __future__ import annotations

import json
import os
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any


def _is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def _repo_root() -> Path:
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


class Settings:
    APP_NAME = "雨海工作台"
    VERSION = "1.0.0"

    def __init__(self) -> None:
        self.is_frozen = _is_frozen()
        self.repo_root = _repo_root()

        # ---- 数据目录 ----
        # 开发时优先用仓库根的 data\（真实数据在那里，不是 backend\data）
        env_data = os.environ.get("YUHAI_DATA_DIR")
        if env_data:
            self.data_dir = Path(env_data)
        elif self.is_frozen:
            base = os.environ.get("LOCALAPPDATA") or str(Path.home())
            self.data_dir = Path(base) / "YuhaiWorkbench"
        else:
            repo_data = self.repo_root.parent / "data"      # 仓库根/data
            inner_data = self.repo_root / "data"           # backend/data
            pick = None
            for cand in (repo_data, inner_data):
                db = cand / "workbench.db"
                try:
                    if db.exists() and db.stat().st_size > 20 * 1024:
                        pick = cand
                        break
                except OSError:
                    pass
            self.data_dir = pick or repo_data
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.browser_profiles = self.data_dir / "browser_profiles"
        self.browser_profiles.mkdir(exist_ok=True)
        self.logs_dir = self.data_dir / "logs"
        self.logs_dir.mkdir(exist_ok=True)
        self.cache_dir = self.data_dir / "cache"
        self.cache_dir.mkdir(exist_ok=True)

        self.db_path = self.data_dir / "workbench.db"

        # ---- 前端目录 ----
        env_fe = os.environ.get("YUHAI_FRONTEND")
        if env_fe:
            self.frontend_dir = Path(env_fe)
        else:
            cands = [
                self.repo_root / "frontend",
                self.repo_root.parent / "frontend",
                self.repo_root / "web",
            ]
            self.frontend_dir = next((c for c in cands if (c / "index.html").exists()), cands[0])

        # ---- 端口 ----
        self.port = int(os.environ.get("YUHAI_PORT", "8710"))

        # ---- 外部依赖 ----
        self.hubstudio_api = os.environ.get("YUHAI_HUBSTUDIO", "http://127.0.0.1:6873")
        self.clash_api = os.environ.get("YUHAI_CLASH", "http://127.0.0.1:9097")
        self.clash_secret = os.environ.get("YUHAI_CLASH_SECRET", "set-your-secret")

        # ReelsPublisher 内核（发布用）
        self.reels_env_dir = os.environ.get(
            "YUHAI_REELS_ENV",
            r"E:\ReelsPublisher-v19.7-Portable\resources\worker\src",
        )
        self.node_exe = os.environ.get("YUHAI_NODE", "")
        # 没有 node 时用 Electron 二进制当 node（已验证可用）
        self.electron_node = os.environ.get(
            "YUHAI_ELECTRON_NODE",
            r"E:\ReelsPublisher-v19.7-Portable\Reels Publisher.exe",
        )

        # 素材目录（全部走 app.paths 的统一解析，换机器不用改代码）
        from app import paths as _paths
        self.library_root = _paths.library_root()
        self.asset_roots = _paths.asset_roots()
        self.source_roots = _paths.source_roots()
        self.output_root = _paths.output_root()
        self.tools_dir = _paths.tools_dir()

        # FB 常量
        self.fb_publisher_cuser = os.environ.get("YUHAI_PUB_CUSER", "61595095770895")
        self.fb_backup_cuser = os.environ.get("YUHAI_BAK_CUSER", "61595415385701")
        self.fb_backup_profile_id = os.environ.get("YUHAI_BAK_PROFILE", "61595415385701")

        self._extra: dict[str, Any] = {}
        self._load_user_config()

    # ---------------- 用户配置 ----------------
    @property
    def user_config_path(self) -> Path:
        return self.data_dir / "config.json"

    def _load_user_config(self) -> None:
        p = self.user_config_path
        if not p.exists():
            return
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return
        if not isinstance(raw, dict):
            return
        self._extra = raw
        for k, v in raw.items():
            attr = k.lower()
            if attr in ("port",):
                setattr(self, "port", int(v))
            elif attr == "hubstudio_api":
                self.hubstudio_api = str(v)
            elif attr == "clash_api":
                self.clash_api = str(v)
            elif attr == "clash_secret":
                self.clash_secret = str(v)
            elif attr == "reels_env_dir":
                self.reels_env_dir = str(v)
            elif attr == "node_exe":
                self.node_exe = str(v)
            elif attr == "asset_roots" and isinstance(v, list):
                self.asset_roots = [Path(x) for x in v]
            elif attr == "source_roots" and isinstance(v, list):
                self.source_roots = [Path(x) for x in v]

    def save_user_config(self, patch: dict[str, Any]) -> None:
        cur = dict(self._extra)
        cur.update(patch)
        self.user_config_path.write_text(
            json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        self._extra = cur

    # ---------------- 便捷 ----------------
    def node_command(self) -> list[str]:
        """返回可用于跑 .mjs 的命令前缀。"""
        if self.node_exe and Path(self.node_exe).exists():
            return [self.node_exe]
        # Electron 二进制以 node 模式运行
        if Path(self.electron_node).exists():
            return [self.electron_node]
        return ["node"]

    def rel(self, p: Path | str) -> str:
        """转成相对 data_dir 的可移植路径（写库用）。"""
        try:
            return str(Path(p).resolve().relative_to(self.data_dir.resolve())).replace("\\", "/")
        except Exception:
            return str(p)


@lru_cache(maxsize=1)
def _settings() -> Settings:
    return Settings()


settings = _settings()
