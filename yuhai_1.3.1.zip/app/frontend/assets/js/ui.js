/* UI 工具：DOM、格式化、Toast、Modal */
import { icon } from './icons.js';

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function h(tag, attrs = {}, children = []) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else el.setAttribute(k, v);
  }
  const list = Array.isArray(children) ? children : [children];
  for (const c of list) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

/* ---------- 格式化 ---------- */
export function nfmt(n) {
  if (n == null || Number.isNaN(n)) return '—';
  if (Math.abs(n) >= 1e8) return (n / 1e8).toFixed(2) + '亿';
  if (Math.abs(n) >= 1e4) return (n / 1e4).toFixed(n >= 1e6 ? 0 : 1) + '万';
  return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export function pct(n, digits = 1) {
  if (n == null || Number.isNaN(n)) return '—';
  return (n * 100).toFixed(digits) + '%';
}

export function ts(iso, withDate = false) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  if (!withDate) return `${hh}:${mm}`;
  return `${d.getMonth() + 1}/${d.getDate()} ${hh}:${mm}`;
}

export function ago(iso) {
  if (!iso) return '—';
  const d = new Date(iso).getTime();
  const s = Math.max(0, (Date.now() - d) / 1000);
  if (s < 60) return `${Math.round(s)} 秒前`;
  if (s < 3600) return `${Math.round(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.round(s / 3600)} 小时前`;
  return `${Math.round(s / 86400)} 天前`;
}

/* ---------- Toast ---------- */
export function toast(title, body = '', kind = 'info', ttl = 3200) {
  const root = $('#toast-root');
  const el = h('div', { class: `toast ${kind}` }, [
    h('b', { text: title }),
    body ? h('span', { text: body }) : null,
  ]);
  root.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .18s, transform .18s';
    el.style.opacity = '0';
    el.style.transform = 'translateX(12px)';
    setTimeout(() => el.remove(), 220);
  }, ttl);
}

/* ---------- Modal ---------- */
let modalStack = [];

export function modal({ title, body, footer = [], width = '', onClose,
                        clickOutsideClose = false, closable = true }) {
  const root = $('#modal-root');
  // 每次开新弹窗前，先把残留的遮罩状态清掉，避免叠加出多个界面
  if (!modalStack.length) root.classList.remove('on');

  const wrap = h('div', { class: 'modal-mask' });
  const box = h('div', { class: `modal ${width}` });
  const head = h('div', { class: 'modal-head' }, [
    h('h3', { text: title }),
    closable
      ? h('button', { class: 'x', text: '×', onclick: () => close() })
      : h('span'),
  ]);
  const bd = h('div', { class: 'modal-body' });
  if (typeof body === 'string') bd.innerHTML = body;
  else if (body) bd.appendChild(body);

  box.appendChild(head);
  box.appendChild(bd);
  if (footer.length) {
    const ft = h('div', { class: 'modal-foot' });
    footer.forEach((f) => ft.appendChild(f));
    box.appendChild(ft);
  }
  wrap.appendChild(box);
  root.appendChild(wrap);
  root.classList.add('on');
  modalStack.push(wrap);

  let closed = false;
  function close() {
    if (closed) return;          // 幂等：重复调用不会留下幽灵遮罩
    closed = true;
    wrap.remove();
    modalStack = modalStack.filter((x) => x !== wrap);
    if (!modalStack.length) root.classList.remove('on');
    if (onClose) onClose();
  }

  // 默认**点遮罩不关闭**。
  // 长表单（抓取/发布/切片）内容高度接近视口，滑动或误触很容易点到外面，
  // 以前的「点外面就关」会把人辛苦填的内容全丢掉。
  // 需要「点外面关」的轻量弹窗显式传 clickOutsideClose: true。
  // 另外，正在输入/滚动时（mousedown→mouseup 跨越了弹层）也不算点击外部。
  if (clickOutsideClose) {
    let downOnMask = false;
    wrap.addEventListener('mousedown', (e) => {
      downOnMask = (e.target === wrap);
    });
    wrap.addEventListener('click', (e) => {
      // 必须按下和抬起都在遮罩上，才算真的点外部
      if (downOnMask && e.target === wrap && !closed) close();
      downOnMask = false;
    });
  }
  return { el: box, body: bd, close };
}

export function closeAllModals() {
  modalStack.forEach((w) => w.remove());
  modalStack = [];
  const root = $('#modal-root');
  if (root) {
    root.classList.remove('on');
    root.innerHTML = '';       // 兜底：清掉任何游离节点
  }
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modalStack.length) {
    modalStack[modalStack.length - 1].remove();
    modalStack.pop();
    if (!modalStack.length) $('#modal-root').classList.remove('on');
  }
});

/* ---------- 复用片段 ---------- */
export function badge(text, kind = 'mute', dot = false) {
  return `<span class="badge ${kind}">${dot ? '<span class="bdot"></span>' : ''}${text}</span>`;
}

export function bar(percent, kind = '') {
  return `<div class="bar ${kind}"><i style="width:${Math.min(100, Math.max(0, percent))}%"></i></div>`;
}

export function sparkline(values, hiIndex = -1) {
  const max = Math.max(...values, 1);
  return `<div class="spark">${values
    .map((v, i) => {
      const ph = Math.max(6, Math.round((v / max) * 100));
      let cls = '';
      if (i === values.length - 1) cls = 'top';
      else if (i >= values.length - 3) cls = 'hi';
      return `<i class="${cls}" style="height:${ph}%"></i>`;
    })
    .join('')}</div>`;
}

export function statCard({ label, value, unit, foot, trend, iconName }) {
  const tr = trend
    ? `<span class="trend ${trend.dir}">${trend.dir === 'up' ? '▲' : trend.dir === 'down' ? '▼' : '■'} ${trend.text}</span>`
    : '';
  return `
    <div class="stat">
      <div class="stat-label">${iconName ? icon(iconName, 12) : ''}<span>${label}</span></div>
      <div class="stat-value">${value}${unit ? `<span class="unit">${unit}</span>` : ''}</div>
      <div class="stat-foot">${tr}${foot ? `<span>${foot}</span>` : ''}</div>
    </div>`;
}

export function pageHead({ title, desc, actions = [] }) {
  return `
    <div class="page-head">
      <div>
        <h1>${title}</h1>
        <p>${desc || ''}</p>
      </div>
      <div class="actions">${actions.join('')}</div>
    </div>`;
}

export function emptyState(text, sub = '') {
  return `<div class="empty">${icon('layers', 34)}<p>${text}</p><span>${sub}</span></div>`;
}

/* 简易折线（SVG path） */
export function lineChart(series, { w = 720, hgt = 170, key = 'views', color = null } = {}) {
  const theme = document.documentElement.dataset.theme || 'light';
  const isLight = theme === 'light';
  const palette = {
    dark: { views: '#4d9dff', reach: '#a78bfa', minutes: '#34d399', grid: '#55637a', rim: '#0f141b' },
    light: { views: '#4f46e5', reach: '#7c3aed', minutes: '#059669', grid: '#8a94a6', rim: '#ffffff' },
  };
  const p = palette[theme] || palette.light;
  const stroke = color || p.views;
  const gridC = p.grid;
  const dotRim = p.rim;
  const vals = series.map((s) => s[key]);
  const max = Math.max(...vals, 1);
  const min = Math.min(...vals, 0);
  const pad = 8;
  const stepX = (w - pad * 2) / Math.max(1, vals.length - 1);
  const yOf = (v) => hgt - pad - ((v - min) / Math.max(1, max - min)) * (hgt - pad * 2);
  const pts = vals.map((v, i) => [pad + i * stepX, yOf(v)]);
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const area = `${d} L${(pad + (vals.length - 1) * stepX).toFixed(1)},${hgt - pad} L${pad},${hgt - pad} Z`;
  const gid = 'g' + Math.random().toString(36).slice(2, 8);
  const labels = series
    .map((s, i) => (i % Math.ceil(series.length / 7) === 0 || i === series.length - 1)
      ? `<text x="${(pad + i * stepX).toFixed(1)}" y="${hgt - 1}" fill="${gridC}" font-size="9"
           font-family="monospace" text-anchor="middle">${s.date.slice(5)}</text>`
      : '')
    .join('');
  return `<svg viewBox="0 0 ${w} ${hgt}" style="width:100%;height:${hgt}px;display:block">
    <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${stroke}" stop-opacity="${isLight ? 0.2 : 0.28}"/>
      <stop offset="100%" stop-color="${stroke}" stop-opacity="0"/>
    </linearGradient></defs>
    <path d="${area}" fill="url(#${gid})"/>
    <path d="${d}" fill="none" stroke="${stroke}" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/>
    ${pts.map((p2, i) => i === pts.length - 1
      ? `<circle cx="${p2[0].toFixed(1)}" cy="${p2[1].toFixed(1)}" r="3.2" fill="${stroke}" stroke="${dotRim}" stroke-width="1.6"/>`
      : '').join('')}
    ${labels}
  </svg>`;
}

export function copyText(txt) {
  navigator.clipboard?.writeText(txt).then(
    () => toast('已复制', txt.slice(0, 40), 'ok', 1600),
    () => toast('复制失败', '浏览器拒绝剪贴板访问', 'err')
  );
}
