/* 指纹浏览器（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, ts, ago, copyText, emptyState,
} from '../ui.js';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '指纹浏览器',
      desc: 'Hubstudio 环境：创建 / 同步 / 转移 / 启动关闭 / 按 PID 提取主页',
      actions: [
        `<button class="btn sm primary" data-act="newenv"><span data-icon="plus"></span>创建环境</button>`,
        `<button class="btn sm" data-act="migrate"><span data-icon="route"></span>一键转移</button>`,
        `<button class="btn sm ghost" data-act="sync"><span data-icon="refresh"></span>同步环境</button>`,
        `<button class="btn sm ghost" data-act="health"><span data-icon="shield"></span>体检</button>`,
      ],
    })}
    <div id="ev-body"></div>
  `;
  $$('[data-act="pid"]', root).forEach((b) => (b.onclick = () => openPid(root)));
  $$('[data-act="probe"]', root).forEach((b) => (b.onclick = () => doProbe()));
  $$('[data-act="sync"]', root).forEach((b) => (b.onclick = () => doSync(root, b)));
  $$('[data-act="health"]', root).forEach((b) => (b.onclick = () => openHealth(root)));
  $$('[data-act="newenv"]', root).forEach((b) => (b.onclick = () => openNewEnv(root)));
  $$('[data-act="migrate"]', root).forEach((b) => (b.onclick = () => openMigrate(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    await store.loadCore();
    const d = await api.envs(true);
    store.envs = d.items || [];
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  paint(root);
}

function paint(root) {
  const body = $('#ev-body', root);
  if (!body) return;
  const envs = store.envs || [];
  const running = envs.filter((e) => e.status === 'running');

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '环境总数', value: envs.length, unit: '个', iconName: 'layers' })}
      ${statCard({ label: '运行中', value: running.length, unit: '个', iconName: 'bolt' })}
      ${statCard({ label: '已登录', value: envs.filter((e) => e.loginValid).length, unit: '个', iconName: 'check' })}
      ${statCard({ label: '已提取主页', value: store.pages.length, unit: '个', iconName: 'flag' })}
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">Hubstudio API</div>
        <div style="display:flex;gap:7px;align-items:center">
          <span class="chip">127.0.0.1:6873</span>
          ${badge('可用', 'ok', true)}
        </div>
      </div>
      <div class="card-body">
        <div class="grid g3" style="gap:10px">
          ${[
            ['全部状态', 'POST /api/v1/browser/all-browser-status', '已开环境 + 真实 pid'],
            ['启动环境', 'POST /api/v1/browser/start', '返回 debuggingPort'],
            ['关闭环境', 'POST /api/v1/browser/stop', 'body: containerCode'],
            ['环境清单', 'POST /api/v1/env/list', '名称 / 代理 / 类型'],
            ['CDP 探测', 'GET :<port>/json/version', '确认 Chrom 内核'],
            ['PID 反查', 'psutil → netstat', 'containerId ≠ PID'],
          ].map(([t, a2, d]) => `
            <div style="background:var(--bg-0);border-radius:var(--r-sm);padding:9px 11px">
              <div style="font-size:11.5px;font-weight:600;margin-bottom:3px">${t}</div>
              <div style="font-family:var(--mono);font-size:10px;color:var(--ac);word-break:break-all">${a2}</div>
              <div style="font-size:10px;color:var(--tx-3);margin-top:3px">${d}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <div class="section-title">环境列表</div>
    <div class="grid g2">
      ${envs.length ? envs.map((e) => {
        const run = e.status === 'running';
        const rk = e.role === 'publisher' ? 'info' : e.role === 'backup' ? 'purple' : 'mute';
        return `
          <div class="page-card" data-env="${e.containerCode}">
            <div class="pc-top">
              <div class="pc-avatar">${run ? icon('bolt', 15) : icon('layers', 15)}</div>
              <div class="pc-name">
                <strong>${esc(e.name)}</strong>
                <span>${e.containerCode}</span>
              </div>
              ${badge(e.roleLabel, rk)}
              ${run ? badge('运行中', 'ok', true) : badge('已关闭', 'mute', true)}
            </div>
            <div style="display:flex;flex-direction:column;gap:3px;margin-bottom:9px">
              ${[
                ['账号', e.account || '未登录'],
                ['c_user', e.cUser || '—'],
                ['代理', `${e.proxyHost || '—'}:${e.proxyPort || ''}`],
                ['CDP', run ? `127.0.0.1:${e.cdpPort}` : '未启动'],
                ['PID', e.pid || '—'],
              ].map(([k, v]) => `
                <div class="kv" style="padding:3px 0;border:none">
                  <span class="k" style="font-size:10.5px">${k}</span>
                  <span class="v" style="font-size:10.5px">${esc(String(v))}</span>
                </div>`).join('')}
            </div>
            <div class="pc-foot" style="border-top:1px dashed rgba(0,0,0,.06);padding-top:9px">
              <span style="font-size:10.5px;color:var(--tx-3)">
                主页 <b style="color:var(--tx-1)">${e.pagesFound || 0}</b> 个
              </span>
              <span style="display:flex;gap:4px">
                ${run
                  ? `<button class="btn xs ghost" data-x="pid" data-code="${e.containerCode}">提取</button>
                     <button class="btn xs danger" data-x="stop" data-code="${e.containerCode}">关闭</button>`
                  : `<button class="btn xs primary" data-x="launch" data-code="${e.containerCode}">启动</button>
                     <button class="btn xs ghost" data-x="proxy" data-code="${e.containerCode}">改代理</button>
                     <button class="btn xs ghost" data-x="remove" data-code="${e.containerCode}">移除</button>`}
              </span>
            </div>
          </div>`;
      }).join('') : `<div class="card"><div class="card-body">${emptyState('没有环境', '确认 Hubstudio 已运行')}</div></div>`}
    </div>
  `;

  $$('[data-x]', root).forEach((b) => {
    b.onclick = async (ev) => {
      ev.stopPropagation();
      const code = b.dataset.code;
      const x = b.dataset.x;
      b.disabled = true;
      try {
        if (x === 'launch') {
          toast('启动中', code, 'info');
          const r = await api.startEnv(code);
          toast('已启动', `CDP ${r.cdpPort} · PID ${r.pid}`, 'ok', 5000);
          await load(root);
        } else if (x === 'stop') {
          await api.stopEnv(code);
          toast('已关闭', code, 'warn');
          await load(root);
        } else if (x === 'pid') {
          const env = (store.envs || []).find((v) => v.containerCode === code);
          openPid(root, env);
        } else if (x === 'remove') {
          m2Remove(root, code);
        } else if (x === 'proxy') {
          openProxy(root, (store.envs || []).find((v) => v.containerCode === code));
        }
      } catch (e) {
        toast('失败', e.message, 'err', 5000);
      } finally {
        b.disabled = false;
      }
    };
  });
}

async function doProbe() {
  try {
    const r = await api.probePorts();
    const items = r.items || [];
    if (!items.length) return toast('没发现 CDP', '确认环境已启动', 'warn');
    modal({
      title: '探测到 ' + items.length + ' 个 CDP',
      body: `<div class="card"><div class="card-body tight">
        ${items.map((x) => `
          <div class="litem">
            <span class="dot ok"></span>
            <div class="litem-main">
              <div class="litem-title">PID ${x.pid} · 端口 ${x.port}</div>
              <div class="litem-sub">${esc(x.name)} · ${esc(x.browser || '')}</div>
            </div>
          </div>`).join('')}
      </div></div>`,
      footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: function () { this.closest('.modal-root').classList.remove('on'); } })],
    });
  } catch (e) {
    toast('探测失败', e.message, 'err');
  }
}

async function doSync(root, btn) {
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>同步中…';
  try {
    const r = await api.syncEnvs();
    const parts = [];
    if (r.added) parts.push(`新增 ${r.added}`);
    if (r.updated) parts.push(`更新 ${r.updated}`);
    if ((r.removed || []).length) parts.push(`移除 ${r.removed.length}`);
    toast('同步完成', parts.join(' · ') || '无变化', 'ok', 5000);
    if ((r.removed || []).length) {
      toast('以下环境已不在 Hubstudio 中',
        r.removed.map((x) => `${x.name}(${x.code})`).join(', '), 'warn', 8000);
    }
    store.envs = r.items || [];
    paint(root);
  } catch (e) {
    toast('同步失败', e.message, 'err', 5000);
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

/* ---------------- 修改代理 ---------------- */
function openProxy(root, env) {
  if (!env) return;
  const others = (store.envs || []).filter(
    (e) => e.containerCode !== env.containerCode && e.status !== 'removed');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px">
      <div class="card-body" style="padding:11px 13px">
        <div class="kv"><span class="k">环境</span><span class="v">${esc(env.name)}</span></div>
        <div class="kv"><span class="k">当前代理</span>
          <span class="v" style="font-family:var(--mono);font-size:10.5px">
            ${env.proxyHost ? `${esc(env.proxyHost)}:${env.proxyPort || ''}` : '无'}
          </span></div>
        <div class="kv"><span class="k">状态</span>
          <span class="v" style="color:${env.status === 'running' ? 'var(--danger)' : 'var(--ok)'}">
            ${env.status === 'running' ? '运行中（需先关闭）' : '已关闭（可修改）'}</span></div>
      </div>
    </div>

    <div class="field">
      <label>快捷方式：克隆其他环境的代理</label>
      <div style="display:flex;gap:6px">
        <select class="select" id="px-from" style="flex:1">
          <option value="">— 选择源环境 —</option>
          ${others.map((e) => `<option value="${e.containerCode}">${esc(e.name)} · ${esc(e.proxyHost || '无代理')}:${e.proxyPort || ''}</option>`).join('')}
        </select>
        <button class="btn sm" id="px-clone">克隆</button>
      </div>
      <div class="hint">最省事：从已配好的环境复制代理（IP 池一致）</div>
    </div>

    <div class="section-title">或手动填写</div>
    <div class="row-2">
      <div class="field"><label>代理类型</label>
        <select class="select" id="px-type">
          <option>Socks5</option><option>http</option><option>https</option>
        </select>
      </div>
      <div class="field"><label>代理主机</label>
        <input class="input" id="px-server" value="${esc(env.proxyHost || '')}"
               placeholder="198.87.177.237" style="font-family:var(--mono);font-size:11px" />
      </div>
    </div>
    <div class="row-3">
      <div class="field"><label>端口</label>
        <input class="input" id="px-port" type="number" value="${env.proxyPort || ''}"
               style="font-family:var(--mono)" /></div>
      <div class="field"><label>账号</label>
        <input class="input" id="px-account" placeholder="可选"
               style="font-family:var(--mono);font-size:11px" /></div>
      <div class="field"><label>密码</label>
        <input class="input" id="px-password" type="password" placeholder="可选"
               style="font-family:var(--mono);font-size:11px" /></div>
    </div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
      改代理会重置这个环境的网络身份。<b>建议改完先进浏览器确认 IP 变了、再登录 FB</b>，
      否则可能出现登录异常触发风控。
    </div></div>`;

  const m = modal({
    title: `修改代理 · ${env.name}`, width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存代理',
        onclick: async () => {
          const server = (body.querySelector('#px-server').value || '').trim();
          if (!server) return toast('代理主机不能为空', '', 'err');
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '保存中…';
          try {
            const r = await api.setEnvProxy(env.containerCode, {
              proxyType: body.querySelector('#px-type').value,
              proxyServer: server,
              proxyPort: parseInt(body.querySelector('#px-port').value, 10) || 0,
              proxyAccount: body.querySelector('#px-account').value.trim(),
              proxyPassword: body.querySelector('#px-password').value,
            });
            toast('已修改', r.proxy, 'ok', 6000);
            m.close();
            await load(root);
          } catch (e) {
            toast('修改失败', e.message, 'err', 7000);
          } finally { btn.disabled = false; btn.textContent = '保存代理'; }
        },
      }),
    ],
  });

  body.querySelector('#px-clone').onclick = async () => {
    const from = body.querySelector('#px-from').value;
    if (!from) return toast('先选源环境', '', 'err');
    try {
      const r = await api.cloneEnvProxy(env.containerCode, from);
      toast('已克隆', r.proxy, 'ok', 6000);
      m.close();
      await load(root);
    } catch (e) { toast('克隆失败', e.message, 'err', 7000); }
  };
}

function m2Remove(root, code) {
  const env = (store.envs || []).find((v) => v.containerCode === code);
  const body = document.createElement('div');
  body.innerHTML = `
    <p style="margin:0 0 10px;font-size:12px;color:var(--tx-1)">
      从台账移除环境 <b>${esc(env?.name || code)}</b>（${code}）？
    </p>
    <div class="field">
      <label>移除方式</label>
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:4px">
        <label class="switch"><input type="checkbox" id="rm-hard" />
          <span class="track"></span>
          <span class="lbl">硬删除（连同记录一起清掉，主页归属置空）</span></label>
      </div>
      <div class="hint">
        默认只标记移除，主页归属记录保留。如果这个环境在 Hubstudio 里被删了，
        下次「同步环境」也会自动标记移除。
      </div>
    </div>`;
  const m = modal({
    title: '移除环境', width: 'narrow', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn danger', textContent: '确认移除',
        onclick: async () => {
          const hard = body.querySelector('#rm-hard').checked;
          try {
            await api.deleteEnv(code, hard);
            toast('已移除', hard ? '记录已删除' : '已标记移除', 'warn');
            m.close();
            await load(root);
          } catch (e) { toast('失败', e.message, 'err', 5000); }
        },
      }),
    ],
  });
}

/* ---------------- 体检（升级兼容） ---------------- */
async function openHealth(root) {
  const body = document.createElement('div');
  body.innerHTML = '<div style="padding:24px;text-align:center;color:var(--tx-3)">检查中…</div>';
  const m = modal({
    title: 'Hubstudio 兼容性体检', width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), {
      className: 'btn', textContent: '关闭', onclick: () => m.close(),
    })],
  });
  try {
    const h = await api.envHealth();
    const row = (k, v, note = '') => `
      <div class="litem" style="padding:6px 0">
        <span class="dot ${v ? 'ok' : 'bad'}"></span>
        <div class="litem-main">
          <div class="litem-title" style="font-size:11.5px">${k}</div>
          ${note ? `<div class="litem-sub" style="font-size:10px">${esc(note)}</div>` : ''}
        </div>
        <span style="font-family:var(--mono);font-size:10px;
                     color:${v ? 'var(--ok)' : 'var(--danger)'}">
          ${v === null ? '未知' : v ? 'OK' : 'FAIL'}
        </span>
      </div>`;
    body.innerHTML = `
      <div class="card" style="margin-bottom:12px">
        <div class="card-body">
          <div class="kv"><span class="k">接口地址</span>
            <span class="v" style="font-family:var(--mono);font-size:10.5px">${esc(h.endpoint || '')}</span></div>
          <div class="kv"><span class="k">整体状态</span>
            <span class="v" style="color:${h.ok ? 'var(--ok)' : 'var(--danger)'}">
              ${h.ok ? '可正常连接' : '连接异常'}</span></div>
          <div class="kv"><span class="k">环境数</span><span class="v">${h.envCount || 0}</span></div>
        </div>
      </div>
      <div class="section-title">接口探测</div>
      <div class="card"><div class="card-body tight">
        ${row('/api/v1/env/list（读取环境）', h.envListOk, '列出所有环境')}
        ${row('/api/v1/browser/all-browser-status（运行状态）', h.statusOk, '已开环境 + PID')}
        ${row('/api/v1/env/create（创建环境）', h.createOk, '升级后可能改名')}
        ${row('/api/v1/env/del（删除环境）', h.delOk, '升级后可能改名')}
      </div></div>
      ${(h.drifted || []).length ? `
      <div class="section-title" style="color:var(--warn)">台账与 Hubstudio 不一致</div>
      <div class="card"><div class="card-body tight">
        ${h.drifted.map((d) => `
          <div class="litem">
            <span class="dot warn"></span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">${esc(d.name)} · ${esc(d.code)}</div>
              <div class="litem-sub">${esc(d.issue)}</div>
            </div>
          </div>`).join('')}
      </div></div>` : ''}
      ${h.error ? `<div class="card" style="margin-top:12px;border-color:rgba(248,113,113,.4)">
        <div class="card-body" style="font-size:11px;color:var(--danger)">${esc(h.error)}</div>
      </div>` : ''}
      <div class="card" style="margin-top:12px">
        <div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
          <b>Hubstudio 升级后会不会连不上？</b><br/>
          只要你本地 API 端口（6873）还在、接口路径没改，就照常连。
          这个体检就是用来发现「升级后接口路径改名」这类问题的 ——
          哪一项 FAIL 就说明那个接口对不上了，需要按新版文档改路径。
          连接方式是 HTTP 轮询，不依赖任何 SDK，所以不会因为客户端升级而断。
        </div>
      </div>`;
  } catch (e) {
    body.innerHTML = `<div style="padding:20px;color:var(--danger);font-size:12px">${esc(e.message)}</div>`;
  }
}

/* ---------------- 创建环境 ---------------- */
function openNewEnv(root) {
  const envs = (store.envs || []).filter((e) => e.status !== 'removed');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>环境名称</label>
      <input class="input" id="ne-name" placeholder="发布号04" />
    </div>
    <div class="field">
      <label>代理来源</label>
      <select class="select" id="ne-clone">
        <option value="">— 手动填写 —</option>
        ${envs.map((e) => `<option value="${e.containerCode}">克隆 ${esc(e.name)} 的代理（${esc(e.proxyHost || '—')}:${e.proxyPort || ''}）</option>`).join('')}
      </select>
      <div class="hint">大多数情况下克隆已有环境的代理最省事（IP 池一致）</div>
    </div>
    <div id="ne-manual">
      <div class="row-2">
        <div class="field"><label>代理类型</label>
          <select class="select" id="ne-type">
            <option>Socks5</option><option>http</option><option>https</option>
          </select>
        </div>
        <div class="field"><label>代理主机</label>
          <input class="input" id="ne-server" placeholder="198.87.177.237" style="font-family:var(--mono);font-size:11px" />
        </div>
      </div>
      <div class="row-3">
        <div class="field"><label>端口</label>
          <input class="input" id="ne-port" type="number" placeholder="8022" style="font-family:var(--mono)" /></div>
        <div class="field"><label>账号</label>
          <input class="input" id="ne-account" placeholder="可选" style="font-family:var(--mono);font-size:11px" /></div>
        <div class="field"><label>密码</label>
          <input class="input" id="ne-password" placeholder="可选" type="password" style="font-family:var(--mono);font-size:11px" /></div>
      </div>
    </div>
    <div class="field"><label>备注</label>
      <input class="input" id="ne-remark" placeholder="可选" /></div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
      创建后会自动同步进台账。<b>代理主机是必填项</b>（Hubstudio 侧要求），
      不填会被拒（E110076）。建好后记得进浏览器登录 FB 账号。
    </div></div>`;

  const m = modal({
    title: '创建 Hubstudio 环境', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '创建', id: 'ne-go',
        onclick: async () => {
          const name = (body.querySelector('#ne-name').value || '').trim();
          if (!name) return toast('请输入环境名称', '', 'err');
          const clone = body.querySelector('#ne-clone').value;
          const payload = {
            name,
            cloneProxyFrom: clone,
            proxyType: body.querySelector('#ne-type').value,
            proxyServer: body.querySelector('#ne-server').value.trim(),
            proxyPort: parseInt(body.querySelector('#ne-port').value, 10) || 0,
            proxyAccount: body.querySelector('#ne-account').value.trim(),
            proxyPassword: body.querySelector('#ne-password').value,
            remark: body.querySelector('#ne-remark').value.trim(),
            syncAfter: true,
          };
          if (!clone && !payload.proxyServer) {
            return toast('代理主机不能为空', '可改用「克隆已有环境」', 'err', 5000);
          }
          const btn = body.querySelector('#ne-go');
          btn.disabled = true; btn.textContent = '创建中…';
          try {
            const r = await api.createEnv(payload);
            toast('创建成功',
              `containerCode ${r.containerCode}${r.synced ? ' · 已同步台账' : ''}`, 'ok', 6000);
            m.close();
            await load(root);
          } catch (e) {
            toast('创建失败', e.message, 'err', 7000);
          } finally { btn.disabled = false; btn.textContent = '创建'; }
        },
      }),
    ],
  });

  const toggleManual = () => {
    const clone = body.querySelector('#ne-clone').value;
    body.querySelector('#ne-manual').style.display = clone ? 'none' : '';
  };
  body.querySelector('#ne-clone').onchange = toggleManual;
  toggleManual();
}

/* ---------------- 一键转移 ---------------- */
function openMigrate(root) {
  const envs = (store.envs || []).filter((e) => e.status !== 'removed');
  const pages = store.pages || [];
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field" style="margin:0"><label>从（源环境）</label>
        <select class="select" id="mg-from">
          ${envs.map((e) => `<option value="${e.containerCode}">${esc(e.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field" style="margin:0"><label>到（目标环境）</label>
        <select class="select" id="mg-to">
          ${envs.map((e) => `<option value="${e.containerCode}">${esc(e.name)}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="field">
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:6px">
        <label class="switch"><input type="checkbox" id="mg-all" checked />
          <span class="track"></span><span class="lbl">转移源环境名下的全部主页</span></label>
        <label class="switch"><input type="checkbox" id="mg-acc" checked />
          <span class="track"></span><span class="lbl">同时转移号绑定</span></label>
      </div>
    </div>
    <div id="mg-preview" style="margin-top:10px"></div>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn" id="mg-dry"><span data-icon="eye"></span>预览</button>
      <button class="btn primary" id="mg-go"><span data-icon="route"></span>执行转移</button>
    </div>
    <div class="card" style="margin-top:12px;border-color:rgba(251,191,36,.3)">
      <div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
        转移的是<b>台账归属</b>（主页挂在哪个环境、号绑在哪个环境）。<br/>
        <b style="color:var(--warn)">浏览器里的登录态（cookie）搬不了</b> ——
        那是 Hubstudio 自己加密存的。所以换环境后要在新环境里重新登录 FB，
        再点「按 PID 提取」确认主页还在。
      </div>
    </div>`;

  const m = modal({
    title: '一键转移环境资产', width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), {
      className: 'btn', textContent: '关闭', onclick: () => m.close(),
    })],
  });

  const build = (dry) => ({
    fromEnv: body.querySelector('#mg-from').value,
    toEnv: body.querySelector('#mg-to').value,
    moveAllPages: body.querySelector('#mg-all').checked,
    pageIds: [],
    moveAccounts: body.querySelector('#mg-acc').checked,
    dryRun: dry,
  });

  body.querySelector('#mg-dry').onclick = async () => {
    const p = build(true);
    if (p.fromEnv === p.toEnv) return toast('源和目标不能相同', '', 'err');
    try {
      const r = await api.migrateEnv(p);
      const pl = r.plan || {};
      body.querySelector('#mg-preview').innerHTML = `
        <div class="card"><div class="card-body">
          <div class="kv"><span class="k">从</span><span class="v">${esc(pl.from?.name || '')}</span></div>
          <div class="kv"><span class="k">到</span><span class="v">${esc(pl.to?.name || '')}</span></div>
          <div class="kv"><span class="k">主页</span><span class="v">${(pl.pages || []).length} 个</span></div>
          <div class="kv"><span class="k">号</span><span class="v">${(pl.accounts || []).length} 个</span></div>
          <div style="margin-top:8px;font-size:10.5px;color:var(--tx-3);line-height:1.7">
            ${esc(pl.note || '')}
          </div>
        </div></div>`;
    } catch (e) { toast('预览失败', e.message, 'err'); }
  };

  body.querySelector('#mg-go').onclick = async () => {
    const p = build(false);
    if (p.fromEnv === p.toEnv) return toast('源和目标不能相同', '', 'err');
    if (!confirm('确认执行转移？主页与号的环境归属会立刻改掉。')) return;
    try {
      const r = await api.migrateEnv(p);
      toast('转移完成', `${r.pages} 个主页 · ${r.accounts} 个号`, 'ok');
      m.close();
      await load(root);
    } catch (e) { toast('转移失败', e.message, 'err'); }
  };
}

function openPid(root, env) {  const running = (store.envs || []).filter((e) => e.status === 'running');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>PID 或 CDP 端口</label>
      <input class="input" id="px-v" placeholder="PID 或端口"
             value="${env ? (env.pid || env.cdpPort || '') : (running[0] ? (running[0].pid || running[0].cdpPort || '') : '')}"
             style="font-family:var(--mono)" />
      <div class="hint">containerId 不是进程 PID。不知道就填 CDP 端口，或从下面选已开环境。</div>
    </div>
    <div class="field">
      <label>已开环境</label>
      <select class="select" id="px-env">
        <option value="">— 手动输入 —</option>
        ${running.map((e) => `<option value="${e.containerCode}">${esc(e.name)} · PID ${e.pid || '—'} · 端口 ${e.cdpPort || '—'}</option>`).join('')}
      </select>
    </div>`;
  const m = modal({
    title: '按 PID 提取主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn primary', textContent: '开始提取', id: 'px-run' }),
    ],
  });
  const inp = body.querySelector('#px-v');
  body.querySelector('#px-env').onchange = (e) => {
    const x = running.find((v) => v.containerCode === e.target.value);
    if (x) inp.value = x.pid || x.cdpPort || '';
  };
  m.el.querySelector('#px-run').onclick = async () => {
    const v = (inp.value || '').trim();
    if (!v) return toast('请输入', '', 'err');
    const btn = m.el.querySelector('#px-run');
    btn.disabled = true; btn.textContent = '提取中…';
    try {
      const isPort = +v > 40000;
      const r = isPort ? await api.extractPages(0, +v) : await api.extractPages(+v, 0);
      if (!r.ok) {
        toast('提取失败', r.error || '', 'err', 6000);
      } else {
        toast('提取完成', `c_user ${r.cUser} · ${r.count} 个主页`, 'ok');
        m.close();
        await load(root);
      }
    } catch (e) {
      toast('失败', e.message, 'err');
    } finally {
      btn.disabled = false; btn.textContent = '开始提取';
    }
  };
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
