/* 短剧切片（严格对齐《短剧切片完整流程.md》）
   五步流程 + 两条出片线 + 硬约束校验 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let env = null;
let envFull = null;
let sources = { roots: [], items: [], source: '' };
let dramas = [];
let types = [];
let constraints = null;
let jobs = [];
let curDrama = '';
let curStatus = null;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '短剧切片',
      desc: '转录 → 语音检测 → 类型判定 → 张力打分 → 单集/精品双线出片',
      actions: [
        `<button class="btn sm" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
        `<button class="btn sm primary" data-act="run"><span data-icon="bolt"></span>开始切片</button>`,
      ],
    })}
    <div id="sl-body"></div>
  `;
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  $$('[data-act="run"]', root).forEach((b) => (b.onclick = () => openRun(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    env = await api.sliceEnv();
    try { envFull = await api.envFull(); } catch { envFull = null; }
    try { sources = await api.sliceSources(); } catch { sources = { roots: [], items: [] }; }
    dramas = (await api.sliceDramas()).items || [];
    types = (await api.sliceTypes()).items || [];
    constraints = await api.sliceConstraints();
    jobs = (await api.sliceJobs()).items || [];
    if (curDrama) {
      try { curStatus = await api.sliceStatus(curDrama); } catch { curStatus = null; }
    }
  } catch (e) { console.warn(e.message); }
  paint(root);
}

function paint(root) {
  const body = $('#sl-body', root);
  if (!body) return;

  const canSliceCount = dramas.filter((d) => d.canSlice).length;
  const withOutput = dramas.filter((d) => d.hasOutput).length;
  const hasAnySource = canSliceCount > 0;

  body.innerHTML = `
    ${envCard()}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '可处理剧', value: dramas.length, unit: '部', iconName: 'layers',
                   foot: `${dramas.reduce((a, x) => a + x.episodes, 0)} 集` })}
      ${statCard({ label: '转录引擎', value: env?.fasterWhisper ? '就绪' : '缺失', unit: '',
                   iconName: 'bolt', foot: env?.gpu ? esc(env.gpu.slice(0, 20)) : '无 GPU' })}
      ${statCard({ label: '编码加速', value: env?.nvenc ? 'NVENC' : 'CPU', unit: '',
                   iconName: 'video', foot: env?.nvenc ? 'GPU 硬件编码' : 'libx264 软编' })}
      ${statCard({ label: '切片任务', value: jobs.length, unit: '个', iconName: 'clock' })}
    </div>

    <!-- 源素材目录（可自定义） -->
    <div class="card" style="margin-bottom:13px;border-color:${hasAnySource
      ? 'rgba(52,211,153,.3)' : 'rgba(251,191,36,.4)'}">
      <div class="card-head">
        <div class="card-title">
          <span data-icon="db"></span> 源素材目录
          <span class="badge ${hasAnySource ? 'ok' : 'warn'}" style="font-size:9px;margin-left:5px">
            ${hasAnySource ? `${canSliceCount} 部可切` : '没找到源片'}</span>
          <span class="chip ghost" style="font-size:8.5px;margin-left:4px">
            ${esc(sources.source || '自动发现')}</span>
        </div>
        <button class="btn xs ghost" id="sl-src-edit">自定义目录</button>
      </div>
      <div class="card-body">
        <div style="display:flex;flex-direction:column;gap:5px">
          ${(sources.items || []).map((s) => `
            <div class="litem" style="padding:5px 0">
              <span class="dot ${s.dramaCount ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:10px;font-family:var(--mono);
                     word-break:break-all">${esc(s.path)}</div>
                <div class="litem-sub" style="font-size:9px;color:var(--tx-3)">
                  ${s.exists ? `${s.dramaCount} 部剧` : '目录不存在'}
                </div>
              </div>
            </div>`).join('') || '<div style="font-size:10px;color:var(--tx-3)">没有配置源素材目录</div>'}
        </div>
        ${!hasAnySource ? `
        <div style="margin-top:9px;padding:9px 11px;border-radius:var(--r-sm);
                    background:rgba(251,191,36,.07);font-size:10.5px;line-height:1.8;
                    color:var(--warn)">
          切片需要 <b>按剧名分文件夹的原始集</b>：<code style="font-family:var(--mono);
          font-size:10px;background:var(--bg-0);padding:2px 6px;border-radius:4px">
          &lt;目录&gt;\\&lt;剧名&gt;\\EP01.mp4</code><br/>
          源片不在这里？点右上「自定义目录」指过去，或去「素材抓取」重新抓。
        </div>` : ''}
      </div>
    </div>

    <div class="grid" style="grid-template-columns:1fr 1.15fr;margin-bottom:13px">
      <div class="card">
        <div class="card-head">
          <div class="card-title">剧集 <span class="sub">${dramas.length} 部</span></div>
          <div style="display:flex;gap:4px">
            <span class="badge ok" style="font-size:8.5px">可切片 ${canSliceCount}</span>
            <span class="badge mute" style="font-size:8.5px">已出片 ${withOutput}</span>
          </div>
        </div>
        <div class="card-body tight" style="max-height:400px;overflow-y:auto">
          ${dramas.length ? dramas.map((d) => `
            <div class="litem" data-drama="${esc(d.drama)}" style="cursor:pointer">
              <span class="dot ${d.progress >= 4 ? 'ok' : d.progress > 0 ? 'warn' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">
                  ${esc(d.title || d.drama)}
                  ${d.canSlice
                    ? '<span class="badge ok" style="font-size:8px;margin-left:5px">可切</span>'
                    : '<span class="badge mute" style="font-size:8px;margin-left:5px">无源片</span>'}
                </div>
                <div class="litem-sub" style="font-size:9.5px">
                  ${d.outCount ? `成片 ${d.outCount} 条` : ''}
                  ${d.epLines ? ` · 转录 ${d.epLines} 集` : ''}
                  ${d.hasSource ? ` · ${d.episodes} 集源片 ${d.sizeMb} MB` : ''}
                  ${!d.outCount && !d.epLines && !d.hasSource ? d.state : ''}
                </div>
                <div style="display:flex;gap:3px;margin-top:3px;flex-wrap:wrap">
                  ${['transcribe', 'voice', 'classify', 'tension'].map((k) =>
                    `<span class="badge ${d.steps[k]?.done ? 'ok' : 'mute'}" style="font-size:8.5px">
                      ${k === 'transcribe' ? '转录' : k === 'voice' ? '语音' : k === 'classify' ? '分类' : '打分'}
                    </span>`).join('')}
                </div>
              </div>
              <button class="btn xs ghost" data-dlgcheck="${esc(d.drama)}" title="台词完整性"
                      style="flex-shrink:0">校验</button>
              ${d.canSlice
                ? `<button class="btn xs primary" data-runsingle="${esc(d.drama)}"
                   style="flex-shrink:0">切片</button>`
                : ''}
            </div>`).join('')
            : `<div style="padding:24px;text-align:center;color:var(--tx-3);font-size:11.5px">
                 没有找到任何剧
               </div>`}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">流程说明</div>
          <span class="chip">五步 + 双线</span>
        </div>
        <div class="card-body">
          <div class="steps" style="margin-bottom:12px">
            ${[
              ['① 台词转录', 'faster-whisper GPU，20集约43秒，输出带时间戳'],
              ['② 语音检测', '频谱分析，人声 vs 音乐/静音，准确率99.4%'],
              ['③ 类型判定', '7类强弱关键词加权，读完整台词本'],
              ['④ 张力打分', '8维度：挑逗/攻击/情感/疑问/否定/命令/短句'],
              ['⑤ 单集出片', '1-5句完整台词建段，40-55s，段边界对齐台词'],
              ['⑥ 精品混剪', '强制5阶段，按类型查节奏表，120-150s'],
            ].map(([t, d], i) => `
              <div class="step ${i < 4 ? 'done' : 'wait'}">
                <div class="step-num">${i < 4 ? '✓' : i + 1}</div>
                <div class="step-body">
                  <div class="step-title">${t}</div>
                  <div class="step-desc">${d}</div>
                </div>
              </div>`).join('')}
          </div>
          <div class="section-title">硬性约束（违反必返工）</div>
          <div style="font-size:10.5px;color:var(--tx-2);line-height:1.9">
            ${(constraints?.rules || []).map((r) => `<div>${esc(r)}</div>`).join('')}
          </div>
        </div>
      </div>
    </div>

    ${curStatus ? paintStatus(curStatus) : ''}

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">七种剧型</div>
        <span class="chip">BGM 按类型匹配</span>
      </div>
      <div class="card-body">
        <div class="tbl-wrap">
          <table class="tbl" style="font-size:10.5px">
            <thead><tr>
              <th>类型</th><th>节奏</th><th>BGM</th><th>强特征</th>
            </tr></thead>
            <tbody>
              ${types.map((t) => `
                <tr>
                  <td><b>${esc(t.name)}</b></td>
                  <td style="font-size:10px">${esc(t.rhythm)}</td>
                  <td style="font-family:var(--mono);font-size:9.5px">${(t.bgm || []).join(' / ')}</td>
                  <td style="font-family:var(--mono);font-size:9px;color:var(--tx-3)">
                    ${(t.strong || []).slice(0, 4).join(', ')}
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">切片任务</div></div>
      <div class="card-body tight" style="max-height:320px;overflow-y:auto">
        ${jobs.length ? jobs.slice(0, 10).map((j) => {
          const st = j.status === 'running' ? ['执行中', 'info']
            : j.status === 'done' ? ['完成', 'ok']
            : j.status === 'failed' ? ['失败', 'danger'] : ['排队', 'mute'];
          const res = j.result || {};
          return `
            <div class="litem" style="flex-direction:column;align-items:stretch;gap:6px">
              <div style="display:flex;gap:8px;align-items:center">
                <div class="litem-title" style="flex:1">${esc(j.title)} ${badge(st[0], st[1], j.status === 'running')}</div>
                <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">${j.progress || 0}%</span>
              </div>
              ${bar(j.progress || 0, j.status === 'failed' ? 'danger' : j.status === 'done' ? 'ok' : '')}
              ${(j.steps || []).length ? `
                <div style="display:flex;flex-direction:column;gap:3px">
                  ${(j.steps || []).map((s) => `
                    <div style="display:flex;gap:7px;font-size:10.5px">
                      <span style="color:${s.state === 'done' ? 'var(--ok)' : s.state === 'err' ? 'var(--danger)' : s.state === 'run' ? 'var(--ac)' : 'var(--tx-3)'}">
                        ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : s.state === 'run' ? '…' : s.state === 'skip' ? '—' : '·'}
                      </span>
                      <span style="flex:1;color:var(--tx-2)">${esc(s.name)}</span>
                      <span style="color:var(--tx-3);font-size:9.5px">${esc(s.note || '')}</span>
                    </div>`).join('')}
                </div>` : ''}
              ${res.premium?.path ? `
                <div style="font-size:10px;color:var(--ok);font-family:var(--mono);word-break:break-all">
                  ${esc(res.premium.path)}
                </div>` : ''}
              ${j.error ? `<div style="font-size:10px;color:var(--danger)">${esc(j.error)}</div>` : ''}
            </div>`;
        }).join('') : '<div style="padding:22px;text-align:center;color:var(--tx-3);font-size:11.5px">还没有切片任务</div>'}
      </div>
    </div>
  `;

  $$('[data-drama]', body).forEach((el) => {
    el.onclick = async (e) => {
      if (e.target.closest('[data-runsingle]')) return;
      curDrama = el.dataset.drama;
      try {
        curStatus = await api.sliceStatus(curDrama);
        paint(root);
      } catch (err) { toast('加载失败', err.message, 'err'); }
    };
  });
  $$('[data-runsingle]', body).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openRun(root, b.dataset.runsingle); };
  });
  $$('[data-verify]', body).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); verifyFile(b.dataset.verify, b); };
  });
  $$('[data-dlgcheck]', body).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); checkDialogue(root, b.dataset.dlgcheck); };
  });
  $$('[data-audioguard]', body).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); audioGuard(b.dataset.audioguard); };
  });
  $$('[data-envcheck]', body).forEach((b) => {
    b.onclick = async () => {
      b.disabled = true;
      try { envFull = await api.envFull(); paint(root); toast('已重新检测', '', 'ok'); }
      catch (err) { toast('检测失败', err.message, 'err'); }
      finally { b.disabled = false; }
    };
  });
  $$('[data-envinstall]', body).forEach((b) => {
    b.onclick = () => runEnvInstall(root);
  });
  $$('#sl-src-edit', body).forEach((b) => {
    b.onclick = () => editSources(root);
  });
}

/* ---------------- 源素材目录编辑 ---------------- */
function editSources(root) {
  const cur = (sources.items || []).map((s) => s.path);
  const body = document.createElement('div');
  body.innerHTML = `
    <div style="font-size:10.5px;line-height:1.8;color:var(--tx-2);margin-bottom:10px">
      切片会按顺序在这些目录里找 <code style="font-family:var(--mono);font-size:10px">
      &lt;剧名&gt;\\EP01.mp4</code>。一行动一个目录，越靠前优先级越高。
    </div>
    <div class="field">
      <label>源素材目录（一行一个）</label>
      <textarea class="input" id="src-list" rows="6"
        style="font-family:var(--mono);font-size:10.5px;resize:vertical">${esc(cur.join('\n'))}</textarea>
    </div>
    <div class="field">
      <label>快捷添加</label>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn xs" data-add="${esc(env?.sourceRoots?.[0] || '')}">默认位置</button>
        <button class="btn xs" data-add="${esc(sources.items?.[0]?.path || '')}">第一个候选</button>
      </div>
    </div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10px;
                color:var(--tx-3);line-height:1.8">
      保存后写入 <code style="font-family:var(--mono)">config.json</code>，
      <b>重启程序</b>后所有模块生效。留空 = 恢复自动发现。
    </div></div>`;
  const m = modal({
    title: '自定义源素材目录', width: 'mid', body,
    footer: [
      Object.assign(document.createElement('button'),
        { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const roots = body.querySelector('#src-list').value
            .split('\n').map((s) => s.trim()).filter(Boolean);
          try {
            const r = await api.sliceSourcesSave(roots);
            if (!r.ok) { toast('保存失败', r.error || '', 'err', 7000); return; }
            toast('已保存', r.note || '', 'ok', 6000);
            m.close();
            await load(root);
          } catch (e) { toast('保存失败', e.message, 'err', 7000); }
        },
      }),
    ],
  });
  body.querySelectorAll('[data-add]').forEach((b) => {
    b.onclick = () => {
      const v = b.dataset.add;
      if (!v) return;
      const ta = body.querySelector('#src-list');
      if (!ta.value.split('\n').map((x) => x.trim()).includes(v)) {
        ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + v;
      }
    };
  });
}

/* ---------------- 环境自检卡 ---------------- */

function envCard() {
  const e = envFull;
  if (!e) return '';
  const warn = e.warnings || [];
  const gpu = e.gpu || {};
  const ff = e.ffmpeg || {};
  const py = e.python || [];
  const pyBad = py.filter((p) => p.required && !p.ok);
  const tools = e.tools || {};
  const assets = e.assets || {};
  const proxy = e.proxy || {};
  const curl = e.curl || {};
  const okAll = warn.length === 0;

  const row = (label, ok, detail) => `
    <div class="litem" style="padding:5px 0">
      <span class="dot ${ok ? 'ok' : 'err'}"></span>
      <div class="litem-main">
        <div class="litem-title" style="font-size:10.5px">${esc(label)}</div>
        <div class="litem-sub" style="font-size:9px;color:var(--tx-3)">${esc(detail)}</div>
      </div>
    </div>`;

  return `
    <div class="card" style="margin-bottom:13px;border-color:${okAll
      ? 'rgba(52,211,153,.32)' : 'rgba(251,191,36,.4)'}">
      <div class="card-head">
        <div class="card-title">
          <span data-icon="shield"></span>
          运行环境自检
          <span class="badge ${okAll ? 'ok' : 'warn'}" style="margin-left:6px;font-size:9px">
            ${okAll ? '全部就绪' : `${warn.length} 项待处理`}
          </span>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn xs ghost" data-envcheck><span data-icon="refresh"></span>重新检测</button>
          ${!okAll ? `<button class="btn xs primary" data-envinstall><span data-icon="down"></span>一键安装缺失</button>` : ''}
        </div>
      </div>
      <div class="card-body">
        <div class="grid g2" style="gap:0 22px">
          <div>
            ${row('Python ' + (e.platform?.python || ''),
              pyBad.length === 0,
              pyBad.length ? `缺 ${pyBad.map((p) => p.name).join('、')}` : `${py.filter((p) => p.ok).length}/${py.length} 依赖就绪`)}
            ${row('FFmpeg', ff.ok, ff.ok
              ? `${ff.bundled ? '内置' : '系统'} · ${ff.version.split(' ')[2] || ''}${ff.nvenc ? ' · NVENC' : ' · 仅 CPU'}`
              : (ff.hint || '未找到 ffmpeg'))}
            ${row('GPU 硬件编码', gpu.ok, gpu.ok
              ? `${gpu.name}${gpu.driver ? ' · 驱动 ' + gpu.driver : ''}`
              : (gpu.hint || '未检测到 NVIDIA GPU，将用 CPU 编码'))}
            ${row('切片脚本', tools.ok,
              tools.ok ? `${tools.dir} · ${Object.keys(tools.scripts || {}).length} 个齐全`
                : `缺 ${(tools.missing || []).join('、')}`)}
          </div>
          <div>
            ${row('字体 / BGM', assets.ok,
              assets.ok ? `${assets.fontCount} 字体 · ${assets.bgmCount} BGM · ${assets.sfxCount} 音效`
                : (assets.hint || '字体或音频缺失'))}
            ${row('抓取代理', proxy.alive,
              proxy.alive ? `${proxy.proxy} 可用` : (proxy.hint || '代理不通，抓取会失败'))}
            ${row('curl', curl.ok, curl.ok ? curl.version.slice(0, 46) : (curl.hint || '缺少 curl.exe'))}
            ${row('数据目录', true, e.platform?.dataDir || '')}
          </div>
        </div>
        ${warn.length ? `
        <div style="margin-top:9px;padding:9px 11px;border-radius:var(--r-sm);
                    background:rgba(251,191,36,.07);border:1px solid rgba(251,191,36,.28);
                    font-size:10.5px;line-height:1.85;color:var(--warn)">
          ${warn.map((w) => `<div>· ${esc(w)}</div>`).join('')}
        </div>` : ''}
      </div>
    </div>`;
}

async function runEnvInstall(root) {
  const m = modal({
    title: '一键安装缺失依赖',
    width: 'mid',
    body: (() => {
      const d = document.createElement('div');
      d.innerHTML = `
        <div style="font-size:11px;line-height:1.9;color:var(--tx-2);margin-bottom:10px">
          会按顺序尝试：<b>pip</b> 装 Python 包 → <b>winget</b> / <b>choco</b> 装 ffmpeg。<br/>
          <span style="color:var(--tx-3);font-size:10.5px">
            没有包管理器时会返回手动安装命令，照着跑一遍即可。</span>
        </div>
        <pre id="env-log" style="font-family:var(--mono);font-size:9.5px;line-height:1.7;
             background:var(--bg-0);border-radius:var(--r-sm);padding:10px;
             max-height:260px;overflow:auto;white-space:pre-wrap;color:var(--tx-2)">准备中…</pre>`;
      return d;
    })(),
    footer: [Object.assign(document.createElement('button'),
      { className: 'btn primary', textContent: '关闭', onclick: () => m.close() })],
  });
  const logEl = m.el.querySelector('#env-log');
  const say = (t) => { logEl.textContent += `\n${t}`; logEl.scrollTop = logEl.scrollHeight; };
  logEl.textContent = '开始安装…';
  try {
    const r = await api.envInstall('all');
    (r.steps || []).forEach((s) => {
      say(`[${s.ok ? 'OK' : '!!'}] ${s.what}: ${s.detail || ''}`);
      (s.log || []).slice(-6).forEach((l) => say('    ' + l));
    });
    say('');
    say(r.ok ? '✅ 安装流程结束，正在重新检测…' : '⚠ 部分项目未装上，见上方日志');
    if (!r.ok && (r.manual || []).length) {
      say('');
      say('手动安装命令：');
      (r.manual || []).forEach((c) => say('  ' + c));
    }
    await load(root);
  } catch (e) {
    say('❌ ' + e.message);
  }
}

/* ---------------- 校验动作 ---------------- */

async function verifyFile(path, btn) {
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '校验中…';
  try {
    const r = await api.sliceVerify(path);
    const checks = r.checks || r.items || [];
    const bad = checks.filter((c) => c.ok === false);
    openResult('成片校验 · ' + path.split('\\').pop(), {
      ok: bad.length === 0 && r.ok !== false,
      rows: checks.map((c) => [c.name || c.key, `${c.value ?? ''} ${c.unit || ''}`.trim(),
        c.ok === false ? 'fail' : 'ok', c.note || '']),
      raw: r,
    });
  } catch (e) { toast('校验失败', e.message, 'err', 7000); }
  finally { btn.disabled = false; btn.textContent = old; }
}

async function checkDialogue(root, drama) {
  const ep = curStatus?.ep || '';
  toast('校验中', '正在比对台词完整性…', 'info');
  try {
    const r = await api.sliceCheckDialogue(drama, ep);
    if (r.error) { toast('无法校验', r.error, 'err', 8000); return; }
    openResult(`台词完整性 · ${drama} ${r.ep || ''}`, {
      ok: r.ok,
      head: `${r.segments} 段 · 总时长 ${r.totalDur}s · 该集 ${r.epLines} 句台词`,
      rows: (r.detail || []).map((d) => [
        `段 ${d.seg}`, `${d.start}→${d.end}s（${d.dur}s）`,
        d.cut > 0 || d.overlap ? 'fail' : 'ok',
        d.cut > 0 ? `截断 ${d.cut} 句：${(d.cutText || []).join(' / ')}`
          : d.overlap ? `与上段重叠 ${Math.abs(d.gap)}s`
          : `${d.lines} 句台词`,
      ]),
      issues: r.issues || [],
      verdict: r.verdict,
      raw: r,
    });
  } catch (e) { toast('校验失败', e.message, 'err', 7000); }
}

async function audioGuard(path) {
  toast('检测中', '扫描静音段…', 'info');
  try {
    const r = await api.sliceAudioGuard(path);
    const rows = [];
    (r.silences_list || r.silences || []).forEach?.((s, i) => {
      if (typeof s === 'object') {
        rows.push([`静音 ${i + 1}`, `${s.start}s → ${s.end}s`, 'fail', `时长 ${s.dur}s`]);
      }
    });
    openResult('静音检测 · ' + path.split('\\').pop(), {
      ok: r.ok, head: r.verdict, rows,
      issues: r.ok ? [] : [`检出 ${Array.isArray(r.silences) ? r.silences : (r.silences_list || []).length} 段 ≥ 2s 静音`],
      verdict: r.verdict, raw: r,
    });
  } catch (e) { toast('检测失败', e.message, 'err', 7000); }
}

function openResult(title, opt) {
  const body = document.createElement('div');
  const rows = opt.rows || [];
  body.innerHTML = `
    <div class="card" style="margin-bottom:11px;border-color:${opt.ok
      ? 'rgba(52,211,153,.35)' : 'rgba(248,113,113,.4)'}">
      <div class="card-body" style="padding:11px 13px">
        <div style="font-size:12px;font-weight:600;color:${opt.ok ? 'var(--ok)' : 'var(--danger)'}">
          ${esc(opt.verdict || (opt.ok ? '✅ 通过' : '❌ 未通过'))}
        </div>
        ${opt.head ? `<div style="font-size:10.5px;color:var(--tx-3);margin-top:4px">${esc(opt.head)}</div>` : ''}
      </div>
    </div>
    ${(opt.issues || []).length ? `
    <div class="card" style="margin-bottom:11px;border-color:rgba(248,113,113,.4);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="padding:10px 13px;font-size:10.5px;line-height:1.9">
        ${opt.issues.map((x) => `<div style="color:var(--danger)">· ${esc(x)}</div>`).join('')}
      </div>
    </div>` : ''}
    ${rows.length ? `
    <div class="card"><div class="card-body" style="padding:0;max-height:340px;overflow-y:auto">
      ${rows.map(([a, b, st, c]) => `
        <div class="litem" style="padding:6px 13px;border-bottom:1px solid var(--line)">
          <span class="dot ${st === 'fail' ? 'err' : 'ok'}"></span>
          <div class="litem-main">
            <div class="litem-title" style="font-size:10.5px">${esc(a)} · ${esc(b)}</div>
            ${c ? `<div class="litem-sub" style="font-size:9px;color:${st === 'fail'
              ? 'var(--danger)' : 'var(--tx-3)'}">${esc(c)}</div>` : ''}
          </div>
        </div>`).join('')}
    </div></div>` : ''}
    <details style="margin-top:11px">
      <summary style="cursor:pointer;font-size:10px;color:var(--tx-3)">原始返回</summary>
      <pre style="font-size:9.5px;color:var(--tx-2);white-space:pre-wrap;
                  word-break:break-all;max-height:200px;overflow:auto;margin-top:6px">${esc(JSON.stringify(opt.raw, null, 1))}</pre>
    </details>`;
  const m = modal({
    title, width: 'wide', body,
    footer: [Object.assign(document.createElement('button'),
      { className: 'btn primary', textContent: '关闭', onclick: () => m.close() })],
  });
}

function paintStatus(s) {
  const st = s.steps || {};
  return `
    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.28)">
      <div class="card-head">
        <div class="card-title">${esc(s.drama)} 详情</div>
        <span class="chip">${s.sourceEpisodes} 集源片</span>
      </div>
      <div class="card-body">
        <div class="grid g4" style="gap:9px;margin-bottom:12px">
          ${[
            ['转录', st.transcribe?.segments || 0, '句'],
            ['语音检测', st.voice?.checked || 0, '项'],
            ['类型', st.classify?.typeName || '未判定', ''],
            ['张力打分', st.tension?.lines || 0, '句'],
          ].map(([k, v, u]) => `
            <div style="background:var(--bg-0);border-radius:var(--r-sm);padding:9px 11px">
              <div style="font-size:10px;color:var(--tx-3);margin-bottom:3px">${k}</div>
              <div style="font-size:13px;font-weight:600">${v} <span style="font-size:10px;color:var(--tx-3)">${u}</span></div>
            </div>`).join('')}
        </div>

        ${st.classify?.rhythm ? `
        <div class="card" style="margin-bottom:11px;border-color:rgba(52,211,153,.3);
                                  background:rgba(52,211,153,.04)">
          <div class="card-body" style="padding:10px 12px">
            <div class="kv"><span class="k">节奏</span><span class="v">${esc(st.classify.rhythm)}</span></div>
            <div class="kv"><span class="k">BGM</span>
              <span class="v" style="font-family:var(--mono)">${(st.classify.bgm || []).join(' / ')}</span></div>
          </div>
        </div>` : ''}

        ${(s.tensionTop || []).length ? `
        <div class="section-title">张力 Top 10</div>
        <div style="max-height:200px;overflow-y:auto;margin-bottom:11px">
          ${(s.tensionTop || []).slice(0, 10).map((x, i) => `
            <div class="litem" style="padding:5px 0">
              <span style="width:18px;font-family:var(--mono);font-size:9.5px;
                           color:${i < 3 ? 'var(--ac)' : 'var(--tx-3)'}">${i + 1}</span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:10.5px">${esc(x.text)}</div>
                <div class="litem-sub" style="font-size:9px">${esc(x.ep || '')}</div>
              </div>
              <span style="font-family:var(--mono);font-size:10px;color:var(--ac)">
                ${(x.score || 0).toFixed(2)}
              </span>
            </div>`).join('')}
        </div>` : ''}

        ${(s.planStages || []).length ? `
        <div class="section-title">精品混剪 5 阶段</div>
        <div style="margin-bottom:11px">
          ${(s.planStages || []).map((g, i) => `
            <div class="litem" style="padding:4px 0">
              <span class="dot ok"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:10.5px">
                  ${esc(g.name || g.stage || `阶段 ${i + 1}`)}
                </div>
                <div class="litem-sub" style="font-size:9px">
                  ${g.segments ? `${g.segments.length} 段` : ''}
                  ${g.dur ? ` · ${g.dur}s` : ''}
                </div>
              </div>
            </div>`).join('')}
        </div>` : ''}

        ${(st.single?.files || []).length || (st.premium?.files || []).length ? `
        <div class="section-title">已出成片</div>
        <div style="max-height:180px;overflow-y:auto">
          ${(st.single?.files || []).map((f) => `
            <div class="litem" style="padding:4px 0">
              <div class="litem-main">
                <div class="litem-title" style="font-size:10px">${esc(f.split('\\').pop())}</div>
                <div class="litem-sub" style="font-size:9px;color:var(--tx-3)">${esc(f)}</div>
              </div>
              <button class="btn xs ghost" data-audioguard="${esc(f)}">静音</button>
              <button class="btn xs ghost" data-verify="${esc(f)}">校验</button>
            </div>`).join('')}
          ${(st.premium?.files || []).map((f) => `
            <div class="litem" style="padding:4px 0">
              <span class="badge purple" style="font-size:8.5px">主线</span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:10px">${esc(f.split('\\').pop())}</div>
                <div class="litem-sub" style="font-size:9px;color:var(--tx-3)">${esc(f)}</div>
              </div>
              <button class="btn xs ghost" data-audioguard="${esc(f)}">静音</button>
              <button class="btn xs ghost" data-verify="${esc(f)}">校验</button>
            </div>`).join('')}
        </div>` : ''}

        <div class="section-title">流程校验</div>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:4px">
          <button class="btn xs" data-dlgcheck="${esc(s.drama)}">
            <span data-icon="check"></span>台词完整性
          </button>
          ${(st.single?.files || [])[0] ? `
          <button class="btn xs" data-audioguard="${esc((st.single.files || [])[0])}">
            <span data-icon="play"></span>静音检测
          </button>` : ''}
        </div>
      </div>
    </div>`;
}

function openRun(root, drama) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>选剧</label>
      <select class="select" id="sl-drama">
        ${dramas.map((d) => `<option value="${esc(d.drama)}" ${drama === d.drama ? 'selected' : ''}>
          ${esc(d.title || d.drama)} · ${d.episodes} 集
        </option>`).join('')}
      </select>
    </div>
    <div class="row-2">
      <div class="field"><label>whisper 模型</label>
        <select class="select" id="sl-model">
          <option value="small">small（默认，20集43秒）</option>
          <option value="medium">medium（疑难集，慢但准）</option>
        </select>
      </div>
      <div class="field"><label>单集目标时长（秒）</label>
        <input class="input" id="sl-target" type="number" value="45" min="30" max="60" /></div>
    </div>
    <div class="field">
      <div style="display:flex;flex-direction:column;gap:8px">
        <label class="switch"><input type="checkbox" id="sl-single" checked />
          <span class="track"></span><span class="lbl">单集线（40-55s，段边界对齐台词）</span></label>
        <label class="switch"><input type="checkbox" id="sl-premium" checked />
          <span class="track"></span><span class="lbl">精品混剪线（5 阶段，120-150s）</span></label>
      </div>
    </div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;
                color:var(--tx-2);line-height:1.8">
      <b>耗时</b>：转录 20 集约 43 秒（GPU）· 语音检测 1-2 分钟 ·
      单集每集约 30 秒 · 精品混剪 3-5 分钟。<br/>
      <b>校验</b>：跑完自动校验时长/分辨率/帧率/响度/静音段。
    </div></div>`;
  const m = modal({
    title: '开始切片', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始',
        onclick: async () => {
          const d = body.querySelector('#sl-drama').value;
          if (!d) return toast('没有可处理的剧', '', 'err');
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '提交中…';
          try {
            const r = await api.sliceRun({
              drama: d,
              model: body.querySelector('#sl-model').value,
              target: parseFloat(body.querySelector('#sl-target').value) || 45,
              single: body.querySelector('#sl-single').checked,
              premium: body.querySelector('#sl-premium').checked,
            });
            toast('已入队', `任务 ${r.jobId}`, 'ok');
            m.close();
            const t0 = Date.now();
            while (Date.now() - t0 < 7200000) {
              await new Promise((res) => setTimeout(res, 4000));
              const j = await api.job(r.jobId);
              if (['done', 'failed', 'blocked'].includes(j.status)) {
                toast(j.status === 'done' ? '切片完成' : '切片失败',
                  j.status === 'done' ? '成片已生成' : (j.error || ''),
                  j.status === 'done' ? 'ok' : 'err', 8000);
                break;
              }
            }
            await load(root);
          } catch (e) { toast('失败', e.message, 'err', 7000); }
          finally { btn.disabled = false; btn.textContent = '开始'; }
        },
      }),
    ],
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
