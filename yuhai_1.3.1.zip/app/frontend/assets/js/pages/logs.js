/* 运行日志（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import { pageHead, $, $$, toast, copyText, badge, ts } from '../ui.js';

let lvl = 'all';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '运行日志',
      desc: '后端事件流：任务、采集、风控、邮件',
      actions: [
        `<button class="btn sm" data-act="copy"><span data-icon="copy"></span>复制全部</button>`,
        `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
      ],
    })}
    <div id="lg-body"></div>
  `;
  $$('[data-act="copy"]', root).forEach((b) => (b.onclick = () => {
    copyText((store.events || []).map((e) => `${e.ts} ${e.level} [${e.source}] ${e.msg}`).join('\n'));
  }));
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  paint(root);
  load(root);
}

async function load(root) {
  await store.loadEvents(300);
  paint(root);
}

function paint(root) {
  const body = $('#lg-body', root);
  if (!body) return;
  const evs = store.events || [];
  const list = lvl === 'all' ? evs : evs.filter((e) => e.level === lvl);
  const cnt = (k) => evs.filter((e) => e.level === k).length;

  body.innerHTML = `
    <div class="card">
      <div class="card-head">
        <div class="card-title">事件流 <span class="sub">${evs.length} 条</span></div>
        <div class="seg" data-seg="lvl">
          <button class="${lvl === 'all' ? 'on' : ''}" data-v="all">全部</button>
          <button class="${lvl === 'info' ? 'on' : ''}" data-v="info">INFO ${cnt('info')}</button>
          <button class="${lvl === 'ok' ? 'on' : ''}" data-v="ok">OK ${cnt('ok')}</button>
          <button class="${lvl === 'warn' ? 'on' : ''}" data-v="warn">WARN ${cnt('warn')}</button>
          <button class="${lvl === 'err' ? 'on' : ''}" data-v="err">ERR ${cnt('err')}</button>
        </div>
      </div>
      <div class="card-body">
        <div class="term" id="lg-term" style="max-height:560px">
          ${list.length ? list.map((e) => {
            const t = (e.ts || '').slice(11, 19) || '—';
            return `
              <div class="ln">
                <span class="ts">${t}</span>
                <span class="lv ${e.level}">${(e.level || '').toUpperCase()}</span>
                <span class="msg"><span style="color:var(--tx-3)">[${esc(e.source || '')}]</span> ${esc(e.msg || '')}</span>
              </div>`;
          }).join('') : '<div class="ln"><span class="msg">暂无事件</span></div>'}
        </div>
      </div>
    </div>
  `;

  $$('[data-seg="lvl"] button', root).forEach((b) => {
    b.onclick = () => { lvl = b.dataset.v; paint(root); };
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
