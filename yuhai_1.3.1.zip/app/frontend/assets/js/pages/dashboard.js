/* 工作台概览（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  nfmt, statCard, sparkline, lineChart, bar, badge, pageHead,
  ts, ago, $, $$, toast, modal, emptyState,
} from '../ui.js';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '工作台概览',
      desc: '推广矩阵总览',
      actions: [
        `<button class="btn sm" data-act="sync"><span data-icon="refresh"></span>全量刷新</button>`,
        `<button class="btn sm primary" data-act="collect"><span data-icon="bolt"></span>采集数据</button>`,
      ],
    })}
    <div id="db-body"></div>
  `;
  $$('[data-act="sync"]', root).forEach((b) => (b.onclick = () => load(root, true)));
  $$('[data-act="collect"]', root).forEach((b) => (b.onclick = () => {
    location.hash = '#/analytics';
  }));
  paint(root);
  load(root);
}

async function load(root, manual = false) {
  try {
    await store.loadCore();
    await Promise.all([
      store.loadOverview(14), store.loadJobs(), store.loadGuard(),
      store.loadAuto().catch(() => {}),
    ]);
    if (manual) toast('已刷新', '数据已更新', 'ok', 1600);
  } catch (e) {
    toast('刷新失败', e.message, 'err');
  }
  paint(root);
  bindAuto(root);
}

/* ---------------- 全自动总控卡 ---------------- */
function autoCard(a) {
  if (!a || !a.items) {
    return `
    <div class="card" style="margin-bottom:13px">
      <div class="card-body" style="font-size:11px;color:var(--tx-3)">
        全自动总控加载中…
      </div>
    </div>`;
  }
  const on = !!a.enabled;
  const obs = !!a.observeOnly;
  return `
    <div class="card" style="margin-bottom:13px;border-color:${on
      ? 'rgba(52,211,153,.4)' : 'var(--line)'};
      ${on ? 'background:rgba(52,211,153,.03)' : ''}">
      <div class="card-head" style="align-items:flex-start">
        <div class="card-title" style="display:flex;flex-direction:column;gap:4px">
          <div style="display:flex;align-items:center;gap:7px">
            <span data-icon="bolt"></span>
            全自动
            <span class="badge ${on ? 'ok' : 'mute'}" style="font-size:9px">
              ${on ? '运行中' : '已停止'}</span>
            ${obs ? '<span class="badge warn" style="font-size:9px">只观察</span>' : ''}
          </div>
          <div style="font-size:9.5px;color:var(--tx-3);font-weight:400">
            ${on ? `${a.activeCount}/${a.totalCount} 项生效` : '所有自动流程已暂停'}
            · 不含排期和发布（永远手动）
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:9px">
          ${on ? '<button class="btn xs" id="auto-stop" style="color:var(--danger);border-color:rgba(248,113,113,.5)">急停</button>' : ''}
          <label class="switch" title="${on ? '点这里关掉全部自动流程' : '点这里开启全部自动流程'}">
            <input type="checkbox" id="auto-master" ${on ? 'checked' : ''} />
            <span class="track"></span>
          </label>
        </div>
      </div>
      <div class="card-body">
        <div class="grid g2" style="gap:4px 22px">
          ${a.items.map((it) => `
            <div class="litem" style="padding:6px 0;opacity:${on ? '1' : '.55'}">
              <span class="dot ${it.active ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:10.5px;display:flex;
                     align-items:center;gap:6px">
                  ${esc(it.name)}
                  ${it.intervalMin ? `<span class="chip ghost" style="font-size:8px">
                    ${it.intervalMin >= 60 ? (it.intervalMin / 60) + 'h' : it.intervalMin + 'm'}</span>` : ''}
                </div>
                <div class="litem-sub" style="font-size:9px;color:var(--tx-3)">
                  ${esc(it.desc)}
                  ${it.note ? `<span style="color:var(--tx-2)"> · ${esc(it.note)}</span>` : ''}
                </div>
              </div>
              <label class="switch" style="transform:scale(.8)">
                <input type="checkbox" class="auto-item" data-key="${esc(it.key)}"
                       ${it.subOn ? 'checked' : ''} ${on ? '' : 'disabled'} />
                <span class="track"></span>
              </label>
            </div>`).join('')}
        </div>

        <div style="margin-top:11px;padding:9px 11px;border-radius:var(--r-sm);
                    background:var(--bg-0);font-size:9.5px;color:var(--tx-3);
                    line-height:1.8">
          <b style="color:var(--tx-2)">永远手动（不受此开关影响）</b>：
          ${(a.manualOnly || []).map((m) => `<span class="chip ghost"
            style="font-size:8.5px;margin:0 3px" title="${esc(m.desc)}">${esc(m.name)}</span>`).join('')}
        </div>

        <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)">
          <div style="display:flex;align-items:center;gap:7px;margin-bottom:7px">
            <span style="font-size:10px;color:var(--tx-2);font-weight:600">
              一键跑一轮</span>
            <span style="font-size:9px;color:var(--tx-3)">
              没空的时候手动点，不用等间隔，也不受总开关限制</span>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${(a.quickActions || []).map((q) => `
              <button class="btn xs" data-quick="${esc(q.key)}" title="${esc(q.desc)}">
                ${esc(q.name)}
              </button>`).join('')}
          </div>
        </div>
      </div>
    </div>`;
}

function bindAuto(root) {
  const master = document.getElementById('auto-master');
  if (master) {
    master.onchange = async () => {
      const on = master.checked;
      master.disabled = true;
      try {
        store.auto = await api.autoMaster(on);
        toast(on ? '全自动已开启' : '全自动已关闭',
          on ? '评论区维护/数据采集/风控巡检等已启动' : '所有自动流程已暂停', 'ok', 5000);
        paint(root); bindAuto(root);
      } catch (e) {
        master.checked = !on;
        toast('切换失败', e.message, 'err', 6000);
      } finally { master.disabled = false; }
    };
  }
  document.querySelectorAll('.auto-item').forEach((el) => {
    el.onchange = async () => {
      const key = el.dataset.key;
      el.disabled = true;
      try {
        store.auto = await api.autoItem(key, el.checked);
        paint(root); bindAuto(root);
      } catch (e) {
        el.checked = !el.checked;
        toast('切换失败', e.message, 'err', 6000);
      } finally { el.disabled = false; }
    };
  });
  const stop = document.getElementById('auto-stop');
  if (stop) {
    stop.onclick = async () => {
      if (!confirm('一键急停：关闭所有自动流程，并开启「只观察」模式。\n（发布/建主页会被拦截，只记录不动作）')) return;
      try {
        store.auto = await api.autoStop();
        toast('已急停', '全部自动关闭 + 只观察已开', 'ok', 6000);
        paint(root); bindAuto(root);
      } catch (e) { toast('急停失败', e.message, 'err', 6000); }
    };
  }
  document.querySelectorAll('[data-quick]').forEach((b) => {
    b.onclick = async () => {
      const key = b.dataset.quick;
      const name = b.textContent.trim();
      const old = b.textContent;
      b.disabled = true; b.textContent = '执行中…';
      toast('已开始', name + '（后台执行，完成后会提示）', 'info', 5000);
      try {
        const r = await api.autoQuick(key);
        const jobId = r.jobId;
        if (!jobId) throw new Error('提交失败');
        // 轮询任务进度（评论/采集可能跑几分钟）
        const t0 = Date.now();
        while (Date.now() - t0 < 1800000) {
          await new Promise((res) => setTimeout(res, 6000));
          const j = await api.job(jobId);
          if (j.status === 'done') {
            const inner = (j.result && j.result.result) || j.result || {};
            let detail = '';
            if (key === 'comments') {
              detail = `${inner.reply || 0} 条回复 · ${inner.delete || 0} 条删除`
                + ` · 覆盖 ${inner.pages || 0} 个主页`;
            } else if (key === 'metrics') {
              detail = `${inner.ok || 0} 采集成功 · ${inner.fail || 0} 失败`;
            } else {
              detail = `${inner.checked || 0} 个主页检查 · ${inner.blocked || 0} 个异常`;
            }
            toast('完成', detail
              + ((j.result && j.result.observeOnly) ? '（只观察模式：未实际动作）' : ''),
              'ok', 9000);
            break;
          }
          if (j.status === 'failed') {
            toast('执行失败', j.error || '未知错误', 'err', 9000);
            break;
          }
        }
        await store.loadAuto();
        paint(root); bindAuto(root);
      } catch (e) {
        toast('执行失败', e.message, 'err', 7000);
      } finally { b.disabled = false; b.textContent = old; }
    };
  });
}

function paint(root) {
  const body = $('#db-body', root);
  if (!body) return;
  const s = store.summary || {};
  const ov = store.overview || {};
  const auto = store.auto || {};
  const daily = ov.daily || [];
  const jobs = store.jobs || [];
  const pages = store.pages || [];
  const g = store.guard || {};

  const playsTotal = daily.reduce((a, d) => a + (d.plays || 0), 0);
  const clicksTotal = daily.reduce((a, d) => a + (d.clicks || 0), 0);
  const running = jobs.filter((j) => j.status === 'running');
  const blocked = jobs.filter((j) => j.status === 'blocked');

  body.innerHTML = `
    ${autoCard(auto)}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '14 天播放', value: nfmt(playsTotal), unit: '次', iconName: 'eye' })}
      ${statCard({ label: '出站点击', value: nfmt(clicksTotal), unit: '次', iconName: 'link',
                   foot: playsTotal ? `CTR ${((clicksTotal / playsTotal) * 100).toFixed(2)}%` : '' })}
      ${statCard({ label: '视频条数', value: s.videoCount || 0, unit: '条', iconName: 'video',
                   foot: `${s.pages || 0} 个主页` })}
      ${statCard({
        label: '风控状态', value: g.blocked ? '已熔断' : '正常', unit: '',
        iconName: g.blocked ? 'warn' : 'shield',
        foot: g.blocked ? `${g.count} 个待处理` : '无异常',
      })}
    </div>

    ${g.blocked ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="display:flex;gap:11px;align-items:center">
        <span style="color:var(--danger)">${icon('warn', 17)}</span>
        <div style="flex:1;font-size:12px;color:var(--tx-1)">
          <b style="color:var(--danger)">风控熔断中</b>：${g.latest?.message || ''}
        </div>
        <button class="btn sm danger" data-go="guard">处理</button>
      </div>
    </div>` : ''}

    <div class="grid" style="grid-template-columns:1.6fr 1fr;margin-bottom:13px">
      <div class="card">
        <div class="card-head">
          <div class="card-title">播放趋势 <span class="sub">近 14 天全部视频</span></div>
        </div>
        <div class="card-body">
          ${daily.length >= 2
            ? lineChart(daily.map((d) => ({ date: d.date, views: d.plays || 0 })), { key: 'views' })
            : `<div style="padding:44px 20px;text-align:center">
                 ${daily.length === 1
                   ? `<div style="font-size:12.5px;color:var(--tx-1);margin-bottom:5px">
                        今天已采集 ${nfmt(daily[0].plays)} 次播放
                      </div>
                      <div style="font-size:11px;color:var(--tx-3);line-height:1.7">
                        趋势曲线需要 ≥2 天快照，每天采一次就会累积
                      </div>`
                   : `<div style="font-size:12.5px;color:var(--tx-2)">暂无数据</div>
                      <div style="font-size:11px;color:var(--tx-3);margin-top:4px">
                        去「视频数据」页点采集
                      </div>`}
               </div>`}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">环境</div>
          <span class="chip">${(store.envs || []).filter((e) => e.status === 'running').length} 个运行中</span>
        </div>
        <div class="card-body tight">
          ${(store.envs || []).map((e) => `
            <div class="litem">
              <span class="dot ${e.status === 'running' ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title">${esc(e.name)}
                  ${badge(e.roleLabel, e.role === 'publisher' ? 'info' : e.role === 'backup' ? 'purple' : 'mute')}
                </div>
                <div class="litem-sub">${e.containerCode} · ${e.account || '未登录'}${e.cdpPort ? ' · CDP ' + e.cdpPort : ''}</div>
              </div>
            </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无环境</div>'}
        </div>
      </div>
    </div>

    <div class="grid" style="grid-template-columns:1fr 1.2fr;margin-bottom:13px">
      <div class="card">
        <div class="card-head">
          <div class="card-title">任务 <span class="sub">${running.length} 运行中</span></div>
          <button class="btn xs ghost" data-go="logs">日志</button>
        </div>
        <div class="card-body tight">
          ${jobs.slice(0, 6).map((j) => {
            const st = j.status === 'running' ? ['执行中', 'info']
              : j.status === 'done' ? ['完成', 'ok']
              : j.status === 'blocked' ? ['受阻', 'danger']
              : j.status === 'failed' ? ['失败', 'danger'] : ['排队', 'mute'];
            return `
              <div class="litem">
                <div class="litem-main">
                  <div class="litem-title">${esc(j.title)} ${badge(st[0], st[1], j.status === 'running')}</div>
                  <div class="litem-sub">${j.id} · ${j.progress || 0}%</div>
                  <div style="margin-top:6px">${bar(j.progress || 0, j.status === 'blocked' || j.status === 'failed' ? 'danger' : j.status === 'done' ? 'ok' : '')}</div>
                </div>
              </div>`;
          }).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无任务</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">Top 视频 <span class="sub">按播放</span></div>
          <button class="btn xs ghost" data-go="analytics">全部</button>
        </div>
        <div class="card-body tight">
          ${(ov.topVideos || []).slice(0, 6).map((t, i) => `
            <div class="litem">
              <span style="width:20px;text-align:center;font-family:var(--mono);font-size:11px;
                           color:${i < 3 ? 'var(--ac)' : 'var(--tx-3)'}">${i + 1}</span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">${esc((t.title || '').slice(0, 46))}</div>
                <div class="litem-sub">${t.page_name || ''}</div>
              </div>
              <span style="font-family:var(--mono);font-size:11.5px;font-weight:600">${nfmt(t.plays)}</span>
            </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">暂无数据</div>'}
        </div>
      </div>
    </div>

    <div class="grid g3">
      <div class="card">
        <div class="card-head"><div class="card-title">待办</div></div>
        <div class="card-body tight">
          ${buildTodos(pages, g).map(([t, d, k]) => `
            <div class="litem">
              <span class="dot ${k === 'danger' ? 'bad' : k === 'warn' ? 'warn' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title">${t}</div>
                <div class="litem-sub" style="font-family:var(--sans)">${d}</div>
              </div>
            </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无待办</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">最近验证码</div></div>
        <div class="card-body tight">
          ${(store.mails || []).filter((m) => m.code).slice(0, 3).map((m) => `
            <div class="litem">
              <div class="litem-main">
                <div class="litem-title">${(m.mailbox || '').split('@')[0]}
                  <span class="badge mute">${m.source}</span></div>
                <div class="litem-sub">${esc((m.subject || '').slice(0, 34))}</div>
              </div>
              <span class="mail-code">${m.code}</span>
            </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">系统</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">后端</span><span class="v" style="color:var(--ok)">127.0.0.1:8710</span></div>
          <div class="kv"><span class="k">主页</span><span class="v">${store.pages.length} 个</span></div>
          <div class="kv"><span class="k">视频</span><span class="v">${s.videoCount || 0} 条</span></div>
          <div class="kv"><span class="k">风控事件</span><span class="v" style="color:${g.count ? 'var(--danger)' : 'var(--ok)'}">${g.count || 0} 未处理</span></div>
          <div class="kv"><span class="k">最近采集</span><span class="v">${store.videos[0]?.collectedAt ? ago(store.videos[0].collectedAt) : '—'}</span></div>
        </div>
      </div>
    </div>
  `;

  $$('[data-go]', root).forEach((b) => {
    b.onclick = () => { location.hash = `#/${b.dataset.go}`; };
  });
}

function buildTodos(pages, g) {
  const out = [];
  if (g.blocked) out.push(['风控熔断待处理', g.latest?.message || '去风控中心解除', 'danger']);
  const noAsset = pages.filter((p) => !p.assetId);
  if (noAsset.length) out.push([`${noAsset.length} 个主页缺 asset_id`, '无法发布与采集，需重新提取', 'warn']);
  const noBackup = pages.filter((p) => !p.authz || !p.authz.backup || !p.authz.backup.present);
  if (noBackup.length) out.push([`${noBackup.length} 个主页备份号未覆盖`, '主号受限时无法接管', 'warn']);
  const restricted = pages.filter((p) => p.health !== 'ok');
  if (restricted.length) out.push([`${restricted.length} 个主页受限`, '退避后再试', 'warn']);
  return out.slice(0, 4);
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
