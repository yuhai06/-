/* 评论区维护（真实数据）
   评论用英文引导 + 必须带链接；删除针对恶评 / 蹭量引流 / 违规言论。
   删除是不可恢复操作，默认演练。 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let tab = 'run';          // run | watch | history
let fetched = [];         // 已抓到的评论
let planResult = null;
let histData = { items: [], stats: [] };
let watchData = null;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '评论区维护',
      desc: '英文话术引导点击链接 · 自动清理恶评 / 蹭量引流 / 违规言论 · 支持常驻托管',
      actions: [
        `<button class="btn sm primary" data-act="instant"><span data-icon="bolt"></span>一键评论</button>`,
        `<button class="btn sm" data-act="fetch"><span data-icon="refresh"></span>抓取评论</button>`,
        `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
      ],
    })}
    <div id="cm-body"></div>
  `;
  $$('[data-act="fetch"]', root).forEach((b) => (b.onclick = () => openFetch(root)));
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  $$('[data-act="instant"]', root).forEach((b) => (b.onclick = () => instant(root, b)));
  paint(root);
  load(root);
}

/* 一键评论：立刻跑一轮，不等待定间隔（没空时手动触发） */
async function instant(root, btn) {
  const old = btn.innerHTML;
  btn.disabled = true;
  btn.textContent = '执行中…';
  toast('已开始', '正在扫描全部主页的评论（约 3-6 分钟）', 'info', 5000);
  try {
    const r = await api.autoQuick('comments');
    const jobId = r.jobId;
    if (!jobId) throw new Error('提交失败');
    const t0 = Date.now();
    let lastProg = -1;
    while (Date.now() - t0 < 1800000) {
      await new Promise((res) => setTimeout(res, 6000));
      const j = await api.job(jobId);
      if (j.progress !== lastProg && j.progress > 0) {
        lastProg = j.progress;
        btn.textContent = `执行中 ${j.progress}%`;
      }
      if (j.status === 'done') {
        const res = j.result?.result || j.result || {};
        toast('一轮完成',
          `${res.reply || 0} 条回复 · ${res.delete || 0} 条删除 · 覆盖 ${res.pages || 0} 个主页`
          + (j.result?.observeOnly ? '（只观察模式：未实际动作）' : ''),
          'ok', 9000);
        break;
      }
      if (j.status === 'failed') {
        toast('执行失败', j.error || '未知错误', 'err', 9000);
        break;
      }
    }
    await load(root);
  } catch (e) {
    toast('执行失败', e.message, 'err', 8000);
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

async function load(root) {
  try {
    await store.loadCore();
    histData = await api.commentHistory();
    store.commentQuota = await api.commentQuota().then((d) => d.items || []);
    store.commentTpl = await api.commentTemplates();
    watchData = await api.watchStatus();
  } catch (e) {
    console.warn(e.message);
  }
  paint(root);
}

function paint(root) {
  const body = $('#cm-body', root);
  if (!body) return;
  const tpl = store.commentTpl || { templates: [], limits: {}, linkCount: 0 };
  const quotas = store.commentQuota || [];
  const hist = histData.items || [];

  const rep = hist.filter((x) => x.action === 'reply' && !x.dry).length;
  const del = hist.filter((x) => x.action === 'delete' && !x.dry).length;
  const linkOk = tpl.linkCount > 0;

  body.innerHTML = `
    ${!linkOk ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="display:flex;gap:10px;align-items:center">
        <span style="color:var(--danger)">${icon('warn', 16)}</span>
        <div style="flex:1;font-size:11.5px;color:var(--tx-1)">
          <b style="color:var(--danger)">没有配置推广链接</b> —— 评论回复必须带链接，
          否则不会发送。先去「授权管理 → 推广链接」加一条。
        </div>
        <button class="btn sm danger" data-go="authz">去配置</button>
      </div>
    </div>` : ''}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '已回复', value: rep, unit: '条', iconName: 'mail',
                   foot: '引导点击链接' })}
      ${statCard({ label: '已删除', value: del, unit: '条', iconName: 'trash',
                   foot: '恶评/引流/违规' })}
      ${statCard({ label: '推广链接', value: tpl.linkCount, unit: '条', iconName: 'link',
                   foot: linkOk ? '回复会自动附上' : '缺链接，无法回复' })}
      ${statCard({ label: '回复模板', value: (tpl.templates || []).length, unit: '个',
                   iconName: 'chat' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="tabs" style="border:none;padding:0;margin:0">
          <div class="tab ${tab === 'run' ? 'active' : ''}" data-tab="run">
            执行面板 ${fetched.length ? `<span class="cnt">${fetched.length}</span>` : ''}
          </div>
          <div class="tab ${tab === 'watch' ? 'active' : ''}" data-tab="watch">
            常驻托管
            ${watchData && watchData.watcherRunning
              ? '<span class="nav-badge ok" style="font-size:8.5px;margin-left:4px">运行中</span>' : ''}
          </div>
          <div class="tab ${tab === 'history' ? 'active' : ''}" data-tab="history">
            操作历史 <span class="cnt">${hist.length}</span>
          </div>
        </div>
      </div>
      <div class="card-body" id="cm-inner"></div>
    </div>
  `;

  $$('[data-tab]', root).forEach((t) => {
    t.onclick = () => { tab = t.dataset.tab; paint(root); };
  });
  $$('[data-go]', root).forEach((b) => (b.onclick = () => { location.hash = `#/${b.dataset.go}`; }));

  const inner = $('#cm-inner', root);
  if (tab === 'history') return paintHistory(inner, hist);
  if (tab === 'watch') return paintWatch(inner, root, watchData || {});
  paintRun(inner, root, tpl, quotas);
}

/* ---------------- 常驻托管 ---------------- */
function paintWatch(inner, root, w) {
  const cfg = w.config || {};
  const running = w.watcherRunning;
  const procs = w.backendProcs || [];
  const quiet = w.inQuietHours;
  const cov = w.coverage || {};

  inner.innerHTML = `
    <div class="grid g3" style="margin-bottom:13px">
      ${statCard({ label: '轮询状态', value: running ? '运行中' : '已停止', unit: '',
                   iconName: running ? 'bolt' : 'warn',
                   foot: w.lastTick ? `上次 ${w.lastTick.slice(11, 19)}` : '尚未运行' })}
      ${statCard({ label: '轮询间隔', value: cfg.intervalMin || 15, unit: '分钟',
                   iconName: 'clock', foot: `每轮 ${cfg.pagesPerRound || 5} 个主页` })}
      ${statCard({ label: '计划任务', value: w.scheduledTask || '未知', unit: '',
                   iconName: 'shield',
                   foot: w.scheduledTask === '已安装' ? '软件关了也能跑' : '建议安装' })}
    </div>

    ${quiet ? `<div class="card" style="margin-bottom:13px;border-color:rgba(251,191,36,.35)">
      <div class="card-body" style="font-size:11.5px;color:var(--warn)">
        当前处于静默时段（${(cfg.quietHours || []).join(':00, ')}:00），不动作 —— 模拟人类睡觉，降低被识别风险。
      </div></div>` : ''}

    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.4);
                              background:rgba(248,113,113,.04)">
      <div class="card-body">
        <div style="font-size:12.5px;font-weight:620;color:var(--danger);margin-bottom:7px">
          关机期间是<b>完全不跑</b>的
        </div>
        <div style="font-size:11.5px;color:var(--tx-1);line-height:1.8">
          必须说清楚：电脑一关等进程就没了，任何本地程序都不可能在关机状态下工作。
          下面那些只是「<b>让它在能跑的时候一定在跑</b>」，不是「关机也能跑」。<br/>
          <b>能做到</b>：开机后自动补一轮，把关机期间漏掉的评论捞回大部分。<br/>
          <b>做不到</b>：关机那段时间的实时响应 —— 那时候没有任何东西在运行。
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">真实覆盖情况</div>
        <span class="chip">${cov.lastRun ? `上次 ${cov.gapText}` : '尚未运行'}</span>
      </div>
      <div class="card-body">
        <div class="grid g2" style="gap:10px;margin-bottom:12px">
          <div style="background:var(--bg-0);border-radius:var(--r-sm);padding:10px 12px">
            <div style="font-size:10.5px;color:var(--tx-3);margin-bottom:3px">轮询节奏</div>
            <div style="font-size:12.5px;font-weight:600">
              每 ${cov.intervalMin >= 60 ? (cov.intervalMin / 60) + ' 小时' : cov.intervalMin + ' 分钟'}
              → 最多 ${cov.perRound} 个主页
            </div>
            <div style="font-size:10px;color:var(--tx-3);margin-top:3px">
              ${esc(cov.fullCycleText || '')}
            </div>
          </div>
          <div style="background:var(--bg-0);border-radius:var(--r-sm);padding:10px 12px">
            <div style="font-size:10.5px;color:var(--tx-3);margin-bottom:3px">当前状态</div>
            <div style="font-size:12.5px;font-weight:600;
                        color:${running ? 'var(--ok)' : 'var(--danger)'}">
              ${running ? (quiet ? '运行中（静默时段）' : '运行中') : '已停止'}
            </div>
            <div style="font-size:10px;color:var(--tx-3);margin-top:3px">
              ${running ? '开机期间持续轮询' : '关机/关闭期间 0 覆盖'}
            </div>
          </div>
        </div>

        ${cfg.coverNewPages ? `
        <div class="card" style="margin-bottom:11px;border-color:rgba(52,211,153,.3);
                                  background:rgba(52,211,153,.04)">
          <div class="card-body" style="padding:9px 12px;font-size:10.5px;color:var(--tx-1);line-height:1.7">
            <b style="color:var(--ok)">新增主页优先覆盖已开启</b> ——
            排序规则是「从没查过的排最前，其次最久没查的」。所以你后面新建的主页，
            下一轮一定被扫到，不会被老主页挤掉。
          </div>
        </div>` : ''}

        <div class="tbl-wrap">
          <table class="tbl" style="font-size:11px">
            <thead><tr><th>场景</th><th>能否工作</th><th>覆盖情况</th></tr></thead>
            <tbody>
              <tr><td>软件开着 + 电脑开着</td><td>${badge('能', 'ok')}</td>
                <td>每 ${cov.intervalMin} 分钟轮一轮，覆盖最好</td></tr>
              <tr><td>关掉软件，电脑开着</td><td>${badge('能', 'ok')}</td>
                <td>计划任务 5 分钟内自动拉起后端，继续轮询</td></tr>
              <tr><td>电脑休眠 / 睡眠</td><td>${badge('不能', 'danger')}</td>
                <td>进程挂起，完全停止</td></tr>
              <tr><td>电脑关机</td><td>${badge('不能', 'danger')}</td>
                <td>完全停止，只有开机后补漏</td></tr>
              <tr><td>开机后</td><td>${badge('自动', 'info')}</td>
                <td>${cfg.catchUpOnBoot ? `自动补一轮（${cfg.catchUpPages || 12} 个主页）` : '未开启补漏'}</td></tr>
            </tbody>
          </table>
        </div>

        <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:12px;align-items:center">
          <button class="btn sm primary" id="cw-catchup">
            <span data-icon="bolt"></span>立刻补漏一轮
          </button>
          <label class="switch" style="margin:0">
            <input type="checkbox" id="cw-catchup-on" ${cfg.catchUpOnBoot ? 'checked' : ''} />
            <span class="track"></span><span class="lbl">开机自动补漏</span>
          </label>
        </div>
        <div class="hint" style="margin-top:8px">
          补漏一次看 ${cfg.catchUpPages || 12} 个主页（比常规 ${cov.perRound} 个多），优先处理最久没查过的。
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.3)">
      <div class="card-head"><div class="card-title">要真 7×24 覆盖，只有两条路</div></div>
      <div class="card-body">
        <div style="font-size:11.5px;color:var(--tx-1);line-height:1.9">
          <b>方案 A：部署到一台不关的机器</b><br/>
          <span style="color:var(--tx-2);font-size:11px">
            把后端放到一台 7×24 开着的 Windows VPS 或另一台常开的电脑。
            装好保活任务它就一直跑，你这台电脑只连它的网页界面，关机也不影响。<br/>
            代价：那台机器上也得有指纹浏览器和 FB 登录态。</span>
        </div>
        <div style="font-size:11.5px;color:var(--tx-1);line-height:1.9;margin-top:12px">
          <b>方案 B：降低实时性要求（我推荐）</b><br/>
          <span style="color:var(--tx-2);font-size:11px">
            把间隔拉长到 30–60 分钟，接受「一天查几轮」。评论维护本来不需要秒级响应 ——
            观众不会在意你晚两小时回。你正常用电脑的时间就够覆盖。</span>
        </div>
        <div style="margin-top:12px;padding:10px 12px;background:var(--bg-0);
                    border-radius:var(--r-sm);font-size:10.5px;color:var(--tx-3);line-height:1.7">
          建议先用方案 B：真实场景里评论不需要实时，账号安全比响应速度重要得多。
          高频轮询本身就是最容易被识别成机器人的信号之一。
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head"><div class="card-title">轮询配置</div></div>
      <div class="card-body">
        <div class="row-3">
          <div class="field"><label>间隔（分钟，360 = 6 小时）</label>
            <input class="input" id="cw-int" type="number" value="${cfg.intervalMin || 360}" min="30" /></div>
          <div class="field"><label>每轮最多主页数</label>
            <input class="input" id="cw-pages" type="number" value="${cfg.pagesPerRound || 20}" min="1" max="60" /></div>
          <div class="field"><label>静默时段（小时，逗号分隔）</label>
            <input class="input" id="cw-quiet" value="${(cfg.quietHours || []).join(',')}"
                   style="font-family:var(--mono);font-size:11px" /></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;margin:10px 0">
          <label class="switch"><input type="checkbox" id="cw-reply" ${cfg.allowReply ? 'checked' : ''} />
            <span class="track"></span><span class="lbl">自动回复真实互动（英文 + 链接）</span></label>
          <label class="switch"><input type="checkbox" id="cw-delete" ${cfg.allowDelete ? 'checked' : ''} />
            <span class="track"></span><span class="lbl">自动删除恶评 / 引流 / 违规</span></label>
          <label class="switch"><input type="checkbox" id="cw-newpages" ${cfg.coverNewPages ? 'checked' : ''} />
            <span class="track"></span><span class="lbl">新增主页优先覆盖（从没查过的排最前）</span></label>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn sm primary" id="cw-save">保存配置</button>
          <button class="btn sm" id="cw-once"><span data-icon="bolt"></span>立刻跑一轮</button>
          ${running
            ? '<button class="btn sm danger" id="cw-stop">停止轮询</button>'
            : '<button class="btn sm" id="cw-start">启动轮询</button>'}
        </div>
        ${cfg.lastResult ? `<div class="hint" style="margin-top:9px">
          上次结果：<span style="font-family:var(--mono);font-size:10px">${esc(cfg.lastResult)}</span>
        </div>` : ''}
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">关了软件怎么办</div>
        <span class="chip">随软件启停</span>
      </div>
      <div class="card-body">
        <div class="steps" style="margin-bottom:13px">
          <div class="step ${running ? 'done' : 'wait'}">
            <div class="step-num">${running ? '✓' : '1'}</div>
            <div class="step-body">
              <div class="step-title">软件打开时</div>
              <div class="step-desc">后台每 ${cfg.intervalMin >= 60 ? (cfg.intervalMin / 60) + ' 小时' : cfg.intervalMin + ' 分钟'}自动轮询，最多扫 ${cfg.pagesPerRound || 20} 个主页</div>
            </div>
          </div>
          <div class="step wait">
            <div class="step-num">2</div>
            <div class="step-body">
              <div class="step-title">关掉软件 / 关电脑</div>
              <div class="step-desc">完全不跑（按你的要求不做 Windows 计划任务）</div>
            </div>
          </div>
          <div class="step ${cfg.catchUpOnBoot ? 'done' : 'wait'}">
            <div class="step-num">${cfg.catchUpOnBoot ? '✓' : '3'}</div>
            <div class="step-body">
              <div class="step-title">下次打开软件</div>
              <div class="step-desc">自动补一轮（${cfg.catchUpPages || 30} 个主页），把关机期间漏掉的捞回来</div>
            </div>
          </div>
        </div>

        <div class="card" style="border-color:rgba(79,70,229,.25)">
          <div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.8">
            <b>为什么不做计划任务</b>：按你的要求已移除。软件不运行时不会有任何后台进程。
            好处是不留系统痕迹、不占资源；代价是关软件期间不响应评论。<br/>
            <b>如果要 7×24 覆盖</b>：把整个程序目录放到一台常开的机器上运行即可，
            本机只用来远程连它的界面。
          </div>
        </div>
      </div>
    </div>

    <div class="card" style="border-color:rgba(79,70,229,.25)">
      <div class="card-body" style="padding:11px 13px;font-size:10.5px;color:var(--tx-2);line-height:1.8">
        <b>为什么这样设计</b>：评论回复和删除都是高频操作，如果做成「一直开着一秒钟查一次」，
        极易被识别为机器人。所以做成<b>周期性轮询</b>：每 15 分钟看一轮、每轮只看 5 个主页、
        评论之间随机等 6–18 秒、凌晨 2–6 点完全不动 —— 模拟真人在维护账号的节奏。
      </div>
    </div>
  `;

  const save = async () => {
    try {
      await api.watchConfig({
        intervalMin: parseInt($('#cw-int', inner).value, 10) || 360,
        pagesPerRound: parseInt($('#cw-pages', inner).value, 10) || 20,
        allowReply: $('#cw-reply', inner).checked,
        allowDelete: $('#cw-delete', inner).checked,
        coverNewPages: $('#cw-newpages', inner).checked,
        quietHours: $('#cw-quiet', inner).value.split(',')
          .map((x) => parseInt(x.trim(), 10)).filter((x) => !isNaN(x)),
      });
      toast('已保存', '', 'ok');
      await load(root);
    } catch (e) { toast('保存失败', e.message, 'err'); }
  };
  $('#cw-save', inner).onclick = save;

  const once = $('#cw-once', inner);
  if (once) once.onclick = async () => {
    once.disabled = true;
    const old = once.innerHTML;
    once.innerHTML = '<span class="spin" data-icon="bolt"></span>执行中';
    try {
      const r = await api.watchRunOnce();
      const res = r.result || {};
      toast('跑完一轮',
        res.skipped || `${res.pages} 页 · 回 ${res.reply} · 删 ${res.delete}`,
        (res.errors || []).length ? 'warn' : 'ok', 7000);
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    finally { once.disabled = false; once.innerHTML = old; }
  };
  const on = $('#cw-start', inner);
  if (on) on.onclick = async () => {
    try { await api.watchStart(); toast('已启动', '', 'ok'); await load(root); }
    catch (e) { toast('失败', e.message, 'err'); }
  };
  const off = $('#cw-stop', inner);
  if (off) off.onclick = async () => {
    try { await api.watchStop(); toast('已停止', '', 'warn'); await load(root); }
    catch (e) { toast('失败', e.message, 'err'); }
  };

  const cu = $('#cw-catchup', inner);
  if (cu) cu.onclick = async () => {
    cu.disabled = true;
    const old = cu.innerHTML;
    cu.innerHTML = '<span class="spin" data-icon="bolt"></span>补漏中';
    try {
      const r = await api.watchRunOnce();
      const res = r.result || {};
      toast('补漏完成',
        res.skipped || `${res.pages} 页 · 回 ${res.reply} · 删 ${res.delete}`,
        (res.errors || []).length ? 'warn' : 'ok', 7000);
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
    finally { cu.disabled = false; cu.innerHTML = old; }
  };
  const cOn = $('#cw-catchup-on', inner);
  if (cOn) cOn.onchange = async () => {
    try {
      await api.watchConfig({ catchUpOnBoot: cOn.checked });
      toast('已保存', cOn.checked ? '开机自动补漏' : '已关闭补漏', 'ok');
    } catch (e) { toast('失败', e.message, 'err'); }
  };
}

function paintRun(inner, root, tpl, quotas) {
  const pages = store.pages || [];
  inner.innerHTML = `
    <div class="row-2" style="margin-bottom:12px">
      <div class="field" style="margin:0">
        <label>目标主页</label>
        <select class="select" id="cm-page">
          ${pages.map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field" style="margin:0">
        <label>评论额度（每小时）</label>
        <div style="display:flex;gap:5px;flex-wrap:wrap;padding-top:4px">
          ${quotas.slice(0, 4).map((q) => `
            <span class="chip" style="font-size:9.5px">
              ${esc(q.label.slice(0, 6))} 回${q.replyLeft} 删${q.deleteLeft}
            </span>`).join('') || '<span style="font-size:10.5px;color:var(--tx-3)">无号</span>'}
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">回复话术（自动附链接）</div>
        <button class="btn xs primary" id="cm-rules"><span data-icon="cog"></span>自定义规则</button>
      </div>
      <div class="card-body tight">
        ${(tpl.templates || []).map((t, i) => `
          <div class="litem">
            <span style="width:16px;font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${i + 1}</span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px;line-height:1.5">
                ${esc(t.replace('{link}', '⟨链接⟩'))}
              </div>
            </div>
          </div>`).join('')}
      </div>
      <div style="padding:8px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        <b>会自动回复的</b>：nice / good / wow / love it / lol / hahaha / 🔥😂 纯表情 /
        [sticker] 贴纸 / 提问「where to watch」等。点「自定义规则」可添加你自己的词。
      </div>
    </div>

    ${fetched.length ? `
    <div class="section-title">抓到 ${fetched.length} 条评论</div>
    <div class="tbl-wrap" style="margin-bottom:12px">
      <table class="tbl">
        <thead><tr>
          <th>作者</th><th>内容</th><th>分类</th><th>建议动作</th><th></th>
        </tr></thead>
        <tbody>
          ${fetched.map((c, i) => {
            const catCls = c.category === 'genuine' ? 'ok'
              : c.category === 'ambiguous' ? 'mute' : 'danger';
            return `
              <tr>
                <td style="font-size:11px">${esc(c.author || '—')}</td>
                <td style="font-size:11px;max-width:380px">${esc(c.text)}</td>
                <td>${badge(catCls === 'danger' ? '违规/引流' : c.category, catCls)}</td>
                <td>${c.shouldDelete ? badge('删除', 'danger', true)
                  : c.shouldReply ? badge('回复引导', 'ok', true)
                  : badge('跳过', 'mute', true)}</td>
                <td style="font-size:9.5px;color:var(--tx-3)">${esc(c.reason || '')}</td>
              </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>

    <div style="display:flex;flex-direction:column;gap:9px;margin-bottom:12px">
      <label class="switch"><input type="checkbox" id="cm-reply" checked />
        <span class="track"></span><span class="lbl">回复真实互动（英文 + 链接）</span></label>
      <label class="switch"><input type="checkbox" id="cm-delete" checked />
        <span class="track"></span><span class="lbl">删除恶评 / 蹭量引流 / 违规言论</span></label>
    </div>

    <div class="card" style="margin-bottom:12px;border-color:rgba(251,191,36,.35)">
      <div class="card-body" style="padding:11px 13px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
        <b style="color:var(--warn)">删除不可恢复</b>。先点「演练」看清要动哪些，
        确认无误再点「执行」。每步之间会随机等 8–22 秒，命中风控立即中止整批。
      </div>
    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn" id="cm-dry"><span data-icon="eye"></span>演练（不改动）</button>
      <button class="btn danger" id="cm-run"><span data-icon="trash"></span>执行</button>
    </div>
    <div id="cm-plan" style="margin-top:12px"></div>
    ` : `
    <div style="padding:36px 20px;text-align:center">
      <div style="font-size:13px;color:var(--tx-1);margin-bottom:6px">还没有抓取评论</div>
      <div style="font-size:11.5px;color:var(--tx-3);line-height:1.8">
        点右上「抓取评论」登录态下读取主页评论<br/>
        抓完会先分类给你看，确认后再执行
      </div>
    </div>`}
  `;

  // 自定义规则按钮（不依赖是否抓取过评论）
  const rb = document.getElementById('cm-rules');
  if (rb) rb.onclick = () => openRules(root);

  if (!fetched.length) return;

  const doRun = async (dry) => {    const pageId = $('#cm-page', inner).value;
    if (!pageId) return toast('请选主页', '', 'err');
    const btn = dry ? $('#cm-dry', inner) : $('#cm-run', inner);
    btn.disabled = true;
    const old = btn.innerHTML;
    btn.innerHTML = `<span class="spin" data-icon="${dry ? 'eye' : 'trash'}"></span>${dry ? '演练中' : '执行中'}`;
    try {
      const r = await api.runComments({
        pageId,
        comments: fetched.map((c) => ({ cid: c.cid, text: c.text, author: c.author })),
        allowReply: $('#cm-reply', inner).checked,
        allowDelete: $('#cm-delete', inner).checked,
        dryRun: dry,
      });
      if (dry) {
        planResult = r;
        $('#cm-plan', inner).innerHTML = renderPlan(r);
        toast('演练完成',
          `回复 ${r.summary.reply} · 删除 ${r.summary.delete} · 跳过 ${r.summary.skip}`, 'info', 6000);
      } else {
        toast('已入队', `任务 ${r.jobId}`, 'ok');
        const t0 = Date.now();
        while (Date.now() - t0 < 1800000) {
          await new Promise((res) => setTimeout(res, 4000));
          const j = await api.job(r.jobId);
          btn.innerHTML = `<span class="spin" data-icon="trash"></span>${j.progress || 0}%`;
          if (['done', 'failed', 'blocked'].includes(j.status)) {
            const res2 = j.result || {};
            if (res2.guard) {
              const m = await import('../store.js');
              m.raiseGuard(res2.guard);
            }
            toast(j.status === 'done' ? '执行完成' : '执行受阻',
              `回复 ${res2.reply || 0} · 删除 ${res2.delete || 0} · 失败 ${res2.fail || 0}`,
              j.status === 'done' ? 'ok' : 'warn', 7000);
            break;
          }
        }
        await load(root);
      }
    } catch (e) {
      toast(dry ? '演练失败' : '执行失败', e.message, 'err', 6000);
    } finally {
      btn.disabled = false;
      btn.innerHTML = old;
    }
  };
  $('#cm-dry', inner).onclick = () => doRun(true);
  $('#cm-run', inner).onclick = () => doRun(false);
}

function renderPlan(r) {
  return `
    <div class="card" style="border-color:rgba(79,70,229,.28)">
      <div class="card-head">
        <div class="card-title">演练结果 <span class="sub">未做任何操作</span></div>
        <div class="chips">
          <span class="chip">回 ${r.summary.reply}</span>
          <span class="chip">删 ${r.summary.delete}</span>
          <span class="chip ghost">跳过 ${r.summary.skip}</span>
        </div>
      </div>
      <div class="card-body tight" style="max-height:260px;overflow-y:auto">
        ${(r.plan || []).filter((x) => x.action !== 'skip').map((x) => `
          <div class="litem">
            <span class="dot ${x.action === 'delete' ? 'bad' : 'ok'}"></span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">
                ${x.action === 'delete' ? badge('删除', 'danger') : badge('回复', 'ok')}
                ${esc((x.author || '') + ': ' + (x.text || '').slice(0, 60))}
              </div>
              <div class="litem-sub" style="font-size:10px">
                ${esc(x.reason)}
                ${x.reply ? `<br/><span style="color:var(--ok)">${esc(x.reply)}</span>` : ''}
              </div>
            </div>
          </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">没有需要动作的评论</div>'}
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3)">
        链接：<span style="font-family:var(--mono);color:var(--ok)">${esc(r.link || '无')}</span>
      </div>
    </div>`;
}

function paintHistory(inner, hist) {
  const stats = histData.stats || [];
  inner.innerHTML = `
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
      ${stats.map((s) => `
        <span class="chip" style="font-size:9.5px">
          ${esc(s.action)}/${esc(s.category || '-')} <b>${s.n}</b>
        </span>`).join('') || '<span style="font-size:10.5px;color:var(--tx-3)">还没有记录</span>'}
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>时间</th><th>主页</th><th>动作</th><th>分类</th>
          <th>评论</th><th>回复内容</th><th>模式</th>
        </tr></thead>
        <tbody>
          ${hist.length ? hist.slice(0, 120).map((h) => `
            <tr>
              <td class="mono" style="font-size:9.5px">${ts(h.ts, true)}</td>
              <td class="mono" style="font-size:9.5px">${esc(h.page_id)}</td>
              <td>${h.action === 'reply' ? badge('回复', 'ok')
                : h.action === 'delete' ? badge('删除', 'danger')
                : badge('跳过', 'mute')}</td>
              <td style="font-size:10px">${esc(h.category || '—')}</td>
              <td style="font-size:10.5px;max-width:260px">${esc((h.comment_text || '').slice(0, 60))}</td>
              <td style="font-size:10.5px;max-width:260px;color:var(--tx-2)">
                ${esc((h.reply_text || '').slice(0, 60)) || '—'}</td>
              <td>${h.dry ? badge('演练', 'warn') : badge('真实', 'ok')}</td>
            </tr>`).join('')
            : '<tr><td colspan="7" style="text-align:center;color:var(--tx-3);padding:24px">还没有操作记录</td></tr>'}
        </tbody>
      </table>
    </div>`;
}

/* ---------------- 自定义规则 ---------------- */
async function openRules(root) {
  let d;
  try {
    d = await api.commentRules();
  } catch (e) {
    return toast('加载失败', e.message, 'err');
  }
  const custom = d.custom || {};
  const builtin = d.builtin || {};

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
        每行一个词 / 短语。自定义规则的优先级高于内置规则：
        <b>删除词优先判删</b>，<b>正面词优先判回</b>。
      </div>
    </div>

    <div class="field">
      <label>① 命中就回复的正面词（每行一个）</label>
      <textarea class="textarea" id="cr-pos" style="min-height:80px;font-family:var(--mono);font-size:11px"
        placeholder="例如：&#10;binge&#10;obsessed&#10;can't stop watching">${(custom.positive || []).join('\n')}</textarea>
      <div class="hint">观众说这些词时回复引导。像 nice / good / lol / hahaha / 🔥 这类已内置</div>
    </div>

    <div class="field">
      <label>② 命中就删除的词（每行一个）</label>
      <textarea class="textarea" id="cr-del" style="min-height:80px;font-family:var(--mono);font-size:11px"
        placeholder="例如：&#10;骗子&#10;垃圾剧&#10;别看了">${(custom.deleteWords || []).join('\n')}</textarea>
      <div class="hint">常见辱骂 / 恶意差评 / 你自己的黑名单词</div>
    </div>

    <div class="field">
      <label>③ 命中就删除的正则（每行一条，进阶）</label>
      <textarea class="textarea" id="cr-re" style="min-height:64px;font-family:var(--mono);font-size:11px"
        placeholder="例如：&#10;https?://(?!pinedrama)\S+&#10;\b\d{8,}\b">${(custom.deleteRegex || []).join('\n')}</textarea>
      <div class="hint">留空即可。写错了会被跳过，不会报错</div>
    </div>

    <div class="section-title">内置规则（不可删，仅供参考）</div>
    <div class="card"><div class="card-body tight" style="max-height:200px;overflow-y:auto">
      <div class="litem" style="padding:5px 0">
        <div class="litem-main">
          <div class="litem-title" style="font-size:11px">短评正面词 ${(builtin.shortPositive || []).length} 个</div>
          <div class="litem-sub" style="font-size:10px">${(builtin.shortPositive || []).slice(0, 30).join(' / ')}</div>
        </div>
      </div>
      <div class="litem" style="padding:5px 0">
        <div class="litem-main">
          <div class="litem-title" style="font-size:11px">笑声词 ${(builtin.laughWords || []).length} 个</div>
          <div class="litem-sub" style="font-size:10px">${(builtin.laughWords || []).join(' / ')}</div>
        </div>
      </div>
      <div class="litem" style="padding:5px 0">
        <div class="litem-main">
          <div class="litem-title" style="font-size:11px">辱骂词 ${(builtin.toxic || []).length} 个</div>
          <div class="litem-sub" style="font-size:10px">${(builtin.toxic || []).slice(0, 20).join(' / ')}…</div>
        </div>
      </div>
      <div class="litem" style="padding:5px 0">
        <div class="litem-main">
          <div class="litem-title" style="font-size:11px">表情检测</div>
          <div class="litem-sub" style="font-size:10px">${esc(d.emojiDetection || '')}</div>
        </div>
      </div>
    </div></div>

    <div class="section-title">试一下</div>
    <div class="field">
      <div style="display:flex;gap:6px">
        <input class="input" id="cr-test" placeholder="输入一条评论测试分类" />
        <button class="btn sm" id="cr-try">测试</button>
      </div>
      <div id="cr-out" style="margin-top:8px"></div>
    </div>`;

  const m = modal({
    title: '自定义评论规则', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存规则',
        onclick: async () => {
          const lines = (id) => (body.querySelector(id).value || '')
            .split('\n').map((x) => x.trim()).filter(Boolean);
          try {
            await api.saveCommentRules({
              positive: lines('#cr-pos'),
              deleteWords: lines('#cr-del'),
              deleteRegex: lines('#cr-re'),
            });
            toast('已保存', '规则立即生效', 'ok');
            m.close();
            await load(root);
          } catch (e) { toast('保存失败', e.message, 'err'); }
        },
      }),
    ],
  });

  body.querySelector('#cr-try').onclick = async () => {
    const t = body.querySelector('#cr-test').value.trim();
    if (!t) return;
    try {
      const r = await api.commentClassify([t]);
      const it = (r.items || [])[0] || {};
      const cls = it.delete ? 'danger' : it.reply ? 'ok' : 'mute';
      body.querySelector('#cr-out').innerHTML = `
        <div class="litem">
          <span class="dot ${cls === 'danger' ? 'bad' : cls === 'ok' ? 'ok' : ''}"></span>
          <div class="litem-main">
            <div class="litem-title">${badge(it.category || '', cls)}
              ${it.delete ? badge('会删除', 'danger', true) : it.reply ? badge('会回复', 'ok', true) : badge('跳过', 'mute', true)}
            </div>
            <div class="litem-sub">${esc(it.reason || '')}</div>
          </div>
        </div>`;
    } catch (e) { toast('测试失败', e.message, 'err'); }
  };
  body.querySelector('#cr-test').onkeydown = (e) => {
    if (e.key === 'Enter') body.querySelector('#cr-try').click();
  };
}

/* ---------------- 抓取 ---------------- */
function openFetch(root) {
  const running = (store.envs || []).filter((e) => e.status === 'running');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>主页</label>
      <select class="select" id="cf-page">
        ${(store.pages || []).map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
      </select>
    </div>
    <div class="field">
      <label>环境</label>
      <select class="select" id="cf-env">
        ${running.map((e) => `<option value="${e.containerCode}">${esc(e.name)} · CDP ${e.cdpPort}</option>`).join('')
          || '<option value="">没有运行中的环境</option>'}
      </select>
    </div>
    <div class="field">
      <label>最多抓多少条</label>
      <input class="input" id="cf-limit" type="number" value="50" min="10" max="200" />
    </div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.7">
      抓取只是读取，不修改任何东西。抓完会先分类，确认后再执行回复/删除。
      抓取前会过一次风控检查，命中会直接中止。
    </div></div>`;
  const m = modal({
    title: '抓取评论', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始抓取',
        onclick: async () => {
          const envCode = body.querySelector('#cf-env').value;
          if (!envCode) return toast('没有可用环境', '先启动指纹浏览器', 'err');
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '抓取中…';
          try {
            const r = await api.fetchComments({
              pageId: body.querySelector('#cf-page').value,
              envCode,
              limit: parseInt(body.querySelector('#cf-limit').value, 10) || 50,
            });
            fetched = r.items || [];
            toast('抓取完成', `${r.count} 条 · ${JSON.stringify(r.byCategory)}`, 'ok', 6000);
            m.close();
            tab = 'run';
            paint(root);
          } catch (e) {
            toast('抓取失败', e.message, 'err', 7000);
          } finally {
            btn.disabled = false; btn.textContent = '开始抓取';
          }
        },
      }),
    ],
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
