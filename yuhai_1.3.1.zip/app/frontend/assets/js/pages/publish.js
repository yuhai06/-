/* 发布中心（真实数据）
   从队列取素材，走 reels_composer 单链路，只认受理回执。 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import {
  badge, pageHead, statCard, bar, $, $$, toast, modal, nfmt, ts, emptyState,
} from '../ui.js';

let picked = new Set();
let ptTab = 'queue';        // queue | links | captions
let linksData = [];
let tplData = { items: [], vars: {}, default: '' };
let variants = [];
let platData = { platform: 'fb', platformName: 'Facebook', useHashtags: false, available: [] };
let missedData = { items: [], count: 0 };
let reelsData = { ok: false, planPages: 0, pages: [] };

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '发布中心',
      desc: '发布队列 · 推广链接池 · 文案模板与生成 · 链接提取',
      actions: [
        `<button class="btn sm" data-act="extract"><span data-icon="link"></span>提取本次链接</button>`,
        `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
        `<button class="btn sm primary" data-act="go"><span data-icon="send"></span>开始发布</button>`,
      ],
    })}
    <div id="pb-body"></div>
  `;
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  $$('[data-act="go"]', root).forEach((b) => (b.onclick = () => openRun(root)));
  $$('[data-act="extract"]', root).forEach((b) => (b.onclick = () => openExtract(root)));
  paint(root);
  load(root);
}

async function load(root) {
  await Promise.all([
    store.loadQueue(), store.loadJobs(), store.loadCore(),
    (async () => { try { linksData = (await api.links()).items || []; } catch { linksData = []; } })(),
    (async () => { try { tplData = await api.captionTemplates(); } catch { /* ignore */ } })(),
    (async () => { try { variants = (await api.captionVariants()).items || []; } catch { variants = []; } })(),
    (async () => { try { platData = await api.publishPlatform(); } catch { /* ignore */ } })(),
    (async () => { try { missedData = await api.scheduleMissed(7); } catch { missedData = { items: [] }; } })(),
    (async () => { try { reelsData = await api.reelsStatus(); } catch { /* ignore */ } })(),
    (async () => { try { if (!store.dsh) store.dsh = await api.dshStatus(); } catch { store.dsh = null; } })(),
  ]);
  paint(root);
  bindPlat(root); bindReels(root);
}

/* 发布中心：队列 / 链接池 / 文案模板 三个标签 */
/* ---------------- 发布平台卡（FB 不带标签 / TK 带） ---------------- */
function platCard() {
  const p = platData || {};
  const isFB = (p.platform || 'fb') === 'fb';
  return `
    <div class="card" style="margin-bottom:13px;border-color:${isFB
      ? 'rgba(52,211,153,.35)' : 'rgba(79,70,229,.35)'}">
      <div class="card-head">
        <div class="card-title">
          <span data-icon="globe"></span> 发布平台
          <span class="badge ${isFB ? 'ok' : 'purple'}" style="font-size:9px;margin-left:5px">
            ${esc(p.platformName || 'Facebook')}</span>
        </div>
        <div style="display:flex;gap:6px">
          ${(p.available || []).map((x) => `
            <button class="btn xs ${p.platform === x.key ? 'primary' : 'ghost'}"
                    data-plat="${esc(x.key)}">
              ${esc(x.name)}${x.hashtags ? '' : '（无标签）'}
            </button>`).join('')}
        </div>
      </div>
      <div class="card-body">
        <div style="font-size:10.5px;color:var(--tx-2);line-height:1.8">
          <b>最终文案构成</b>：
          标题 + 推广链接${p.useHashtags ? ' + 标签' : '（<b style="color:var(--ok)">不加标签</b>）'}
          <br/>
          <span style="color:var(--tx-3);font-size:9.5px">
            ${isFB
              ? 'FB 只要标题和链接，标签会降低自然触达，已关闭。'
              : `TK 模式会附加：${esc(p.hashtags || '')}`}
          </span>
        </div>
        <div style="margin-top:9px;padding:9px 11px;border-radius:var(--r-sm);
                    background:var(--bg-0);font-size:10px;font-family:var(--mono);
                    white-space:pre-wrap;line-height:1.75;word-break:break-all"
             id="pb-plat-preview">点下方「预览一条」看实际效果</div>
        <div style="margin-top:8px;display:flex;gap:6px">
          <button class="btn xs" id="pb-plat-preview-btn">预览一条</button>
        </div>
      </div>
    </div>`;
}

function bindPlat(root) {
  document.querySelectorAll('[data-plat]').forEach((b) => {
    b.onclick = async () => {
      b.disabled = true;
      try {
        platData = await api.setPublishPlatform(b.dataset.plat);
        toast('已切换', `${platData.platformName} · ${platData.useHashtags ? '带标签' : '不带标签'}`, 'ok');
        paint(root); bindPlat(root); bindReels(root);
      } catch (e) { toast('切换失败', e.message, 'err'); }
      finally { b.disabled = false; }
    };
  });
  const pv = document.getElementById('pb-plat-preview-btn');
  if (pv) {
    pv.onclick = async () => {
      pv.disabled = true; pv.textContent = '生成中…';
      try {
        const pg = (store.pages || [])[0] || {};
        const r = await api.captionPreview(pg.pageId || pg.name || '', '');
        const el = document.getElementById('pb-plat-preview');
        if (el) el.textContent = r.caption || '(空)';
        toast('已生成', `长度 ${r.length} · 链接 ${r.hasLink ? '有' : '无'} · 标签 ${r.hasHashtags ? '有' : '无'}`, 'ok');
      } catch (e) { toast('预览失败', e.message, 'err'); }
      finally { pv.disabled = false; pv.textContent = '预览一条'; }
    };
  }
}

/* ---------------- ReelsPublisher 内核批量发布卡 ---------------- */
function reelsCard() {
  const r = reelsData || {};
  const ok = !!r.ok;
  return `
    <div class="card" style="margin-bottom:13px;border-color:${ok
      ? 'rgba(52,211,153,.4)' : 'rgba(248,113,113,.4)'}">
      <div class="card-head">
        <div class="card-title">
          <span data-icon="bolt"></span> Reels 内核批量发布
          <span class="badge ${ok ? 'ok' : 'danger'}" style="font-size:9px;margin-left:5px">
            ${ok ? `${r.version} 就绪 · ${r.planPages} 个主页` : '内核不可用'}</span>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn xs ghost" id="rl-check">检查浏览器</button>
          <button class="btn xs primary" id="rl-go">开始发布</button>
        </div>
      </div>
      <div class="card-body">
        <div style="font-size:10.5px;color:var(--tx-2);line-height:1.8">
          用 ReelsPublisher v19.7 的成熟链路发布（Playwright + skill-runtime），
          比自研 CDP 稳。流程：打开 composer → 塞视频 → 填标题 → 点发布 → 提回执 → <b>自动删素材</b>。
        </div>
        <div class="row-2" style="margin-top:10px">
          <div class="field"><label>每主页发几条</label>
            <input class="input" id="rl-clips" type="number" value="1" min="1" max="6" /></div>
          <div class="field"><label>并发环境数</label>
            <input class="input" id="rl-conc" type="number" value="1" min="1" max="3" /></div>
        </div>
        <div class="field">
          <label>标题模板（用 <code>{{DRAMA}}</code> 占位，会替换成剧名）</label>
          <textarea class="input" id="rl-desc" rows="5"
            style="font-family:var(--mono);font-size:10.5px;resize:vertical">${esc(tplData.default || '')}</textarea>
        </div>
        <div class="field">
          <label>链接池（每行一个，随机替换标题里的链接）</label>
          <input class="input" id="rl-links" value="${esc((linksData[0] || {}).url || '')}"
                 style="font-family:var(--mono);font-size:10.5px" />
        </div>
        <div id="rl-out" style="font-size:10px;color:var(--tx-3);line-height:1.7"></div>
      </div>
    </div>`;
}

function bindReels(root) {
  const chk = document.getElementById('rl-check');
  if (chk) {
    chk.onclick = async () => {
      chk.disabled = true; chk.textContent = '检查中…';
      const out = document.getElementById('rl-out');
      try {
        const r = await api.reelsCheck();
        const res = r.results || [];
        if (out) {
          out.innerHTML = res.map((x) => `
            <div style="color:${x.status === 'ready' ? 'var(--ok)' : 'var(--danger)'}">
              · ${esc(x.environmentId)} : ${esc(x.status)}
              ${x.error ? ' — ' + esc(x.error) : ''}
            </div>`).join('');
        }
        const bad = res.filter((x) => x.status !== 'ready');
        toast(bad.length ? '有环境未就绪' : '全部就绪',
          bad.length ? bad.map((b) => b.environmentId).join(',') : `${res.length} 个环境`,
          bad.length ? 'err' : 'ok', 6000);
      } catch (e) {
        if (out) out.innerHTML = `<div style="color:var(--danger)">${esc(e.message)}</div>`;
        toast('检查失败', e.message, 'err');
      } finally { chk.disabled = false; chk.textContent = '检查浏览器'; }
    };
  }

  const go = document.getElementById('rl-go');
  if (go) {
    go.onclick = async () => {
      const desc = document.getElementById('rl-desc').value.trim();
      const links = document.getElementById('rl-links').value.trim();
      if (!desc) { toast('标题不能为空', '', 'err'); return; }
      if (!confirm(`开始批量发布？\n每主页 1 条 · 共 ${reelsData.planPages || 0} 个主页\n发布成功后素材会自动删除。`)) return;

      go.disabled = true; go.textContent = '提交中…';
      const out = document.getElementById('rl-out');
      try {
        const r = await api.reelsPublish({
          clipsPerPage: parseInt(document.getElementById('rl-clips').value, 10) || 1,
          concurrency: parseInt(document.getElementById('rl-conc').value, 10) || 1,
          description: desc,
          linkPool: links,
        });
        toast('已提交', `任务 ${r.jobId}`, 'ok', 6000);
        if (out) out.innerHTML = `<div>任务 ${esc(r.jobId)} 已提交，看下方「发布任务」进度</div>`;
        go.textContent = '执行中…';

        const t0 = Date.now();
        while (Date.now() - t0 < 3600000) {
          await new Promise((res) => setTimeout(res, 8000));
          const j = await api.job(r.jobId);
          if (out && j.steps?.length) {
            out.innerHTML = j.steps.map((s) => `
              <div style="color:${s.state === 'done' ? 'var(--ok)'
                : s.state === 'err' ? 'var(--danger)' : 'var(--tx-2)'}">
                ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : '…'}
                ${esc(s.name)} ${esc(s.note || '')}
              </div>`).join('');
          }
          if (j.status === 'done') {
            const v = j.result || {};
            const pages = v.value?.pages || v.pages || [];
            const done = pages.filter((p) => p.state === 'completed').length;
            toast('发布完成', `${done}/${pages.length} 个主页成功`, 'ok', 9000);
            break;
          }
          if (j.status === 'failed') {
            toast('发布失败', j.error || '', 'err', 9000);
            break;
          }
        }
      } catch (e) {
        toast('提交失败', e.message, 'err', 8000);
      } finally { go.disabled = false; go.textContent = '开始发布'; }
    };
  }
}

function paint(root) {
  const body = $('#pb-body', root);
  if (!body) return;
  // 发布队列只放单集；混剪单独统计，不参与发布（用户要求）
  const q = (store.queue || []).filter((x) => x.state === 'ready' && x.kind !== 'mix');
  const mixCount = (store.queue || []).filter((x) => x.kind === 'mix').length;
  const jobs = (store.jobs || []).filter((j) => j.kind === 'publish');
  const running = jobs.filter((j) => j.status === 'running').length;

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '待发（单集）', value: q.length, unit: '条', iconName: 'layers',
                   foot: mixCount ? `另有 ${mixCount} 条混剪（不参与发布）` : '' })}
      ${statCard({ label: '选中', value: picked.size, unit: '条', iconName: 'check' })}
      ${statCard({ label: '推广链接', value: linksData.length, unit: '条', iconName: 'link' })}
      ${statCard({ label: '文案变体', value: variants.length, unit: '条', iconName: 'chat',
                   foot: `${tplData.items?.length || 0} 个模板` })}
    </div>

    ${platCard()}

    ${reelsCard()}

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="tabs" style="border:none;padding:0;margin:0">
          <div class="tab ${ptTab === 'queue' ? 'active' : ''}" data-tab="queue">
            发布队列 <span class="cnt">${q.length}</span>
          </div>
          <div class="tab ${ptTab === 'links' ? 'active' : ''}" data-tab="links">
            推广链接 <span class="cnt">${linksData.length}</span>
          </div>
          <div class="tab ${ptTab === 'captions' ? 'active' : ''}" data-tab="captions">
            文案模板 <span class="cnt">${variants.length}</span>
          </div>
          <div class="tab ${ptTab === 'missed' ? 'active' : ''}" data-tab="missed"
               style="${missedData.items?.length ? 'color:var(--warn)' : ''}">
            待手动 <span class="cnt">${missedData.items?.length || 0}</span>
          </div>
        </div>
      </div>
      <div class="card-body tight" id="pb-inner"></div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">发布任务</div></div>
      <div class="card-body tight">
        ${jobs.length ? jobs.slice(0, 10).map((j) => {
          const st = j.status === 'running' ? ['执行中', 'info']
            : j.status === 'done' ? ['完成', 'ok']
            : j.status === 'blocked' ? ['受阻', 'danger']
            : j.status === 'failed' ? ['失败', 'danger'] : ['排队', 'mute'];
          return `
            <div class="litem" style="flex-direction:column;align-items:stretch;gap:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <div class="litem-title" style="flex:1">${esc(j.title)} ${badge(st[0], st[1], j.status === 'running')}</div>
                <span style="font-family:var(--mono);font-size:10.5px;color:var(--tx-3)">${j.progress || 0}%</span>
              </div>
              ${bar(j.progress || 0, j.status === 'blocked' || j.status === 'failed' ? 'danger' : j.status === 'done' ? 'ok' : '')}
              ${(j.steps || []).length ? `
                <div style="display:flex;flex-direction:column;gap:3px">
                  ${(j.steps || []).slice(0, 6).map((s) => `
                    <div style="display:flex;gap:7px;font-size:10.5px">
                      <span style="color:${s.state === 'done' ? 'var(--ok)' : s.state === 'err' ? 'var(--danger)' : s.state === 'run' ? 'var(--ac)' : 'var(--tx-3)'}">
                        ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : s.state === 'run' ? '…' : '·'}
                      </span>
                      <span style="flex:1;color:var(--tx-2)">${esc(s.name)}</span>
                      <span style="color:var(--tx-3);font-family:var(--mono);font-size:9.5px">${esc(s.note || '')}</span>
                    </div>`).join('')}
                </div>` : ''}
              ${j.error ? `<div style="font-size:10.5px;color:var(--danger)">${esc(j.error)}</div>` : ''}
            </div>`;
        }).join('') : `<div style="padding:22px;text-align:center;color:var(--tx-3);font-size:11.5px">还没有发布任务</div>`}
      </div>
    </div>
  `;

  $$('[data-tab]', body).forEach((t) => {
    t.onclick = () => { ptTab = t.dataset.tab; paint(root); };
  });

  const inner = $('#pb-inner', body);
  if (ptTab === 'links') return paintLinks(inner, root);
  if (ptTab === 'captions') return paintCaptions(inner, root);
  if (ptTab === 'missed') return paintMissed(inner, root);
  paintQueue(inner, root, q);
}

/* ---------------- 待手动（超时转手动的素材） ---------------- */
function paintMissed(inner, root) {
  const items = missedData.items || [];
  inner.innerHTML = `
    <div style="padding:10px 14px;font-size:10.5px;color:var(--tx-2);line-height:1.8">
      <b style="color:var(--warn)">超时未发 → 已转手动</b>：这些排期到点时软件没在跑，
      为避免一次性涌出被判定自动化，已从自动队列撤下。
      <b>素材没丢</b>，还在队列里，你可以挑合适时机手动发，或重新排期。
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>原定时间</th><th>主页</th><th>剧 / 集</th>
          <th>素材文件</th><th>状态</th><th class="actions"></th>
        </tr></thead>
        <tbody>
          ${items.length ? items.map((s) => `
            <tr>
              <td class="mono" style="font-size:10px">${esc(s.date)} ${esc(s.time)}</td>
              <td><b style="font-size:11.5px">${esc(s.page)}</b></td>
              <td style="font-size:10.5px">${esc(s.drama || '—')} ${esc(s.ep || '')}</td>
              <td class="mono" style="font-size:9.5px;max-width:260px;overflow:hidden;
                         text-overflow:ellipsis;white-space:nowrap">
                ${esc((s.queue && s.queue.file) || '（素材已删）')}
              </td>
              <td>${s.fileExists
                ? badge('素材在队列', 'ok')
                : badge('素材丢失', 'danger')}</td>
              <td class="actions">
                <button class="btn xs ghost" data-requeue="${esc(s.id)}">放回队列</button>
              </td>
            </tr>`).join('')
            : `<tr><td colspan="6" style="padding:26px;text-align:center;
                   color:var(--tx-3);font-size:11.5px">
                 没有待手动素材 —— 说明排期都按时发了
               </td></tr>`}
        </tbody>
      </table>
    </div>`;

  $$('[data-requeue]', inner).forEach((b) => {
    b.onclick = async () => {
      b.disabled = true; b.textContent = '处理中…';
      try {
        const r = await api.scheduleRequeue(b.dataset.requeue);
        toast('已放回队列', r.note || '', 'ok', 6000);
        missedData = await api.scheduleMissed(7);
        await store.loadQueue();
        paint(root); bindPlat(root); bindReels(root);
      } catch (e) {
        toast('操作失败', e.message, 'err', 6000);
        b.disabled = false; b.textContent = '放回队列';
      }
    };
  });
}

/* ---------------- 队列 ---------------- */
function paintQueue(inner, root, q) {
  inner.innerHTML = `
    <div style="display:flex;gap:6px;padding:9px 14px 0;flex-wrap:wrap">
      <button class="btn xs ghost" data-act="all">全选</button>
      <button class="btn xs ghost" data-act="none">清空</button>
      <button class="btn xs" data-act="random"><span data-icon="refresh"></span>随机 2 条</button>
      <button class="btn xs primary" data-act="smart"><span data-icon="bolt"></span>智能匹配</button>
    </div>
    <div style="padding:10px 14px;max-height:360px;overflow-y:auto">
      ${q.length ? q.map((x) => `
        <label class="litem" style="cursor:pointer">
          <input type="checkbox" data-pick="${x.id}"
                 style="width:14px;height:14px;accent-color:var(--ac)"
                 ${picked.has(x.id) ? 'checked' : ''} />
          <div class="litem-main">
            <div class="litem-title">${esc(x.drama || '—')} ${x.ep || ''}
              ${x.page
                ? `<b style="font-family:var(--mono);color:var(--ac);font-size:10px">${esc(x.page)}</b>`
                : '<span class="badge mute" style="font-size:8.5px">待分配主页</span>'}
            </div>
            <div class="litem-sub">${esc(x.file)} · ${x.dur || '—'}s · ${x.size_mb || '—'}MB
              ${x.kind === 'mix' ? ' · <b style="color:var(--warn)">混剪</b>' : ''}</div>
          </div>
        </label>`).join('')
        : `<div style="padding:24px;text-align:center;color:var(--tx-3);font-size:11.5px">
             队列为空 · 去素材库选素材推入
           </div>`}
    </div>`;

  $$('[data-pick]', inner).forEach((cb) => {
    cb.onchange = () => {
      if (cb.checked) picked.add(cb.dataset.pick);
      else picked.delete(cb.dataset.pick);
      paint(root);
    };
  });
  $$('[data-act="all"]', inner).forEach((b) => (b.onclick = () => {
    q.forEach((x) => picked.add(x.id)); paint(root);
  }));
  $$('[data-act="none"]', inner).forEach((b) => (b.onclick = () => {
    picked.clear(); paint(root);
  }));
  $$('[data-act="random"]', inner).forEach((b) => (b.onclick = () => {
    picked.clear();
    const n = Math.min(q.length, 2);
    q.slice().sort(() => Math.random() - 0.5).slice(0, n).forEach((x) => picked.add(x.id));
    toast('已随机选', `${n} 条`, 'ok'); paint(root);
  }));
  $$('[data-act="smart"]', inner).forEach((b) => (b.onclick = () => openSmart(q, root)));
}

/* ---------------- 链接池 ---------------- */
function paintLinks(inner, root) {
  inner.innerHTML = `
    <div style="display:flex;justify-content:flex-end;padding:9px 14px 0">
      <button class="btn xs primary" data-act="addlink"><span data-icon="plus"></span>新增链接</button>
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>标签</th><th>链接（原样使用，绝不改写）</th><th>绑定主页</th>
          <th class="num">权重</th><th class="num">已用</th><th>状态</th><th></th>
        </tr></thead>
        <tbody>
          ${linksData.length ? linksData.map((l) => `
            <tr>
              <td><b>${esc(l.label)}</b></td>
              <td class="mono" style="font-size:10px;max-width:360px;overflow:hidden;
                         text-overflow:ellipsis;white-space:nowrap">${esc(l.url)}</td>
              <td style="font-size:11px">${l.page_id ? esc(l.page_id) : badge('全局', 'mute')}</td>
              <td class="num">${l.weight}</td>
              <td class="num">${l.used_count}</td>
              <td>${l.enabled ? badge('启用', 'ok') : badge('停用', 'mute')}</td>
              <td class="row-actions"><button class="btn xs danger" data-dellink="${l.id}">删</button></td>
            </tr>`).join('')
            : '<tr><td colspan="7" style="text-align:center;color:var(--tx-3);padding:24px">还没有链接</td></tr>'}
        </tbody>
      </table>
    </div>
    <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
      发布时每个主页随机取一条（按权重，避开最近用过的）。<b>链接原样插入不改写</b>。
    </div>`;

  $$('[data-act="addlink"]', inner).forEach((b) => (b.onclick = () => openLink(root)));
  $$('[data-dellink]', inner).forEach((b) => {
    b.onclick = async () => {
      try { await api.delLink(b.dataset.dellink); toast('已删除', '', 'warn'); await load(root); }
      catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

/* ---------------- 文案模板 ---------------- */
function paintCaptions(inner, root) {
  const tpl = (tplData.items || [])[0] || {};
  inner.innerHTML = `
    <div style="padding:12px 14px">
      <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
        <div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.8">
          <b style="color:var(--ac)">用法</b>：填一条你一直在用的文案（含 <code style="font-family:var(--mono)">{{LINK}}</code>
          和 <code style="font-family:var(--mono)">{{DRAMA}}</code> 占位符），
          让模型生成多个<b>同结构但钩子不同</b>的版本，发布时每主页随机取一条。<br/>
          <b>链接永远原样插入，不改一个字符。</b>
        </div>
      </div>

      <div class="field">
        <label>参考文案（你的原版）</label>
        <textarea class="textarea" id="cp-body" style="min-height:150px;font-family:var(--mono);font-size:11px">${esc(tpl.body || tplData.default || '')}</textarea>
        <div class="hint">
          可用变量：{{LINK}} = 推广链接 · {{DRAMA}} = 剧名 · {{EP}} = 集号
        </div>
      </div>
      <div class="row-3">
        <div class="field"><label>生成数量</label>
          <input class="input" id="cp-n" type="number" value="5" min="1" max="20" /></div>
        <div class="field"><label>剧名（可选）</label>
          <input class="input" id="cp-drama" placeholder="留空则保留占位符" /></div>
        <div class="field"><label>模型</label>
          <select class="select" id="cp-model" style="font-size:11px">
            <option value="">默认（${esc(store.dsh?.selected || '自动')}）</option>
            ${(store.dsh?.channels || []).map((g) => `
              <optgroup label="${esc(g.label)}（${g.models.length}）">
                ${g.models.map((m) =>
                  `<option value="${esc(m.id)}">${esc(m.name)}${m.free ? ' · 免费' : ''}</option>`).join('')}
              </optgroup>`).join('')}
          </select>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <button class="btn primary" data-act="gen"><span data-icon="bolt"></span>生成变体</button>
        <button class="btn" data-act="savetpl">保存为模板</button>
        <button class="btn ghost" data-act="reset">恢复默认</button>
      </div>

      <div class="section-title">文案变体 <span class="sub">${variants.length} 条</span></div>
      <div class="card"><div class="card-body tight" style="max-height:340px;overflow-y:auto">
        ${variants.length ? variants.map((v, i) => `
          <div class="litem" style="align-items:flex-start">
            <span style="width:18px;font-family:var(--mono);font-size:10px;color:var(--tx-3);margin-top:2px">${i + 1}</span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px;line-height:1.6;white-space:pre-wrap">${esc(v.body)}</div>
              <div class="litem-sub" style="font-size:9.5px">
                ${esc(v.source || '')} · 已用 ${v.used_count || 0} 次
              </div>
            </div>
            <button class="btn xs danger" data-delvar="${v.id}">删</button>
          </div>`).join('')
          : `<div style="padding:24px;text-align:center;color:var(--tx-3);font-size:11.5px">
               还没有变体 · 点「生成变体」
             </div>`}
      </div></div>
    </div>`;

  $$('[data-act="gen"]', inner).forEach((b) => (b.onclick = async () => {
    const body = $('#cp-body', inner).value;
    if (!body.trim()) return toast('先填参考文案', '', 'err');
    b.disabled = true;
    const old = b.innerHTML;
    b.innerHTML = '<span class="spin" data-icon="bolt"></span>生成中';
    try {
      const r = await api.genCaptions({
        body,
        drama: $('#cp-drama', inner).value,
        n: parseInt($('#cp-n', inner).value, 10) || 5,
        model: $('#cp-model', inner).value,
      });
      toast('生成完成', `${(r.variants || []).length} 条 · ${r.source}`, 'ok', 6000);
      await load(root);
    } catch (e) { toast('生成失败', e.message, 'err', 6000); }
    finally { b.disabled = false; b.innerHTML = old; }
  }));
  $$('[data-act="savetpl"]', inner).forEach((b) => (b.onclick = async () => {
    try {
      await api.saveCaptionTemplate({ name: '我的模板', body: $('#cp-body', inner).value, id: tpl.id || '' });
      toast('已保存', '', 'ok');
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
  }));
  $$('[data-act="reset"]', inner).forEach((b) => (b.onclick = () => {
    $('#cp-body', inner).value = tplData.default || '';
    toast('已恢复默认', '', 'info');
  }));
  $$('[data-delvar]', inner).forEach((b) => {
    b.onclick = async () => {
      try { await api.delCaptionVariant(b.dataset.delvar); await load(root); }
      catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

function openLink(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field"><label>标签</label><input class="input" id="lk-label" placeholder="美国主链" /></div>
    <div class="field"><label>链接（原样使用）</label>
      <input class="input" id="lk-url" placeholder="https://pinedrama.onelink.me/..." style="font-family:var(--mono);font-size:11px" /></div>
    <div class="row-2">
      <div class="field"><label>绑定主页（留空=全局）</label>
        <select class="select" id="lk-page">
          <option value="">全局可用</option>
          ${(store.pages || []).map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field"><label>权重</label><input class="input" id="lk-weight" type="number" value="1" min="1" max="10" /></div>
    </div>`;
  const m = modal({
    title: '新增推广链接', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const url = (body.querySelector('#lk-url').value || '').trim();
          if (!url) return toast('链接不能为空', '', 'err');
          try {
            await api.addLink({
              label: body.querySelector('#lk-label').value || url.slice(0, 30),
              url, pageId: body.querySelector('#lk-page').value,
              weight: parseInt(body.querySelector('#lk-weight').value, 10) || 1,
            });
            toast('已添加', '', 'ok'); m.close(); await load(root);
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

/* ---------------- 智能匹配 ---------------- */
async function openSmart(q, root) {
  const pages = (store.pages || []).filter((p) => p.health === 'ok');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>按哪个主页的偏好匹配</label>
      <select class="select" id="sm-page">
        ${pages.map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
      </select>
    </div>
    <div id="sm-result" style="margin-top:10px"></div>`;

  const m = modal({
    title: '智能匹配素材', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '选中前 2 条',
        onclick: () => {
          const sel = body.querySelectorAll('[data-sm-pick]:checked');
          picked.clear();
          sel.forEach((cb) => picked.add(cb.value));
          toast('已选中', `${sel.length} 条`, 'ok');
          m.close();
          paint(root);
        },
      }),
    ],
  });

  const loadFit = async () => {
    const pid = body.querySelector('#sm-page').value;
    const box = body.querySelector('#sm-result');
    box.innerHTML = '<div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11.5px">匹配中…</div>';
    try {
      const r = await api.aiMatch(pid, 'fit', 20);
      const items = r.items || [];
      box.innerHTML = `
        ${r.note ? `<div style="padding:9px 11px;background:rgba(251,191,36,.08);
                      border-radius:var(--r-sm);font-size:10.5px;color:var(--warn);margin-bottom:9px">
                      ${esc(r.note)}</div>` : ''}
        <div style="font-size:10.5px;color:var(--tx-3);margin-bottom:8px">
          目标剧型 <b style="color:var(--ac)">${esc(r.wantType || '未定')}</b>
          ${(r.keywords || []).length ? ' · 关键词 ' + r.keywords.slice(0, 4).map((k) => esc(k)).join('/') : ''}
        </div>
        <div class="card"><div class="card-body tight" style="max-height:280px;overflow-y:auto">
          ${items.map((x) => `
            <label class="litem" style="cursor:pointer">
              <input type="checkbox" data-sm-pick value="${x.id}" style="width:14px;height:14px" />
              <div class="litem-main">
                <div class="litem-title">${esc(x.drama)} ${x.ep || ''}
                  ${x.fitScore > 0 ? badge(`匹配 ${x.fitScore}`, 'ok') : badge('无匹配', 'mute')}
                </div>
                <div class="litem-sub">${esc(x.file)} · ${x.size_mb}MB</div>
              </div>
            </label>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无素材</div>'}
        </div></div>`;
    } catch (e) {
      box.innerHTML = `<div style="padding:16px;color:var(--danger);font-size:11.5px">${esc(e.message)}</div>`;
    }
  };
  body.querySelector('#sm-page').onchange = loadFit;
  loadFit();
}

/* ---------------- 智能匹配 ---------------- */
function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}


