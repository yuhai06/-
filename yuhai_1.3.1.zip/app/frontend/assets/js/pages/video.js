/* 视频制作（内置 ffmpeg，不依赖任何外部程序）
   模型只用来生成文案，视频合成 100% 本地完成。 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let env = null;
let templates = [];
let jobs = [];
let curSrc = '';
let curInfo = null;
let steps = [];       // 当前编排的步骤
let multiSrc = [];    // 多选模式下的源文件列表
let multiMode = false;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '视频制作',
      desc: '内置 ffmpeg 本地出片 · 不依赖外部程序 · 换电脑照样用',
      actions: [
        `<button class="btn sm" data-act="pick"><span data-icon="layers"></span>选素材</button>`,
        `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
      ],
    })}
    <div id="vm-body"></div>
  `;
  $$('[data-act="pick"]', root).forEach((b) => (b.onclick = () => openPick(root)));
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    env = await api.videoEnv();
    templates = (await api.videoTemplates()).items || [];
    jobs = (await api.videoJobs()).items || [];
    if (!store.dsh) store.dsh = await api.dshStatus();
    if (!store.library || !store.library.length) await store.loadLibrary({});
  } catch (e) {
    console.warn(e.message);
  }
  paint(root);
}

function paint(root) {
  const body = $('#vm-body', root);
  if (!body) return;
  const lib = store.library || [];

  body.innerHTML = `
    ${!env?.ok ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="display:flex;gap:10px;align-items:center">
        <span style="color:var(--danger)">${icon('warn', 16)}</span>
        <div style="flex:1;font-size:11.5px">
          <b style="color:var(--danger)">ffmpeg 不可用</b> —— ${env?.error || '未找到内置二进制'}
        </div>
      </div>
    </div>` : ''}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: 'ffmpeg', value: env?.ok ? '内置可用' : '不可用', unit: '',
                   iconName: env?.ok ? 'check' : 'warn',
                   foot: env?.bundled ? '打包内置' : '系统 PATH' })}
      ${statCard({ label: '可剪辑素材', value: lib.filter((x) => x.state === 'ready').length,
                   unit: '条', iconName: 'layers' })}
      ${statCard({ label: '模板', value: templates.length, unit: '个', iconName: 'bolt' })}
      ${statCard({ label: '出片任务', value: jobs.length, unit: '个', iconName: 'video' })}
    </div>

    <div class="grid" style="grid-template-columns:1fr 1.1fr;margin-bottom:13px">
      <div class="card">
        <div class="card-head">
          <div class="card-title">源素材</div>
          <div style="display:flex;gap:5px">
            <button class="btn xs ghost" data-act="pick2"><span data-icon="layers"></span>单文件</button>
            <button class="btn xs primary" data-act="multi"><span data-icon="plus"></span>多文件夹</button>
          </div>
        </div>
        <div class="card-body">
          ${multiMode ? `
            <div style="font-size:11.5px;color:var(--tx-1);margin-bottom:8px">
              已选 <b style="color:var(--ac)">${multiSrc.length}</b> 个文件
              （${multiSrc.reduce((a, x) => a + (x.sizeMb || 0), 0).toFixed(0)} MB）
            </div>
            <div style="max-height:200px;overflow-y:auto;margin-bottom:9px">
              ${multiSrc.slice(0, 50).map((x) => `
                <div class="litem" style="padding:5px 0">
                  <div class="litem-main">
                    <div class="litem-title" style="font-size:10.5px">${esc(x.name)}</div>
                    <div class="litem-sub" style="font-size:9.5px">${esc(x.dir || '')}</div>
                  </div>
                  <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${x.sizeMb}MB</span>
                </div>`).join('')}
              ${multiSrc.length > 50 ? `<div style="font-size:10px;color:var(--tx-3);padding:6px">…还有 ${multiSrc.length - 50} 个</div>` : ''}
            </div>
            <button class="btn sm ghost" data-act="clearmulti">清空</button>
          ` : curSrc ? `
            <div style="font-family:var(--mono);font-size:10.5px;word-break:break-all;
                        color:var(--tx-2);margin-bottom:9px">${esc(curSrc)}</div>
            ${curInfo ? `
            <div class="grid g2" style="gap:8px">
              <div class="kv"><span class="k">时长</span><span class="v">${curInfo.dur}s</span></div>
              <div class="kv"><span class="k">分辨率</span><span class="v">${curInfo.w}×${curInfo.h}</span></div>
              <div class="kv"><span class="k">帧率</span><span class="v">${curInfo.fps || '—'}</span></div>
              <div class="kv"><span class="k">音轨</span><span class="v">${curInfo.audio ? '有' : '无'}</span></div>
              <div class="kv"><span class="k">大小</span><span class="v">${curInfo.size_mb} MB</span></div>
            </div>` : ''}
          ` : `
            <div style="padding:32px 16px;text-align:center;color:var(--tx-3);font-size:11.5px;line-height:1.9">
              还没选源素材<br/>
              <div style="display:flex;gap:6px;justify-content:center;margin-top:10px">
                <button class="btn sm" data-act="pick3">单文件</button>
                <button class="btn sm primary" data-act="multi2">多文件夹</button>
              </div>
            </div>`}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">快速模板</div>
          <span class="chip">一键套用</span>
        </div>
        <div class="card-body tight">
          ${templates.map((t) => `
            <div class="litem" data-tpl="${t.id}" style="cursor:pointer">
              <span class="dot ok"></span>
              <div class="litem-main">
                <div class="litem-title">${esc(t.name)}</div>
                <div class="litem-sub">${t.steps.map((s) => s.name).join(' → ')}</div>
              </div>
              <span style="font-size:10px;color:var(--tx-3)">套用 ›</span>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">步骤编排 <span class="sub">${steps.length} 步</span></div>
        <div style="display:flex;gap:6px">
          <button class="btn xs ghost" data-act="addstep"><span data-icon="plus"></span>加一步</button>
          <button class="btn xs ghost" data-act="clearstep">清空</button>
        </div>
      </div>
      <div class="card-body tight">
        ${steps.length ? steps.map((s, i) => `
          <div class="litem">
            <span style="width:20px;font-family:var(--mono);font-size:10px;color:var(--tx-3)">${i + 1}</span>
            <div class="litem-main">
              <div class="litem-title">${esc(s.name || s.op)}</div>
              <div class="litem-sub" style="font-family:var(--mono);font-size:9.5px">
                ${esc(JSON.stringify(Object.fromEntries(
                  Object.entries(s).filter(([k]) => k !== 'op' && k !== 'name'))))}
              </div>
            </div>
            <button class="btn xs danger" data-rmstep="${i}">删</button>
          </div>`).join('')
          : '<div class="litem" style="justify-content:center;color:var(--tx-3);padding:20px">还没有步骤 · 套用模板或手动添加</div>'}
      </div>
      <div style="padding:10px 14px;border-top:1px solid var(--line-soft);
                  display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <button class="btn primary" data-act="run"
                ${(!curSrc && !multiSrc.length) || !steps.length ? 'disabled' : ''}>
          <span data-icon="bolt"></span>开始出片${multiMode && multiSrc.length > 1 ? ` (${multiSrc.length})` : ''}
        </button>
        <button class="btn" data-act="caption"><span data-icon="chat"></span>AI 生成文案</button>
        <span style="font-size:10.5px;color:var(--tx-3)">
          ${!curSrc ? '先选源素材' : !steps.length ? '先加步骤' : '视频合成全本地，不联网'}
        </span>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">发布文案（可选）</div>
        <span class="chip">${store.dsh?.modelCount || 0} 个模型可用</span>
      </div>
      <div class="card-body">
        <div class="row-2">
          <div class="field" style="margin:0">
            <label>参考标题</label>
            <input class="input" id="vm-ref" value="When she walked into the banquet, everyone laughed — until the CEO called her mother." />
          </div>
          <div class="field" style="margin:0">
            <label>模型</label>
            <select class="select" id="vm-model">
              <option value="">默认（${esc(store.dsh?.selected || '自动')}）</option>
              ${(store.dsh?.models || []).filter((m) => m.free).slice(0, 30).map((m) =>
                `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}
            </select>
          </div>
        </div>
        <div id="vm-cap-out" style="margin-top:10px"></div>
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        文案用 DSH 模型生成，视频合成完全不用模型（内置 ffmpeg）。两者独立。
      </div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">出片任务</div></div>
      <div class="card-body tight" style="max-height:340px;overflow-y:auto">
        ${jobs.length ? jobs.slice(0, 20).map((j) => {
          const st = j.status === 'running' ? ['执行中', 'info']
            : j.status === 'done' ? ['完成', 'ok']
            : j.status === 'failed' ? ['失败', 'danger']
            : ['排队', 'mute'];
          const res = j.result || {};
          return `
            <div class="litem" style="flex-direction:column;align-items:stretch;gap:6px">
              <div style="display:flex;gap:8px;align-items:center">
                <div class="litem-title" style="flex:1">${esc(j.title)} ${badge(st[0], st[1], j.status === 'running')}</div>
                <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">${j.progress || 0}%</span>
              </div>
              ${bar(j.progress || 0, j.status === 'failed' ? 'danger' : j.status === 'done' ? 'ok' : '')}
              ${(j.steps || []).length ? `
                <div style="display:flex;flex-direction:column;gap:3px">
                  ${(j.steps || []).map((s) => `
                    <div style="display:flex;gap:7px;font-size:10.5px">
                      <span style="color:${s.state === 'done' ? 'var(--ok)' : s.state === 'err' ? 'var(--danger)' : s.state === 'run' ? 'var(--ac)' : 'var(--tx-3)'}">
                        ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : s.state === 'run' ? '…' : '·'}
                      </span>
                      <span style="flex:1;color:var(--tx-2)">${esc(s.name)}</span>
                      <span style="color:var(--tx-3);font-family:var(--mono);font-size:9.5px">${esc(s.note || '')}</span>
                    </div>`).join('')}
                </div>` : ''}
              ${res.output ? `
                <div style="font-size:10px;color:var(--ok);font-family:var(--mono);word-break:break-all">
                  ${esc(res.output)}
                </div>` : ''}
              ${j.error ? `<div style="font-size:10px;color:var(--danger)">${esc(j.error)}</div>` : ''}
            </div>`;
        }).join('') : '<div class="litem" style="justify-content:center;color:var(--tx-3);padding:22px">还没有出片任务</div>'}
      </div>
    </div>
  `;

  ['pick', 'pick2', 'pick3'].forEach((a) => {
    $$(`[data-act="${a}"]`, body).forEach((b) => (b.onclick = () => { multiMode = false; openPick(root); }));
  });
  ['multi', 'multi2'].forEach((a) => {
    $$(`[data-act="${a}"]`, body).forEach((b) => (b.onclick = () => openMulti(root)));
  });
  $$('[data-act="clearmulti"]', body).forEach((b) => (b.onclick = () => {
    multiSrc = []; paint(root);
  }));
  $$('[data-tpl]', body).forEach((el) => {
    el.onclick = () => {
      const t = templates.find((x) => x.id === el.dataset.tpl);
      if (!t) return;
      steps = JSON.parse(JSON.stringify(t.steps));
      toast('已套用', t.name, 'ok');
      paint(root);
    };
  });
  $$('[data-act="addstep"]', body).forEach((b) => (b.onclick = () => openAddStep(root)));
  $$('[data-act="clearstep"]', body).forEach((b) => (b.onclick = () => { steps = []; paint(root); }));
  $$('[data-rmstep]', body).forEach((b) => {
    b.onclick = () => { steps.splice(+b.dataset.rmstep, 1); paint(root); };
  });
  $$('[data-act="run"]', body).forEach((b) => (b.onclick = () => runMake(root, b)));
  $$('[data-act="caption"]', body).forEach((b) => (b.onclick = async () => {
    const out = document.getElementById('vm-cap-out');
    const ref = (document.getElementById('vm-ref')?.value || '').trim();
    const model = document.getElementById('vm-model')?.value || '';
    if (!ref) return toast('先填参考标题', '', 'err');
    b.disabled = true;
    const old = b.innerHTML;
    b.innerHTML = '<span class="spin" data-icon="chat"></span>生成中';
    out.innerHTML = '<div style="font-size:11px;color:var(--tx-3)">模型生成中，可能要 20–60 秒…</div>';
    try {
      const r = await api.videoCaption({ title: ref, model, n: 3 });
      out.innerHTML = `
        <div class="card"><div class="card-body tight">
          ${(r.titles || []).map((t, i) => `
            <div class="litem">
              <span style="width:18px;font-family:var(--mono);font-size:10px;color:var(--tx-3)">${i + 1}</span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px;line-height:1.5">${esc(t)}</div>
              </div>
            </div>`).join('')}
        </div>
        <div style="padding:8px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3)">
          来源：${esc(r.source || '')}
        </div></div>`;
      toast('生成完成', `${(r.titles || []).length} 条 · ${r.source}`, 'ok');
    } catch (e) {
      out.innerHTML = `<div style="font-size:11px;color:var(--danger)">${esc(e.message)}</div>`;
    } finally {
      b.disabled = false;
      b.innerHTML = old;
    }
  }));
}

/* ---------------- 多文件夹选择 ---------------- */
async function openMulti(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div style="display:flex;gap:6px;align-items:center;margin-bottom:10px">
      <button class="btn xs ghost" id="mf-up">↑ 上级</button>
      <div id="mf-path" style="flex:1;font-family:var(--mono);font-size:10px;
                                color:var(--tx-2);overflow:hidden;text-overflow:ellipsis;
                                white-space:nowrap"></div>
    </div>
    <div class="card" style="margin-bottom:10px"><div class="card-body tight"
         id="mf-list" style="max-height:320px;overflow-y:auto">
      <div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11px">加载中…</div>
    </div></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn sm" id="mf-selectall">全选当前目录</button>
      <button class="btn sm ghost" id="mf-scanall">递归扫描所有子目录</button>
    </div>
    <div class="hint" style="margin-top:8px">
      点文件夹进入 · 勾选视频 · 可跨多个文件夹累积
    </div>
    <div id="mf-picked" style="margin-top:10px"></div>`;

  let curPath = '';
  const picked = new Set();

  const m = modal({
    title: '选择多个文件夹 / 视频', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '确定',
        onclick: () => {
          multiSrc = [...picked];
          multiMode = multiSrc.length > 0;
          if (multiSrc.length === 1) { curSrc = multiSrc[0].path; }
          toast('已选', `${multiSrc.length} 个文件`, 'ok');
          m.close();
          paint(root);
        },
      }),
    ],
  });

  const renderPicked = () => {
    body.querySelector('#mf-picked').innerHTML = picked.size ? `
      <div class="section-title">已选 ${picked.size} 个</div>
      <div style="max-height:120px;overflow-y:auto">
        ${[...picked].slice(0, 20).map((p) => `
          <div class="litem" style="padding:4px 0">
            <div class="litem-main">
              <div class="litem-title" style="font-size:10px">${esc(p.split('\\').pop())}</div>
            </div>
          </div>`).join('')}
      </div>` : '';
  };

  const browse = async (path) => {
    const list = body.querySelector('#mf-list');
    list.innerHTML = '<div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11px">加载中…</div>';
    try {
      const r = await api.videoBrowse(path);
      curPath = r.path;
      body.querySelector('#mf-path').textContent = r.path;
      const dirs = r.dirs || [];
      const files = r.files || [];
      list.innerHTML = `
        ${dirs.map((d) => `
          <div class="litem" data-dir="${esc(d.path)}" style="cursor:pointer">
            <span style="color:var(--ac)">📁</span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11.5px">${esc(d.name)}</div>
              <div class="litem-sub" style="font-size:9.5px">
                ${d.videos} 个视频${d.subdirs ? ` · ${d.subdirs} 个子目录` : ''}
              </div>
            </div>
            <span style="font-size:10px;color:var(--tx-3)">进入 ›</span>
          </div>`).join('')}
        ${files.map((f) => `
          <label class="litem" style="cursor:pointer">
            <input type="checkbox" data-file="${esc(f.path)}"
                   style="width:14px;height:14px;accent-color:var(--ac)"
                   ${picked.has(f.path) ? 'checked' : ''} />
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">${esc(f.name)}</div>
            </div>
            <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${f.sizeMb}MB</span>
          </label>`).join('')}
        ${!dirs.length && !files.length ? '<div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11px">空目录</div>' : ''}
      `;
      list.querySelectorAll('[data-dir]').forEach((el) => {
        el.onclick = () => browse(el.dataset.dir);
      });
      list.querySelectorAll('[data-file]').forEach((cb) => {
        cb.onchange = () => {
          const p = cb.dataset.file;
          if (cb.checked) {
            const f = files.find((x) => x.path === p);
            picked.add(p);
            renderPicked();
          } else {
            picked.delete(p);
            renderPicked();
          }
        };
      });
    } catch (e) {
      list.innerHTML = `<div style="padding:16px;color:var(--danger);font-size:11px">${esc(e.message)}</div>`;
    }
  };

  body.querySelector('#mf-up').onclick = () => {
    const parts = curPath.split('\\');
    if (parts.length > 1) browse(parts.slice(0, -1).join('\\'));
  };
  body.querySelector('#mf-selectall').onclick = async () => {
    try {
      const r = await api.videoScan([curPath], false);
      (r.items || []).forEach((x) => picked.add(x.path));
      renderPicked();
      toast('已选当前目录', `${r.count} 个`, 'ok');
      browse(curPath);
    } catch (e) { toast('失败', e.message, 'err'); }
  };
  body.querySelector('#mf-scanall').onclick = async () => {
    try {
      const r = await api.videoScan([curPath], true);
      (r.items || []).forEach((x) => picked.add(x.path));
      renderPicked();
      toast('递归扫描完成', `${r.count} 个视频 · ${r.totalMb} MB`, 'ok', 6000);
    } catch (e) { toast('失败', e.message, 'err'); }
  };

  browse('');
}

/* ---------------- 选素材 ---------------- */
function openPick(root) {
  const lib = (store.library || []).filter((x) => x.state === 'ready');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>从素材库选（${lib.length} 条可剪辑）</label>
      <div class="card"><div class="card-body tight" style="max-height:320px;overflow-y:auto">
        ${lib.length ? lib.map((x) => `
          <div class="litem" data-pickone="${esc(x.path)}" style="cursor:pointer">
            <span class="dot ok"></span>
            <div class="litem-main">
              <div class="litem-title">${esc(x.drama)} ${x.ep || ''}</div>
              <div class="litem-sub">${esc(x.file)} · ${x.dur}s · ${x.size_mb}MB</div>
            </div>
          </div>`).join('')
          : '<div class="litem" style="justify-content:center;color:var(--tx-3);padding:20px">素材库没有可剪辑的素材</div>'}
      </div></div>
    </div>
    <div class="field">
      <label>或手动输入路径</label>
      <input class="input" id="pk-path" placeholder="粘贴完整路径，例如 D:/素材/xxx.mp4"
             style="font-family:var(--mono);font-size:11px" />
    </div>`;
  const m = modal({
    title: '选择源素材', width: 'wide', body,
    clickOutsideClose: false,      // 长列表：点外面不关，避免选到一半被误触关掉
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '确定',
        onclick: async () => {
          const p = (body.querySelector('#pk-path').value || '').trim();
          if (!p) return toast('请选择或输入路径', '', 'err');
          await setSrc(root, p);
          m.close();
        },
      }),
    ],
  });
  body.querySelectorAll('[data-pickone]').forEach((el) => {
    el.onclick = async () => {
      await setSrc(root, el.dataset.pickone);
      m.close();
    };
  });
}

async function setSrc(root, path) {
  try {
    const r = await api.videoProbe(path);
    curSrc = path;
    curInfo = r;
    toast('已选素材', `${r.dur}s · ${r.w}x${r.h}`, 'ok');
    paint(root);
  } catch (e) {
    toast('读取失败', e.message, 'err');
  }
}

/* ---------------- 加步骤 ---------------- */
function openAddStep(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>操作</label>
      <select class="select" id="st-op">
        <option value="clip">切片（按时间截取）</option>
        <option value="vertical">转竖屏（9:16）</option>
        <option value="speed">变速</option>
        <option value="subtitle">加字幕</option>
        <option value="normalize">响度归一</option>
      </select>
    </div>
    <div id="st-fields"></div>`;
  const renderFields = () => {
    const op = body.querySelector('#st-op').value;
    const box = body.querySelector('#st-fields');
    if (op === 'clip') {
      box.innerHTML = `
        <div class="row-2">
          <div class="field"><label>开始（秒）</label><input class="input" id="st-start" type="number" value="0" step="0.1" /></div>
          <div class="field"><label>结束（秒）</label><input class="input" id="st-end" type="number" value="${curInfo?.dur ? Math.min(45, curInfo.dur) : 45}" step="0.1" /></div>
        </div>`;
    } else if (op === 'vertical') {
      box.innerHTML = `
        <div class="field"><label>比例</label>
          <select class="select" id="st-ratio">
            <option value="9:16">9:16（Reels）</option>
            <option value="4:5">4:5（Feed）</option>
          </select>
        </div>`;
    } else if (op === 'speed') {
      box.innerHTML = `
        <div class="field"><label>倍速（0.5–2.0）</label>
          <input class="input" id="st-speed" type="number" value="1.1" step="0.05" min="0.5" max="2" /></div>`;
    } else if (op === 'subtitle') {
      box.innerHTML = `
        <div class="field"><label>字幕文字</label>
          <input class="input" id="st-text" placeholder="Watch the full series 👇" /></div>
        <div class="row-2">
          <div class="field"><label>字号</label><input class="input" id="st-size" type="number" value="42" /></div>
          <div class="field"><label>颜色</label>
            <select class="select" id="st-color"><option>white</option><option>yellow</option><option>#ff3b30</option></select></div>
        </div>`;
    } else {
      box.innerHTML = `
        <div class="field"><label>目标响度（LUFS）</label>
          <input class="input" id="st-lufs" type="number" value="-14" step="0.5" />
          <div class="hint">平台推荐 -14 LUFS</div></div>`;
    }
  };
  body.querySelector('#st-op').onchange = renderFields;
  renderFields();

  const m = modal({
    title: '添加步骤', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '添加',
        onclick: () => {
          const op = body.querySelector('#st-op').value;
          const s = { op };
          const g = (id) => body.querySelector(id);
          if (op === 'clip') {
            s.start = parseFloat(g('#st-start').value) || 0;
            s.end = parseFloat(g('#st-end').value) || 45;
            s.name = `截取 ${s.start}–${s.end}s`;
          } else if (op === 'vertical') {
            s.ratio = g('#st-ratio').value;
            s.name = `转竖屏 ${s.ratio}`;
          } else if (op === 'speed') {
            s.speed = parseFloat(g('#st-speed').value) || 1;
            s.name = `变速 ${s.speed}x`;
          } else if (op === 'subtitle') {
            s.text = g('#st-text').value || '';
            s.fontSize = parseInt(g('#st-size').value, 10) || 42;
            s.color = g('#st-color').value;
            s.name = `字幕：${(s.text || '').slice(0, 20)}`;
          } else {
            s.lufs = parseFloat(g('#st-lufs').value) || -14;
            s.name = `归一 ${s.lufs} LUFS`;
          }
          steps.push(s);
          toast('已添加', s.name, 'ok');
          m.close();
          paint(root);
        },
      }),
    ],
  });
}

/* ---------------- 执行 ---------------- */
async function runMake(root, btn) {
  const srcs = multiMode && multiSrc.length ? multiSrc.map((x) => x.path) : [curSrc];
  if (!srcs.length || !srcs[0]) return toast('先选源素材', '', 'err');
  if (!steps.length) return toast('先加步骤', '', 'err');

  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="bolt"></span>提交中…';
  try {
    let jobIds = [];
    if (srcs.length > 1) {
      // 批量：同一套步骤套所有源
      const r = await api.videoBatch({ sources: srcs, template: { steps } });
      jobIds = r.jobs || [];
      toast('已入队', `${jobIds.length} 个任务`, 'ok');
    } else {
      const r = await api.videoMake({ src: srcs[0], steps, title: `出片 ${srcs[0].split('\\').pop()}` });
      jobIds = [r.jobId];
      toast('已入队', `任务 ${r.jobId}`, 'ok');
    }

    // 轮询最后一个
    const t0 = Date.now();
    while (Date.now() - t0 < 3600000) {
      await new Promise((res) => setTimeout(res, 2500));
      const j = await api.job(jobIds[jobIds.length - 1]);
      btn.innerHTML = `<span class="spin" data-icon="bolt"></span>${j.progress || 0}%`;
      if (['done', 'failed', 'blocked'].includes(j.status)) {
        const res = j.result || {};
        toast(j.status === 'done' ? '出片完成' : '出片失败',
          j.status === 'done' ? `${res.info?.dur}s · ${res.info?.size_mb}MB` : (j.error || ''),
          j.status === 'done' ? 'ok' : 'err', 7000);
        break;
      }
    }
    await load(root);
  } catch (e) {
    toast('提交失败', e.message, 'err', 6000);
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
