/* 设置（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import { pageHead, $, $$, toast, badge } from '../ui.js';

let cfg = {};
let paths = { items: [], snapshot: {}, configFile: '' };
let upd = { version: '1.0.0', fileCount: 0, backups: [], hotCount: {} };

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '设置',
      desc: '全局配置、路径、安全阀',
      actions: [`<button class="btn sm primary" data-act="save">保存配置</button>`],
    })}
    <div id="st-body"></div>
  `;
  $$('[data-act="save"]', root).forEach((b) => (b.onclick = () => doSave(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    cfg = await api.config();
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  try {
    paths = await api.envPaths();
  } catch { paths = { items: [], snapshot: {}, configFile: '' }; }
  try {
    upd = await api.updateStatus();
  } catch { /* ignore */ }
  paint(root);
  bindPaths(root);
  // 检查内置 ffmpeg
  try {
    const env = await api.videoEnv();
    const a = document.getElementById('ff-status');
    const b = document.getElementById('ffp-status');
    if (a) a.innerHTML = env.ok
      ? `<span style="color:var(--ok)">✓ ${env.bundled ? '内置' : '系统'} · ${esc((env.version || '').slice(0, 40))}</span>`
      : `<span style="color:var(--danger)">✗ ${esc(env.error || '不可用')}</span>`;
    if (b) b.innerHTML = env.ok
      ? `<span style="color:var(--ok)">✓ 可用</span>`
      : `<span style="color:var(--danger)">✗</span>`;
  } catch { /* ignore */ }
}

/* ---------------- 路径配置 ---------------- */
function bindPaths(root) {
  const save = document.getElementById('path-save');
  if (save) {
    save.onclick = async () => {
      const patch = {};
      $$('.path-in', root).forEach((el) => {
        if (!el.readOnly) patch[el.dataset.key] = el.value.trim();
      });
      save.disabled = true; save.textContent = '保存中…';
      try {
        const r = await api.envPathsSave(patch);
        toast('已保存', r.note || '', 'ok', 6000);
        paths = await api.envPaths();
        paint(root); bindPaths(root);
      } catch (e) { toast('保存失败', e.message, 'err'); }
      finally { save.disabled = false; save.textContent = '保存'; }
    };
  }
  const ens = document.getElementById('path-ensure');
  if (ens) {
    ens.onclick = async () => {
      ens.disabled = true; ens.textContent = '创建中…';
      try {
        const r = await api.envEnsureDirs();
        toast(r.created.length ? `已创建 ${r.created.length} 个目录` : '目录都已存在',
          (r.created || []).join('\n'), 'ok', 6000);
        paths = await api.envPaths();
        paint(root); bindPaths(root);
      } catch (e) { toast('创建失败', e.message, 'err'); }
      finally { ens.disabled = false; ens.textContent = '创建缺失目录'; }
    };
  }
}

function paint(root) {
  const body = $('#st-body', root);
  if (!body) return;
  const h = store.summary || {};

  body.innerHTML = `
    <div class="grid g2">
      <div class="card">
        <div class="card-head"><div class="card-title">账号与环境</div></div>
        <div class="card-body">
          ${(store.envs || []).filter((e) => e.role !== 'spare').map((a) => `
            <div class="field" style="border:1px solid var(--line-soft);border-radius:var(--r-md);padding:11px 12px">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                <strong style="font-size:12.5px">${esc(a.roleLabel)}</strong>
                <span class="badge ${a.role === 'publisher' ? 'info' : 'purple'}">${esc(a.name)}</span>
                <span class="chip ghost" style="margin-left:auto">${a.containerCode}</span>
              </div>
              <div class="row-2">
                <div class="field" style="margin:0"><label>邮箱</label>
                  <input class="input" value="${esc(a.account || '未登录')}" readonly style="color:var(--tx-2)" /></div>
                <div class="field" style="margin:0"><label>c_user</label>
                  <input class="input" value="${a.cUser || '—'}" readonly style="color:var(--tx-2)" /></div>
              </div>
            </div>`).join('') || '<div class="hint">未发现环境</div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">路径（跨环境可改）</div>
          <div style="display:flex;gap:5px">
            <button class="btn xs ghost" id="path-ensure">创建缺失目录</button>
            <button class="btn xs primary" id="path-save">保存</button>
          </div>
        </div>
        <div class="card-body">
          <div class="hint" style="margin-bottom:9px">
            换电脑/换目录只改这里。优先级：环境变量 &gt; 本页保存的值 &gt; 自动发现。
            保存后写入 <code style="font-family:var(--mono)">config.json</code>，重启生效。
          </div>
          ${(paths.items || []).map((p) => `
            <div class="field" style="margin-bottom:8px">
              <label style="display:flex;align-items:center;gap:6px">
                ${esc(p.label)}
                <span class="badge ${p.source === '自动发现' ? 'mute'
                  : p.source === '环境变量' ? 'info' : 'ok'}" style="font-size:8.5px">${p.source}</span>
                <span style="margin-left:auto;font-size:9px;color:var(--tx-3);
                             font-family:var(--mono)">${esc(p.envKey)}</span>
              </label>
              <input class="input path-in" data-key="${esc(p.key)}"
                     value="${esc(p.value || '')}"
                     ${p.source === '环境变量' ? 'readonly' : ''}
                     style="font-family:var(--mono);font-size:10.5px;
                            ${p.source === '环境变量' ? 'color:var(--tx-2)' : ''}" />
            </div>`).join('')}
          <div class="field" style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)">
            <label>只读信息</label>
            <div style="font-size:10px;color:var(--tx-2);line-height:1.9;font-family:var(--mono)">
              <div>数据目录 ${esc(paths.snapshot?.dataDir || cfg.dataDir || '')}</div>
              <div>数据库 ${esc(cfg.dbPath || '')}</div>
              <div>前端 ${esc(cfg.frontendDir || '')}</div>
              <div>配置文件 ${esc(paths.configFile || '')}</div>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">网络与接口</div></div>
        <div class="card-body">
          <div class="row-2">
            <div class="field"><label>Hubstudio API</label>
              <input class="input" id="cfg-hubstudioApi" value="${esc(cfg.hubstudioApi || '')}"
                     style="font-family:var(--mono);font-size:11px" /></div>
            <div class="field"><label>Clash API</label>
              <input class="input" id="cfg-clashApi" value="${esc(cfg.clashApi || '')}"
                     style="font-family:var(--mono);font-size:11px" /></div>
          </div>
          <div class="field">
            <label>Node 命令</label>
            <input class="input" readonly value="${esc((cfg.nodeCommand || []).join(' '))}"
                   style="font-family:var(--mono);font-size:11px;color:var(--tx-2)" />
            <div class="hint">用于跑 ReelsPublisher 的 .mjs 脚本</div>
          </div>
          <div class="kv"><span class="k">后端端口</span><span class="v">${cfg.port || 8710}</span></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">AI 模型端点</div></div>
        <div class="card-body">
          <div class="field">
            <label>OpenAI 兼容端点（base URL）</label>
            <input class="input" id="cfg-llmBase" value="${esc(cfg.llmBase || '')}"
                   placeholder="https://api.deepseek.com" style="font-family:var(--mono);font-size:11px" />
            <div class="hint">
              DSH 的免费模型不对外暴露网关，要 AI 分析生效需填一个兼容端点。
              留空则 AI 分析走规则统计兜底（不编造结论）。
            </div>
          </div>
          <div class="field">
            <label>API Key</label>
            <input class="input" id="cfg-llmKey" type="password" value="${esc(cfg.llmKey || '')}"
                   placeholder="sk-..." style="font-family:var(--mono);font-size:11px" />
          </div>
          <div class="field">
            <label>默认模型名</label>
            <input class="input" id="cfg-llmModel" value="${esc(cfg.llmModel || 'deepseek-chat')}"
                   placeholder="deepseek-chat" style="font-family:var(--mono);font-size:11px" />
          </div>
          <div class="kv"><span class="k">当前状态</span>
            <span class="v" style="color:${cfg.llmBase ? 'var(--ok)' : 'var(--warn)'}">
              ${cfg.llmBase ? '已配置' : '未配置（规则兜底）'}</span></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">内置工具</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">ffmpeg</span>
            <span class="v" id="ff-status">检查中…</span></div>
          <div class="kv"><span class="k">ffprobe</span>
            <span class="v" id="ffp-status">检查中…</span></div>
          <div style="margin-top:9px;padding:9px 11px;background:var(--bg-0);
                      border-radius:var(--r-sm);font-size:10px;color:var(--tx-3);line-height:1.7">
            视频制作全部用内置 ffmpeg，不依赖外部程序。换电脑照样能用。
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">安全阀（后端强制）</div></div>
        <div class="card-body">
          ${[
            ['授权只认 profile ID', '姓名/邮箱请求 → 422', true],
            ['建主页每日上限', '默认 2，超出 400', true],
            ['服务端拒绝即停手', '非 transient 错误直接 break', true],
            ['发布只认受理回执', '看不到回执判失败', true],
            ['失败不删素材', '仅成功才 unlink', true],
            ['排期每日上限', '同页同日超出 → 400', true],
            ['排期最小间隔', '默认 120 分钟', true],
            ['风控命中即熔断', '账号级整批停止', true],
            ['标签页复用', '单实例单标签', true],
          ].map(([k, v, on]) => `
            <div class="litem" style="padding:7px 0">
              <span class="dot ${on ? 'ok' : ''}"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">${k}</div>
                <div class="litem-sub" style="font-family:var(--sans);font-size:10px">${v}</div>
              </div>
              ${on ? badge('启用', 'ok') : badge('关闭', 'mute')}
            </div>`).join('')}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">数据概况</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">主页</span><span class="v">${h.pages || 0} 个</span></div>
          <div class="kv"><span class="k">视频</span><span class="v">${h.videoCount || 0} 条</span></div>
          <div class="kv"><span class="k">素材库</span><span class="v">${h.libReady || 0} 条可发布</span></div>
          <div class="kv"><span class="k">队列</span><span class="v">${h.queueReady || 0} 条待发</span></div>
          <div class="kv"><span class="k">排期</span><span class="v">${h.schedulePlanned || 0} 条已排</span></div>
          <div class="kv"><span class="k">风控未处理</span><span class="v" style="color:${h.alerts ? 'var(--danger)' : 'var(--ok)'}">${h.alerts || 0} 条</span></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">关于</div></div>
        <div class="card-body">
          <div class="kv"><span class="k">版本</span><span class="v">${esc(upd.version || '1.0.0')}</span></div>
          <div class="kv"><span class="k">前端</span><span class="v">原生 JS · 无构建</span></div>
          <div class="kv"><span class="k">后端</span><span class="v">FastAPI · SQLite WAL</span></div>
          <div class="kv"><span class="k">浏览器控制</span><span class="v">裸 CDP WebSocket</span></div>
          <div class="kv"><span class="k">发布内核</span><span class="v">ReelsPublisher v19.7</span></div>
        </div>
      </div>

      <!-- 热更新 -->
      <div class="card" style="grid-column:1/-1">
        <div class="card-head">
          <div class="card-title">
            <span data-icon="refresh"></span> 系统更新
            <span class="badge ${upd.hasExtApp ? 'ok' : 'mute'}"
                  style="font-size:8.5px;margin-left:5px">
              ${upd.hasExtApp ? '支持热更新' : '未启用外部代码'}</span>
          </div>
          <div style="display:flex;gap:6px">
            <input type="file" id="upd-file" accept=".zip" style="display:none" />
            <button class="btn xs" id="upd-pick">选择更新包</button>
            <button class="btn xs primary" id="upd-apply" disabled>应用更新</button>
          </div>
        </div>
        <div class="card-body">
          <div style="font-size:10.5px;color:var(--tx-2);line-height:1.9">
            <b>不用重新打包</b>：更新包只替换 <code style="font-family:var(--mono)">app\</code>
            和 <code style="font-family:var(--mono)">frontend\</code> 两个目录
            （约 ${upd.fileCount || 0} 个文件），数据库和素材不动。
            <br/>
            <span style="color:var(--tx-3);font-size:9.5px">
              流程：选 zip → 校验 → 应用（自动备份）→ 3 秒后重启。
              校验失败或版本不对会自动回滚。
            </span>
          </div>

          <div style="display:flex;gap:14px;margin-top:10px;font-size:10px;
                      color:var(--tx-3);flex-wrap:wrap">
            <span>当前版本 <b style="color:var(--tx-1)">${esc(upd.version || '1.0.0')}</b></span>
            <span>更新于 ${esc(upd.updatedAt ? ago(upd.updatedAt) : '—')}</span>
            <span>文件 ${upd.fileCount || 0} 个
              （app ${upd.hotCount?.app || 0} · 前端 ${upd.hotCount?.frontend || 0}）</span>
          </div>

          <div id="upd-out" style="margin-top:9px;font-size:10px;line-height:1.8;
               color:var(--tx-3);font-family:var(--mono)"></div>

          ${(upd.backups || []).length ? `
          <div style="margin-top:11px;padding-top:10px;border-top:1px solid var(--line)">
            <div style="font-size:10px;color:var(--tx-2);font-weight:600;margin-bottom:6px">
              备份（可回滚）</div>
            <div style="display:flex;flex-direction:column;gap:4px">
              ${upd.backups.map((b) => `
                <div class="litem" style="padding:4px 0">
                  <span class="dot ok"></span>
                  <div class="litem-main">
                    <div class="litem-title" style="font-size:10px;font-family:var(--mono)">
                      ${esc(b.name)}</div>
                  </div>
                  <button class="btn xs ghost" data-rollback="${esc(b.name)}">回滚</button>
                </div>`).join('')}
            </div>
          </div>` : ''}
        </div>
      </div>
    </div>
  `;
  bindUpdate(root);
}

/* ---------------- 热更新绑定 ---------------- */
function bindUpdate(root) {
  const fileIn = document.getElementById('upd-file');
  const pick = document.getElementById('upd-pick');
  const apply = document.getElementById('upd-apply');
  const out = document.getElementById('upd-out');
  let picked = null;

  const say = (html) => { if (out) out.innerHTML = html; };

  if (pick && fileIn) {
    pick.onclick = () => fileIn.click();
    fileIn.onchange = async () => {
      const f = fileIn.files?.[0];
      if (!f) return;
      picked = null;
      apply.disabled = true;
      say(`<div style="color:var(--tx-2)">校验中：${esc(f.name)} …</div>`);
      try {
        const r = await api.updateUpload(f);
        picked = r;
        say(`<div style="color:var(--ok)">✓ 包有效 · 版本 ${esc(r.version)} ·
              ${r.fileCount} 个文件</div>
             <div style="color:var(--tx-3);font-size:9.5px">${esc(r.note || '')}</div>`);
        apply.disabled = false;
        toast('更新包已校验', `${r.version} · ${r.fileCount} 文件`, 'ok');
      } catch (e) {
        say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
        toast('校验失败', e.message, 'err', 7000);
      }
    };
  }

  if (apply) {
    apply.onclick = async () => {
      if (!picked) return;
      if (!confirm(`应用更新到 ${picked.version}？\n会先自动备份，然后 3 秒后重启程序。`)) return;
      apply.disabled = true;
      apply.textContent = '应用中…';
      say('<div style="color:var(--tx-2)">正在覆盖文件并校验…</div>');
      try {
        const r = await api.updateApply(true);
        say(`<div style="color:var(--ok)">✓ 已更新到 ${esc(r.version)}（${r.files} 个文件）</div>
             <div style="color:var(--tx-3)">${esc(r.note || '')}</div>
             <div style="color:var(--warn)">程序即将重启…</div>`);
        toast('更新成功', '3 秒后重启', 'ok', 8000);
      } catch (e) {
        say(`<div style="color:var(--danger)">✗ ${esc(e.message)}</div>`);
        toast('更新失败', e.message, 'err', 8000);
        apply.disabled = false;
        apply.textContent = '应用更新';
      }
    };
  }

  $$('[data-rollback]', root).forEach((b) => {
    b.onclick = async () => {
      const name = b.dataset.rollback;
      if (!confirm(`回滚到 ${name}？\n当前 app/frontend 会被该备份覆盖，然后重启。`)) return;
      b.disabled = true;
      try {
        const r = await api.updateRollback(name);
        toast('已回滚', `${r.backup} · 3 秒后重启`, 'ok', 8000);
        say(`<div style="color:var(--ok)">✓ 已回滚到 ${esc(r.backup)}</div>`);
      } catch (e) {
        toast('回滚失败', e.message, 'err', 7000);
        b.disabled = false;
      }
    };
  });
}

async function doSave(root) {
  const patch = {};
  const g = (id) => {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
  };
  ['hubstudioApi', 'clashApi', 'reelsEnvDir', 'libraryRoot',
   'llmBase', 'llmKey', 'llmModel'].forEach((k) => {
    const v = g('cfg-' + k);
    if (v !== '') patch[k] = v;
  });
  const roots = g('cfg-assetRoots');
  if (roots) patch.assetRoots = roots.split(';').map((s) => s.trim()).filter(Boolean);
  try {
    await api.saveConfig(patch);
    toast('已保存', '部分配置需重启后端生效', 'ok', 5000);
    await load(root);
  } catch (e) {
    toast('保存失败', e.message, 'err');
  }
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
