/* 公共主页（真实数据版） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import {
  nfmt, badge, pageHead, sparkline, statCard, $, $$, toast, modal, bar, ts, ago, emptyState,
} from '../ui.js';

let viewMode = 'grid';
let filter = { q: '', health: 'all', sort: 'views' };

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '公共主页',
      desc: '主页是发布通道，数据看「视频数据」页',
      actions: [
        `<button class="btn sm" data-act="pid"><span data-icon="route"></span>按 PID 提取</button>`,
        `<button class="btn sm primary" data-act="create"><span data-icon="plus"></span>创建主页</button>`,
      ],
    })}
    <div id="pg-body"></div>
  `;
  $$('[data-act="create"]', root).forEach((b) => (b.onclick = openCreate));
  $$('[data-act="pid"]', root).forEach((b) => (b.onclick = openPid));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    await store.loadCore();
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  paint(root);
}

function paint(root) {
  const body = $('#pg-body', root);
  if (!body) return;
  const all = store.pages || [];
  const s = store.summary || {};

  let list = all.slice();
  if (filter.q) {
    const k = filter.q.toLowerCase();
    list = list.filter((p) => (p.name || '').toLowerCase().includes(k)
      || (p.profileId || '').includes(k) || (p.assetId || '').includes(k));
  }
  if (filter.health !== 'all') list = list.filter((p) => p.health === filter.health);
  const sorters = {
    views: (a, b) => (b.views30d || 0) - (a.views30d || 0),
    followers: (a, b) => (b.followers || 0) - (a.followers || 0),
    name: (a, b) => String(a.name).localeCompare(String(b.name)),
    published: (a, b) => (b.published || 0) - (a.published || 0),
  };
  list.sort(sorters[filter.sort] || sorters.views);

  const noAsset = all.filter((p) => !p.assetId).length;
  const pending = all.filter((p) => !p.authz || !p.authz.backup || !p.authz.backup.present).length;

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '主页总数', value: all.length, unit: '个', iconName: 'flag' })}
      ${statCard({ label: '正常', value: all.filter((p) => p.health === 'ok').length, unit: '个', iconName: 'check' })}
      ${statCard({ label: '缺 asset_id', value: noAsset, unit: '个', iconName: 'warn',
                   foot: noAsset ? '无法发布与采集' : '全部齐备' })}
      ${statCard({ label: '备份号未覆盖', value: pending, unit: '个', iconName: 'shield' })}
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">筛选</div>
        <div class="seg" data-seg="view">
          <button class="${viewMode === 'grid' ? 'on' : ''}" data-v="grid">卡片</button>
          <button class="${viewMode === 'table' ? 'on' : ''}" data-v="table">表格</button>
        </div>
      </div>
      <div class="card-body" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
        <div class="field" style="flex:1;min-width:180px;margin:0">
          <label>搜索</label>
          <input class="input" id="pf-q" placeholder="主页名 / page_id / asset_id" value="${filter.q}" />
        </div>
        <div class="field" style="width:140px;margin:0">
          <label>状态</label>
          <select class="select" id="pf-health">
            <option value="all">全部</option>
            <option value="ok">正常</option>
            <option value="restricted">受限</option>
            <option value="pending">待授权</option>
          </select>
        </div>
        <div class="field" style="width:150px;margin:0">
          <label>排序</label>
          <select class="select" id="pf-sort">
            <option value="views">按播放</option>
            <option value="followers">按粉丝</option>
            <option value="name">按编号</option>
            <option value="published">按已发</option>
          </select>
        </div>
      </div>
    </div>

    <div id="pg-list">${viewMode === 'grid' ? gridHtml(list) : tableHtml(list)}</div>
  `;

  const q = $('#pf-q', root);
  q.oninput = (e) => { filter.q = e.target.value; repaint(root); q.focus(); q.setSelectionRange(filter.q.length, filter.q.length); };
  $('#pf-health', root).value = filter.health;
  $('#pf-sort', root).value = filter.sort;
  $('#pf-health', root).onchange = (e) => { filter.health = e.target.value; repaint(root); };
  $('#pf-sort', root).onchange = (e) => { filter.sort = e.target.value; repaint(root); };
  $$('[data-seg="view"] button', root).forEach((b) => {
    b.onclick = () => {
      viewMode = b.dataset.v;
      $$('[data-seg="view"] button', root).forEach((x) => x.classList.toggle('on', x === b));
      repaint(root);
    };
  });
  bind(root);
}

function repaint(root) {
  const all = store.pages || [];
  let list = all.slice();
  if (filter.q) {
    const k = filter.q.toLowerCase();
    list = list.filter((p) => (p.name || '').toLowerCase().includes(k)
      || (p.profileId || '').includes(k) || (p.assetId || '').includes(k));
  }
  if (filter.health !== 'all') list = list.filter((p) => p.health === filter.health);
  const sorters = {
    views: (a, b) => (b.views30d || 0) - (a.views30d || 0),
    followers: (a, b) => (b.followers || 0) - (a.followers || 0),
    name: (a, b) => String(a.name).localeCompare(String(b.name)),
    published: (a, b) => (b.published || 0) - (a.published || 0),
  };
  list.sort(sorters[filter.sort] || sorters.views);
  const wrap = $('#pg-list', root);
  wrap.innerHTML = viewMode === 'grid' ? gridHtml(list) : tableHtml(list);
  bind(root);
}

function healthBadge(h) {
  if (h === 'ok') return badge('正常', 'ok', true);
  if (h === 'restricted') return badge('受限', 'danger', true);
  if (h === 'pending') return badge('待授权', 'warn', true);
  return badge('未知', 'mute');
}

function gridHtml(list) {
  if (!list.length) {
    return `<div class="card"><div class="card-body">${emptyState('没有主页', '点「按 PID 提取」从账号拉取')}</div></div>`;
  }
  return `<div class="grid g3">${list.map((p) => `
    <div class="page-card" data-page="${p.profileId}">
      <div class="pc-top">
        <div class="pc-avatar">${esc(p.name)}</div>
        <div class="pc-name">
          <strong>${esc(p.name)}</strong>
          <span>${p.assetId || '⚠ 缺 asset_id'}</span>
        </div>
        ${healthBadge(p.health)}
      </div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--tx-3);margin-bottom:4px">
        ${p.profileId}
      </div>
      <div class="pc-metrics">
        <div class="pc-m"><b>${nfmt(p.views30d)}</b><span>30天播放</span></div>
        <div class="pc-m"><b>${nfmt(p.followers)}</b><span>粉丝</span></div>
        <div class="pc-m"><b>${p.published || 0}</b><span>已发</span></div>
      </div>
      <div class="pc-foot">
        <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${p.envCode || '—'}</span>
        <span style="display:flex;gap:4px">
          ${p.authz && p.authz.publisher && p.authz.publisher.present
            ? badge('发布号', 'info') : badge('发布号缺失', 'danger')}
          ${p.authz && p.authz.backup && p.authz.backup.present
            ? badge('备份号', 'purple') : badge('待授权', 'warn')}
        </span>
      </div>
    </div>`).join('')}</div>`;
}

function tableHtml(list) {
  return `<div class="card"><div class="card-body tight"><div class="tbl-wrap">
    <table class="tbl"><thead><tr>
      <th>主页</th><th>page_id</th><th>asset_id</th>
      <th class="num">30天播放</th><th class="num">粉丝</th><th class="num">已发</th>
      <th>授权</th><th>状态</th><th></th>
    </tr></thead><tbody>
      ${list.map((p) => `
        <tr data-page="${p.profileId}">
          <td><b>${esc(p.name)}</b></td>
          <td class="mono">${p.profileId}</td>
          <td class="mono">${p.assetId || '<span style="color:var(--danger)">缺失</span>'}</td>
          <td class="num">${nfmt(p.views30d)}</td>
          <td class="num">${nfmt(p.followers)}</td>
          <td class="num">${p.published || 0}</td>
          <td>
            <div style="display:flex;gap:3px">
              ${p.authz && p.authz.publisher && p.authz.publisher.present ? badge('发', 'info') : badge('—', 'mute')}
              ${p.authz && p.authz.backup && p.authz.backup.present ? badge('备', 'purple') : badge('—', 'mute')}
            </div>
          </td>
          <td>${healthBadge(p.health)}</td>
          <td class="row-actions"><button class="btn xs ghost" data-detail="${p.profileId}">展开</button></td>
        </tr>`).join('')}
    </tbody></table>
  </div></div></div>`;
}

function bind(root) {
  $$('[data-page]', root).forEach((el) => {
    el.onclick = (e) => {
      if (e.target.closest('[data-detail]')) return;
      openDetail(el.dataset.page);
    };
  });
  $$('[data-detail]', root).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openDetail(b.dataset.detail); };
  });
}

async function openDetail(pid) {
  let d;
  try { d = await api.pageDetail(pid); } catch (e) { return toast('失败', e.message, 'err'); }
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="grid g2" style="margin-bottom:14px">
      <div>
        <div class="kv"><span class="k">page_id</span><span class="v">${d.profileId}</span></div>
        <div class="kv"><span class="k">asset_id</span><span class="v" style="color:${d.assetId ? '' : 'var(--danger)'}">${d.assetId || '缺失'}</span></div>
        <div class="kv"><span class="k">环境</span><span class="v">${d.envCode || '—'}</span></div>
      </div>
      <div>
        <div class="kv"><span class="k">30天播放</span><span class="v">${nfmt(d.views30d)}</span></div>
        <div class="kv"><span class="k">粉丝</span><span class="v">${nfmt(d.followers)}</span></div>
        <div class="kv"><span class="k">已发布</span><span class="v">${d.published || 0}</span></div>
      </div>
    </div>
    <div class="section-title">授权</div>
    <div class="card" style="margin-bottom:14px"><div class="card-body tight">
      ${(d.roles || []).length ? (d.roles || []).map((r) => `
        <div class="litem">
          <span class="dot ${r.state === 'active' ? 'ok' : 'warn'}"></span>
          <div class="litem-main">
            <div class="litem-title">c_user ${r.c_user} ${badge(r.state, r.state === 'active' ? 'ok' : 'warn')}</div>
            <div class="litem-sub">${r.role} · ${r.granted_at || '—'}</div>
          </div>
        </div>`).join('')
        : '<div class="litem" style="justify-content:center;color:var(--tx-3)">无授权记录</div>'}
    </div></div>
    <div class="section-title">操作</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn sm" data-x="verify">核对权限</button>
      <button class="btn sm ghost" data-x="open">在浏览器打开</button>
    </div>`;
  const m = modal({
    title: `${d.name} 详情`, width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() })],
  });
  body.querySelectorAll('[data-x]').forEach((b) => {
    b.onclick = async () => {
      if (b.dataset.x === 'verify') {
        try {
          const r = await api.verifyAuthz(d.profileId);
          toast('核对完成', `发布号 ${r.publisherPresent ? '在' : '不在'} · 备份号 ${r.backupPresent ? '在' : '不在'}`, 'ok');
          load(document.getElementById('view'));
        } catch (e) { toast('核对失败', e.message, 'err'); }
      } else {
        toast('打开', `facebook.com/profile.php?id=${d.profileId}`, 'info');
      }
    };
  });
}

/* ---------------- 按 PID 提取 ---------------- */
function openPid() {
  const running = (store.envs || []).filter((e) => e.status === 'running');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>PID 或 CDP 端口</label>
      <input class="input" id="px-pid" placeholder="PID（如 12584）或端口（如 60005）"
             value="${running[0] ? (running[0].pid || running[0].cdpPort || '') : ''}"
             style="font-family:var(--mono)" />
      <div class="hint">
        注意：Hubstudio 的 containerId 不是进程 PID。不知道 PID 就填 CDP 端口，
        或直接从下面的已开环境里选。
      </div>
    </div>
    <div class="field">
      <label>已开环境</label>
      <select class="select" id="px-env">
        <option value="">— 手动输入 —</option>
        ${running.map((e) => `<option value="${e.containerCode}">${e.name} · PID ${e.pid || '—'} · 端口 ${e.cdpPort || '—'}</option>`).join('')}
      </select>
    </div>
    <div class="hint" style="margin-top:8px">
      提取会用当前登录身份读取该账号名下的全部主页（page_id + asset_id），
      与本地台账做差集后入库。全程拟人化操作，命中风控立即熔断。
    </div>`;
  const m = modal({
    title: '按 PID 提取主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn primary', textContent: '开始提取', id: 'px-run' }),
    ],
  });
  const pg = body.querySelector('#px-pid');
  body.querySelector('#px-env').onchange = (e) => {
    const env = running.find((x) => x.containerCode === e.target.value);
    if (env) pg.value = env.pid || env.cdpPort || '';
  };
  m.el.querySelector('#px-run').onclick = async () => {
    const v = (pg.value || '').trim();
    if (!v) return toast('请输入 PID 或端口', '', 'err');
    const btn = m.el.querySelector('#px-run');
    btn.disabled = true; btn.textContent = '提取中…';
    try {
      const isPort = +v > 40000;
      const r = isPort ? await api.extractPages(0, +v) : await api.extractPages(+v, 0);
      if (!r.ok) {
        toast('提取失败', r.error || '未知原因', 'err', 6000);
      } else {
        toast('提取完成', `c_user ${r.cUser} · ${r.count} 个主页`, 'ok');
        m.close();
        await load(document.getElementById('view'));
      }
    } catch (e) {
      toast('提取失败', e.message, 'err');
    } finally {
      btn.disabled = false; btn.textContent = '开始提取';
    }
  };
}

/* ---------------- 创建主页 ---------------- */
function openCreate() {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field"><label>主页名称</label><input class="input" id="cr-name" placeholder="Y16" /></div>
      <div class="field"><label>类别</label>
        <select class="select" id="cr-cat">
          <option>家居用品</option><option>电子产品店</option><option>宠物店</option>
          <option>餐饮服务</option><option>健身房/健身中心</option>
          <option>美容、美妆与个人护理</option><option>汽车服务</option>
          <option>本地服务</option><option>零售购物</option>
        </select>
      </div>
    </div>
    <div class="field"><label>简介</label><textarea class="textarea" id="cr-bio"></textarea></div>
    <div class="row-2">
      <div class="field"><label>数量</label><input class="input" id="cr-count" type="number" value="1" min="1" max="2" /></div>
      <div class="field"><label>今日上限</label><input class="input" id="cr-limit" type="number" value="2" min="1" max="5" readonly /></div>
    </div>
    <div class="card" style="border-color:rgba(251,191,36,.3)">
      <div class="card-body" style="padding:11px 13px;font-size:10.5px;color:var(--tx-2);line-height:1.7">
        实测：单号一天建 5–6 个就会触发静默限制。这里默认 2 个，
        服务端拒绝时立即停手不重试。创建前会自动切回个人身份。
      </div>
    </div>`;
  const m = modal({
    title: '创建公共主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), { className: 'btn primary', textContent: '开始创建', id: 'cr-run' }),
    ],
  });
  m.el.querySelector('#cr-run').onclick = async () => {
    const name = (body.querySelector('#cr-name').value || '').trim();
    if (!name) return toast('请输入名称', '', 'err');
    const btn = m.el.querySelector('#cr-run');
    btn.disabled = true; btn.textContent = '提交中…';
    try {
      const r = await api.createPages({
        name, category: body.querySelector('#cr-cat').value,
        bio: body.querySelector('#cr-bio').value,
        count: parseInt(body.querySelector('#cr-count').value, 10) || 1,
        dailyLimit: 2,
      });
      toast('已入队', `任务 ${r.jobId}`, 'ok');
      m.close();
    } catch (e) {
      toast('创建失败', e.message, 'err', 5000);
    } finally {
      btn.disabled = false; btn.textContent = '开始创建';
    }
  };
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
