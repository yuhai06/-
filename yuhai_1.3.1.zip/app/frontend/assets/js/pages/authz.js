/* 主页与授权（合并页）
   一个页面搞定：主页台账 + 多号授权矩阵 + 建主页 + 推广链接 + 标题池
   主页是发布通道，号是操作主体，两者绑在一起看才清楚。 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store, raiseGuard } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let tab = 'pages';    // pages | matrix | accounts | links | titles
let mxData = null;
let viewMode = 'grid';
let filter = { q: '', health: 'all', acc: 'all' };

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '主页与授权',
      desc: '主页台账 · 多号授权矩阵 · 建主页 · 链接池 · 标题池（一个页面全搞定）',
      actions: [
        `<button class="btn sm primary" data-act="create"><span data-icon="plus"></span>创建主页</button>`,
        `<button class="btn sm" data-act="extract"><span data-icon="refresh"></span>提取主页</button>`,
        `<button class="btn sm ghost" data-act="fromenv"><span data-icon="layers"></span>从环境建号</button>`,
      ],
    })}
    <div id="az-body"></div>
  `;
  $$('[data-act="create"]', root).forEach((b) => (b.onclick = () => openCreate(root)));
  $$('[data-act="extract"]', root).forEach((b) => (b.onclick = () => openExtract(root)));
  $$('[data-act="fromenv"]', root).forEach((b) => (b.onclick = () => doFromEnvs(b, root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    await store.loadCore();
    store.accountsData = await api.accounts();
    mxData = await api.accountsMatrix();
    store.linksData = (await api.links()).items || [];
    store.titlesData = (await api.titles()).items || [];
  } catch (e) {
    toast('加载失败', e.message, 'err');
  }
  paint(root);
}

function paint(root) {
  const body = $('#az-body', root);
  if (!body) return;
  const acc = store.accountsData || { items: [], publishers: [], backups: [] };
  const mx = mxData || { accounts: [], rows: [] };
  const links = store.linksData || [];
  const titles = store.titlesData || [];
  const pages = store.pages || [];
  const rows = mx.rows || [];

  const pending = rows.filter((r) =>
    r.grants.some((g) => g.role === 'backup' && !g.present)).length;
  const noAsset = pages.filter((p) => !p.assetId).length;

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '主页总数', value: pages.length, unit: '个', iconName: 'flag' })}
      ${statCard({ label: '发布号', value: (acc.publishers || []).length, unit: '个', iconName: 'key' })}
      ${statCard({ label: '备份号', value: (acc.backups || []).length, unit: '个', iconName: 'shield',
                   foot: pending ? `${pending} 个主页未覆盖` : '全部覆盖' })}
      ${statCard({ label: '缺 asset_id', value: noAsset, unit: '个', iconName: 'warn',
                   foot: noAsset ? '无法发布与采集' : '全部齐备' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="tabs" style="border:none;padding:0;margin:0">
          <div class="tab ${tab === 'pages' ? 'active' : ''}" data-tab="pages">
            主页台账 <span class="cnt">${pages.length}</span>
          </div>
          <div class="tab ${tab === 'matrix' ? 'active' : ''}" data-tab="matrix">
            授权矩阵 <span class="cnt">${rows.length}</span>
          </div>
          <div class="tab ${tab === 'accounts' ? 'active' : ''}" data-tab="accounts">
            号管理 <span class="cnt">${(acc.items || []).length}</span>
          </div>
          <div class="tab ${tab === 'links' ? 'active' : ''}" data-tab="links">
            推广链接 <span class="cnt">${links.length}</span>
          </div>
          <div class="tab ${tab === 'titles' ? 'active' : ''}" data-tab="titles">
            标题池 <span class="cnt">${titles.length}</span>
          </div>
        </div>
      </div>
      <div class="card-body tight" id="az-inner"></div>
    </div>
  `;

  $$('[data-tab]', root).forEach((t) => {
    t.onclick = () => { tab = t.dataset.tab; paint(root); };
  });

  const inner = $('#az-inner', root);
  if (tab === 'matrix') return paintMatrix(inner, root, mx, rows);
  if (tab === 'accounts') return paintAccounts(inner, root, acc);
  if (tab === 'links') return paintLinks(inner, root, links);
  if (tab === 'titles') return paintTitles(inner, root, titles);
  paintPages(inner, root, pages, acc, mx);
}

/* ---------------- 主页台账 ---------------- */
function paintPages(inner, root, pages, acc, mx) {
  const envToAcc = {};
  (acc.items || []).forEach((a) => { if (a.envCode) envToAcc[String(a.envCode)] = a; });

  let list = pages.slice();
  if (filter.q) {
    const k = filter.q.toLowerCase();
    list = list.filter((p) => (p.name || '').toLowerCase().includes(k)
      || (p.profileId || '').includes(k) || (p.assetId || '').includes(k));
  }
  if (filter.health !== 'all') list = list.filter((p) => p.health === filter.health);
  if (filter.acc !== 'all') {
    list = list.filter((p) => {
      const a = envToAcc[String(p.envCode || '')];
      return filter.acc === '__none__' ? !a : (a && a.id === filter.acc);
    });
  }

  inner.innerHTML = `
    <div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap;padding:9px 14px 0">
      <input class="input" id="pf-q" placeholder="搜主页名 / page_id / asset_id" value="${filter.q}"
             style="width:200px;padding:4px 8px;font-size:11.5px" />
      <select class="select" id="pf-acc" style="width:160px;padding:4px 8px;font-size:11.5px">
        <option value="all" ${filter.acc === 'all' ? 'selected' : ''}>全部号</option>
        ${(acc.items || []).map((a) =>
          `<option value="${a.id}" ${filter.acc === a.id ? 'selected' : ''}>${esc(a.label)}</option>`).join('')}
        <option value="__none__" ${filter.acc === '__none__' ? 'selected' : ''}>未归属号</option>
      </select>
      <select class="select" id="pf-health" style="width:120px;padding:4px 8px;font-size:11.5px">
        <option value="all" ${filter.health === 'all' ? 'selected' : ''}>全部状态</option>
        <option value="ok" ${filter.health === 'ok' ? 'selected' : ''}>正常</option>
        <option value="restricted" ${filter.health === 'restricted' ? 'selected' : ''}>受限</option>
      </select>
      <div class="seg" data-seg="view">
        <button class="${viewMode === 'grid' ? 'on' : ''}" data-v="grid">卡片</button>
        <button class="${viewMode === 'table' ? 'on' : ''}" data-v="table">表格</button>
      </div>
      <span style="margin-left:auto;font-size:10.5px;color:var(--tx-3)">${list.length} / ${pages.length}</span>
    </div>
    <div id="pg-list" style="padding:12px 14px">
      ${viewMode === 'grid' ? gridHtml(list, envToAcc) : tableHtml(list, envToAcc)}
    </div>`;

  const q = $('#pf-q', inner);
  if (q) q.oninput = (e) => { filter.q = e.target.value; paint(root); };
  const sa = $('#pf-acc', inner);
  if (sa) sa.onchange = (e) => { filter.acc = e.target.value; paint(root); };
  const sh = $('#pf-health', inner);
  if (sh) sh.onchange = (e) => { filter.health = e.target.value; paint(root); };
  $$('[data-seg="view"] button', inner).forEach((b) => {
    b.onclick = () => { viewMode = b.dataset.v; paint(root); };
  });
  $$('[data-page]', inner).forEach((el) => {
    el.onclick = (e) => {
      if (e.target.closest('[data-detail]') || e.target.closest('[data-skip]')) return;
      openDetail(el.dataset.page);
    };
  });
  $$('[data-detail]', inner).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openDetail(b.dataset.detail); };
  });
  $$('[data-skip]', inner).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const pid = b.dataset.skip;
      const p = (store.pages || []).find((x) => x.profileId === pid);
      const next = !(p && p.skipPublish);
      try {
        await api.setSkipPublish(pid, next, next ? '我手动发这个主页' : '');
        toast(next ? '已设为不自动发布' : '已恢复自动发布',
          next ? '排期会自动跳过这个主页' : '', next ? 'warn' : 'ok');
        await load(root);
      } catch (err) { toast('失败', err.message, 'err'); }
    };
  });
}

function healthBadge(h) {
  if (h === 'ok') return badge('正常', 'ok', true);
  if (h === 'restricted') return badge('受限', 'danger', true);
  if (h === 'pending') return badge('待授权', 'warn', true);
  return badge('未知', 'mute');
}

function gridHtml(list, envToAcc) {
  if (!list.length) return emptyState('没有匹配的主页', '换个筛选条件');
  return `<div class="grid g3">${list.map((p) => {
    const a = envToAcc[String(p.envCode || '')];
    return `
      <div class="page-card" data-page="${p.profileId}">
        <div class="pc-top">
          <div class="pc-avatar">${esc(p.name)}</div>
          <div class="pc-name">
            <strong>${esc(p.name)}</strong>
            <span>${p.assetId || '⚠ 缺 asset_id'}</span>
          </div>
          ${healthBadge(p.health)}
        </div>
        <div style="display:flex;gap:5px;align-items:center;margin-bottom:6px">
          ${a ? `<span class="badge ${a.role === 'publisher' ? 'info' : 'purple'}" style="font-size:9px">${esc(a.label)}</span>`
            : '<span class="badge warn" style="font-size:9px">未归属号</span>'}
          <span style="font-family:var(--mono);font-size:9.5px;color:var(--tx-3)">${p.profileId}</span>
        </div>
        <div class="pc-metrics">
          <div class="pc-m"><b>${nfmt(p.views30d)}</b><span>30天播放</span></div>
          <div class="pc-m"><b>${nfmt(p.followers)}</b><span>粉丝</span></div>
          <div class="pc-m"><b>${p.published || 0}</b><span>已发</span></div>
        </div>
        <div class="pc-foot">
          <span style="display:flex;gap:4px;flex-wrap:wrap">
            ${p.authz && p.authz.publisher && p.authz.publisher.present
              ? badge('发布号', 'info') : badge('发布号缺失', 'danger')}
            ${p.authz && p.authz.backup && p.authz.backup.present
              ? badge('备份号', 'purple') : badge('待授权', 'warn')}
            ${p.skipPublish ? badge('不自动发', 'warn') : ''}
          </span>
          <button class="btn xs ghost" data-skip="${p.profileId}"
                  style="font-size:9.5px;padding:2px 6px">
            ${p.skipPublish ? '恢复' : '跳过'}
          </button>
        </div>
      </div>`;
  }).join('')}</div>`;
}

function tableHtml(list, envToAcc) {
  if (!list.length) return emptyState('没有匹配的主页', '换个筛选条件');
  return `<div class="tbl-wrap">
    <table class="tbl"><thead><tr>
      <th>主页</th><th>所属号</th><th>page_id</th><th>asset_id</th>
      <th class="num">30天播放</th><th class="num">粉丝</th><th class="num">已发</th>
      <th>授权</th><th>状态</th><th>自动发布</th><th></th>
    </tr></thead><tbody>
      ${list.map((p) => {
        const a = envToAcc[String(p.envCode || '')];
        return `
          <tr data-page="${p.profileId}">
            <td><b>${esc(p.name)}</b></td>
            <td>${a ? `<span class="badge ${a.role === 'publisher' ? 'info' : 'purple'}" style="font-size:9px">${esc(a.label)}</span>`
              : '<span class="badge warn" style="font-size:9px">未归属</span>'}</td>
            <td class="mono" style="font-size:10px">${p.profileId}</td>
            <td class="mono" style="font-size:10px">${p.assetId || '<span style="color:var(--danger)">缺失</span>'}</td>
            <td class="num">${nfmt(p.views30d)}</td>
            <td class="num">${nfmt(p.followers)}</td>
            <td class="num">${p.published || 0}</td>
            <td>
              <div style="display:flex;gap:3px">
                ${p.authz && p.authz.publisher && p.authz.publisher.present ? badge('发', 'info') : badge('—', 'mute')}
                ${p.authz && p.authz.backup && p.authz.backup.present ? badge('备', 'purple') : badge('—', 'mute')}
              </div>
            </td>
            <td>${healthBadge(p.health)}</td>
            <td>
              <button class="btn xs ${p.skipPublish ? 'danger' : 'ghost'}"
                      data-skip="${p.profileId}" style="font-size:9.5px;padding:2px 7px">
                ${p.skipPublish ? '不自动发' : '自动发'}
              </button>
            </td>
            <td class="row-actions"><button class="btn xs ghost" data-detail="${p.profileId}">展开</button></td>
          </tr>`;
      }).join('')}
    </tbody></table>
  </div>`;
}

/* ---------------- 主页详情 ---------------- */
async function openDetail(pid) {
  let d;
  try { d = await api.pageDetail(pid); } catch (e) { return toast('失败', e.message, 'err'); }
  const acc = store.accountsData || { items: [] };
  const envToAcc = {};
  (acc.items || []).forEach((a) => { if (a.envCode) envToAcc[String(a.envCode)] = a; });
  const owner = envToAcc[String(d.envCode || '')];

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="grid g2" style="margin-bottom:14px">
      <div>
        <div class="kv"><span class="k">page_id</span><span class="v">${d.profileId}</span></div>
        <div class="kv"><span class="k">asset_id</span><span class="v" style="color:${d.assetId ? '' : 'var(--danger)'}">${d.assetId || '缺失'}</span></div>
        <div class="kv"><span class="k">所属号</span><span class="v">${owner ? esc(owner.label) : '未归属'}</span></div>
      </div>
      <div>
        <div class="kv"><span class="k">30天播放</span><span class="v">${nfmt(d.views30d)}</span></div>
        <div class="kv"><span class="k">粉丝</span><span class="v">${nfmt(d.followers)}</span></div>
        <div class="kv"><span class="k">已发布</span><span class="v">${d.published || 0}</span></div>
      </div>
    </div>
    <div class="section-title">授权</div>
    <div class="card" style="margin-bottom:14px"><div class="card-body tight">
      ${(d.roles || []).length ? (d.roles || []).map((r) => `
        <div class="litem">
          <span class="dot ${r.state === 'active' ? 'ok' : 'warn'}"></span>
          <div class="litem-main">
            <div class="litem-title">c_user ${r.c_user} ${badge(r.state, r.state === 'active' ? 'ok' : 'warn')}</div>
            <div class="litem-sub">${r.role} · ${r.granted_at || '—'}</div>
          </div>
        </div>`).join('')
        : '<div class="litem" style="justify-content:center;color:var(--tx-3)">无授权记录</div>'}
    </div></div>
    <div class="section-title">操作</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn sm" data-x="verify">核对权限</button>
      <button class="btn sm ghost" data-x="sync">同步全部信息</button>
    </div>`;
  const m = modal({
    title: `${d.name} 详情`, width: 'wide', body,
    footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() })],
  });
  body.querySelectorAll('[data-x]').forEach((b) => {
    b.onclick = async () => {
      if (b.dataset.x === 'verify') {
        try {
          const r = await api.verifyAuthz(d.profileId);
          toast('核对完成', `发布号 ${r.publisherPresent ? '在' : '不在'} · 备份号 ${r.backupPresent ? '在' : '不在'}`, 'ok');
          await load(document.getElementById('view'));
        } catch (e) { toast('核对失败', e.message, 'err'); }
      } else {
        try {
          const r = await api.syncPageInfo(d.profileId);
          toast('同步完成', JSON.stringify(r).slice(0, 100), 'ok', 6000);
          await load(document.getElementById('view'));
        } catch (e) { toast('同步失败', e.message, 'err'); }
      }
    };
  });
}

/* ---------------- 提取主页（一次同步全部） ---------------- */
function openExtract(root) {
  const running = (store.envs || []).filter((e) => e.status === 'running');
  const acc = store.accountsData || { items: [] };
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:11px;color:var(--tx-2);line-height:1.7">
        <b>一次提取，全部同步</b>：主页清单 + asset_id + 授权关系 + 粉丝数 + 30 天播放
        + 主页健康状态，一次性拿全。不用再分几次跑。
      </div>
    </div>
    <div class="field">
      <label>用哪个环境提取</label>
      <select class="select" id="ex-env">
        ${running.map((e) => `<option value="${e.containerCode}">${esc(e.name)} · PID ${e.pid || '—'} · CDP ${e.cdpPort || '—'}</option>`).join('')
          || '<option value="">没有运行中的环境</option>'}
      </select>
    </div>
    <div class="field">
      <label>归属到哪个号（可选）</label>
      <select class="select" id="ex-acc">
        <option value="">— 按环境自动判断 —</option>
        ${(acc.items || []).map((a) =>
          `<option value="${a.id}">${esc(a.label)} · ${a.role === 'publisher' ? '发布号' : '备份号'}</option>`).join('')}
      </select>
      <div class="hint">提取到的主页会绑定到这个号（不选则按环境的号）</div>
    </div>
    <div style="display:flex;flex-direction:column;gap:8px;margin:10px 0">
      <label class="switch"><input type="checkbox" id="ex-full" checked />
        <span class="track"></span><span class="lbl">同步全部信息（asset / 授权 / 粉丝 / 播放 / 健康）</span></label>
    </div>
    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.7">
      提取走拟人化操作，命中风控立即中止。已有的主页只更新不重复建。
    </div></div>`;
  const m = modal({
    title: '提取主页（全量同步）', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始提取',
        onclick: async () => {
          const envCode = body.querySelector('#ex-env').value;
          if (!envCode) return toast('没有可用环境', '先启动指纹浏览器', 'err');
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '提取中…';
          try {
            const env = (store.envs || []).find((e) => e.containerCode === envCode);
            const isPort = env && env.cdpPort;
            const r = await api.extractPages(isPort ? 0 : (env?.pid || 0), isPort ? env.cdpPort : 0);
            if (!r.ok) {
              toast('提取失败', r.error || '', 'err', 6000);
            } else {
              toast('提取完成', `c_user ${r.cUser} · ${r.count} 个主页`, 'ok', 6000);
              // 绑定到指定号
              const accId = body.querySelector('#ex-acc').value;
              if (accId && r.pages) {
                const a = (acc.items || []).find((x) => x.id === accId);
                if (a && a.envCode) {
                  try {
                    await api.bindPagesToAccount(a.envCode, r.pages.map((p) => p.page_id));
                    toast('已绑定', `${r.pages.length} 个主页 → ${a.label}`, 'ok');
                  } catch (e2) { console.warn(e2.message); }
                }
              }
              // 全量同步
              if (body.querySelector('#ex-full').checked) {
                btn.textContent = '同步信息…';
                try {
                  const s = await api.syncAllPages({ envCode });
                  toast('全量同步完成', JSON.stringify(s).slice(0, 120), 'ok', 7000);
                } catch (e2) {
                  toast('同步部分失败', e2.message, 'warn', 6000);
                }
              }
              m.close();
              await load(root);
            }
          } catch (e) {
            toast('提取失败', e.message, 'err', 7000);
          } finally { btn.disabled = false; btn.textContent = '开始提取'; }
        },
      }),
    ],
  });
}

/* ---------------- 授权矩阵 ---------------- */
function paintMatrix(inner, root, mx, rows) {
  const accs = mx.accounts || [];
  if (!rows.length || !accs.length) {
    inner.innerHTML = emptyState('还没有数据',
      rows.length ? '去「号管理」建号' : '先「提取主页」');
    return;
  }
  inner.innerHTML = `
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>主页</th><th>asset_id</th>
          ${accs.map((a) => `<th style="text-align:center">
            ${esc(a.label)}
            <div style="font-size:9px;color:var(--tx-3);font-family:var(--mono)">${a.cUser || '无 ID'}</div>
          </th>`).join('')}
          <th></th>
        </tr></thead>
        <tbody>
          ${rows.map((r) => `
            <tr>
              <td><b style="font-family:var(--mono);color:var(--ac)">${esc(r.pageName)}</b></td>
              <td class="mono" style="font-size:10px">${r.assetId || '<span style="color:var(--danger)">缺失</span>'}</td>
              ${accs.map((a) => {
                const g = r.grants.find((x) => x.accountId === a.id) || {};
                return `<td style="text-align:center">
                  ${g.present
                    ? badge(g.state === 'active' ? '✓' : g.state, 'ok')
                    : `<button class="btn xs ghost" data-grant="${r.pageId}|${a.id}">授</button>`}
                </td>`;
              }).join('')}
              <td class="row-actions">
                <button class="btn xs ghost" data-verify="${r.pageId}">核对</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
      点「授」登记授权关系。同一主页可授给多个号。身份只认 profile 数字 ID。
    </div>`;

  $$('[data-grant]', inner).forEach((b) => {
    b.onclick = async () => {
      const [pid, aid] = b.dataset.grant.split('|');
      try {
        await api.mapRole({ pageId: pid, accountId: aid, state: 'active' });
        toast('已登记', '', 'ok');
        await load(root);
      } catch (e) { toast('失败', e.message, 'err'); }
    };
  });
  $$('[data-verify]', inner).forEach((b) => {
    b.onclick = async () => {
      b.disabled = true; b.textContent = '…';
      try {
        const r = await api.verifyAuthz(b.dataset.verify);
        toast('核对完成',
          `发布号 ${r.publisherPresent ? '在' : '不在'} · 备份号 ${r.backupPresent ? '在' : '不在'}`,
          r.backupPresent ? 'ok' : 'warn');
        await load(root);
      } catch (e) { toast('失败', e.message, 'err'); }
      finally { b.disabled = false; b.textContent = '核对'; }
    };
  });
}

/* ---------------- 号管理 ---------------- */
function paintAccounts(inner, root, acc) {
  const items = acc.items || [];
  inner.innerHTML = `
    <div style="display:flex;justify-content:flex-end;padding:9px 14px 0">
      <button class="btn xs primary" data-act="addacc"><span data-icon="plus"></span>新增号</button>
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>显示名</th><th>角色</th><th>c_user</th>
          <th>建页额度</th><th>今日已建</th><th>环境</th><th class="num">主页</th><th>状态</th><th></th>
        </tr></thead>
        <tbody>
          ${items.length ? items.map((a) => {
            const lvl = a.quotaLevel || 'new';
            const lvCls = lvl === 'new' ? 'ok' : lvl === 'limited' ? 'warn' : 'danger';
            return `
            <tr>
              <td><b>${esc(a.label)}</b></td>
              <td>${a.role === 'publisher' ? badge('发布号', 'info') : badge('备份号', 'purple')}</td>
              <td class="mono" style="font-size:10.5px;color:${a.cUser ? '' : 'var(--danger)'}">${a.cUser || '缺失'}</td>
              <td><button class="btn xs ${lvCls === 'ok' ? 'ok' : lvCls === 'warn' ? '' : 'danger'}"
                          data-quota="${a.id}">${a.quotaLabel || lvl} · ${a.quotaLimit}</button></td>
              <td class="num" style="font-size:11px">${a.quotaUsed || 0} / 剩 ${a.quotaRemaining || 0}</td>
              <td class="mono" style="font-size:10px">${esc(a.envCode || '—')}</td>
              <td class="num">${a.pages}</td>
              <td>${a.enabled ? badge('启用', 'ok') : badge('停用', 'mute')}</td>
              <td class="row-actions">
                <button class="btn xs ghost" data-editacc="${a.id}">编辑</button>
                <button class="btn xs danger" data-delacc="${a.id}">停用</button>
              </td>
            </tr>`;
          }).join('')
            : '<tr><td colspan="9" style="text-align:center;color:var(--tx-3);padding:24px">还没有号，点右上「从环境建号」</td></tr>'}
        </tbody>
      </table>
    </div>
    <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.75">
      建页额度按账号状态走：新号 6–7 个 · 被限过后 1–2 个 · 限制严重 0 个。
      风控命中会自动降级。多号架构：每个号 = FB 个人号 + 环境 + 名下一批主页。
    </div>`;

  $$('[data-act="addacc"]', inner).forEach((b) => (b.onclick = () => openAccount(root)));
  $$('[data-quota]', inner).forEach((b) => {
    b.onclick = () => openQuota(root, items.find((x) => x.id === b.dataset.quota));
  });
  $$('[data-editacc]', inner).forEach((b) => {
    b.onclick = () => openAccount(root, items.find((x) => x.id === b.dataset.editacc));
  });
  $$('[data-delacc]', inner).forEach((b) => {
    b.onclick = async () => {
      if (!confirm('停用这个号？')) return;
      try {
        await api.delAccount(b.dataset.delacc);
        toast('已停用', '', 'warn');
        await load(root);
      } catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

/* ---------------- 链接池 ---------------- */
function paintLinks(inner, root, links) {
  inner.innerHTML = `
    <div style="display:flex;justify-content:flex-end;padding:9px 14px 0">
      <button class="btn xs primary" data-act="addlink"><span data-icon="plus"></span>新增链接</button>
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>标签</th><th>链接（原样使用）</th><th>绑定主页</th>
          <th class="num">权重</th><th class="num">已用</th><th>状态</th><th></th>
        </tr></thead>
        <tbody>
          ${links.length ? links.map((l) => `
            <tr>
              <td><b>${esc(l.label)}</b></td>
              <td class="mono" style="font-size:10px;max-width:340px;overflow:hidden;
                         text-overflow:ellipsis;white-space:nowrap">${esc(l.url)}</td>
              <td style="font-size:11px">${l.page_id ? esc(l.page_id) : badge('全局', 'mute')}</td>
              <td class="num">${l.weight}</td>
              <td class="num">${l.used_count}</td>
              <td>${l.enabled ? badge('启用', 'ok') : badge('停用', 'mute')}</td>
              <td class="row-actions"><button class="btn xs danger" data-dellink="${l.id}">删</button></td>
            </tr>`).join('')
            : '<tr><td colspan="7" style="text-align:center;color:var(--tx-3);padding:24px">还没有链接</td></tr>'}
        </tbody>
      </table>
    </div>
    <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
      发布时每个主页随机取一条（按权重，避开最近用过的）。<b>链接原样插入不改写</b>。
    </div>`;

  $$('[data-act="addlink"]', inner).forEach((b) => (b.onclick = () => openLink(root)));
  $$('[data-dellink]', inner).forEach((b) => {
    b.onclick = async () => {
      try { await api.delLink(b.dataset.dellink); toast('已删除', '', 'warn'); await load(root); }
      catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

/* ---------------- 标题池 ---------------- */
function paintTitles(inner, root, titles) {
  const pages = store.pages || [];
  inner.innerHTML = `
    <div style="display:flex;justify-content:flex-end;padding:9px 14px 0">
      <button class="btn xs primary" data-act="gentitles"><span data-icon="bolt"></span>AI 生成标题</button>
    </div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>主页</th><th>标题</th><th>来源</th><th></th></tr></thead>
        <tbody>
          ${titles.length ? titles.slice(0, 100).map((t) => `
            <tr>
              <td class="mono" style="font-size:10px">${esc(t.page_id)}</td>
              <td style="font-size:11.5px;max-width:520px">${esc(t.title)}</td>
              <td>${badge(t.source || 'generated', 'mute')}</td>
              <td class="row-actions"><button class="btn xs danger" data-deltitle="${t.id}">删</button></td>
            </tr>`).join('')
            : '<tr><td colspan="4" style="text-align:center;color:var(--tx-3);padding:24px">还没有标题，点「AI 生成标题」</td></tr>'}
        </tbody>
      </table>
    </div>
    <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
      给参考标题 → 大模型生成 N 个不同角度版本 → 发布时每主页随机取一条。
    </div>`;

  $$('[data-act="gentitles"]', inner).forEach((b) => (b.onclick = () => openGenTitles(root, pages)));
  $$('[data-deltitle]', inner).forEach((b) => {
    b.onclick = async () => {
      try { await api.delTitle(b.dataset.deltitle); toast('已删除', '', 'warn'); await load(root); }
      catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

/* ---------------- 弹窗们 ---------------- */
function openLink(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field"><label>标签</label><input class="input" id="lk-label" placeholder="美国主链" /></div>
    <div class="field"><label>链接（原样使用）</label>
      <input class="input" id="lk-url" placeholder="https://pinedrama.onelink.me/..." style="font-family:var(--mono);font-size:11px" /></div>
    <div class="row-2">
      <div class="field"><label>绑定主页（留空=全局）</label>
        <select class="select" id="lk-page">
          <option value="">全局可用</option>
          ${(store.pages || []).map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
        </select>
      </div>
      <div class="field"><label>权重</label><input class="input" id="lk-weight" type="number" value="1" min="1" max="10" /></div>
    </div>`;
  const m = modal({
    title: '新增推广链接', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const url = (body.querySelector('#lk-url').value || '').trim();
          if (!url) return toast('链接不能为空', '', 'err');
          try {
            await api.addLink({
              label: body.querySelector('#lk-label').value || url.slice(0, 30),
              url, pageId: body.querySelector('#lk-page').value,
              weight: parseInt(body.querySelector('#lk-weight').value, 10) || 1,
            });
            toast('已添加', '', 'ok'); m.close(); await load(root);
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

function openGenTitles(root, pages) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field"><label>为主页生成</label>
      <select class="select" id="gt-page">
        ${pages.map((p) => `<option value="${p.profileId}">${esc(p.name)}</option>`).join('')}
      </select>
    </div>
    <div class="field"><label>参考标题</label>
      <textarea class="textarea" id="gt-ref" style="min-height:64px">${esc('When she walked into the banquet, everyone laughed at her cheap dress — until the CEO stood up and called her mother.')}</textarea>
    </div>
    <div class="field"><label>生成数量</label>
      <input class="input" id="gt-n" type="number" value="5" min="1" max="20" /></div>
    <div id="gt-result" style="margin-top:10px"></div>`;
  const m = modal({
    title: 'AI 生成标题', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始生成',
        onclick: async () => {
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '生成中…';
          try {
            const r = await api.genTitles({
              pageId: body.querySelector('#gt-page').value,
              reference: body.querySelector('#gt-ref').value,
              n: parseInt(body.querySelector('#gt-n').value, 10) || 5, save: true,
            });
            body.querySelector('#gt-result').innerHTML = `
              <div class="section-title">生成结果 <span class="chip">${r.source}</span></div>
              <div class="card"><div class="card-body tight">
                ${(r.titles || []).map((t, i) => `
                  <div class="litem">
                    <span style="width:18px;font-family:var(--mono);font-size:10px;color:var(--tx-3)">${i + 1}</span>
                    <div class="litem-main"><div class="litem-title" style="font-size:11.5px">${esc(t)}</div></div>
                  </div>`).join('')}
              </div></div>`;
            toast('生成完成', `${(r.titles || []).length} 条`, 'ok');
            await load(root);
          } catch (e) { toast('失败', e.message, 'err'); }
          finally { btn.disabled = false; btn.textContent = '开始生成'; }
        },
      }),
    ],
  });
}

function openAccount(root, a) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field"><label>显示名</label>
        <input class="input" id="ac-label" value="${esc(a?.label || '')}" placeholder="发布号03" /></div>
      <div class="field"><label>角色</label>
        <select class="select" id="ac-role" ${a ? 'disabled' : ''}>
          <option value="publisher" ${a?.role === 'publisher' ? 'selected' : ''}>发布号</option>
          <option value="backup" ${a?.role === 'backup' ? 'selected' : ''}>备份号</option>
        </select>
      </div>
    </div>
    <div class="field"><label>c_user（profile 数字 ID，授权必需）</label>
      <input class="input" id="ac-cuser" value="${esc(a?.cUser || '')}" placeholder="61595095770895" style="font-family:var(--mono)" />
      <div class="hint">必须纯数字。姓名/邮箱不能用于授权。</div>
    </div>
    <div class="row-2">
      <div class="field"><label>邮箱</label>
        <input class="input" id="ac-email" value="${esc(a?.email || '')}" /></div>
      <div class="field"><label>环境</label>
        <select class="select" id="ac-env">
          <option value="">未绑定</option>
          ${(store.envs || []).map((e) => `<option value="${e.containerCode}" ${a?.envCode === e.containerCode ? 'selected' : ''}>${esc(e.name)}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="field"><label>分组</label>
      <input class="input" id="ac-group" value="${esc(a?.groupName || '')}" placeholder="组A" /></div>`;
  const m = modal({
    title: a ? '编辑号' : '新增号', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const payload = {
            label: body.querySelector('#ac-label').value.trim(),
            role: body.querySelector('#ac-role').value,
            cUser: body.querySelector('#ac-cuser').value.trim(),
            email: body.querySelector('#ac-email').value.trim(),
            envCode: body.querySelector('#ac-env').value,
            groupName: body.querySelector('#ac-group').value.trim(),
          };
          if (!payload.label) return toast('显示名不能为空', '', 'err');
          try {
            if (a) await api.patchAccount(a.id, payload);
            else await api.addAccount(payload);
            toast('已保存', '', 'ok'); m.close(); await load(root);
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

function openQuota(root, a) {
  if (!a) return;
  const lv = a.quotaLevel || 'new';
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px"><div class="card-body" style="padding:11px 13px">
      <div class="kv"><span class="k">号</span><span class="v">${esc(a.label)}</span></div>
      <div class="kv"><span class="k">今日已建</span><span class="v">${a.quotaUsed || 0} 个</span></div>
      <div class="kv"><span class="k">当前额度</span><span class="v">${a.quotaLabel || lv} · ${a.quotaLimit} 个</span></div>
    </div></div>
    <div class="field">
      <label>额度档位</label>
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:6px">
        ${[['new', '新号', '可建 6–7 个'], ['limited', '受限', '只能建 1–2 个'], ['blocked', '禁建', '暂停建主页']]
          .map(([v, t, d]) => `
          <label style="display:flex;gap:9px;align-items:flex-start;cursor:pointer;
                        padding:9px 11px;border-radius:var(--r-sm);background:var(--bg-0);
                        border:1.5px solid ${lv === v ? 'var(--ac)' : 'transparent'}">
            <input type="radio" name="qlevel" value="${v}" ${lv === v ? 'checked' : ''}
                   style="margin-top:2px;accent-color:var(--ac)" />
            <span><b style="font-size:12px">${t}</b>
              <span style="display:block;font-size:10.5px;color:var(--tx-3);margin-top:2px">${d}</span></span>
          </label>`).join('')}
      </div>
    </div>
    <div class="field"><label>变更原因</label><input class="input" id="q-note" /></div>`;
  const m = modal({
    title: `建页额度 · ${a.label}`, body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const sel = body.querySelector('input[name="qlevel"]:checked');
          if (!sel) return toast('请选档位', '', 'err');
          try {
            await api.setQuota(a.id, sel.value, body.querySelector('#q-note').value);
            toast('已保存', sel.value, 'ok'); m.close(); await load(root);
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

/* ---------------- 创建主页 ---------------- */
function openCreate(root) {
  const acc = store.accountsData || { publishers: [] };
  const pubs = (acc.publishers || []).filter((x) => x.enabled && x.cUser);
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:12px;border-color:rgba(79,70,229,.28)">
      <div class="card-body" style="padding:10px 12px;font-size:11px;color:var(--tx-2);line-height:1.7">
        用指定发布号创建主页。创建前自动切回个人身份。额度按号状态决定。
      </div>
    </div>
    <div class="field">
      <label>用哪个号创建</label>
      <select class="select" id="cr-acc">
        ${pubs.length ? pubs.map((a) =>
          `<option value="${a.id}" data-cuser="${a.cUser}" data-limit="${a.quotaLimit}"
                   data-level="${a.quotaLevel}" data-remain="${a.quotaRemaining}">
            ${esc(a.label)} · ${a.quotaLabel || a.quotaLevel} 额度 ${a.quotaLimit} · 剩 ${a.quotaRemaining}
          </option>`).join('')
          : '<option value="">没有可用的发布号（需有 profile ID）</option>'}
      </select>
    </div>
    <div id="cr-quota-bar" style="margin-bottom:12px"></div>
    <div class="row-2">
      <div class="field"><label>主页名称</label><input class="input" id="cr-name" placeholder="Y16" /></div>
      <div class="field"><label>类别</label>
        <select class="select" id="cr-cat">
          <option>家居用品</option><option>电子产品店</option><option>宠物店</option>
          <option>餐饮服务</option><option>健身房/健身中心</option>
          <option>美容、美妆与个人护理</option><option>汽车服务</option>
          <option>本地服务</option><option>零售购物</option>
        </select>
      </div>
    </div>
    <div class="field"><label>简介</label><textarea class="textarea" id="cr-bio"></textarea></div>
    <div class="row-2">
      <div class="field"><label>数量</label><input class="input" id="cr-count" type="number" value="1" min="1" /></div>
      <div class="field"><label>主页间隔（秒）</label><input class="input" id="cr-gap" type="number" value="420" /></div>
    </div>
    <div class="card" style="border-color:rgba(251,191,36,.3)"><div class="card-body" style="padding:10px 12px;font-size:10.5px;color:var(--tx-2);line-height:1.75">
      新号一天能建 6–7 个才开始被限；一旦被限制只能建 1–2 个。服务端拒绝会自动降级该号额度。
    </div></div>`;
  const m = modal({
    title: '创建公共主页', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始创建',
        onclick: async () => {
          const sel = body.querySelector('#cr-acc');
          const opt = sel.selectedOptions[0];
          const name = (body.querySelector('#cr-name').value || '').trim();
          if (!name) return toast('请输入主页名称', '', 'err');
          if (!opt || !opt.dataset.cuser) return toast('该号缺 profile ID', '', 'err');
          const count = parseInt(body.querySelector('#cr-count').value, 10) || 1;
          const remain = parseInt(opt.dataset.remain || '0', 10);
          if (count > remain) return toast('超出额度', `该号今日还能建 ${remain} 个`, 'err', 6000);
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '提交中…';
          try {
            const r = await api.createPages({
              name, category: body.querySelector('#cr-cat').value,
              bio: body.querySelector('#cr-bio').value, count,
              accountId: sel.value,
              gapSec: parseInt(body.querySelector('#cr-gap').value, 10) || 420,
            });
            toast('已入队', `任务 ${r.jobId} · 该号剩 ${r.remaining} 个`, 'ok');
            m.close(); await load(root);
          } catch (e) { toast('创建失败', e.message, 'err', 7000); }
          finally { btn.disabled = false; btn.textContent = '开始创建'; }
        },
      }),
    ],
  });

  const renderBar = () => {
    const opt = body.querySelector('#cr-acc').selectedOptions[0];
    const barEl = body.querySelector('#cr-quota-bar');
    if (!opt || !opt.dataset.level) { barEl.innerHTML = ''; return; }
    const lv = opt.dataset.level;
    const limit = parseInt(opt.dataset.limit || '0', 10);
    const remain = parseInt(opt.dataset.remain || '0', 10);
    const color = lv === 'new' ? 'var(--ok)' : lv === 'limited' ? 'var(--warn)' : 'var(--danger)';
    barEl.innerHTML = `
      <div class="card" style="border-color:${color}33"><div class="card-body" style="padding:10px 13px">
        <div style="display:flex;gap:10px;align-items:center">
          <span style="font-size:11.5px;font-weight:600;color:${color}">
            ${lv === 'new' ? '新号档' : lv === 'limited' ? '受限档' : '禁建档'}</span>
          <span style="font-size:11px;color:var(--tx-2)">
            今日额度 ${limit} · 还能建 <b style="color:${color}">${remain}</b> 个</span>
        </div>
        <div style="margin-top:7px">${bar(limit ? (limit - remain) / limit * 100 : 100,
          lv === 'new' ? 'ok' : lv === 'limited' ? 'warn' : 'danger')}</div>
      </div></div>`;
    const cnt = body.querySelector('#cr-count');
    if (cnt) { cnt.max = Math.max(1, remain); if (+cnt.value > remain) cnt.value = Math.max(1, remain); }
  };
  body.querySelector('#cr-acc').onchange = renderBar;
  renderBar();
}

async function doFromEnvs(btn, root) {
  btn.disabled = true;
  try {
    const r = await api.accountsFromEnvs();
    toast('同步完成', `新增 ${r.created} · 更新 ${r.updated}`, 'ok');
    await load(root);
  } catch (e) { toast('失败', e.message, 'err'); }
  finally { btn.disabled = false; }
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
