/* 第三方对接 + 模型 / 技能 / 插件（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import { badge, pageHead, statCard, $, $$, toast, modal, ts, ago, emptyState, nfmt } from '../ui.js';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '第三方对接',
      desc: '外部依赖的连通性、模型来源、技能与插件',
      actions: [
        `<button class="btn sm" data-act="retest"><span data-icon="refresh"></span>全部重测</button>`,
      ],
    })}
    <div id="it-body"></div>
  `;
  $$('[data-act="retest"]', root).forEach((b) => (b.onclick = () => retestAll(b)));
  paint(root);
  load(root);
}

async function load(root) {
  await store.loadIntegrations();
  try {
    store.dsh = await api.dshStatus();
    store.dshPlugins = await api.dshPlugins();
  } catch (e) {
    store.dsh = null;
    store.dshPlugins = null;
  }
  paint(root);
}

function paint(root) {
  const body = $('#it-body', root);
  if (!body) return;
  const integ = store.integrations || [];
  const models = store.models || [];
  const skills = store.skills || [];
  const plugins = store.plugins || [];

  const connected = integ.filter((i) => i.state === 'connected').length;
  const modelCount = models.reduce((a, m) => a + (m.models || []).length, 0);
  const visionCount = models.reduce(
    (a, m) => a + (m.models || []).filter((x) => x.vision).length, 0);

  body.innerHTML = `
    ${store.dsh && store.dsh.modelCount > 0 ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.3)">
      <div class="card-head">
        <div class="card-title">插件模型接入
          <span class="sub">${store.dsh.channelCount} 个渠道 · ${store.dsh.modelCount} 个模型</span>
        </div>
        <span class="chip ok">只含账号接入</span>
      </div>
      <div class="card-body">
        <div class="card" style="margin-bottom:11px;border-color:rgba(251,191,36,.3)">
          <div class="card-body" style="padding:9px 11px;font-size:10.5px;
                      color:var(--tx-2);line-height:1.7">
            已排除：<b>our-free-model</b>（插件匿名免费池）、
            <b>eac / magpie</b>（付费转售）。只保留你自己登录的账号渠道。
          </div>
        </div>

        <div class="field">
          <label>默认模型（按渠道分组）</label>
          <select class="select" id="dsh-model" style="font-size:11px">
            ${(store.dsh.channels || []).map((g) => `
              <optgroup label="${esc(g.label)}（${g.models.length} 个${g.freeCount ? ` · ${g.freeCount} 免费` : ''}）">
                ${g.models.map((m) =>
                  `<option value="${esc(m.id)}" ${store.dsh.selected === m.id ? 'selected' : ''}>
                    ${esc(m.name)}${m.free ? ' · 免费' : ''}${m.vision ? ' 👁' : ''}
                  </option>`).join('')}
              </optgroup>`).join('')}
          </select>
          <div class="hint">端点：${esc(store.dsh.endpoint?.base || '')} · 选完点保存</div>
        </div>
        <div style="display:flex;gap:7px;flex-wrap:wrap">
          <button class="btn sm primary" id="dsh-save">保存默认模型</button>
          <button class="btn sm ghost" id="dsh-test">测试连通</button>
        </div>
        <div id="dsh-out" style="margin-top:9px"></div>

        <div class="section-title" style="margin-top:14px">插件接入</div>
        <div class="tbl-wrap">
          <table class="tbl" style="font-size:10.5px">
            <thead><tr>
              <th>插件</th><th>版本</th><th>可接入渠道</th><th>状态</th>
            </tr></thead>
            <tbody>
              ${(store.dshPlugins?.items || []).map((p) => `
                <tr>
                  <td class="mono" style="font-size:10px">${esc(p.name)}</td>
                  <td style="font-size:10px">v${esc(p.version || '?')}</td>
                  <td>
                    ${(p.channels || []).length
                      ? (p.channels || []).map((c) =>
                          `<span class="badge info" style="font-size:9px;margin-right:3px">
                            ${esc(c.label)} ${c.models}${c.freeCount ? ` /${c.freeCount}免费` : ''}
                          </span>`).join('')
                      : (p.excludedChannels || []).length
                        ? (p.excludedChannels || []).map((c) =>
                            `<span class="badge mute" style="font-size:9px;margin-right:3px">
                              ${esc(c.label)}（已排除）</span>`).join('')
                        : '<span style="font-size:10px;color:var(--tx-3)">不经网关</span>'}
                  </td>
                  <td>${p.usable ? badge('可接入', 'ok') : badge('不接入', 'mute')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>

        <div class="section-title" style="margin-top:14px">渠道明细</div>
        <div class="tbl-wrap">
          <table class="tbl" style="font-size:10.5px">
            <thead><tr>
              <th>渠道</th><th>名称</th><th class="num">模型</th>
              <th class="num">免费</th><th>类型</th><th></th>
            </tr></thead>
            <tbody>
              ${(store.dsh.channels || []).map((g) => `
                <tr>
                  <td class="mono">${esc(g.channel)}</td>
                  <td><b>${esc(g.label)}</b></td>
                  <td class="num">${g.models.length}</td>
                  <td class="num" style="color:${g.freeCount ? 'var(--ok)' : 'var(--tx-3)'}">${g.freeCount}</td>
                  <td>${g.isAccount ? badge('账号接入', 'info') : badge('其他', 'mute')}</td>
                  <td class="row-actions">
                    <button class="btn xs ghost" data-cht="${esc(g.channel)}">测</button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;color:var(--tx-3);line-height:1.7">
        模型来自本机 DSH 网关（8326），读取你已登录的账号池。
        点某个渠道的「测」会用该渠道第一个免费模型试一次。
      </div>
    </div>` : `
    <div class="card" style="margin-bottom:13px;border-color:rgba(251,191,36,.35)">
      <div class="card-body" style="font-size:11.5px;color:var(--warn);line-height:1.75">
        <b>DSH 网关未检测到</b> —— 确认 DSH 在运行且已登录账号。
        没有模型时 AI 分析会自动退回规则统计（不编造结论）。
      </div>
    </div>`}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '对接项', value: integ.length, unit: '个', iconName: 'plug',
                   foot: `${connected} 个已连通` })}
      ${statCard({ label: '可用模型', value: modelCount, unit: '个', iconName: 'layers',
                   foot: `${visionCount} 个支持视觉` })}
      ${statCard({ label: '技能', value: skills.length, unit: '个', iconName: 'bolt' })}
      ${statCard({ label: '插件', value: plugins.length, unit: '个', iconName: 'plug' })}
    </div>

    <div class="section-title">对接状态</div>
    <div class="grid g3" style="margin-bottom:18px">
      ${integ.map((it) => {
        const st = it.state === 'connected' ? ['已连通', 'ok', 'ok']
          : it.state === 'error' ? ['异常', 'danger', 'bad']
          : it.state === 'configured' ? ['已配置', 'warn', 'warn']
          : ['未配置', 'mute', ''];
        return `
          <div class="integ" data-integ="${it.id}">
            <div class="integ-top">
              <div class="integ-ico">${esc((it.label || '?').slice(0, 1))}</div>
              <div class="integ-name">
                <strong>${esc(it.label)}</strong>
                <span>${esc(it.kind || '')}</span>
              </div>
              <span class="dot ${st[2]}"></span>
            </div>
            <div class="integ-desc">${esc(it.desc || '')}</div>
            <div class="integ-foot">
              <span class="mono" style="font-size:10px;color:var(--tx-3)">${esc(it.endpoint || '—')}</span>
              <span class="badge ${st[1]}">${st[0]}</span>
            </div>
          </div>`;
      }).join('')}
    </div>

    <div class="section-title">模型来源</div>
    <div class="grid g2" style="margin-bottom:18px">
      ${models.map((src) => `
        <div class="integ" data-src="${src.id}">
          <div class="integ-top">
            <div class="integ-ico">${src.kind === 'plugin' ? icon('plug', 14) : icon('key', 14)}</div>
            <div class="integ-name">
              <strong>${esc(src.name)}</strong>
              <span>${src.plugin ? esc(src.plugin) + ' v' + esc(src.version || '') : 'API 端点'}</span>
            </div>
            <span class="dot ${src.on ? 'ok' : ''}"></span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;padding-top:8px;
                      border-top:1px dashed rgba(0,0,0,.06)">
            ${(src.models || []).length
              ? (src.models || []).slice(0, 10).map((mm) => `
                  <span class="chip" style="font-size:9.5px;padding:2px 7px"
                        title="${esc(mm.id || '')} · ctx ${mm.ctx || '—'}">
                    ${esc(mm.name || mm.id)}${mm.vision ? ' 👁' : ''}
                  </span>`).join('')
              : `<span style="font-size:10px;color:var(--tx-3)">无模型信息</span>`}
          </div>
        </div>`).join('') || '<div class="integ">无模型来源</div>'}
    </div>

    <div class="section-title">技能（skill）</div>
    <div class="card" style="margin-bottom:18px">
      <div class="card-body tight">
        ${skills.length ? skills.map((s) => `
          <div class="litem">
            <span class="dot ok"></span>
            <div class="litem-main">
              <div class="litem-title">${esc(s.name)}</div>
              <div class="litem-sub" style="font-family:var(--sans)">${esc((s.desc || '').slice(0, 140))}</div>
              <div class="litem-sub" style="color:var(--tx-3)">${esc(s.path || '')}</div>
            </div>
            <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">
              ${s.size ? (s.size / 1024).toFixed(1) + ' KB' : ''}
            </span>
          </div>`).join('')
          : '<div class="litem" style="justify-content:center;color:var(--tx-3)">未发现技能</div>'}
      </div>
    </div>

    <div class="section-title">插件</div>
    <div class="grid g3">
      ${plugins.length ? plugins.map((p) => `
        <div class="integ">
          <div class="integ-top">
            <div class="integ-ico">${icon('plug', 13)}</div>
            <div class="integ-name">
              <strong>${esc(p.name)}</strong>
              <span>v${esc(p.ver || '—')}</span>
            </div>
            <span class="dot ok"></span>
          </div>
          <div class="integ-desc" style="min-height:auto">${esc((p.desc || '').slice(0, 120))}</div>
        </div>`).join('')
        : '<div class="integ">未发现插件</div>'}
    </div>
  `;

  $$('[data-integ]', root).forEach((el) => {
    el.onclick = () => testOne(el.dataset.integ);
  });
  $$('[data-src]', root).forEach((el) => {
    el.onclick = () => openSource((store.models || []).find((x) => x.id === el.dataset.src));
  });

  const saveM = document.getElementById('dsh-save');
  if (saveM) saveM.onclick = async () => {
    const m = document.getElementById('dsh-model').value;
    try {
      await api.dshSelectModel(m);
      toast('已保存', m, 'ok');
      await load(root);
    } catch (e) { toast('失败', e.message, 'err'); }
  };
  const testM = document.getElementById('dsh-test');
  if (testM) testM.onclick = async () => {
    const out = document.getElementById('dsh-out');
    const m = document.getElementById('dsh-model').value;
    out.innerHTML = '<div style="font-size:11px;color:var(--tx-3)">测试中…（模型响应可能 20–60 秒）</div>';
    try {
      const t = await api.dshTest(m);
      out.innerHTML = `<div style="font-size:11px;color:${t.ok ? 'var(--ok)' : 'var(--danger)'}">
        ${t.ok ? '✓ 连通' : '✗ 失败'} · ${esc(t.model || m)}
        ${t.reply ? ` · 回复「${esc(t.reply)}」` : ''}
        ${t.error ? ` · ${esc(t.error)}` : ''}
      </div>`;
    } catch (e) {
      out.innerHTML = `<div style="font-size:11px;color:var(--danger)">✗ ${esc(e.message)}</div>`;
    }
  };
  $$('[data-cht]', root).forEach((b) => {
    b.onclick = async () => {
      const ch = b.dataset.cht;
      const g = (store.dsh.channels || []).find((x) => x.channel === ch);
      if (!g) return;
      // 优先免费模型
      const m = (g.models.find((x) => x.free) || g.models[0]).id;
      b.disabled = true; b.textContent = '…';
      try {
        const t = await api.dshTest(m);
        toast(t.ok ? '渠道可用' : '渠道不可用',
          `${ch} · ${m}${t.error ? ' · ' + t.error.slice(0, 60) : ''}`,
          t.ok ? 'ok' : 'warn', 7000);
      } catch (e) { toast('失败', e.message, 'err'); }
      finally { b.disabled = false; b.textContent = '测'; }
    };
  });
}

async function testOne(id) {
  try {
    const r = await api.testIntegration(id);
    toast(r.ok ? '连通' : '失败', r.error || (r.version || r.containers || r.proxies || '').toString(),
      r.ok ? 'ok' : 'err');
    await load(document.getElementById('view'));
  } catch (e) {
    toast('测试失败', e.message, 'err');
  }
}

async function retestAll(btn) {
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>重测中…';
  const ids = ['hubstudio', 'clash', 'ffmpeg'];
  let ok = 0;
  for (const id of ids) {
    try {
      const r = await api.testIntegration(id);
      if (r.ok) ok++;
    } catch { /* ignore */ }
  }
  toast('重测完成', `${ok}/${ids.length} 连通`, ok === ids.length ? 'ok' : 'warn');
  btn.disabled = false;
  btn.innerHTML = old;
  await load(document.getElementById('view'));
}

function openSource(src) {
  if (!src) return;
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="card" style="margin-bottom:13px"><div class="card-body" style="padding:11px 13px">
      <div class="kv"><span class="k">来源</span><span class="v">${esc(src.plugin || '自定义 API')} ${src.version ? 'v' + esc(src.version) : ''}</span></div>
      <div class="kv"><span class="k">模型数</span><span class="v">${(src.models || []).length}</span></div>
      <div class="kv"><span class="k">状态</span><span class="v" style="color:${src.on ? 'var(--ok)' : 'var(--tx-3)'}">${src.on ? '已启用' : '已停用'}</span></div>
    </div></div>
    <div class="section-title">可用模型</div>
    <div class="card"><div class="card-body tight">
      ${(src.models || []).map((m) => `
        <div class="litem">
          <div class="litem-main">
            <div class="litem-title">${esc(m.name || m.id)}
              ${m.vision ? badge('视觉', 'purple') : badge('纯文本', 'mute')}</div>
            <div class="litem-sub">${esc(m.id || '')}${m.ctx ? ' · 上下文 ' + nfmt(m.ctx) : ''}</div>
          </div>
        </div>`).join('') || '<div class="litem" style="justify-content:center;color:var(--tx-3)">无</div>'}
    </div></div>`;
  modal({ title: esc(src.name), body, footer: [Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: function () { this.closest('.modal-root').classList.remove('on'); } })] });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
