/* 风控中心：跳脸事件、熔断状态、签名库 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, ts, ago, emptyState, nfmt,
} from '../ui.js';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '风控中心',
      desc: '跳脸检测与熔断管理。命中即自动停止后续操作，不允许静默继续。',
      actions: [
        `<button class="btn sm" data-act="check"><span data-icon="shield"></span>立即检查</button>`,
        `<button class="btn sm ghost" data-act="refresh"><span data-icon="refresh"></span>刷新</button>`,
      ],
    })}
    <div id="gd-body"></div>
  `;
  $$('[data-act="refresh"]', root).forEach((b) => (b.onclick = () => load(root)));
  $$('[data-act="check"]', root).forEach((b) => (b.onclick = () => doCheck(b)));
  load(root);
}

async function load(root) {
  await store.loadGuard();
  try {
    store.signatures = (await api.guardSignatures());
  } catch (e) { store.signatures = { items: [], urlPatterns: [] }; }
  paint(root);
}

function paint(root) {
  const body = $('#gd-body', root);
  if (!body) return;
  const g = store.guard || {};
  const evs = store.guardEvents || [];
  const sig = store.signatures || { items: [], urlPatterns: [] };

  const byKind = g.byKind || {};
  const kindLabel = {
    checkpoint: '身份验证', captcha: '人机验证', action_block: '操作阻止',
    session_verify: '本人确认', rate_limit: '频率限制', suspicious: '异常活动',
  };

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({
        label: '当前状态',
        value: g.blocked ? '已熔断' : '正常',
        unit: '', iconName: g.blocked ? 'warn' : 'shield',
        foot: g.blocked ? `${g.count} 个未处理事件` : '无风控信号',
      })}
      ${statCard({ label: '未处理事件', value: g.count || 0, unit: '条', iconName: 'clock' })}
      ${statCard({ label: '受限环境', value: (g.blockedEnvs || []).length, unit: '个', iconName: 'layers' })}
      ${statCard({ label: '受限主页', value: (g.blockedPages || []).length, unit: '个', iconName: 'flag' })}
    </div>

    ${g.blocked ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="display:flex;gap:11px;align-items:flex-start">
        <span style="color:var(--danger);flex:0 0 auto;margin-top:2px">${icon('warn', 17)}</span>
        <div style="flex:1">
          <div style="font-size:13px;font-weight:620;color:var(--danger);margin-bottom:4px">
            已熔断：${kindLabel[g.latest?.kind] || g.latest?.kind || '风控信号'}
          </div>
          <div style="font-size:11.5px;color:var(--tx-2);line-height:1.7">
            ${g.latest?.message || ''}<br/>
            熔断范围：<b>${g.latest?.scope === 'account' ? '该账号（整个环境停止）'
              : g.latest?.scope === 'page' ? '该主页' : '全局'}</b>
            ${(g.blockedEnvs || []).length ? `<br/>受限环境：${g.blockedEnvs.join(', ')}` : ''}
            ${(g.blockedPages || []).length ? `<br/>受限主页：${g.blockedPages.slice(0, 8).join(', ')}${g.blockedPages.length > 8 ? ' …' : ''}` : ''}
          </div>
          <div style="margin-top:10px;display:flex;gap:7px">
            <button class="btn sm danger" data-act="resolve-all">全部解除（已人工确认）</button>
            <button class="btn sm ghost" data-act="open-browser">去浏览器确认</button>
          </div>
        </div>
      </div>
    </div>` : `
    <div class="card" style="margin-bottom:13px;border-color:rgba(52,211,153,.3);
                              background:rgba(52,211,153,.04)">
      <div class="card-body" style="display:flex;gap:11px;align-items:center">
        <span style="color:var(--ok)">${icon('check', 16)}</span>
        <div style="font-size:12px;color:var(--tx-1)">当前无风控信号，所有采集与发布可正常执行。</div>
      </div>
    </div>`}

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">事件列表 <span class="sub">${evs.length} 条未处理</span></div>
      </div>
      <div class="card-body tight">
        ${evs.length ? evs.map((e) => `
          <div class="litem">
            <span class="dot bad"></span>
            <div class="litem-main">
              <div class="litem-title">
                ${kindLabel[e.kind] || e.kind}
                ${badge(e.severity, e.severity === 'critical' ? 'danger' : 'warn')}
                ${badge(e.scope === 'account' ? '账号级' : e.scope === 'page' ? '主页级' : '全局', 'mute')}
              </div>
              <div class="litem-sub">${esc(e.message || '')}</div>
              <div class="litem-sub" style="color:var(--tx-3)">
                ${e.env_code || '—'} · ${e.page_id || '—'} · ${ts(e.ts, true)}
              </div>
            </div>
            <button class="btn xs ghost" data-resolve="${e.id}">解除</button>
          </div>`).join('')
          : `<div class="litem" style="justify-content:center;color:var(--tx-3);font-size:11.5px;padding:22px">
               没有未处理事件
             </div>`}
      </div>
    </div>

    <div class="grid g2">
      <div class="card">
        <div class="card-head"><div class="card-title">页面签名库</div></div>
        <div class="card-body tight">
          ${(sig.items || []).map((s) => `
            <div class="litem">
              <div class="litem-main">
                <div class="litem-title">
                  ${s.message}
                  ${badge(s.severity, s.severity === 'critical' ? 'danger' : 'warn')}
                </div>
                <div class="litem-sub" style="font-family:var(--mono);font-size:9.5px">
                  ${esc((s.pattern || '').slice(0, 90))}
                </div>
              </div>
            </div>`).join('')}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">URL 特征</div></div>
        <div class="card-body tight">
          ${(sig.urlPatterns || []).map((u) => `
            <div class="litem">
              <span class="dot bad"></span>
              <div class="litem-main">
                <div class="litem-title">${u.kind} ${badge(u.severity, 'warn')}</div>
                <div class="litem-sub" style="font-family:var(--mono)">${esc(u.fragment)}</div>
              </div>
            </div>`).join('')}
          <div style="padding:11px 14px;font-size:10.5px;color:var(--tx-3);line-height:1.7">
            命中任一特征即熔断。账号级熔断会停止整个环境的所有操作，
            主页级只跳过该主页。
          </div>
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:13px">
      <div class="card-head"><div class="card-title">防封控措施（已生效）</div></div>
      <div class="card-body">
        <div class="grid g3" style="gap:10px">
          ${[
            ['鼠标轨迹', '三次贝塞尔弧线 + 手抖，12–48 步'],
            ['落点偏移', '随机 ±6px，不点正中'],
            ['按压时长', '50–140ms，不是瞬时'],
            ['打字节奏', '逐字 45–160ms 变间隔'],
            ['滚动惯性', '90–260px/段，段间停顿'],
            ['账号节流', '操作间隔 2.5–6s，每 12 次强制休息 18–45s'],
            ['页面切换', '3–7s 随机间隔'],
            ['标签复用', '单实例单标签，不每操作开新页'],
            ['熔断粒度', '账号级整批停止，主页级单页跳过'],
          ].map(([k, v]) => `
            <div style="background:var(--bg-0);border-radius:var(--r-sm);padding:9px 11px">
              <div style="font-size:11.5px;font-weight:600;margin-bottom:3px">${k}</div>
              <div style="font-size:10px;color:var(--tx-3);line-height:1.6">${v}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>
  `;

  $$('[data-resolve]', root).forEach((b) => {
    b.onclick = async () => {
      try {
        await api.guardResolve(+b.dataset.resolve, '人工确认');
        toast('已解除', '该事件已标记处理', 'ok');
        load(root);
      } catch (e) { toast('失败', e.message, 'err'); }
    };
  });
  $$('[data-act="resolve-all"]', root).forEach((b) => {
    b.onclick = async () => {
      const evs = store.guardEvents || [];
      for (const e of evs) {
        try { await api.guardResolve(e.id, '人工确认全部'); } catch { /* ignore */ }
      }
      toast('已解除', `${evs.length} 个事件`, 'ok');
      load(root);
    };
  });
  $$('[data-act="open-browser"]', root).forEach((b) => {
    b.onclick = () => toast('提示', '请打开指纹浏览器对应环境，人工处理验证页面', 'info', 5000);
  });
}

async function doCheck(btn) {
  btn.disabled = true;
  try {
    const r = await api.guardCheck({});
    const v = r.verdict || {};
    if (v.tripped) {
      toast('发现风控信号', v.message || v.kind, 'err', 6000);
      load(document.getElementById('view'));
    } else {
      toast('检查通过', '当前页面无风控特征', 'ok');
    }
  } catch (e) {
    toast('检查失败', e.message, 'err');
  } finally {
    btn.disabled = false;
  }
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
