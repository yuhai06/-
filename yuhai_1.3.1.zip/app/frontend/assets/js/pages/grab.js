/* 素材抓取（PineDrama）
   · 剧类型一起抓（categories→7型+中文标签）
   · 自定义读取内容：剧型 / 标签 / 排除 / 起始集 / 翻页 / 排序
   · 自定义原始素材文件夹
   · 去重：已抓过的剧/集不再重抓
   · 后台静默，只显示进度 */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let env = null;
let hot = [];
let grabbed = [];
let jobs = [];
let meta = { types: [], tags: [], languages: [] };
let roots = { items: [], current: '' };
let recs = { items: [], stats: {} };
let filterType = '';
let showAll = false;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '素材抓取',
      desc: 'PineDrama · 剧类型一起抓 · 自定义条件 · 自动去重',
      actions: [
        `<button class="btn sm" data-act="allhot"><span data-icon="layers"></span>拉全榜</button>`,
        `<button class="btn sm" data-act="hot"><span data-icon="refresh"></span>刷新热门榜</button>`,
        `<button class="btn sm primary" data-act="run"><span data-icon="bolt"></span>开始抓取</button>`,
      ],
    })}
    <div id="gr-body"></div>
  `;
  $$('[data-act="hot"]', root).forEach((b) => (b.onclick = () => loadHot(b, false)));
  $$('[data-act="allhot"]', root).forEach((b) => (b.onclick = () => loadHot(b, true)));
  $$('[data-act="run"]', root).forEach((b) => (b.onclick = () => openRun(root)));
  paint(root);
  load(root);
}

async function load(root) {
  try {
    const [e, g, m, rr, rc] = await Promise.all([
      api.grabEnv(), api.grabGrabbed(), api.grabTypes(),
      api.grabRoots(), api.grabRecords(),
    ]);
    env = e;
    grabbed = g.items || [];
    meta = { types: m.types || [], tags: m.tags || [],
             languages: m.languages || [] };
    roots = rr;
    recs = rc;
    jobs = (await api.grabJobs?.() || { items: [] }).items || [];
  } catch (err) { console.warn(err.message); }
  paint(root);
}

async function loadHot(btn, all) {
  const old = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.textContent = all ? '拉全榜中…' : '拉取中…'; }
  try {
    const r = all ? await api.grabAllHot(30) : await api.grabHot(1, 30);
    hot = r.items || [];
    showAll = all;
    toast(all ? '全榜已拉取' : '热门榜已更新', `${hot.length} 部`, 'ok');
    paint(document.getElementById('view'));
  } catch (e) {
    toast('拉取失败', e.message, 'err', 6000);
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = old; }
  }
}

function typeBadge(t) {
  if (!t.typeZh) return '<span class="badge mute" style="font-size:8.5px">未分类</span>';
  return `<span class="badge purple" style="font-size:8.5px">${esc(t.typeZh)}</span>`;
}

function paint(root) {
  const body = $('#gr-body', root);
  if (!body) return;

  const totalMb = grabbed.reduce((a, x) => a + x.sizeMb, 0);
  const typeCount = recs.stats?.types?.length || 0;
  const shown = filterType
    ? hot.filter((h) => h.typeZh === filterType)
    : hot;

  body.innerHTML = `
    ${env && !env.ok ? `
    <div class="card" style="margin-bottom:13px;border-color:rgba(248,113,113,.45);
                              background:rgba(248,113,113,.05)">
      <div class="card-body" style="font-size:11.5px">
        <b style="color:var(--danger)">抓取环境不完整</b> ——
        curl: ${env.curl ? '✓' : '✗'} ·
        代理: ${env.proxyAlive ? '✓' : '✗'} (${esc(env.proxy)})
        ${env.downloadNeedsProxy ? `<div style="margin-top:5px;color:var(--warn)">
          代理端口通但连不上：列表能拉，<b>下载会失败</b>，先启动 Clash</div>` : ''}
      </div>
    </div>` : ''}

    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '已抓剧数', value: grabbed.length, unit: '部', iconName: 'layers',
                   foot: `${grabbed.reduce((a, x) => a + x.episodes, 0)} 集` })}
      ${statCard({ label: '占用空间', value: (totalMb / 1024).toFixed(1), unit: 'GB', iconName: 'db' })}
      ${statCard({ label: '去重台账', value: recs.stats?.dramas || 0, unit: '部',
                   iconName: 'shield',
                   foot: `${recs.stats?.episodes || 0} 集已记录 · ${typeCount} 种类型` })}
      ${statCard({ label: '热门榜', value: hot.length, unit: '部', iconName: 'chart',
                   foot: showAll ? '全榜' : (hot.length ? '第1页' : '点右上拉取') })}
    </div>

    <!-- 自定义原始素材文件夹 -->
    <div class="card" style="margin-bottom:13px;border-color:rgba(79,70,229,.28)">
      <div class="card-head">
        <div class="card-title"><span data-icon="db"></span> 原始素材保存位置</div>
        <button class="btn xs ghost" id="gr-root-pick">切换目录</button>
      </div>
      <div class="card-body">
        <div style="font-family:var(--mono);font-size:11px;word-break:break-all;
                    padding:8px 11px;background:var(--bg-0);border-radius:var(--r-sm)">
          ${esc(roots.current || env?.grabRoot || '')}
        </div>
        <div style="font-size:10px;color:var(--tx-3);margin-top:7px;line-height:1.7">
          抓下来的剧直接落到这里（每部一个文件夹，含 EP01.mp4… / meta.json / type.json）。
          换目录只影响新抓的，老素材留在原处不动。
        </div>
      </div>
    </div>

    <div class="grid" style="grid-template-columns:1.25fr 1fr;margin-bottom:13px">
      <!-- 热门榜 -->
      <div class="card">
        <div class="card-head">
          <div class="card-title">热门榜 <span class="sub">${shown.length}/${hot.length} 部</span></div>
          <select class="select" id="gr-filter" style="width:auto;font-size:10px;height:26px">
            <option value="">全部类型</option>
            ${[...new Set(hot.map((h) => h.typeZh).filter(Boolean))]
              .map((t) => `<option value="${esc(t)}" ${filterType === t ? 'selected' : ''}>${esc(t)}</option>`)
              .join('')}
          </select>
        </div>
        <div class="card-body tight" style="max-height:420px;overflow-y:auto">
          ${shown.length ? shown.map((h, i) => {
            const done = recs.items.some((r) => String(r.cid) === String(h.cid));
            return `
            <div class="litem" style="opacity:${done ? '0.55' : '1'}">
              <span style="width:20px;font-family:var(--mono);font-size:10px;
                           color:${i < 3 ? 'var(--ac)' : 'var(--tx-3)'}">${i + 1}</span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">${esc(h.title || h.cid)}</div>
                <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:3px">
                  ${typeBadge(h)}
                  ${(h.typeTags || []).slice(1, 3).map((t) =>
                    `<span class="chip ghost" style="font-size:8px">${esc(t)}</span>`).join('')}
                  ${done ? '<span class="badge ok" style="font-size:8px">已抓</span>' : ''}
                  ${h.hot ? '<span class="badge warn" style="font-size:8px">热</span>' : ''}
                  ${h.new ? '<span class="badge info" style="font-size:8px">新</span>' : ''}
                </div>
                <div class="litem-sub" style="font-family:var(--mono);font-size:9px;
                                              margin-top:2px">
                  ${h.cid}${h.episodes ? ` · ${h.episodes} 集` : ''}
                  ${h.views ? ` · ${nfmt(h.views)} 播放` : ''}
                </div>
              </div>
            </div>`;
          }).join('')
            : `<div class="litem" style="justify-content:center;color:var(--tx-3);padding:26px">
                 ${hot.length ? '该类型下没有剧' : '还没有加载榜单 · 点右上「刷新热门榜」或「拉全榜」'}
               </div>`}
        </div>
      </div>

      <!-- 已抓素材（带类型） -->
      <div class="card">
        <div class="card-head">
          <div class="card-title">已抓素材 <span class="sub">${grabbed.length} 部</span></div>
        </div>
        <div class="card-body tight" style="max-height:420px;overflow-y:auto">
          ${grabbed.length ? grabbed.map((g) => `
            <div class="litem">
              <span class="dot ok"></span>
              <div class="litem-main">
                <div class="litem-title" style="font-size:11.5px">${esc(g.title)}</div>
                <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:3px">
                  ${typeBadge(g)}
                  ${(g.typeTags || []).slice(1, 2).map((t) =>
                    `<span class="chip ghost" style="font-size:8px">${esc(t)}</span>`).join('')}
                </div>
                <div class="litem-sub">${g.episodes} 集 · ${g.sizeMb} MB
                  ${g.at ? ` · ${ago(g.at)}` : ''}</div>
              </div>
            </div>`).join('')
            : `<div class="litem" style="justify-content:center;color:var(--tx-3);padding:26px">
                 还没有抓取素材
               </div>`}
        </div>
      </div>
    </div>

    <!-- 去重台账 -->
    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">抓取台账 <span class="sub">${recs.stats?.dramas || 0} 部</span></div>
        <div style="display:flex;gap:5px">
          <span class="chip">${recs.stats?.episodes || 0} 集</span>
          ${(recs.items || []).length ? `<button class="btn xs ghost" id="gr-rec-clear">清空台账</button>` : ''}
        </div>
      </div>
      <div class="card-body tight" style="max-height:230px;overflow-y:auto">
        ${recs.items?.length ? recs.items.map((r) => `
          <div class="litem">
            <span class="dot ok"></span>
            <div class="litem-main">
              <div class="litem-title" style="font-size:11px">
                ${esc(r.title || r.cid)}
                <span class="badge purple" style="font-size:8px;margin-left:4px">
                  ${esc(r.type_zh || r.drama_type || '未分类')}</span>
              </div>
              <div class="litem-sub">已抓 ${(r.episodes || []).length}/${r.total_eps || '?'} 集
                · ${r.attempts} 次 · ${r.grabbed_at ? ago(r.grabbed_at) : ''}</div>
            </div>
            <button class="btn xs ghost" data-rec-clear="${esc(r.cid)}">重抓</button>
          </div>`).join('')
          : `<div style="padding:20px;text-align:center;color:var(--tx-3);font-size:11px">
               台账是空的 —— 抓过的剧会自动记在这里，下次不会重复抓
             </div>`}
      </div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">抓取任务</div></div>
      <div class="card-body tight" style="max-height:320px;overflow-y:auto">
        ${jobs.length ? jobs.slice(0, 10).map((j) => {
          const st = j.status === 'running' ? ['执行中', 'info']
            : j.status === 'done' ? ['完成', 'ok']
            : j.status === 'failed' ? ['失败', 'danger'] : ['排队', 'mute'];
          const res = j.result || {};
          return `
            <div class="litem" style="flex-direction:column;align-items:stretch;gap:6px">
              <div style="display:flex;gap:8px;align-items:center">
                <div class="litem-title" style="flex:1">${esc(j.title)} ${badge(st[0], st[1], j.status === 'running')}</div>
                <span style="font-family:var(--mono);font-size:10px;color:var(--tx-3)">${j.progress || 0}%</span>
              </div>
              ${bar(j.progress || 0, j.status === 'failed' ? 'danger' : j.status === 'done' ? 'ok' : '')}
              ${(j.steps || []).length ? `
                <div style="display:flex;flex-direction:column;gap:3px">
                  ${(j.steps || []).map((s) => `
                    <div style="display:flex;gap:7px;font-size:10.5px">
                      <span style="color:${s.state === 'done' ? 'var(--ok)' : s.state === 'err' ? 'var(--danger)' : s.state === 'run' ? 'var(--ac)' : 'var(--tx-3)'}">
                        ${s.state === 'done' ? '✓' : s.state === 'err' ? '✕' : s.state === 'run' ? '…' : '·'}
                      </span>
                      <span style="flex:1;color:var(--tx-2)">${esc(s.name)}</span>
                      <span style="color:var(--tx-3);font-size:9.5px">${esc(s.note || '')}</span>
                    </div>`).join('')}
                </div>` : ''}
              ${res.ok !== undefined ? `<div style="font-size:10px;color:var(--ok)">
                成功 ${res.ok} 集 · 失败 ${res.fail} 集
                ${res.skippedEps ? ` · 跳过 ${res.skippedEps} 集` : ''}
                ${(res.types || []).length ? ` · 类型 ${res.types.join(' / ')}` : ''}
              </div>` : ''}
              ${res.note ? `<div style="font-size:10px;color:var(--warn)">${esc(res.note)}</div>` : ''}
              ${j.error ? `<div style="font-size:10px;color:var(--danger)">${esc(j.error)}</div>` : ''}
            </div>`;
        }).join('') : '<div class="litem" style="justify-content:center;color:var(--tx-3);padding:22px">还没有抓取任务</div>'}
      </div>
      <div style="padding:9px 14px;background:var(--bg-0);font-size:10px;
                  color:var(--tx-3);line-height:1.7">
        抓取全程在后台跑，不会弹命令窗口；进度和结果都在这张卡里。
      </div>
    </div>
  `;

  // 事件绑定
  const f = $('#gr-filter', body);
  if (f) f.onchange = () => {
    filterType = f.value;
    paint(root);
  };
  const rp = $('#gr-root-pick', body);
  if (rp) rp.onclick = () => openRootPicker(root);
  const rc = $('#gr-rec-clear', body);
  if (rc) rc.onclick = () => clearRecords(root);
  $$('[data-rec-clear]', body).forEach((b) => {
    b.onclick = () => clearRecords(root, b.dataset.recClear);
  });
}

/* ---------------- 目录选择 ---------------- */
function openRootPicker(root) {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>已有目录</label>
      <div style="display:flex;flex-direction:column;gap:5px;max-height:200px;overflow-y:auto">
        ${(roots.items || []).map((r) => `
          <label class="litem" style="cursor:pointer;padding:7px 9px;border-radius:var(--r-sm);
                 border:1px solid ${r.custom ? 'var(--ac)' : 'var(--line)'};
                 background:${r.custom ? 'rgba(79,70,229,.05)' : 'transparent'}">
            <input type="radio" name="rootpick" value="${esc(r.path)}"
                   ${r.custom || r.default ? 'checked' : ''}
                   style="margin-right:8px" />
            <div class="litem-main">
              <div class="litem-title" style="font-size:10.5px">
                ${esc(r.path)}
                <span class="badge ${r.custom ? 'ok' : r.default ? 'info' : 'mute'}"
                      style="font-size:8px;margin-left:4px">${esc(r.tag)}</span>
              </div>
              <div class="litem-sub" style="font-size:9px">
                ${r.dramaCount} 部剧 · ${r.exists ? '存在' : '不存在（会自动创建）'}
              </div>
            </div>
          </label>`).join('')}
      </div>
    </div>
    <div class="field">
      <label>或输入新路径</label>
      <input class="input" id="rp-new" placeholder="D:\\我的素材\\原始素材"
             style="font-family:var(--mono);font-size:11px" />
      <div class="hint">留空 = 恢复默认（素材库/原始素材）</div>
    </div>`;
  const m = modal({
    title: '切换原始素材目录', width: 'mid', body,
    footer: [
      Object.assign(document.createElement('button'),
        { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const typed = body.querySelector('#rp-new').value.trim();
          const picked = body.querySelector('input[name="rootpick"]:checked')?.value || '';
          const target = typed || picked;
          try {
            const r = await api.grabSetRoot(target);
            toast('已切换', r.root, 'ok', 6000);
            roots = { items: r.items || [], current: r.root };
            env = await api.grabEnv();
            m.close();
            paint(root);
          } catch (e) { toast('切换失败', e.message, 'err', 6000); }
        },
      }),
    ],
  });
}

/* ---------------- 清台账 ---------------- */
async function clearRecords(root, cid) {
  const isAll = !cid;
  const name = isAll ? '全部台账'
    : (recs.items.find((r) => String(r.cid) === String(cid))?.title || cid);
  if (!confirm(`清空「${name}」的去重记录？\n清空后这部剧会被当成没抓过，下次会重抓。`)) return;
  try {
    const r = await api.grabRecordClear(cid || '');
    toast('已清空', isAll ? '台账全部清空' : name, 'ok');
    recs = { items: (await api.grabRecords()).items, stats: r.stats };
    paint(root);
  } catch (e) { toast('清空失败', e.message, 'err'); }
}

/* ---------------- 开始抓取 ---------------- */
function openRun(root) {
  const typeOpts = meta.types || [];
  const tagOpts = meta.tags || [];
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <label>抓取模式</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <label class="switch"><input type="radio" name="gr-mode" value="count" checked />
          <span class="track"></span><span class="lbl">按数量（N 部 × M 集）</span></label>
        <label class="switch"><input type="radio" name="gr-mode" value="all" />
          <span class="track"></span><span class="lbl">抓当天全部热门</span></label>
        <label class="switch"><input type="radio" name="gr-mode" value="search" />
          <span class="track"></span><span class="lbl">按关键词搜索（冷门题材）</span></label>
      </div>
    </div>

    <!-- 关键词搜索区：默认隐藏 -->
    <div id="gr-search-box" style="display:none">
      <div class="field">
        <label>搜索关键词（多个用逗号分隔）</label>
        <input class="input" id="gr-keywords" placeholder="sismance"
               style="font-size:11px" />
        <div class="hint">热榜只有主流题材；百合/GL 这类必须靠搜索</div>
      </div>
      <div class="field">
        <label>标签二次筛（必须含这些标签，过滤搜索结果里的无关剧）</label>
        <input class="input" id="gr-tagfilter" placeholder="sismance"
               style="font-size:11px" />
        <div class="hint">search 是模糊匹配，会混进无关剧；填标签能精确过滤</div>
      </div>
      <div class="field">
        <label>推荐组合（点一下自动填）</label>
        <div id="gr-kwhints" style="display:flex;flex-direction:column;gap:5px;
             max-height:170px;overflow-y:auto">
          <div style="font-size:10px;color:var(--tx-3)">加载中…</div>
        </div>
      </div>
      <div class="row-2">
        <div class="field"><label>搜索翻页</label>
          <input class="input" id="gr-kwpages" type="number" value="2" min="1" max="20" /></div>
        <div class="field"><label>搜索结果预览</label>
          <button class="btn sm" id="gr-kwpreview" style="width:100%">搜一下看看</button></div>
      </div>
      <div id="gr-kwresult" style="font-size:10px;color:var(--tx-2);
           max-height:130px;overflow-y:auto;line-height:1.8"></div>
    </div>

    <div id="gr-count-box" class="row-2">
      <div class="field"><label>抓几部剧</label>
        <input class="input" id="gr-dramas" type="number" value="3" min="1" max="200" /></div>
      <div class="field"><label>每部抓几集</label>
        <input class="input" id="gr-eps" type="number" value="10" min="1" max="200" /></div>
    </div>

    <div class="field">
      <label>剧类型（勾选＝优先抓这些类型；不勾＝不限）</label>
      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:5px">
        ${typeOpts.map((t) => `
          <label class="chip" style="cursor:pointer;user-select:none">
            <input type="checkbox" class="gr-type" value="${esc(t.key)}"
                   style="margin-right:4px" />${esc(t.name)}
          </label>`).join('')}
      </div>
    </div>

    <div class="field">
      <label>只要这些标签（可多选，空格分隔也行）</label>
      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:5px;max-height:130px;overflow-y:auto">
        ${tagOpts.map((t) => `
          <label class="chip ghost" style="cursor:pointer;user-select:none;font-size:9.5px">
            <input type="checkbox" class="gr-tag" value="${esc(t)}"
                   style="margin-right:3px" />${esc(t)}
          </label>`).join('')}
      </div>
      <input class="input" id="gr-tags-extra" placeholder="额外关键词，逗号分隔"
             style="margin-top:6px;font-size:11px" />
    </div>

    <div class="field">
      <label>自定义抓取类型（填了就只抓匹配这些词的剧）</label>
      <input class="input" id="gr-custom-types"
             placeholder="如：复仇, 豪门, 失忆, 战神  （逗号分隔，留空=不限）"
             style="font-size:11px" />
      <div class="hint">会在分类标签和标题里模糊匹配；和上面的 7 型是「与」关系</div>
    </div>

    <div class="field">
      <label>语言筛选</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:7px">
        <label class="switch"><input type="radio" name="gr-langmode" value="off" checked />
          <span class="track"></span><span class="lbl">不筛选（推荐）</span></label>
        <label class="switch"><input type="radio" name="gr-langmode" value="include" />
          <span class="track"></span><span class="lbl">只要勾选的语言</span></label>
        <label class="switch"><input type="radio" name="gr-langmode" value="exclude" />
          <span class="track"></span><span class="lbl">排除勾选的语言</span></label>
      </div>
      <div id="gr-lang-box" style="display:flex;gap:5px;flex-wrap:wrap;
           opacity:.45;pointer-events:none">
        ${(meta.languages || []).map((l) => `
          <label class="chip ghost" style="cursor:pointer;user-select:none;font-size:9.5px">
            <input type="checkbox" class="gr-lang" value="${esc(l.code)}"
                   style="margin-right:3px" />${esc(l.name)}
          </label>`).join('')}
      </div>
      <div class="hint">语言从标题/描述推断；判不出来的剧在「只要」模式下也会放行，不会漏抓</div>
    </div>

    <div class="field">
      <label>排除标签（这些类型的剧不抓）</label>
      <input class="input" id="gr-excl" placeholder="如：末世灾变, 幻想"
             style="font-size:11px" />
    </div>

    <div class="row-2">
      <div class="field"><label>从第几集开始</label>
        <input class="input" id="gr-startep" type="number" value="1" min="1" /></div>
      <div class="field"><label>排序依据</label>
        <select class="select" id="gr-order">
          <option value="list">榜单顺序</option>
          <option value="hot">播放量最高</option>
          <option value="newest">最新优先</option>
        </select></div>
    </div>

    <div class="field">
      <label>榜单翻页（候选池越大越容易挑到想要的类型）</label>
      <input class="input" id="gr-pages" type="number" value="2" min="1" max="60" />
      <div class="hint">每页约 15 部；全榜模式会自动翻到底</div>
    </div>

    <div class="field">
      <label>保存到</label>
      <input class="input" id="gr-root" value="${esc(roots.current || '')}"
             style="font-family:var(--mono);font-size:10.5px" />
      <div class="hint">本次生效；想永久改去顶部「切换目录」</div>
    </div>

    <div class="field">
      <div style="display:flex;flex-direction:column;gap:8px">
        <label class="switch"><input type="checkbox" id="gr-dedupe" checked />
          <span class="track"></span><span class="lbl">去重：已抓过的剧不再抓（推荐）</span></label>
        <label class="switch"><input type="checkbox" id="gr-skipeps" checked />
          <span class="track"></span><span class="lbl">已抓过的集不重复下载</span></label>
        <label class="switch"><input type="checkbox" id="gr-ai" checked />
          <span class="track"></span><span class="lbl">参考 AI 分析偏好排序</span></label>
      </div>
    </div>

    <div class="card"><div class="card-body" style="padding:10px 12px;font-size:10.5px;
                color:var(--tx-2);line-height:1.8">
      <b>剧类型会一起抓</b>：上游 categories/tags 自动映射成 7 型 + 中文标签，
      存进 meta.json 和 type.json，切片和素材库都能直接用。<br/>
      <b>后台静默</b>：不会弹命令窗口，进度看任务卡。<br/>
      <b>节流</b>：每集两次 API，7.5 秒间隔；60 集约 40 分钟。
    </div></div>`;

  // 模式切换
  const bindMode = () => {
    const mode = body.querySelector('input[name="gr-mode"]:checked').value;
    const box = body.querySelector('#gr-count-box');
    if (box) box.style.display = mode === 'all' ? 'none' : 'grid';
    const sb = body.querySelector('#gr-search-box');
    if (sb) sb.style.display = mode === 'search' ? 'block' : 'none';
    const pg = body.querySelector('#gr-pages');
    if (pg) pg.disabled = mode === 'all';
    if (mode === 'search') loadKwHints();
  };
  body.querySelectorAll('input[name="gr-mode"]').forEach((r) => {
    r.onchange = bindMode;
  });

  // 推荐关键词
  async function loadKwHints() {
    const box = body.querySelector('#gr-kwhints');
    if (!box || box.dataset.loaded) return;
    try {
      const r = await api.grabKeywords();
      box.innerHTML = (r.items || []).map((h, i) => `
        <label class="litem" style="cursor:pointer;padding:6px 8px;
               border:1px solid var(--line);border-radius:var(--r-sm)">
          <input type="radio" name="kwhint" data-idx="${i}" style="margin-right:7px" />
          <div class="litem-main">
            <div class="litem-title" style="font-size:10px">${esc(h.label)}</div>
            <div class="litem-sub" style="font-size:8.5px;color:var(--tx-3)">
              ${esc((h.keywords || []).join(', '))}
              ${(h.tagFilter || []).length ? ` （筛：${esc(h.tagFilter.join(','))}）` : ''}
              — ${esc(h.desc)}
            </div>
          </div>
        </label>`).join('');
      box.dataset.loaded = '1';
      box.querySelectorAll('input[name="kwhint"]').forEach((el) => {
        el.onchange = () => {
          const h = r.items[parseInt(el.dataset.idx, 10)];
          body.querySelector('#gr-keywords').value = (h.keywords || []).join(',');
          body.querySelector('#gr-tagfilter').value = (h.tagFilter || []).join(',');
        };
      });
    } catch (e) {
      box.innerHTML = `<div style="color:var(--danger);font-size:10px">
        加载失败：${esc(e.message)}</div>`;
    }
  }

  // 搜索预览
  const prev = body.querySelector('#gr-kwpreview');
  if (prev) {
    prev.onclick = async () => {
      const kw = (body.querySelector('#gr-keywords').value.split(/[,，\s]+/)
        .filter(Boolean))[0];
      if (!kw) { toast('先填关键词', '', 'err'); return; }
      prev.disabled = true; prev.textContent = '搜索中…';
      const out = body.querySelector('#gr-kwresult');
      try {
        const r = await api.grabSearch(kw, parseInt(body.querySelector('#gr-kwpages').value, 10) || 2);
        const items = r.items || [];
        out.innerHTML = items.length
          ? `<div style="margin-bottom:4px;color:var(--ok)">
              「${esc(kw)}」找到 ${items.length} 部</div>` +
            items.slice(0, 20).map((x) => `
              <div>· ${esc(x.title)}
                <span style="color:var(--tx-3)">${esc((x.typeTags || []).join(' / '))}</span>
              </div>`).join('')
          : `<div style="color:var(--warn)">「${esc(kw)}」没有结果，换个词试试</div>`;
      } catch (e) {
        out.innerHTML = `<div style="color:var(--danger)">${esc(e.message)}</div>`;
      } finally { prev.disabled = false; prev.textContent = '搜一下看看'; }
    };
  }

  // 语言模式：选「不筛选」时禁用勾选框
  const bindLang = () => {
    const mode = body.querySelector('input[name="gr-langmode"]:checked').value;
    const box = body.querySelector('#gr-lang-box');
    if (!box) return;
    const off = mode === 'off';
    box.style.opacity = off ? '.45' : '1';
    box.style.pointerEvents = off ? 'none' : 'auto';
  };
  body.querySelectorAll('input[name="gr-langmode"]').forEach((r) => {
    r.onchange = bindLang;
  });

  const m = modal({
    title: '开始抓取', width: 'wide', body,
    clickOutsideClose: false,      // 长表单：点外面绝不关，只有取消/× 能关
    closable: false,               // 去掉右上 ×，避免手滑点掉 (底部有「取消」)
    footer: [
      Object.assign(document.createElement('button'), {
        className: 'btn', textContent: '取消',
        onclick: () => {
          // 有改动就确认一下，别把填好的条件白丢
          const touched = body.querySelector('#gr-keywords')?.value.trim()
            || body.querySelector('#gr-custom-types')?.value.trim()
            || body.querySelector('#gr-tags-extra')?.value.trim()
            || body.querySelector('#gr-excl')?.value.trim()
            || body.querySelector('#gr-tagfilter')?.value.trim()
            || body.querySelectorAll('.gr-type:checked').length
            || body.querySelectorAll('.gr-tag:checked').length;
          if (touched && !confirm('表单里填了内容，关闭会丢掉。确定关闭？')) return;
          m.close();
        },
      }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '开始抓取',
        onclick: async () => {
          const btn = m.el.querySelector('.btn.primary');
          btn.disabled = true; btn.textContent = '提交中…';
          try {
            const mode = body.querySelector('input[name="gr-mode"]:checked').value;
            const wantTags = [...body.querySelectorAll('.gr-tag:checked')]
              .map((x) => x.value);
            const extra = body.querySelector('#gr-tags-extra').value
              .split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean);
            const exclude = body.querySelector('#gr-excl').value
              .split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean);
            const customTypes = body.querySelector('#gr-custom-types').value
              .split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean);
            const keywords = mode === 'search'
              ? body.querySelector('#gr-keywords').value
                  .split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean)
              : [];
            const tagFilter = mode === 'search'
              ? body.querySelector('#gr-tagfilter').value
                  .split(/[,，\s]+/).map((s) => s.trim().toLowerCase()).filter(Boolean)
              : [];
            if (mode === 'search' && !keywords.length) {
              toast('搜索模式需要关键词', '填 sismance 抓百合', 'err', 6000);
              btn.disabled = false; btn.textContent = '开始抓取';
              return;
            }
            const langMode = body.querySelector('input[name="gr-langmode"]:checked').value;
            const wantLangs = langMode === 'off' ? []
              : [...body.querySelectorAll('.gr-lang:checked')].map((x) => x.value);
            const r = await api.grabRun({
              dramas: parseInt(body.querySelector('#gr-dramas').value, 10) || 3,
              episodes: parseInt(body.querySelector('#gr-eps').value, 10) || 10,
              useAnalysis: body.querySelector('#gr-ai').checked,
              wantTypes: [...body.querySelectorAll('.gr-type:checked')]
                .map((x) => x.value),
              customTypes,
              wantTags: [...wantTags, ...extra],
              excludeTags: exclude,
              wantLangs,
              langMode,
              keywords,
              kwPages: parseInt(body.querySelector('#gr-kwpages').value, 10) || 2,
              tagFilter,
              startEp: parseInt(body.querySelector('#gr-startep').value, 10) || 1,
              cursorPages: parseInt(body.querySelector('#gr-pages').value, 10) || 2,
              orderBy: body.querySelector('#gr-order').value,
              allHot: mode === 'all',
              dedupe: body.querySelector('#gr-dedupe').checked,
              skipExistingEps: body.querySelector('#gr-skipeps').checked,
              root: body.querySelector('#gr-root').value.trim(),
            });
            toast('已入队', `任务 ${r.jobId}`, 'ok', 6000);
            m.close();
            const t0 = Date.now();
            while (Date.now() - t0 < 7200000) {
              await new Promise((res) => setTimeout(res, 5000));
              const j = await api.job(r.jobId);
              if (['done', 'failed'].includes(j.status)) {
                const r2 = j.result || {};
                toast(j.status === 'done' ? '抓取完成' : '抓取失败',
                  j.status === 'done'
                    ? `${r2.dramas} 部 · ${r2.ok} 集${r2.skippedEps ? ` · 跳过 ${r2.skippedEps}` : ''}`
                    : (j.error || ''),
                  j.status === 'done' ? 'ok' : 'err', 9000);
                break;
              }
            }
            await load(root);
          } catch (e) { toast('失败', e.message, 'err', 6000); }
          finally { btn.disabled = false; btn.textContent = '开始抓取'; }
        },
      }),
    ],
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
