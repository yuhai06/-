/* 排期与队列（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, $, $$, toast, modal, bar, ts, ago, emptyState, nfmt,
} from '../ui.js';

let view = 'calendar';
let weekOffset = 0;
let envFilter = '';
let pageFilter = 'all';

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '排期与队列',
      desc: '把要发的视频放进队列，排期从队列取素材；发布成功后素材立即删除',
      actions: [
        `<button class="btn sm" data-act="rules"><span data-icon="cog"></span>排期规则</button>`,
        `<button class="btn sm primary" data-act="autoplan"><span data-icon="bolt"></span>自动排期</button>`,
      ],
    })}
    <div id="sc-body"></div>
  `;
  $$('[data-act="rules"]', root).forEach((b) => (b.onclick = () => openRules(root)));
  $$('[data-act="autoplan"]', root).forEach((b) => (b.onclick = () => openAutoPlan(root)));
  paint(root);
  load(root);
}

async function load(root) {
  await Promise.all([store.loadQueue(), store.loadSchedule(), store.loadLibrary({})]);
  if (!store.envs || !store.envs.length) {
    try { await store.loadCore(); } catch { /* ignore */ }
  }
  paint(root);
}

function isoOf(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function weekDates() {
  const base = new Date();
  const dow = (base.getDay() + 6) % 7;
  base.setDate(base.getDate() - dow + weekOffset * 7);
  base.setHours(0, 0, 0, 0);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(base.getTime() + i * 86400000);
    return {
      iso: isoOf(d),
      label: ['一', '二', '三', '四', '五', '六', '日'][i],
      day: d.getDate(),
      isToday: isoOf(d) === isoOf(new Date()),
    };
  });
}

function paint(root) {
  const body = $('#sc-body', root);
  if (!body) return;
  const q = store.queue || [];
  const schAll = store.schedule || [];
  const rules = store.rules || {};

  // 按号 / 按主页筛选（前端过滤，避免每次切换都请求）
  let sch = schAll.slice();
  if (envFilter) {
    const pageIdsInEnv = new Set((store.pages || [])
      .filter((p) => p.envCode === envFilter).map((p) => p.profileId));
    sch = sch.filter((s) => pageIdsInEnv.has(s.page));
  }
  if (pageFilter !== 'all') sch = sch.filter((s) => s.page === pageFilter);

  const ready = q.filter((x) => x.state === 'ready').length;
  const planned = sch.filter((s) => s.state === 'planned').length;
  const blocked = sch.filter((s) => s.state === 'blocked').length;

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '队列待发', value: ready, unit: '条', iconName: 'layers',
                   foot: `${q.reduce((a, x) => a + (+x.size_mb || 0), 0).toFixed(0)} MB` })}
      ${statCard({ label: '已排期', value: planned, unit: '条', iconName: 'clock' })}
      ${statCard({ label: '排期受阻', value: blocked, unit: '条', iconName: 'warn' })}
      ${statCard({ label: '发布后清理', value: rules.deleteAfterPublish ? '开' : '关', unit: '',
                   iconName: 'trash' })}
    </div>

    <div class="card">
      <div class="card-head">
        <div class="tabs" style="border:none;padding:0;margin:0">
          <div class="tab ${view === 'calendar' ? 'active' : ''}" data-tab="calendar">
            排期日历 <span class="cnt">${sch.length}</span>
          </div>
          <div class="tab ${view === 'queue' ? 'active' : ''}" data-tab="queue">
            素材队列 <span class="cnt">${q.length}</span>
          </div>
        </div>
        <div id="sc-tools"></div>
      </div>
      <div class="card-body" id="sc-inner"></div>
    </div>
  `;

  // 号 / 主页筛选条（放在 tabs 上方）
  const head = body.querySelector('.card-head');
  if (head) {
    const filt = document.createElement('div');
    filt.style.cssText = 'display:flex;gap:7px;align-items:center;padding:8px 14px 0 14px';
    filt.innerHTML = `
      <span style="font-size:10.5px;color:var(--tx-3)">筛选</span>
      <select class="select" id="sc-env" style="width:150px;padding:3px 8px;font-size:11px">
        <option value="">全部号</option>
        ${(store.envs || []).filter((e) => e.status !== 'removed').map((e) =>
          `<option value="${e.containerCode}" ${envFilter === e.containerCode ? 'selected' : ''}>${esc(e.name)}</option>`).join('')}
      </select>
      <select class="select" id="sc-page" style="width:170px;padding:3px 8px;font-size:11px">
        <option value="all" ${pageFilter === 'all' ? 'selected' : ''}>全部主页</option>
        ${(store.pages || []).map((p) =>
          `<option value="${p.profileId}" ${pageFilter === p.profileId ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}
      </select>
      ${(envFilter || pageFilter !== 'all') ? '<button class="btn xs ghost" id="sc-clearf">清除</button>' : ''}
    `;
    head.parentElement.insertBefore(filt, head.nextSibling);
    const se = filt.querySelector('#sc-env');
    if (se) se.onchange = (e) => { envFilter = e.target.value; paint(root); };
    const sp = filt.querySelector('#sc-page');
    if (sp) sp.onchange = (e) => { pageFilter = e.target.value; paint(root); };
    const cf = filt.querySelector('#sc-clearf');
    if (cf) cf.onclick = () => { envFilter = ''; pageFilter = 'all'; paint(root); };
  }

  $$('[data-tab]', root).forEach((t) => {
    t.onclick = () => { view = t.dataset.tab; paint(root); };
  });

  const tools = $('#sc-tools', root);
  const inner = $('#sc-inner', root);

  if (view === 'calendar') {
    const days = weekDates();
    tools.innerHTML = `
      <div style="display:flex;gap:6px;align-items:center">
        <button class="btn xs ghost" data-week="-1">‹ 上周</button>
        <span class="chip">${days[0].iso.slice(5)} ~ ${days[6].iso.slice(5)}</span>
        <button class="btn xs ghost" data-week="1">下周 ›</button>
        <button class="btn xs" data-week="0">本周</button>
      </div>`;
    $$('[data-week]', root).forEach((b) => {
      b.onclick = () => {
        const v = parseInt(b.dataset.week, 10);
        weekOffset = v === 0 ? 0 : weekOffset + v;
        paint(root);
      };
    });
    inner.innerHTML = `
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px">
        ${days.map((d) => {
          const items = sch.filter((s) => s.date === d.iso);
          return `
            <div style="background:var(--bg-0);border-radius:var(--r-md);min-height:200px;padding:8px;
                        ${d.isToday ? 'box-shadow:inset 0 0 0 1.5px var(--ac)' : ''}">
              <div style="display:flex;align-items:center;gap:5px;margin-bottom:7px">
                <span style="font-size:10.5px;color:var(--tx-3)">周${d.label}</span>
                <strong style="font-size:13px;${d.isToday ? 'color:var(--ac)' : ''}">${d.day}</strong>
                ${d.isToday ? badge('今天', 'info') : ''}
                <span style="margin-left:auto;font-size:10px;color:var(--tx-3)">${items.length || ''}</span>
              </div>
              ${items.map(schedItem).join('') || '<div style="text-align:center;color:var(--tx-3);font-size:10.5px;padding:20px 0">—</div>'}
              <button class="btn xs ghost" data-add="${d.iso}"
                      style="width:100%;margin-top:6px;justify-content:center;opacity:.6">+ 加一条</button>
            </div>`;
        }).join('')}
      </div>
      <div style="margin-top:13px;display:flex;gap:14px;flex-wrap:wrap;font-size:10.5px;color:var(--tx-3)">
        <span>${badge('完成', 'ok')} 已发布</span>
        <span>${badge('待执行', 'info')} 已绑素材</span>
        <span>${badge('受阻', 'danger')} 主页受限或素材缺失</span>
        <span style="margin-left:auto">每页每天 ${rules.perPagePerDay || 2} 条 · 时段 ${rules.windowStart || 19}:00–${rules.windowEnd || 22}:00 · 最小间隔 ${rules.minGapMinutes || 120} 分钟</span>
      </div>`;
    $$('[data-add]', root).forEach((b) => (b.onclick = () => openAddSchedule(root, b.dataset.add)));
    $$('[data-sched]', root).forEach((el) => {
      el.onclick = () => openSchedDetail(root, store.schedule.find((s) => s.id === el.dataset.sched));
    });
    return;
  }

  // 队列视图
  tools.innerHTML = `
    <div style="display:flex;gap:7px;align-items:center">
      <span class="chip">合计 <b>${q.reduce((a, x) => a + (+x.size_mb || 0), 0).toFixed(1)}</b> MB</span>
      <button class="btn xs ghost" data-act="addq"><span data-icon="plus"></span>从素材库推</button>
    </div>`;
  $$('[data-act="addq"]', root).forEach((b) => (b.onclick = () => { location.hash = '#/library'; }));

  inner.innerHTML = q.length ? `
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr>
          <th>素材</th><th>剧名</th><th>集</th><th>指定主页</th>
          <th class="num">时长</th><th class="num">大小</th><th>状态</th><th>入队时间</th><th></th>
        </tr></thead>
        <tbody>
          ${q.map((x) => `
            <tr data-queue="${x.id}">
              <td style="font-family:var(--mono);font-size:10.5px;max-width:280px;overflow:hidden;
                         text-overflow:ellipsis;white-space:nowrap">${esc(x.file)}</td>
              <td>${esc(x.drama || '—')}</td>
              <td class="mono">${x.ep || '—'}</td>
              <td>${x.page ? `<b style="font-family:var(--mono);color:var(--ac)">${esc(x.page)}</b>` : '—'}</td>
              <td class="num">${x.dur || '—'}s</td>
              <td class="num">${x.size_mb || '—'} MB</td>
              <td>${x.state === 'ready' ? badge('待排期', 'ok', true)
                : x.state === 'scheduled' ? badge('已排期', 'info', true)
                : x.state === 'publishing' ? badge('发布中', 'warn', true)
                : x.state === 'done' ? badge('已发', 'mute', true)
                : badge(x.state, 'danger', true)}</td>
              <td class="mono">${x.added_at ? ts(x.added_at, true) : '—'}</td>
              <td class="row-actions">
                <button class="btn xs ghost" data-qx="del" data-q="${x.id}">移除</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div style="margin-top:11px;padding:9px 11px;background:var(--bg-0);border-radius:var(--r-sm);
                font-size:10.5px;color:var(--tx-3);line-height:1.65">
      队列是临时中转区，不保留历史：发布成功 → 立即删除文件；失败 → 保留等待重试。
    </div>` : `<div class="card-body">${emptyState('队列为空', '去素材库选素材推入')}</div>`;

  $$('[data-qx]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      try {
        await api.delQueue(b.dataset.q, false);
        toast('已移除', '记录已删（文件保留）', 'warn');
        await load(document.getElementById('view'));
      } catch (err) { toast('失败', err.message, 'err'); }
    };
  });
}

function schedItem(s) {
  const kind = s.state === 'done' ? 'ok' : s.state === 'blocked' ? 'danger' : 'info';
  const color = s.state === 'done' ? 'var(--ok)' : s.state === 'blocked' ? 'var(--danger)' : 'var(--ac)';
  return `
    <div data-sched="${s.id}" style="background:var(--bg-1);border-radius:7px;padding:6px 7px;
         margin-bottom:5px;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.06);
         border-left:2.5px solid ${color}">
      <div style="display:flex;align-items:center;gap:4px;margin-bottom:2px">
        <strong style="font-size:11px;font-family:var(--mono)">${s.time}</strong>
        <span style="font-size:10.5px;color:var(--ac);font-weight:600">${esc(s.page)}</span>
        <span style="margin-left:auto;font-size:9px;color:var(--tx-3)">${s.ep || ''}</span>
      </div>
      <div style="font-size:10px;color:var(--tx-2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
        ${esc(s.drama || '—')}
      </div>
      <div style="font-size:9px;color:${s.state === 'blocked' ? 'var(--danger)' : s.state === 'done' ? 'var(--ok)' : 'var(--tx-3)'};margin-top:2px">
        ${s.state === 'done' ? '已发布' : s.state === 'blocked' ? (s.note || '受阻') : (s.queue ? `素材 ${s.queue.size_mb}MB` : '未绑素材')}
      </div>
    </div>`;
}

/* ---------------- 新增排期 ---------------- */
function openAddSchedule(root, date) {
  const q = (store.queue || []).filter((x) => x.state === 'ready');
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field"><label>目标主页</label>
        <select class="select" id="as-page">
          ${(store.pages || []).map((p) => `<option value="${p.name}">${p.name}${p.health !== 'ok' ? '（受限）' : ''}</option>`).join('')}
        </select>
      </div>
      <div class="field"><label>日期</label>
        <input class="input" id="as-date" type="date" value="${date}" style="font-family:var(--mono)" /></div>
    </div>
    <div class="row-2">
      <div class="field"><label>时间</label>
        <input class="input" id="as-time" type="time" value="19:30" style="font-family:var(--mono)" /></div>
      <div class="field"><label>素材</label>
        <select class="select" id="as-q">
          <option value="">— 稍后绑 —</option>
          ${q.map((x) => `<option value="${x.id}">${esc(x.drama)} ${x.ep || ''} · ${x.file.slice(-30)}</option>`).join('')}
        </select>
      </div>
    </div>`;
  const m = modal({
    title: '新增排期', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '加入排期',
        onclick: async () => {
          const qid = body.querySelector('#as-q').value;
          const qq = (store.queue || []).find((x) => x.id === qid);
          try {
            await api.addSchedule({
              page: body.querySelector('#as-page').value,
              date: body.querySelector('#as-date').value,
              time: body.querySelector('#as-time').value,
              drama: qq ? qq.drama : '',
              ep: qq ? qq.ep : '',
              queueId: qid,
            });
            toast('已加入', '', 'ok');
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('失败', e.message, 'err', 6000); }
        },
      }),
    ],
  });
}

function openSchedDetail(root, s) {
  if (!s) return;
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="grid g2" style="margin-bottom:12px">
      <div class="kv"><span class="k">主页</span><span class="v">${esc(s.page)}</span></div>
      <div class="kv"><span class="k">时间</span><span class="v">${s.date} ${s.time}</span></div>
      <div class="kv"><span class="k">剧名</span><span class="v">${esc(s.drama || '—')}</span></div>
      <div class="kv"><span class="k">状态</span><span class="v">${s.state}</span></div>
    </div>
    ${s.note ? `<div class="hint" style="margin-bottom:10px">${esc(s.note)}</div>` : ''}`;
  const m = modal({
    title: '排期详情', body,
    clickOutsideClose: false,      // 详情里有删除操作，别让人误触点外面丢掉查看位置
    footer: [
      Object.assign(document.createElement('button'), {
        className: 'btn danger', textContent: '删除',
        onclick: async () => {
          try { await api.delSchedule(s.id); toast('已删除', '', 'warn'); m.close(); await load(document.getElementById('view')); }
          catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '关闭', onclick: () => m.close() }),
    ],
  });
}

/* ---------------- 规则 ---------------- */
function openRules(root) {
  const r = store.rules || {};
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="field">
      <div style="display:flex;align-items:center;justify-content:space-between">
        <label style="margin:0">每主页每天上限</label>
        <input class="input" id="r-per" type="number" value="${r.perPagePerDay || 2}" style="width:100px;text-align:right" />
      </div>
      <div class="hint">同主页一天多发容易触发风控，建议 1–2</div>
    </div>
    <div class="row-2">
      <div class="field"><label>时段起</label>
        <input class="input" id="r-ws" type="number" value="${r.windowStart || 19}" /></div>
      <div class="field"><label>时段止</label>
        <input class="input" id="r-we" type="number" value="${r.windowEnd || 22}" /></div>
    </div>
    <div class="field"><label>同页最小间隔（分钟）</label>
      <input class="input" id="r-gap" type="number" value="${r.minGapMinutes || 120}" /></div>
    <div style="display:flex;flex-direction:column;gap:8px">
      <label class="switch"><input type="checkbox" id="r-del" ${r.deleteAfterPublish ? 'checked' : ''} />
        <span class="track"></span><span class="lbl">发布成功后删除本地素材</span></label>
      <label class="switch"><input type="checkbox" id="r-skip" ${r.skipRestrictedPages ? 'checked' : ''} />
        <span class="track"></span><span class="lbl">主页受限时跳过并顺延</span></label>
    </div>`;
  const m = modal({
    title: '排期规则', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          try {
            await api.setScheduleRules({
              perPagePerDay: +body.querySelector('#r-per').value,
              windowStart: +body.querySelector('#r-ws').value,
              windowEnd: +body.querySelector('#r-we').value,
              minGapMinutes: +body.querySelector('#r-gap').value,
              deleteAfterPublish: body.querySelector('#r-del').checked,
              skipRestrictedPages: body.querySelector('#r-skip').checked,
            });
            toast('已保存', '', 'ok');
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

/* ---------------- 自动排期 ---------------- */
async function openAutoPlan(root) {
  let cap;
  try { cap = await api.capacity(3); } catch { cap = {}; }
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="row-2">
      <div class="field"><label>排期天数</label>
        <input class="input" id="ap-days" type="number" value="3" min="1" max="30" /></div>
      <div class="field"><label>分配方式</label>
        <select class="select" id="ap-mode">
          <option value="page-first">优先填满同一主页</option>
          <option value="spread">跨主页均匀铺开</option>
        </select>
      </div>
    </div>
    <div class="card"><div class="card-body" style="padding:11px 13px;font-size:11.5px;color:var(--tx-2);line-height:1.8">
      可用主页 <b>${cap.pagesAvailable || 0}</b> 个 · 每页每天 <b>${cap.perPagePerDay || 2}</b> 条<br/>
      ${cap.days || 3} 天可容纳 <b>${cap.capacity || 0}</b> 条 · 队列有 <b>${cap.queueReady || 0}</b> 条<br/>
      <span style="color:${cap.enough ? 'var(--ok)' : 'var(--warn)'}">${cap.enough ? '容量充足' : `容量不足，超出 ${cap.overflow} 条`}</span>
    </div></div>`;
  const m = modal({
    title: '自动排期', width: 'wide', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '生成排期',
        onclick: async () => {
          try {
            const r = await api.autoplan({
              days: +body.querySelector('#ap-days').value,
              mode: body.querySelector('#ap-mode').value,
            });
            toast('已生成', `${r.created} 条排期${r.remaining ? `，剩 ${r.remaining} 条未排` : ''}`, 'ok');
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('失败', e.message, 'err', 6000); }
        },
      }),
    ],
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
