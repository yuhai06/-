/* 全局数据层：从后端拉真实数据，页面订阅变化 */
import { api } from './api.js';
import { toast } from './ui.js';

export const store = {
  loaded: false,
  loading: false,
  error: null,

  summary: {},
  pages: [],
  envs: [],
  videos: [],
  overview: { daily: [], byPage: [], topVideos: [], totals: {} },
  guard: { blocked: false, count: 0, byKind: {}, blockedEnvs: [], blockedPages: [] },
  guardEvents: [],
  jobs: [],
  library: [],
  queue: [],
  schedule: [],
  rules: {},
  mails: [],
  channels: [],
  integrations: [],
  models: [],
  skills: [],
  plugins: [],
  events: [],
  auto: null,

  _subs: new Set(),
  subscribe(fn) { this._subs.add(fn); return () => this._subs.delete(fn); },
  emit() { this._subs.forEach((f) => { try { f(this); } catch (e) { console.error(e); } }); },

  /* ---------------- 加载 ---------------- */
  async loadCore() {
    const [summary, pages, envs, guard] = await Promise.all([
      api.summary().catch(() => ({})),
      api.pages().then((d) => d.items || []).catch(() => []),
      api.envs().then((d) => d.items || []).catch(() => []),
      api.guardStatus().catch(() => ({ blocked: false, count: 0 })),
    ]);
    this.summary = summary;
    this.pages = pages;
    this.envs = envs;
    this.guard = guard;
    this.loaded = true;
    this.emit();
  },

  async loadOverview(days = 14) {
    try {
      const ov = await api.overview(days);
      this.overview = ov;
      // overview 里带 videoCount，同步进 summary，避免概览页显示 0
      this.summary = {
        ...this.summary,
        videoCount: ov.videoCount ?? (this.summary.videoCount || 0),
        totalViews: (ov.totals || {}).plays ?? this.summary.totalViews,
      };
    } catch (e) {
      console.warn('overview failed', e.message);
    }
    this.emit();
  },

  async loadVideos(params = {}) {
    try {
      const d = await api.videos(params);
      this.videos = d.items || [];
    } catch (e) {
      console.warn('videos failed', e.message);
      this.videos = [];
    }
    this.emit();
    return this.videos;
  },

  async loadGuard() {
    try {
      const [st, ev] = await Promise.all([
        api.guardStatus(),
        api.guardEvents(true).catch(() => ({ items: [] })),
      ]);
      this.guard = st;
      this.guardEvents = ev.items || [];
    } catch (e) {
      console.warn('guard failed', e.message);
    }
    this.emit();
    return this.guard;
  },

  async loadAuto() {
    try {
      this.auto = await api.autoStatus();
    } catch (e) {
      console.warn('auto failed', e.message);
      this.auto = null;
    }
    this.emit();
    return this.auto;
  },

  async loadJobs() {
    try {
      const d = await api.jobs({ limit: 40 });
      this.jobs = d.items || [];
    } catch (e) { this.jobs = []; }
    this.emit();
    return this.jobs;
  },

  async loadLibrary(params = {}) {
    try {
      const d = await api.library(params);
      this.library = d.items || [];
      this.dramaTypes = d.types || {};
    } catch (e) { this.library = []; }
    this.emit();
    return this.library;
  },

  async loadQueue() {
    try {
      const d = await api.queue();
      this.queue = d.items || [];
      this.queueMix = this.queue.filter((x) => x.kind === 'mix');
    } catch (e) { this.queue = []; this.queueMix = []; }
    this.emit();
    return this.queue;
  },

  async loadSchedule() {
    try {
      const d = await api.schedule();
      this.schedule = d.items || [];
      this.rules = d.rules || {};
    } catch (e) { this.schedule = []; }
    this.emit();
    return this.schedule;
  },

  async loadMail(params = {}) {
    try {
      const [m, ch] = await Promise.all([
        api.mails({ limit: params.limit || 100, onlyCode: params.onlyCode }),
        api.mailChannels().catch(() => ({ items: [] })),
      ]);
      this.mails = m.items || [];
      this.mailStats = m.stats || {};
      this.channels = ch.items || [];
    } catch (e) { this.mails = []; this.channels = []; }
    this.emit();
  },

  async loadIntegrations() {
    try {
      const [i, mo, sk, pl] = await Promise.all([
        api.integrations().catch(() => ({ items: [] })),
        api.models().catch(() => ({ items: [] })),
        api.skills().catch(() => ({ items: [] })),
        api.plugins().catch(() => ({ items: [] })),
      ]);
      this.integrations = i.items || [];
      this.models = mo.items || [];
      this.skills = sk.items || [];
      this.plugins = pl.items || [];
    } catch (e) { /* ignore */ }
    this.emit();
  },

  async loadEvents(limit = 200) {
    try {
      const d = await api.events(limit);
      this.events = d.items || [];
    } catch (e) { this.events = []; }
    this.emit();
  },
};

/* ---------------- 风控告警 ----------------
   任何页面拉到 tripped 都调这里：顶栏红色角标 + 弹窗，不允许静默。 */
let guardModalShown = false;

export function raiseGuard(verdict) {
  if (!verdict || !verdict.tripped) return;
  store.guard = {
    ...store.guard,
    blocked: true,
    count: (store.guard.count || 0) + 1,
    latest: verdict,
  };
  paintGuardBadge();
  showGuardModal(verdict);
}

export function paintGuardBadge() {
  const el = document.getElementById('chip-guard');
  if (!el) return;
  const n = store.guard.count || 0;
  if (n > 0) {
    el.style.display = '';
    el.className = 'chip alarm guard-pulse';
    el.innerHTML = `⚠ 风控 <b>${n}</b>`;
    el.title = store.guard.latest
      ? `${store.guard.latest.message || ''}`
      : '检测到风控信号，已熔断';
  } else {
    el.style.display = 'none';
  }
}

export function showGuardModal(v) {
  if (guardModalShown) return;
  guardModalShown = true;
  const root = document.getElementById('modal-root');
  const wrap = document.createElement('div');
  wrap.innerHTML = `
    <div class="modal" style="max-width:520px;border-color:rgba(248,113,113,.5)">
      <div class="modal-head" style="background:rgba(248,113,113,.08)">
        <h3 style="color:#f87171">⚠ 检测到风控信号，已自动熔断</h3>
      </div>
      <div class="modal-body">
        <div class="kv"><span class="k">类型</span><span class="v" style="color:#f87171">${v.kind}</span></div>
        <div class="kv"><span class="k">严重度</span><span class="v">${v.severity}</span></div>
        <div class="kv"><span class="k">熔断范围</span><span class="v">${v.scope === 'account' ? '该账号（整个环境停止）' : v.scope === 'page' ? '该主页' : '全局'}</span></div>
        <div class="kv"><span class="k">命中</span><span class="v">${(v.matched || '').slice(0, 60)}</span></div>
        <div style="margin-top:10px;font-size:11.5px;color:var(--tx-2);line-height:1.7">
          ${v.message || ''}<br/>
          <b>已停止所有后续操作</b>，不会继续碰这个${v.scope === 'page' ? '主页' : '账号'}。
          请到浏览器里人工确认并处理，处理完后在「风控」页解除熔断。
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn" data-x="close">知道了</button>
        <button class="btn primary" data-x="go">去风控页</button>
      </div>
    </div>`;
  root.appendChild(wrap);
  root.classList.add('on');
  const close = () => {
    wrap.remove();
    if (!root.children.length) root.classList.remove('on');
    guardModalShown = false;
  };
  wrap.querySelector('[data-x="close"]').onclick = close;
  wrap.querySelector('[data-x="go"]').onclick = () => {
    close();
    location.hash = '#/guard';
  };
  toast('风控熔断', v.message || v.kind, 'err', 6000);
}
