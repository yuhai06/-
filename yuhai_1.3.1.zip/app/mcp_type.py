# -*- coding: utf-8 -*-
"""mcp_type.py — 剧型工具（列出/判定/手动指定）"""
import json
import logging

log = logging.getLogger("yuhai.mcp.type")


def register(mcp):
    def _ok(**kw):
        return {"ok": True, **kw}

    def _err(msg, **kw):
        return {"ok": False, "error": msg, **kw}

    @mcp.tool(
        description="列出所有剧型，以及判定阈值。"
                    "共 7 种真实类型 + 1 种通用兜底")
    def drama_types() -> dict:
        try:
            from app.services import slicing as sl
            r = sl.list_types()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            # 退化：读 classify.py 常量
            try:
                import sys
                from app import paths
                td = paths.tools_dir()
                sys.path.insert(0, str(td))
                import classify as C
                return _ok(types=C.ALL_TYPES,
                           fallback=C.FALLBACK_TYPE,
                           threshold=C.MIN_RATE,
                           minHits=C.MIN_HITS,
                           note="7 种真实类型 + 通用兜底")
            except Exception as e2:
                return _err(f"列类型失败: {str(e)[:80]} / {str(e2)[:60]}")

    @mcp.tool(
        description=(
            "看某部剧被判成什么类型，以及各类型得分。"
            "如果 matched=false 说明没类型达标，用了通用兜底"))
    def drama_type_of(drama: str) -> dict:
        try:
            from app.services import slicing as sl
            r = sl.classify_drama(drama)
            if not r.get("ok"):
                return _err(r.get("error") or "判定失败", drama=drama)
            return _ok(drama=drama, type=r.get("type"),
                       matched=r.get("matched"),
                       fallback=r.get("fallback"),
                       bestScore=r.get("bestScore"),
                       threshold=r.get("threshold"),
                       suggestTop=r.get("suggestTop"),
                       note=r.get("note") or "")
        except Exception as e:
            return _err(f"判定失败: {str(e)[:130]}", drama=drama)

    @mcp.tool(
        description=(
            "手动指定某部剧的类型（覆盖自动判定）。"
            "typeName 传空字符串 = 取消指定。"
            "用于自动判定不达标时人工修正"))
    def drama_set_type(drama: str, type_name: str = "") -> dict:
        try:
            from app.services import slicing as sl
            r = sl.set_type_override(drama, type_name)
            return _ok(**r) if r.get("ok") else _err(
                r.get("error") or "设置失败", **{k: v for k, v in r.items()
                                              if k != "ok"})
        except Exception as e:
            return _err(f"设置失败: {str(e)[:130]}", drama=drama)

    @mcp.tool(
        description="列出所有剧的判定结果（哪些是兜底的、哪些没达标）")
    def drama_type_report(only_fallback: bool = False) -> dict:
        try:
            from app.services import slicing as sl
            items = sl.type_report()
            if only_fallback:
                items = [x for x in items if not x.get("matched")]
            fb = [x for x in items if not x.get("matched")]
            return _ok(total=len(items), fallbackCount=len(fb),
                       items=items)
        except Exception as e:
            return _err(f"生成报告失败: {str(e)[:130]}")


    @mcp.tool(
        description=(
            "用大模型判定剧型（比关键词准）。"
            "会自动抽台词样本（开头/中段/结尾），让模型按语义判断，"
            "而不是数关键词。"
            "apply=true 时把结果写进手动指定，后续切片直接用它"))
    def drama_judge_by_model(drama: str, apply: bool = False,
                             model: str = "") -> dict:
        from app.services import type_llm as tl
        try:
            r = tl.judge(drama, model, apply)
            return _ok(**r) if r.get("ok") else _err(
                r.get("error") or "判型失败", **{k: v for k, v in r.items()
                                            if k != "ok"})
        except Exception as e:
            return _err(f"判型失败: {str(e)[:130]}", drama=drama)

    @mcp.tool(
        description=(
            "批量用模型判型。onlyFallback=true 时只处理关键词判不出来的剧。"
            "apply=true 自动应用结果。会逐个跑，每部约 5-8 秒"))
    def drama_judge_batch(only_fallback: bool = True,
                          apply: bool = False, limit: int = 0) -> dict:
        from app.services import type_llm as tl
        from app.services import slicing as sl
        try:
            rep = sl.type_report()
            targets = [x for x in rep if x.get("drama")]
            if only_fallback:
                targets = [x for x in targets if not x.get("matched")]
            names = [x["drama"] for x in targets]
            if limit:
                names = names[:limit]
            if not names:
                return _ok(total=0, note="没有需要判型的剧")
            # 后台跑（避免 MCP 调用超时）
            import threading
            res = {"done": False, "total": len(names), "results": []}

            def worker():
                res["results"] = tl.judge_batch(names, "", apply, False)[
                    "results"]
                res["done"] = True

            th = threading.Thread(target=worker, daemon=True)
            th.start()
            th.join(timeout=60)
            if not res["done"]:
                return _ok(total=len(names), started=True,
                           note="已在后台判定，稍后用 drama_llm_pending 查")
            ok = [x for x in res["results"] if x.get("ok")]
            applied = [x for x in res["results"] if x.get("applied")]
            return _ok(total=len(names), success=len(ok),
                       applied=len(applied),
                       results=res["results"])
        except Exception as e:
            return _err(f"批量判型失败: {str(e)[:130]}")


    return mcp
