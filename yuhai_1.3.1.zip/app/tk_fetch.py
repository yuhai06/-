#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TikTok 短剧抓取（独立子进程）
用法: python tk_fetch.py <drama_id> [--wait 12] [--retries 3]
输出: 一行 JSON 到 stdout

双重策略（实盘验证）：
  ① 主路：拦截页面自己发的 /api/drama/detail + episode/item_list
  ② 兜底：接口被风控时，从 DOM 直接读剧名/集数/时长
     （页面往往还能渲染，接口却返回 Something went wrong）
"""
import io
import json
import sys
import time

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

DOM_JS = r"""() => {
  const out = {title: '', epCount: 0, cur: 0, dur: 0, w: 0, h: 0,
               bodyErr: false, videos: 0};
  const bodyTxt = document.body ? (document.body.innerText || '') : '';
  if (/Something went wrong|出错了/i.test(bodyTxt)) out.bodyErr = true;

  // 标题：h2 里排除「通知」
  const h2s = Array.from(document.querySelectorAll('h2'))
      .map(e => e.textContent.trim())
      .filter(t => t && t !== '通知' && t.length < 80);
  if (h2s.length) out.title = h2s[0];

  // 集数文案（观看全部 42 集 / 第 1 集）
  let m = bodyTxt.match(/观看全部\s*(\d+)\s*集/);
  if (m) out.epCount = +m[1];
  if (!out.epCount) {
    m = bodyTxt.match(/(\d+)\s*Episodes?/i);
    if (m) out.epCount = +m[1];
  }
  m = bodyTxt.match(/第\s*(\d+)\s*集/);
  if (m) out.cur = +m[1];

  const v = document.querySelector('video');
  if (v) {
    out.dur = Math.round(v.duration || 0);
    out.w = v.videoWidth || 0;
    out.h = v.videoHeight || 0;
  }
  out.videos = document.querySelectorAll('video').length;
  return out;
}"""


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "缺少 drama_id"}, ensure_ascii=False))
        return 1

    drama_id = sys.argv[1].strip()
    cdp = "http://127.0.0.1:9222"
    wait = 12
    retries = 3
    for i, a in enumerate(sys.argv):
        if a == "--cdp" and i + 1 < len(sys.argv):
            cdp = sys.argv[i + 1]
        elif a == "--wait" and i + 1 < len(sys.argv):
            wait = int(sys.argv[i + 1])
        elif a == "--retries" and i + 1 < len(sys.argv):
            retries = int(sys.argv[i + 1])

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print(json.dumps({"error": f"playwright 未安装: {e}"}, ensure_ascii=False))
        return 1

    target = f"https://www.tiktok.com/shortdrama/episode/{drama_id}/1"
    best = {"detail": None, "eps": [], "attempts": 0, "err": "", "dom": None}

    try:
        with sync_playwright() as pw:
            br = pw.chromium.connect_over_cdp(cdp, timeout=60000)
            ctx = br.contexts[0]
            _ = len(ctx.pages)

            for attempt in range(1, retries + 1):
                caught = {"d": None, "e": []}
                pg = None
                try:
                    pg = ctx.new_page()

                    def on_resp(r):
                        try:
                            u = r.url
                            if "/api/drama/detail/" in u and r.status == 200 and not caught["d"]:
                                t = r.text()
                                if len(t) > 500:
                                    caught["d"] = t
                            elif "/api/drama/episode/item_list/" in u and r.status == 200:
                                t = r.text()
                                if len(t) > 500:
                                    caught["e"].append(t)
                        except Exception:
                            pass

                    pg.on("response", on_resp)
                    pg.goto(target, wait_until="domcontentloaded", timeout=55000)
                    time.sleep(11)
                    if caught["d"] and not caught["e"]:
                        try:
                            pg.mouse.wheel(0, 800)
                        except Exception:
                            pass
                        time.sleep(7)
                    elif not caught["d"]:
                        time.sleep(7)
                except Exception as e:
                    best["err"] = repr(e)[:160]

                # 无论接口有没有，都试 DOM（兜底：接口坏了页面可能还在）
                if pg is not None:
                    try:
                        dm = pg.evaluate(DOM_JS)
                        if dm and (dm.get("title") or dm.get("epCount")):
                            best["dom"] = dm
                    except Exception:
                        pass

                dl = len(caught["d"] or "")
                el = len(caught["e"])
                best["attempts"] = attempt

                if dl > 500 and not best["detail"]:
                    best["detail"] = caught["d"]
                if el > 0:
                    best["eps"] = caught["e"]

                try:
                    if pg is not None:
                        pg.close()
                except Exception:
                    pass

                if dl > 500 and el > 0:
                    best["detail"] = caught["d"]
                    best["eps"] = caught["e"]
                    best["err"] = ""
                    break
                if attempt < retries:
                    time.sleep(5)
            try:
                br.close()
            except Exception:
                pass
    except Exception as e:
        best["err"] = repr(e)[:200]

    print(json.dumps(best, ensure_ascii=False))
    return 0 if (best["detail"] or best.get("dom")) else 2


if __name__ == "__main__":
    sys.exit(main())
