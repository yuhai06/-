# -*- coding: utf-8 -*-
"""mcp_mail.py — 邮箱通道操作的 MCP 工具"""
import json
import logging

log = logging.getLogger("yuhai.mcp.mail")


def _run_async(fn, *args, **kw):
    """在同步上下文里跑 async 函数。"""
    import asyncio
    import concurrent.futures
    try:
        return asyncio.run(fn(*args, **kw))
    except RuntimeError:
        with concurrent.futures.ThreadPoolExecutor() as ex:
            return ex.submit(lambda: asyncio.run(fn(*args, **kw))).result(
                timeout=120)


def register(mcp):
    """邮箱工具（配置/测试/拉取/验证码）。"""

    def _ok(**kw):
        return {"ok": True, **kw}

    def _err(msg, **kw):
        return {"ok": False, "error": msg, **kw}

    KINDS_INFO = {
        "imap": {
            "name": "IMAP 邮箱",
            "best_for": "QQ / 163 / 企业邮箱（最常用）",
            "fields": ["host", "port", "user", "password(授权码)"],
            "howto": [
                "登录邮箱网页版",
                "设置 → 账号 → 开启 IMAP 服务",
                "生成授权码（不是登录密码）",
                "填 host=imap.qq.com port=993 user=邮箱 password=授权码",
            ],
        },
        "gmail": {
            "name": "Gmail",
            "best_for": "Google 账号",
            "fields": ["user", "password(应用专用密码)"],
            "howto": [
                "myaccount.google.com/security 开启两步验证",
                "应用专用密码 → 选邮件 → 生成",
                "16 位字母去掉空格填进去",
            ],
        },
        "graph": {
            "name": "Microsoft Graph",
            "best_for": "Outlook / Hotmail",
            "fields": ["tenant", "clientId", "clientSecret", "user"],
            "howto": [
                "portal.azure.com 应用注册",
                "记下 租户ID / 应用ID",
                "证书和密码 → 新建客户端密码",
                "API 权限加 Mail.Read",
            ],
        },
        "webhook": {
            "name": "Webhook 转发",
            "best_for": "第三方服务转发",
            "fields": ["token"],
            "howto": [
                "定一个 Token",
                "第三方 POST 到 /api/mail/webhook/<token>",
            ],
        },
        "browser": {
            "name": "浏览器读取",
            "best_for": "已登录的网页邮箱",
            "fields": ["url", "envCode"],
            "howto": [
                "先在指纹浏览器登录邮箱",
                "填邮箱网址和环境编号",
            ],
        },
        "manual": {
            "name": "手动录入",
            "best_for": "不想配任何东西",
            "fields": [],
            "howto": ["收到验证码后手动填进系统"],
        },
    }

    @mcp.tool(description="看支持哪些邮箱接入方式，以及每种怎么配")
    def mail_kinds() -> dict:
        return _ok(count=len(KINDS_INFO),
                   items=[{"kind": k, "name": v["name"],
                           "bestFor": v["best_for"],
                           "fields": v["fields"],
                           "steps": v["howto"]}
                          for k, v in KINDS_INFO.items()])

    @mcp.tool(description="列已配置的邮箱通道（含是否启用）")
    def mail_channels() -> dict:
        from app.db import db
        rows = db.q("""SELECT id, kind, label, enabled, config,
                       updated_at FROM mail_accounts ORDER BY rowid DESC""")
        out = []
        for r in rows:
            cfg = {}
            try:
                cfg = json.loads(r.get("config") or "{}")
            except Exception:
                pass
            # 敏感字段只显示是否已填
            safe = {}
            for k, v in cfg.items():
                if k.lower() in ("password", "secret", "token", "clientsecret"):
                    safe[k] = "已填" if v else "未填"
                else:
                    safe[k] = v
            out.append({"id": r["id"], "kind": r.get("kind"),
                        "label": r.get("label"),
                        "enabled": bool(r.get("enabled")),
                        "config": safe,
                        "updatedAt": r.get("updated_at")})
        return _ok(count=len(out), items=out)

    @mcp.tool(
        description=(
            "新增邮箱通道。kind 见 mail_kinds；config 是 JSON 对象字符串。\n"
            '  imap 例子: {"host":"imap.qq.com","port":"993",'
            '"user":"xxx@qq.com","password":"授权码"}\n'
            '  gmail:     {"user":"xxx@gmail.com","password":"16位应用密码"}'))
    def mail_add_channel(kind: str, label: str,
                         config: str = "{}") -> dict:
        from app.db import db, now_iso
        import uuid
        try:
            cfg = config if isinstance(config, dict) else json.loads(config)
        except json.JSONDecodeError as e:
            return _err(f"config 不是合法 JSON: {str(e)[:60]}",
                        hint='格式如 {"host":"imap.qq.com","port":"993"}')
        if kind not in KINDS_INFO:
            return _err(f"不认识的 kind: {kind}",
                        supported=list(KINDS_INFO.keys()))
        need = [f for f in KINDS_INFO[kind]["fields"]
                if cfg.get(f.split("(")[0]) is None]
        if need and kind != "manual":
            return _err(f"缺字段: {', '.join(need)}",
                        hint="参考 mail_kinds 里的 fields")
        try:
            db.exec("""CREATE TABLE IF NOT EXISTS mail_accounts (
                id TEXT PRIMARY KEY, kind TEXT, label TEXT, enabled INTEGER,
                config TEXT, created_at TEXT, updated_at TEXT)""")
            cid = "mc-" + uuid.uuid4().hex[:8]
            now = now_iso()
            db.exec("""INSERT INTO mail_accounts
                (id, kind, label, enabled, config, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?)""",
                    (cid, kind, label, 1,
                     json.dumps(cfg, ensure_ascii=False), now, now))
            return _ok(id=cid, kind=kind, label=label,
                       note=f"已新增通道 {label}")
        except Exception as e:
            return _err(f"新增失败: {str(e)[:130]}")

    @mcp.tool(description="测试邮箱通道能否连上。传通道 id（用 mail_channels 查）")
    def mail_test_channel(channel_id: str) -> dict:
        import asyncio
        from app.api.mail import TestReq, test_channel
        try:
            r = _run_async(test_channel, TestReq(id=channel_id))
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"测试失败: {str(e)[:130]}")

    @mcp.tool(description="立即拉取邮件（从已配置的通道读验证码）")
    def mail_pull(channel_ids: str = "", since_minutes: int = 1440,
                  limit: int = 30) -> dict:
        from app.api.mail import PullReq, pull
        try:
            ids = ([x.strip() for x in channel_ids.split(",") if x.strip()]
                   if channel_ids else [])
            r = _run_async(pull, PullReq(channelIds=ids,
                                         sinceMinutes=since_minutes,
                                         limit=limit))
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"拉取失败: {str(e)[:130]}")

    @mcp.tool(description="最新一个验证码（发布/授权时用）")
    def mail_latest_code(mailbox: str = "") -> dict:
        from app.db import db
        if mailbox:
            r = db.q1("""SELECT * FROM mails WHERE mailbox=? AND code<>''
                         ORDER BY received_at DESC LIMIT 1""", (mailbox,))
        else:
            r = db.q1("""SELECT * FROM mails WHERE code<>''
                         ORDER BY received_at DESC LIMIT 1""")
        if not r:
            return _err("没有找到验证码", hint="先去拉取，或用 mail_manual")
        return _ok(id=r["id"], mailbox=r.get("mailbox"),
                   code=r.get("code"), subject=r.get("subject"),
                   at=r.get("received_at"),
                   source=r.get("source") or "manual")

    @mcp.tool(
        description=(
            "手动录入一个验证码（不接邮箱时用）。"
            "收到邮件后把 6-8 位数字填进来，系统会存成一条邮件记录"))
    def mail_manual(mailbox: str, code: str, note: str = "") -> dict:
        from app.db import db, now_iso
        import uuid
        try:
            if not code.strip():
                return _err("验证码不能为空")
            db.exec("""CREATE TABLE IF NOT EXISTS mails (
                id TEXT PRIMARY KEY, mailbox TEXT, subject TEXT,
                body TEXT, code TEXT, source TEXT, seen INTEGER,
                received_at TEXT)""")
            mid = "mail-" + uuid.uuid4().hex[:10]
            db.exec("""INSERT INTO mails
                (id, mailbox, subject, body, code, source, seen, received_at)
                VALUES (?,?,?,?,?,?,0,?)""",
                    (mid, mailbox or "manual@local",
                     note or "手动录入", "", code.strip(), "manual",
                     now_iso()))
            return _ok(id=mid, mailbox=mailbox, code=code.strip(),
                       note="已录入，发布/授权时能自动带上")
        except Exception as e:
            return _err(f"录入失败: {str(e)[:130]}")

    @mcp.tool(description="邮箱收件箱（最近收到的邮件和验证码）")
    def mail_inbox(limit: int = 30, only_code: bool = False) -> dict:
        from app.db import db
        try:
            if only_code:
                rows = db.q("""SELECT * FROM mails WHERE code<>''
                               ORDER BY received_at DESC LIMIT ?""", (limit,))
            else:
                rows = db.q("""SELECT * FROM mails
                               ORDER BY received_at DESC LIMIT ?""", (limit,))
            return _ok(count=len(rows), items=[
                {"id": r["id"], "mailbox": r.get("mailbox"),
                 "subject": (r.get("subject") or "")[:60],
                 "code": r.get("code") or "",
                 "source": r.get("source") or "",
                 "at": r.get("received_at")} for r in rows])
        except Exception as e:
            return _err(f"读取失败: {str(e)[:120]}")

    @mcp.tool(description="删掉一个邮箱通道")
    def mail_del_channel(channel_id: str) -> dict:
        from app.db import db
        db.exec("DELETE FROM mail_accounts WHERE id=?", (channel_id,))
        return _ok(deleted=channel_id)

    return mcp
