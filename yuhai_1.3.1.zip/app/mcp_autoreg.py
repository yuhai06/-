# -*- coding: utf-8 -*-
"""
mcp_autoreg.py — 从 OpenAPI 自动注册 MCP 工具

解决「加了新功能，Agent 怎么用」：
  新写一个 @router.get/@router.post 端点 → 重启服务 →
  自动变成 MCP 工具，Agent 立刻能用。

原理：
  FastAPI 自带 app.openapi()（247 个操作，含完整参数定义）
  → 每个操作生成带明确签名的 MCP 工具函数
  → 调用时直接调 endpoint 函数（不经 HTTP）

工具命名：<method>_<path>
  GET  /api/pages        → get_api_pages
  POST /api/pages/create → post_api_pages_create
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import inspect
import logging
import re
from typing import Any

log = logging.getLogger("yuhai.mcp.autoreg")


def _clean_name(method: str, path: str) -> str:
    p = path.strip("/")
    p = re.sub(r"[{}]", "", p)
    p = re.sub(r"[^A-Za-z0-9]+", "_", p)
    p = re.sub(r"_+", "_", p).strip("_")
    return (f"{method.lower()}_{p}")[:128]


def _run_async(coro):
    try:
        return asyncio.run(coro)
    except RuntimeError:
        with concurrent.futures.ThreadPoolExecutor() as ex:
            return ex.submit(asyncio.run, coro).result(timeout=300)


def _extract_params(op, spec):
    props: dict[str, Any] = {}
    required: list[str] = []

    for prm in (op.get("parameters") or []):
        n = prm.get("name")
        if not n:
            continue
        sch = prm.get("schema") or {}
        if "$ref" in sch:
            sch = {"type": "string"}
        props[n] = {
            "type": sch.get("type") or "string",
            "description": (prm.get("description") or "")[:120],
        }
        if sch.get("enum"):
            props[n]["enum"] = sch["enum"]
        if prm.get("required"):
            required.append(n)

    body = op.get("requestBody") or {}
    content = (body.get("content") or {}).get("application/json") or {}
    bs = content.get("schema") or {}
    body_model = None
    ref = bs.get("$ref")
    if ref:
        body_model = ref.split("/")[-1]
        sch2 = (spec.get("components", {}).get("schemas") or {}).get(
            body_model) or {}
        for k, v in (sch2.get("properties") or {}).items():
            props[k] = {
                "type": "object" if "$ref" in v else (v.get("type") or "string"),
                "description": (v.get("description") or "")[:120]}
        required += list(sch2.get("required") or [])
    else:
        for k, v in (bs.get("properties") or {}).items():
            props[k] = {
                "type": "object" if "$ref" in v else (v.get("type") or "string"),
                "description": (v.get("description") or "")[:120]}
        required += list(bs.get("required") or [])

    return props, required, body_model


# ═══════════════════════════════════════════
#  执行器（所有动态工具共用这一份逻辑）
# ═══════════════════════════════════════════
def _build_runner(fn, path_params, body_fields, body_model):
    """返回一个接收 kwargs 的执行函数。"""

    def run(_alias=None, **kw):
        # 还原别名（from/to 等关键字）
        if _alias:
            for safe, real in _alias.items():
                if kw.get(safe) is not None:
                    kw[real] = kw.pop(safe)
        clean = {k: v for k, v in kw.items() if v is not None and v != ""}
        call, bodyextra = {}, {}
        for k, v in clean.items():
            if k in path_params:
                call[k] = v
            elif k in body_fields:
                bodyextra[k] = v
            else:
                call[k] = v

        # 构造 pydantic body
        if body_model and bodyextra:
            cls = _find_model(fn, body_model)
            if cls is not None:
                sig = inspect.signature(fn)
                bname = None
                for pname, prm in sig.parameters.items():
                    ann = prm.annotation
                    if ann == cls or hasattr(ann, "model_fields"):
                        bname = pname
                        break
                if bname:
                    try:
                        call[bname] = cls(**bodyextra)
                    except Exception as e:
                        return {"ok": False,
                                "error": f"body 校验失败: {str(e)[:130]}",
                                "schema": list(bodyextra.keys())}
                else:
                    call.update(bodyextra)

        # 清理 FastAPI 的 Query/Path/Body 包装（否则参数绑定失败）
        sig0 = inspect.signature(fn)
        accepted0 = list(sig0.parameters.keys())
        try:
            from fastapi.params import Query, Path as FPath, Body
            for pname, prm in sig0.parameters.items():
                dv = prm.default
                if isinstance(dv, (Query, FPath, Body)):
                    real = getattr(dv, "default", None)
                    if real is not None and real is not Ellipsis:
                        if pname not in call:
                            call[pname] = real
        except Exception:
            pass

        # 参数名模糊匹配：OpenAPI 的 from → 函数的 from_
        for k in list(call.keys()):
            if k in accepted0:
                continue
            for cand in (k + "_", k.rstrip("_"), k.lower()):
                if cand in accepted0:
                    call[cand] = call.pop(k)
                    break

        # 只保留函数真正接受的参数
        sig = inspect.signature(fn)
        accepted = set(sig.parameters.keys())
        call = {k: v for k, v in call.items() if k in accepted}

        try:
            r = fn(**call)
            if inspect.isawaitable(r):
                r = _run_async(r)
            return r
        except TypeError as e:
            # 参数不匹配：尝试只用路径参数
            try:
                minimal = {k: v for k, v in call.items()
                           if k in path_params and v}
                r = fn(**minimal)
                if inspect.isawaitable(r):
                    r = _run_async(r)
                return r
            except Exception:
                return {"ok": False,
                        "error": f"参数不匹配: {str(e)[:130]}",
                        "accepted": sorted(accepted),
                        "got": sorted(call.keys())}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {str(e)[:150]}"}

    return run


def _find_model(fn, model_name):
    mod = getattr(fn, "__module__", "")
    for cand in (mod, "app.api." + mod.split(".")[-1]):
        try:
            m = __import__(cand, fromlist=[model_name])
            cls = getattr(m, model_name, None)
            if cls is not None:
                return cls
        except Exception:
            continue
    try:
        for prm in inspect.signature(fn).parameters.values():
            if hasattr(prm.annotation, "model_fields"):
                return prm.annotation
    except Exception:
        pass
    return None


def _walk_routes(routes, prefix="", _depth=0):
    """递归展开路由树。

    FastAPI 新版把 include_router 的路由包在 _IncludedRouter 里，
    真正的路由在 .original_router.routes。
    """
    from fastapi.routing import APIRoute
    if _depth > 6:
        return {}
    out = {}
    for r in routes:
        if isinstance(r, APIRoute):
            path = getattr(r, "path", "")
            methods = getattr(r, "methods", None) or set()
            fn = getattr(r, "endpoint", None)
            if path and fn:
                for m in methods:
                    out[(m.upper(), path)] = fn
            continue

        # _IncludedRouter → original_router.routes
        orig = getattr(r, "original_router", None)
        if orig is not None:
            inc = getattr(r, "include_context", None)
            pre = ""
            for attr in ("prefix", "path_prefix"):
                if inc is not None:
                    pv = getattr(inc, attr, None)
                    if isinstance(pv, str):
                        pre = pv
                        break
            sr = getattr(orig, "routes", None) or []
            sub = _walk_routes(sr, pre, _depth + 1)
            for (m, p), fn in sub.items():
                out[(m, p)] = fn
            continue

        # 普通容器
        sub = getattr(r, "routes", None)
        if sub:
            sub_map = _walk_routes(sub, prefix, _depth + 1)
            for (m, p), fn in sub_map.items():
                out[(m, p)] = fn
            continue
        router = getattr(r, "router", None)
        if router is not None:
            sr = getattr(router, "routes", None) or []
            sub_map = _walk_routes(sr, prefix, _depth + 1)
            for (m, p), fn in sub_map.items():
                out[(m, p)] = fn
    return out


def register_all(app, mcp, skip_prefixes=None, skip_names=None):
    spec = app.openapi()
    paths = spec.get("paths") or {}
    schemas = spec.get("components", {}).get("schemas") or {}
    skip_prefixes = list(skip_prefixes or [])
    skip_names = set(skip_names or [])

    try:
        existing = _run_async(mcp.list_tools())
        skip_names |= {t.name for t in existing}
    except Exception:
        pass

    # 递归展开所有路由（关键：include_router 的包在容器里）
    route_map = _walk_routes(app.routes)
    log.info("autoreg: 展开路由 %d 条", len(route_map))

    registered, skipped = [], []

    for path, ops in paths.items():
        if any(path.startswith(p) for p in skip_prefixes):
            continue
        for method, op in ops.items():
            method = method.upper()
            if method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                continue
            name = _clean_name(method, path)
            if name in skip_names:
                skipped.append(name)
                continue
            fn = route_map.get((method, path))
            if fn is None:
                # 路由表里的路径通常不带 include_router 的 prefix
                # （如 /api/envs 在 route 里是 /envs），两种都试
                variants = []
                if path.startswith("/api/"):
                    variants.append(path[4:])          # /api/envs → /envs
                    variants.append(path[5:])          # /api/envs → envs
                else:
                    variants.append("/api" + path)
                for v in variants:
                    fn = route_map.get((method, v))
                    if fn is not None:
                        break
            if fn is None:
                continue

            props, required, body_model = _extract_params(op, spec)
            desc = (op.get("summary") or "").strip()
            if not desc:
                desc = (fn.__doc__ or "").strip().split("\n")[0]
            desc = (desc or f"{method} {path}")[:280]

            path_params = set(re.findall(r"{(\w+)}", path))
            body_fields = set()
            if body_model:
                sch = schemas.get(body_model) or {}
                body_fields = set((sch.get("properties") or {}).keys())

            # 只保留合法标识符，且不能是 Python 关键字（from/to/class 等）
            import keyword
            arg_names = [k for k in props.keys()
                         if k.isidentifier()
                         and not keyword.iskeyword(k)
                         and k not in ("self", "cls")]

            runner = _build_runner(fn, path_params, body_fields, body_model)

            # 用 exec 生成带明确签名的函数（MCP 从签名读 schema）
            # ⚠️ 不能用 **kwargs：MCP 会把 kwargs 当成必填字段，全部报错
            # ⚠️ 参数名不能以下划线开头（MCP 拒绝）
            # Python 关键字（from/to/class）用 p_ 前缀别名，调用时还原
            import keyword as _kwmod
            py_names, alias = [], {}
            for k in props.keys():
                if not k.isidentifier() or k in ("self", "cls"):
                    continue
                if _kwmod.iskeyword(k):
                    safe = "p_" + k
                    alias[safe] = k
                    py_names.append(safe)
                else:
                    py_names.append(k)

            if py_names:
                sig_src = ", ".join("%s=None" % p for p in py_names)
                args_src = ", ".join("%s=%s" % (p, p) for p in py_names)
                src = (f"def {name}({sig_src}):\n"
                       f"    return _runner({args_src}, _alias={alias!r})\n")
            else:
                src = (f"def {name}():\n"
                       f"    return _runner(_alias={alias!r})\n")
            ns = {"_runner": runner}
            try:
                exec(src, ns)
                tool_fn = ns[name]
            except Exception as e:
                log.warning("生成 %s 失败: %s", name, e)
                continue

            tool_fn.__doc__ = desc
            try:
                mcp.add_tool(tool_fn, name=name, description=desc)
                registered.append(name)
            except Exception as e:
                # 打完整错误，别吞
                import traceback
                log.warning("注册 %s 失败: %s", name, e)
                log.debug("详情: %s", traceback.format_exc()[-500:])
                skipped.append(name + "(add失败:" + str(e)[:60] + ")")
            continue

    log.info("autoreg: 注册 %d 个，跳过 %d 个",
             len(registered), len(skipped))
    return {"registered": registered, "skipped": skipped}
