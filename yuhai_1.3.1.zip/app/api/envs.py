"""指纹浏览器环境 API。"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel

from app.adapters import hubstudio as hs
from app.adapters.hubstudio import hub, HubstudioError
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.api.envs")
router = APIRouter(tags=["envs"])


def _row_to_env(r: dict) -> dict:
    return {
        "containerCode": r["container_code"],
        "containerId": r["container_id"],
        "name": r["name"],
        "role": r["role"],
        "roleLabel": {"publisher": "发布号", "backup": "备份号"}.get(r["role"], "备用"),
        "account": r["account"],
        "cUser": r["c_user"],
        "displayName": r["display_name"],
        "profileDir": r["profile_dir"],
        "status": r["status"],
        "pid": r["pid"],
        "cdpPort": r["cdp_port"],
        "proxyType": r["proxy_type"],
        "proxyHost": r["proxy_host"],
        "proxyPort": r["proxy_port"],
        "proxyKind": r["proxy_kind"],
        "egressIp": r["egress_ip"],
        "egressCountry": r["egress_country"],
        "kernel": r["kernel"],
        "loginValid": None if r["login_valid"] is None else bool(r["login_valid"]),
        "lastChecked": r["last_checked"],
        "pagesFound": db.q1("SELECT COUNT(*) c FROM pages WHERE env_code=?", (r["container_code"],))["c"],
    }


@router.get("/envs")
async def list_envs(refresh: bool = False, include_removed: bool = False):
    if refresh:
        envs = await sync_envs()
    else:
        where = "" if include_removed else " WHERE status<>'removed'"
        rows = db.q("SELECT * FROM envs" + where + " ORDER BY role='spare', name")
        if not rows:
            envs = await sync_envs()
        else:
            envs = [_row_to_env(r) for r in rows]
    return {"items": envs}


async def sync_envs() -> list[dict]:
    try:
        raw = await hub.collect()
    except HubstudioError as e:
        db.log_event("err", "env", str(e))
        rows = db.q("SELECT * FROM envs WHERE status<>'removed' ORDER BY role='spare', name")
        return [_row_to_env(r) for r in rows]

    enriched = []
    for info in raw:
        try:
            enriched.append(await hs.enrich(info))
        except Exception as e:
            log.debug("enrich %s failed: %s", info.container_code, e)
            enriched.append(info)
    await hs.dump_to_db(enriched)
    rows = db.q("SELECT * FROM envs WHERE status<>'removed' ORDER BY role='spare', name")
    return [_row_to_env(r) for r in rows]


@router.get("/envs/status")
async def env_status():
    try:
        st = await hub.status()
    except HubstudioError as e:
        return {"ok": False, "error": str(e), "containers": []}
    return {"ok": True, "containers": [
        {"containerCode": k, **v} for k, v in st.items()]}


# ---------------- 环境同步（增删） ----------------
@router.post("/envs/sync")
async def sync_envs_api():
    """从 Hubstudio 重新拉环境清单。

    新增的入库、消失的标记 removed（不硬删，保留主页归属）。
    """
    try:
        raw = await hub.collect()
    except HubstudioError as e:
        raise HTTPException(500, str(e))

    live_codes = set()
    added, updated = 0, 0
    for info in raw:
        try:
            info = await hs.enrich(info)
        except Exception:
            pass
        live_codes.add(info.container_code)
        exists = db.q1("SELECT 1 FROM envs WHERE container_code=?",
                       (info.container_code,))
        await hs.dump_to_db([info])
        if exists:
            updated += 1
        else:
            added += 1
            db.log_event("ok", "env",
                         f"新增环境 {info.name}（{info.container_code}）")

    # 库里存在但 Hubstudio 已没有的 → 标记 removed
    removed = []
    for row in db.q("SELECT container_code,name FROM envs WHERE status<>'removed'"):
        code = row["container_code"]
        if code not in live_codes:
            db.exec("UPDATE envs SET status='removed', updated_at=? "
                    "WHERE container_code=?", (now_iso(), code))
            removed.append({"code": code, "name": row["name"]})
            db.log_event("warn", "env",
                         f"环境 {row['name']}（{code}）已不在 Hubstudio 中，标记移除")

    rows = db.q("SELECT * FROM envs WHERE status<>'removed' ORDER BY role='spare', name")
    return {"ok": True, "added": added, "updated": updated,
            "removed": removed, "items": [_row_to_env(r) for r in rows]}


@router.delete("/envs/{code}")
async def delete_env(code: str, hard: bool = False):
    """从台账移除环境。

    hard=False（默认）：标记 removed，保留主页归属记录
    hard=True：真删该环境记录（主页的 env_code 置空）
    """
    r = db.q1("SELECT * FROM envs WHERE container_code=?", (code,))
    if not r:
        raise HTTPException(404, "环境不存在")
    if r["status"] == "running":
        raise HTTPException(400, "环境还在运行，先关闭再移除")
    if hard:
        db.exec("UPDATE pages SET env_code=NULL WHERE env_code=?", (code,))
        db.exec("DELETE FROM envs WHERE container_code=?", (code,))
        db.log_event("warn", "env", f"硬删除环境 {r['name']}（{code}）")
    else:
        db.exec("UPDATE envs SET status='removed', updated_at=? WHERE container_code=?",
                (now_iso(), code))
        db.log_event("warn", "env", f"移除环境 {r['name']}（{code}）")
    return {"ok": True, "hard": hard}


@router.post("/envs/{code}/restore")
async def restore_env(code: str):
    """把标记 removed 的环境恢复回来（它重新出现在 Hubstudio 里时用）。"""
    r = db.q1("SELECT * FROM envs WHERE container_code=?", (code,))
    if not r:
        raise HTTPException(404, "环境不存在")
    db.exec("UPDATE envs SET status='closed', updated_at=? WHERE container_code=?",
            (now_iso(), code))
    return {"ok": True}


# ---------------- 版本/兼容性自检 ----------------
@router.get("/envs/health")
async def env_health():
    """检查 Hubstudio 是否升级导致 API 变化、还能不能连上。

    返回每个关键接口的可用性。任何一项 False 都会在设置页显示告警。
    """
    try:
        v = await hub.version()
    except Exception as e:
        return {"ok": False, "error": str(e), "api": "http://127.0.0.1:6873"}
    # 交叉检查：库里记为 running 的，在 Hubstudio 里是否真在运行
    drifted = []
    try:
        st = await hub.status()
        live = set(st.keys())
        for row in db.q("SELECT container_code,name,status FROM envs "
                        "WHERE status='running'"):
            if row["container_code"] not in live:
                drifted.append({"code": row["container_code"],
                                "name": row["name"],
                                "issue": "库里记为运行中，Hubstudio 已不在运行"})
        for code in live:
            r = db.q1("SELECT name FROM envs WHERE container_code=?", (code,))
            if not r:
                drifted.append({"code": code, "name": "（库中无记录）",
                                "issue": "Hubstudio 有但台账没有，需同步"})
    except Exception as e:
        v["error"] = str(e)

    v["drifted"] = drifted
    v["endpoint"] = "http://127.0.0.1:6873"
    v["ok"] = v.get("envListOk") and v.get("statusOk")
    return v


# ---------------- 一键转移 ----------------
class MigrateReq(BaseModel):
    fromEnv: str
    toEnv: str
    pageIds: list[str] = []
    moveAllPages: bool = False
    moveAccounts: bool = True
    dryRun: bool = False


@router.post("/envs/migrate")
async def migrate(req: MigrateReq):
    """把一个环境的台账资产一键转移到另一个环境。

    转移内容：
        · 主页归属（pages.env_code）
        · 号绑定（accounts.env_code）
    不触碰浏览器里的登录态（那是 Hubstudio 侧的 cookie，无法通过 API 搬）。
    """
    src = db.q1("SELECT * FROM envs WHERE container_code=?", (req.fromEnv,))
    dst = db.q1("SELECT * FROM envs WHERE container_code=?", (req.toEnv,))
    if not src:
        raise HTTPException(404, f"源环境不存在: {req.fromEnv}")
    if not dst:
        raise HTTPException(404, f"目标环境不存在: {req.toEnv}")
    if req.fromEnv == req.toEnv:
        raise HTTPException(400, "源和目标不能相同")

    # 待转移的主页
    if req.moveAllPages:
        page_rows = db.q("SELECT page_id,name FROM pages WHERE env_code=?",
                         (req.fromEnv,))
    else:
        if not req.pageIds:
            raise HTTPException(400, "pageIds 或 moveAllPages 必须给一个")
        marks = ",".join("?" * len(req.pageIds))
        page_rows = db.q(f"SELECT page_id,name FROM pages WHERE page_id IN ({marks})",
                         tuple(req.pageIds))

    acc_rows = db.q("SELECT id,label FROM accounts WHERE env_code=?",
                    (req.fromEnv,)) if req.moveAccounts else []

    plan = {
        "from": {"code": src["container_code"], "name": src["name"]},
        "to": {"code": dst["container_code"], "name": dst["name"]},
        "pages": [{"pageId": p["page_id"], "name": p["name"]} for p in page_rows],
        "accounts": [{"id": a["id"], "label": a["label"]} for a in acc_rows],
        "note": "只转移台账归属；浏览器登录态（cookie）在 Hubstudio 侧，需人工确认",
    }
    if req.dryRun:
        return {"ok": True, "dryRun": True, "plan": plan}

    n_p, n_a = 0, 0
    for p in page_rows:
        db.exec("UPDATE pages SET env_code=? WHERE page_id=?",
                (req.toEnv, p["page_id"]))
        n_p += 1
    for a in acc_rows:
        db.exec("UPDATE accounts SET env_code=? WHERE id=?",
                (req.toEnv, a["id"]))
        n_a += 1

    db.log_event("ok", "env",
                 f"转移 {src['name']} → {dst['name']}："
                 f"{n_p} 个主页、{n_a} 个号")
    return {"ok": True, "pages": n_p, "accounts": n_a, "plan": plan}


# ---------------- 创建环境 ----------------
class CreateEnvReq(BaseModel):
    name: str
    proxyType: str = "Socks5"
    proxyServer: str = ""
    proxyPort: int = 0
    proxyAccount: str = ""
    proxyPassword: str = ""
    remark: str = ""
    # 可选：建好后按某个已有环境克隆代理设置
    cloneProxyFrom: str = ""
    syncAfter: bool = True


@router.post("/envs/create")
async def create_env(req: CreateEnvReq):
    """在 Hubstudio 里创建新环境。"""
    server = req.proxyServer.strip()
    port = req.proxyPort
    ptype = req.proxyType.strip() or "Socks5"
    account = req.proxyAccount
    password = req.proxyPassword

    # 从已有环境克隆代理
    if req.cloneProxyFrom:
        src = await hub.env_list()
        hit = next((e for e in src
                    if str(e.get("containerCode")) == req.cloneProxyFrom), None)
        if not hit:
            raise HTTPException(404, "cloneProxyFrom 环境不存在")
        server = hit.get("proxyHost") or hit.get("proxyServer") or ""
        port = int(hit.get("proxyPort") or 0)
        ptype = hit.get("proxyTypeName") or ptype
        account = hit.get("proxyAccount") or account
        password = hit.get("proxyPassword") or password

    if not server:
        raise HTTPException(400, "代理主机不能为空（Hubstudio 必填）。"
                                 "可从已有环境克隆，或手填")

    try:
        data = await hub.create_env(req.name, ptype, server, port,
                                    account, password, req.remark)
    except HubstudioError as e:
        raise HTTPException(400, str(e))

    # 新建环境的 containerCode 在 data.containerCode 或 data 本身
    code = None
    d = data.get("data")
    if isinstance(d, dict):
        code = d.get("containerCode") or d.get("id")
    elif isinstance(d, (int, str)):
        code = d
    if not code:
        # 兜底：按名字回查
        try:
            envs = await hub.env_list()
            hit = next((e for e in envs
                        if e.get("containerName") == req.name.strip()), None)
            if hit:
                code = hit.get("containerCode")
        except Exception:
            pass

    out = {"ok": True, "containerCode": code, "name": req.name,
           "proxy": f"{ptype}://{server}:{port}"}

    if req.syncAfter:
        try:
            await sync_envs()
            out["synced"] = True
        except Exception as e:
            out["synced"] = False
            out["syncError"] = str(e)[:200]

    db.log_event("ok", "env", f"创建环境 {req.name}（{code}）")
    return out


# ---------------- 删除环境（Hubstudio 侧真删） ----------------
class DeleteEnvReq(BaseModel):
    codes: list[str]
    alsoLocal: bool = True


@router.post("/envs/delete-remote")
async def delete_remote(req: DeleteEnvReq):
    """在 Hubstudio 里真删环境（不可恢复），并同步台账。"""
    if not req.codes:
        raise HTTPException(400, "codes 为空")
    # 运行中的先拒
    for code in req.codes:
        r = db.q1("SELECT status,name FROM envs WHERE container_code=?", (code,))
        if r and r["status"] == "running":
            raise HTTPException(400, f"环境 {r['name']} 正在运行，先关闭再删")
    try:
        await hub.delete_env(req.codes)
    except HubstudioError as e:
        raise HTTPException(400, str(e))
    if req.alsoLocal:
        for code in req.codes:
            db.exec("UPDATE pages SET env_code=NULL WHERE env_code=?", (code,))
            db.exec("DELETE FROM envs WHERE container_code=?", (code,))
    db.log_event("warn", "env", f"Hubstudio 删除环境 {len(req.codes)} 个")
    return {"ok": True, "deleted": len(req.codes)}


class StartReq(BaseModel):
    containerCode: str


@router.post("/envs/{code}/proxy")
async def set_env_proxy(code: str, req: dict):
    """修改环境代理。

    字段与创建一致：proxyTypeName / proxyServer / proxyPort /
    proxyAccount / proxyPassword。
    """
    env = db.q1("SELECT * FROM envs WHERE container_code=?", (code,))
    if not env:
        raise HTTPException(404, "环境不存在")
    if env["status"] == "running":
        raise HTTPException(400, "环境正在运行，先关闭再改代理")

    ptype = (req.get("proxyType") or req.get("proxyTypeName") or "Socks5").strip()
    server = (req.get("proxyServer") or "").strip()
    if not server:
        raise HTTPException(400, "代理主机不能为空")

    body = {
        "proxyTypeName": ptype,
        "proxyServer": server,
        "proxyPort": int(req.get("proxyPort") or 0),
    }
    for k in ("proxyAccount", "proxyPassword"):
        v = (req.get(k) or "").strip()
        if v:
            body[k] = v

    try:
        await hub.modify_env(code, **body)
    except HubstudioError as e:
        raise HTTPException(400, str(e))

    # 同步台账
    db.exec("UPDATE envs SET proxy_host=?, proxy_port=?, updated_at=? "
            "WHERE container_code=?",
            (server, body["proxyPort"], now_iso(), code))
    db.log_event("ok", "env", f"修改 {env['name']} 代理 → {ptype}://{server}:{body['proxyPort']}")
    return {"ok": True, "proxy": f"{ptype}://{server}:{body['proxyPort']}"}


@router.post("/envs/{code}/proxy/clone")
async def clone_env_proxy(code: str, fromCode: str = ""):
    """从另一个环境克隆代理设置到目标环境。"""
    if not fromCode:
        raise HTTPException(400, "fromCode 不能为空")
    target = db.q1("SELECT * FROM envs WHERE container_code=?", (code,))
    if not target:
        raise HTTPException(404, "目标环境不存在")
    if target["status"] == "running":
        raise HTTPException(400, "目标环境正在运行，先关闭")

    try:
        envs = await hub.env_list()
    except HubstudioError as e:
        raise HTTPException(500, str(e))
    src = next((e for e in envs if str(e.get("containerCode")) == fromCode), None)
    if not src:
        raise HTTPException(404, "源环境不存在")

    body = {
        "proxyTypeName": src.get("proxyTypeName") or "Socks5",
        "proxyServer": src.get("proxyHost") or src.get("proxyServer") or "",
        "proxyPort": int(src.get("proxyPort") or 0),
    }
    if src.get("proxyAccount"):
        body["proxyAccount"] = src["proxyAccount"]
    if src.get("proxyPassword"):
        body["proxyPassword"] = src["proxyPassword"]
    if not body["proxyServer"]:
        raise HTTPException(400, "源环境没有代理信息")

    try:
        await hub.modify_env(code, **body)
    except HubstudioError as e:
        raise HTTPException(400, str(e))

    db.exec("UPDATE envs SET proxy_host=?, proxy_port=?, updated_at=? "
            "WHERE container_code=?",
            (body["proxyServer"], body["proxyPort"], now_iso(), code))
    db.log_event("ok", "env",
                 f"{target['name']} 代理克隆自 {src.get('containerName')}")
    return {"ok": True, "proxy": f"{body['proxyTypeName']}://{body['proxyServer']}:{body['proxyPort']}"}


@router.post("/envs/start")
async def start_env(req: StartReq):
    try:
        d = await hub.start(req.containerCode)
    except HubstudioError as e:
        db.log_event("err", "env", f"启动 {req.containerCode} 失败: {e}")
        raise HTTPException(500, str(e))
    port = int(d.get("debuggingPort") or 0)
    # 注意：API 返回的 containerId 不是进程 PID，必须按 CDP 端口反查真实 PID
    real_pid = await _pid_by_port(port)
    db.exec("UPDATE envs SET status='running', pid=?, cdp_port=?, updated_at=? "
            "WHERE container_code=?",
            (real_pid, port or None, now_iso(), req.containerCode))
    db.log_event("ok", "env", f"启动 {req.containerCode} → CDP {port} pid={real_pid}")
    return {"ok": True, "containerCode": req.containerCode,
            "cdpPort": port, "pid": real_pid}


async def _pid_by_port(port: int) -> int | None:
    """按 CDP 端口反查监听进程的真实 PID。"""
    if not port:
        return None
    import psutil
    try:
        for c in psutil.net_connections(kind="inet"):
            if c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == port and c.pid:
                return int(c.pid)
    except (psutil.AccessDenied, PermissionError):
        # 降级：用 netstat 解析
        try:
            r = proc.run(["netstat", "-ano", "-p", "TCP"],
                               capture_output=True, text=True, timeout=15,
                               encoding="utf-8", errors="replace")
            for line in (r.stdout or "").splitlines():
                parts = line.split()
                if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
                    return int(parts[4])
        except Exception:
            pass
    return None


@router.post("/envs/stop")
async def stop_env(req: StartReq):
    try:
        await hub.stop(req.containerCode)
    except HubstudioError as e:
        raise HTTPException(500, str(e))
    db.exec("UPDATE envs SET status='closed', pid=NULL, cdp_port=NULL, updated_at=? "
            "WHERE container_code=?", (now_iso(), req.containerCode))
    db.log_event("warn", "env", f"关闭 {req.containerCode}")
    return {"ok": True}


# ---------------- PID 反查 ----------------
@router.get("/envs/resolve-pid")
async def resolve_pid(pid: int = 0, port: int = 0):
    """PID → 端口 / CDP / 所属环境；也支持直接给 CDP 端口。

    这是「按 PID 提取主页」的第一步。
    """
    info: dict[str, Any] = {"pid": pid, "port": port,
                            "listeningPorts": [], "cdp": None, "env": None}
    if not pid and not port:
        return {"ok": False, "error": "需要 pid 或 port", **info}

    if pid and not port:
        ports = hub.listening_ports(pid)
        info["listeningPorts"] = ports
        if not ports:
            return {"ok": False,
                    "error": "该 PID 没有监听端口（containerId 不是进程 PID，请改用 port 参数）",
                    **info}
        cdp = await hub.resolve_cdp(pid)
    else:
        cdp = await hub.probe_cdp(port)

    if not cdp:
        return {"ok": False, "error": "未发现 Chromium CDP", **info}
    info["cdp"] = cdp
    info["pid"] = pid or await _pid_by_port(port)
    info["port"] = cdp["port"]

    env = await hub.find_env_by_pid(info["pid"]) if info["pid"] else None
    if not env:
        # 按 CDP 端口在库里匹配
        row = db.q1("SELECT * FROM envs WHERE cdp_port=?", (cdp["port"],))
        if row:
            info["env"] = _row_to_env(row)
    else:
        row = db.q1("SELECT * FROM envs WHERE container_code=?", (env["container_code"],))
        info["env"] = _row_to_env(row) if row else env
    return {"ok": True, **info}


@router.get("/envs/probe-ports")
async def probe_ports():
    """扫描所有 hubstudio.exe 进程并找 CDP。"""
    import psutil
    found = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            nm = (p.info.get("name") or "").lower()
            if "hubstudio" not in nm and "chrome" not in nm:
                continue
            pid = p.info["pid"]
            ports = hub.listening_ports(pid)
            if not ports:
                continue
            cdp = await hub.resolve_cdp(pid)
            if cdp:
                found.append({"pid": pid, "name": p.info.get("name"),
                              "port": cdp["port"], "browser": cdp.get("Browser")})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return {"ok": True, "items": found}


# ---------------- 单个环境 ----------------
@router.get("/envs/{code}")
async def env_detail(code: str):
    r = db.q1("SELECT * FROM envs WHERE container_code=?", (code,))
    if not r:
        raise HTTPException(404, "环境不存在")
    d = _row_to_env(r)
    d["pages"] = db.q("SELECT page_id,asset_id,name,health FROM pages WHERE env_code=?", (code,))
    return d


class ProxyTestReq(BaseModel):
    host: str
    port: int
    kind: str = "socks5"


@router.post("/envs/test-proxy")
async def test_proxy(req: ProxyTestReq):
    """用代理拉 ipinfo，顺带判定机房 / 住宅。"""
    import httpx
    scheme = "socks5" if req.kind.lower().startswith("socks") else "http"
    proxy = f"{scheme}://{req.host}:{req.port}"
    try:
        async with httpx.AsyncClient(proxy=proxy, timeout=15) as c:
            r = await c.get("https://ipinfo.io/json")
        d = r.json()
    except Exception as e:
        return {"ok": False, "error": f"代理不通: {str(e)[:120]}"}
    org = (d.get("org") or "").lower()
    datacenter_hints = ("cloudflare", "amazon", "google", "microsoft", "digitalocean",
                        "linode", "vultr", "ovh", "hetzner", "alibaba", "tencent",
                        "leaseweb", "contabo", "choopa", "m247")
    kind = "datacenter" if any(h in org for h in datacenter_hints) else "residential"
    return {"ok": True, "ip": d.get("ip"), "country": d.get("country"),
            "city": d.get("city"), "org": d.get("org"), "kind": kind}
