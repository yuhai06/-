"""播放量 API：从 Business Suite 主页成效分析采集，按主页按天入库。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import date, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.adapters.facebook import FB, FBError
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.insights")
router = APIRouter(tags=["insights"])

# 成效分析页的数字提取：Meta 用「1.2万」「3,456」混合格式
NUM_JS = r"""
(() => {
  const pick = (re) => {
    const body = document.body ? document.body.innerText : '';
    const m = body.match(re);
    return m ? m[1] : null;
  };
  const parseCN = (s) => {
    if (!s) return null;
    s = s.replace(/,/g, '').trim();
    let mul = 1;
    if (/亿/.test(s)) mul = 1e8;
    else if (/万/.test(s)) mul = 1e4;
    else if (/千/.test(s)) mul = 1e3;
    const n = parseFloat(s.replace(/[^\d.]/g, ''));
    return isNaN(n) ? null : Math.round(n * mul);
  };
  return {
    views: parseCN(pick(/播放次数[\s\S]{0,120}?([\d.,]+\s*[万亿千]?)/)),
    reach: parseCN(pick(/覆盖人数[\s\S]{0,120}?([\d.,]+\s*[万亿千]?)/)),
    minutes: parseCN(pick(/观看分钟[\s\S]{0,120}?([\d.,]+\s*[万亿千]?)/)),
    reactions: parseCN(pick(/(?:心情|赞|互动)[\s\S]{0,80}?([\d.,]+\s*[万亿千]?)/)),
    raw: (document.body ? document.body.innerText.slice(0, 1200) : '')
  };
})()
"""


class CollectReq(BaseModel):
    pageIds: list[str] = []
    days: int = 30


@router.post("/insights/collect")
async def collect(req: CollectReq):
    env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    targets = req.pageIds or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]
    if not targets:
        raise HTTPException(400, "没有可采集的主页（缺 asset_id）")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{len(targets)} 个主页", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "insights", f"采集播放量 {len(targets)} 个主页", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_collect(job_id, targets, int(env["cdp_port"])))
    return {"ok": True, "jobId": job_id}


async def _run_collect(job_id: str, page_ids: list[str], port: int) -> None:
    ok, fail = 0, 0
    today = date.today().isoformat()
    try:
        async with FB(port) as fb:
            await fb.assert_identity(settings.fb_publisher_cuser)
            for i, pid in enumerate(page_ids):
                row = db.q1("SELECT asset_id,name FROM pages WHERE page_id=?", (pid,))
                asset = row["asset_id"] if row else None
                if not asset:
                    fail += 1
                    continue
                page = await fb.tab()   # 复用唯一工作标签
                try:
                    await page.goto(
                        f"https://business.facebook.com/latest/insights/overview?asset_id={asset}",
                        wait_until_loaded=9.0)
                    await asyncio.sleep(2.5)
                    data = await page.eval(NUM_JS) or {}
                    if data.get("views") is not None:
                        db.exec(
                            "INSERT INTO insights(page_id,date,views,reach,minutes,reactions,"
                            "comments,shares,collected_at) VALUES(?,?,?,?,?,?,?,?,?)"
                            " ON CONFLICT(page_id,date) DO UPDATE SET"
                            " views=excluded.views, reach=excluded.reach,"
                            " minutes=excluded.minutes, reactions=excluded.reactions,"
                            " collected_at=excluded.collected_at",
                            (pid, today, data.get("views") or 0, data.get("reach") or 0,
                             data.get("minutes") or 0, data.get("reactions") or 0, 0, 0,
                             now_iso()))
                        db.exec("UPDATE pages SET views_30d=? WHERE page_id=?",
                                (data.get("views") or 0, pid))
                        ok += 1
                    else:
                        fail += 1
                        db.log_event("warn", "insights", f"{row['name']} 未解析到数字")
                except Exception as e:
                    fail += 1
                    log.debug("insights %s failed: %s", pid, e)
                db.exec("UPDATE jobs SET progress=? WHERE id=?",
                        (int((i + 1) / len(page_ids) * 100), job_id))
                await asyncio.sleep(2)
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps({"ok": ok, "fail": fail}), now_iso(), job_id))
        db.log_event("ok", "insights", f"采集完成 {ok} 成功 / {fail} 失败")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


@router.get("/insights")
async def get_insights(days: int = Query(14, ge=1, le=90)):
    pages = db.q("SELECT page_id,name,asset_id,views_30d,followers,published,health "
                 "FROM pages ORDER BY views_30d DESC")
    series = db.q(
        "SELECT date,SUM(views) views,SUM(reach) reach,SUM(minutes) minutes "
        "FROM insights WHERE date>=? GROUP BY date ORDER BY date",
        ((date.today() - timedelta(days=days)).isoformat(),))
    rows = []
    for p in pages:
        ins = db.q1(
            "SELECT SUM(views) v, SUM(reach) r, SUM(minutes) m, SUM(reactions) rc,"
            " SUM(comments) c, SUM(shares) s FROM insights WHERE page_id=?", (p["page_id"],))
        rows.append({
            "id": p["page_id"],
            "name": p["name"],
            "assetId": p["asset_id"],
            "views30d": p["views_30d"] or (ins or {}).get("v") or 0,
            "followers": p["followers"] or 0,
            "published": p["published"] or 0,
            "health": p["health"],
            "reactions": (ins or {}).get("rc") or 0,
            "comments": (ins or {}).get("c") or 0,
            "shares": (ins or {}).get("s") or 0,
            "watchMinutes": (ins or {}).get("m") or 0,
        })
    return {"series": series, "pages": rows, "days": days}


@router.get("/insights/{page_id}")
async def page_insights(page_id: str, days: int = 14):
    rows = db.q("SELECT * FROM insights WHERE page_id=? ORDER BY date DESC LIMIT ?",
                (page_id, days))
    agg = db.q1("SELECT SUM(views) v,SUM(reach) r,SUM(minutes) m FROM insights WHERE page_id=?",
                (page_id,))
    return {"pageId": page_id, "daily": rows, "total": agg}
