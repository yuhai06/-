"""风控告警 API：跳脸事件、熔断状态、解除。

前端要做的：任何 tripped=true 立刻弹窗 + 顶栏红色角标，不允许静默。
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.adapters import guard as gd
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.guard")
router = APIRouter(tags=["guard"])


@router.get("/guard/events")
async def list_events(open_only: bool = True, limit: int = 100):
    sql = "SELECT * FROM guard_events"
    if open_only:
        sql += " WHERE resolved=0"
    sql += " ORDER BY ts DESC LIMIT ?"
    rows = db.q(sql, (min(limit, 500),))
    return {"items": rows,
            "open": db.q1("SELECT COUNT(*) c FROM guard_events WHERE resolved=0")["c"],
            "total": db.q1("SELECT COUNT(*) c FROM guard_events")["c"]}


@router.get("/guard/status")
async def status():
    """熔断总览：哪些环境/主页被锁。"""
    open_rows = db.q("SELECT * FROM guard_events WHERE resolved=0 ORDER BY ts DESC")
    by_kind: dict[str, int] = {}
    for r in open_rows:
        by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + 1
    accounts = sorted({r["env_code"] for r in open_rows if r["scope"] == "account" and r["env_code"]})
    pages = sorted({r["page_id"] for r in open_rows if r["scope"] == "page" and r["page_id"]})
    return {
        "blocked": bool(open_rows),
        "count": len(open_rows),
        "byKind": by_kind,
        "blockedEnvs": accounts,
        "blockedPages": pages,
        "latest": open_rows[0] if open_rows else None,
    }


class ResolveReq(BaseModel):
    id: int
    note: str = ""


@router.post("/guard/resolve")
async def resolve(req: ResolveReq):
    r = db.q1("SELECT * FROM guard_events WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "事件不存在")
    gd.resolve(req.id, req.note or "人工确认")
    return {"ok": True}


@router.get("/guard/signatures")
async def signatures():
    """把签名库暴露给前端，方便说明「什么样的页面算跳脸」。"""
    out = []
    for kind, sev, msg, rx in gd.SIGNATURES:
        out.append({"kind": kind, "severity": sev, "message": msg,
                    "pattern": rx.pattern[:160]})
    return {"items": out,
            "urlPatterns": [{"kind": k, "severity": s, "fragment": f}
                            for k, s, f in gd.URL_SIGNATURES]}


class CheckReq(BaseModel):
    envCode: str = ""
    pageId: str = ""


@router.post("/guard/check")
async def manual_check(req: CheckReq):
    """对当前运行中的发布号环境做一次主动检查。"""
    env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,)) \
        if req.envCode else db.q1(
            "SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的环境")
    from app.adapters.cdp import Browser
    from app.adapters.facebook import FB
    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()   # 复用唯一工作标签
            import asyncio as aio
            await aio.sleep(3)
            v = await gd.check(page, env["container_code"], req.pageId)
    except Exception as e:
        raise HTTPException(500, f"检查失败: {str(e)[:200]}")
    return {"ok": True, "verdict": v.as_dict()}
