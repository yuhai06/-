"""评论区维护 API：抓评论 → 分类 → 回复引导 / 删除恶评。

安全默认：
    · 抓取和分类可以先 dryRun，让用户看清楚要动哪些
    · 删除默认 dryRun，必须 commit=true 才真删
    · 每条评论 24h 内只处理一次，防重复
"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import comments as cm

log = logging.getLogger("yuhai.api.comments")
router = APIRouter(tags=["comments"])


# ---------------- 分类预览（不碰浏览器）----------------
class ClassifyReq(BaseModel):
    texts: list[str] = []
    accountId: str = ""


@router.post("/comments/classify")
async def classify_texts(req: ClassifyReq):
    """纯分类，不操作。给前端/测试看规则命中情况。"""
    out = []
    for t in req.texts:
        cat, reason = cm.classify(t)
        out.append({"text": t, "category": cat, "reason": reason,
                    "delete": cm.should_delete(cat),
                    "reply": cm.should_reply(cat)})
    custom = cm.load_custom_rules()
    return {"items": out,
            "rules": {"toxic": len(cm.TOXIC_WORDS),
                      "illegal": len(cm.ILLEGAL_WORDS),
                      "spamPatterns": len(cm.SPAM_PATTERNS),
                      "genuineHints": len(cm.GENUINE_HINTS),
                      "shortPositive": len(cm.SHORT_POSITIVE),
                      "laughWords": len(cm.LAUGH_WORDS),
                      "replyTemplates": len(cm.REPLY_TEMPLATES),
                      "customPositive": len(custom.get("positive", [])),
                      "customDelete": len(custom.get("deleteWords", []))}}


# ---------------- 自定义规则 ----------------
class RulesReq(BaseModel):
    positive: list[str] | None = None       # 命中就回复的词/短语
    deleteWords: list[str] | None = None    # 命中就删的词
    deleteRegex: list[str] | None = None    # 命中就删的正则


@router.get("/comments/rules")
async def get_rules():
    custom = cm.load_custom_rules(force=True)
    return {
        "custom": custom,
        "builtin": {
            "shortPositive": sorted(cm.SHORT_POSITIVE),
            "laughWords": sorted(cm.LAUGH_WORDS),
            "genuineHints": cm.GENUINE_HINTS,
            "toxic": cm.TOXIC_WORDS,
            "illegal": cm.ILLEGAL_WORDS,
            "spamPatterns": cm.SPAM_PATTERNS,
        },
        "emojiDetection": "纯表情 / 表情为主（≥50%）/ 贴纸 [sticker] 都会回复",
    }


@router.post("/comments/rules")
async def set_rules(req: RulesReq):
    custom = cm.save_custom_rules(req.model_dump(exclude_none=True))
    return {"ok": True, "custom": custom}


@router.get("/comments/templates")
async def templates():
    from app.services import caption
    links = [x for x in caption.list_links("") if x["enabled"]]
    return {"templates": cm.REPLY_TEMPLATES,
            "limits": cm.LIMITS,
            "linkCount": len(links),
            "sampleReplies": [cm.build_reply(links[0]["url"]) for _ in range(3)]
                             if links else []}


@router.get("/comments/quota")
async def quota(accountId: str = ""):
    if accountId:
        return cm.quota_for(accountId)
    rows = db.q("SELECT id,label FROM accounts WHERE enabled=1")
    return {"items": [{"accountId": r["id"], "label": r["label"],
                       **cm.quota_for(r["id"])} for r in rows]}


# ---------------- 抓评论 ----------------
class FetchReq(BaseModel):
    pageId: str
    postId: str = ""
    envCode: str = ""
    limit: int = 50


@router.post("/comments/fetch")
async def fetch(req: FetchReq):
    """抓某个主页（或某条帖子）的评论。"""
    p = db.q1("SELECT * FROM pages WHERE page_id=?", (req.pageId,))
    if not p:
        raise HTTPException(404, "主页不存在")
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的环境")

    from app.adapters.facebook import FB
    from app.adapters import guard as gd

    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()
            url = (f"https://www.facebook.com/{p['asset_id']}"
                   if p["asset_id"] else f"https://www.facebook.com/profile.php?id={req.pageId}")
            await page.goto(url, wait_until_loaded=8.0)
            await asyncio.sleep(2.5)

            v = await gd.check(page)
            if v and v.tripped:
                raise HTTPException(429, f"风控命中：{v.message}")

            raw = await page.eval(COMMENTS_JS.replace("__LIMIT__", str(req.limit)))
            items = (raw or {}).get("comments") or []
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"抓取失败：{str(e)[:200]}")

    out = []
    for c in items:
        cat, reason = cm.classify(c.get("text") or "")
        out.append({**c, "category": cat, "reason": reason,
                    "shouldDelete": cm.should_delete(cat),
                    "shouldReply": cm.should_reply(cat)})
    return {"ok": True, "count": len(out), "items": out,
            "byCategory": _count_cat(out)}


COMMENTS_JS = r"""
(() => {
  const out = [];
  const LIMIT = __LIMIT__;
  // 评论节点：FB 用 role=article 且带 aria-label 含 Comment
  const nodes = document.querySelectorAll(
    'div[role="article"][aria-label*="Comment"], ul div[role="article"]');
  let i = 0;
  for (const n of nodes) {
    if (i++ >= LIMIT) break;
    const t = (n.innerText || '').trim();
    if (!t) continue;
    // 作者：第一个链接
    const a = n.querySelector('a[role="link"] span, a strong');
    const author = a ? (a.innerText || '').trim() : '';
    // id：从 data-ft 或 href 里抠
    let cid = n.getAttribute('data-ft') || '';
    if (!cid) {
      const l = n.querySelector('a[href*="comment_id"]');
      if (l) {
        const m = (l.getAttribute('href') || '').match(/comment_id=(\d+)/);
        if (m) cid = m[1];
      }
    }
    const full = (n.innerText || '').replace(author, '').trim();
    out.push({cid: cid || ('c' + i), text: full.slice(0, 600),
              author: author.slice(0, 80)});
  }
  return {comments: out, total: nodes.length};
})()
"""


def _count_cat(items: list[dict]) -> dict:
    d: dict[str, int] = {}
    for x in items:
        d[x["category"]] = d.get(x["category"], 0) + 1
    return d


# ---------------- 执行（回复 / 删除）----------------
class RunReq(BaseModel):
    pageId: str
    accountId: str = ""
    envCode: str = ""
    comments: list[dict] = []
    allowReply: bool = True
    allowDelete: bool = True
    dryRun: bool = True          # 默认演练
    linkUrl: str = ""            # 指定链接；空则从池随机


@router.post("/comments/run")
async def run(req: RunReq):
    """对给定评论执行回复/删除。

    dryRun=True（默认）只出计划，不碰浏览器。
    「只观察」模式会强制 dryRun=True（只记录不动作）。
    """
    from app.services import automation as au
    if au.observe_only():
        req.dryRun = True
    p = db.q1("SELECT * FROM pages WHERE page_id=?", (req.pageId,))
    if not p:
        raise HTTPException(404, "主页不存在")

    acc = None
    if req.accountId:
        acc = db.q1("SELECT * FROM accounts WHERE id=?", (req.accountId,))
    if not acc:
        acc = db.q1("SELECT * FROM accounts WHERE role='publisher' AND enabled=1"
                    " LIMIT 1")
    acc_id = (acc or {}).get("id") or ""

    q = cm.quota_for(acc_id) if acc_id else {
        "replyLeft": 20, "deleteLeft": 30, "level": "unknown"}

    # 链接：指定 > 池随机
    link = req.linkUrl.strip()
    if not link:
        from app.services import caption
        picked = caption.pick_link(req.pageId)
        link = picked["url"] if picked else ""

    objs = [cm.Comment(cid=c.get("cid") or "", text=c.get("text") or "",
                       author=c.get("author") or "",
                       post_id=c.get("postId") or req.pageId)
            for c in req.comments]
    plan = cm.plan_for(objs, link, req.allowDelete, req.allowReply,
                       q["replyLeft"], q["deleteLeft"])
    summary = cm.summarize(plan)

    if req.dryRun:
        return {"ok": True, "dryRun": True, "plan": [
            {"cid": c.cid, "text": c.text[:120], "author": c.author,
             "category": c.category, "reason": c.reason,
             "action": c.action, "reply": c.reply_text} for c in plan],
            "summary": summary, "link": link, "quota": q,
            "note": "演练模式，未做任何操作。确认后传 dryRun=false 执行。"}

    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的环境")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{c.action}: {c.text[:30]}", "state": "wait", "note": ""}
             for c in plan if c.action in ("reply", "delete")]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "comments", f"评论区维护 {p['name'] or req.pageId}",
             "running", 0, json.dumps(steps, ensure_ascii=False),
             json.dumps({"pageId": req.pageId, "accountId": acc_id,
                         "summary": summary}, ensure_ascii=False),
             now_iso(), now_iso()))
    asyncio.create_task(_run_comments(job_id, req, plan, env, acc_id, link))
    return {"ok": True, "jobId": job_id, "summary": summary}


async def _collect_and_act(page_id: str, env: dict, allow_reply: bool = True,
                           allow_delete: bool = True, dry_run: bool = False,
                           link_url: str = "", limit: int = 50) -> dict:
    """抓某主页的评论并处理。供常驻轮询和 API 共用。

    返回 {reply, delete, skip, guard, error}
    """
    from app.adapters.facebook import FB
    from app.adapters import guard as gd

    p = db.q1("SELECT * FROM pages WHERE page_id=?", (page_id,))
    if not p:
        return {"reply": 0, "delete": 0, "skip": 0, "error": "主页不存在"}

    # 链接
    link = link_url.strip()
    if not link:
        from app.services import caption
        picked = caption.pick_link(page_id)
        link = picked["url"] if picked else ""

    # 额度
    acc = db.q1("SELECT * FROM accounts WHERE env_code=? AND role='publisher'"
                " AND enabled=1 LIMIT 1", (env["container_code"],))
    acc_id = (acc or {}).get("id") or ""
    q = cm.quota_for(acc_id) if acc_id else {"replyLeft": 20, "deleteLeft": 30}

    out = {"reply": 0, "delete": 0, "skip": 0, "guard": None, "error": None,
           "found": 0}

    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()
            url = (f"https://www.facebook.com/{p['asset_id']}" if p["asset_id"]
                   else f"https://www.facebook.com/profile.php?id={page_id}")
            await page.goto(url, wait_until_loaded=8.0)
            await asyncio.sleep(2.5)

            v = await gd.check(page, env_code=env["container_code"], page_id=page_id)
            if v and v.tripped:
                out["guard"] = {"kind": v.kind, "message": v.message,
                                "scope": v.scope}
                return out

            raw = await page.eval(COMMENTS_JS.replace("__LIMIT__", str(limit)))
            items = (raw or {}).get("comments") or []
            out["found"] = len(items)

            objs = [cm.Comment(cid=x.get("cid") or "", text=x.get("text") or "",
                               author=x.get("author") or "", post_id=page_id)
                    for x in items]
            plan = cm.plan_for(objs, link, allow_delete, allow_reply,
                               q["replyLeft"], q["deleteLeft"])

            from app.adapters import humanize as hz
            for c in plan:
                if c.action not in ("reply", "delete"):
                    out["skip"] += 1
                    continue
                v2 = await gd.check(page, env_code=env["container_code"],
                                    page_id=page_id)
                if v2 and v2.tripped:
                    out["guard"] = {"kind": v2.kind, "message": v2.message,
                                    "scope": v2.scope}
                    return out
                try:
                    if c.action == "delete":
                        r = {"ok": True} if dry_run else await _do_delete(page, c)
                    else:
                        r = {"ok": True} if dry_run else await _do_reply(page, c, link)
                except Exception as e:
                    r = {"ok": False, "error": str(e)[:120]}

                if r.get("ok"):
                    out[c.action] += 1
                    cm.record(acc_id, page_id, c.cid, c.action, c.category,
                              c.text, c.reply_text, dry=dry_run)
                else:
                    out["skip"] += 1
                # 评论间长间隔
                await hz.human_delay("nav")
                await asyncio.sleep(hz.jitter(6, 18))
    except Exception as e:
        out["error"] = str(e)[:200]
    return out


async def _run_comments(job_id: str, req: RunReq, plan: list[cm.Comment],
                        env: dict, acc_id: str, link: str) -> None:
    from app.adapters.facebook import FB
    from app.adapters import guard as gd, humanize as hz

    steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?",
                             (job_id,))["steps"] or "[]")
    ok_r, ok_d, fail = 0, 0, 0
    si = 0
    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()
            p = db.q1("SELECT * FROM pages WHERE page_id=?", (req.pageId,))
            url = (f"https://www.facebook.com/{p['asset_id']}"
                   if p and p["asset_id"]
                   else f"https://www.facebook.com/profile.php?id={req.pageId}")
            await page.goto(url, wait_until_loaded=8.0)
            await hz.human_delay("read")

            for c in plan:
                if c.action not in ("reply", "delete"):
                    continue
                # 每步前过 guard
                v = await gd.check(page, env_code=env["container_code"],
                                   page_id=req.pageId)
                if v and v.tripped:
                    steps[si].update(state="err", note=f"⚠ {v.message}")
                    db.exec("UPDATE jobs SET steps=?,status='blocked',"
                            "result=?,ended_at=? WHERE id=?",
                            (json.dumps(steps, ensure_ascii=False),
                             json.dumps({"reply": ok_r, "delete": ok_d,
                                         "guard": {"kind": v.kind,
                                                   "message": v.message,
                                                   "scope": v.scope}},
                                        ensure_ascii=False),
                             now_iso(), job_id))
                    db.log_event("err", "comments",
                                 f"评论区维护命中 {v.kind}，已中止")
                    return

                steps[si]["state"] = "run"
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False), job_id))

                try:
                    if c.action == "delete":
                        res = await _do_delete(page, c)
                    else:
                        res = await _do_reply(page, c, link)
                except Exception as e:
                    res = {"ok": False, "error": str(e)[:150]}

                if res.get("ok"):
                    if c.action == "delete":
                        ok_d += 1
                    else:
                        ok_r += 1
                    steps[si].update(state="done",
                                     note=("已删" if c.action == "delete"
                                           else "已回"))
                    cm.record(acc_id, req.pageId, c.cid, c.action, c.category,
                              c.text, c.reply_text)
                else:
                    fail += 1
                    steps[si].update(state="err", note=res.get("error") or "失败")
                    cm.record(acc_id, req.pageId, c.cid, "skip", c.category,
                              c.text, "", dry=True)

                si += 1
                db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False),
                         int(si / max(1, len(steps)) * 100), job_id))
                # 评论之间长间隔（比发帖更频繁，所以更要慢）
                await hz.human_delay("nav")
                await asyncio.sleep(hz.jitter(8, 22))

        db.exec("UPDATE jobs SET status=?,result=?,ended_at=? WHERE id=?",
                ("done" if fail == 0 else "blocked",
                 json.dumps({"reply": ok_r, "delete": ok_d, "fail": fail},
                            ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "comments",
                     f"评论区维护完成：回复 {ok_r} · 删除 {ok_d} · 失败 {fail}")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "comments", str(e)[:200])


async def _do_delete(page, c: cm.Comment) -> dict:
    """找到该评论的菜单 → 删除。"""
    from app.adapters import humanize as hz
    js = r"""
    (cid) => {
      const nodes = document.querySelectorAll('div[role="article"]');
      for (const n of nodes) {
        let id = n.getAttribute('data-ft') || '';
        if (!id) {
          const l = n.querySelector('a[href*="comment_id"]');
          if (l) {
            const m = (l.getAttribute('href')||'').match(/comment_id=(\d+)/);
            if (m) id = m[1];
          }
        }
        if (id !== cid) continue;
        const btn = n.querySelector('[aria-label*="Action"],[aria-label*="更多"]');
        if (btn) { btn.click(); return 'menu-open'; }
      }
      return '';
    }"""
    r = await page.eval(js, [c.cid])
    if not r:
        return {"ok": False, "error": "找不到该评论"}
    await hz.human_delay("click")
    # 菜单里点删除
    ok = await page.click_text("Delete", exact=False)
    if not ok:
        ok = await page.click_text("删除", exact=False)
    if not ok:
        return {"ok": False, "error": "菜单中找不到删除项"}
    await hz.human_delay("click")
    # 确认弹窗
    for label in ("Delete", "删除"):
        if await page.click_text(label, exact=True):
            break
    await hz.human_delay("click")
    return {"ok": True}


async def _do_reply(page, c: cm.Comment, link: str) -> dict:
    """回复该评论，内容里必须含链接。"""
    from app.adapters import humanize as hz
    if not c.reply_text or link not in c.reply_text:
        return {"ok": False, "error": "回复内容缺链接，拒绝发送"}

    js = r"""
    (cid) => {
      const nodes = document.querySelectorAll('div[role="article"]');
      for (const n of nodes) {
        let id = n.getAttribute('data-ft') || '';
        if (!id) {
          const l = n.querySelector('a[href*="comment_id"]');
          if (l) {
            const m = (l.getAttribute('href')||'').match(/comment_id=(\d+)/);
            if (m) id = m[1];
          }
        }
        if (id !== cid) continue;
        const reply = n.querySelector('[aria-label*="Reply"],[aria-label*="回复"]');
        if (reply) { reply.click(); return 'reply-open'; }
      }
      return '';
    }"""
    r = await page.eval(js, [c.cid])
    if not r:
        return {"ok": False, "error": "找不到回复按钮"}
    await hz.human_delay("click")

    # 拟人打字（不一次性粘贴）
    await hz.human_type(page, c.reply_text)
    await hz.human_delay("click")

    # 回车提交
    sent = await page.eval(r"""
    (() => {
      const box = document.querySelector('div[contenteditable="true"]');
      if (!box) return false;
      box.dispatchEvent(new KeyboardEvent('keydown',
        {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true}));
      return true;
    })()""")
    await hz.human_delay("read")
    return {"ok": bool(sent)}


# ---------------- 常驻轮询（软件关了怎么办）----------------
class WatchCfgReq(BaseModel):
    enabled: bool | None = None
    intervalMin: int | None = None
    pagesPerRound: int | None = None
    allowReply: bool | None = None
    allowDelete: bool | None = None
    useRandomLink: bool | None = None
    quietHours: list[int] | None = None
    catchUpOnBoot: bool | None = None
    catchUpPages: int | None = None
    coverNewPages: bool | None = None


@router.get("/comments/watch")
async def watch_status():
    from app.services import comment_watch as cw
    return {**cw.status(),
            "explain": {
                "layer1": "软件运行时：后台每 N 分钟自动轮询（本服务）",
                "layer2": "软件关了但电脑开着：装 Windows 计划任务每 5 分钟自查，没跑就拉起来",
                "layer3": "电脑关机：开机自启（计划任务 ONSTART/ONLOGON），或部署到 7x24 VPS",
            }}


@router.post("/comments/watch")
async def watch_config(req: WatchCfgReq):
    from app.services import comment_watch as cw
    cfg = cw.save_cfg(req.model_dump(exclude_none=True))
    return {"ok": True, "config": cfg}


@router.post("/comments/watch/start")
async def watch_start():
    from app.services import comment_watch as cw
    cw.save_cfg({"enabled": True})
    await cw.watcher.start()
    return {"ok": True, "running": bool(cw.watcher.task
                                        and not cw.watcher.task.done())}


@router.post("/comments/watch/stop")
async def watch_stop():
    from app.services import comment_watch as cw
    await cw.watcher.stop()
    return {"ok": True, "running": False}


@router.post("/comments/watch/run-once")
async def watch_run_once(catchUp: bool = False):
    """立刻跑一轮（不用等间隔）。catchUp=true 时按补漏规模跑。"""
    from app.services import comment_watch as cw
    if catchUp:
        res = await cw.watcher.catch_up()
    else:
        res = await cw.watcher.round(cw.load_cfg())
    return {"ok": True, "result": res}


@router.get("/comments/watch/task")
async def watch_task_commands():
    """返回计划任务命令（供前端展示，用户可复制或一键安装）。"""
    from app.services import comment_watch as cw
    return cw.task_command()


@router.post("/comments/watch/task")
async def watch_install_task(kind: str = "alive"):
    from app.services import comment_watch as cw
    return cw.install_task(kind)


@router.delete("/comments/watch/task")
async def watch_uninstall_task():
    from app.services import comment_watch as cw
    return cw.uninstall_tasks()


# ---------------- 历史 ----------------
@router.get("/comments/history")
async def history(pageId: str = "", action: str = "", limit: int = 200):
    sql = "SELECT * FROM comment_actions WHERE 1=1"
    params: list[Any] = []
    if pageId:
        sql += " AND page_id=?"
        params.append(pageId)
    if action:
        sql += " AND action=?"
        params.append(action)
    sql += " ORDER BY ts DESC LIMIT ?"
    params.append(min(limit, 1000))
    rows = db.q(sql, params)
    stats = db.q(
        "SELECT action, category, COUNT(*) n FROM comment_actions "
        "GROUP BY action, category ORDER BY n DESC")
    return {"items": rows, "stats": stats}
