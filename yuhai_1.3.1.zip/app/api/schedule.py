"""排期 API：日历、队列、规则、自动排期。

关键约束：
  · 每主页每天上限（默认 2）
  · 同页最小间隔（默认 120 分钟）
  · 发布后删素材（队列条目随之删除）
"""
from __future__ import annotations

import json
import logging
import uuid
from pathlib import Path
from datetime import date, datetime, timedelta
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.db import db, now_iso

log = logging.getLogger("yuhai.api.schedule")
router = APIRouter(tags=["schedule"])

DEFAULT_RULES = {
    "perPagePerDay": 4,      # 用户要求：每个公共主页每天固定 4 条
    "windowStart": 17,       # 17:00-24:00（4 条 × 120 分钟 = 需 6 小时窗口）
    "windowEnd": 24,
    "minGapMinutes": 120,
    "staggerPerPage": True,
    "deleteAfterPublish": True,
    "skipRestrictedPages": True,
    # 过期保护：排期超过这么多分钟仍未执行就转手动，不自动补发。
    # 避免关软件几小时后重开，一次性涌出一堆旧排期（明显非人类行为）
    "expireMin": 180,
    # 超时后是否转手动（素材保留在队列，用户自己挑时机发）
    # 设 False 则只标 missed 并丢弃那条排期（素材仍留在队列）
    "expireToManual": True,
}

# 每页每天 4 条的推荐时间槽（相邻间隔都 >= 120 分钟，且落在 17-24 窗口内）
# 北京 → 美东(EDT)：17=05 / 19:30=07:30 / 21:30=09:30 / 23:30=11:30
SPREAD_SLOTS = ["17:00", "19:30", "21:30", "23:30"]


def rules() -> dict:
    return {**DEFAULT_RULES, **(db.get_kv("schedule.rules") or {})}


@router.get("/schedule/missed")
async def list_missed(days: int = 7):
    """超时转手动的排期（素材还在队列里，等用户自己发）。

    返回：
        items  每条含 page / 原定时间 / 剧名 / 集号 / 素材文件 / 队列 id
        count  条数
    用户可以在发布中心挑这些素材手动发，或者重新排期。
    """
    from datetime import date, timedelta
    since = (date.today() - timedelta(days=max(1, days))).isoformat()
    rows = db.q(
        "SELECT * FROM schedule WHERE state='missed' AND date>=? "
        "ORDER BY date DESC, time DESC", (since,))

    items = []
    for s in rows:
        q = db.q1("SELECT * FROM queue WHERE id=?", (s["queue_id"],)) if s["queue_id"] else None
        items.append({
            **s,
            "queue": q,
            "fileExists": bool(q and Path(q["path"]).exists()),
        })
    return {"items": items, "count": len(items),
            "note": "这些是超时未发、已转手动的素材。素材仍在队列，可手动发布或重新排期。"}


@router.post("/schedule/{sid}/requeue")
async def requeue_missed(sid: str):
    """把超时转手动的排期重新排（可选：直接放回队列 ready）。"""
    s = db.q1("SELECT * FROM schedule WHERE id=?", (sid,))
    if not s:
        raise HTTPException(404, "排期不存在")
    if s["queue_id"]:
        db.exec("UPDATE queue SET state='ready' WHERE id=?", (s["queue_id"],))
    db.exec("DELETE FROM schedule WHERE id=?", (sid,))
    db.log_event("info", "schedule", f"已把 {s['page']} {s['time']} 的素材放回队列")
    return {"ok": True, "queueId": s["queue_id"],
            "note": "素材已回队列 ready，可手动发布或重新排期"}


# ---------------- 队列 ----------------
@router.get("/queue")
async def list_queue(kind: str = "", state: str = ""):
    """队列列表。

    kind: single | mix | 空=全部
    state: ready | scheduled | done | 空=全部

    发布页用 `?kind=single&state=ready`，把混剪排除在发布队列外
    （用户要求：混剪留着，不和单集一起发布）。
    """
    sql = "SELECT * FROM queue WHERE 1=1"
    params: list = []
    if kind:
        sql += " AND kind=?"
        params.append(kind)
    if state:
        sql += " AND state=?"
        params.append(state)
    sql += " ORDER BY added_at DESC"
    rows = db.q(sql, tuple(params))
    return {"items": rows,
            "totalMb": round(sum(float(r["size_mb"] or 0) for r in rows), 1)}


def detect_kind(path: str, name: str = "") -> str:
    """判断素材类型：single（单集）| mix（混剪/主线版）。

    判据（按优先级）：
        · 文件名/路径含 `主线版` `精品混剪` `混剪` → mix
        · 文件名形如 `xxx_EP01.mp4` → single
        · 其余 → single
    """
    s = f"{name or ''} {path or ''}".lower()
    if any(k in s for k in ("主线版", "精品混剪", "混剪", "纯混剪")):
        return "mix"
    return "single"


class AddQueueReq(BaseModel):
    path: str
    drama: str = ""
    ep: str = ""
    page: str = ""
    libId: str = ""
    kind: str = ""          # 空 = 自动判断


@router.post("/queue")
async def add_queue(req: AddQueueReq):
    from pathlib import Path
    p = Path(req.path)
    if not p.exists():
        raise HTTPException(400, f"文件不存在: {req.path}")
    qid = "q-" + uuid.uuid4().hex[:10]
    kind = req.kind or detect_kind(str(p), p.name)
    db.exec("INSERT INTO queue(id,lib_id,path,file,drama,ep,page,dur,size_mb,"
            "state,added_at,kind) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (qid, req.libId or None, str(p), p.name, req.drama, req.ep, req.page,
             None, round(p.stat().st_size / 1048576, 1), "ready", now_iso(), kind))
    return {"ok": True, "id": qid, "kind": kind}


@router.delete("/queue/{qid}")
async def del_queue(qid: str, deleteFile: bool = False):
    r = db.q1("SELECT * FROM queue WHERE id=?", (qid,))
    if not r:
        raise HTTPException(404, "不存在")
    if deleteFile:
        from pathlib import Path
        try:
            Path(r["path"]).unlink()
        except Exception as e:
            raise HTTPException(500, f"删文件失败: {e}")
    db.exec("DELETE FROM queue WHERE id=?", (qid,))
    return {"ok": True}


# ---------------- 排期 ----------------
@router.get("/schedule")
async def list_schedule(from_: str = Query("", alias="from"), to: str = "",
                        envCode: str = "", pageIds: str = ""):
    """排期列表。envCode 按号筛选；pageIds 逗号分隔，支持 'all'。"""
    sql = "SELECT * FROM schedule WHERE 1=1"
    params: list[Any] = []
    if from_:
        sql += " AND date>=?"
        params.append(from_)
    if to:
        sql += " AND date<=?"
        params.append(to)

    if pageIds and pageIds != "all":
        ids = [x.strip() for x in pageIds.split(",") if x.strip()]
        if ids:
            sql += " AND page IN (%s)" % ",".join("?" * len(ids))
            params.extend(ids)
    elif envCode:
        rows = db.q("SELECT page_id FROM pages WHERE env_code=?", (envCode,))
        ids = [r["page_id"] for r in rows]
        if ids:
            sql += " AND page IN (%s)" % ",".join("?" * len(ids))
            params.extend(ids)
        else:
            return {"items": [], "rules": rules()}

    sql += " ORDER BY date, time"
    rows = db.q(sql, params)
    for r in rows:
        if r["queue_id"]:
            q = db.q1("SELECT file,size_mb,state FROM queue WHERE id=?", (r["queue_id"],))
            r["queue"] = q
        p = db.q1("SELECT name,env_code FROM pages WHERE page_id=?", (r["page"],))
        if p:
            r["pageName"] = p["name"]
            r["envCode"] = p["env_code"]
    return {"items": rows, "rules": rules()}


def _to_min(hhmm: str) -> int:
    try:
        h, m = hhmm.split(":")
        return int(h) * 60 + int(m or 0)
    except Exception:
        return 0


class SchedReq(BaseModel):
    page: str
    date: str
    time: str
    drama: str = ""
    ep: str = ""
    queueId: str = ""
    kind: str = ""          # 空 = 从队列继承


@router.post("/schedule")
async def add_schedule(req: SchedReq):
    R = rules()
    kind = req.kind
    if not kind and req.queueId:
        q = db.q1("SELECT kind FROM queue WHERE id=?", (req.queueId,))
        kind = (q or {}).get("kind") or ""
    if not kind:
        kind = "single"

    same_day = db.q("SELECT * FROM schedule WHERE page=? AND date=?",
                    (req.page, req.date))
    if len(same_day) >= R["perPagePerDay"]:
        raise HTTPException(400,
            f"{req.page} 在 {req.date} 已有 {len(same_day)} 条，上限 {R['perPagePerDay']} 条")
    # 同一天同一页：混剪和单集不能混发（用户要求）
    if same_day:
        kinds = {(s.get("kind") or "single") for s in same_day}
        if kinds and kind not in kinds:
            raise HTTPException(400,
                f"{req.page} 在 {req.date} 已经排了 {sorted(kinds)[0]} 类型素材，"
                f"混剪和单集不能同页混发。请换主页或换日期。")
    t = _to_min(req.time)
    for s in same_day:
        if abs(_to_min(s["time"]) - t) < R["minGapMinutes"]:
            raise HTTPException(400,
                f"与 {s['time']} 相差不足 {R['minGapMinutes']} 分钟，请错开")
    page = db.q1("SELECT health FROM pages WHERE page_id=? OR name=?", (req.page, req.page))
    state = "planned"
    if page and page["health"] != "ok":
        state = "blocked"
    sid = "s-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO schedule(id,page,date,time,drama,ep,queue_id,state,"
            "created_at,kind) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (sid, req.page, req.date, req.time, req.drama, req.ep,
             req.queueId or None, state, now_iso(), kind))
    if req.queueId:
        db.exec("UPDATE queue SET state='scheduled',page=? WHERE id=?", (req.page, req.queueId))
    return {"ok": True, "id": sid, "state": state, "kind": kind}


class SchedPatch(BaseModel):
    page: str | None = None
    date: str | None = None
    time: str | None = None
    drama: str | None = None
    ep: str | None = None
    queueId: str | None = None
    state: str | None = None


@router.patch("/schedule/{sid}")
async def patch_schedule(sid: str, p: SchedPatch):
    r = db.q1("SELECT * FROM schedule WHERE id=?", (sid,))
    if not r:
        raise HTTPException(404, "不存在")
    fields = {k: v for k, v in p.model_dump(exclude_none=True).items()}
    if not fields:
        return {"ok": True}
    col = {"queueId": "queue_id"}
    sets = ",".join(f"{col.get(k, k)}=?" for k in fields)
    db.exec(f"UPDATE schedule SET {sets} WHERE id=?", (*fields.values(), sid))
    return {"ok": True}


@router.delete("/schedule/{sid}")
async def del_schedule(sid: str):
    db.exec("DELETE FROM schedule WHERE id=?", (sid,))
    return {"ok": True}


# ---------------- 规则 ----------------
@router.get("/schedule/rules")
async def get_rules():
    return rules()


class RulesReq(BaseModel):
    perPagePerDay: int | None = None
    windowStart: int | None = None
    windowEnd: int | None = None
    minGapMinutes: int | None = None
    staggerPerPage: bool | None = None
    deleteAfterPublish: bool | None = None
    skipRestrictedPages: bool | None = None
    expireMin: int | None = None      # 过期多少分钟后不再补发（0=全部补发）
    expireToManual: bool | None = None  # 超时是否转手动（True=素材保留可手发）


@router.post("/schedule/rules")
async def set_rules(req: RulesReq):
    cur = rules()
    cur.update({k: v for k, v in req.model_dump(exclude_none=True).items()})
    db.set_kv("schedule.rules", cur)
    return {"ok": True, "rules": cur}


# ---------------- 自动排期 ----------------
class AutoPlanReq(BaseModel):
    days: int = 3
    startDate: str = ""
    mode: str = "page-first"
    pageIds: list[str] = []
    envCode: str = ""
    randomPick: bool = False
    smartMatch: bool = False
    perPagePerDay: int = 0       # 0 = 用规则里的默认值
    totalLimit: int = 0          # 0 = 不限；否则本次最多排这么多条


@router.post("/schedule/autoplan")
async def autoplan(req: AutoPlanReq):
    R = rules()
    # 本次生效的每页每日上限（可覆盖规则）
    per_day = req.perPagePerDay if req.perPagePerDay > 0 else R["perPagePerDay"]
    per_day = max(1, min(10, per_day))

    start = req.startDate or date.today().isoformat()
    try:
        start_d = date.fromisoformat(start)
    except Exception:
        raise HTTPException(400, "startDate 格式应为 YYYY-MM-DD")

    qs = db.q("SELECT * FROM queue WHERE state='ready' ORDER BY added_at")
    if not qs:
        return {"ok": True, "created": 0, "note": "队列为空"}

    if req.totalLimit > 0:
        qs = qs[:req.totalLimit]

    if req.pageIds:
        pages = []
        for pid in req.pageIds:
            p = db.q1("SELECT page_id,name,health,env_code,skip_publish FROM pages "
                      "WHERE page_id=? OR name=?", (pid, pid))
            if p:
                pages.append(p)
    else:
        pages = db.q("SELECT page_id,name,health,env_code,skip_publish FROM pages "
                     "ORDER BY views_30d DESC")

    if req.envCode:
        pages = [p for p in pages if p["env_code"] == req.envCode]

    # 跳过被标记为「不自动发布」的主页（手动发的）
    skipped_manual = [p for p in pages if p.get("skip_publish")]
    pages = [p for p in pages if not p.get("skip_publish")]

    if R["skipRestrictedPages"]:
        pages = [p for p in pages if p["health"] == "ok"]
    if not pages:
        raise HTTPException(400,
            f"没有可用主页（{len(skipped_manual)} 个被标记为不自动发布，"
            f"其余可能全部受限）")

    if req.randomPick:
        import random
        random.shuffle(qs)
    elif req.smartMatch:
        scored = []
        for q in qs:
            best = 0.0
            for p in pages:
                fit = db.q1("SELECT * FROM page_fit WHERE page_id=?", (p["page_id"],))
                if not fit:
                    continue
                try:
                    kws = json.loads(fit["keywords"] or "[]")
                except Exception:
                    kws = []
                blob = ((q.get("drama") or "") + " " + (q.get("file") or "")).lower()
                s = 0.0
                if fit["drama_type"]:
                    s += 10
                for kw in kws:
                    if kw and kw.lower() in blob:
                        s += 5
                best = max(best, s)
            scored.append((best, q))
        scored.sort(key=lambda x: -x[0])
        qs = [q for _, q in scored]

    created = 0
    idx = 0
    for d in range(req.days):
        day = (start_d + timedelta(days=d)).isoformat()
        for p in pages:
            exist = db.q("SELECT * FROM schedule WHERE page=? AND date=?",
                         (p["page_id"], day))
            slots = per_day - len(exist)
            if slots <= 0:
                continue
            for k in range(slots):
                if idx >= len(qs):
                    break
                if req.totalLimit > 0 and created >= req.totalLimit:
                    break
                q = qs[idx]
                idx += 1
                span = (R["windowEnd"] - R["windowStart"]) * 60
                step = span // max(1, per_day)
                minutes = R["windowStart"] * 60 + k * step + (hash(p["page_id"]) % 17)
                tm = f"{minutes // 60:02d}:{minutes % 60:02d}"
                sid = "s-" + uuid.uuid4().hex[:10]
                db.exec("INSERT INTO schedule(id,page,date,time,drama,ep,queue_id,"
                        "state,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                        (sid, p["page_id"], day, tm, q["drama"], q["ep"], q["id"],
                         "planned", now_iso()))
                db.exec("UPDATE queue SET state='scheduled',page=? WHERE id=?",
                        (p["page_id"], q["id"]))
                created += 1
        if idx >= len(qs):
            break
        if req.totalLimit > 0 and created >= req.totalLimit:
            break

    db.log_event("ok", "schedule",
                 f"自动排期 {created} 条（{len(pages)} 主页 × 每页每天 {per_day}"
                 f"{f'，跳过 {len(skipped_manual)} 个手动发布主页' if skipped_manual else ''}）")
    return {"ok": True, "created": created, "remaining": len(qs) - idx,
            "pages": len(pages), "perPagePerDay": per_day,
            "skippedManual": len(skipped_manual),
            "window": f"{R['windowStart']}:00–{R['windowEnd']}:00"}


@router.post("/schedule/capacity")
async def capacity(days: int = 3):
    R = rules()
    pages = db.q("SELECT health FROM pages")
    free = sum(1 for p in pages if p["health"] == "ok") if R["skipRestrictedPages"] else len(pages)
    qn = db.q1("SELECT COUNT(*) c FROM queue WHERE state='ready'")["c"]
    cap = days * free * R["perPagePerDay"]
    return {"days": days, "pagesAvailable": free, "perPagePerDay": R["perPagePerDay"],
            "capacity": cap, "queueReady": qn, "enough": qn <= cap,
            "overflow": max(0, qn - cap)}
