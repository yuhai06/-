"""发布 API：走 reels_composer 单链路，只认受理回执。

三条铁律：
  1. 只认 Meta 的「正在处理 Reels / Reels 已发布」，看不到回执判失败
  2. 失败绝不删素材
  3. 发布前校验 asset_id 与当前身份
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.adapters.facebook import FB, FBError
from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.publish")
router = APIRouter(tags=["publish"])

DEFAULT_CAPTION = """《{drama}》 {ep_title}
{hook}

{{LINK}}"""


class PublishItem(BaseModel):
    pageId: str
    assetId: str
    pageLabel: str = ""
    videoPath: str
    caption: str = ""
    # 新增：标题链接随机
    useRandomLink: bool = True
    useRandomTitle: bool = True
    referenceTitle: str = ""
    linkId: str = ""
    titleId: str = ""


class PublishReq(BaseModel):
    items: list[PublishItem]
    gapSec: int = 300
    deleteOnSuccess: bool = True
    keepOnFail: bool = True


def _build_caption(it: PublishItem) -> tuple[str, dict]:
    """组装最终文案：标题（随机或指定）+ 链接（随机或指定）。

    链接原样插入，不做任何改写。
    """
    from app.services import caption as cap

    meta: dict = {"linkId": None, "titleId": None,
                  "link": None, "title": None}

    # 标题
    if it.caption.strip():
        title = it.caption.strip()
        meta["title"] = title
    elif it.useRandomTitle:
        picked = cap.pick_caption(it.pageId, it.referenceTitle)
        title = picked.get("title") or ""
        meta["title"] = title
        meta["titleId"] = picked.get("titleId")
    else:
        title = it.referenceTitle or cap.REFERENCE_TITLE
        meta["title"] = title

    # 链接
    link = None
    if it.linkId:
        link = db.q1("SELECT * FROM promo_links WHERE id=?", (it.linkId,))
    if not link and it.useRandomLink:
        link = cap.pick_link(it.pageId)
    if link:
        meta["linkId"] = link["id"]
        meta["link"] = link["url"]

    body = title
    if link:
        # 链接原样放在标题后，单独一行
        body = f"{title}\n\n{link['url']}"

    # 标签按平台：FB 不加（默认），TK/IG 才加
    from app.services import platform_cfg as pc
    body = body + pc.hashtags()
    return body, meta


@router.post("/publish")
async def publish(req: PublishReq):
    from app.services import automation as au
    # 只观察模式下禁止一切写操作（发布是硬拦截，不是提示）
    if au.observe_only():
        raise HTTPException(403,
            "当前是「只观察不动作」模式，发布已被拦截。"
            "去 概览 → 全自动 里关掉「只观察」，再发布。")
    if not req.items:
        raise HTTPException(400, "items 为空")
    for it in req.items:
        if not Path(it.videoPath).exists():
            raise HTTPException(400, f"素材不存在: {it.videoPath}")

    env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "发布号环境未启动")

    # 组装文案（每条独立随机）
    prepared = []
    for it in req.items:
        caption, meta = _build_caption(it)
        prepared.append({"item": it, "caption": caption, "meta": meta})

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"{p['item'].pageLabel or p['item'].pageId} · "
                      f"{Path(p['item'].videoPath).name}",
              "state": "wait", "note": ""} for p in prepared]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,"
            "started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "publish", f"发布 {len(prepared)} 条", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps({"items": [p["meta"] for p in prepared]},
                        ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_publish(job_id, req, prepared, int(env["cdp_port"])))
    return {"ok": True, "jobId": job_id,
            "preview": [{"page": p["item"].pageLabel,
                         "title": p["meta"]["title"],
                         "link": p["meta"]["link"]} for p in prepared]}


async def _run_publish(job_id: str, req: PublishReq, prepared: list[dict],
                       port: int) -> None:
    steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))["steps"] or "[]")
    ok_n, fail_n = 0, 0
    env = db.q1("SELECT * FROM envs WHERE cdp_port=?", (port,))
    env_code = env["container_code"] if env else ""
    try:
        async with FB(port) as fb:
            await fb.assert_identity(settings.fb_publisher_cuser)
            for i, p in enumerate(prepared):
                it = p["item"]
                caption = p["caption"]
                meta = p["meta"]
                steps[i]["state"] = "run"
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False), job_id))
                try:
                    res = await fb.publish_reel(it.assetId, it.videoPath,
                                                caption, it.pageLabel,
                                                env_code=env_code, page_id=it.pageId)
                except FBError as e:
                    res = {"ok": False, "error": str(e), "stage": "fb"}

                # 跳脸 → 立即中止整个批次，不继续碰其它主页
                if res.get("guard"):
                    g = res["guard"]
                    steps[i].update(state="err", note=f"⚠ {g['message']}（已熔断）")
                    db.exec("UPDATE jobs SET steps=?,status='blocked',result=?,ended_at=?"
                            " WHERE id=?",
                            (json.dumps(steps, ensure_ascii=False),
                             json.dumps({"ok": ok_n, "fail": fail_n + 1,
                                        "guard": g}, ensure_ascii=False),
                             now_iso(), job_id))
                    db.log_event("err", "publish",
                                 f"检测到 {g['kind']}，批次立即中止：{g['message']}")
                    return

                if res.get("ok"):
                    ok_n += 1
                    steps[i].update(state="done", note=f"已受理（{res.get('acceptance')}）")
                    db.exec("UPDATE pages SET published=published+1 WHERE page_id=?",
                            (it.pageId,))
                    # 记录用了哪个链接 / 标题
                    if meta.get("linkId"):
                        from app.services import caption as cap
                        cap.mark_link_used(meta["linkId"])
                    db.log_event("ok", "publish",
                                 f"{it.pageLabel} 发布成功 · {res.get('acceptance')} "
                                 f"· link={meta.get('linkId') or '-'} "
                                 f"· title={meta.get('titleId') or '-'}")
                    if req.deleteOnSuccess:
                        try:
                            Path(it.videoPath).unlink()
                            steps[i]["note"] += " · 素材已删"
                        except Exception as e:
                            log.debug("unlink failed: %s", e)
                else:
                    fail_n += 1
                    steps[i].update(state="err",
                                    note=f"{res.get('error')} [{res.get('stage')}]")
                    db.log_event("warn", "publish",
                                 f"{it.pageLabel} 发布失败: {res.get('error')}")
                    # 失败绝不删素材
                db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False),
                         int((i + 1) / len(prepared) * 100), job_id))
                if i < len(prepared) - 1:
                    # 主页之间长间隔（拟人 + 降低关联风险）
                    from app.adapters import humanize as hz
                    await hz.human_delay("nav")
                    await asyncio.sleep(max(0, req.gapSec - int(hz.jitter(3, 7))))
        status = "done" if fail_n == 0 else ("blocked" if ok_n else "failed")
        db.exec("UPDATE jobs SET status=?,result=?,ended_at=? WHERE id=?",
                (status, json.dumps({"ok": ok_n, "fail": fail_n}), now_iso(), job_id))
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "publish", str(e)[:200])


@router.get("/publish/history")
async def history(limit: int = 50):
    rows = db.q("SELECT * FROM jobs WHERE kind='publish' ORDER BY created_at DESC LIMIT ?",
                (min(limit, 200),))
    return {"items": rows}


@router.get("/publish/caption-template")
async def caption_template():
    return {"template": DEFAULT_CAPTION,
            "vars": ["drama", "ep", "ep_title", "hook"]}


class CaptionReq(BaseModel):
    template: str
    drama: str = ""
    ep: str = ""
    ep_title: str = ""
    hook: str = ""


@router.post("/publish/render-caption")
async def render_caption(req: CaptionReq):
    out = req.template
    for k, v in {"drama": req.drama, "ep": req.ep,
                 "ep_title": req.ep_title, "hook": req.hook}.items():
        out = out.replace("{" + k + "}", v)
    return {"caption": out}
