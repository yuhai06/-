"""第三方对接 API：连通性测试 + 模型/技能/插件清单。

模型与技能的「实际来源」：
    · 模型：Our Free Model 插件（$DSH_HOME/our-free-model/catalog.json）
            + WorkBuddy 插件（本机 WorkBuddy 登录态）
    · 技能：$DSH_HOME/skills 下的 SKILL.md
    · 插件：profile 的 node_modules/dsh-*/
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from pathlib import Path
from typing import Any

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.api.integrations")
router = APIRouter(tags=["integrations"])

DSH_HOME = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
PROFILE = os.environ.get("DSH_PROFILE", "desktop")


# ---------------- 静态定义 ----------------
INTEGRATIONS = [
    {"id": "hubstudio", "kind": "指纹浏览器", "label": "Hubstudio",
     "desc": "启动/关闭环境、拿 CDP 端口、读环境清单", "endpoint": settings.hubstudio_api},
    {"id": "clash", "kind": "网络出口", "label": "Clash / 代理池",
     "desc": "读当前出口 IP 与归属地，判定机房/住宅", "endpoint": settings.clash_api},
    {"id": "graph", "kind": "官方接口", "label": "Meta Graph API",
     "desc": "insights 备用通道；发布仍走浏览器自动化", "endpoint": "graph.facebook.com/v21.0"},
    {"id": "webhook", "kind": "通知", "label": "出站 Webhook",
     "desc": "任务完成/失败推送到企业微信、飞书", "endpoint": ""},
    {"id": "storage", "kind": "素材", "label": "对象存储",
     "desc": "S3 兼容存储归档截图与索引", "endpoint": ""},
    {"id": "ffmpeg", "kind": "本地工具", "label": "FFmpeg",
     "desc": "探规格、转码、去重扰动", "endpoint": "bundled"},
]


@router.get("/integrations")
async def list_integrations():
    saved = {r["id"]: r for r in db.q("SELECT * FROM integrations")}
    out = []
    for it in INTEGRATIONS:
        s = saved.get(it["id"], {})
        out.append({**it,
                    "enabled": bool(s.get("enabled") or 0),
                    "state": s.get("state") or "unconfigured",
                    "lastTest": s.get("last_test"),
                    "lastError": s.get("last_error")})
    return {"items": out}


class IntegReq(BaseModel):
    id: str
    enabled: bool | None = None
    config: dict | None = None


@router.post("/integrations")
async def save_integration(req: IntegReq):
    defn = next((x for x in INTEGRATIONS if x["id"] == req.id), None)
    if not defn:
        raise HTTPException(404, "未知对接")
    now = now_iso()
    ex = db.q1("SELECT * FROM integrations WHERE id=?", (req.id,))
    cfg = json.dumps(req.config or {}, ensure_ascii=False)
    if ex:
        db.exec("UPDATE integrations SET enabled=?, config=?, updated_at=? WHERE id=?",
                (1 if (req.enabled if req.enabled is not None else bool(ex["enabled"])) else 0,
                 cfg if req.config is not None else ex["config"], now, req.id))
    else:
        db.exec("INSERT INTO integrations(id,kind,label,enabled,config,state,updated_at)"
                " VALUES(?,?,?,?,?,?,?)",
                (req.id, defn["kind"], defn["label"],
                 1 if req.enabled else 0, cfg, "configured", now))
    return {"ok": True}


@router.post("/integrations/{iid}/test")
async def test_integration(iid: str):
    now = now_iso()
    res: dict[str, Any]
    if iid == "hubstudio":
        from app.adapters.hubstudio import hub, HubstudioError
        try:
            st = await hub.status()
            res = {"ok": True, "containers": len(st),
                   "running": sum(1 for v in st.values() if v["status"] == "running")}
        except HubstudioError as e:
            res = {"ok": False, "error": str(e)}
    elif iid == "clash":
        try:
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get(f"{settings.clash_api}/proxies",
                                headers={"Authorization": f"Bearer {settings.clash_secret}"})
            res = {"ok": r.status_code == 200,
                   "proxies": len((r.json().get("proxies") or {})) if r.status_code == 200 else 0}
        except Exception as e:
            res = {"ok": False, "error": str(e)[:150]}
    elif iid == "ffmpeg":
        try:
            p = proc.run(["ffmpeg", "-version"], capture_output=True, text=True,
                               timeout=15, encoding="utf-8", errors="replace")
            first = (p.stdout or "").splitlines()[0] if p.stdout else ""
            res = {"ok": p.returncode == 0, "version": first[:120]}
        except Exception as e:
            res = {"ok": False, "error": str(e)[:150]}
    elif iid == "webhook":
        ex = db.q1("SELECT * FROM integrations WHERE id='webhook'")
        cfg = json.loads((ex or {}).get("config") or "{}")
        url = cfg.get("url", "")
        if not url:
            res = {"ok": False, "error": "未配置 webhook URL"}
        else:
            try:
                async with httpx.AsyncClient(timeout=10) as c:
                    r = await c.post(url, json={"msgtype": "text",
                                               "text": {"content": "雨海工作台连通性测试"}})
                res = {"ok": r.status_code < 400, "status": r.status_code}
            except Exception as e:
                res = {"ok": False, "error": str(e)[:150]}
    else:
        res = {"ok": False, "error": "该对接暂无自动测试"}

    state = "connected" if res.get("ok") else "error"
    db.exec("UPDATE integrations SET state=?,last_test=?,last_error=?,updated_at=? WHERE id=?",
            (state, now, res.get("error"), now, iid))
    if not db.q1("SELECT 1 FROM integrations WHERE id=?", (iid,)):
        defn = next((x for x in INTEGRATIONS if x["id"] == iid), {"kind": "", "label": iid})
        db.exec("INSERT INTO integrations(id,kind,label,enabled,config,state,last_test,"
                "last_error,updated_at) VALUES(?,?,?,0,'{}',?,?,?,?)",
                (iid, defn["kind"], defn["label"], state, now, res.get("error"), now))
    return res


# ---------------- 模型 ----------------
@router.get("/integrations/models")
async def models():
    """从 DSH 插件读可用模型清单。"""
    out = []

    # Our Free Model
    cat = DSH_HOME / "our-free-model" / "catalog.json"
    if cat.exists():
        try:
            d = json.loads(cat.read_text(encoding="utf-8"))
            rows = d.get("kiloRows") or []
            ms = []
            for r in rows:
                ms.append({"id": r.get("id"), "name": r.get("name"),
                           "vision": bool(r.get("vision")),
                           "ctx": r.get("contextWindow"),
                           "wire": r.get("wire")})
            out.append({"id": "ms-free", "name": "Our Free Model",
                        "kind": "plugin", "plugin": "dsh-our-free-model",
                        "version": _plugin_version("dsh-our-free-model"),
                        "on": True, "models": ms})
        except Exception as e:
            log.debug("read free model catalog failed: %s", e)

    # WorkBuddy：读 models.json 占位（真实目录由插件在运行时拉）
    wb = Path(os.environ.get("APPDATA", "")) / ".." / "Local" / "WorkBuddy" / "models.json"
    out.append({"id": "ms-wb", "name": "WorkBuddy", "kind": "plugin",
                "plugin": "dsh-connect-workbuddy",
                "version": _plugin_version("dsh-connect-workbuddy"),
                "on": _plugin_enabled("dsh-connect-workbuddy"),
                "models": _workbuddy_models()})

    for pid, label, plug in (("ms-agnes", "Agnes 多模态", "dsh-agnes-multimodal"),
                             ("ms-muse", "Muse 视频", "dsh-muse-video")):
        out.append({"id": pid, "name": label, "kind": "plugin", "plugin": plug,
                    "version": _plugin_version(plug),
                    "on": _plugin_enabled(plug), "models": []})

    out.append({"id": "ms-api", "name": "自定义 API", "kind": "api",
                "plugin": None, "version": None, "on": True,
                "models": []})
    return {"items": out}


def _plugin_dir(name: str) -> Path:
    return DSH_HOME / "profiles" / PROFILE / "node_modules" / name


def _plugin_version(name: str) -> str:
    p = _plugin_dir(name) / "package.json"
    if not p.exists():
        return ""
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("version", "")
    except Exception:
        return ""


def _plugin_enabled(name: str) -> bool:
    # 插件目录存在即视为已安装；启用状态在 cordis.patch.yml 里
    return _plugin_dir(name).exists()


def _workbuddy_models() -> list[dict]:
    p = Path(os.environ.get("LOCALAPPDATA", "")) / "WorkBuddy" / "models.json"
    if not p.exists():
        p = Path.home() / ".workbuddy" / "models.json"
    if not p.exists():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []
    if isinstance(d, list):
        return [{"id": m.get("id") or m.get("model"), "name": m.get("name") or m.get("id"),
                 "vision": bool(m.get("vision")), "ctx": m.get("contextWindow")}
                for m in d if isinstance(m, dict)][:30]
    return []


# ---------------- 技能 ----------------
@router.get("/integrations/dsh")
async def dsh_status():
    """DSH 模型注入状态：网关、模型、插件、技能。"""
    from app.services import dsh_models as dm
    info = dm.dsh_available()
    gw = dm.gateway_info()
    info["gateway"] = {
        "ok": gw["ok"], "base": gw["base"], "port": gw.get("port"),
        "count": gw["count"], "error": gw.get("error"),
    }
    info["selected"] = dm.get_selection()
    info["endpoint"] = dm.resolve_endpoint()
    return info


@router.get("/integrations/dsh/test")
async def dsh_test(model: str = ""):
    """实测某个模型能不能用（真发一次请求）。"""
    from app.services import dsh_models as dm
    import httpx
    gw = dm.gateway_info()
    if not gw["ok"]:
        return {"ok": False, "error": gw.get("error")}
    mid = model or dm.default_model()
    try:
        async with httpx.AsyncClient(timeout=45) as c:
            r = await c.post(
                gw["base"] + "/v1/chat/completions",
                headers={"Authorization": f"Bearer {gw['key']}",
                         "Content-Type": "application/json"},
                json={"model": mid, "max_tokens": 10,
                      "messages": [{"role": "user", "content": "say OK only"}]})
        if r.status_code != 200:
            return {"ok": False, "model": mid, "status": r.status_code,
                    "error": r.text[:200]}
        d = r.json()
        txt = ((d.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        return {"ok": bool(txt.strip()), "model": mid, "reply": txt.strip()[:60]}
    except Exception as e:
        return {"ok": False, "model": mid, "error": str(e)[:200]}


class ModelSelReq(BaseModel):
    model: str


@router.post("/integrations/dsh/model")
async def dsh_select_model(req: ModelSelReq):
    from app.services import dsh_models as dm
    r = dm.save_selection(req.model)
    db.log_event("ok", "integrations", f"默认模型设为 {req.model}")
    return r


@router.get("/integrations/dsh/models")
async def dsh_models():
    from app.services import dsh_models as dm
    return {"items": dm.free_models(), "selected": dm.get_selection()}


@router.get("/integrations/dsh/channels")
async def dsh_channels():
    """按渠道分组的模型清单（只含账号接入，排除插件免费池和 EAC）。"""
    from app.services import dsh_models as dm
    chs = dm.channels()
    return {
        "items": chs,
        "count": len(chs),
        "totalModels": sum(len(g["models"]) for g in chs),
        "excluded": sorted(dm.EXCLUDE_CHANNELS),
        "note": "已排除 our-free-model（插件匿名免费池）和 eac/magpie（付费转售）",
    }


@router.get("/integrations/dsh/plugins")
async def dsh_plugins():
    """插件清单 + 每个插件对应的模型渠道。

    映射是手工维护的（插件名和渠道名不是规则对应的）：
        dsh-connect-workbuddy  -> workbuddy / workbuddy-global / buddy
        dsh-our-free-model     -> our-free-model（已排除，仅展示）
        dsh-muse-video         -> muse
        dsh-agnes-multimodal   -> magpie（Agnes 走 magpie 通道，已排除）
        dsh-codex-bridge       -> 无（走本地 CLI，不经网关）
    """
    from app.services import dsh_models as dm
    info = dm.dsh_available()
    chs = {g["channel"]: g for g in info["channels"]}
    all_chs = {g["channel"]: g for g in dm.channels()}

    # 插件 → 渠道 显式映射
    PLUGIN_CHANNELS = {
        "dsh-connect-workbuddy": ["workbuddy", "workbuddy-global", "buddy"],
        "dsh-our-free-model": ["our-free-model", "our-free-model-region"],
        "dsh-muse-video": ["muse"],
        "dsh-agnes-multimodal": ["magpie", "magpie-responses"],
        "dsh-codex-bridge": [],
        "dsh-workbuddy-review": ["workbuddy", "workbuddy-global"],
    }

    out = []
    for p in info["plugins"]:
        names = PLUGIN_CHANNELS.get(p["name"], [])
        matched = []
        excluded_hit = []
        for ch in names:
            if ch in chs:
                g = chs[ch]
                matched.append({"channel": ch, "label": g["label"],
                                "models": len(g["models"]),
                                "freeCount": g["freeCount"],
                                "excluded": False})
            elif ch in all_chs:
                g = all_chs[ch]
                excluded_hit.append({"channel": ch, "label": g["label"],
                                     "models": len(g["models"]),
                                     "excluded": True})
        out.append({
            **p,
            "channels": matched,
            "excludedChannels": excluded_hit,
            "usable": bool(matched),
            "note": ("可用于 AI 分析" if matched else
                     "该插件的渠道已被排除（免费池/付费转售）" if excluded_hit
                     else "不经网关，无需接入"),
        })
    return {"items": out, "count": len(out)}


@router.get("/integrations/skills")
async def skills():
    root = DSH_HOME / "skills"
    out = []
    if root.exists():
        for d in sorted(root.iterdir()):
            if not d.is_dir():
                continue
            md = d / "SKILL.md"
            cam = d / "SKILL.md"
            if cam.exists():
                md = cam
            if not md.exists():
                continue
            try:
                head = md.read_text(encoding="utf-8", errors="replace")[:2000]
            except Exception:
                head = ""
            name = re.search(r"^name:\s*(.+)$", head, re.M)
            desc = re.search(r"^description:\s*(.+)$", head, re.M)
            out.append({
                "id": d.name,
                "name": name.group(1).strip() if name else d.name,
                "desc": (desc.group(1).strip()[:220] if desc else head.split("\n")[0][:120]),
                "path": str(md),
                "size": md.stat().st_size,
            })
    return {"items": out}


# ---------------- 插件 ----------------
@router.get("/integrations/plugins")
async def plugins():
    root = DSH_HOME / "profiles" / PROFILE / "node_modules"
    out = []
    if root.exists():
        for d in sorted(root.iterdir()):
            if not d.name.startswith("dsh-"):
                continue
            pj = d / "package.json"
            ver, desc = "", ""
            if pj.exists():
                try:
                    j = json.loads(pj.read_text(encoding="utf-8"))
                    ver = j.get("version", "")
                    desc = (j.get("description") or "")[:200]
                except Exception:
                    pass
            out.append({"id": d.name, "name": d.name, "ver": ver, "desc": desc,
                        "on": True})
    return {"items": out}
