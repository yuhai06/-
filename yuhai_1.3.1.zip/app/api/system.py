"""系统：健康检查、概览统计、事件流、配置。"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, Body
from pydantic import BaseModel

from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.system")
router = APIRouter(tags=["system"])


@router.get("/system/health")
async def health():
    from app.adapters.hubstudio import hub, HubstudioError
    from app.db import db as _db
    hub_ok, hub_err = True, None
    try:
        await hub.status()
    except HubstudioError as e:
        hub_ok, hub_err = False, str(e)
    return {
        "ok": True,
        "version": settings.VERSION,
        "port": settings.port,
        "data_dir": str(settings.data_dir),
        "db": str(settings.db_path),
        "hubstudio": {"ok": hub_ok, "error": hub_err},
        "frontend": str(settings.frontend_dir),
        "ts": now_iso(),
    }


@router.get("/system/summary")
async def summary():
    pages = db.q("SELECT * FROM pages")
    lib = db.q("SELECT * FROM library")
    q = db.q("SELECT * FROM queue WHERE state IN ('ready','scheduled')")
    sch = db.q("SELECT * FROM schedule")
    jobs = db.q("SELECT * FROM jobs WHERE status IN ('running','queued','blocked')")
    envs = db.q("SELECT * FROM envs")
    return {
        "pages": len(pages),
        "pagesHealthy": sum(1 for p in pages if p["health"] == "ok"),
        "pagesRestricted": sum(1 for p in pages if p["health"] != "ok"),
        "totalViews": sum(int(p.get("views_30d") or 0) for p in pages),
        "totalFollowers": sum(int(p.get("followers") or 0) for p in pages),
        "published": sum(int(p.get("published") or 0) for p in pages),
        "authzPending": db.q1(
            "SELECT COUNT(*) c FROM pages p WHERE NOT EXISTS "
            "(SELECT 1 FROM page_roles r WHERE r.page_id=p.page_id AND r.state='active')"
        )["c"],
        "libReady": sum(1 for x in lib if x["state"] == "ready"),
        "libBlocked": sum(1 for x in lib if x["state"] == "blocked"),
        "libMb": round(sum(float(x.get("size_mb") or 0) for x in lib)),
        "queueReady": len(q),
        "queueMb": round(sum(float(x.get("size_mb") or 0) for x in q)),
        "schedulePlanned": sum(1 for s in sch if s["state"] == "planned"),
        "scheduleBlocked": sum(1 for s in sch if s["state"] == "blocked"),
        "runningJobs": sum(1 for j in jobs if j["status"] == "running"),
        "alerts": sum(1 for j in jobs if j["status"] == "blocked"),
        "envsTotal": len(envs),
        "envsRunning": sum(1 for e in envs if e["status"] == "running"),
    }


@router.get("/system/events")
async def events(limit: int = 200, level: str = ""):
    if level and level != "all":
        rows = db.q("SELECT * FROM events WHERE level=? ORDER BY id DESC LIMIT ?",
                    (level, min(limit, 1000)))
    else:
        rows = db.q("SELECT * FROM events ORDER BY id DESC LIMIT ?", (min(limit, 1000),))
    return {"items": rows}


@router.get("/system/config")
async def get_config():
    return {
        "port": settings.port,
        "dataDir": str(settings.data_dir),
        "dbPath": str(settings.db_path),
        "frontendDir": str(settings.frontend_dir),
        "hubstudioApi": settings.hubstudio_api,
        "clashApi": settings.clash_api,
        "reelsEnvDir": settings.reels_env_dir,
        "nodeCommand": settings.node_command(),
        "assetRoots": [str(p) for p in settings.asset_roots],
        "sourceRoots": [str(p) for p in settings.source_roots],
        "fbPublisherCuser": settings.fb_publisher_cuser,
        "fbBackupCuser": settings.fb_backup_cuser,
    }


class ConfigPatch(BaseModel):
    hubstudioApi: str | None = None
    clashApi: str | None = None
    clashSecret: str | None = None
    reelsEnvDir: str | None = None
    nodeExe: str | None = None
    assetRoots: list[str] | None = None
    sourceRoots: list[str] | None = None


@router.post("/system/config")
async def set_config(patch: ConfigPatch):
    raw = patch.model_dump(exclude_none=True)
    settings.save_user_config(raw)
    return {"ok": True, "saved": list(raw.keys())}
