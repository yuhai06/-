"""全自动总控 API。"""
from __future__ import annotations

import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db
from app.services import automation as au

log = logging.getLogger("yuhai.api.auto")
router = APIRouter(tags=["auto"])


@router.get("/auto")
async def get_status():
    """全自动总控状态：总开关 + 8 项受管 + 4 项手动。"""
    return au.status()


class MasterReq(BaseModel):
    enabled: bool


@router.post("/auto/master")
async def set_master(req: MasterReq):
    """全自动总开关。不含排期和发布。"""
    return await au.set_master(req.enabled)


class ItemReq(BaseModel):
    key: str
    enabled: bool


@router.post("/auto/item")
async def set_item(req: ItemReq):
    """单项开关。"""
    r = await au.set_item(req.key, req.enabled)
    if isinstance(r, dict) and r.get("ok") is False:
        return r
    return r


@router.post("/auto/stop")
async def stop_all():
    """一键急停（关总闸 + 开只观察）。"""
    return await au.emergency_stop()


@router.get("/auto/items")
async def list_items():
    """受管项清单（不含状态）。"""
    return {"managed": au.ITEMS, "manualOnly": au.MANUAL_ONLY,
            "quickActions": au.QUICK_ACTIONS}


class QuickReq(BaseModel):
    key: str


@router.post("/auto/quick")
async def run_quick(req: QuickReq):
    """手动点一下立刻跑一轮（不受总开关限制）。

    key: comments | metrics | guard
    评论和采集可能跑几分钟，所以立刻返回 jobId，前端轮询进度。
    """
    import asyncio
    import json
    import uuid
    from app.db import db, now_iso

    known = {q["key"] for q in au.QUICK_ACTIONS}
    if req.key not in known:
        raise HTTPException(400, f"未知动作 {req.key}")

    job_id = "job-" + uuid.uuid4().hex[:12]
    name = next(q["name"] for q in au.QUICK_ACTIONS if q["key"] == req.key)
    steps = [{"name": name, "state": "run", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at,started_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "auto", f"手动触发 · {name}", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps({"key": req.key}, ensure_ascii=False),
             now_iso(), now_iso()))

    async def _bg() -> None:
        try:
            r = await au.run_quick(req.key)
            db.exec("UPDATE jobs SET status='done',progress=100,result=?,"
                    "ended_at=? WHERE id=?",
                    (json.dumps(r, ensure_ascii=False, default=str), now_iso(), job_id))
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id, "action": req.key,
            "observeOnly": au.observe_only(),
            "note": "后台执行中，进度看任务列表"}
