"""热更新 API：检查版本、应用更新包、回滚。"""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from fastapi import APIRouter, HTTPException, UploadFile, File
from pydantic import BaseModel

from app.db import db
from app.services import updater as up

log = logging.getLogger("yuhai.api.update")
router = APIRouter(tags=["update"])


@router.get("/update/check")
async def check_update(remote: str = ""):
    """检查有没有新版本。

    不传 remote：扫本地 _updates 目录里的 zip 包。
    传 remote：从远程 manifest.json 拉版本信息。
    """
    if remote:
        return await asyncio.to_thread(up.check_remote, remote)
    return await asyncio.to_thread(up.check_local)


@router.post("/update/auto")
async def auto_update(restart: bool = True, remote: str = ""):
    """一键更新：检查 → 下载（如需）→ 应用 → 重启。

    不需要手动选 zip。
    """
    # ① 检查
    info = (await asyncio.to_thread(up.check_remote, remote) if remote
            else await asyncio.to_thread(up.check_local))
    if not info.get("ok"):
        raise HTTPException(400, info.get("error") or "检查失败")
    if not info.get("hasUpdate"):
        return {"ok": True, "hasUpdate": False,
                "current": info.get("current"),
                "note": "已是最新版本"}

    pkg = info.get("package") or ""
    if not pkg:
        raise HTTPException(400, "找不到可用的更新包")

    # ② 远程包先下载
    if remote and pkg.startswith("http"):
        d = await asyncio.to_thread(up.download_package, pkg)
        if not d.get("ok"):
            raise HTTPException(400, d.get("error") or "下载失败")
        pkg = d["path"]

    # ③ 应用
    r = await asyncio.to_thread(up.apply_package, Path(pkg))
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "应用失败")
    db.log_event("info", "update",
                 f"一键更新到 {r.get('version')}（{r.get('files')} 文件）")

    if restart:
        asyncio.create_task(_restart_later())
    return {**r, "hasUpdate": True, "from": info.get("current"),
            "restart": restart,
            "note": "已更新到 " + str(r.get("version")) + ("，3 秒后重启" if restart else "")}


@router.get("/update/status")
async def update_status():
    """当前版本 + 热更新目录状态 + 可用备份。"""
    ver = up.current_version()
    local = up.scan_local()
    bak_root = up.data_dir() / "_backup_update"
    backups = []
    if bak_root.exists():
        for d in sorted(bak_root.iterdir(), reverse=True):
            if d.is_dir():
                backups.append({"name": d.name, "path": str(d)})
    return {
        "ok": True,
        "version": ver.get("version"),
        "updatedAt": ver.get("updatedAt"),
        "fileCount": len(local),
        "appDir": str(up.app_dir()),
        "hasExtApp": (up.app_dir() / "app" / "main.py").exists(),
        "hasExtFrontend": (up.app_dir() / "frontend" / "index.html").exists(),
        "backups": backups[:5],
        "hotCount": {
            "app": sum(1 for k in local if k.startswith("app/")),
            "frontend": sum(1 for k in local if k.startswith("frontend/")),
        },
    }


@router.post("/update/package")
async def upload_package(file: UploadFile = File(...)):
    """上传更新包（zip），先校验不落盘。"""
    tmp = up.data_dir() / "_incoming.zip"
    try:
        with open(tmp, "wb") as f:
            while True:
                chunk = await file.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
        v = up.verify_package(tmp)
        if not v.get("ok"):
            tmp.unlink(missing_ok=True)
            raise HTTPException(400, v.get("error") or "更新包无效")
        return {"ok": True, "version": v.get("version"),
                "fileCount": v.get("fileCount"), "path": str(tmp),
                "note": "已校验，点「应用更新」才会真正覆盖"}
    except HTTPException:
        raise
    except Exception as e:
        tmp.unlink(missing_ok=True)
        raise HTTPException(500, f"上传失败: {e}")


@router.post("/update/apply")
async def apply_update(restart: bool = True):
    """应用已上传的更新包。"""
    tmp = up.data_dir() / "_incoming.zip"
    if not tmp.exists():
        raise HTTPException(400, "没有待应用的更新包，请先上传")
    r = await asyncio.to_thread(up.apply_package, tmp)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "应用失败")
    try:
        tmp.unlink()
    except Exception:
        pass
    db.log_event("info", "update",
                 f"热更新到 {r.get('version')}（{r.get('files')} 个文件）")
    if restart:
        # 3 秒后重启（给前端返回响应的时间）
        asyncio.create_task(_restart_later())
    return {**r, "restart": restart,
            "note": "已更新" + ("，3 秒后自动重启" if restart else "，请手动重启程序")}


async def _restart_later() -> None:
    await asyncio.sleep(3)
    _restart()


def _restart() -> None:
    """重启当前程序。"""
    try:
        if getattr(sys, "frozen", False):
            exe = Path(sys.executable)
        else:
            exe = None
        if exe and exe.exists():
            # 用脚本延迟重启，避免自己杀自己
            bat = up.data_dir() / "_restart.bat"
            bat.write_text(
                "@echo off\r\n"
                "timeout /t 2 /nobreak >nul\r\n"
                f'start "" "{exe}"\r\n'
                "del \"%~f0\"\r\n",
                encoding="utf-8")
            subprocess.Popen(["cmd.exe", "/c", str(bat)],
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            os._exit(0)
    except Exception as e:
        log.warning("restart failed: %s", e)


class RollbackReq(BaseModel):
    backup: str = ""      # 备份目录名，空=最近一份


@router.post("/update/rollback")
async def rollback(req: RollbackReq):
    """回滚到某个备份。"""
    root = up.data_dir() / "_backup_update"
    if not root.exists():
        raise HTTPException(400, "没有可用备份")
    dirs = sorted([d for d in root.iterdir() if d.is_dir()],
                  key=lambda d: d.name, reverse=True)
    target = None
    if req.backup:
        cand = root / req.backup
        if cand.is_dir():
            target = cand
    elif dirs:
        target = dirs[0]
    if not target:
        raise HTTPException(404, "备份不存在")

    base = up.app_dir()
    for top in ("app", "frontend"):
        src = target / top
        if not src.exists():
            continue
        dst = base / top
        try:
            if dst.exists():
                shutil.rmtree(dst, ignore_errors=True)
            shutil.copytree(src, dst)
        except Exception as e:
            raise HTTPException(500, f"回滚 {top} 失败: {e}")
    db.log_event("warn", "update", f"回滚到备份 {target.name}")
    asyncio.create_task(_restart_later())
    return {"ok": True, "backup": target.name, "note": "已回滚，3 秒后重启"}


@router.get("/update/backups")
async def list_backups():
    root = up.data_dir() / "_backup_update"
    out = []
    if root.exists():
        for d in sorted(root.iterdir(), key=lambda x: x.name, reverse=True):
            if not d.is_dir():
                continue
            n = sum(1 for _ in d.rglob("*") if _.is_file())
            out.append({"name": d.name, "path": str(d), "files": n})
    return {"items": out}
