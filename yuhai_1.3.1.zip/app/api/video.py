"""视频制作 API：内置 ffmpeg，不依赖外部程序。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import video_maker as vm

log = logging.getLogger("yuhai.api.video")
router = APIRouter(tags=["video"])


@router.get("/video/env")
async def video_env():
    """检查内置 ffmpeg 是否可用。"""
    return vm.env_check()


class ProbeReq(BaseModel):
    path: str


@router.post("/video/probe")
async def probe(req: ProbeReq):
    if not Path(req.path).exists():
        raise HTTPException(404, "文件不存在")
    return {"ok": True, **vm.probe(req.path)}


class OpReq(BaseModel):
    op: str                     # clip | vertical | speed | subtitle | normalize | concat
    src: str
    start: float = 0
    end: float = 0
    speed: float = 1.0
    text: str = ""
    fontSize: int = 42
    color: str = "white"
    lufs: float = -14
    ratio: str = "9:16"
    paths: list[str] = []
    name: str = ""


@router.post("/video/op")
async def single_op(req: OpReq):
    """单个操作（同步执行，短视频几秒就好）。"""
    if not Path(req.src).exists():
        raise HTTPException(404, "源文件不存在")
    op = req.op
    if op == "clip":
        r = vm.clip(req.src, req.start, req.end, req.name)
    elif op == "vertical":
        r = vm.to_vertical(req.src, req.name, req.ratio)
    elif op == "speed":
        r = vm.change_speed(req.src, req.speed, req.name)
    elif op == "subtitle":
        r = vm.burn_subs(req.src, req.text, req.name, req.fontSize, req.color)
    elif op == "normalize":
        r = vm.normalize_audio(req.src, req.lufs, req.name)
    elif op == "concat":
        r = vm.concat([req.src] + req.paths, req.name)
    else:
        raise HTTPException(400, f"未知操作 {op}")
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "执行失败")
    return {"ok": True, "path": r["path"], "info": vm.probe(r["path"])}


class MakeReq(BaseModel):
    src: str
    steps: list[dict] = []
    title: str = ""


@router.post("/video/make")
async def make(req: MakeReq):
    """一键出片（多步骤组合，后台任务）。"""
    if not Path(req.src).exists():
        raise HTTPException(404, "源文件不存在")
    if not req.steps:
        raise HTTPException(400, "steps 不能为空")

    env = vm.env_check()
    if not env["ok"]:
        raise HTTPException(500, f"ffmpeg 不可用：{env.get('error') or env['ffmpeg']}")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": s.get("name") or s.get("op"), "state": "wait", "note": ""}
             for s in req.steps]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "video", req.title or f"出片 {Path(req.src).name}",
             "queued", 0, json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))
    asyncio.create_task(vm.make_video(job_id, req.src, req.model_dump()))
    return {"ok": True, "jobId": job_id}


class BatchReq(BaseModel):
    sources: list[str] = []
    template: dict = {}          # 对每个源都套用同一套 steps
    title: str = ""


@router.post("/video/batch")
async def batch(req: BatchReq):
    """批量出片：同一套模板套多个源。"""
    if not req.sources:
        raise HTTPException(400, "sources 不能为空")
    if not req.template.get("steps"):
        raise HTTPException(400, "template.steps 不能为空")

    ids = []
    for src in req.sources:
        if not Path(src).exists():
            continue
        job_id = "job-" + uuid.uuid4().hex[:12]
        steps = [{"name": s.get("name") or s.get("op"), "state": "wait", "note": ""}
                 for s in req.template["steps"]]
        db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
                "created_at) VALUES(?,?,?,?,?,?,?,?)",
                (job_id, "video", f"批量出片 {Path(src).name}", "queued", 0,
                 json.dumps(steps, ensure_ascii=False),
                 json.dumps({"src": src, **req.template}, ensure_ascii=False),
                 now_iso()))
        asyncio.create_task(vm.make_video(job_id, src, req.template))
        ids.append(job_id)
        await asyncio.sleep(0.3)
    return {"ok": True, "jobs": ids, "count": len(ids)}


# ---------------- 可选的模型辅助（只生成文案，不参与合成）----------------
class CaptionReq(BaseModel):
    title: str = ""
    drama: str = ""
    model: str = ""
    n: int = 3


@router.post("/video/caption")
async def gen_caption(req: CaptionReq):
    """用模型生成发布文案（可选）。视频合成完全不依赖模型。"""
    from app.services import caption as cap
    ref = req.title or f"《{req.drama}》 高能片段"
    r = await cap.generate_titles(ref, req.n, req.model, req.drama)
    return {"ok": True, "titles": r["titles"], "source": r["source"],
            "note": "模型只生成文案，视频合成用内置 ffmpeg"}


@router.get("/video/templates")
async def templates():
    """预设出片模板。"""
    return {"items": [
        {"id": "reels", "name": "Reels 标准（竖屏 + 归一）",
         "steps": [{"op": "vertical", "ratio": "9:16", "name": "转竖屏"},
                   {"op": "normalize", "lufs": -14, "name": "响度归一"}]},
        {"id": "clip_only", "name": "只切片",
         "steps": [{"op": "clip", "start": 0, "end": 45, "name": "截取 45s"}]},
        {"id": "fast", "name": "快节奏（1.1x + 竖屏）",
         "steps": [{"op": "speed", "speed": 1.1, "name": "加速 1.1x"},
                   {"op": "vertical", "ratio": "9:16", "name": "转竖屏"},
                   {"op": "normalize", "lufs": -14, "name": "归一"}]},
        {"id": "full", "name": "完整（切片 + 竖屏 + 字幕 + 归一）",
         "steps": [{"op": "clip", "start": 0, "end": 50, "name": "截取"},
                   {"op": "vertical", "ratio": "9:16", "name": "转竖屏"},
                   {"op": "subtitle", "text": "", "name": "字幕"},
                   {"op": "normalize", "lufs": -14, "name": "归一"}]},
    ]}


@router.get("/video/browse")
async def browse(path: str = ""):
    """浏览文件夹，选多个视频。

    不传 path 时列出素材根目录；传了就列该目录下的视频和子目录。
    """
    from app.config import settings
    from app import paths as _paths
    roots = [settings.library_root, _paths.output_root(), *_paths.asset_roots()]
    base = Path(path) if path else None
    if base is None:
        for r in roots:
            if r.exists():
                base = r
                break
    if base is None or not base.exists():
        return {"items": [], "path": str(base or ""), "error": "目录不存在"}

    dirs, files = [], []
    try:
        for f in sorted(base.iterdir()):
            if f.is_dir():
                n_vid = len([x for x in f.glob("*.mp4")])
                n_sub = len([x for x in f.iterdir() if x.is_dir()])
                dirs.append({"name": f.name, "path": str(f),
                             "videos": n_vid, "subdirs": n_sub})
            elif f.suffix.lower() in (".mp4", ".mov", ".mkv"):
                try:
                    size = round(f.stat().st_size / 1048576, 1)
                except Exception:
                    size = 0
                files.append({"name": f.name, "path": str(f), "sizeMb": size})
    except Exception as e:
        return {"items": [], "path": str(base), "error": str(e)[:200]}

    return {
        "path": str(base),
        "parent": str(base.parent) if base.parent != base else "",
        "dirs": dirs,
        "files": files,
        "totalVideos": sum(d["videos"] for d in dirs) + len(files),
    }


class ScanReq(BaseModel):
    dirs: list[str] = []
    recursive: bool = True


@router.post("/video/scan")
async def scan_videos(req: ScanReq):
    """扫多个文件夹，返回所有视频（递归）。"""
    out = []
    for d in req.dirs:
        p = Path(d)
        if not p.exists():
            continue
        it = p.rglob("*.mp4") if req.recursive else p.glob("*.mp4")
        for f in it:
            try:
                out.append({"name": f.name, "path": str(f),
                            "sizeMb": round(f.stat().st_size / 1048576, 1),
                            "dir": str(f.parent)})
            except Exception:
                pass
    return {"items": out, "count": len(out),
            "totalMb": round(sum(x["sizeMb"] for x in out), 1)}


@router.get("/video/jobs")
async def video_jobs(limit: int = 50):
    rows = db.q("SELECT * FROM jobs WHERE kind='video' ORDER BY created_at DESC LIMIT ?",
                (min(limit, 200),))
    for r in rows:
        for k in ("steps", "payload", "result"):
            if r.get(k):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
    return {"items": rows}
