"""邮件 API：多通道（IMAP / API / Webhook / 无头浏览器 / 手动）。"""
from __future__ import annotations

import asyncio
import json
import logging
import secrets
import uuid
from typing import Any

from fastapi import APIRouter, Body, HTTPException, Request
from pydantic import BaseModel

from app.adapters import imap_mail
from app.db import db, now_iso

log = logging.getLogger("yuhai.api.mail")
router = APIRouter(tags=["mail"])

CHANNEL_KINDS = ("imap", "graph", "gmail", "webhook", "browser", "manual")


# ---------------- 收件箱 ----------------
@router.get("/mail")
async def list_mail(limit: int = 100, mailbox: str = "", only_code: bool = False):
    sql = "SELECT * FROM mails WHERE 1=1"
    params: list[Any] = []
    if mailbox:
        sql += " AND mailbox=?"
        params.append(mailbox)
    if only_code:
        sql += " AND code IS NOT NULL"
    sql += " ORDER BY received_at DESC LIMIT ?"
    params.append(min(limit, 500))
    rows = db.q(sql, params)
    return {"items": rows,
            "stats": {
                "total": db.q1("SELECT COUNT(*) c FROM mails")["c"],
                "withCode": db.q1("SELECT COUNT(*) c FROM mails WHERE code IS NOT NULL")["c"],
                "unseen": db.q1("SELECT COUNT(*) c FROM mails WHERE seen=0")["c"],
            }}


@router.get("/mail/latest")
async def latest_code(mailbox: str = "", max_age_sec: int = 900):
    """给自动化流程用的取码接口。"""
    import time
    from datetime import datetime, timedelta
    since = (datetime.now() - timedelta(seconds=max_age_sec)).isoformat(timespec="seconds")
    sql = "SELECT * FROM mails WHERE code IS NOT NULL AND received_at>=?"
    params: list[Any] = [since]
    if mailbox:
        sql += " AND mailbox LIKE ?"
        params.append(f"%{mailbox}%")
    sql += " ORDER BY received_at DESC LIMIT 1"
    r = db.q1(sql, params)
    if not r:
        return {"ok": False, "error": "没有新的验证码"}
    return {"ok": True, "code": r["code"], "mailbox": r["mailbox"],
            "subject": r["subject"], "receivedAt": r["received_at"]}


class SeenReq(BaseModel):
    id: str


@router.post("/mail/seen")
async def mark_seen(req: SeenReq):
    db.exec("UPDATE mails SET seen=1 WHERE id=?", (req.id,))
    return {"ok": True}


# ---------------- 通道 ----------------
@router.get("/mail/channels")
async def channels():
    rows = db.q("SELECT * FROM mail_accounts ORDER BY created_at")
    if not rows:
        # 首次：从配置里种入两个已知邮箱
        seed()
        rows = db.q("SELECT * FROM mail_accounts ORDER BY created_at")
    out = []
    for r in rows:
        cfg = {}
        try:
            cfg = json.loads(r["config"] or "{}")
        except Exception:
            pass
        # 不返回密码
        safe = {k: v for k, v in cfg.items() if k not in ("password", "secret", "token")}
        out.append({**{k: r[k] for k in ("id", "kind", "label", "enabled")},
                    "config": safe,
                    "hasSecret": bool(cfg.get("password") or cfg.get("secret") or cfg.get("token"))})
    return {"items": out, "kinds": CHANNEL_KINDS}


def seed() -> None:
    now = now_iso()
    items = [
        ("mc-163", "imap", "163 发布号邮箱", 1,
         {"user": "m19897410232@163.com", "provider": "163",
          "host": "imap.163.com", "port": 993, "needId": True,
          "password": "QMvdhvwvr8tnuGdP"}),
        ("mc-gmail", "imap", "Gmail 备份号邮箱", 1,
         {"user": "haiyu325355@gmail.com", "provider": "gmail",
          "host": "imap.gmail.com", "port": 993, "needId": False, "password": ""}),
        ("mc-webhook", "webhook", "Webhook 回调入口", 1,
         {"token": secrets.token_urlsafe(16)}),
        ("mc-browser", "browser", "无头浏览器登录", 1,
         {"profile": "mail-163", "pollSec": 20}),
        ("mc-manual", "manual", "手动录入 / 验证码池", 1, {"ttlMin": 30}),
    ]
    for cid, kind, label, en, cfg in items:
        db.exec("INSERT INTO mail_accounts(id,kind,label,enabled,config,created_at,updated_at)"
                " VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
                (cid, kind, label, en, json.dumps(cfg, ensure_ascii=False), now, now))


class ChannelReq(BaseModel):
    id: str = ""
    kind: str
    label: str
    enabled: bool = True
    config: dict = {}


@router.post("/mail/channels")
async def save_channel(req: ChannelReq):
    if req.kind not in CHANNEL_KINDS:
        raise HTTPException(400, f"未知通道类型 {req.kind}")
    cid = req.id or ("mc-" + uuid.uuid4().hex[:8])
    now = now_iso()
    existing = db.q1("SELECT * FROM mail_accounts WHERE id=?", (cid,))
    cfg = req.config or {}
    if existing:
        old = {}
        try:
            old = json.loads(existing["config"] or "{}")
        except Exception:
            pass
        # 没传密码就保留旧的
        for k in ("password", "secret", "token"):
            if k in old and k not in cfg:
                cfg[k] = old[k]
        db.exec("UPDATE mail_accounts SET kind=?,label=?,enabled=?,config=?,updated_at=?"
                " WHERE id=?",
                (req.kind, req.label, 1 if req.enabled else 0,
                 json.dumps(cfg, ensure_ascii=False), now, cid))
    else:
        db.exec("INSERT INTO mail_accounts(id,kind,label,enabled,config,created_at,updated_at)"
                " VALUES(?,?,?,?,?,?,?)",
                (cid, req.kind, req.label, 1 if req.enabled else 0,
                 json.dumps(cfg, ensure_ascii=False), now, now))
    return {"ok": True, "id": cid}


class TestReq(BaseModel):
    id: str


@router.post("/mail/channels/test")
async def test_channel(req: TestReq):
    r = db.q1("SELECT * FROM mail_accounts WHERE id=?", (req.id,))
    if not r:
        raise HTTPException(404, "通道不存在")
    cfg = json.loads(r["config"] or "{}")
    if r["kind"] == "imap":
        cli = imap_mail.build_client(cfg)
        res = await asyncio.to_thread(cli.test)
        db.log_event("ok" if res.get("ok") else "err", "mail",
                     f"{r['label']} 测试: {res}")
        return res
    if r["kind"] in ("graph", "gmail"):
        return {"ok": False, "error": "该通道需先完成 OAuth 授权", "note": "前端配置后由 /mail/oauth 拉起"}
    if r["kind"] == "webhook":
        return {"ok": True, "url": f"/api/mail/webhook/{cfg.get('token', '')}"}
    if r["kind"] == "browser":
        return {"ok": True, "note": "浏览器通道由后台轮询服务驱动"}
    return {"ok": True, "note": "手动通道无需测试"}


# ---------------- 拉取 ----------------
class PullReq(BaseModel):
    channelIds: list[str] = []
    sinceMinutes: int = 1440
    limit: int = 30


@router.post("/mail/pull")
async def pull(req: PullReq):
    rows = db.q("SELECT * FROM mail_accounts WHERE enabled=1")
    if req.channelIds:
        rows = [r for r in rows if r["id"] in req.channelIds]
    imap_rows = [r for r in rows if r["kind"] == "imap"]
    if not imap_rows:
        return {"ok": True, "fetched": 0, "note": "没有启用的 IMAP 通道"}

    total_new = 0
    errors = []

    async def one(r: dict) -> None:
        nonlocal total_new
        cfg = json.loads(r["config"] or "{}")
        cli = imap_mail.build_client(cfg)
        try:
            mails = await asyncio.to_thread(cli.fetch, req.sinceMinutes, req.limit)
        except Exception as e:
            errors.append({"channel": r["label"], "error": str(e)[:200]})
            db.log_event("err", "mail", f"{r['label']} 拉取失败: {str(e)[:120]}")
            return
        for m in mails:
            exists = db.q1("SELECT 1 FROM mails WHERE mailbox=? AND uid=?",
                           (m.mailbox, m.uid))
            if exists:
                continue
            db.exec("INSERT INTO mails(id,mailbox,source,sender,subject,body,code,"
                    "received_at,fetched_at,seen,uid) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    ("m-" + uuid.uuid4().hex[:10], m.mailbox, "imap", m.sender,
                     m.subject, m.body, m.code, m.received_at, now_iso(), 0, m.uid))
            total_new += 1
        db.log_event("ok", "mail", f"{r['label']} 拉到 {len(mails)} 封")

    await asyncio.gather(*(one(r) for r in imap_rows))
    return {"ok": True, "fetched": total_new, "errors": errors}


# ---------------- Webhook 接收 ----------------
@router.post("/mail/webhook/{token}")
async def webhook(token: str, request: Request):
    """邮件服务商推送入口。token 在通道配置里生成。"""
    hit = None
    for r in db.q("SELECT * FROM mail_accounts WHERE kind='webhook' AND enabled=1"):
        cfg = json.loads(r["config"] or "{}")
        if cfg.get("token") == token:
            hit = r
            break
    if not hit:
        raise HTTPException(403, "token 无效")

    try:
        payload = await request.json()
    except Exception:
        payload = {}

    mailbox = payload.get("mailbox") or payload.get("to") or "webhook"
    sender = payload.get("from") or payload.get("sender") or ""
    subject = payload.get("subject") or ""
    body = payload.get("body") or payload.get("text") or payload.get("html") or ""
    code = imap_mail.extract_code(subject + "\n" + str(body))
    mid = "m-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO mails(id,mailbox,source,sender,subject,body,code,"
            "received_at,fetched_at,seen,uid) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (mid, mailbox, "webhook", sender, subject, str(body)[:20000], code,
             now_iso(), now_iso(), 0, mid))
    db.log_event("ok", "mail", f"webhook 收到 {subject[:40]} code={code}")
    return {"ok": True, "id": mid, "code": code}


# ---------------- 手动录入 ----------------
class ManualReq(BaseModel):
    mailbox: str
    code: str
    subject: str = "手动录入"
    ttlMin: int = 30


@router.post("/mail/manual")
async def manual(req: ManualReq):
    if not req.code.strip():
        raise HTTPException(400, "验证码不能为空")
    mid = "m-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO mails(id,mailbox,source,sender,subject,body,code,"
            "received_at,fetched_at,seen,uid) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (mid, req.mailbox, "manual", "manual", req.subject, "", req.code.strip(),
             now_iso(), now_iso(), 1, mid))
    return {"ok": True, "id": mid}
