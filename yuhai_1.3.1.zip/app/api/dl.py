"""短剧下载 API（多站点）

端点：
    GET  /dl/sites              站点清单
    GET  /dl/home?site=         站点首页目录
    GET  /dl/search?site=&kw=   站内搜索
    GET  /dl/meta?site=&slug=   剧集详情 + 分集
    POST /dl/download           下载指定集
    GET  /dl/tasks              任务进度
    POST /dl/task/cancel        取消
    POST /dl/task/remove        移除
    GET  /dl/library            本地片库
    GET  /dl/episodes?site=&slug=  某剧本地文件
    GET  /dl/play?path=         视频流（Range）
    GET  /dl/env                环境自检
"""
from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

from app.services import dl, dlq

log = logging.getLogger("yuhai.api.dl")
router = APIRouter(tags=["dl"])


class DlReq(BaseModel):
    site: str
    slug: str
    eps: list[int] = []
    lang: str = "en"


@router.get("/dl/config")
async def dl_config_get():
    """下载配置：根目录 / 目录结构"""
    return dl.dl_cfg_get()


class DlCfgReq(BaseModel):
    root: str | None = None
    layout: str | None = None


@router.post("/dl/config")
async def dl_config_set(req: DlCfgReq):
    try:
        return dl.dl_cfg_set(req.root, req.layout)
    except Exception as e:
        raise HTTPException(400, str(e)[:200])


@router.get("/dl/browse")
async def dl_browse(path: str = ""):
    """目录浏览：给前端选目录用。path 为空则列出盘符"""
    import os
    from pathlib import Path as _P

    if not path:
        drives = []
        if os.name == "nt":
            for d in "CDEFGHIJKLMNOPQRSTUVWXYZ":
                p = _P(f"{d}:\\")
                try:
                    if p.exists():
                        drives.append({"name": f"{d}:", "path": str(p)})
                except Exception:
                    pass
        return {"path": "", "parent": None, "items": drives, "drives": True}

    p = _P(path)
    if not p.exists() or not p.is_dir():
        raise HTTPException(404, "目录不存在")

    items = []
    try:
        for x in sorted(p.iterdir(), key=lambda z: z.name.lower()):
            try:
                if x.is_dir() and not x.name.startswith("."):
                    items.append({"name": x.name, "path": str(x)})
            except Exception:
                continue
    except PermissionError:
        raise HTTPException(403, "没有访问权限")

    parent = str(p.parent) if p.parent != p else ""
    return {"path": str(p), "parent": parent, "items": items[:300], "drives": False}


@router.post("/dl/pick-folder")
async def dl_pick_folder(initial: str = ""):
    """弹出 Windows 原生「选择文件夹」对话框

    浏览器出于安全无法给出真实路径（只能拿到沙箱化的 FileSystemHandle），
    所以由后端进程调用系统对话框，用户选完把绝对路径返回给前端。

    注意：对话框是模态的，会阻塞，因此放线程里跑。
    """
    import os
    import subprocess as _sp

    def _pick() -> str:
        if os.name != "nt":
            raise RuntimeError("只支持 Windows")
        # PowerShell 调 Shell.Application.BrowseForFolder
        init = (initial or "").replace("'", "''")
        ps = f"""
Add-Type -AssemblyName System.Windows.Forms | Out-Null
$dlg = New-Object System.Windows.Forms.FolderBrowserDialog
$dlg.Description = '选择短剧下载目录'
$dlg.ShowNewFolderButton = $true
$init = '{init}'
if ($init -and (Test-Path -LiteralPath $init)) {{ $dlg.SelectedPath = $init }}
$top = New-Object System.Windows.Forms.Form
$top.TopMost = $true
$top.ShowInTaskbar = $false
$top.WindowState = 'Minimized'
$r = $dlg.ShowDialog($top)
$top.Dispose()
if ($r -eq [System.Windows.Forms.DialogResult]::OK) {{
    Write-Output $dlg.SelectedPath
}}
"""
        try:
            out = _sp.run(
                ["powershell", "-NoProfile", "-STA", "-Command", ps],
                capture_output=True, text=True, timeout=180,
                encoding="utf-8", errors="replace",
                creationflags=0x08000000)
            p = (out.stdout or "").strip().splitlines()
            for line in reversed(p):
                line = line.strip()
                if line and (":" in line or line.startswith("\\\\")):
                    return line
            return ""
        except Exception as e:
            raise RuntimeError(f"打开对话框失败: {str(e)[:80]}")

    try:
        path = await asyncio.to_thread(_pick)
    except Exception as e:
        raise HTTPException(500, str(e)[:200])

    if not path:
        return {"ok": False, "cancelled": True, "path": ""}
    return {"ok": True, "cancelled": False, "path": path}


@router.get("/dl/sites")
async def dl_sites():
    items = [{"id": k, "name": v["name"], "color": v["color"]}
             for k, v in dl.SITES.items()]
    items.append({"id": "tiktok", "name": "TikTok", "color": "#94a3b8"})
    items.append({"id": "tiktok_drama", "name": "TK短剧", "color": "#f472b6"})
    return {"items": items}


@router.get("/dl/env")
async def dl_env():
    return {
        "ok": True,
        "root": str(dl.out_root()),
        "proxy": dl.sess().proxies.get("http", "") if dl.sess().proxies else "",
        "ffmpeg": dl.ffmpeg_bin(),
        "ytdlp": dl.ytdlp_bin(),
        "cdp": dl.sd_available(),
        "cdp_url": dl.CDP_URL,
        "slice_root": str(dl.slice_target_root()),
    }


@router.get("/dl/tiktok/meta")
async def dl_tk_meta(id: str = ""):
    vid = dl.tk_id_from(id)
    if not vid:
        raise HTTPException(400, "没识别到作品 ID（需要 15–25 位数字）")
    try:
        m = await asyncio.to_thread(dl.tk_meta, vid)
    except Exception as e:
        raise HTTPException(502, str(e)[:180])
    # 本地是否已下
    local = []
    tk = dl.tk_dir()
    if tk.exists():
        for p in tk.rglob(f"{vid}*.mp4"):
            local.append({"path": str(p), "bytes": p.stat().st_size})
    m = dict(m)
    m["local"] = local
    return m


@router.post("/dl/tiktok/download")
async def dl_tk_download(req: Request):
    body = await req.json()
    vid = dl.tk_id_from(body.get("id", ""))
    if not vid:
        raise HTTPException(400, "没识别到作品 ID")
    try:
        m = await asyncio.to_thread(dl.tk_meta, vid)
    except Exception as e:
        raise HTTPException(502, str(e)[:180])
    t = dlq.new_task("tiktok", vid, (m.get("desc") or vid)[:60],
                     m.get("cover") or "", [1], "")
    t["web_url"] = m.get("web_url")
    dlq.submit(t)
    return {"ok": True, "task": t["id"], "id": vid}


@router.get("/dl/sd/meta")
async def dl_sd_meta(id: str = "", force: int = 0):
    import re as _re
    m = _re.match(r"(\d{15,25})", (id or "").strip())
    if not m:
        raise HTTPException(400, "ID 格式不对（需要 15–25 位数字）")
    did = m.group(1)
    try:
        d = await asyncio.to_thread(dl.sd_drama, did, bool(force))
    except Exception as e:
        raise HTTPException(502, str(e)[:220])
    folder = dl.drama_dir("tiktok_drama", d.get("name") or did)
    own = []
    if folder.exists():
        for p in folder.glob("*.mp4"):
            mm = _re.findall(r"-(\d+)\.mp4$", p.name)
            if mm:
                own.append(int(mm[-1]))
    d = dict(d)
    d["local_eps"] = sorted(own)
    d["folder"] = str(folder)
    return d


@router.get("/dl/sd/status")
async def dl_sd_status():
    st = dl.sd_state()
    try:
        from app.services import tk_browser
        br = tk_browser.status()
    except Exception:
        br = {}
    return {"cdp": dl.sd_available(), "cdp_url": dl.CDP_URL, **st, "browser": br}


# ─────────────── 浏览器接管 ───────────────
@router.post("/dl/sd/browser/start")
async def dl_sd_browser_start(req: Request):
    """启动调试浏览器。headless=true 时不显示窗口"""
    try:
        body = await req.json()
    except Exception:
        body = {}
    headless = body.get("headless", True)
    fresh = bool(body.get("fresh", False))
    try:
        from app.services import tk_browser
        r = await asyncio.to_thread(tk_browser.start, bool(headless), fresh)
        return {"ok": True, **r}
    except Exception as e:
        raise HTTPException(502, str(e)[:220])


@router.post("/dl/sd/browser/stop")
async def dl_sd_browser_stop():
    """彻底关闭调试浏览器"""
    try:
        from app.services import tk_browser
        r = await asyncio.to_thread(tk_browser.stop)
        return {"ok": True, **r}
    except Exception as e:
        raise HTTPException(502, str(e)[:200])


@router.post("/dl/sd/browser/ensure")
async def dl_sd_browser_ensure(req: Request):
    """需要时再打开：没开就自动开，开了就复用"""
    try:
        body = await req.json()
    except Exception:
        body = {}
    try:
        from app.services import tk_browser
        r = await asyncio.to_thread(tk_browser.ensure, body.get("headless", True))
        return {"ok": True, **r}
    except Exception as e:
        raise HTTPException(502, str(e)[:220])


@router.post("/dl/sd/browser/config")
async def dl_sd_browser_config(req: Request):
    """设置：无头开关 / 空闲自动关闭秒数"""
    body = await req.json()
    try:
        from app.services import tk_browser
        if "headless" in body:
            tk_browser.set_headless(bool(body["headless"]))
        if "idle" in body:
            tk_browser.set_idle_timeout(int(body["idle"]))
        return {"ok": True, **tk_browser.status()}
    except Exception as e:
        raise HTTPException(502, str(e)[:200])


# ─────────────── 批量 / 历史 ───────────────
@router.get("/dl/sd/history")
async def dl_sd_history():
    """查过的剧（最近 300 条）"""
    items = await asyncio.to_thread(dl.sd_history)
    return {"items": items, "count": len(items)}


@router.post("/dl/sd/history/clear")
async def dl_sd_history_clear(req: Request):
    try:
        body = await req.json()
    except Exception:
        body = {}
    ids = body.get("ids") or None
    r = await asyncio.to_thread(dl.sd_history_clear, ids)
    return r


class SdBatchReq(BaseModel):
    ids: list[str] = []
    stopOnFail: bool = False


@router.post("/dl/sd/batch")
async def dl_sd_batch(req: SdBatchReq):
    """批量查询 TK 短剧（串行 + 自动节流）"""
    ids = [x.strip() for x in (req.ids or []) if x and x.strip()]
    if not ids:
        raise HTTPException(400, "ids 不能为空")
    if len(ids) > 50:
        raise HTTPException(400, "一次最多 50 部")
    try:
        r = await asyncio.to_thread(dl.sd_batch, ids, req.stopOnFail)
    except Exception as e:
        raise HTTPException(502, str(e)[:200])
    return r


@router.post("/dl/slice")
async def dl_slice(req: Request):
    """把已下载的剧送去切片（硬链接到源素材根）"""
    body = await req.json()
    site = body.get("site", "")
    dir_name = body.get("dir", "")
    if not site or not dir_name:
        raise HTTPException(400, "缺少 site 或 dir")
    try:
        r = await asyncio.to_thread(dl.send_to_slice, site, dir_name)
    except Exception as e:
        raise HTTPException(502, str(e)[:200])
    return r


@router.get("/dl/home")
async def dl_home(site: str = "pinedrama"):
    if site not in dl.SITES:
        raise HTTPException(400, "未知站点")
    h = await asyncio.to_thread(dl.fetch_home, site)
    return {"site": site, "items": [{"slug": s, "site": site} for s in (h.get("slugs") or [])[:60]],
            "total": len(h.get("slugs") or [])}


@router.get("/dl/search")
async def dl_search(site: str = "pinedrama", kw: str = "", limit: int = 60):
    if site not in dl.SITES:
        raise HTTPException(400, "未知站点")
    r = await asyncio.to_thread(dl.search, site, kw, limit)
    return {"site": site, "total": r["total"],
            "items": [{"slug": s, "site": site} for s in r["slugs"]]}


@router.get("/dl/meta")
async def dl_meta(site: str, slug: str, force: int = 0):
    if site == "tiktok":
        vid = dl.tk_id_from(slug)
        if not vid:
            raise HTTPException(400, "没识别到作品 ID")
        try:
            m = await asyncio.to_thread(dl.tk_meta, vid)
        except Exception as e:
            raise HTTPException(502, str(e)[:180])
        m = dict(m)
        m["local_eps"] = []
        m["folder"] = str(dl.tk_dir())
        return m
    if site == "tiktok_drama":
        return await dl_sd_meta(id=slug, force=force)
    if site not in dl.SITES:
        raise HTTPException(400, "未知站点")
    try:
        m = await asyncio.to_thread(dl.fetch_meta, site, slug, bool(force))
    except Exception as e:
        raise HTTPException(502, str(e)[:200])
    # 本地已下载
    folder = dl.drama_dir(site, m.get("name") or slug)
    own = []
    if folder.exists():
        for p in folder.glob("*.mp4"):
            mm = re.findall(r"-(\d+)\.mp4$", p.name)
            if mm:
                own.append(int(mm[-1]))
    m = dict(m)
    m["local_eps"] = sorted(own)
    m["folder"] = str(folder)
    return m


@router.post("/dl/download")
async def dl_download(req: DlReq):
    if req.site == "tiktok":
        body = {"id": req.slug}
        return await dl_tk_download_raw(body)
    if req.site == "tiktok_drama":
        try:
            m = await asyncio.to_thread(dl.sd_drama, req.slug)
        except Exception as e:
            raise HTTPException(502, str(e)[:200])
        eps = sorted({int(x) for x in req.eps if int(x) > 0}) or [1]
        t = dlq.new_task(req.site, req.slug, m.get("name") or req.slug,
                         m.get("cover") or "", eps, "zh-Hans")
        dlq.submit(t)
        return {"ok": True, "task": t["id"], "count": len(eps)}
    if req.site not in dl.SITES:
        raise HTTPException(400, "未知站点")
    eps = sorted({int(x) for x in req.eps if int(x) > 0})
    if not eps:
        raise HTTPException(400, "没有选中任何集")
    try:
        m = await asyncio.to_thread(dl.fetch_meta, req.site, req.slug, False)
    except Exception as e:
        raise HTTPException(502, f"取元数据失败: {e}")
    t = dlq.new_task(req.site, req.slug, m.get("name") or req.slug,
                     m.get("cover") or "", eps, req.lang)
    dlq.submit(t)
    return {"ok": True, "task": t["id"], "count": len(eps)}


async def dl_tk_download_raw(body: dict):
    vid = dl.tk_id_from(body.get("id", ""))
    if not vid:
        raise HTTPException(400, "没识别到作品 ID")
    try:
        m = await asyncio.to_thread(dl.tk_meta, vid)
    except Exception as e:
        raise HTTPException(502, str(e)[:180])
    t = dlq.new_task("tiktok", vid, (m.get("desc") or vid)[:60],
                     m.get("cover") or "", [1], "")
    t["web_url"] = m.get("web_url")
    dlq.submit(t)
    return {"ok": True, "task": t["id"], "id": vid}


@router.get("/dl/tasks")
async def dl_tasks():
    return {"items": dlq.snapshot()}


@router.post("/dl/task/cancel")
async def dl_cancel(req: Request):
    body = await req.json()
    tid = int(body.get("id") or 0)
    if not dlq.cancel(tid):
        raise HTTPException(404, "任务不存在")
    return {"ok": True}


@router.post("/dl/task/remove")
async def dl_remove(req: Request):
    body = await req.json()
    tid = int(body.get("id") or 0)
    dlq.remove(tid)
    return {"ok": True}


@router.get("/dl/library")
async def dl_library():
    items = await asyncio.to_thread(dl.scan_local)
    return {"items": items,
            "series": len(items),
            "files": sum(i["count"] for i in items),
            "bytes": sum(i["bytes"] for i in items)}


@router.get("/dl/episodes")
async def dl_episodes(site: str, slug: str):
    return await asyncio.to_thread(dl.episode_files, site, slug)


@router.get("/dl/play")
async def dl_play(path: str):
    """本地视频流（支持 Range，浏览器可拖进度条）"""
    p = Path(path)
    if not p.exists() or p.suffix.lower() != ".mp4":
        raise HTTPException(404, "文件不存在")
    # 必须在下载根目录内
    try:
        p.resolve().relative_to(dl.out_root().resolve())
    except Exception:
        raise HTTPException(403, "路径不允许")
    return FileResponse(str(p), media_type="video/mp4",
                        headers={"Accept-Ranges": "bytes"})


_ALLOW_HOSTS = (
    "v.pinedrama.com", "thwztchapter.dramaboxdb.com", "thwztvideo.dramaboxdb.com",
    "infocdn.dramaboxdb.com", "hwvideoseo.dramaboxdb.com",
    "cdreader.com", "dramaboxdb.com",
    "acf.goodshort.com", "acfs3.goodshort.com", "v3.goodshort.com",
    "tiktokcdn-us.com", "tiktokcdn.com", "tiktokcdn-eu.com", "ibytedtos.com",
    "byteimg.com",
)


@router.get("/dl/cover")
async def dl_cover(u: str = ""):
    """封面代理：绕开浏览器跨域/防盗链"""
    from urllib.parse import urlparse as _urlparse
    if not u.startswith("https://"):
        raise HTTPException(404, "不允许的地址")
    host = (_urlparse(u).hostname or "").lower()
    if not any(host == h or host.endswith("." + h) for h in _ALLOW_HOSTS):
        raise HTTPException(404, "不允许的地址")
    # Referer 按来源站给，部分 CDN 校验它
    ref = "https://www.tiktok.com/"
    if "pinedrama" in host:
        ref = "https://pinedrama.com/"
    elif "dramabox" in host:
        ref = "https://www.dramabox.com/"
    elif "goodshort" in host:
        ref = "https://www.goodshort.com/"
    elif "cdreader" in host:
        ref = "https://www.moboreels.com/"
    try:
        r = dl.sess().get(u, timeout=25,
                          headers={"Referer": ref,
                                   "Accept": "image/webp,image/apng,image/*,*/*;q=0.8"})
        if r.status_code != 200 or not r.content:
            raise HTTPException(502, f"上游 {r.status_code}")
        return Response(content=r.content,
                        media_type=r.headers.get("content-type", "image/webp"),
                        headers={"Cache-Control": "public, max-age=86400"})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, str(e)[:80])
