"""发布平台配置 API（FB 不带标签，TK 带标签）。"""
from __future__ import annotations

import logging
from fastapi import APIRouter
from pydantic import BaseModel

from app.services import platform_cfg as pc

log = logging.getLogger("yuhai.api.platform")
router = APIRouter(tags=["platform"])


@router.get("/publish/platform")
async def get_platform():
    """当前发布平台 + 标签设置。"""
    return pc.info()


class PlatReq(BaseModel):
    platform: str


@router.post("/publish/platform")
async def set_platform(req: PlatReq):
    """切换平台。fb=不加标签，tk/ig=加标签。"""
    r = pc.set_platform(req.platform)
    if not r.get("ok"):
        from fastapi import HTTPException
        raise HTTPException(400, r.get("error") or "切换失败")
    return {**r, **pc.info()}


class TagsReq(BaseModel):
    hashtags: str | None = None      # 空串=强制不加；null=恢复按平台默认


@router.post("/publish/hashtags")
async def set_hashtags(req: TagsReq):
    """强制覆盖标签（留空表示不加任何标签）。"""
    from app.db import db
    if req.hashtags is None:
        db.set_kv("publish.hashtags", None)
    else:
        db.set_kv("publish.hashtags", req.hashtags.strip())
    return pc.info()


@router.get("/publish/preview")
async def preview(pageId: str = "", drama: str = ""):
    """预览一条最终文案（不发布，只看长什么样）。"""
    from app.db import db
    from app.services import caption as cap
    from app.services.scheduler import Scheduler

    page = db.q1("SELECT * FROM pages WHERE page_id=? OR name=?", (pageId, pageId))
    if not page:
        page = {"page_id": pageId, "name": pageId, "drama": drama}
    q = {"drama": drama, "ep": "EP01"}
    body = Scheduler._caption(page, q)
    return {"ok": True, "caption": body, "length": len(body),
            "platform": pc.platform(),
            "hasLink": "http" in body,
            "hasHashtags": "#" in body}
