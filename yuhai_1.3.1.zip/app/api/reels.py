"""ReelsPublisher 内核发布 API（批量发布，走官方 worker）。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import reels as rl

log = logging.getLogger("yuhai.api.reels")
router = APIRouter(tags=["reels"])


@router.get("/reels/status")
async def reels_status():
    """内核可用性 + 已规划主页。"""
    info = rl.available()
    return {**info, "pages": rl.plan_pages()}


@router.post("/reels/check")
async def reels_check():
    """检查每个环境是否有可用的 Meta 工作标签。"""
    r = await rl.check_browsers()
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "检查失败")
    return r


@router.get("/reels/materials")
async def reels_materials(directory: str = ""):
    """扫描素材目录（不启动发布）。"""
    from app import paths
    d = directory or str(paths.output_root())
    r = await rl.scan_materials(d)
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "扫描失败")
    return {"directory": d,
            "total": r.get("total") or 0,
            "folderCount": r.get("folderCount") or 0,
            "groups": r.get("groups") or [],
            "sampleTitle": r.get("sampleTitle") or "",
            "debug": r}


class ReelsPublishReq(BaseModel):
    directory: str = ""
    description: str = ""          # 固定标题模板（含链接占位）；titleMode=fixed 时使用
    linkPool: str = ""             # 链接池，每行一个；useRandomLink=False 时忽略
    clipsPerPage: int = 1
    concurrency: int = 1
    publishMode: str = "merge"     # merge | folders
    browserIds: list[str] = []
    autoPrepare: bool = True       # 自动开浏览器 + 开工作标签
    pages: list[str] = []          # 只发这些主页（pageId），空=全部
    materials: list[str] = []      # 只用这些素材（文件路径），空=全部

    # ---- 文案来源 ----
    # random : 从每个主页的标题变体池里随机取（多标题随机）
    # fixed  : 全部使用 description
    titleMode: str = "random"
    referenceTitle: str = ""       # 变体池为空时用这个当参考/兜底
    useRandomLink: bool = True     # 链接是否从链接池按主页随机
    fixedTitle: str = ""           # titleMode=fixed 时的标题正文（不含链接）


@router.get("/reels/pages")
async def reels_pages():
    """可发布的主页清单（供前端勾选）。"""
    ps = rl.plan_pages()
    out = []
    for p in ps:
        row = db.q1("SELECT name, health, drama, genre FROM pages WHERE page_id=?",
                    (p.get("profileId"),))
        out.append({
            "pageId": p.get("pageId"),
            "pageName": p.get("pageName"),
            "profileId": p.get("profileId"),
            "environmentId": p.get("environmentId"),
            "health": (row or {}).get("health") or "ok",
            "drama": (row or {}).get("drama") or "",
            "genre": (row or {}).get("genre") or "",
            "selectable": ((row or {}).get("health") or "ok") == "ok",
        })
    out.sort(key=lambda x: str(x.get("pageName") or ""))
    return {"items": out, "total": len(out),
            "usable": sum(1 for x in out if x["selectable"])}


@router.get("/reels/files")
async def reels_files(directory: str = "", limit: int = 300):
    """素材文件清单（供前端勾选）。"""
    from app import paths
    d = directory or str(paths.output_root())
    root = Path(d)
    if not root.exists():
        return {"items": [], "total": 0, "directory": d}
    items = []
    for f in sorted(root.rglob("*.mp4")):
        is_mix = any(k in f.stem for k in ("主线版", "精品混剪", "混剪"))
        rel = str(f.relative_to(root))
        items.append({
            "path": str(f),
            "file": f.name,
            "rel": rel,
            "sizeMb": round(f.stat().st_size / 1048576, 1),
            "kind": "mix" if is_mix else "single",
        })
    # 默认只返回单集（混剪不参与发布）
    singles = [x for x in items if x["kind"] == "single"]
    return {"items": singles[:limit], "total": len(singles),
            "mixCount": len(items) - len(singles),
            "directory": d}


@router.post("/reels/stop")
async def reels_stop(jobId: str = ""):
    """停止发布（不传 jobId 就停全部）。"""
    r = rl.stop_worker(jobId)
    # 把还在 running 的任务标成 stopped
    if jobId:
        db.exec("UPDATE jobs SET status='stopped',ended_at=? WHERE id=? "
                "AND status IN ('running','queued')", (now_iso(), jobId))
    else:
        db.exec("UPDATE jobs SET status='stopped',ended_at=? "
                "WHERE status IN ('running','queued')", (now_iso(),))
    db.log_event("warn", "reels", f"停止发布: {r.get('note')}")
    return {**r, "ok": True}


@router.post("/reels/prepare")
async def reels_prepare(containerCode: str = ""):
    """手动触发：开浏览器 + 整理 Meta 工作标签 + 识别主页。"""
    from app.services import prepare as pz
    r = await pz.prepare_publish(containerCode)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "准备失败")
    return r


@router.post("/reels/publish")
async def reels_publish(req: ReelsPublishReq):
    """启动批量发布（后台跑，进度走 jobs）。

    autoPrepare=True 时会先自动：
        · 启动发布号浏览器（若没开）
        · 打开/整理唯一的 Meta 工作标签
        · 识别当前主页
    然后再交给 ReelsPublisher 内核发布。
    """
    from app import paths

    info = rl.available()
    if not info.get("ok"):
        raise HTTPException(400, "ReelsPublisher 内核不可用")

    directory = req.directory or str(paths.output_root())
    from app.services import caption as cap
    from app.services import platform_cfg as pc

    description = req.description.strip()
    link_pool = req.linkPool.strip()

    # ---- 文案来源：random 走变体池随机，fixed 用固定模板 ----
    title_mode = (req.titleMode or "random").strip().lower()
    mode_note = ""

    if title_mode == "fixed":
        if not description:
            description = req.fixedTitle.strip() or cap.REFERENCE_TITLE
            if link_pool.split():
                pass  # 固定模式下由 worker 的 linkPool 自己轮换
        mode_note = "固定标题"
    else:
        # 多标题随机：按第一个目标主页取一条代表文案作为 worker 的模板基底，
        # 真正的逐条随机由下面的 per_page_captions 覆盖写入。
        probe_page = (req.pages or [""])[0] if req.pages else ""
        try:
            picked = cap.pick_caption(probe_page, req.referenceTitle or "")
            base_title = (picked or {}).get("title") or ""
        except Exception:
            base_title = ""
        base_title = base_title or req.referenceTitle.strip() or cap.REFERENCE_TITLE

        link = ""
        if req.useRandomLink:
            try:
                lk = cap.pick_link(probe_page)
                link = (lk or {}).get("url") or ""
            except Exception:
                link = ""
        if link:
            description = f"{base_title}\n\n{link}"
        else:
            description = base_title
        if not req.useRandomLink and link_pool:
            description = f"{base_title}\n\n{link_pool.split()[0]}"
        mode_note = "多标题随机"

    # 兜底：仍是空就退回参考标题
    if not description:
        description = cap.REFERENCE_TITLE

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": "准备浏览器", "state": "wait", "note": ""},
             {"name": "检查浏览器", "state": "wait", "note": ""},
             {"name": "扫描素材", "state": "wait", "note": ""},
             {"name": "执行发布", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "reels", f"Reels 批量发布 · {req.clipsPerPage} 条/主页 · {mode_note}",
             "queued", 0, json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))

    def _set_step(idx: int, state: str, note: str = "") -> None:
        """更新第 idx 步的状态（同时把之前未完成的标记 done）。"""
        cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
        try:
            arr = json.loads((cur or {}).get("steps") or "[]")
        except Exception:
            arr = list(steps)
        if not arr or idx >= len(arr):
            return
        for i in range(idx):
            if arr[i]["state"] in ("wait", "run"):
                arr[i]["state"] = "done"
        arr[idx]["state"] = state
        if note:
            arr[idx]["note"] = note[:70]
        db.exec("UPDATE jobs SET steps=? WHERE id=?",
                (json.dumps(arr, ensure_ascii=False), job_id))

    async def _bg() -> None:
        def prog(msg: str) -> None:
            cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
            try:
                arr = json.loads((cur or {}).get("steps") or "[]")
            except Exception:
                arr = list(steps)
            if arr:
                arr[-1]["note"] = (msg or "")[:70]
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(arr, ensure_ascii=False), job_id))
        try:
            db.exec("UPDATE jobs SET status='running',started_at=? WHERE id=?",
                    (now_iso(), job_id))

            # ① 自动准备：开浏览器 + 开工作标签
            browser_ids = list(req.browserIds)
            if req.autoPrepare:
                _set_step(0, "run", "正在启动浏览器并打开工作页…")
                from app.services import prepare as pz
                pr = await pz.prepare_publish(browser_ids[0] if browser_ids else "")
                if not pr.get("ok"):
                    _set_step(0, "err", pr.get("error") or "准备失败")
                    db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? "
                            "WHERE id=?",
                            (f"[{pr.get('stage')}] {pr.get('error')}"[:400],
                             now_iso(), job_id))
                    return
                _set_step(0, "done", f"{pr.get('pageName') or '—'} @ CDP "
                                     f"{pr.get('cdpPort')}"
                                     f"{' (已启动)' if pr.get('started') else ''}")
                if not browser_ids and pr.get("code"):
                    browser_ids = [pr["code"]]
            else:
                _set_step(0, "done", "跳过自动准备")

            # ② 浏览器检查 + 发布
            _set_step(1, "run", "检查 Meta 工作标签…")
            r = await rl.publish(
                directory=directory,
                description=description,
                link_pool=link_pool,
                clips_per_page=req.clipsPerPage,
                concurrency=req.concurrency,
                publish_mode=req.publishMode,
                browser_ids=browser_ids,
                pages=req.pages or None,
                materials=req.materials or None,
                title_mode=title_mode,
                reference_title=req.referenceTitle,
                use_random_link=req.useRandomLink,
                fixed_title=req.fixedTitle,
                on_progress=prog,
                job_id=job_id)
            ok = bool(r.get("ok"))
            value = r.get("result") or r
            if ok:
                _set_step(3, "done", "发布完成")
            else:
                _set_step(3, "err", (r.get("error") or "发布失败")[:70])
            db.exec("UPDATE jobs SET status=?,result=?,progress=100,ended_at=? WHERE id=?",
                    ("done" if ok else "failed",
                     json.dumps(value, ensure_ascii=False, default=str),
                     now_iso(), job_id))
            db.log_event("ok" if ok else "err", "reels",
                         f"Reels 批量发布{'完成' if ok else '失败'}")
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id, "directory": directory,
            "clipsPerPage": req.clipsPerPage,
            "autoPrepare": req.autoPrepare,
            "note": "会自动开浏览器和页面，然后发布；素材成功后自动删除"}
