"""任务 API：作业列表、详情、取消。"""
from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from app.db import db, now_iso

log = logging.getLogger("yuhai.api.jobs")
router = APIRouter(tags=["jobs"])


def _row(r: dict) -> dict:
    out = dict(r)
    for k in ("steps", "payload", "result"):
        if out.get(k):
            try:
                out[k] = json.loads(out[k])
            except Exception:
                pass
    return out


@router.get("/jobs")
async def list_jobs(status: str = "", kind: str = "", limit: int = 50):
    sql = "SELECT * FROM jobs WHERE 1=1"
    params: list[Any] = []
    if status and status != "all":
        sql += " AND status=?"
        params.append(status)
    if kind:
        sql += " AND kind=?"
        params.append(kind)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(min(limit, 300))
    rows = db.q(sql, params)
    return {"items": [_row(r) for r in rows]}


@router.get("/jobs/{job_id}")
async def job_detail(job_id: str):
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        raise HTTPException(404, "任务不存在")
    return _row(r)


@router.post("/jobs/{job_id}/cancel")
async def cancel(job_id: str):
    r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
    if not r:
        raise HTTPException(404, "任务不存在")
    if r["status"] in ("done", "failed", "cancelled"):
        return {"ok": True, "note": "已结束"}
    db.exec("UPDATE jobs SET status='cancelled',ended_at=? WHERE id=?", (now_iso(), job_id))
    db.log_event("warn", "jobs", f"取消任务 {job_id}")
    return {"ok": True}
