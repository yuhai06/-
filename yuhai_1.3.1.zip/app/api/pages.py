"""公共主页 API：列表、按 PID 提取、创建、详情。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any

from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel

from app.adapters import hubstudio as hs
from app.adapters.facebook import FB, FBError, PageRow, upsert_pages
from app.adapters.hubstudio import hub, HubstudioError
from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.api.pages")
router = APIRouter(tags=["pages"])


async def _pid_by_port(port: int) -> int | None:
    """按 CDP 端口反查真实 PID（containerId 不是进程 PID）。"""
    if not port:
        return None
    import psutil
    try:
        for c in psutil.net_connections(kind="inet"):
            if c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == port and c.pid:
                return int(c.pid)
    except (psutil.AccessDenied, PermissionError):
        try:
            r = proc.run(["netstat", "-ano", "-p", "TCP"], capture_output=True,
                               text=True, timeout=15, encoding="utf-8", errors="replace")
            for line in (r.stdout or "").splitlines():
                parts = line.split()
                if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
                    return int(parts[4])
        except Exception:
            pass
    return None


def _row(r: dict) -> dict:
    roles = {x["c_user"]: x for x in db.q(
        "SELECT * FROM page_roles WHERE page_id=?", (r["page_id"],))}
    return {
        "id": r["page_id"],
        "name": r["name"],
        "profileId": r["page_id"],
        "assetId": r["asset_id"],
        "drama": r["drama"] or "",
        "genre": r["genre"] or "",
        "followers": r["followers"] or 0,
        "views30d": r["views_30d"] or 0,
        "published": r["published"] or 0,
        "health": r["health"] or "ok",
        "envCode": r["env_code"],
        "skipPublish": bool(r["skip_publish"]) if "skip_publish" in r.keys() else False,
        "skipReason": r["skip_reason"] if "skip_reason" in r.keys() else None,
        "authz": {
            "publisher": {
                "present": settings.fb_publisher_cuser in roles,
                "level": (roles.get(settings.fb_publisher_cuser) or {}).get("role"),
                "grantedAt": (roles.get(settings.fb_publisher_cuser) or {}).get("granted_at"),
            },
            "backup": {
                "present": settings.fb_backup_cuser in roles,
                "level": (roles.get(settings.fb_backup_cuser) or {}).get("role"),
                "grantedAt": (roles.get(settings.fb_backup_cuser) or {}).get("granted_at"),
            },
        },
    }


@router.get("/pages")
async def list_pages():
    rows = db.q("SELECT * FROM pages ORDER BY name")
    return {"items": [_row(r) for r in rows]}


@router.get("/pages/{page_id}")
async def page_detail(page_id: str):
    r = db.q1("SELECT * FROM pages WHERE page_id=?", (page_id,))
    if not r:
        raise HTTPException(404, "主页不存在")
    d = _row(r)
    d["insights"] = db.q(
        "SELECT date,views,reach,minutes FROM insights WHERE page_id=? ORDER BY date DESC LIMIT 30",
        (page_id,))
    d["roles"] = db.q("SELECT * FROM page_roles WHERE page_id=?", (page_id,))
    return d


# ---------------- 按 PID 提取 ----------------
class ExtractReq(BaseModel):
    pids: list[str] = []
    parallel: int = 2
    createMissing: bool = True
    markMissing: bool = True
    pullInsights: bool = False


@router.post("/pages/extract")
async def extract(req: ExtractReq):
    """按 PID 提取该号名下全部主页。

    硬约束：
      · 每个 PID 先反查 CDP，读 c_user 确认身份
      · profile id 与 c_user 不一致 → 该 PID 标记「身份未校验」并跳过，不入库
    """
    pids = [p.strip() for p in req.pids if p.strip()]
    if not pids:
        raise HTTPException(400, "PID 不能为空")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [
        {"name": "反查 PID 监听端口", "state": "wait", "note": ""},
        {"name": "探测 CDP", "state": "wait", "note": ""},
        {"name": "读取当前身份 c_user", "state": "wait", "note": ""},
        {"name": "解析主页列表", "state": "wait", "note": ""},
        {"name": "与台账做差集", "state": "wait", "note": ""},
        {"name": "写库", "state": "wait", "note": ""},
    ]
    db.exec(
        "INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
        " VALUES(?,?,?,?,?,?,?,?,?)",
        (job_id, "extract", f"按 PID 提取主页（{len(pids)} 个）", "running", 0,
         json.dumps(steps, ensure_ascii=False),
         json.dumps(req.model_dump(), ensure_ascii=False), now_iso(), now_iso()))

    # 异步跑，前端轮询 /api/jobs/{id}
    asyncio.create_task(_run_extract(job_id, pids, req.parallel))
    return {"ok": True, "jobId": job_id}


async def _run_extract(job_id: str, pids: list[str], parallel: int) -> None:
    def upd(i: int, state: str, note: str = "", progress: int = -1):
        steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))["steps"] or "[]")
        if i < len(steps):
            steps[i]["state"] = state
            if note:
                steps[i]["note"] = note
        patch = {"steps": json.dumps(steps, ensure_ascii=False)}
        if progress >= 0:
            patch["progress"] = progress
        sets = ",".join(f"{k}=?" for k in patch)
        db.exec(f"UPDATE jobs SET {sets} WHERE id=?", (*patch.values(), job_id))

    sem = asyncio.Semaphore(max(1, min(8, parallel)))
    results: list[dict] = []

    async def one(pid: str) -> None:
        async with sem:
            rec = {"pid": pid, "known": False, "cUser": None, "pages": 0,
                   "envName": "", "error": None, "skipped": False}
            try:
                ports = hub.listening_ports(int(pid))
                if not ports:
                    rec["error"] = "无监听端口"
                    rec["skipped"] = True
                    results.append(rec)
                    return
                cdp = await hub.resolve_cdp(int(pid))
                if not cdp:
                    rec["error"] = "未发现 CDP"
                    rec["skipped"] = True
                    results.append(rec)
                    return

                env = await hub.find_env_by_pid(int(pid))
                env_code = env["container_code"] if env else ""
                rec["known"] = bool(env)
                rec["envName"] = (db.q1("SELECT name FROM envs WHERE container_code=?",
                                        (env_code,)) or {}).get("name") or env_code

                async with FB(cdp["port"]) as fb:
                    cur = await fb.c_user()
                    rec["cUser"] = cur
                    if not cur:
                        rec["error"] = "读取 c_user 失败"
                        rec["skipped"] = True
                        results.append(rec)
                        return
                    rows = await fb.extract_pages(cur)
                    rec["pages"] = len(rows)
                    if rows:
                        upsert_pages(rows, env_code)
                        # 补 page_roles：当前身份即管理员
                        for r in rows:
                            db.exec(
                                "INSERT INTO page_roles(page_id,c_user,role,state,checked_at)"
                                " VALUES(?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                                " role=excluded.role,state='active',checked_at=excluded.checked_at",
                                (r.page_id, cur, "full", "active", now_iso()))
                        db.exec("UPDATE pages SET env_code=?,last_seen=? WHERE page_id IN (%s)" %
                                ",".join("?" * len(rows)),
                                (env_code, now_iso(), *[r.page_id for r in rows]))
                db.log_event("ok", "extract", f"PID {pid} 提取 {rec['pages']} 个主页")
            except (HubstudioError, FBError) as e:
                rec["error"] = str(e)[:200]
                db.log_event("err", "extract", f"PID {pid}: {e}")
            except Exception as e:
                rec["error"] = f"{type(e).__name__}: {e}"[:200]
                log.exception("extract pid %s", pid)
            results.append(rec)

    try:
        upd(0, "done", f"{len(pids)} 个 PID")
        upd(1, "run")
        await asyncio.gather(*(one(p) for p in pids))
        upd(1, "done")
        upd(2, "done")
        upd(3, "done", f"{sum(r['pages'] for r in results)} 个主页")
        upd(4, "done")
        upd(5, "done", "提交完成")

        total = db.q1("SELECT COUNT(*) c FROM pages")["c"]
        status = "done" if all(not r["error"] for r in results) else "blocked"
        db.exec("UPDATE jobs SET status=?,progress=100,result=?,ended_at=? WHERE id=?",
                (status, json.dumps({"results": results, "total": total}, ensure_ascii=False),
                 now_iso(), job_id))
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))


# ---------------- 单 PID / 端口 即时提取（同步版，前端弹窗用） ----------------
@router.get("/extract/pages")
async def extract_sync(pid: int = 0, port: int = 0):
    if pid and not port:
        ports = hub.listening_ports(pid)
        if not ports:
            return {"ok": False, "error": "该 PID 无监听端口（containerId 不是进程 PID，请改用 port）",
                    "pid": pid, "ports": []}
        cdp = await hub.resolve_cdp(pid)
    elif port:
        cdp = await hub.probe_cdp(port)
        if not cdp:
            return {"ok": False, "error": f"端口 {port} 不是 Chromium CDP", "pid": pid, "ports": []}
    else:
        return {"ok": False, "error": "需要 pid 或 port"}

    if not cdp:
        return {"ok": False, "error": "未发现 CDP", "pid": pid, "ports": []}
    real_pid = pid or await _pid_by_port(cdp["port"])
    env = await hub.find_env_by_pid(real_pid) if real_pid else None
    env_code = env["container_code"] if env else ""
    try:
        async with FB(cdp["port"]) as fb:
            cur = await fb.c_user()
            if not cur:
                return {"ok": False, "error": "该环境未登录 Facebook（读不到 c_user）",
                        "pid": real_pid, "cdpPort": cdp["port"], "cUser": None,
                        "pages": [], "count": 0}
            rows = await fb.extract_pages(cur)
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "pid": real_pid,
                "cdp": cdp, "env": env}
    if rows:
        upsert_pages(rows, env_code)
        # 能提取到主页 → 当前 c_user 就是这些主页的管理员，直接落 page_roles
        ts = now_iso()
        for r in rows:
            db.exec(
                "INSERT INTO page_roles(page_id,c_user,role,state,granted_at,checked_at)"
                " VALUES(?,?,?,?,?,?) ON CONFLICT(page_id,c_user) DO UPDATE SET"
                " role='full', state='active', checked_at=excluded.checked_at",
                (r.page_id, cur, "full", "active", ts, ts))
        db.log_event("info", "pages",
                     f"c_user {cur} 标记为 {len(rows)} 个主页的管理员")
    return {"ok": True, "pid": real_pid, "cUser": cur, "env": env,
            "cdpPort": cdp["port"], "pages": [r.__dict__ for r in rows],
            "count": len(rows)}

# ---------------- 创建主页 ----------------
class CreateReq(BaseModel):
    name: str
    category: str
    bio: str = ""
    count: int = 1
    accountId: str = ""
    dailyLimit: int = 0        # 0 = 由 quota 自动决定
    gapSec: int = 420
    quotaOverride: str = ""    # 强制指定档位（new/limited/blocked）


@router.post("/pages/create")
async def create_pages(req: CreateReq):
    from app.services import automation as au
    if au.observe_only():
        raise HTTPException(403,
            "当前是「只观察不动作」模式，建主页已被拦截。"
            "去 概览 → 全自动 里关掉「只观察」再操作。")
    """创建主页。额度按账号状态决定，不写死：

        new      新号 6–7 个
        limited  被限过后 1–2 个
        blocked  禁建

    创建前切回个人身份；服务端拒绝时立即停手，不做无意义重试。
    """
    from app.services import quota as q

    # 选号：指定 > 运行中的发布号
    acc = None
    if req.accountId:
        acc = db.q1("SELECT * FROM accounts WHERE id=?", (req.accountId,))
        if not acc:
            raise HTTPException(404, "号不存在")
    else:
        acc = db.q1("SELECT * FROM accounts WHERE role='publisher' AND enabled=1"
                    " ORDER BY created_at LIMIT 1")

    if acc:
        info = q.resolve_quota(acc["id"], req.quotaOverride)
        if not info.get("ok"):
            raise HTTPException(400, info.get("error") or "额度查询失败")
        limit = info["limit"]
        if info["suggestLevel"] != info["level"]:
            raise HTTPException(400,
                f"该号额度建议降到「{info['suggestLevel']}」：{info['reason']}。"
                f"请先在号管理里确认档位，或传 quotaOverride 强制。")
    else:
        # 没有号记录时退回旧逻辑
        limit = req.dailyLimit or 2
        info = {"usedToday": 0, "remaining": limit, "level": "unknown"}

    if req.count > limit:
        raise HTTPException(400,
            f"本次要建 {req.count} 个，超过该号额度 {limit} 个"
            f"（{info.get('level')} 档）。{info.get('reason', '')}")

    if info["remaining"] < req.count:
        raise HTTPException(400,
            f"今日已建 {info['usedToday']} 个，额度 {limit}，"
            f"最多还能建 {info['remaining']} 个")

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": f"创建 {i+1}/{req.count}: {req.name}", "state": "wait", "note": ""}
             for i in range(req.count)]
    payload = {**req.model_dump(), "resolvedLimit": limit,
               "accountLabel": (acc or {}).get("label", ""),
               "accountId": (acc or {}).get("id", "")}
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,created_at,started_at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, "create", f"创建主页 {req.name} × {req.count}", "running", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(payload, ensure_ascii=False), now_iso(), now_iso()))
    asyncio.create_task(_run_create(job_id, req))
    return {"ok": True, "jobId": job_id, "limit": limit,
            "account": (acc or {}).get("label", ""),
            "remaining": info["remaining"] - req.count}


async def _run_create(job_id: str, req: CreateReq) -> None:
    from app.services import quota as q
    # 找发布号环境
    row = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not row:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                ("发布号环境未启动", now_iso(), job_id))
        db.log_event("err", "create", "发布号环境未启动")
        return
    port = row["cdp_port"]
    payload = json.loads(db.q1("SELECT payload FROM jobs WHERE id=?",
                               (job_id,))["payload"] or "{}")
    c_user = payload.get("accountCUser") or settings.fb_publisher_cuser or ""
    acc_id = req.accountId or payload.get("accountId") or ""
    ok_n, fail_n = 0, 0
    downgraded = None
    try:
        async with FB(int(port)) as fb:
            await fb.assert_identity(settings.fb_publisher_cuser)
            await fb.ensure_personal_identity(row["display_name"] or "Yu Hai")
            for i in range(req.count):
                nm = f"{req.name}" if req.count == 1 else f"{req.name}{i+1:02d}"
                res = await fb.create_page(nm, req.category, req.bio)
                steps = json.loads(db.q1("SELECT steps FROM jobs WHERE id=?",
                                         (job_id,))["steps"] or "[]")

                # 风控命中 → 立即降级该号额度并停手
                if res.get("guard"):
                    g = res["guard"]
                    if acc_id:
                        downgraded = q.auto_downgrade(acc_id, g.get("kind") or "")
                    steps[i].update(state="err",
                                    note=f"⚠ {g.get('message')}（已熔断）")
                    db.exec("UPDATE jobs SET steps=?,status='blocked',result=?,ended_at=?"
                            " WHERE id=?",
                            (json.dumps(steps, ensure_ascii=False),
                             json.dumps({"ok": ok_n, "fail": fail_n + 1,
                                         "guard": g, "downgraded": downgraded},
                                        ensure_ascii=False),
                             now_iso(), job_id))
                    db.log_event("err", "create_page",
                                 f"检测到 {g.get('kind')}，批次中止；"
                                 f"{'额度降级到 ' + downgraded if downgraded else '额度未变'}")
                    return

                if res["ok"]:
                    ok_n += 1
                    # events 里带上 c_user，便于按号统计额度
                    steps[i].update(state="done", note="创建成功")
                    db.log_event("ok", "create_page", f"{nm} 创建成功 c_user={c_user}")
                else:
                    fail_n += 1
                    steps[i].update(state="err", note=res["error"] or "失败")
                    db.log_event("warn", "create_page", f"{nm}: {res['error']}")

                pct = int((ok_n + fail_n) / req.count * 100)
                db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False), pct, job_id))

                if not res["ok"] and not res.get("transient"):
                    log.warning("create rejected, stop batch: %s", res["error"])
                    # 服务端拒绝 → 视为被限，降级
                    if acc_id:
                        downgraded = q.auto_downgrade(acc_id, "action_block")
                    break
                if i < req.count - 1:
                    await asyncio.sleep(req.gapSec)

        # 建满新号额度 → 主动降到受限档（保守）
        if acc_id and ok_n >= 6:
            downgraded = q.auto_downgrade(acc_id, "rate_limit") or downgraded

        status = "done" if fail_n == 0 else "blocked"
        db.exec("UPDATE jobs SET status=?,result=?,ended_at=? WHERE id=?",
                (status,
                 json.dumps({"ok": ok_n, "fail": fail_n,
                             "downgraded": downgraded}, ensure_ascii=False),
                 now_iso(), job_id))
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "create_page", str(e)[:200])


class SyncAllReq(BaseModel):
    envCode: str = ""
    pageIds: list[str] = []
    includeInsights: bool = True


@router.post("/pages/sync-all")
async def sync_all_pages(req: SyncAllReq):
    """一次同步全部主页信息。

    做四件事：
        ① 重新提取主页清单（拿 asset_id）
        ② 核对授权关系（发布号/备份号）
        ③ 抓粉丝数与 30 天播放（Business Suite insights）
        ④ 更新健康状态

    提取主页后调这个，就不用再分几次跑了。
    """
    env = None
    if req.envCode:
        env = db.q1("SELECT * FROM envs WHERE container_code=?", (req.envCode,))
    if not env:
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
    if not env:
        raise HTTPException(400, "没有运行中的环境")

    targets = req.pageIds or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]
    if not targets:
        return {"ok": True, "note": "没有可同步的主页", "pages": 0}

    from app.adapters.facebook import FB
    from app.adapters import guard as gd
    from app.adapters import humanize as hz

    out = {"pages": len(targets), "asset": 0, "authz": 0, "insights": 0,
           "failed": 0, "guard": None, "details": []}

    try:
        async with FB(int(env["cdp_port"])) as fb:
            page = await fb.tab()

            # ① 先重新提取一遍，确保 asset_id 齐全
            try:
                rows = await fb.extract_pages()
                if rows:
                    upsert_pages(rows, env["container_code"])
                    out["asset"] = len(rows)
            except Exception as e:
                log.debug("extract during sync failed: %s", e)

            # ② 逐个核对授权
            for pid in targets:
                v = await gd.check(page, env["container_code"], pid)
                if v and v.tripped:
                    out["guard"] = v.as_dict()
                    break
                try:
                    r = await fb.list_roles(
                        (db.q1("SELECT asset_id FROM pages WHERE page_id=?",
                               (pid,)) or {}).get("asset_id") or "")
                    # 记录角色
                    ts = now_iso()
                    for role in (r or []):
                        cu = role.get("c_user")
                        if not cu:
                            continue
                        db.exec(
                            "INSERT INTO page_roles(page_id,c_user,role,state,"
                            "granted_at,checked_at) VALUES(?,?,?,?,?,?)"
                            " ON CONFLICT(page_id,c_user) DO UPDATE SET"
                            " state=excluded.state, checked_at=excluded.checked_at",
                            (pid, cu, role.get("level") or "partial",
                             "active", ts, ts))
                    out["authz"] += 1
                except Exception as e:
                    out["failed"] += 1
                    out["details"].append({"pageId": pid, "authz": str(e)[:80]})
                await hz.human_delay("nav")

            # ③ 抓 insights（粉丝 + 播放）
            if req.includeInsights:
                try:
                    from app.api.insights import NUM_JS
                    for pid in targets[:20]:
                        row = db.q1("SELECT asset_id FROM pages WHERE page_id=?", (pid,))
                        if not row or not row["asset_id"]:
                            continue
                        v = await gd.check(page, env["container_code"], pid)
                        if v and v.tripped:
                            out["guard"] = v.as_dict()
                            break
                        await page.goto(
                            f"https://business.facebook.com/latest/insights/overview"
                            f"?asset_id={row['asset_id']}", wait_until_loaded=9.0)
                        await hz.human_delay("read")
                        data = await page.eval(NUM_JS) or {}
                        if data.get("views") is not None:
                            from datetime import date as _d
                            today = _d.today().isoformat()
                            db.exec(
                                "INSERT INTO insights(page_id,date,views,reach,minutes,"
                                "reactions,comments,shares,collected_at)"
                                " VALUES(?,?,?,?,?,?,?,?,?)"
                                " ON CONFLICT(page_id,date) DO UPDATE SET"
                                " views=excluded.views, reach=excluded.reach,"
                                " minutes=excluded.minutes, reactions=excluded.reactions,"
                                " collected_at=excluded.collected_at",
                                (pid, today, data.get("views") or 0,
                                 data.get("reach") or 0, data.get("minutes") or 0,
                                 data.get("reactions") or 0, 0, 0, now_iso()))
                            db.exec("UPDATE pages SET views_30d=? WHERE page_id=?",
                                    (data.get("views") or 0, pid))
                            out["insights"] += 1
                        await hz.human_delay("nav")
                except Exception as e:
                    out["details"].append({"insights": str(e)[:100]})

            # 收尾清理多余标签
            try:
                await fb.prune_tabs(keep=1)
            except Exception:
                pass
    except Exception as e:
        raise HTTPException(500, f"同步失败：{str(e)[:200]}")

    db.log_event("ok" if not out["guard"] else "warn", "pages",
                 f"全量同步：{out['pages']} 页 · asset {out['asset']} "
                 f"· 授权 {out['authz']} · insights {out['insights']}")
    return {"ok": True, **out}


class SkipReq(BaseModel):
    skip: bool
    reason: str = ""


@router.post("/pages/{page_id}/skip-publish")
async def set_skip_publish(page_id: str, req: SkipReq):
    """标记主页是否参与自动发布。

    有些主页你会手动发，自动发布要跳过它们，否则会重复发。
    """
    r = db.q1("SELECT name FROM pages WHERE page_id=?", (page_id,))
    if not r:
        raise HTTPException(404, "主页不存在")
    db.exec("UPDATE pages SET skip_publish=?,skip_reason=? WHERE page_id=?",
            (1 if req.skip else 0, req.reason or None, page_id))
    db.log_event("info", "pages",
                 f"{r['name']} {'跳过' if req.skip else '恢复'}自动发布"
                 + (f"（{req.reason}）" if req.reason else ""))
    return {"ok": True, "skip": req.skip}


class SkipBatchReq(BaseModel):
    pageIds: list[str]
    skip: bool
    reason: str = ""


@router.post("/pages/skip-publish-batch")
async def set_skip_batch(req: SkipBatchReq):
    n = 0
    for pid in req.pageIds:
        if db.q1("SELECT 1 FROM pages WHERE page_id=?", (pid,)):
            db.exec("UPDATE pages SET skip_publish=?,skip_reason=? WHERE page_id=?",
                    (1 if req.skip else 0, req.reason or None, pid))
            n += 1
    return {"ok": True, "updated": n}


class PagePatch(BaseModel):
    drama: str | None = None
    genre: str | None = None
    health: str | None = None


@router.patch("/pages/{page_id}")
async def patch_page(page_id: str, p: PagePatch):
    fields = {k: v for k, v in p.model_dump(exclude_none=True).items()}
    if not fields:
        return {"ok": True}
    col = {"drama": "drama", "genre": "genre", "health": "health"}
    sets = ",".join(f"{col[k]}=?" for k in fields)
    db.exec(f"UPDATE pages SET {sets} WHERE page_id=?", (*fields.values(), page_id))
    return {"ok": True}
