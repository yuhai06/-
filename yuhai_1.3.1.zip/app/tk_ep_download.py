#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TK短剧单集下载（独立子进程）

为什么单独写：
    TikTok 短剧集的 playAddr 在浏览器里 fetch 才有效（带 Cookie + Sec-Fetch），
    用 requests 直连一律 403。所以必须：
      ① 打开剧集页，触发播放，让页面自己请求真实分片
      ② 从 Playwright 的 response 事件拿到真实 mp4 URL
      ③ 在页面内用 fetch(credentials:'include') 分块取回
      ④ 写入磁盘

用法: python tk_ep_download.py <drama_id> <ep> <out_path> [--cdp URL]
输出: 一行 JSON  {"ok": bool, "bytes": N, "url": "...", "err": "..."}
"""
import base64
import io
import json
import os
import sys
import time

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 页面内分块取数据的 JS
FETCH_JS = r"""async (args) => {
    const [url, start, size] = args;
    const r = await fetch(url, {
        credentials: 'include',
        headers: {'Range': `bytes=${start}-${start + size - 1}`}
    });
    if (r.status !== 200 && r.status !== 206) {
        return {status: r.status, err: 'bad status'};
    }
    // Content-Range: bytes 0-1999999/12345678
    const cr = r.headers.get('content-range') || '';
    let total = 0;
    const m = cr.match(/\/(\d+)\s*$/);
    if (m) total = parseInt(m[1], 10);

    const buf = new Uint8Array(await r.arrayBuffer());
    let s = '';
    const CH = 8192;
    for (let i = 0; i < buf.length; i += CH) {
        s += String.fromCharCode.apply(null, buf.subarray(i, Math.min(i + CH, buf.length)));
    }
    return {status: r.status, len: buf.length, total, b64: btoa(s)};
}"""

# 触发播放（让它请求真实流）
PLAY_JS = r"""async () => {
    const out = [];
    for (const v of document.querySelectorAll('video')) {
        try {
            v.muted = true;
            v.preload = 'auto';
            await v.play();
            out.push({ok: true, dur: v.duration});
        } catch(e) {
            out.push({ok: false, err: String(e).slice(0, 50)});
        }
    }
    return out;
}"""


def main():
    if len(sys.argv) < 4:
        print(json.dumps({"ok": False, "err": "用法: <drama_id> <ep> <out_path>"}))
        return 1

    drama_id = sys.argv[1].strip()
    ep = int(sys.argv[2])
    out_path = sys.argv[3]
    cdp = "http://127.0.0.1:9222"
    for i, a in enumerate(sys.argv):
        if a == "--cdp" and i + 1 < len(sys.argv):
            cdp = sys.argv[i + 1]

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print(json.dumps({"ok": False, "err": f"playwright 未安装: {e}"}))
        return 1

    result = {"ok": False, "bytes": 0, "url": "", "err": ""}
    pg = br = pw = None

    try:
        pw = sync_playwright().start()
        br = pw.chromium.connect_over_cdp(cdp, timeout=60000)
        ctx = br.contexts[0]
        pg = ctx.new_page()

        media = []

        def on_resp(r):
            try:
                ct = (r.headers or {}).get("content-type", "")
                if r.status in (200, 206) and "video/mp4" in ct and ".tiktok" in r.url:
                    if r.url not in media:
                        media.append(r.url)
            except Exception:
                pass

        pg.on("response", on_resp)

        target = f"https://www.tiktok.com/shortdrama/episode/{drama_id}/{ep}"
        pg.goto(target, wait_until="domcontentloaded", timeout=55000)
        time.sleep(9)

        # 触发播放 -> 页面开始拉真实分片
        try:
            pg.evaluate(PLAY_JS)
        except Exception:
            pass

        # 等媒体请求出现
        t0 = time.time()
        while time.time() - t0 < 25 and not media:
            time.sleep(2)
            try:
                pg.evaluate(PLAY_JS)
            except Exception:
                pass

        if not media:
            result["err"] = "页面没有下发视频流（可能该集需付费，或风控）"
            print(json.dumps(result, ensure_ascii=False))
            return 2

        url = media[0]
        result["url"] = url[:200]

        # 先探总大小
        probe = pg.evaluate(FETCH_JS, [url, 0, 1])
        if probe.get("err") or probe.get("status") not in (200, 206):
            result["err"] = f"探测失败: {probe.get('err') or probe.get('status')}"
            print(json.dumps(result, ensure_ascii=False))
            return 3

        total_size = int(probe.get("total") or 0)
        result["total"] = total_size

        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        tmp = out_path + ".part"

        CHUNK = 2 * 1024 * 1024      # 每块 2MB
        MAX_CHUNKS = 500             # 上限 1GB
        written = 0
        with open(tmp, "wb") as f:
            for i in range(MAX_CHUNKS):
                start = i * CHUNK
                # 已到总大小就收工
                if total_size and start >= total_size:
                    break
                r = pg.evaluate(FETCH_JS, [url, start, CHUNK])
                if r.get("err"):
                    if written > 0:
                        break          # 已有数据，收工
                    result["err"] = f"取块失败: {r['err']}"
                    break
                n = r.get("len") or 0
                if n <= 0:
                    break
                raw = base64.b64decode(r["b64"])
                f.write(raw)
                written += len(raw)
                # 有 total 时：按 total 判断结束
                if total_size:
                    if written >= total_size:
                        break
                else:
                    # 没 total：本块不足说明到底了
                    if n < CHUNK:
                        break

        if written < 2048:
            try:
                os.unlink(tmp)
            except Exception:
                pass
            result["err"] = result["err"] or f"文件过小 {written}B"
            print(json.dumps(result, ensure_ascii=False))
            return 4

        # 校验是不是 MP4
        with open(tmp, "rb") as f:
            head = f.read(12)
        if head[4:8] != b"ftyp":
            try:
                os.unlink(tmp)
            except Exception:
                pass
            result["err"] = f"不是有效 MP4（头部 {head[:8]!r}）"
            print(json.dumps(result, ensure_ascii=False))
            return 5

        os.replace(tmp, out_path)
        result["ok"] = True
        result["bytes"] = written
        result["err"] = ""
        print(json.dumps(result, ensure_ascii=False))
        return 0

    except Exception as e:
        result["err"] = repr(e)[:200]
        print(json.dumps(result, ensure_ascii=False))
        return 6
    finally:
        for obj, meth in ((pg, "close"), (br, "close"), (pw, "stop")):
            try:
                if obj is not None:
                    getattr(obj, meth)()
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
