# -*- coding: utf-8 -*-
"""
agent_detect.py — 检测用户机器上的 Agent，并读取**该 Agent 实际在用的模型**

设计要点（按用户要求）：
  ① 只检测知名的 10 个 agent，不暴力全盘递归
  ② 只读**该 agent 自己在用的模型**，不是网关全量
     例：接 dsh → 只有 text_model + fallback 共 4 个
         接 codex → 只有 config.toml 里写的 1 个
         接 ollama → 只有本地 /api/tags 里列的
  ③ 每个模型可实测可用性
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
from pathlib import Path

log = logging.getLogger("yuhai.agent")

HOME = Path.home()
WIN = sys.platform == "win32"


# ---------------- Agent 定义 ----------------
# kind: toml | json | ollama | workbuddy
AGENTS = [
    {
        "id": "dsh", "name": "DSH", "kind": "json",
        "paths": [HOME / ".dsh" / "glm_config.json"],
        "why": "DSH 桌面版",
    },
    {
        "id": "codex", "name": "Codex CLI", "kind": "toml",
        "paths": [HOME / ".codex" / "config.toml"],
        "why": "OpenAI Codex CLI",
    },
    {
        "id": "codex-agnes", "name": "Codex (Agnes)", "kind": "toml",
        "paths": [HOME / ".codex-agnes" / "config.toml"],
        "why": "Codex 的 Agnes profile",
    },
    {
        "id": "codex-dsx", "name": "Codex (DSH桥)", "kind": "toml",
        "paths": [HOME / ".codex" / "dsx.config.toml"],
        "why": "Codex 的 DSH 桥接 profile",
    },
    {
        "id": "ollama", "name": "Ollama", "kind": "ollama",
        "paths": [],
        "api": "http://127.0.0.1:11434",
        "why": "本地模型服务",
    },
    {
        "id": "workbuddy", "name": "WorkBuddy", "kind": "workbuddy",
        "paths": [HOME / ".workbuddy" / "settings.json"],
        "why": "WorkBuddy 桌面版",
    },
    {
        "id": "claude", "name": "Claude Code", "kind": "claude",
        "paths": [HOME / ".claude" / "config.json",
                  HOME / ".claude.json"],
        "why": "Anthropic Claude Code",
    },
    {
        "id": "cursor", "name": "Cursor", "kind": "cursor",
        "paths": [HOME / ".cursor"],
        "why": "Cursor 编辑器",
    },
    {
        "id": "windsurf", "name": "Windsurf", "kind": "windsurf",
        "paths": [HOME / ".windsurf", HOME / ".codeium"],
        "why": "Windsurf 编辑器",
    },
    {
        "id": "cline", "name": "Cline", "kind": "cline",
        "paths": [HOME / ".cline", HOME / ".vscode" / "extensions"],
        "why": "VS Code Cline 插件",
    },
    {
        "id": "continue", "name": "Continue", "kind": "continue",
        "paths": [HOME / ".continue"],
        "why": "VS Code Continue 插件",
    },
]

# 下载链接（没装时提示用）
DOWNLOAD = {
    "dsh": "https://www.deepseek.com",
    "codex": "https://github.com/openai/codex",
    "ollama": "https://ollama.com/download",
    "workbuddy": "https://www.workbuddy.cn",
    "claude": "https://claude.ai/code",
    "cursor": "https://cursor.com",
    "windsurf": "https://windsurf.com",
    "cline": "https://marketplace.visualstudio.com/items?itemName=saoudrizwan.claude-dev",
    "continue": "https://continue.dev",
}


# ---------------- 工具 ----------------
def _read_json(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def _read_toml(p: Path) -> dict:
    """极简 TOML 解析（只取我们需要的键，不引第三方库）。"""
    out: dict = {"providers": {}}
    cur = None
    try:
        text = p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return out
    for line in text.split("\n"):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        m = re.match(r"^\[([^\]]+)\]$", s)
        if m:
            cur = m.group(1).strip()
            if cur.startswith("model_providers."):
                out["providers"].setdefault(cur.split(".", 1)[1], {})
            continue
        m = re.match(r"^([A-Za-z0-9_\-]+)\s*=\s*(.+)$", s)
        if not m:
            continue
        k, v = m.group(1), m.group(2).strip()
        v = v.strip('"').strip("'")
        if cur and cur.startswith("model_providers."):
            out["providers"].setdefault(cur.split(".", 1)[1], {})[k] = v
        elif cur is None or cur == "":
            out[k] = v
    return out


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _http_json(url: str, headers: dict | None = None,
               timeout: int = 10) -> dict | None:
    try:
        import urllib.request
        req = urllib.request.Request(url, headers=headers or {})
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read())
    except Exception:
        return None


# ---------------- 各 agent 的模型读取 ----------------
def models_dsh(p: Path) -> dict:
    """dsh 的模型 = ① 主配置(text/vision/fallback) ② 插件里的模型。

    插件位置：~/.dsh/our-free-model/catalog.json
       entries  10 个  简名
       sealIds  11 个  带前缀完整 id
       kiloRows 12 个  带 name/channel/vision
    这些都是 dsh 能用的，都要显示。
    """
    d = _read_json(p)
    gateway = d.get("gateway", "")
    seen: dict[str, dict] = {}

    # ① 主配置
    for key, role in (("text_model", "文本"), ("vision_model", "视觉")):
        m = d.get(key)
        if m:
            seen.setdefault(m, {"id": m, "name": m.split("/")[-1],
                                "role": [], "endpoint": gateway,
                                "source": "主配置"})
            r = seen[m]["role"]
            if role not in r:
                r.append(role)
    for m in (d.get("fallback") or []):
        if m:
            seen.setdefault(m, {"id": m, "name": m.split("/")[-1],
                                "role": [], "endpoint": gateway,
                                "source": "主配置"})
            if "备用" not in seen[m]["role"]:
                seen[m]["role"].append("备用")

    # ② 插件模型（our-free-model catalog）
    cat = p.parent / "our-free-model" / "catalog.json"
    if cat.exists():
        c = _read_json(cat)
        # entries
        for e in (c.get("entries") or []):
            if not e:
                continue
            mid = "our-free-model/" + e
            seen.setdefault(mid, {
                "id": mid, "name": e, "role": ["插件"],
                "endpoint": gateway, "source": "our-free-model",
                "channel": "our-free-model"})
        # sealIds
        for s in (c.get("sealIds") or []):
            if not s:
                continue
            seen.setdefault(s, {
                "id": s, "name": s.split("/")[-1], "role": ["插件"],
                "endpoint": gateway, "source": "our-free-model",
                "channel": s.split("/")[0]})
        # kiloRows
        for r in (c.get("kiloRows") or []):
            mid = r.get("id") or ""
            if not mid:
                continue
            seen.setdefault(mid, {
                "id": mid, "name": r.get("name") or mid.split("/")[-1],
                "role": ["插件"], "endpoint": gateway,
                "source": "kilo", "channel": r.get("channel") or "kilo",
                "vision": bool(r.get("vision")),
                "reasoning": bool(r.get("reasoning"))})

    return {"models": list(seen.values()), "endpoint": gateway,
            "key": d.get("key", "")}


_GW_CACHE: dict = {"at": 0.0, "data": None}


def models_gateway_all(timeout: float = 5, cache_sec: float = 120) -> dict:
    """从 DSH 网关拉**全部**模型（不只是 dsh 订阅的那些）。

    网关（18326）返回 129 个模型 / 19 个渠道，
    dsh 的 glm_config 只订阅了其中 36 个。
    这里把网关全量拉出来，让用户能选到所有能用的。

    鉴权用 glm_config.json 里的 key（实测可用）。

    ⚠️ 带缓存：detect_all 会串行跑 10 个 agent，每次都拉网关会卡死首页。
    """
    import time as _t
    import urllib.request

    # 缓存命中直接返回
    now = _t.time()
    if (_GW_CACHE["data"] is not None
            and now - _GW_CACHE["at"] < cache_sec):
        return _GW_CACHE["data"]

    p = Path.home() / ".dsh" / "glm_config.json"
    d = _read_json(p)
    gateway = (d.get("gateway") or "").rstrip("/")
    key = d.get("key") or ""
    if not gateway:
        return {"models": [], "endpoint": "", "error": "没配网关"}

    try:
        req = urllib.request.Request(
            gateway + "/v1/models",
            headers={"Authorization": "Bearer " + key} if key else {})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return {"models": [], "endpoint": gateway,
                "error": "拉取失败: %s" % str(e)[:80]}

    out = []
    for m in (data.get("data") or []):
        mid = m.get("id") or ""
        if not mid:
            continue
        chan = mid.split("/")[0] if "/" in mid else "(默认)"
        name = mid.split("/")[-1]
        out.append({
            "id": mid, "name": name, "role": ["网关"],
            "endpoint": gateway, "key": key,
            "source": chan, "channel": chan,
            "vision": bool(m.get("vision")) or "vl" in name.lower(),
            "reasoning": bool(m.get("reasoning")),
        })
    res = {"models": out, "endpoint": gateway, "key": key}
    _GW_CACHE["data"] = res
    _GW_CACHE["at"] = now
    return res


def models_dsh_full(p: Path | None = None) -> dict:
    """DSH 模型 = ①dsh 订阅 ②网关全量（去重合并）。

    返回的每个模型带 inDsh 标记，前端可以区分：
      inDsh=True  → dsh 配置里直接用得上
      inDsh=False → 只在网关里，也能调，但需要在 dsh 里显式指定
    """
    p = p or (Path.home() / ".dsh" / "glm_config.json")
    base = models_dsh(p)
    gw = models_gateway_all()

    seen = {m["id"]: m for m in (base.get("models") or [])}
    for m in seen.values():
        m["inDsh"] = True

    for m in (gw.get("models") or []):
        if m["id"] in seen:
            seen[m["id"]]["inDsh"] = True
            seen[m["id"]]["inGateway"] = True
        else:
            m["inDsh"] = False
            m["inGateway"] = True
            seen[m["id"]] = m

    for m in seen.values():
        m.setdefault("inDsh", False)
        m.setdefault("inGateway", False)
        # 保证 channel 一定存在（前端按渠道分组）
        if not m.get("channel"):
            mid = m.get("id") or ""
            m["channel"] = (mid.split("/")[0] if "/" in mid
                            else (m.get("source") or "(默认)"))

    return {
        "models": list(seen.values()),
        "endpoint": base.get("endpoint") or gw.get("endpoint") or "",
        "key": base.get("key") or gw.get("key") or "",
        "dshCount": sum(1 for m in seen.values() if m["inDsh"]),
        "gatewayCount": sum(1 for m in seen.values() if m["inGateway"]),
        "total": len(seen),
        "gatewayError": gw.get("error") or "",
    }


def models_toml(p: Path) -> dict:
    t = _read_toml(p)
    prov = t.get("model_provider", "")
    m = t.get("model", "")
    pinfo = (t.get("providers") or {}).get(prov) or {}
    base = pinfo.get("base_url", "")
    out = []
    if m:
        out.append({
            "id": m, "name": m,
            "role": ["默认"],
            "provider": prov,
            "endpoint": base,
            "wire": pinfo.get("wire_api", ""),
        })
    # 也列出 provider 里声明的其它候选（有些配置写 models=[...]）
    for extra in re.split(r"[,\s]+", t.get("models", "") or ""):
        if extra and extra != m:
            out.append({"id": extra, "name": extra, "role": ["备选"],
                        "provider": prov, "endpoint": base})

    # ⚠️ config 里没写 model → 去网关问它有哪些（这才是实际能用的）
    if not out and base:
        env_key = pinfo.get("env_key", "")
        key = os.environ.get(env_key, "") if env_key else ""
        d = _http_json(base.rstrip("/") + "/models",
                       headers={"Authorization": f"Bearer {key}"} if key else {})
        if d and d.get("data"):
            for mm in d["data"][:40]:
                mid = mm.get("id") or ""
                if mid:
                    out.append({"id": mid, "name": mid.split("/")[-1],
                                "role": ["网关"], "provider": prov,
                                "endpoint": base})
            if out:
                out[0]["role"] = ["默认(网关首个)"]

    return {"models": out, "endpoint": base, "key_env": pinfo.get("env_key", "")}


def models_ollama(api: str) -> dict:
    d = _http_json(api + "/api/tags")
    if not d:
        return {"models": [], "endpoint": api, "error": "服务未运行"}
    out = []
    for m in (d.get("models") or []):
        name = m.get("name") or ""
        size = m.get("size") or 0
        out.append({
            "id": name, "name": name,
            "role": ["本地"],
            "sizeMb": round(size / 1048576, 1),
            "family": (m.get("details") or {}).get("family", ""),
        })
    return {"models": out, "endpoint": api}


def models_workbuddy(p: Path) -> dict:
    """WorkBuddy 的模型。

    models.json 通常是空数组（模型由服务端下发），
    实际模型在本地 relay 网关的 workbuddy / workbuddy-global 渠道。
    relay 地址从 dsh 的 glm_config.json 里取（同一个网关 18326）。
    """
    base = p.parent
    mp = base / "models.json"
    models = _read_json(mp) if mp.exists() else []
    out = []
    if isinstance(models, list):
        for m in models:
            if isinstance(m, dict):
                mid = m.get("id") or m.get("model") or ""
                if mid:
                    out.append({"id": mid,
                                "name": m.get("name") or mid,
                                "role": ["WorkBuddy"], "source": "models.json"})

    # 插件清单（信息展示）
    plugins = []
    ip = base / "plugins" / "installed_plugins.json"
    if ip.exists():
        d = _read_json(ip)
        plugins = list(((d.get("plugins") or {})).keys())

    # 走 relay 网关查 workbuddy 渠道
    endpoint = ""
    dsh_cfg = HOME / ".dsh" / "glm_config.json"
    if dsh_cfg.exists():
        dc = _read_json(dsh_cfg)
        gw = dc.get("gateway", "")
        key = dc.get("key", "")
        if gw:
            endpoint = gw
            d = _http_json(gw.rstrip("/") + "/v1/models",
                           headers={"Authorization": f"Bearer {key}"})
            if d and d.get("data"):
                for mm in d["data"]:
                    mid = mm.get("id") or ""
                    if not mid:
                        continue
                    if not (mid.startswith("workbuddy/") or
                            mid.startswith("workbuddy-global/")):
                        continue
                    if mid in (x["id"] for x in out):
                        continue
                    out.append({"id": mid, "name": mid.split("/")[-1],
                                "role": ["WorkBuddy"], "source": "relay",
                                "endpoint": endpoint,
                                "channel": mid.split("/")[0]})

    return {"models": out, "plugins": plugins, "endpoint": endpoint}


def models_claude(p: Path) -> dict:
    d = _read_json(p)
    out = []
    for k in ("model", "defaultModel", "primaryModel"):
        if d.get(k):
            out.append({"id": str(d[k]), "name": str(d[k]), "role": ["默认"]})
    return {"models": out, "endpoint": ""}


def models_cursor(p: Path) -> dict:
    d = _read_json(p)
    out = []
    for k in ("model", "selectedModel"):
        v = d.get(k)
        if isinstance(v, str) and v:
            out.append({"id": v, "name": v, "role": ["默认"]})
    return {"models": out, "endpoint": ""}


def models_windsurf(p: Path) -> dict:
    d = _read_json(p)
    out = []
    for k in ("model", "selectedModel"):
        v = d.get(k)
        if isinstance(v, str) and v:
            out.append({"id": v, "name": v, "role": ["默认"]})
    return {"models": out, "endpoint": ""}


def models_cline(p: Path) -> dict:
    gs = p / "data" / "globalState.json"
    if not gs.exists():
        return {"models": [], "endpoint": ""}
    d = _read_json(gs)
    out = []
    for k in ("apiProvider", "openAiModelId", "ollamaModelId"):
        v = d.get(k)
        if isinstance(v, str) and v:
            out.append({"id": v, "name": v, "role": [k]})
    return {"models": out, "endpoint": ""}


def models_continue(p: Path) -> dict:
    out = []
    for name in ("config.json", "config.yaml"):
        f = p / name
        if not f.exists():
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for m in re.finditer(r"model\s*[:=]\s*[\"']?([A-Za-z0-9_.:/\-]+)", text):
            out.append({"id": m.group(1), "name": m.group(1), "role": ["配置"]})
    return {"models": out, "endpoint": ""}


PARSERS = {
    "dsh": lambda p: models_dsh_full(p),
    "codex": models_toml,
    "codex-agnes": models_toml,
    "codex-dsx": models_toml,
    "workbuddy": models_workbuddy,
    "claude": models_claude,
    "cursor": models_cursor,
    "windsurf": models_windsurf,
    "cline": models_cline,
    "continue": models_continue,
}


# ---------------- 检测 ----------------
def detect_one(spec: dict) -> dict:
    aid = spec["id"]
    out = {
        "id": aid, "name": spec["name"], "why": spec["why"],
        "installed": False, "path": "", "models": [],
        "endpoint": "", "error": "", "download": DOWNLOAD.get(aid, ""),
        "plugins": [],
    }

    # ollama 走端口探测
    if spec["kind"] == "ollama":
        api = spec["api"]
        if _port_open("127.0.0.1", 11434):
            r = models_ollama(api)
            out["installed"] = bool(r.get("models"))
            out["models"] = r.get("models") or []
            out["endpoint"] = api
            out["path"] = api
            if not out["models"]:
                out["error"] = "服务在跑但没有模型（ollama pull 一个）"
        else:
            out["error"] = "Ollama 未运行"
        return out

    # 其余走文件
    hit = None
    for p in spec["paths"]:
        if p.exists():
            hit = p
            break
    if not hit:
        out["error"] = "未安装"
        return out

    out["installed"] = True
    out["path"] = str(hit)
    fn = PARSERS.get(aid)
    if not fn:
        out["error"] = "暂不支持解析"
        return out
    try:
        r = fn(hit)
        out["models"] = r.get("models") or []
        out["endpoint"] = r.get("endpoint") or ""
        out["plugins"] = r.get("plugins") or []
        # DSH 特有：区分「dsh 订阅」和「网关全量」
        for extra in ("dshCount", "gatewayCount", "total", "gatewayError"):
            if r.get(extra):
                out[extra] = r[extra]
        if r.get("key_env"):
            out["keyEnv"] = r["key_env"]
        if r.get("key"):
            out["hasKey"] = True
        if not out["models"]:
            out["error"] = "已安装，但没读到在用模型（可能在设置里配）"
    except Exception as e:
        out["error"] = f"解析失败: {str(e)[:60]}"
    return out


def detect_all() -> dict:
    items = [detect_one(a) for a in AGENTS]
    installed = [i for i in items if i["installed"]]
    return {
        "items": items,
        "installed": len(installed),
        "ok": bool(installed),
        "hint": "" if installed else "没检测到任何 Agent，点下载链接安装",
        "home": str(HOME),
        "disks": _disks(),
    }


def _disks() -> list[str]:
    if not WIN:
        return ["/"]
    out = []
    for c in "CDEFGH":
        if Path(f"{c}:/").exists():
            out.append(f"{c}:")
    return out


def deep_scan() -> dict:
    """深度扫描：每个盘只找一级+二级目录里的 agent 关键词（不递归到底）。"""
    pat = re.compile(
        r"(?i)(claude|cursor|codex|windsurf|cline|continue|ollama|"
        r"agent|workbuddy|dsh|lmstudio|anythingllm)")
    found = []
    for disk in _disks():
        root = Path(disk + "/")
        try:
            lvl1 = [d for d in root.iterdir() if d.is_dir()]
        except OSError:
            continue
        for d1 in lvl1:
            if pat.search(d1.name):
                found.append(str(d1))
                continue
            # 只看 Program Files 这类容器的一层
            if d1.name.lower() in ("program files", "program files (x86)",
                                   "programs", "apps", "tools", "software"):
                try:
                    for d2 in d1.iterdir():
                        if d2.is_dir() and pat.search(d2.name):
                            found.append(str(d2))
                except OSError:
                    pass
    return {"found": found[:40], "count": len(found)}


# ---------------- 模型可用性实测 ----------------
def test_model(endpoint: str, model_id: str, api_key: str = "",
               timeout: int = 25) -> dict:
    """真发一次最小请求，确认模型能用。

    ollama 用 /api/chat，其它走 OpenAI 兼容 /chat/completions。
    """
    if not endpoint:
        return {"ok": False, "error": "缺 endpoint"}

    if "11434" in endpoint:      # ollama
        body = json.dumps({"model": model_id, "stream": False,
                           "messages": [{"role": "user", "content": "hi"}]})
        url = endpoint.rstrip("/") + "/api/chat"
        headers = {"Content-Type": "application/json"}
    else:
        base = endpoint.rstrip("/")
        if not base.endswith("/v1"):
            base += "/v1"
        url = base + "/chat/completions"
        body = json.dumps({"model": model_id, "max_tokens": 8,
                           "messages": [{"role": "user", "content": "hi"}]})
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

    import urllib.error
    import urllib.request
    try:
        req = urllib.request.Request(url, data=body.encode(), headers=headers)
        raw = urllib.request.urlopen(req, timeout=timeout).read()
        d = json.loads(raw)
        if "11434" in endpoint:
            txt = ((d.get("message") or {}).get("content") or "").strip()
        else:
            txt = ((d.get("choices") or [{}])[0].get("message") or {}).get(
                "content") or ""
            if not txt.strip():
                txt = ((d.get("choices") or [{}])[0].get("message") or {}).get(
                    "reasoning_content") or ""
        return {"ok": bool(txt.strip()), "reply": txt.strip()[:40],
                "via": url}
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.code}",
                "detail": (e.read() or b"").decode("utf-8", "replace")[:120]}
    except Exception as e:
        return {"ok": False, "error": str(e)[:100]}


if __name__ == "__main__":
    d = detect_all()
    print(f"检测到 {d['installed']} 个 Agent")
    for it in d["items"]:
        mark = "OK " if it["installed"] else "   "
        print(f"\n{mark} {it['name']}  ({it['id']})")
        if it["installed"]:
            print(f"    路径: {it['path']}")
            if it["endpoint"]:
                print(f"    端点: {it['endpoint']}")
            print(f"    在用模型 {len(it['models'])} 个:")
            for m in it["models"]:
                role = "+".join(m.get("role") or [])
                extra = f" {m.get('sizeMb')}MB" if m.get("sizeMb") else ""
                print(f"      {m['id']:<44} [{role}]{extra}")
            if it.get("error"):
                print(f"    ⚠️ {it['error']}")
        else:
            print(f"    {it['error']}  → {it['download']}")
