"""发布前自动准备：启动浏览器 → 打开 Meta 工作标签 → 校验主页身份。

用户要求：「发布就自动打开相应浏览器和页面提取和发布」
即点「开始发布」后，程序自己把环境摆好，不需要人手动开浏览器/开标签。

流程（prepare_publish）：
    ① 找发布号环境（role=publisher）。没在跑就调 Hubstudio 启动，等 CDP 就绪。
    ② 用裸 CDP 打开唯一一个 Meta 工作标签（business.facebook.com/latest/）。
       · 若标签停在 bulk_upload_composer（ReelsPublisher 会拒），强制换页
       · 若环境里有多个工作标签，只留一个（否则 ReelsPublisher 报 AMBIGUOUS_WORK_TAB）
       · 关掉其它无关 page 标签，避免 playwright 扫描卡顿
    ③ 校验：该标签的 asset_id 能取到 → 记为当前主页
    ④ 返回 {ok, cdpPort, targetId, assetId, pageName}

失败时返回明确原因，前端提示用户。
"""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

import httpx

from app.db import db, now_iso

log = logging.getLogger("yuhai.prepare")

WORK_URL = "https://business.facebook.com/latest/home"
FORBIDDEN_PATH = "/latest/bulk_upload_composer"


# ---------------- CDP 基础 ----------------
async def _cdp_list(port: int, timeout: float = 12) -> list[dict]:
    async with httpx.AsyncClient(timeout=timeout) as c:
        r = await c.get(f"http://127.0.0.1:{port}/json/list")
        r.raise_for_status()
        return r.json()


async def _cdp_version(port: int, timeout: float = 8) -> dict:
    async with httpx.AsyncClient(timeout=timeout) as c:
        r = await c.get(f"http://127.0.0.1:{port}/json/version")
        r.raise_for_status()
        return r.json()


async def _cdp_close(port: int, target_id: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.get(f"http://127.0.0.1:{port}/json/close/{target_id}")
            return r.status_code == 200
    except Exception:
        return False


class _Tab:
    """最小 CDP 会话（只用于导航 + 取 URL）。"""

    def __init__(self, ws) -> None:
        self.ws = ws
        self._mid = 0

    async def cmd(self, method: str, params: dict | None = None,
                  timeout: float = 30) -> dict:
        self._mid += 1
        i = self._mid
        await self.ws.send(json.dumps({"id": i, "method": method,
                                       "params": params or {}}))
        while True:
            m = json.loads(await asyncio.wait_for(self.ws.recv(), timeout=timeout))
            if m.get("id") == i:
                return m

    async def eval(self, expr: str, timeout: float = 15):
        r = await self.cmd("Runtime.evaluate", {
            "expression": expr, "returnByValue": True,
            "awaitPromise": True, "userGesture": True}, timeout)
        res = (r.get("result") or {}).get("result") or {}
        return res.get("value")


async def _with_tab(port: int, target_id: str, fn, timeout: float = 120):
    """连上某个标签，执行 fn(tab)，最后关闭 ws。"""
    import websockets
    tabs = await _cdp_list(port)
    tab = next((t for t in tabs if t.get("id") == target_id), None)
    if not tab:
        raise RuntimeError(f"标签 {target_id[:8]} 不存在")
    ws = await asyncio.wait_for(
        websockets.connect(tab["webSocketDebuggerUrl"], max_size=16 * 2 ** 20),
        timeout=12)
    try:
        t = _Tab(ws)
        await t.cmd("Page.enable")
        return await asyncio.wait_for(fn(t), timeout=timeout)
    finally:
        try:
            await ws.close()
        except Exception:
            pass


# ---------------- 环境就绪 ----------------
async def _ensure_env(container_code: str = "") -> dict:
    """确保发布号环境在跑，返回 {code, port, pid}。"""
    row = None
    if container_code:
        row = db.q1("SELECT * FROM envs WHERE container_code=?", (container_code,))
    if not row:
        row = db.q1("SELECT * FROM envs WHERE role='publisher' ORDER BY updated_at DESC")
    if not row:
        raise RuntimeError("没有配置发布号环境")

    code = row["container_code"]
    port = int(row["cdp_port"] or 0)
    status = row["status"]

    # 已在跑：验证 CDP 真的能连（进程可能已死）
    if status == "running" and port:
        try:
            v = await _cdp_version(port)
            if v.get("webSocketDebuggerUrl"):
                log.info("env %s 已在运行 (CDP %s)", code, port)
                return {"code": code, "port": port, "pid": row["pid"], "started": False}
        except Exception:
            log.warning("env %s 标记 running 但 CDP %s 不通，重启", code, port)

    # 启动
    from app.adapters.hubstudio import hub
    d = await hub.start(code)
    port = int(d.get("debuggingPort") or 0)
    if not port:
        raise RuntimeError(f"启动环境 {code} 后没拿到 CDP 端口")

    # 等 CDP 就绪（最多 40 秒）
    for _ in range(40):
        try:
            v = await _cdp_version(port, timeout=5)
            if v.get("webSocketDebuggerUrl"):
                break
        except Exception:
            await asyncio.sleep(1)
    else:
        raise RuntimeError(f"环境 {code} 启动了但 CDP {port} 无响应")

    pid = None
    try:
        import psutil
        for c in psutil.net_connections(kind="inet"):
            if c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == port and c.pid:
                pid = int(c.pid)
                break
    except Exception:
        pass

    db.exec("UPDATE envs SET status='running',pid=?,cdp_port=?,updated_at=? "
            "WHERE container_code=?", (pid, port, now_iso(), code))
    db.log_event("ok", "prepare", f"自动启动环境 {code} → CDP {port}")
    return {"code": code, "port": port, "pid": pid, "started": True}


# ---------------- 标签整理 ----------------
def _is_meta_work(url: str) -> bool:
    return (url or "").startswith("https://business.facebook.com/latest/")


def _is_forbidden(url: str) -> bool:
    return FORBIDDEN_PATH in (url or "")


async def _arrange_tabs(port: int) -> dict:
    """整理成「恰好一个可用的 Meta 工作标签」，返回该标签信息。"""
    tabs = await _cdp_list(port)
    pages = [t for t in tabs if t.get("type") == "page"]
    log.info("环境标签: %d 个 page", len(pages))

    good = [t for t in pages
            if _is_meta_work(t.get("url") or "") and not _is_forbidden(t.get("url") or "")]
    forbidden = [t for t in pages if _is_forbidden(t.get("url") or "")]

    # 1. 已有一个合格工作标签
    if len(good) == 1:
        keep = good[0]
        log.info("复用现有工作标签 %s", keep["id"][:8])
    elif len(good) > 1:
        # 多个：留第一个，其余关掉（否则 AMBIGUOUS_WORK_TAB）
        keep = good[0]
        for t in good[1:]:
            await _cdp_close(port, t["id"])
            log.info("关闭重复工作标签 %s", t["id"][:8])
    else:
        # 没有合格标签：优先把 forbidden 的改造，否则把第一个 page 改造
        target = forbidden[0] if forbidden else (pages[0] if pages else None)
        if not target:
            raise RuntimeError("环境里没有任何标签，无法打开工作页")
        keep = target

    # 2. 导航到工作页（若当前不合适）
    cur = keep.get("url") or ""
    if not (_is_meta_work(cur) and not _is_forbidden(cur)):
        log.info("导航 %s → latest/home", keep["id"][:8])

        async def nav(t: _Tab):
            await t.cmd("Page.navigate", {"url": WORK_URL}, 40)
            for _ in range(25):
                await asyncio.sleep(1.2)
                href = await t.eval("location.href")
                if href and "business.facebook.com" in str(href):
                    return str(href)
            return str(await t.eval("location.href") or "")

        final = await _with_tab(port, keep["id"], nav, timeout=90)
        log.info("导航完成: %s", str(final)[:80])

    # 3. 关掉其它 page 标签（减少 playwright 扫描负担）
    closed = 0
    for t in pages:
        if t.get("id") == keep.get("id"):
            continue
        # 只关 http(s) 的普通页面，别动扩展
        u = t.get("url") or ""
        if u.startswith("http") or u.startswith("business.facebook"):
            if await _cdp_close(port, t["id"]):
                closed += 1
    if closed:
        log.info("关闭 %d 个多余标签", closed)

    # 4. 取最终 URL / asset_id
    tabs2 = await _cdp_list(port)
    final_tab = next((t for t in tabs2 if t.get("id") == keep.get("id")), None)
    if not final_tab:
        raise RuntimeError("整理标签后找不到工作标签")
    url = final_tab.get("url") or ""
    asset = ""
    try:
        from urllib.parse import parse_qs, urlparse
        q = parse_qs(urlparse(url).query)
        asset = (q.get("asset_id") or q.get("page_id") or [""])[0]
    except Exception:
        pass

    return {"targetId": final_tab["id"], "url": url, "assetId": asset}


# ---------------- 主入口 ----------------
async def prepare_publish(container_code: str = "") -> dict:
    """一键准备：环境 + 工作标签 + 主页识别。

    返回：
        ok, code, cdpPort, targetId, url, assetId, pageName, started
    """
    try:
        env = await _ensure_env(container_code)
    except Exception as e:
        log.error("prepare env failed: %s", e)
        return {"ok": False, "stage": "env", "error": str(e)}

    try:
        tab = await _arrange_tabs(env["port"])
    except Exception as e:
        log.error("prepare tabs failed: %s", e)
        return {"ok": False, "stage": "tabs", "error": str(e),
                "cdpPort": env["port"]}

    # 主页名（用 asset_id 反查）
    page_name = ""
    if tab.get("assetId"):
        p = db.q1("SELECT name FROM pages WHERE asset_id=?", (tab["assetId"],))
        page_name = (p or {}).get("name") or ""

    return {
        "ok": True,
        "code": env["code"],
        "cdpPort": env["port"],
        "pid": env["pid"],
        "started": env.get("started", False),
        **tab,
        "pageName": page_name,
    }
