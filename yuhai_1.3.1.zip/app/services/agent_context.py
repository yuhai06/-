# -*- coding: utf-8 -*-
"""agent_context.py — 会话摘要 + 重要记忆注入

解决两个问题：
  ① 只带最近 8 条 → 早期信息丢失（失忆）
  ② 重要事实（比如"我发号是网易01"）跨会话也要记住

做法：
  · 早期消息 → 压缩成摘要（每 10 条压一次，存在 agent_chats.summary）
  · 重要记忆 → key/value 表，自动挑相关的注入提示词
"""
from __future__ import annotations

import json
import logging
import re

from app.db import db, now_iso

log = logging.getLogger("yuhai.agent_context")

RECENT_KEEP = 8          # 最近保留多少条原文
SUMMARIZE_AT = 16        # 超过多少条开始压缩
SUMMARY_MAX = 600        # 摘要最大字符


# ══════════════════════════════════════════
#  会话摘要
# ══════════════════════════════════════════
def get_summary(chat_id: str) -> str:
    """读会话摘要。"""
    r = db.q1("SELECT summary FROM agent_chats WHERE id=?", (chat_id,))
    return (r or {}).get("summary") or ""


def set_summary(chat_id: str, text: str) -> None:
    db.exec("UPDATE agent_chats SET summary=? WHERE id=?",
            ((text or "")[:SUMMARY_MAX], chat_id))


def build_summary(chat_id: str, model: str = "") -> str:
    """把早期消息规则压缩成摘要（不调模型，快且省）。

    抽：用户说了什么、AI 做了哪些工具、关键结论。
    """
    msgs = db.q(
        """SELECT role, content, trace FROM agent_msgs
           WHERE chat_id=? ORDER BY id ASC""", (chat_id,))
    if len(msgs) <= RECENT_KEEP:
        return ""

    early = msgs[:-RECENT_KEEP]
    lines = []
    for m in early:
        role = m["role"]
        c = (m["content"] or "").strip().replace("\n", " ")
        if role == "user" and c:
            lines.append("· 用户说过: " + c[:90])
        elif role == "assistant":
            try:
                tr = json.loads(m.get("trace") or "[]")
            except Exception:
                tr = []
            if tr:
                tools = ", ".join(t.get("tool", "") for t in tr[:6])
                lines.append("· 执行过: " + tools)
            if c:
                lines.append("· 结论: " + c[:100])

    # 去重 + 限长
    seen = set()
    uniq = []
    for ln in lines:
        if ln not in seen:
            seen.add(ln)
            uniq.append(ln)
    text = "\n".join(uniq)
    if len(text) > SUMMARY_MAX:
        text = text[-SUMMARY_MAX:]  # 保留最近发生的
    return text


def maybe_summarize(chat_id: str) -> str:
    """消息够多时自动压缩早期内容，返回最新摘要。"""
    n = (db.q1("SELECT COUNT(*) c FROM agent_msgs WHERE chat_id=?",
               (chat_id,)) or {}).get("c", 0)
    if n < SUMMARIZE_AT:
        return get_summary(chat_id)
    s = build_summary(chat_id)
    if s:
        set_summary(chat_id, s)
        log.info("summarized chat %s (%d msgs)", chat_id, n)
    return s


# ══════════════════════════════════════════
#  重要记忆
# ══════════════════════════════════════════
def ensure_table() -> None:
    db.exec("""CREATE TABLE IF NOT EXISTS agent_memory (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at INTEGER NOT NULL)""")


def set_memory(key: str, value: str) -> dict:
    ensure_table()
    db.exec("""INSERT INTO agent_memory (key, value, updated_at)
               VALUES (?,?,?)
               ON CONFLICT(key) DO UPDATE SET value=?, updated_at=?""",
            (key, value, int(now_iso().replace("-", "").replace("T", "")
                             .replace(":", "").replace(" ", "")[:14] or 0),
             value, 0))
    return {"ok": True, "key": key}


def list_memory(limit: int = 40) -> dict:
    ensure_table()
    rows = db.q("""SELECT key, value FROM agent_memory
                   ORDER BY updated_at DESC LIMIT ?""", (limit,))
    return {"ok": True, "items": [
        {"key": r["key"], "value": r["value"]} for r in rows]}


def del_memory(key: str) -> dict:
    ensure_table()
    db.exec("DELETE FROM agent_memory WHERE key=?", (key,))
    return {"ok": True, "deleted": key}


def auto_remember(text: str) -> list[str]:
    """从用户消息里抽取要长期记住的事实。

    ⚠️ 严格模式（重要）：
      只有用户**明确要求记住**时才抽，例如：
        「记住 我的发布号固定用网易01」   → 存
        「记牢：切片一律 target=45」       → 存

    ⚠️ 这些**不存**：
        「不要用QQ号」        → 当前任务的临时要求，不是永久规则
        「以后都用XX」        → 可能是这次的做法，不一定长期
        「每次都要检查一遍」  → 同上

    为什么这么严：写错的记忆会被模型每次对话都看到，
    很难自己发现，会一直污染判断。
    需要长期规则时，让用户自己说「记住…」，或手动 memory_set。
    """
    out = []
    t = (text or "").strip()
    if not t or len(t) > 400:
        return out

    # 必须出现强记忆指令，且指令后紧跟内容
    M = ("记住", "记牢", "记一下", "别忘了", "不要忘", "永久记住",
         "一直记住", "长期记住")
    pat = r"(?:请|帮我|给我|你)?\s*(%s)\s*[:：，,、\s]\s*(.{6,150})" % "|".join(M)
    m = re.search(pat, t)
    if not m:
        return out

    frag = m.group(2).strip().rstrip("。，,.;；!！")
    # 排除疑问（「记住我说的了吗？」）
    if frag and ("？" not in frag and "?" not in frag):
        # 排除纯否定（「记住不要用QQ」→ 这确实该记，所以不排除）
        out.append("explicit:" + frag[:120])
    return out


def save_auto(text: str) -> list[dict]:
    """自动记住并入库（同 key 覆盖）。

    ⚠️ 严格模式：只有 auto_remember 抽到内容才写；
    关掉 AUTO_MEMORY_ENABLED 时永远不写。
    """
    saved = []
    for frag in auto_remember(text):
        kind, _, val = frag.partition(":")
        key = "auto_" + kind
        try:
            ensure_table()
            db.exec("""INSERT INTO agent_memory (key, value, updated_at)
                       VALUES (?,?,?)
                       ON CONFLICT(key) DO UPDATE SET value=?""",
                    (key, val, 0, val))
            saved.append({"key": key, "value": val})
        except Exception as e:
            log.warning("save memory failed: %s", e)
    return saved


def memory_block(question: str = "", limit: int = 12) -> str:
    """构造要注入提示词的记忆文本。

    简单相关度：记忆内容里出现问题中的关键词就优先。
    """
    ensure_table()
    rows = db.q("""SELECT key, value FROM agent_memory
                   ORDER BY updated_at DESC LIMIT ?""", (limit,))
    if not rows:
        return ""

    qwords = set(re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]{3,}",
                            question or ""))
    scored = []
    for r in rows:
        v = r["value"] or ""
        hit = sum(1 for w in qwords if w in v)
        scored.append((hit, r["key"], v))
    scored.sort(key=lambda x: -x[0])

    lines = []
    for _, k, v in scored[:limit]:
        if not v:
            continue
        lines.append(f"- [{k}] {v[:120]}")
    if not lines:
        return ""
    return ("【长期记忆 · 用户之前定下的规则和事实，必须遵守】\n"
            + "\n".join(lines) + "\n\n")


# ══════════════════════════════════════════
#  给 chat 用的完整上下文
# ══════════════════════════════════════════
def build_context(chat_id: str, user_msg: str,
                  recent: int = RECENT_KEEP) -> dict:
    """组装：摘要 + 记忆 + 最近 N 条。"""
    summary = maybe_summarize(chat_id) if chat_id else ""
    mem = memory_block(user_msg)

    history = []
    if chat_id:
        rows = db.q(
            """SELECT role, content FROM agent_msgs
               WHERE chat_id=? ORDER BY id DESC LIMIT ?""",
            (chat_id, recent))
        rows = list(reversed(rows))
        history = [{"role": r["role"], "content": r["content"] or ""}
                   for r in rows if (r["content"] or "").strip()]

    prefix = ""
    if summary:
        prefix += "【早期对话摘要 · 你可能需要参考】\n" + summary + "\n\n"
    prefix += mem

    return {"prefix": prefix, "history": history, "summary": summary,
            "memoryUsed": bool(mem)}
