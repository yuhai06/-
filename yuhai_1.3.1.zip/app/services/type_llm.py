# -*- coding: utf-8 -*-
"""type_llm.py — 用大模型判定剧型（比关键词更准）

流程：
  ① 抽台词样本（开头/中间/高潮各取，控制在 300 字内）
  ② 拼提示词：7 种类型定义 + 样本 + 要求输出 JSON
  ③ 调模型（优先 Agent 接入的模型）
  ④ 校验结果：类型必须在清单内，否则拒绝
  ⑤ 写进 type_override.json（等同手动指定）

为什么比关键词准：
  · 关键词只看字面，模型看语义
  · 「他跪下来求我」→ 关键词命中"跪下"算纯爽，但可能是伦理剧的认错
  · 模型能理解上下文、人物关系、剧情走向
"""
from __future__ import annotations

import io
import json
import logging
import os
import re
import sys

log = logging.getLogger("yuhai.type_llm")

# 7 种类型的语义定义（给模型看的，不是关键词）
TYPE_DEFS = {
    "纯爽反打流": {
        "core": "主角被轻视/羞辱，然后身份揭露或实力碾压，让对方打脸认错",
        "signals": ["当众被看不起", "身份曝光反转", "下跪求饶", "财富权力碾压"],
        "avoid": "如果只是吵架没身份反转，不算这类",
    },
    "伦理撕扯流": {
        "core": "家庭/婚姻伦理冲突：出轨、离婚、争产、婆媳、抚养权",
        "signals": ["出轨被发现", "离婚争夺", "家人互撕", "亲子/继亲矛盾"],
        "avoid": "纯恋爱甜宠不算，必须有伦理撕扯",
    },
    "大佬撑腰流": {
        "core": "有权势者出面保护主角，压制造反者",
        "signals": ["保镖/靠山出现", "放话威胁对方", "势力碾压"],
        "avoid": "主角自己变强不算，必须是外部靠山",
    },
    "倒叙悬疑流": {
        "core": "隐藏真相逐步揭露：命案、秘密、阴谋、身份谜团",
        "signals": ["往事回忆", "证据浮现", "凶手身份", "隐瞒被拆穿"],
        "avoid": "单纯误会解开不算悬疑",
    },
    "张力拉锯流": {
        "core": "两人之间强烈的拉扯：爱恨交织、欲拒还迎、势均力敌对峙",
        "signals": ["亲密接触又推开", "口是心非", "情绪张力强", "反复纠缠"],
        "avoid": "单向追求不算拉锯，要双向",
    },
    "甜宠轻度流": {
        "core": "轻松甜向：宠爱、撒娇、日常温馨，冲突很小",
        "signals": ["宠溺桥段", "撒娇吃醋", "甜蜜互动", "无重大冲突"],
        "avoid": "有严重打脸/撕扯的不算轻度",
    },
    "重生逆袭流": {
        "core": "主角死过/重来一次，带着记忆改写命运",
        "signals": ["明确说前世/重生", "预知未来", "改变过去的选择"],
        "avoid": "只是励志翻身不算，必须有重生设定",
    },
}

PROMPT_TMPL = """你是短剧类型分析专家。根据下面的台词片段判断这部剧属于哪一类。

【可选类型】（必须严格从这 7 个里选一个，不能自己造）
{defs}

【台词片段】
（注意：台词可能是英语、印尼语、葡萄牙语、法语、日语、他加禄语等，
请按语义理解，不要因为不是中文就降低判断质量）
{sample}

【要求】
1. 只输出一个 JSON 对象，不要任何其他文字
2. 格式：
{{"type":"类型名","confidence":0.85,"reason":"判断依据（30字内）",
 "alternative":"次可能类型或空","altConfidence":0.4}}
3. confidence 是 0-1 的小数，表示你有多确定
   · 0.8-1.0  剧情主线清晰，几乎确定
   · 0.5-0.79 大致能判断，可能有次选
   · 0.3-0.49 只能猜，信息不足
   · < 0.3    基本判不出
4. 如果实在都不像，type 填 "不确定"，confidence 填小于 0.3
5. 不要因为「没有明显特征」就给低分 —— 先想这部剧的主线是什么，
   再对应最接近的类型
5. 判断要看剧情本质，不要被单个词误导
"""


def _fmt_defs() -> str:
    lines = []
    for name, d in TYPE_DEFS.items():
        lines.append("- %s：%s\n  特征：%s\n  排除：%s"
                     % (name, d["core"], "、".join(d["signals"]), d["avoid"]))
    return "\n".join(lines)


def _state() -> str:
    """状态目录（transcript 在 state/subs 下）。"""
    try:
        from app import paths
        return str(paths.state_dir())
    except Exception:
        pass
    env = os.environ.get("YUHAI_STATE")
    if env:
        return env
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "_state")


def get_sample(drama: str, max_chars: int = 380) -> str:
    """抽台词样本。

    策略：均匀取 3 段（开头 1/5、中间 1/2、接近结尾 4/5），
    每段取若干句，拼起来不超过 max_chars。
    这样能看到铺垫、冲突、结局。
    """
    state = _state()
    f = os.path.join(state, "subs", drama + "_transcript.json")
    if not os.path.exists(f):
        return ""
    try:
        d = json.loads(io.open(f, encoding="utf-8-sig").read())
    except Exception:
        return ""
    segs = d.get("segments") or []
    if not segs:
        return ""

    n = len(segs)
    picks = []
    for frac in (0.05, 0.25, 0.45, 0.65, 0.85):
        i = max(0, min(n - 1, int(n * frac)))
        picks.append(i)

    out = []
    total = 0
    for i in picks:
        # 每个锚点取连续 3 句
        chunk = []
        for j in range(i, min(i + 3, n)):
            t = (segs[j].get("text") or "").strip()
            if t:
                chunk.append(t)
        s = " ".join(chunk)
        if not s:
            continue
        if total + len(s) > max_chars:
            break
        out.append("[%d%%] %s" % (int(i / n * 100), s))
        total += len(s)

    return "\n".join(out)


def call_llm(prompt: str, model: str = "") -> tuple[str, str]:
    """调模型。优先用 Agent 接入的模型。"""
    from app.services import ai_analysis as ai
    return _run_async(ai.call_model, prompt, model)


def _run_async(fn, *args):
    """同步跑 async 函数。

    ⚠️ 关键：先判断有没有 event loop，再决定怎么跑。
    不能先 asyncio.run() 失败再重试 —— 那样第一次创建的 coroutine
    会成为孤儿，触发「was never awaited」警告。
    """
    import asyncio
    import concurrent.futures

    try:
        asyncio.get_running_loop()
        has_loop = True
    except RuntimeError:
        has_loop = False

    if not has_loop:
        return asyncio.run(fn(*args))

    # 已在 loop 里 → 开新线程（此时才创建 coroutine）
    with concurrent.futures.ThreadPoolExecutor() as ex:
        return ex.submit(lambda: asyncio.run(fn(*args))).result(
            timeout=300)


def parse_result(text: str) -> dict | None:
    """解析模型输出。宽容处理各种格式。"""
    if not text:
        return None
    # 去 markdown 包裹
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)

    # 直接解析
    try:
        d = json.loads(t)
        if isinstance(d, dict):
            return d
    except Exception:
        pass

    # 抓第一个 {...}
    m = re.search(r"\{[^{}]*\}", t, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass

    # 退化：找类型名
    for name in TYPE_DEFS:
        if name in t:
            return {"type": name, "confidence": 0.5,
                    "reason": "从文本中提取", "alternative": ""}
    return None


def judge(drama: str, model: str = "",
          apply: bool = True) -> dict:
    """用模型判定剧型。

    apply=True 时把结果写进 override（等同手动指定），
    这样后续切片就用这个类型。
    """
    sample = get_sample(drama)
    if not sample:
        return {"ok": False, "error": "没找到转录文件或台词为空",
                "drama": drama}

    prompt = PROMPT_TMPL.format(defs=_fmt_defs(), sample=sample)
    try:
        text, used = call_llm(prompt, model)
    except Exception as e:
        return {"ok": False, "error": "模型调用失败: %s" % str(e)[:120],
                "drama": drama}

    d = parse_result(text)
    if not d:
        return {"ok": False, "error": "模型输出无法解析",
                "raw": text[:200], "drama": drama}

    tname = (d.get("type") or "").strip()
    conf = float(d.get("confidence") or 0)
    reason = (d.get("reason") or "")[:120]
    alt = (d.get("alternative") or "").strip()
    altc = float(d.get("altConfidence") or 0)

    # 「不确定」是合法回答（模型诚实说判不出），单独处理
    if tname in ("不确定", "unknown", "未知", ""):
        return {"ok": True, "drama": drama, "type": "不确定",
                "confidence": round(conf, 2), "reason": reason,
                "uncertain": True, "applied": False,
                "model": used, "sampleLen": len(sample),
                "note": "模型判不出，建议手动指定或看台词自己定",
                "suggestManual": list(TYPE_DEFS.keys())}

    # 其他非法类型才报错
    if tname not in TYPE_DEFS:
        return {"ok": False,
                "error": "模型返回的类型不在清单内: %s" % tname,
                "raw": text[:150], "drama": drama,
                "validTypes": list(TYPE_DEFS.keys())}

    # 置信度过低 → 不采纳，但要告诉调用方
    low = conf < 0.4
    if apply and not low:
        try:
            from tools import classify  # type: ignore
        except Exception:
            pass
        try:
            sys.path.insert(0, _tools_dir())
            import classify as C
            C.set_override(drama, tname)
            applied = True
        except Exception as e:
            log.warning("apply override failed: %s", e)
            applied = False
    else:
        applied = False

    return {
        "ok": True,
        "drama": drama,
        "type": tname,
        "confidence": round(conf, 2),
        "reason": reason,
        "alternative": alt,
        "altConfidence": round(altc, 2),
        "lowConfidence": low,
        "applied": applied,
        "model": used,
        "sampleLen": len(sample),
        "note": ("已应用（后续切片用这个类型）" if applied
                 else ("置信度过低未应用，可用 drama_set_type 手动指定"
                       if low else "仅判定未应用")),
    }


def _tools_dir():
    try:
        from app import paths
        return str(paths.tools_dir())
    except Exception:
        return os.path.dirname(os.path.abspath(__file__))


def judge_batch(dramas: list, model: str = "",
                apply: bool = True, only_fallback: bool = True) -> dict:
    """批量判型。only_fallback=True 只处理没达标的。"""
    results = []
    for d in dramas:
        try:
            r = judge(d, model, apply)
            results.append(r)
        except Exception as e:
            results.append({"ok": False, "drama": d,
                            "error": str(e)[:100]})
    ok = [x for x in results if x.get("ok")]
    applied = [x for x in results if x.get("applied")]
    return {"ok": True, "total": len(results),
            "success": len(ok), "applied": len(applied),
            "results": results}


ALL_TYPES = list(TYPE_DEFS.keys())
