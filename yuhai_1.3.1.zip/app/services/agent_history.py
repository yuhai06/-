# -*- coding: utf-8 -*-
"""agent_history.py — Agent 会话历史（列表 / 新建 / 读取 / 追加 / 删除）"""
from __future__ import annotations

import json
import logging
import time
import uuid

from app.db import db, now_iso

log = logging.getLogger("yuhai.agent_history")


def _new_id() -> str:
    return "c" + uuid.uuid4().hex[:12]


def list_chats(limit: int = 40, q: str = "") -> dict:
    """会话列表（按更新时间倒序，置顶优先）。"""
    if q:
        rows = db.q(
            """SELECT * FROM agent_chats
               WHERE title LIKE ? ORDER BY pinned DESC, updated_at DESC
               LIMIT ?""", ("%" + q + "%", limit))
    else:
        rows = db.q(
            """SELECT * FROM agent_chats
               ORDER BY pinned DESC, updated_at DESC LIMIT ?""", (limit,))
    return {"ok": True, "items": [
        {"id": r["id"], "title": r.get("title") or "新对话",
         "agent": r.get("agent") or "", "model": r.get("model") or "",
         "msgCount": r.get("msg_count") or 0,
         "pinned": bool(r.get("pinned")),
         "updatedAt": r.get("updated_at") or "",
         "createdAt": r.get("created_at") or ""}
        for r in rows]}


def create_chat(title: str = "", agent: str = "", model: str = "") -> dict:
    """新建一个空会话。"""
    cid = _new_id()
    ts = now_iso()
    db.exec(
        """INSERT INTO agent_chats
           (id, title, agent, model, created_at, updated_at, msg_count, pinned)
           VALUES (?,?,?,?,?,?,0,0)""",
        (cid, title or "新对话", agent, model, ts, ts))
    return {"ok": True, "id": cid, "title": title or "新对话"}


def get_chat(chat_id: str, limit: int = 200) -> dict:
    """读一个会话的全部消息。"""
    c = db.q1("SELECT * FROM agent_chats WHERE id=?", (chat_id,))
    if not c:
        return {"ok": False, "error": "会话不存在"}
    msgs = db.q(
        """SELECT * FROM agent_msgs WHERE chat_id=?
           ORDER BY id ASC LIMIT ?""", (chat_id, limit))
    out = []
    for m in msgs:
        item = {"role": m["role"], "content": m.get("content") or "",
                "model": m.get("model") or ""}
        try:
            item["trace"] = json.loads(m.get("trace") or "[]")
        except Exception:
            item["trace"] = []
        try:
            item["atts"] = json.loads(m.get("atts") or "[]")
        except Exception:
            item["atts"] = []
        if m.get("error"):
            item["error"] = True
        out.append(item)
    return {"ok": True, "id": chat_id,
            "title": c.get("title") or "新对话",
            "agent": c.get("agent") or "", "model": c.get("model") or "",
            "messages": out}


def append_msg(chat_id: str, role: str, content: str,
               model: str = "", trace: list | None = None,
               atts: list | None = None, error: bool = False) -> dict:
    """往会话追加一条消息，并刷新会话更新时间/计数。"""
    ts = now_iso()
    db.exec(
        """INSERT INTO agent_msgs
           (chat_id, role, content, model, trace, atts, error, created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (chat_id, role, content or "", model or "",
         json.dumps(trace or [], ensure_ascii=False),
         json.dumps(atts or [], ensure_ascii=False),
         1 if error else 0, ts))
    db.exec(
        """UPDATE agent_chats SET updated_at=?,
           msg_count=(SELECT COUNT(*) FROM agent_msgs WHERE chat_id=?)
           WHERE id=?""", (ts, chat_id, chat_id))
    # 首条用户消息自动成为标题
    c = db.q1("SELECT title, msg_count FROM agent_chats WHERE id=?", (chat_id,))
    if c and (c.get("title") in ("", "新对话")) and role == "user" and content:
        t = content.strip().replace("\n", " ")[:28]
        db.exec("UPDATE agent_chats SET title=? WHERE id=?", (t, chat_id))
    return {"ok": True}


def rename_chat(chat_id: str, title: str) -> dict:
    db.exec("UPDATE agent_chats SET title=? WHERE id=?", (title, chat_id))
    return {"ok": True, "id": chat_id, "title": title}


def pin_chat(chat_id: str, pinned: bool = True) -> dict:
    db.exec("UPDATE agent_chats SET pinned=? WHERE id=?",
            (1 if pinned else 0, chat_id))
    return {"ok": True, "id": chat_id, "pinned": pinned}


def delete_chat(chat_id: str) -> dict:
    db.exec("DELETE FROM agent_msgs WHERE chat_id=?", (chat_id,))
    db.exec("DELETE FROM agent_chats WHERE id=?", (chat_id,))
    return {"ok": True, "deleted": chat_id}


def clear_all() -> dict:
    db.exec("DELETE FROM agent_msgs")
    db.exec("DELETE FROM agent_chats")
    return {"ok": True}
