"""环境自检 + 自动安装。

设计目标（用户要求）：**不只能在我这台电脑跑**。
换电脑时缺什么就装什么，或者明确告诉用户怎么装。

检查项：
    ① ffmpeg / ffprobe（内置优先，其次 PATH）
    ② Python 包：faster-whisper / Pillow / httpx / psutil / imapclient / zstandard
    ③ GPU / CUDA（faster-whisper 加速用，没有就降级 CPU）
    ④ NVENC（ffmpeg 硬件编码，没有就用 libx264）
    ⑤ tools/ 脚本目录
    ⑥ 字体（Montserrat，PIL 渲染字幕用）
    ⑦ BGM 音频素材
    ⑧ 本地 Clash 代理（抓取用）

安装策略：
    · Python 包 → pip install（可自动执行）
    · ffmpeg → 内置已打包；没有就提示下载地址 + 尝试 winget/choco
    · 字体/BGM → 提示从哪拷，或自动从内置资源复制
"""
from __future__ import annotations

import logging
import os
import shutil
import sys
from pathlib import Path

from app.config import settings
from app import paths as _paths
from app import proc

log = logging.getLogger("yuhai.envcheck")


# ---------------- Python 包 ----------------
PY_PACKAGES = [
    {"name": "faster-whisper", "import": "faster_whisper",
     "why": "台词转录（切片流程核心）", "required": True,
     "pip": "faster-whisper>=1.0"},
    {"name": "Pillow", "import": "PIL",
     "why": "字幕/CTA 图片渲染", "required": True, "pip": "Pillow"},
    {"name": "httpx", "import": "httpx",
     "why": "HTTP 请求", "required": True, "pip": "httpx"},
    {"name": "psutil", "import": "psutil",
     "why": "进程/端口探测", "required": True, "pip": "psutil"},
    {"name": "imapclient", "import": "imapclient",
     "why": "邮箱验证码", "required": False, "pip": "IMAPClient"},
    {"name": "zstandard", "import": "zstandard",
     "why": "压缩", "required": False, "pip": "zstandard"},
    {"name": "pywebview", "import": "webview",
     "why": "桌面窗口", "required": False, "pip": "pywebview"},
]


# ---------------- ASR 模型 ----------------
# 每个模型的标准文件（faster-whisper 结构）；缺 model.bin 就等于不可用
WHISPER_FILES = ("config.json", "model.bin", "tokenizer.json",
                 "vocabulary.txt")

WHISPER_MODELS = {
    "tiny":   {"mb": 75,   "repo": "Systran/faster-whisper-tiny",
               "why": "极速，精度低，仅测试用"},
    "small":  {"mb": 464,  "repo": "Systran/faster-whisper-small",
               "why": "默认模型，英语/印尼语准确，中文一般"},
    "medium": {"mb": 1460, "repo": "Systran/faster-whisper-medium",
               "why": "中文/日语准确率高，速度慢约 2 倍"},
}

# 模型下载源（按顺序尝试；hf-mirror 国内快，modelscope 是备份）
MODEL_MIRRORS = [
    "https://huggingface.co/{repo}/resolve/main/{file}",
    "https://hf-mirror.com/{repo}/resolve/main/{file}",
    "https://hf-mirror.com/{repo}/resolve/main/{file}?download=true",
]

# tools 脚本版本清单：头部必须含 `# VER: <tag>`
TOOLS_VERSION = {
    "transcribe_audio.py": "20261108-auto",
    "score_lines2.py": "20261108-cn",
    "classify.py": "20261108-cn",
    "detect_lang.py": "20261108",
    "cut_ep2.py": "20261107",
    "plan_from_tension.py": "20261107",
    "voice_check3.py": "20261107",
    "render_plan.py": "20261107",
    "pipeline2.py": "20261107",
    "mark_done.py": "20261107",
}


def _model_ok(d: Path) -> bool:
    """目录里有没有完整的模型文件。"""
    return d.is_dir() and (d / "model.bin").exists() and \
        (d / "model.bin").stat().st_size > 10 * 1024 * 1024


def check_whisper_model(want: str = "small") -> dict:
    """检查 ASR 模型是否可用（本地 models\\ / HF 缓存都算）。"""
    from app import paths as _p

    md = _p.models_dir()
    local = md / f"faster-whisper-{want}"
    if _model_ok(local):
        return {"ok": True, "name": want, "path": str(local),
                "where": "local", "sizeMb": round(
                    sum(f.stat().st_size for f in local.glob("*")
                        if f.is_file()) / 1048576, 1)}

    # HF 缓存兜底（本机开发时常用）
    hf = (Path.home() / ".cache" / "huggingface" / "hub" /
          f"models--Systran--faster-whisper-{want}")
    if hf.exists():
        snaps = list((hf / "snapshots").glob("*")) if (hf / "snapshots").exists() else []
        for s in snaps:
            if _model_ok(s):
                return {"ok": True, "name": want, "path": str(s),
                        "where": "hf-cache",
                        "sizeMb": round(
                            sum(f.stat().st_size for f in s.glob("*")
                                if f.is_file()) / 1048576, 1)}

    # 其它本地模型（用户可能只下了 tiny/medium）
    others = []
    for d in md.glob("faster-whisper-*") if md.exists() else []:
        if _model_ok(d):
            others.append(d.name.replace("faster-whisper-", ""))

    return {
        "ok": False, "name": want, "path": str(local), "where": "",
        "sizeMb": 0,
        "have": others,
        "needMb": WHISPER_MODELS.get(want, {}).get("mb", 0),
        "hint": (f"缺 faster-whisper-{want}（约 "
                 f"{WHISPER_MODELS.get(want, {}).get('mb', '?')}MB）"
                 f"，点「更新」自动下载"
                 + (f"；已有: {', '.join(others)}" if others else "")),
    }


def install_whisper_model(want: str = "small", proxy: str = "") -> dict:
    """下载 ASR 模型到 models\\（多镜像 + 断点续传）。"""
    from app import paths as _p

    info = WHISPER_MODELS.get(want)
    if not info:
        return {"ok": False, "error": f"未知模型: {want}"}

    dst = _p.models_dir() / f"faster-whisper-{want}"
    if _model_ok(dst):
        return {"ok": True, "via": "already", "dir": str(dst)}

    dst.mkdir(parents=True, exist_ok=True)
    repo = info["repo"]
    attempts = []

    for fname in WHISPER_FILES:
        target = dst / fname
        # 大文件才需要 10MB 门槛，小文件按 32 字节
        min_b = 10 * 1048576 if fname == "model.bin" else 32
        if target.exists() and target.stat().st_size >= min_b:
            attempts.append({"file": fname, "ok": True, "via": "already"})
            continue

        got = None
        for tpl in MODEL_MIRRORS:
            url = tpl.format(repo=repo, file=fname)
            dl = _download(url, target, proxy=proxy, timeout=1800,
                           min_bytes=min_b)
            attempts.append({"file": fname, "url": url.split("/")[2],
                             **{k: dl.get(k) for k in ("ok", "via", "error")}})
            if dl.get("ok"):
                got = dl
                break
        if not got:
            return {"ok": False, "dir": str(dst),
                    "error": f"{fname} 下载失败（所有镜像都不通）",
                    "attempts": attempts,
                    "manual": [
                        f"手动下载 {repo} 的全部 4 个文件",
                        f"放到 {dst}",
                        "或点开 https://hf-mirror.com/" + repo,
                    ]}

    ok = _model_ok(dst)
    size = round(sum(f.stat().st_size for f in dst.glob("*")
                     if f.is_file()) / 1048576, 1)
    return {"ok": ok, "via": "download", "dir": str(dst),
            "sizeMb": size, "attempts": attempts,
            "note": f"已下载 {want} 模型 {size}MB"}



def check_python() -> list[dict]:
    out = []
    for p in PY_PACKAGES:
        ok = False
        ver = ""
        try:
            mod = __import__(p["import"])
            ok = True
            ver = getattr(mod, "__version__", "")
        except Exception:
            ok = False
        out.append({**p, "ok": ok, "version": str(ver)[:20]})
    return out


# ---------------- 可执行 ----------------
def check_ffmpeg() -> dict:
    from app.services import video_maker as vm
    ff = vm.ffmpeg_path()
    fp = vm.ffprobe_path()
    ok = False
    ver = ""
    nvenc = False
    try:
        r = proc.run([ff, "-version"], capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
        ok = r.returncode == 0
        ver = (r.stdout or "").split("\n")[0][:100]
        if ok:
            r2 = proc.run([ff, "-hide_banner", "-encoders"],
                                capture_output=True, text=True, timeout=20,
                                encoding="utf-8", errors="replace")
            nvenc = "h264_nvenc" in (r2.stdout or "")
    except Exception as e:
        ver = str(e)[:100]
    return {"ok": ok, "ffmpeg": ff, "ffprobe": fp, "version": ver,
            "bundled": (vm._bundle_dir() / "ffmpeg.exe").exists(),
            "nvenc": nvenc,
            "hint": "" if ok else "内置未打包且 PATH 里没有。"
                                  "下载 https://www.gyan.dev/ffmpeg/builds/ 解压后"
                                  "把 ffmpeg.exe/ffprobe.exe 放到程序目录 bin\\ 下"}


def check_gpu() -> dict:
    """GPU 检测：显卡型号 + **真实 CUDA 可用性**。

    只看 nvidia-smi 会给出假信息（有卡但 CUDA 装坏了也显示 ok）。
    必须实际问 ctranslate2 能不能拿到 CUDA 设备。
    """
    out = {"ok": False, "name": "", "cuda": False, "driver": "",
           "hint": "", "fix": "", "devices": 0}

    # ① 显卡型号
    try:
        r = proc.run(["nvidia-smi", "--query-gpu=name,driver_version",
                      "--format=csv,noheader"],
                     capture_output=True, text=True, timeout=10,
                     encoding="utf-8", errors="replace")
        if r.returncode == 0 and (r.stdout or "").strip():
            parts = (r.stdout or "").strip().split("\n")[0].split(",")
            out["ok"] = True
            out["name"] = parts[0].strip()[:60]
            out["driver"] = parts[1].strip() if len(parts) > 1 else ""
    except Exception:
        out["hint"] = "没检测到 NVIDIA GPU。faster-whisper 会降级用 CPU（慢 5-10 倍）"

    if not out["ok"]:
        out["hint"] = out["hint"] or "无 GPU，转录走 CPU"
        return out

    # ② 真实 CUDA 测试（关键）
    try:
        import ctranslate2
        n = int(ctranslate2.get_cuda_device_count())
        out["devices"] = n
        out["cuda"] = n > 0
        if not out["cuda"]:
            out["hint"] = ("有显卡但 CUDA 不可用 —— 转录会走 CPU，慢 5-10 倍。"
                           "点「修复」自动部署 CUDA 运行库")
            out["fix"] = "cuda"
        else:
            out["hint"] = ""
    except Exception as e:
        out["cuda"] = False
        out["hint"] = f"ctranslate2 CUDA 检测失败: {str(e)[:70]}"
        out["fix"] = "cuda"

    return out


def _script_version(p: Path) -> str:
    """读脚本头部版本标记。

    兼容三种写法（历史脚本格式不统一，宽松匹配避免误判成"版本旧"）：
        # VER: 20261108-cn
        VER: 20261108-cn
        #VER:20261108-cn

    注意：只放宽"标记格式"，不改变"版本值必须相等"的判定逻辑。
    """
    import re as _re
    pat = _re.compile(r"^\s*#?\s*VER\s*:\s*(\S+)\s*$")
    try:
        with open(p, encoding="utf-8", errors="ignore") as f:
            for _ in range(20):
                line = f.readline()
                if not line:
                    break
                m = pat.match(line)
                if m:
                    return m.group(1)
    except Exception:
        pass
    return ""


def check_tools() -> dict:
    """检查脚本齐全度 + **版本新旧**。"""
    from app.services import slicing as sl
    t = sl.tools_dir()

    need = list(TOOLS_VERSION.keys())
    have = {s: (t / s).exists() for s in need}
    missing = [k for k, v in have.items() if not v]

    # 版本比对：无 VER 标记也算旧
    stale, actual = [], {}
    for s, want in TOOLS_VERSION.items():
        p = t / s
        if not p.exists():
            continue
        got = _script_version(p)
        actual[s] = got or "(无版本标记)"
        if got != want:
            stale.append({"file": s, "have": got or "-", "want": want})

    ok = t.exists() and not missing
    hint = ""
    if missing:
        hint = (f"缺 {len(missing)} 个脚本（{', '.join(missing[:3])}…），"
                f"把 tools 目录放到 {t}，或点「更新」自动部署")
    elif stale:
        names = "、".join(x["file"] for x in stale[:3])
        more = "" if len(stale) <= 3 else f" 等 {len(stale)} 个"
        detail = "; ".join(
            f"{x['file']}: 现有 {x['have']} / 需要 {x['want']}" for x in stale[:3])
        hint = (f"{names}{more} 版本不匹配（{detail}），"
                f"点「更新」覆盖，或确认以上脚本确实无需更新")

    return {
        "dir": str(t), "exists": t.exists(),
        "scripts": have, "missing": missing,
        "stale": stale, "versions": actual,
        "ok": ok,
        "upToDate": ok and not stale,
        "hint": hint,
    }


def check_assets() -> dict:
    """字体 + BGM（PIL 渲染和混音用），目录走统一解析。"""
    fonts_dir = _paths.fonts_dir()
    audio_dir = _paths.audio_dir()
    fonts = sorted(f.name for f in fonts_dir.glob("*.ttf")) if fonts_dir.exists() else []
    bgm = sorted(f.name for f in audio_dir.glob("bgm_*.wav")) if audio_dir.exists() else []
    sfx = sorted(f.name for f in audio_dir.glob("sfx_*.wav")) if audio_dir.exists() else []
    return {
        "fontsDir": str(fonts_dir), "fonts": fonts, "fontCount": len(fonts),
        "audioDir": str(audio_dir), "bgm": bgm, "bgmCount": len(bgm),
        "sfxCount": len(sfx),
        "ok": len(fonts) > 0 and len(bgm) > 0,
        "hint": "" if (fonts and bgm) else
                f"字体放 {fonts_dir}（Montserrat），BGM 放 {audio_dir}（bgm_*.wav）。"
                "也可用 YUHAI_FONTS / YUHAI_AUDIO 指定别的目录",
    }


def check_proxy() -> dict:
    import httpx
    proxy = _paths.proxy()
    if not proxy:
        return {"proxy": "", "alive": False,
                "hint": "没检测到本地代理。抓取 PineDrama 需要代理"
                        "（tiktokcdn DNS 被污染）；设 PD_PROXY 环境变量或启动 Clash"}
    alive = False
    try:
        httpx.get(proxy, timeout=2)
        alive = True
    except Exception:
        alive = False
    return {"proxy": proxy, "alive": alive,
            "hint": "" if alive else f"检测到 {proxy} 但连不上，检查代理是否在运行"}


def check_curl() -> dict:
    p = _paths.curl()
    ver = ""
    if p:
        try:
            r = proc.run([str(p), "--version"], capture_output=True, text=True,
                               timeout=10, encoding="utf-8", errors="replace")
            ver = (r.stdout or "").split("\n")[0][:80]
        except Exception:
            pass
    return {"path": str(p) if p else "", "ok": bool(p), "version": ver,
            "hint": "" if p else "Windows 10+ 自带 curl；没有就装 curl 或把 curl.exe 放 PATH"}


# ---------------- 总检 ----------------
def full_check() -> dict:
    py = check_python()
    ff = check_ffmpeg()
    gpu = check_gpu()
    tools = check_tools()
    model = check_whisper_model()
    assets = check_assets()
    proxy = check_proxy()
    curl = check_curl()

    required_ok = (all(p["ok"] for p in py if p["required"])
                   and ff["ok"] and tools["ok"] and model["ok"])

    warnings = []
    if not model["ok"]:
        warnings.append(model.get("hint") or "ASR 模型缺失，转录不可用")
    if tools.get("stale"):
        warnings.append(f"{len(tools['stale'])} 个脚本版本旧，建议更新")
    if not gpu["ok"]:
        warnings.append("无 GPU，转录会慢（CPU 模式）")
    if gpu["ok"] and not gpu.get("cuda"):
        warnings.append("有显卡但 CUDA 不可用，转录走 CPU（慢 5-10 倍）")
    if not ff["nvenc"]:
        warnings.append("无 NVENC，编码用 CPU（慢但能用）")
    if not assets["ok"]:
        warnings.append("字体或 BGM 缺失，字幕/混音可能失败")
    if not proxy["alive"]:
        warnings.append("代理未启动，抓取功能不可用")
    if not curl["ok"]:
        warnings.append("curl 缺失，抓取功能不可用")

    # 汇总「可以一键修」的项
    fixable = []
    if not model["ok"]:
        fixable.append({"what": "whisper", "label": f"下载 {model['name']} 模型"})
    if tools.get("stale") or tools.get("missing"):
        fixable.append({"what": "tools", "label": "更新切片脚本"})
    if not ff["ok"]:
        fixable.append({"what": "ffmpeg", "label": "安装 FFmpeg"})
    if any(not p["ok"] for p in py):
        fixable.append({"what": "python", "label": "安装缺失的 Python 包"})
    if gpu["ok"] and not gpu.get("cuda"):
        fixable.append({"what": "cuda", "label": "部署 CUDA 运行库"})

    return {
        "ok": required_ok,
        "python": py,
        "ffmpeg": ff,
        "gpu": gpu,
        "tools": tools,
        "model": model,
        "assets": assets,
        "proxy": proxy,
        "curl": curl,
        "warnings": warnings,
        "fixable": fixable,
        "paths": _paths.snapshot(),
        "platform": {
            "os": sys.platform,
            "python": sys.version.split()[0],
            "frozen": bool(getattr(sys, "frozen", False)),
            "dataDir": str(settings.data_dir),
        },
    }


# ---------------- 自动安装 ----------------
def install_python(packages: list[str] | None = None) -> dict:
    """pip 安装缺失的包。"""
    py = check_python()
    missing = [p for p in py if not p["ok"]]
    if packages:
        missing = [p for p in missing if p["name"] in packages]
    if not missing:
        return {"ok": True, "note": "没有需要安装的包", "installed": []}

    results = []
    for p in missing:
        spec = p.get("pip") or p["name"]
        try:
            r = proc.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", spec],
                capture_output=True, text=True, timeout=600,
                encoding="utf-8", errors="replace")
            ok = r.returncode == 0
            results.append({"name": p["name"], "ok": ok,
                            "output": (r.stdout or r.stderr or "")[-300:]})
            log.info("pip install %s -> %s", spec, ok)
        except Exception as e:
            results.append({"name": p["name"], "ok": False, "error": str(e)[:200]})
    return {"ok": all(x["ok"] for x in results),
            "installed": [x["name"] for x in results if x["ok"]],
            "failed": [x for x in results if not x["ok"]],
            "results": results}


def _bin_dir() -> Path:
    """程序自带的 bin 目录（没有就建）。"""
    import sys as _sys
    if getattr(_sys, "frozen", False):
        base = Path(_sys.executable).resolve().parent
    else:
        base = Path(__file__).resolve().parent.parent.parent
    d = base / "bin"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _dl_ok(dst: Path, min_bytes: int = 32) -> bool:
    """下载成功判定。小文件（校验和、清单）不能按 1KB 卡。"""
    try:
        return dst.exists() and dst.stat().st_size >= min_bytes
    except OSError:
        return False


def _proxy_alive(px: str) -> bool:
    if not px:
        return False
    try:
        import socket
        from urllib.parse import urlparse
        u = urlparse(px)
        with socket.create_connection((u.hostname or "127.0.0.1",
                                       u.port or 7897), timeout=0.6):
            return True
    except Exception:
        return False


def _download(url: str, dst: Path, proxy: str = "", timeout: int = 300,
              min_bytes: int = 32, prefer_proxy: bool = True) -> dict:
    """下载文件，带断点续传。

    实测（本机）：直连 gyan.dev 约 20KB/s，走本地代理约 2MB/s，差 100 倍，
    所以**代理活着就优先走代理**。代理不通时回退直连，最后回退 urllib。

    Windows 上 curl 用 schannel，离线时证书吊销检查会直接失败
    （CRYPT_E_REVOCATION_OFFLINE），必须带 --ssl-no-revoke。
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    from app import paths as _p

    px = proxy or _p.proxy()
    px_ok = _proxy_alive(px)

    order: list[tuple[str, str]] = []
    if prefer_proxy and px_ok:
        order.append(("proxy", px))
    order.append(("direct", ""))
    if px_ok and not prefer_proxy:
        order.append(("proxy", px))

    errs: list[str] = []
    cb = _p.curl()
    if cb:
        for mode, use_px in order:
            # 两次：第一次正常下，失败且已下了一部分就续传
            for attempt in (1, 2):
                have = dst.stat().st_size if dst.exists() else 0
                args = [str(cb), "-sS", "-L", "--ssl-no-revoke",
                        "--max-time", str(timeout), "-o", str(dst)]
                if attempt == 2 and have > min_bytes:
                    args.insert(1, "-C")
                    args.insert(2, "-")
                if use_px:
                    args += ["-x", use_px]
                args.append(url)
                try:
                    r = proc.run(args, capture_output=True, timeout=timeout + 30)
                    if r.returncode == 0 and _dl_ok(dst, min_bytes):
                        return {"ok": True, "via": f"curl-{mode}",
                                "size": dst.stat().st_size, "resumed": attempt == 2}
                    errs.append(f"curl-{mode}#{attempt}: "
                                f"{(r.stderr or b'').decode('utf-8', 'replace')[:110]}")
                except Exception as e:
                    errs.append(f"curl-{mode}#{attempt}: {str(e)[:110]}")
    else:
        errs.append("curl: 未找到")

    # urllib 回退（读 HTTP_PROXY/HTTPS_PROXY；也手动套代理）
    for use_px in ([px] if px_ok else []) + [""]:
        try:
            import urllib.request
            if use_px:
                op = urllib.request.build_opener(
                    urllib.request.ProxyHandler({"http": use_px, "https": use_px}))
            else:
                op = urllib.request.build_opener()
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with op.open(req, timeout=timeout) as resp:
                dst.write_bytes(resp.read())
            if _dl_ok(dst, min_bytes):
                return {"ok": True, "via": "urllib" + ("-proxy" if use_px else ""),
                        "size": dst.stat().st_size}
        except Exception as e:
            errs.append(f"urllib{'-proxy' if use_px else ''}: {str(e)[:130]}")
    return {"ok": False, "error": " | ".join(errs[-4:])}


def install_ffmpeg_portable(proxy: str = "") -> dict:
    """**不依赖任何包管理器**：直接下载便携版 ffmpeg 解压到 bin\\。

    依次尝试多个镜像源；Windows 用 gyan.dev，Linux/macOS 提示用系统包管理器。
    """
    import platform as _pf
    import tempfile
    import zipfile

    if _pf.system() != "Windows":
        return {
            "ok": False, "via": "unsupported",
            "manual": [
                "Ubuntu/Debian: sudo apt install -y ffmpeg",
                "macOS: brew install ffmpeg",
                "CentOS/RHEL: sudo yum install -y ffmpeg",
            ],
        }

    bin_dir = _bin_dir()
    targets = ("ffmpeg.exe", "ffprobe.exe")
    if all((bin_dir / t).exists() for t in targets):
        return {"ok": True, "via": "already", "dir": str(bin_dir)}

    sources = [
        ("https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip", "gyan"),
        ("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"
         "ffmpeg-master-latest-win64-gpl.zip", "BtbN"),
        ("https://github.com/GyanD/codexffmpeg/releases/download/7.1/"
         "ffmpeg-7.1-essentials_build.zip", "gyan-github"),
    ]

    attempts = []
    for url, tag in sources:
        with tempfile.TemporaryDirectory() as td:
            zp = Path(td) / "ff.zip"
            dl = _download(url, zp, proxy=proxy, timeout=600)
            attempts.append({"source": tag, "url": url, **dl})
            if not dl.get("ok"):
                continue
            try:
                with zipfile.ZipFile(zp) as z:
                    names = z.namelist()
                    got = 0
                    for t in targets:
                        hit = next((n for n in names
                                    if n.replace("\\", "/").endswith("/bin/" + t)), None)
                        if not hit:
                            continue
                        with z.open(hit) as src, open(bin_dir / t, "wb") as out:
                            out.write(src.read())
                        got += 1
                    if got == len(targets):
                        # 验证能跑
                        r = proc.run([str(bin_dir / "ffmpeg.exe"), "-version"],
                                           capture_output=True, text=True, timeout=30,
                                           encoding="utf-8", errors="replace")
                        if r.returncode == 0:
                            return {"ok": True, "via": tag, "dir": str(bin_dir),
                                    "version": (r.stdout or "").split("\n")[0][:90],
                                    "attempts": attempts}
                        attempts.append({"source": tag, "ok": False,
                                         "error": "解压后跑不起来"})
                    else:
                        attempts.append({"source": tag, "ok": False,
                                         "error": f"zip 里只找到 {got}/2 个可执行"})
            except Exception as e:
                attempts.append({"source": tag, "ok": False,
                                 "error": f"解压失败 {str(e)[:150]}"})

    return {
        "ok": False, "attempts": attempts,
        "manual": [
            "① 浏览器打开 https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
            f"② 解压后把 bin\\ffmpeg.exe 和 bin\\ffprobe.exe 复制到 {bin_dir}",
            "③ 重启程序，环境自检会变绿",
        ],
        "binDir": str(bin_dir),
    }


def install_tools(source: str = "") -> dict:
    """部署/更新切片脚本。

    来源优先级：
      ① 调用方指定的 source
      ② 包内 `_internal/tools`（打包时随包分发的最新版）
      ③ 工作区 `<workspace>/tools`
      ④ 环境变量 YUHAI_TOOLS_SOURCE

    目标：paths.tools_dir()
    只复制清单里的脚本，不动 _state 等数据。
    """
    import shutil as _sh
    from app import paths as _p

    dst = _p.tools_dir()
    dst.mkdir(parents=True, exist_ok=True)

    srcs: list[Path] = []
    if source:
        srcs.append(Path(source))
    env_src = os.environ.get("YUHAI_TOOLS_SOURCE", "")
    if env_src:
        srcs.append(Path(env_src))
    srcs += [
        _p._exe_dir() / "_internal" / "tools",
        _p._exe_dir() / "tools",
        _p.WORKSPACE / "tools",
    ]

    # 找一个「含清单脚本且版本更新」的源
    best: Path | None = None
    for s in srcs:
        if not s.exists() or s.resolve() == dst.resolve():
            continue
        if not (s / "pipeline2.py").exists():
            continue
        best = s
        break

    if not best:
        # 没有源可复制 → 只能给指引
        miss = [k for k in TOOLS_VERSION if not (dst / k).exists()]
        if not miss:
            return {"ok": True, "dir": str(dst), "note": "脚本齐全，无需更新"}
        return {
            "ok": False, "dir": str(dst),
            "manual": [
                f"把 tools 目录（含 pipeline2.py 等脚本）放到 {dst}",
                "或设环境变量 YUHAI_TOOLS 指向脚本实际位置",
                "或在「设置 → 路径 → 切片/抓取脚本目录」里改",
            ],
        }

    # 复制清单里的脚本
    copied, skipped = [], []
    for name in TOOLS_VERSION.keys():
        sp = best / name
        if not sp.exists():
            skipped.append(name)
            continue
        dp = dst / name
        # 已经是同版本就跳过
        if dp.exists() and _script_version(dp) == _script_version(sp):
            skipped.append(name)
            continue
        try:
            _sh.copy2(sp, dp)
            copied.append(name)
        except Exception as e:
            skipped.append(f"{name}({str(e)[:30]})")

    # 额外需要的辅助脚本（不在版本清单里但少了会跑不起来）
    EXTRA = ("paths.py", "pd_drama.py")
    for name in EXTRA:
        sp = best / name
        dp = dst / name
        if sp.exists() and not dp.exists():
            try:
                _sh.copy2(sp, dp)
                copied.append(name)
            except Exception:
                pass

    return {
        "ok": True, "dir": str(dst), "from": str(best),
        "copied": copied, "skipped": skipped,
        "note": f"更新 {len(copied)} 个脚本（源: {best.name}）"
                if copied else "脚本已是最新，无需更新",
    }


def install_ffmpeg() -> dict:
    """装 ffmpeg：包管理器 → 便携包直下 → 手动指引（三级兜底）。"""
    attempts: list[dict] = []

    # ① 包管理器
    for tool, cmd in (
        ("winget", ["winget", "install", "--id", "Gyan.FFmpeg",
                    "--accept-package-agreements", "--accept-source-agreements",
                    "--silent"]),
        ("choco", ["choco", "install", "ffmpeg", "-y"]),
        ("scoop", ["scoop", "install", "ffmpeg"]),
        ("brew", ["brew", "install", "ffmpeg"]),
        ("apt", ["apt-get", "install", "-y", "ffmpeg"]),
    ):
        if not shutil.which(tool):
            continue
        try:
            r = proc.run(cmd, capture_output=True, text=True, timeout=900,
                               encoding="utf-8", errors="replace")
            attempts.append({"tool": tool, "ok": r.returncode == 0,
                             "output": (r.stdout or r.stderr or "")[-400:]})
            if r.returncode == 0:
                # 装完复查一次
                if check_ffmpeg()["ok"]:
                    return {"ok": True, "via": tool, "attempts": attempts,
                            "note": "已通过包管理器安装"}
        except Exception as e:
            attempts.append({"tool": tool, "ok": False, "error": str(e)[:200]})

    # ② 便携包直下（不依赖任何包管理器）
    port = install_ffmpeg_portable()
    if port.get("ok"):
        return {**port, "attempts": attempts + (port.get("attempts") or []),
                "note": "已下载便携版到 bin\\，无需包管理器"}

    # ③ 手动
    return {
        "ok": False,
        "attempts": attempts + (port.get("attempts") or []),
        "manual": port.get("manual") or [
            "下载 https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
            f"解压后把 ffmpeg.exe / ffprobe.exe 放到 {_bin_dir()}",
        ],
        "binDir": str(_bin_dir()),
    }


def install_cuda() -> dict:
    """部署 CUDA 运行库（让 ctranslate2 能用 GPU）。

    不装完整 CUDA Toolkit（几个 GB 且要管理员权限），
    只补 ctranslate2 需要的运行时 DLL：
      cuBLAS（cublas64_*.dll / cublasLt64_*.dll）
      cuDNN（cudnn_ops_infer64_*.dll 等）

    下载源：NVIDIA pip 包（nvidia-cublas-cu12 / nvidia-cudnn-cu12），
    解压出 DLL 放到 _internal 下的 cuda 目录，并加进 DLL 搜索路径。
    """
    attempts: list[dict] = []

    # 先复查：可能已经能用
    g = check_gpu()
    if g.get("cuda"):
        return {"ok": True, "via": "already", "note": "CUDA 已可用"}

    # 方案①：pip 装 nvidia 运行时（最省事，不需要管理员）
    for mod, pkg in (("cublas", "nvidia-cublas-cu12"),
                     ("cudnn", "nvidia-cudnn-cu12")):
        try:
            r = proc.run([sys.executable, "-m", "pip", "install",
                          "--target", str(_cuda_dir()), pkg],
                         capture_output=True, text=True, timeout=1800,
                         encoding="utf-8", errors="replace")
            attempts.append({"pkg": pkg, "ok": r.returncode == 0,
                             "out": (r.stdout or r.stderr or "")[-200:]})
        except Exception as e:
            attempts.append({"pkg": pkg, "ok": False, "error": str(e)[:150]})

    if _cuda_dir().exists():
        _add_cuda_to_path()

    g2 = check_gpu()
    if g2.get("cuda"):
        return {"ok": True, "via": "pip-runtime", "attempts": attempts,
                "dir": str(_cuda_dir()), "note": "CUDA 运行时已部署"}

    return {
        "ok": False, "attempts": attempts,
        "manual": [
            "① 装 CUDA Toolkit 11.8 或 12.x：https://developer.nvidia.com/cuda-downloads",
            "② 或 pip install nvidia-cublas-cu12 nvidia-cudnn-cu12",
            "③ 也不会弄就忽略：转录自动降级 CPU，能跑但慢 5-10 倍",
        ],
        "hint": g2.get("hint") or "CUDA 仍不可用",
    }


def _cuda_dir() -> Path:
    from app import paths as _p
    return _p._exe_dir() / "_internal" / "cuda"


def _add_cuda_to_path() -> None:
    """把 cuda 目录下的 bin 加进 DLL 搜索路径（本进程生效）。"""
    d = _cuda_dir()
    if not d.exists():
        return
    bins = [d] + [p for p in d.rglob("bin") if p.is_dir()] + \
           [p for p in d.rglob("lib") if p.is_dir()]
    cur = os.environ.get("PATH", "")
    add = ";".join(str(b) for b in bins if str(b) not in cur)
    if add:
        os.environ["PATH"] = add + ";" + cur
    if hasattr(os, "add_dll_directory"):
        for b in bins:
            try:
                os.add_dll_directory(str(b))
            except Exception:
                pass


def install_one(what: str) -> dict:
    """按单项安装，供 /env/install?what=xxx 调用。"""
    what = (what or "all").lower()
    if what == "python":
        return install_python()
    if what == "ffmpeg":
        return install_ffmpeg()
    if what == "whisper":
        return install_whisper_model()
    if what in ("whisper-medium", "medium"):
        return install_whisper_model("medium")
    if what == "whisper-tiny":
        return install_whisper_model("tiny")
    if what == "tools":
        return install_tools()
    if what == "cuda":
        return install_cuda()
    return install_all()


def install_all() -> dict:
    """一键：Python 包 → FFmpeg → ASR 模型 → 切片脚本，逐步返回。"""
    steps = []

    py = install_python()
    steps.append({
        "what": "Python 包",
        "ok": py.get("ok", False),
        "detail": ("无需安装" if not py.get("installed") and not py.get("failed")
                   else f"装上 {len(py.get('installed') or [])} 个"
                        + (f"，失败 {len(py.get('failed') or [])} 个"
                           if py.get("failed") else "")),
        "log": [f"{r['name']}: {'OK' if r['ok'] else (r.get('error') or '失败')}"
                for r in (py.get("results") or [])],
    })

    ff = {"ok": True, "note": "已可用"}
    if not check_ffmpeg()["ok"]:
        ff = install_ffmpeg()
    steps.append({
        "what": "FFmpeg",
        "ok": ff.get("ok", False),
        "detail": ff.get("note") or ff.get("via") or "失败",
        "log": [f"{a.get('tool') or a.get('source')}: "
                f"{'OK' if a.get('ok') else (a.get('error') or '失败')}"
                for a in (ff.get("attempts") or [])][-8:],
    })

    # ASR 模型（新）
    m = check_whisper_model()
    if m["ok"]:
        steps.append({"what": "ASR 模型", "ok": True,
                      "detail": f"{m['name']} 已就位（{m.get('sizeMb') or 0}MB）",
                      "log": [f"位置: {m['path']}"]})
    else:
        mi = install_whisper_model(m.get("name") or "small")
        steps.append({
            "what": "ASR 模型",
            "ok": mi.get("ok", False),
            "detail": mi.get("note") or mi.get("error") or "失败",
            "log": [f"{a.get('file')}: "
                    f"{'OK' if a.get('ok') else (a.get('error') or '失败')}"
                    for a in (mi.get("attempts") or [])][-8:]
                    or (mi.get("manual") or []),
        })

    # 脚本更新（新：会真的复制最新版）
    tl = install_tools()
    steps.append({
        "what": "切片脚本",
        "ok": tl.get("ok", False),
        "detail": tl.get("note") or f"缺脚本，见 {tl.get('dir')}",
        "log": (tl.get("copied") or []) or (tl.get("manual") or []),
    })

    manual = []
    for s in steps:
        if not s["ok"]:
            manual += [x for x in (s.get("log") or []) if isinstance(x, str)]

    return {
        "ok": all(s["ok"] for s in steps),
        "steps": steps,
        "manual": manual,
        "after": full_check(),
    }
