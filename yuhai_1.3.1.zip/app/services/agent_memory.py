# -*- coding: utf-8 -*-
"""
agent_memory.py — Agent 跨会话记忆

MCP 规范要求状态不能挂在连接上，要用显式 handle。
这里用 SQLite 表存 key-value，MCP 工具和 REST API 共用。

用途：
  · agent 记住「当前在切哪部剧」
  · 记住「用户偏好：不要剩余片段」
  · 记住「上次做到哪一步」
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path

log = logging.getLogger("yuhai.agent.memory")


def _db():
    from app.db import db
    return db


def _init() -> None:
    d = _db()
    try:
        d.exec("""CREATE TABLE IF NOT EXISTS agent_memory (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at INTEGER NOT NULL
        )""")
    except Exception as e:
        log.warning("agent_memory init failed: %s", e)


def set(key: str, value: str) -> dict:
    _init()
    d = _db()
    now = int(time.time() * 1000)
    d.exec("""INSERT INTO agent_memory (key, value, updated_at)
              VALUES (?, ?, ?)
              ON CONFLICT(key) DO UPDATE SET value=?, updated_at=?""",
           (key, value, now, value, now))
    return {"ok": True, "key": key, "updatedAt": now}


def get(key: str) -> dict:
    _init()
    d = _db()
    r = d.q1("SELECT key, value, updated_at FROM agent_memory WHERE key=?",
             (key,))
    if not r:
        return {"ok": False, "key": key, "error": "没有这个键"}
    return {"ok": True, "key": r["key"], "value": r["value"],
            "updatedAt": r["updated_at"]}


def delete(key: str) -> dict:
    _init()
    d = _db()
    d.exec("DELETE FROM agent_memory WHERE key=?", (key,))
    return {"ok": True, "key": key}


def list_all() -> dict:
    _init()
    d = _db()
    rows = d.q("""SELECT key, value, updated_at FROM agent_memory
                  ORDER BY updated_at DESC LIMIT 100""")
    return {"items": [{"key": r["key"], "value": r["value"],
                       "updatedAt": r["updated_at"]} for r in rows],
            "count": len(rows)}
