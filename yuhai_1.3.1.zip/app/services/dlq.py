"""短剧下载 · 任务队列（后台线程池 + 进度）

与工作台 jobs 表解耦，纯内存队列：重启即清空，符合「抓完就走」的使用方式。
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import logging
import threading
import time
import traceback
from pathlib import Path

from app.services import dl

log = logging.getLogger("yuhai.services.dlq")

TASKS: list[dict] = []
LOCK = threading.Lock()
TID = [0]
POOL = cf.ThreadPoolExecutor(max_workers=6)
EP_WORKERS = 6


def new_task(site: str, slug: str, name: str, cover: str,
             eps: list[int], lang: str = "en") -> dict:
    with LOCK:
        TID[0] += 1
        t = {
            "id": TID[0], "site": site, "slug": slug, "name": name,
            "cover": cover, "lang": lang, "created": time.time(),
            "done": False,
            "eps": [{"ep": e, "state": "wait", "msg": "", "bytes": 0, "total": 0}
                    for e in eps],
        }
        TASKS.insert(0, t)
        if len(TASKS) > 80:
            for old in TASKS[80:]:
                if old["done"]:
                    TASKS.remove(old)
        return t


def find(tid: int):
    with LOCK:
        for t in TASKS:
            if t["id"] == tid:
                return t
    return None


def snapshot() -> list[dict]:
    with LOCK:
        out = []
        for t in TASKS[:40]:
            done_n = sum(1 for e in t["eps"] if e["state"] in ("ok", "skip", "locked", "fail"))
            ok_n = sum(1 for e in t["eps"] if e["state"] in ("ok", "skip"))
            out.append({
                "id": t["id"], "site": t["site"], "slug": t["slug"],
                "name": t["name"], "cover": t["cover"], "done": t["done"],
                "total": len(t["eps"]), "finished": done_n, "ok": ok_n,
                "bytes": sum(e.get("bytes", 0) for e in t["eps"]),
                "running": sum(1 for e in t["eps"] if e["state"] == "run"),
                "eps": [dict(e) for e in t["eps"]],
            })
    return out


def cancel(tid: int) -> bool:
    t = find(tid)
    if not t:
        return False
    with LOCK:
        for e in t["eps"]:
            if e["state"] in ("wait", "run"):
                e["state"] = "fail"
                e["msg"] = "已取消"
        t["done"] = True
    return True


def remove(tid: int) -> bool:
    with LOCK:
        for t in list(TASKS):
            if t["id"] == tid:
                TASKS.remove(t)
                return True
    return False


def resolve_url(site: str, slug: str, ep: int, lang: str, meta: dict, ep_meta: dict | None):
    """取单集直链"""
    if site == "pinedrama":
        return dl.pine_play_url(slug, ep, lang)

    # TK短剧：优先用已有 playAddr，签名过期时重新抓
    if site == "tiktok_drama":
        if ep_meta and ep_meta.get("url"):
            return ep_meta["url"], "ok"
        # 没有就重新抓一遍（会触发浏览器）
        try:
            fresh = dl.sd_drama(slug, force=True)
            meta.clear()
            meta.update(fresh)
            for e in (fresh.get("eps") or []):
                if e.get("ep") == ep and e.get("url"):
                    return e["url"], "ok"
        except Exception as e:
            return None, f"重新获取失败：{str(e)[:60]}"
        return None, "这一集没有可用地址"

    if ep_meta and ep_meta.get("url"):
        return ep_meta["url"], "ok"
    for e in (meta.get("eps") or []):
        if e.get("ep") == ep and e.get("url"):
            return e["url"], "ok"
    return None, "该集无可用地址（付费或未下发）"


def _get_meta(site: str, slug: str) -> dict:
    """按站点取元数据（tiktok_drama 走 sd_drama，其它走 fetch_meta）"""
    if site == "tiktok_drama":
        return dl.sd_drama(slug)
    return dl.fetch_meta(site, slug)


def run_tiktok_task(tid: int) -> None:
    """TikTok 走 yt-dlp"""
    t = find(tid)
    if not t:
        return
    folder = dl.tk_dir()
    folder.mkdir(parents=True, exist_ok=True)
    item = t["eps"][0]
    with LOCK:
        item["state"] = "run"
        item["msg"] = "解析中"

    url = t.get("web_url") or t["slug"]
    cmd = [dl.ytdlp_bin(), "--no-warnings", "--no-overwrites",
           "-P", str(folder),
           "-o", "%(uploader_id,uploader)s/%(id)s_%(title).70B.%(ext)s",
           "--restrict-filenames", "--retries", "3",
           "-f", "bv*+ba/b", "--merge-output-format", "mp4",
           "--write-info-json", "--"]
    try:
        px = dl.sess().proxies.get("http", "") if dl.sess().proxies else ""
        if px:
            cmd += ["--proxy", px]
    except Exception:
        pass
    cmd.append(url)

    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=600,
                           encoding="utf-8", errors="replace",
                           creationflags=(0x08000000 if __import__("os").name == "nt" else 0))
        if p.returncode == 0:
            files = sorted(folder.rglob("*.mp4"), key=lambda x: x.stat().st_mtime)
            sz = files[-1].stat().st_size if files else 0
            with LOCK:
                item["state"] = "ok"
                item["bytes"] = sz
                item["msg"] = f"{sz/1048576:.1f}MB"
        else:
            err = (p.stderr or "").strip().splitlines()
            with LOCK:
                item["state"] = "fail"
                item["msg"] = (err[-1][:90] if err else f"exit {p.returncode}")
    except Exception as e:
        with LOCK:
            item["state"] = "fail"
            item["msg"] = repr(e)[:80]
    finally:
        with LOCK:
            t["done"] = True


def run_task(tid: int) -> None:
    t = find(tid)
    if not t:
        return
    site, slug, lang = t["site"], t["slug"], t["lang"]
    folder = dl.drama_dir(site, t["name"])
    folder.mkdir(parents=True, exist_ok=True)

    try:
        meta = _get_meta(site, slug)
    except Exception as e:
        log.warning("meta failed %s/%s: %s", site, slug, e)
        meta = {"eps": [], "name": t["name"]}
    ep_map = {e["ep"]: e for e in (meta.get("eps") or [])}
    referer = dl.SITE_REFERER.get(site, dl.PINE + "/")

    def one(item):
        ep = item["ep"]
        dest = folder / f"{dl.safe(t['name'])}-{ep:02d}.mp4"
        with LOCK:
            item["state"] = "run"
            item["msg"] = "取直链"
        if dest.exists() and dest.stat().st_size > 4096:
            with LOCK:
                item["state"] = "skip"
                item["msg"] = "已存在"
                item["bytes"] = dest.stat().st_size
                item["total"] = dest.stat().st_size
            return

        url, why = resolve_url(site, slug, ep, lang, meta, ep_map.get(ep))
        if not url:
            with LOCK:
                item["state"] = "locked"
                item["msg"] = why
            return

        def prog(got, total):
            with LOCK:
                item["bytes"] = got
                item["total"] = total
                item["msg"] = (f"{got/1048576:.1f}/{total/1048576:.1f}MB"
                               if total else f"{got/1048576:.1f}MB")

        last = ""
        for attempt in range(3):
            try:
                got = dl.download(url, dest, referer=referer, on_progress=prog)
                with LOCK:
                    item["state"] = "ok"
                    item["bytes"] = got
                    item["msg"] = f"{got/1048576:.1f}MB"
                return
            except PermissionError as e:
                last = str(e)[:60]
                with LOCK:
                    item["msg"] = "刷新签名"
                url, why = resolve_url(site, slug, ep, lang, meta, ep_map.get(ep))
                if not url:
                    with LOCK:
                        item["state"] = "locked"
                        item["msg"] = why
                    return
                time.sleep(0.8)
            except Exception as e:
                last = repr(e)[:70]
                time.sleep(1.2 * (attempt + 1))
        with LOCK:
            item["state"] = "fail"
            item["msg"] = last

    try:
        with cf.ThreadPoolExecutor(max_workers=EP_WORKERS) as ex:
            list(ex.map(one, t["eps"]))
    except Exception:
        log.error("task %s crashed\n%s", tid, traceback.format_exc())
    finally:
        with LOCK:
            t["done"] = True
        try:
            (folder / "_meta.json").write_text(
                json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass


def run_sd_task(tid: int) -> None:
    """TK短剧：逐集走独立脚本（页面内 fetch 才不被 403）"""
    t = find(tid)
    if not t:
        return
    site, did = t["site"], t["slug"]
    folder = dl.drama_dir(site, t["name"])
    folder.mkdir(parents=True, exist_ok=True)

    import subprocess as sp
    import sys as _sys
    script = Path(__file__).resolve().parent.parent / "tk_ep_download.py"

    for item in t["eps"]:
        ep = item["ep"]
        dest = folder / f"{dl.safe(t['name'])}-{ep:02d}.mp4"
        with LOCK:
            item["state"] = "run"
            item["msg"] = "取流"

        if dest.exists() and dest.stat().st_size > 4096:
            with LOCK:
                item["state"] = "skip"
                item["msg"] = "已存在"
                item["bytes"] = dest.stat().st_size
                item["total"] = dest.stat().st_size
            continue

        ok = False
        last = ""
        for attempt in range(2):
            try:
                pr = sp.run(
                    [_sys.executable, str(script), str(did), str(ep), str(dest)],
                    capture_output=True, text=True, timeout=300,
                    encoding="utf-8", errors="replace",
                    creationflags=(0x08000000 if __import__("os").name == "nt" else 0))
                raw = (pr.stdout or "").strip()
                j = json.loads(raw.splitlines()[-1]) if raw else {}
                if j.get("ok"):
                    sz = int(j.get("bytes") or 0)
                    with LOCK:
                        item["state"] = "ok"
                        item["bytes"] = sz
                        item["total"] = j.get("total") or sz
                        item["msg"] = f"{sz/1048576:.1f}MB"
                    ok = True
                    break
                last = str(j.get("err") or "")[:70]
            except Exception as e:
                last = repr(e)[:70]
            if attempt == 0:
                time.sleep(4)

        if not ok:
            with LOCK:
                item["state"] = "fail"
                item["msg"] = last or "失败"
        # 集与集之间歇一下，降低风控
        time.sleep(3)

    # 写 _meta.json，让片库能准确识别站点和 slug
    try:
        mf = folder / "_meta.json"
        if not mf.exists():
            mf.write_text(json.dumps({
                "slug": did, "site": site, "name": t["name"],
            }, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass

    with LOCK:
        t["done"] = True


def submit(task: dict) -> None:
    if task.get("site") == "tiktok":
        POOL.submit(run_tiktok_task, task["id"])
    elif task.get("site") == "tiktok_drama":
        POOL.submit(run_sd_task, task["id"])
    else:
        POOL.submit(run_task, task["id"])
