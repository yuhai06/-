"""单条视频数据采集（推广矩阵形态）。

数据粒度：单条视频（unit），不绑定剧名。

采集方式与优先级
----------------
① Graph API（首选，零 UI 交互）
   GET /{page-id}/videos?fields=id,title,created_time,views,...
   天然不触发风控，但需要 token + pages_read_engagement。

② Business Suite 内容库表格（主力兜底，实测已跑通）
   business.facebook.com/latest/posts/published_posts?asset_id=…
   这是一张 17 列的表格，**一次滚动就能拿全每条视频的全部指标**——
   不用点进每条帖子，交互量最小，是风控角度最优的 CDP 路径。

③ 帖子详情页（最慢，仅补缺失字段）

节流与防检测
------------
    · 每次操作前过 Pacer（账号级节流，含长休息）
    · 页面加载后先 READ_DELAY 再动
    · 滚动走惯性分段，不是整数步长
    · 每步操作后过 guard，命中跳脸立即熔断并告警
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re
from datetime import date, datetime, timedelta
from typing import Any

from app.adapters import guard as gd
from app.adapters import humanize as hz
from app.db import db, now_iso

log = logging.getLogger("yuhai.metrics")


# ---------------- 数字 / 时长解析 ----------------
def parse_count(s: str | None) -> int:
    """解析 '1.2万' / '3,456' / '1.1M' / '12K' / '‑‑'。"""
    if not s:
        return 0
    t = str(s).strip().replace(",", "").replace(" ", "").replace("\u200b", "")
    if t in ("‑‑", "--", "-", "—", ""):
        return 0
    mul = 1.0
    if "亿" in t:
        mul = 1e8
    elif "万" in t or "萬" in t:
        mul = 1e4
    elif "千" in t:
        mul = 1e3
    elif re.search(r"[Mm]$", t):
        mul = 1e6
    elif re.search(r"[Kk]$", t):
        mul = 1e3
    m = re.search(r"([\d.]+)", t)
    if not m:
        return 0
    try:
        return int(float(m.group(1)) * mul)
    except Exception:
        return 0


def parse_duration(s: str | None) -> float:
    """解析 '1,812' / '2秒' / '1:23' / '‑‑' → 秒。"""
    if not s:
        return 0.0
    t = str(s).strip().replace("\u200b", "")
    if t in ("‑‑", "--", "-", "—", ""):
        return 0.0
    m = re.match(r"^(\d+):(\d{2})(?::(\d{2}))?$", t)
    if m:
        parts = [int(x) for x in m.groups() if x is not None]
        secs = 0
        for p in parts:
            secs = secs * 60 + p
        return float(secs)
    return float(parse_count(t))


# 中文日期：「11月5日 03:40」「2026年11月5日 03:40」「11-05 03:40」「昨天 03:40」
_CN_DATE = re.compile(r"(?:(\d{4})年)?(\d{1,2})月(\d{1,2})日(?:\s*(\d{1,2}):(\d{2}))?")
_ISO_DATE = re.compile(r"(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})")
_MD_DATE = re.compile(r"^(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{2})$")
_REL_DATE = re.compile(r"^(今天|昨天|前天)\s*(\d{1,2}):(\d{2})$")


def parse_post_date(s: str, now: datetime | None = None) -> tuple[str, str]:
    """把页面上的本地化发布时间解析成 (ISO 日期, 原始文本)。

    返回 ISO 形如 '2026-11-05'；解析不了返回 ('', 原文)。
    跨年处理：若解析出的月份大于当前月份，视为去年。
    """
    if not s:
        return "", ""
    raw = s.strip().replace("\u200b", "")
    now = now or datetime.now()

    m = _ISO_DATE.search(raw)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}", raw

    m = _REL_DATE.search(raw)
    if m:
        word, hh, mm = m.group(1), int(m.group(2)), int(m.group(3))
        delta = {"今天": 0, "昨天": 1, "前天": 2}[word]
        dt = now - timedelta(days=delta)
        return dt.strftime("%Y-%m-%d"), raw

    m = _CN_DATE.search(raw)
    if m:
        y = int(m.group(1)) if m.group(1) else now.year
        mo, d = int(m.group(2)), int(m.group(3))
        if not m.group(1) and mo > now.month + 1:
            y -= 1
        try:
            return f"{y:04d}-{mo:02d}-{d:02d}", raw
        except Exception:
            return "", raw

    m = _MD_DATE.search(raw)
    if m:
        mo, d = int(m.group(1)), int(m.group(2))
        y = now.year
        if mo > now.month + 1:
            y -= 1
        return f"{y:04d}-{mo:02d}-{d:02d}", raw

    return "", raw


# ---------------- ① Graph API ----------------
async def collect_via_graph(page_id: str, token: str, limit: int = 50,
                            since_days: int = 30) -> list[dict]:
    import httpx
    since = (datetime.now() - timedelta(days=since_days)).strftime("%Y-%m-%d")
    fields = ("id,title,description,created_time,length,permalink_url,"
              "views,reactions.summary(true),comments.summary(true),shares")
    url = f"https://graph.facebook.com/v21.0/{page_id}/videos"
    params: dict[str, Any] = {"fields": fields, "limit": limit, "access_token": token}
    out: list[dict] = []
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            while url and len(out) < limit:
                r = await c.get(url, params=params)
                if r.status_code != 200:
                    log.debug("graph %s -> %s %s", page_id, r.status_code, r.text[:120])
                    break
                d = r.json()
                for v in d.get("data") or []:
                    created = (v.get("created_time") or "")[:10]
                    if created and created < since:
                        continue
                    out.append({
                        "post_id": v.get("id") or "",
                        "title": v.get("title") or v.get("description") or "",
                        "published_at": v.get("created_time") or "",
                        "plays": parse_count(v.get("views")),
                        "reach": 0,
                        "reactions": ((v.get("reactions") or {}).get("summary") or {}).get("total_count", 0),
                        "comments": ((v.get("comments") or {}).get("summary") or {}).get("total_count", 0),
                        "shares": ((v.get("shares") or {}) or {}).get("count", 0),
                        "source": "graph",
                    })
                url = (d.get("paging") or {}).get("next")
                params = {}
    except Exception as e:
        log.debug("graph collect failed: %s", e)
    return out


# ---------------- ② 内容库表格 ----------------
# 实测表头（17 列）：
# 标题 / 发布日期 / 状态 / 覆盖人数 / 浏览量 / 浏览人数 / 关注数 / 互动次数 /
# 获赞数和心情数 / 评论数 / 分享次数 / 收藏次数 / 链接点击量 / 观看时长 /
# 视频平均播放时长 / 观看达 3 秒的次数 / 视频插播广告大概收入
TABLE_JS = r"""
(() => {
  const out = {headers: [], headerIdx: [], rows: [], tableCount: 0, colIndexed: false};
  const tables = Array.from(document.querySelectorAll('table, [role="grid"], [role="table"]'));
  out.tableCount = tables.length;
  if (!tables.length) return out;
  const t = tables[0];

  const txt = (el) => (el.innerText || '').replace(/\s+/g, ' ').trim();
  const ci = (el) => {
    const v = el.getAttribute('aria-colindex');
    return v === null ? null : parseInt(v, 10);
  };

  // 表头：带 aria-colindex 的按索引对齐
  const hs = Array.from(t.querySelectorAll('[role="columnheader"], thead th'));
  const hPairs = [];
  for (const h of hs) {
    const s = txt(h);
    if (!s) continue;
    hPairs.push({ text: s, idx: ci(h) });
  }
  out.headers = hPairs.map(p => p.text);
  out.headerIdx = hPairs.map(p => p.idx);
  out.colIndexed = hPairs.length > 0 && hPairs.every(p => p.idx !== null);

  const rows = Array.from(t.querySelectorAll('[role="row"], tbody tr'));
  for (const r of rows) {
    const cells = Array.from(r.querySelectorAll('[role="gridcell"], [role="cell"], td'));
    if (cells.length < 3) continue;
    const pairs = cells.map(c => ({ idx: ci(c), text: txt(c) }));
    let pid = null;
    for (const a of r.querySelectorAll('a[href]')) {
      const hh = a.getAttribute('href') || '';
      const m = hh.match(/\/posts\/(?:pfbid)?([A-Za-z0-9]{12,})/) ||
                hh.match(/story_fbid=(\d{12,})/) ||
                hh.match(/\/videos\/(\d{12,})/) ||
                hh.match(/\/reel\/(\d{12,})/);
      if (m) { pid = m[1]; break; }
    }
    out.rows.push({cells: pairs, pid: pid});
    if (out.rows.length >= 40) break;
  }
  return out;
})()
"""


def _col(headers: list[str], *names: str) -> int:
    for i, h in enumerate(headers):
        hh = h.replace("\u200b", "").strip()
        for n in names:
            if n in hh:
                return i
    return -1


def parse_table(payload: dict) -> list[dict]:
    """表格 → unit 指标列表。

    Meta 表格每格带 `aria-colindex`。优先用它把「表头文字 → 单元格」精确对齐，
    完全不依赖列数猜测——实测这是唯一可靠的做法（表头 17 列，数据行 18 格，
    首格是复选框，靠顺序对齐必然错位）。
    没有 aria-colindex 时退回「按序对齐 + 自动探测偏移」。
    """
    headers = payload.get("headers") or []
    header_idx = payload.get("headerIdx") or []
    rows = payload.get("rows") or []
    if not headers or not rows:
        return []

    col_indexed = bool(payload.get("colIndexed")) and any(
        x is not None for x in header_idx)

    # 关键：Meta 表格首列（aria-colindex=1）是「全选复选框」空列，
    # 表头与数据行**都**从 colindex=1 开始标号，但真实内容从 2 开始。
    # 判定方式：若第一行第一格文本为空，则整体数据列 index = header index + 1。
    shift = 0
    if col_indexed:
        first_row = rows[0].get("cells") or []
        if first_row:
            c0 = first_row[0]
            if (c0.get("text") or "").strip() == "" and c0.get("idx") == header_idx[0]:
                shift = 1

    # 表头文字 → 数据列索引（已含 shift）
    head_map: dict[str, int] = {}
    if col_indexed:
        for text, idx in zip(headers, header_idx):
            if idx is None:
                continue
            clean = text.replace("\u200b", "").strip()
            head_map.setdefault(clean, int(idx) + shift)

    def find_col(*names: str) -> int | None:
        for clean, idx in head_map.items():
            for n in names:
                if n in clean:
                    return idx
        return None

    # 退回模式：顺序对齐 + 偏移探测
    fallback_idx: dict[str, int] = {}
    offset = 0
    if not col_indexed:
        probe = [r.get("cells") or [] for r in rows[:8]]
        probe = [p for p in probe if len(p) >= 4]
        if probe and len(probe[0]) > len(headers):
            offset = len(probe[0]) - len(headers)
        elif probe:
            empty_first = sum(1 for p in probe if p and (p[0].get("text") or "").strip() == "")
            if empty_first >= max(1, len(probe) // 2):
                offset = 1
        for i, h in enumerate(headers):
            clean = h.replace("\u200b", "").strip()
            fallback_idx.setdefault(clean, i + offset)

        def find_col_fb(*names: str) -> int | None:  # noqa: F811
            for clean, idx in fallback_idx.items():
                for n in names:
                    if n in clean:
                        return idx
            return None
        find_col = find_col_fb  # type: ignore

    def cell(cells: list[dict], *names: str) -> str:
        i = find_col(*names)
        if i is None:
            return ""
        # 主路径：按 aria-colindex 精确匹配
        for c in cells:
            if c.get("idx") is not None and int(c["idx"]) == int(i):
                return (c.get("text") or "").strip()
        # 退化路径：按数组位置（此时 i 已是偏移后的下标）
        if 0 <= i < len(cells):
            return (cells[i].get("text") or "").strip()
        return ""

    out = []
    for r in rows:
        cells = r.get("cells") or []
        if len(cells) < 3:
            continue
        title = cell(cells, "标题")
        if len(title) < 3:
            continue
        plays = parse_count(cell(cells, "浏览量", "播放"))
        reach = parse_count(cell(cells, "覆盖人数", "覆盖"))
        reactions = parse_count(cell(cells, "获赞数和心情数", "获赞", "心情"))
        comments = parse_count(cell(cells, "评论数", "评论"))
        shares = parse_count(cell(cells, "分享次数", "分享"))
        saves = parse_count(cell(cells, "收藏次数", "收藏"))
        clicks = parse_count(cell(cells, "链接点击量", "链接点击"))
        watch_sec = parse_duration(cell(cells, "观看时长"))
        avg_watch = parse_duration(cell(cells, "视频平均播放时长", "平均播放时长"))
        three = parse_count(cell(cells, "观看达 3 秒", "3 秒"))

        pid = r.get("pid")
        if not pid:
            fp = (cell(cells, "发布日期") + "|" + title[:60]).encode("utf-8")
            pid = "fp_" + hashlib.sha1(fp).hexdigest()[:16]

        iso_date, raw_date = parse_post_date(cell(cells, "发布日期"))

        out.append({
            "post_id": pid,
            "title": title[:200],
            "published_at": raw_date,
            "published_date": iso_date,
            "status": cell(cells, "状态"),
            "plays": plays,
            "reach": reach,
            "reactions": reactions,
            "comments": comments,
            "shares": shares,
            "saves": saves,
            "clicks": clicks,
            "watch_sec": watch_sec,
            "avg_watch": avg_watch,
            "three_sec": three,
            "source": "suite_table",
        })
    return out


async def collect_via_suite(fb, asset_id: str, env_code: str = "",
                            page_id: str = "") -> list[dict]:
    """Business Suite 内容库。拟人化滚动 + guard 检查。

    复用 fb 的唯一工作标签，不再每次新开（否则 18 个主页会开 18 个标签）。
    """
    page = await fb.tab()
    try:
        await hz.pacer.wait(env_code or asset_id)
        await page.goto(
            f"https://business.facebook.com/latest/posts/published_posts?asset_id={asset_id}",
            wait_until_loaded=10.0)
        await hz.human_delay("read")

        v = await gd.guard(page, env_code, page_id)
        if v.tripped:
            return [{"_guard": v.as_dict()}]

        # 表格是懒加载的，滚到底
        await hz.human_scroll_until_stable(page, rounds=10)
        await hz.human_delay("op")

        raw = await page.eval(TABLE_JS) or {}

        v = await gd.guard(page, env_code, page_id)
        if v.tripped:
            return [{"_guard": v.as_dict()}]

        rows = parse_table(raw)
        log.info("suite %s -> %d rows (headers=%d)",
                 asset_id, len(rows), len(raw.get("headers") or []))
        return rows
    except Exception as e:
        log.debug("suite collect failed: %s", e)
        return []
    # 标签由 FB.close_tab() 统一回收，这里不关


# ---------------- 落库 ----------------
def upsert_unit_metrics(page_id: str, asset_id: str, row: dict,
                        day: str | None = None,
                        window_days: int = 30) -> str:
    """写 units + unit_metrics。

    30 天窗口：published_date 早于窗口的直接丢弃（不建 unit、不写指标）。
    published_date 解析不出来时放行（避免误杀）。
    """
    day = day or date.today().isoformat()
    post_id = (row.get("post_id") or "").strip()
    if not post_id:
        return ""

    pub_date = (row.get("published_date") or "").strip()
    if pub_date:
        try:
            cutoff = (date.today() - timedelta(days=window_days)).isoformat()
            if pub_date < cutoff:
                return ""      # 超出 30 天窗口
        except Exception:
            pass

    unit = db.q1("SELECT * FROM units WHERE post_id=? AND page_id=?",
                 (post_id, page_id))
    if not unit:
        uid = "u-" + post_id[-14:]
        # 幂等写：同一帖子被重复抓取时（CDP 滚动重叠 / 页面重复渲染）
        # 旧逻辑会撞 UNIQUE(units.id) 把整个主页的采集搞失败。
        # 这里改成 UPSERT：已存在就更新可变字段，不覆盖已有标签/文件关联。
        try:
            db.exec(
                "INSERT INTO units(id,page_id,asset_id,file,title,caption,"
                "published_at,published_date,post_id,state,created_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)"
                " ON CONFLICT(id) DO UPDATE SET"
                " asset_id=COALESCE(excluded.asset_id, units.asset_id),"
                " title=CASE WHEN excluded.title<>'' THEN excluded.title"
                "            ELSE units.title END,"
                " published_at=COALESCE(excluded.published_at, units.published_at),"
                " published_date=COALESCE(excluded.published_date,"
                "                         units.published_date),"
                " post_id=COALESCE(excluded.post_id, units.post_id)",
                (uid, page_id, asset_id, None, row.get("title") or "",
                 None, row.get("published_at") or now_iso(), pub_date or None,
                 post_id, "published", now_iso()))
        except Exception as e:
            # 万一 UPSERT 也失败，退化为查已有 id，保证后续指标仍能写入
            log.warning("upsert unit 失败 %s: %s", uid, str(e)[:120])
    else:
        uid = unit["id"]
        patch = {}
        if row.get("title") and row["title"] != unit["title"]:
            patch["title"] = row["title"]
        if pub_date and pub_date != unit.get("published_date"):
            patch["published_date"] = pub_date
        if row.get("published_at") and row["published_at"] != unit.get("published_at"):
            patch["published_at"] = row["published_at"]
        if patch:
            sets = ",".join(f"{k}=?" for k in patch)
            db.exec(f"UPDATE units SET {sets} WHERE id=?", (*patch.values(), uid))

    db.exec(
        "INSERT INTO unit_metrics(unit_id,date,plays,reach,reactions,comments,shares,"
        "saves,watch_sec,avg_watch,completion,clicks,collected_at,source)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        " ON CONFLICT(unit_id,date) DO UPDATE SET"
        " plays=excluded.plays, reach=excluded.reach, reactions=excluded.reactions,"
        " comments=excluded.comments, shares=excluded.shares, saves=excluded.saves,"
        " watch_sec=excluded.watch_sec, avg_watch=excluded.avg_watch,"
        " clicks=excluded.clicks, collected_at=excluded.collected_at,"
        " source=excluded.source",
        (uid, day, row.get("plays") or 0, row.get("reach") or 0,
         row.get("reactions") or 0, row.get("comments") or 0,
         row.get("shares") or 0, row.get("saves") or 0,
         int(row.get("watch_sec") or 0), row.get("avg_watch") or 0,
         0, row.get("clicks") or 0, now_iso(),
         row.get("source") or "suite_table"))
    return uid


# ---------------- 编排 ----------------
async def collect_page(fb, page_id: str, asset_id: str, env_code: str = "",
                       token: str = "", window_days: int = 30) -> dict:
    result = {"pageId": page_id, "api": 0, "cdp": 0, "guard": None,
              "error": None, "saved": 0, "skippedOutWindow": 0}
    rows: list[dict] = []

    if token:
        api_rows = await collect_via_graph(page_id, token, since_days=window_days)
        rows.extend(api_rows)
        result["api"] = len(api_rows)

    if asset_id and (not token or len(rows) == 0):
        cdp_rows = await collect_via_suite(fb, asset_id, env_code, page_id)
        for r in cdp_rows:
            if "_guard" in r:
                result["guard"] = r["_guard"]
                break
            rows.append(r)
        result["cdp"] = len([r for r in cdp_rows if "_guard" not in r])

    seen: set[str] = set()
    for r in rows:
        pid = (r.get("post_id") or "").strip()
        if not pid or pid in seen:
            continue
        seen.add(pid)
        uid = upsert_unit_metrics(page_id, asset_id, r, window_days=window_days)
        if uid:
            result["saved"] += 1
        else:
            result["skippedOutWindow"] += 1
    return result


async def collect_all(env_code: str, cdp_port: int, token: str = "",
                      page_ids: list[str] | None = None,
                      window_days: int = 30) -> dict:
    from app.adapters.facebook import FB
    targets = page_ids or [p["page_id"] for p in db.q(
        "SELECT page_id FROM pages WHERE asset_id IS NOT NULL")]
    summary = {"total": len(targets), "ok": 0, "guard": 0, "error": 0,
               "saved": 0, "skippedOutWindow": 0, "windowDays": window_days,
               "details": []}

    async with FB(cdp_port) as fb:
        for i, pid in enumerate(targets):
            row = db.q1("SELECT * FROM pages WHERE page_id=?", (pid,))
            if not row:
                continue
            blocked = gd.is_blocked(env_code, pid)
            if blocked:
                summary["guard"] += 1
                summary["details"].append({"pageId": pid, "skipped": blocked["message"]})
                continue
            try:
                r = await collect_page(fb, pid, row["asset_id"] or "", env_code,
                                       token, window_days=window_days)
                if r.get("guard"):
                    summary["guard"] += 1
                    if (r["guard"] or {}).get("scope") in ("account", "global"):
                        summary["details"].append({"pageId": pid, "guard": r["guard"]})
                        db.log_event("err", "metrics", "账号级风控，采集中止")
                        break
                else:
                    summary["ok"] += 1
                    summary["saved"] += r.get("saved", 0)
                    summary["skippedOutWindow"] += r.get("skippedOutWindow", 0)
                summary["details"].append({"pageId": pid, **r})
            except Exception as e:
                summary["error"] += 1
                summary["details"].append({"pageId": pid, "error": str(e)[:120]})
            # 更新进度（前端可轮询）
            try:
                db.exec("UPDATE jobs SET progress=? WHERE kind='metrics' AND "
                        "status='running'", (int((i + 1) / len(targets) * 100),))
            except Exception:
                pass
            if i < len(targets) - 1:
                await hz.human_delay("nav")
    # 收尾：关掉多余标签，只留 1 个
    try:
        n = await fb.prune_tabs(keep=1)
        if n:
            log.info("collect_all pruned %d tabs", n)
    except Exception:
        pass
    return summary
