"""标题与链接：多链接池随机 + 大模型生成多样化标题。

需求：
    · 一个主页可以配多个推广链接，发布时**随机分配**，链接本身不改写
    · 给一个参考标题，让大模型生成 N 个不同标题，发布时随机取用
    · 已有的发布记录记下用了哪个链接，避免同主页连续用同一条
"""
from __future__ import annotations

import hashlib
import json
import logging
import random
import uuid
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.caption")


# ---------------- 链接池 ----------------
def list_links(page_id: str = "") -> list[dict]:
    sql = "SELECT * FROM promo_links WHERE 1=1"
    params: list[Any] = []
    if page_id:
        sql += " AND (page_id=? OR page_id='')"
        params.append(page_id)
    sql += " ORDER BY created_at DESC"
    return db.q(sql, params)


def add_link(label: str, url: str, page_id: str = "", weight: int = 1,
             note: str = "") -> str:
    lid = "lnk-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO promo_links(id,label,url,page_id,weight,enabled,note,"
            "used_count,created_at) VALUES(?,?,?,?,?,1,?,0,?)",
            (lid, label, url, page_id, max(1, weight), note, now_iso()))
    return lid


def pick_link(page_id: str, exclude_last: int = 3) -> dict | None:
    """随机挑一个链接。

    规则：主页专属 + 全局共用；权重生效；避开最近用过的几条。
    """
    links = [x for x in list_links(page_id) if x["enabled"]]
    if not links:
        return None
    # 最近用过的（避免连续重复）
    recent = db.q(
        "SELECT link_id FROM units WHERE page_id=? AND link_id IS NOT NULL "
        "ORDER BY created_at DESC LIMIT ?", (page_id, exclude_last))
    recent_ids = {r["link_id"] for r in recent}
    pool = [x for x in links if x["id"] not in recent_ids] or links

    # 加权随机
    weights = [max(1, int(x["weight"] or 1)) for x in pool]
    return random.choices(pool, weights=weights, k=1)[0]


def mark_link_used(link_id: str) -> None:
    db.exec("UPDATE promo_links SET used_count=used_count+1, last_used=? WHERE id=?",
            (now_iso(), link_id))


# ---------------- 标题生成 ----------------
REFERENCE_TITLE = ("When she walked into the banquet, everyone laughed at her cheap dress — "
                   "until the CEO stood up and called her 'mother'.")


def _heuristic_variants(ref: str, n: int, page_name: str = "") -> list[str]:
    """无模型时的规则变体：换开头钩子句式，不改变事实内容。"""
    hooks = [
        "Everyone laughed at her…",
        "She thought he was nobody.",
        "They humiliated her in public.",
        "Nobody knew who she really was.",
        "The moment he stood up, everything changed.",
        "Her cheap dress hid a secret.",
        "They called her a fraud. Then the truth came out.",
        "He said one word and the whole room went silent.",
    ]
    out = []
    body = ref or REFERENCE_TITLE
    for i in range(max(1, n)):
        h = hooks[i % len(hooks)]
        tail = body.split("—")[-1].strip() if "—" in body else ""
        v = f"{h} {tail}".strip()
        if page_name:
            v = f"{v}"
        out.append(v[:180])
    return out


async def generate_titles(ref: str, n: int = 5, model_id: str = "",
                          page_name: str = "") -> dict:
    """让大模型基于参考标题生成 N 个不同标题；失败退回规则变体。"""
    from app.services import ai_analysis as ai

    prompt = f"""你是短剧推广文案。下面是参考标题：

「{ref or REFERENCE_TITLE}」

请生成 {n} 个**不同角度**的英文标题，要求：
- 每条都必须有强钩子（悬念 / 反差 / 打脸 / 身份揭露）
- 长度 60–140 字符，适合 Facebook Reels 首行展示
- 互相之间不能重复句式开头，不要用相同的第一个词
- 只输出 JSON 数组，形如 ["title1", "title2", ...]，不要任何其它文字
- 不要出现具体品牌名、不要夸大收益、不要提到时长
"""
    try:
        text, used = await ai.call_model(prompt, model_id)
        data = ai.extract_json(text)
        if isinstance(data, dict):
            data = data.get("titles") or data.get("result") or []
        if isinstance(data, list) and data:
            titles = [str(x).strip() for x in data if str(x).strip()][:n]
            if titles:
                return {"titles": titles, "source": f"model:{used}"}
    except Exception as e:
        log.warning("generate_titles model failed: %s", e)

    return {"titles": _heuristic_variants(ref, n, page_name),
            "source": "heuristic"}


def pick_caption(page_id: str, ref: str = "", n: int = 5) -> dict:
    """从该主页的标题池里随机取一条。

    两个来源合并（新版用 caption_variants，老版用 title_pool），
    任一侧有数据都能用，避免「界面显示有变体但发布用不上」。
    """
    pool = list_title_pool(page_id)
    if not pool:
        return {"title": ref or REFERENCE_TITLE, "source": "reference"}

    recent = db.q(
        "SELECT title_id FROM units WHERE page_id=? AND title_id IS NOT NULL "
        "ORDER BY created_at DESC LIMIT 3", (page_id,))
    recent_ids = {r["title_id"] for r in recent}
    fresh = [x for x in pool if x["id"] not in recent_ids] or pool

    # 同一轮次内尽量不撞车：优先选 used_count 最小的那批，再在批内随机。
    # 这样主页多、池子小时也不会重复到同一条。
    if len(fresh) > 1:
        try:
            counted = _attach_used_counts(fresh)
            min_used = min(c["used"] for c in counted)
            least = [c for c in counted if c["used"] == min_used]
            pick = random.choice(least)
        except Exception:
            pick = random.choice(fresh)
    else:
        pick = random.choice(fresh)
    return {"title": pick["title"], "source": f"pool:{pick['id']}",
            "titleId": pick["id"]}


def _attach_used_counts(items: list[dict]) -> list[dict]:
    """给标题补上历史使用次数，供轮转挑选使用。"""
    out = []
    for it in items:
        used = 0
        src = it.get("source")
        try:
            if src == "variant":
                row = db.q1(
                    "SELECT used_count FROM caption_variants WHERE id=?",
                    (it.get("id"),))
            else:
                row = db.q1(
                    "SELECT used_count FROM title_pool WHERE id=?",
                    (it.get("id"),))
            used = int((row or {}).get("used_count") or 0)
        except Exception:
            used = 0
        out.append({**it, "used": used})
    return out


def mark_title_used(title_id: str, source: str = "") -> None:
    """把标题的 used_count +1，实现轮转。"""
    try:
        if source == "pool":
            db.exec("UPDATE title_pool SET used_count=COALESCE(used_count,0)+1 "
                    "WHERE id=?", (title_id,))
        else:
            db.exec("UPDATE caption_variants "
                    "SET used_count=COALESCE(used_count,0)+1 WHERE id=?",
                    (title_id,))
    except Exception as e:
        log.warning("标记标题已用失败: %s", e)


def list_title_pool(page_id: str = "") -> list[dict]:
    """合并 caption_variants（新）与 title_pool（旧）两个标题来源。

    返回统一结构 [{id, title, source}]，去掉空串与完全重复的标题。
    """
    out: list[dict] = []
    seen: set[str] = set()

    # 新表：caption_variants（body 是完整文案，取首行当标题）
    try:
        if page_id:
            rows = db.q(
                "SELECT id, body FROM caption_variants WHERE enabled=1 "
                "AND (page_id=? OR page_id='') ORDER BY created_at DESC",
                (page_id,))
        else:
            rows = db.q("SELECT id, body FROM caption_variants WHERE enabled=1 "
                        "ORDER BY created_at DESC")
        for r in rows or []:
            body = (r.get("body") or "").strip()
            if not body:
                continue
            title = body.split("\n")[0].strip()
            if not title or title in seen:
                continue
            seen.add(title)
            out.append({"id": r.get("id"), "title": title,
                        "source": "variant"})
    except Exception as e:
        log.warning("读 caption_variants 失败: %s", e)

    # 旧表：title_pool
    try:
        if page_id:
            rows = db.q("SELECT id, title FROM title_pool WHERE enabled=1 "
                        "AND (page_id=? OR page_id='') "
                        "ORDER BY created_at DESC", (page_id,))
        else:
            rows = db.q("SELECT id, title FROM title_pool WHERE enabled=1 "
                        "ORDER BY created_at DESC")
        for r in rows or []:
            title = (r.get("title") or "").strip()
            if not title or title in seen:
                continue
            seen.add(title)
            out.append({"id": r.get("id"), "title": title, "source": "pool"})
    except Exception as e:
        log.warning("读 title_pool 失败: %s", e)

    return out


def pool_size(page_id: str = "") -> int:
    """当前可用标题条数（供前端提示与自动生成判断）。"""
    return len(list_title_pool(page_id))


async def ensure_title_pool(page_id: str = "", ref: str = "",
                            want: int = 8, model_id: str = "",
                            drama: str = "") -> dict:
    """池子不足时自动用大模型补一批标题，写入 caption_variants。

    返回 {generated, total, source}。已有足够标题时不动。
    """
    current = pool_size(page_id)
    if current >= want:
        return {"generated": 0, "total": current, "source": "existing"}

    need = max(1, want - current)
    try:
        r = await generate_titles(ref or REFERENCE_TITLE, need, model_id)
    except Exception as e:
        log.warning("自动生成标题失败: %s", e)
        return {"generated": 0, "total": current, "source": "failed"}

    titles = [t for t in (r.get("titles") or []) if t.strip()]
    if not titles:
        return {"generated": 0, "total": current, "source": "empty"}

    from app.db import now_iso as _now
    from uuid import uuid4
    added = 0
    for t in titles:
        try:
            vid = "cv-" + uuid4().hex[:10]
            db.exec(
                "INSERT INTO caption_variants"
                "(id,template_id,page_id,body,source,enabled,used_count,created_at) "
                "VALUES(?,?,?,?,?,1,0,?)",
                (vid, "", page_id or "", t.strip()[:4000],
                 "auto:" + str(r.get("source") or "model"), _now()))
            added += 1
        except Exception as e:
            log.warning("写入自动标题失败: %s", e)

    db.log_event("ok", "caption",
                 f"自动补标题 {added} 条（主页 {page_id or '全局'}）")
    return {"generated": added, "total": current + added,
            "source": r.get("source") or "model"}


def save_titles(page_id: str, titles: list[str], ref: str = "",
                source: str = "") -> int:
    db.exec("DELETE FROM title_pool WHERE page_id=? AND source=?",
            (page_id, source or "generated"))
    n = 0
    for t in titles:
        if not t.strip():
            continue
        tid = "ttl-" + hashlib.sha1(
            f"{page_id}|{t}|{now_iso()}".encode()).hexdigest()[:10]
        db.exec("INSERT INTO title_pool(id,page_id,title,ref,source,enabled,created_at)"
                " VALUES(?,?,?,?,?,1,?) ON CONFLICT(id) DO NOTHING",
                (tid, page_id, t.strip()[:300], ref[:300],
                 source or "generated", now_iso()))
        n += 1
    return n
