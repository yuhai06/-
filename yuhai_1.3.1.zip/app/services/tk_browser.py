"""Chrome 调试浏览器管理

提供 4 个能力：
    1. ensure(headless=True)  没开就自动开；已开就复用
    2. stop()                 用完彻底关掉（释放内存）
    3. status()               当前状态：在不在跑、headless、多久没用
    4. 空闲自动关闭            超过 N 分钟没查询就自己关

为什么要 headless：
    TK短剧只需要接口数据，不需要看画面。headless 模式下
    不给用户弹窗口，查询完还能立刻关，体验更干净。
    但 TikTok 对 headless 更敏感，所以保留有头模式作为备选。
"""
from __future__ import annotations

import json
import logging
import os
import socket
import subprocess
import time
from pathlib import Path

log = logging.getLogger("yuhai.services.tk_browser")

CDP_PORT = 9222
CDP_URL = f"http://127.0.0.1:{CDP_PORT}"

# 状态
_PROC = [None]          # 自己启动的 Chrome 进程
_LAST_USE = [0.0]       # 上次使用时间
_HEADLESS = [True]      # 当前是否无头
_IDLE_TIMEOUT = [300]   # 空闲多少秒后自动关（0=不自动关）

# headless 用的独立 profile，避免动用户的真实浏览器
PROFILE_DIR = Path(os.getenv("LOCALAPPDATA") or ".") / "YuhaiWorkbench" / "tk_profile"


def _port_open(port: int = CDP_PORT) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.6):
            return True
    except Exception:
        return False


def cdp_alive() -> bool:
    """CDP 端口是否有响应（区分「端开着」和「Chrome 真活着」）"""
    if not _port_open():
        return False
    try:
        import requests
        r = requests.get(f"{CDP_URL}/json/version", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


def _find_chrome() -> str | None:
    cands = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
        / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
        / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for c in cands:
        try:
            if c.exists():
                return str(c)
        except Exception:
            continue
    return None


def _profile_has_login() -> bool:
    """headless profile 里有没有登录态（有 Cookies 文件就算）"""
    try:
        c = PROFILE_DIR / "Default" / "Network" / "Cookies"
        return c.exists() and c.stat().st_size > 1024
    except Exception:
        return False


def stop() -> dict:
    """彻底关闭调试浏览器

    两种情况都要处理：
      ① 自己启动的（有 _PROC 句柄）→ terminate
      ② 手动启动的（无句柄）→ 按 user-data-dir 找到进程再 kill
    """
    p = _PROC[0]
    killed = False

    if p is not None:
        try:
            p.terminate()
            try:
                p.wait(timeout=8)
            except Exception:
                p.kill()
            killed = True
        except Exception:
            pass
        _PROC[0] = None

    # 通用兜底：找出所有带 9222 调试端口的 chrome 进程
    if os.name == "nt":
        pids: list[str] = []
        # 方式 A：PowerShell（Win11 上 wmic 已弃用）
        try:
            ps = (
                "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | "
                "Where-Object { $_.CommandLine -like '*remote-debugging-port=9222*' "
                f"-or $_.CommandLine -like '*{PROFILE_DIR}*' }} | "
                "Select-Object -ExpandProperty ProcessId"
            )
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                capture_output=True, text=True, timeout=25,
                creationflags=0x08000000)
            for line in (out.stdout or "").splitlines():
                s = line.strip()
                if s.isdigit():
                    pids.append(s)
        except Exception as e:
            log.debug("powershell scan failed: %s", e)

        # 方式 B：wmic（老系统兜底）
        if not pids:
            try:
                out = subprocess.run(
                    ["wmic", "process", "where", "name='chrome.exe'",
                     "get", "ProcessId,CommandLine", "/format:csv"],
                    capture_output=True, text=True, timeout=20,
                    creationflags=0x08000000)
                for line in (out.stdout or "").splitlines():
                    if "remote-debugging-port=9222" in line or str(PROFILE_DIR) in line:
                        seg = line.rsplit(",", 1)
                        if len(seg) == 2 and seg[1].strip().isdigit():
                            pids.append(seg[1].strip())
            except Exception:
                pass

        for pid in set(pids):
            try:
                subprocess.run(["taskkill", "/F", "/PID", pid],
                               capture_output=True, timeout=10,
                               creationflags=0x08000000)
                killed = True
                log.info("killed chrome pid=%s", pid)
            except Exception:
                pass

    _LAST_USE[0] = 0.0
    # 给进程一点退出时间
    for _ in range(10):
        if not cdp_alive():
            break
        time.sleep(0.5)
    return {"ok": True, "killed": killed, "alive": cdp_alive()}


def start(headless: bool = True, fresh_profile: bool = False) -> dict:
    """启动 Chrome（带 9222 调试端口）

    headless=True：无窗口，用户看不到
    fresh_profile=False：复用专用 profile（保留登录）
    """
    if cdp_alive():
        _LAST_USE[0] = time.time()
        return {"ok": True, "already": True, "headless": _HEADLESS[0],
                "profile": str(PROFILE_DIR)}

    exe = _find_chrome()
    if not exe:
        raise RuntimeError("找不到 chrome.exe，请确认已安装 Google Chrome")

    if fresh_profile:
        import shutil
        try:
            shutil.rmtree(PROFILE_DIR, ignore_errors=True)
        except Exception:
            pass
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    args = [
        exe,
        f"--remote-debugging-port={CDP_PORT}",
        "--remote-allow-origins=*",
        f"--user-data-dir={PROFILE_DIR}",
        "--profile-directory=Default",
        "--disable-blink-features=AutomationControlled",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-extensions",
        "--disable-background-networking",
        "--disable-sync",
        "--disable-features=Translate,OptimizationHints",
        "--window-size=1280,900",
    ]
    if headless:
        # 新版 headless（Chrome 112+）：指纹更接近有头
        args.append("--headless=new")
        args.append("--disable-gpu")
        args.append("--mute-audio")
    args.append("https://www.tiktok.com/shortdrama")

    flags = 0
    if os.name == "nt":
        flags = 0x08000000 | 0x00000200   # CREATE_NO_WINDOW | NEW_PROCESS_GROUP

    p = subprocess.Popen(args, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL,
                         creationflags=flags)
    _PROC[0] = p
    _HEADLESS[0] = headless

    # 等端口起来（最多 25 秒）
    t0 = time.time()
    while time.time() - t0 < 25:
        if cdp_alive():
            _LAST_USE[0] = time.time()
            return {"ok": True, "already": False, "headless": headless,
                    "profile": str(PROFILE_DIR), "wait": round(time.time() - t0, 1)}
        time.sleep(0.7)

    raise RuntimeError(
        "Chrome 启动了但 9222 端口没响应。\n"
        "可能原因：① 已有 Chrome 占用该端口 ② 安全软件拦截。\n"
        "建议：先把所有 Chrome 关掉再试。")


def ensure(headless: bool = True) -> dict:
    """要用之前调用：没开就开，开了就复用"""
    if cdp_alive():
        _LAST_USE[0] = time.time()
        return {"ok": True, "already": True, "headless": _HEADLESS[0],
                "profile": str(PROFILE_DIR)}
    return start(headless=headless)


def touch() -> None:
    """每次查询后刷新使用时间（给空闲关闭用）"""
    _LAST_USE[0] = time.time()


def status() -> dict:
    alive = cdp_alive()
    idle = (time.time() - _LAST_USE[0]) if _LAST_USE[0] else None
    return {
        "alive": alive,
        "headless": _HEADLESS[0],
        "owned": _PROC[0] is not None,
        "profile": str(PROFILE_DIR),
        "has_login": _profile_has_login(),
        "idle_sec": round(idle, 0) if idle is not None else None,
        "idle_timeout": _IDLE_TIMEOUT[0],
        "cdp_url": CDP_URL,
    }


def set_idle_timeout(sec: int) -> dict:
    _IDLE_TIMEOUT[0] = max(0, int(sec))
    return status()


def set_headless(on: bool) -> dict:
    _HEADLESS[0] = bool(on)
    return status()


def reap_if_idle() -> bool:
    """被定时器调用：空闲超时就关掉自己启的 Chrome"""
    t = _IDLE_TIMEOUT[0]
    if not t or not _PROC[0] or not _LAST_USE[0]:
        return False
    if time.time() - _LAST_USE[0] < t:
        return False
    log.info("tk browser idle %ss -> shutdown", t)
    stop()
    return True
