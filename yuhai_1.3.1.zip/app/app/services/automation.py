"""全自动总控——一个开关管住软件里所有自动化（不含排期发布）。

用户要求：概览页一个「全自动」总开关，一键启停所有自动流程，
但**明确不含自动排期和自动发布**（发布必须人工确认，这是硬规则）。

受管的自动化（8 项）：
    ① commentWatch    评论区维护：自动回复/删恶评（6 小时一轮）
    ② metrics         视频数据采集：抓播放量/粉丝数
    ③ guardWatch      风控巡检：检测 checkpoint/captcha/封号信号
    ④ quotaBalance    配额回收：冷却到期的号自动恢复额度
    ⑤ grabHot         素材抓取：按条件自动抓当天热门
    ⑥ aiFit           主页画像：大模型分析适合什么类型视频
    ⑦ observeOnly     只观察不动作（安全模式：只记录，不执行写操作）
    ⑧ catchUp         开机补漏：关机期间漏的评论/数据补一轮

明确**不受管**（永远手动）：
    ✗ 排期（schedule）     ✗ 发布（publish）
    ✗ 建主页（createPage） ✗ 授权（authz）

设计要点：
    · 单一开关状态存 kv:auto.master，所有子项都读它
    · 关掉时正在跑的任务跑完当前这一轮就停（不硬杀，避免半途留下脏数据）
    · 每项单独也有开关，总开关关掉时全部忽略
    · 状态可查：每项的启用状态、上次运行、下次预计时间
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.auto")

KV_KEY = "auto.master"

# 这些项不计入「X/Y 项生效」的统计：
#   observeOnly 是保险开关（常态应为关，开了反而是限制）
#   commentInstant 是手动触发项（不是常驻轮询）
_NOT_COUNTED = {"observeOnly", "commentInstant"}

# 受管项定义（这些才会被总开关影响）
ITEMS: list[dict] = [
    {
        "key": "commentWatch", "name": "评论区维护",
        "desc": "自动回复真实互动、删恶评/蹭热度/违规言论，回复必带推广链接",
        "intervalMin": 360, "kv": "comment_watch", "field": "enabled",
        "icon": "mail",
    },
    {
        "key": "commentInstant", "name": "一键评论（手动触发）",
        "desc": "点一下立刻跑一轮评论维护，不用等 6 小时间隔",
        "intervalMin": 0, "kv": "auto.instant", "field": "enabled",
        "icon": "bolt",
    },
    {
        "key": "metrics", "name": "视频数据采集",
        "desc": "采集近 30 天播放量/粉丝数/发布时间",
        "intervalMin": 720, "kv": "auto.metrics", "field": "enabled",
        "icon": "chart",
    },
    {
        "key": "guardWatch", "name": "风控巡检",
        "desc": "检测 checkpoint / captcha / 操作受限 / 限流信号",
        "intervalMin": 60, "kv": "auto.guard", "field": "enabled",
        "icon": "shield",
    },
    {
        "key": "quotaBalance", "name": "配额回收",
        "desc": "冷却到期的账号自动恢复建主页额度",
        "intervalMin": 180, "kv": "auto.quota", "field": "enabled",
        "icon": "key",
    },
    {
        "key": "grabHot", "name": "素材自动抓取",
        "desc": "按设定条件自动抓当天热门（已抓过的自动跳过）",
        "intervalMin": 1440, "kv": "auto.grab", "field": "enabled",
        "icon": "down",
    },
    {
        "key": "aiFit", "name": "主页画像分析",
        "desc": "大模型根据视频数据+人群年龄性别，分析主页适合什么类型",
        "intervalMin": 1440, "kv": "auto.aifit", "field": "enabled",
        "icon": "eye",
    },
    {
        "key": "observeOnly", "name": "只观察不动作",
        "desc": "安全模式：只记录问题，不执行任何写操作（评论/发布/建主页全停）",
        "intervalMin": 0, "kv": "auto.observe", "field": "enabled",
        "icon": "search",
    },
    {
        "key": "catchUp", "name": "开机补漏",
        "desc": "开机后补跑一轮，追上关机期间漏掉的评论和数据",
        "intervalMin": 0, "kv": "auto.catchup", "field": "enabled",
        "icon": "clock",
    },
]

# 永远手动，不受总开关影响（只用于说明展示）
MANUAL_ONLY: list[dict] = [
    {"key": "schedule", "name": "排期", "desc": "必须人工确认，自动排期会打乱发布节奏"},
    {"key": "publish", "name": "发布", "desc": "必须人工确认，防止自动发出错素材"},
    {"key": "createPage", "name": "建公共主页", "desc": "平台限制严格，必须手动控制节奏"},
    {"key": "authz", "name": "授权", "desc": "涉及权限，必须人工核对 profile ID"},
]

# 「一键跑一轮」的快捷动作（手动点，不受总开关限制，方便没空时批量触发）
QUICK_ACTIONS: list[dict] = [
    {"key": "comments", "name": "跑一轮评论维护",
     "desc": "立刻扫描全部主页的评论，回复+删恶评（回复必带链接）"},
    {"key": "metrics", "name": "采一次视频数据",
     "desc": "立刻采集全部主页的播放量/粉丝数/发布时间"},
    {"key": "guard", "name": "查一次风控",
     "desc": "立刻巡检所有环境的风控信号（checkpoint/captcha/限流）"},
]


async def run_quick(key: str) -> dict:
    """手动触发一次快捷动作（内部直接调对应 service，不走 HTTP）。"""
    if key == "comments":
        from app.services import comment_watch as cw
        w = _runtime.get("comment_watcher")
        if w is None:
            from app.services.comment_watch import watcher as w2
            w = w2
        # 安全模式下只出计划不动作
        cfg = cw.load_cfg()
        orig = cfg.get("enabled")
        if observe_only():
            cfg = {**cfg, "allowReply": False, "allowDelete": False}
        res = await w.round(cfg)
        if orig is not None:
            pass
        db.log_event("info", "auto", f"手动触发：跑一轮评论维护 → {res.get('reply', 0)} 回 / {res.get('delete', 0)} 删")
        return {"ok": True, "action": "comments", "result": res,
                "observeOnly": observe_only()}

    if key == "guard":
        from app.adapters import guard as gd
        from app.adapters.facebook import FB
        from app.config import settings
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
        if not env:
            return {"ok": False, "error": "发布号环境未启动"}
        code = env.get("container_code") or ""
        found: list[dict] = []
        pages = db.q("SELECT page_id,name,asset_id FROM pages WHERE asset_id IS NOT NULL")
        try:
            async with FB(int(env["cdp_port"])) as fb:
                await fb.assert_identity(settings.fb_publisher_cuser)
                for p in pages:
                    try:
                        v = await gd.check(fb.tab(), env_code=code,
                                           page_id=p["page_id"])
                        if v and getattr(v, "tripped", False):
                            found.append({"page": p["name"], "kind": v.kind,
                                          "severity": v.severity,
                                          "message": (v.message or "")[:120]})
                    except Exception:
                        continue
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}
        db.log_event("info", "auto",
                     f"手动触发：风控巡检 → {len(found)} 个异常")
        return {"ok": True, "action": "guard",
                "result": {"checked": len(pages), "blocked": len(found),
                           "items": found}}

    if key == "metrics":
        from app.services import metrics as mt
        from app.adapters.facebook import FB
        from app.config import settings
        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
        if not env:
            return {"ok": False, "error": "发布号环境未启动"}
        code = env.get("container_code") or ""
        try:
            async with FB(int(env["cdp_port"])) as fb:
                await fb.assert_identity(settings.fb_publisher_cuser)
                res = await mt.collect_all(code, int(env["cdp_port"]))
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}
        db.log_event("info", "auto", "手动触发：采集视频数据")
        return {"ok": True, "action": "metrics", "result": res}

    return {"ok": False, "error": f"未知动作 {key}"}

DEFAULT_STATE: dict[str, Any] = {
    "enabled": False,          # 总开关：默认关，用户自己开
    "items": {},               # {key: bool}，未设置默认为 True
    "updatedAt": "",
    "lastToggleBy": "",
}

# 运行时句柄（main.py 注入，用于真正启停常驻任务）
_runtime: dict[str, Any] = {}


def bind_runtime(**kw: Any) -> None:
    """由 main.py 注入：comment_watcher=实例, scheduler=实例 ..."""
    _runtime.update(kw)


# ---------------- 状态读写 ----------------
def load_state() -> dict:
    r = db.q1("SELECT v FROM kv WHERE k=?", (KV_KEY,))
    state = dict(DEFAULT_STATE)
    if r and r["v"]:
        try:
            got = json.loads(r["v"])
            if isinstance(got, dict):
                state.update(got)
        except Exception:
            pass
    if not isinstance(state.get("items"), dict):
        state["items"] = {}
    # 补齐缺失项（新增的受管项默认跟随总开关）
    for it in ITEMS:
        state["items"].setdefault(it["key"], True)
    return state


def save_state(state: dict) -> dict:
    state["updatedAt"] = now_iso()
    db.exec("INSERT INTO kv(k,v) VALUES(?,?) "
            "ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            (KV_KEY, json.dumps(state, ensure_ascii=False)))
    return state


def is_on(key: str = "") -> bool:
    """某个自动项当前是否生效（总开关 + 子开关都得开）。

    key 为空时只看总开关。
    """
    st = load_state()
    if not st.get("enabled"):
        return False
    if not key:
        return True
    return bool(st["items"].get(key, True))


def observe_only() -> bool:
    """安全模式是否开启（开启时禁止一切写操作）。

    注意：这一项**不受总开关影响**——总开关关掉时它仍然生效。
    理由：安全模式是「保险」，不能因为关了自动化就跟着失效。
    """
    st = load_state()
    return bool(st["items"].get("observeOnly", False))


def status() -> dict:
    """总控面板数据：总开关 + 每项状态 + 上次/下次运行。"""
    st = load_state()
    cw = {}
    try:
        r = db.q1("SELECT v FROM kv WHERE k='comment_watch'")
        if r and r["v"]:
            cw = json.loads(r["v"]) or {}
    except Exception:
        pass

    items = []
    now = datetime.now()
    for it in ITEMS:
        sub_on = bool(st["items"].get(it["key"], True))
        # observeOnly 是保险开关，不受总闸影响；其余项要总闸+子开关都开
        if it["key"] == "observeOnly":
            eff = sub_on
        else:
            eff = bool(st.get("enabled")) and sub_on
        last = ""
        note = ""
        nxt = ""
        if it["key"] == "commentWatch":
            last = cw.get("lastRun") or ""
            note = cw.get("lastResult") or ""
        else:
            try:
                r2 = db.q1("SELECT v FROM kv WHERE k=?", (it["kv"],))
                if r2 and r2["v"]:
                    d = json.loads(r2["v"]) or {}
                    last = d.get("lastRun") or ""
                    note = d.get("lastResult") or ""
            except Exception:
                pass
        if eff and it["intervalMin"] and last:
            try:
                nxt = (datetime.fromisoformat(last.replace("Z", "+00:00"))
                       + timedelta(minutes=it["intervalMin"])).isoformat()
            except Exception:
                nxt = ""
        items.append({
            "key": it["key"], "name": it["name"], "desc": it["desc"],
            "icon": it["icon"], "intervalMin": it["intervalMin"],
            "subOn": sub_on, "active": eff,
            "lastRun": last, "nextRun": nxt, "note": note,
        })

    # 统计：今天各自动跑了多少
    today = now.strftime("%Y-%m-%d")
    try:
        runs_today = db.q1(
            "SELECT COUNT(*) c FROM events WHERE kind LIKE '%auto%' "
            "AND ts >= ?", (today + "T00:00:00",))
        n_today = int((runs_today or {}).get("c") or 0)
    except Exception:
        n_today = 0

    return {
        "enabled": bool(st.get("enabled")),
        "updatedAt": st.get("updatedAt") or "",
        "observeOnly": observe_only(),
        "items": items,
        "manualOnly": MANUAL_ONLY,
        "running": {
            "commentWatcher": bool(_runtime.get("comment_watcher")),
            "scheduler": bool(_runtime.get("scheduler")),
        },
        "todayRuns": n_today,
        "activeCount": sum(1 for x in items
                           if x["active"] and x["key"] not in _NOT_COUNTED),
        "totalCount": sum(1 for x in ITEMS if x["key"] not in _NOT_COUNTED),
        "quickActions": QUICK_ACTIONS,
    }


# ---------------- 开关 ----------------
async def set_master(enabled: bool) -> dict:
    """总开关：开/关所有受管自动化（不含排期发布）。"""
    st = load_state()
    was = bool(st.get("enabled"))
    st["enabled"] = bool(enabled)
    save_state(st)
    await _apply(enabled, was)
    db.log_event("info", "auto",
                 ("全自动 已开启" if enabled else "全自动 已关闭")
                 + f"（{len(ITEMS)} 项受管，排期/发布仍手动）")
    return status()


async def set_item(key: str, enabled: bool) -> dict:
    """单项开关（总开关关着时，子开关只记录状态不生效）。"""
    if key not in {x["key"] for x in ITEMS}:
        return {"ok": False, "error": f"未知自动项 {key}", **status()}
    st = load_state()
    st["items"][key] = bool(enabled)
    save_state(st)
    # 评论区维护有独立配置，同步过去
    if key == "commentWatch":
        try:
            from app.services import comment_watch as cw
            cw.save_cfg({"enabled": bool(enabled)})
        except Exception:
            pass
    await _apply(bool(st.get("enabled")), bool(st.get("enabled")))
    db.log_event("info", "auto",
                 f"自动项 {'开启' if enabled else '关闭'}：{key}")
    return status()


async def _apply(now_on: bool, was_on: bool) -> None:
    """把开关状态落到实际任务上。

    只控制「跑不跑」，不改变用户对各子项的选择意图。
    """
    cw = _runtime.get("comment_watcher")
    try:
        if cw:
            if now_on:
                await cw.start()
            else:
                # 不硬杀：等当前轮跑完自己退出
                log.info("auto off -> comment watcher will stop after current round")
    except Exception as e:
        log.debug("apply comment watcher: %s", e)

    # 同步「评论区维护」的独立配置，只反映总开关，不改用户意图
    try:
        from app.services import comment_watch as cwm
        cwm.save_cfg({"enabled": bool(now_on)})
    except Exception:
        pass


def ensure_defaults() -> dict:
    """启动时校正：子开关一律补齐为 True（历史脏数据/急停残留）。

    只补齐缺失键；已明确设为 False 的保留（那是用户的选择）。
    """
    st = load_state()
    changed = False
    for it in ITEMS:
        if it["key"] not in st["items"]:
            st["items"][it["key"]] = True
            changed = True
    if changed:
        save_state(st)
    return st


async def emergency_stop() -> dict:
    """一键急停：关总闸 + 开安全模式。

    注意：**不改子开关状态**。急停是临时刹车，不是永久改配置；
    用户重新打开总开关时，原来的子项选择应该原样恢复。
    """
    st = load_state()
    st["enabled"] = False
    st["items"]["observeOnly"] = True
    save_state(st)
    await _apply(False, True)
    db.log_event("warn", "auto", "【急停】全自动关闭 + 只观察模式开启")
    return status()
