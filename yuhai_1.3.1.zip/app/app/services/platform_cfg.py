"""发布文案平台配置——FB 只用标题+链接，TK 才带标签。

用户要求（2026-11-07）：
    「我现在是FB运营不用标签只用标题加链接就行，TK才用标签但是我还没开始做」

设计：
    · 平台配置存 kv: `publish.platform`（fb | tk）
    · fb（默认）：标题 + 链接，**不加任何标签**
    · tk：标题 + 链接 + 标签（保留原有 #pinedrama #us #pinedramaus）
    · 也可单独设 `publish.hashtags`（开启则无论平台都加）
"""
from __future__ import annotations

import logging

from app.db import db

log = logging.getLogger("yuhai.platform")

KV_PLATFORM = "publish.platform"
KV_HASHTAGS = "publish.hashtags"

# 各平台的默认标签（空 = 不加）
PLATFORM_TAGS = {
    "fb": "",
    "tk": "#pinedrama #us #pinedramaus",
    "ig": "#pinedrama #us #pinedramaus",
}

PLATFORM_NAMES = {"fb": "Facebook", "tk": "TikTok", "ig": "Instagram"}


def platform() -> str:
    """当前发布平台（默认 fb）。"""
    v = db.get_kv(KV_PLATFORM, "")
    return (v or "fb").strip().lower()


def set_platform(p: str) -> dict:
    p = (p or "fb").strip().lower()
    if p not in PLATFORM_TAGS:
        return {"ok": False, "error": f"未知平台 {p}"}
    db.set_kv(KV_PLATFORM, p)
    db.log_event("info", "publish", f"发布平台切换为 {PLATFORM_NAMES.get(p, p)}")
    return {"ok": True, "platform": p, "hashtags": hashtags()}


def hashtags(plat: str = "") -> str:
    """当前生效的标签串（含前置换行，空串表示不加）。"""
    # 显式覆盖优先
    override = db.get_kv(KV_HASHTAGS, None)
    if override is not None:
        o = str(override).strip()
        if not o:
            return ""
        return "\n\n" + (o if o.startswith("#") else "#" + o)

    p = (plat or platform()).strip().lower()
    tags = PLATFORM_TAGS.get(p, "")
    return ("\n\n" + tags) if tags else ""


def build_body(title: str, link: str = "", plat: str = "") -> str:
    """组装最终正文：标题 + 链接 (+ 标签，按平台)。

    链接原样插入，绝不改写（硬规则）。
    """
    body = title.strip()
    if link:
        body = f"{body}\n\n{link}"
    return body + hashtags(plat)


def info() -> dict:
    p = platform()
    return {
        "platform": p,
        "platformName": PLATFORM_NAMES.get(p, p),
        "hashtags": hashtags().strip(),
        "useHashtags": bool(hashtags().strip()),
        "available": [{"key": k, "name": PLATFORM_NAMES[k],
                       "hashtags": PLATFORM_TAGS[k]} for k in PLATFORM_TAGS],
    }
