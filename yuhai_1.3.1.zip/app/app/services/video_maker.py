"""视频制作：内置 ffmpeg，不依赖任何外部程序。

设计原则（用户要求）：
    · **绝对不外接** —— 所有剪辑用内置 ffmpeg 完成，换电脑也能用
    · 不依赖 ReelsPublisher / Node / Electron
    · 模型可选：只用它生成标题/文案，不参与视频合成

能力：
    ① 切片（按时间区间截取）
    ② 拼接（多段合并）
    ③ 竖屏裁切（16:9 → 9:16）
    ④ 加字幕（烧入）
    ⑤ 变速
    ⑥ 音量归一
    ⑦ 一键出片（切片+拼接+归一 组合）
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.video")


# ---------------- ffmpeg 定位 ----------------
def _bundle_dir() -> Path:
    """打包后 ffmpeg 在 _internal/bin 或 exe 同级 bin。"""
    if getattr(sys, "frozen", False):
        base = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
        for c in (base / "bin", Path(sys.executable).parent / "bin"):
            if (c / "ffmpeg.exe").exists():
                return c
    # 开发时在 backend/bin
    return Path(__file__).resolve().parent.parent.parent / "bin"


def ffmpeg_path() -> str:
    """优先内置，其次系统 PATH。"""
    local = _bundle_dir() / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    if local.exists():
        return str(local)
    from app import paths
    ff, _ = paths.ffmpeg()
    if ff:
        return str(ff)
    found = shutil.which("ffmpeg")
    return found or "ffmpeg"


def ffprobe_path() -> str:
    local = _bundle_dir() / ("ffprobe.exe" if os.name == "nt" else "ffprobe")
    if local.exists():
        return str(local)
    from app import paths
    _, fp = paths.ffmpeg()
    if fp:
        return str(fp)
    found = shutil.which("ffprobe")
    return found or "ffprobe"


def env_check() -> dict:
    """检查内置 ffmpeg 是否可用（不依赖外部安装）。"""
    ff = ffmpeg_path()
    fp = ffprobe_path()
    out = {"ffmpeg": ff, "ffprobe": fp, "bundled": (_bundle_dir() / "ffmpeg.exe").exists(),
           "ok": False, "version": "", "error": None}
    try:
        r = proc.run([ff, "-version"], capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
        if r.returncode == 0:
            out["ok"] = True
            out["version"] = (r.stdout or "").split("\n")[0][:100]
    except Exception as e:
        out["error"] = str(e)[:200]
    return out


# ---------------- 基础工具 ----------------
def probe(path: str) -> dict:
    cmd = [ffprobe_path(), "-v", "error", "-print_format", "json",
           "-show_format", "-show_streams", path]
    try:
        r = proc.run(cmd, capture_output=True, text=True, timeout=60,
                           encoding="utf-8", errors="replace")
        d = json.loads(r.stdout or "{}")
    except Exception as e:
        log.debug("probe failed: %s", e)
        return {}
    dur = float((d.get("format") or {}).get("duration") or 0)
    w = h = 0
    has_audio = False
    fps = 0
    for s in d.get("streams") or []:
        if s.get("codec_type") == "video" and not w:
            w = int(s.get("width") or 0)
            h = int(s.get("height") or 0)
            fr = s.get("r_frame_rate") or "0/1"
            try:
                a, b = fr.split("/")
                fps = round(float(a) / float(b), 2) if float(b) else 0
            except Exception:
                fps = 0
        if s.get("codec_type") == "audio":
            has_audio = True
    return {"dur": round(dur, 2), "w": w, "h": h, "audio": has_audio, "fps": fps,
            "size_mb": round(Path(path).stat().st_size / 1048576, 1)
                        if Path(path).exists() else 0}


def _err_tail(stderr: str, n: int = 6) -> str:
    """从 ffmpeg stderr 里挑出真正有用的错误行（跳过 Metadata 之类的噪音）。"""
    if not stderr:
        return ""
    lines = [x.strip() for x in stderr.strip().split("\n") if x.strip()]
    # 优先找含 error / Invalid / No such / failed 的行
    keys = ("error", "invalid", "no such", "failed", "unable", "cannot",
            "not found", "denied", "unsupported", "conversion failed")
    hits = [x for x in lines if any(k in x.lower() for k in keys)]
    if hits:
        return " | ".join(hits[-n:])[:400]
    return " | ".join(lines[-n:])[:400]


def run_ff(args: list[str], timeout: int = 3600) -> dict:
    """执行 ffmpeg，返回结果。"""
    cmd = [ffmpeg_path(), "-hide_banner", "-y", *args]
    log.info("ffmpeg: %s", " ".join(cmd)[:300])
    try:
        r = proc.run(cmd, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        ok = r.returncode == 0
        return {"ok": ok, "code": r.returncode,
                "stdout": (r.stdout or "")[-2000:],
                "stderr": _err_tail(r.stderr or "") if not ok else "",
                "cmd": " ".join(cmd)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -2, "error": "超时", "stderr": ""}
    except Exception as e:
        return {"ok": False, "code": -3, "error": str(e)[:200], "stderr": ""}


def out_dir() -> Path:
    d = settings.library_root / "待发布" / now_iso()[:10]
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------- 具体操作 ----------------
def clip(src: str, start: float, end: float, name: str = "") -> dict:
    """按时间区间截取。"""
    out = out_dir() / (name or f"clip_{uuid.uuid4().hex[:8]}.mp4")
    r = run_ff(["-ss", str(start), "-to", str(end), "-i", src,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
                str(out)])
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


def concat(paths: list[str], name: str = "") -> dict:
    """拼接多段（统一分辨率后合并）。"""
    if not paths:
        return {"ok": False, "error": "没有输入"}
    if len(paths) == 1:
        return {"ok": True, "path": paths[0]}
    out = out_dir() / (name or f"concat_{uuid.uuid4().hex[:8]}.mp4")
    # 用 concat demuxer（要求编码一致），先统一转一遍
    tmp = []
    first = probe(paths[0])
    w, h = first.get("w") or 1080, first.get("h") or 1920
    for i, p in enumerate(paths):
        t = out_dir() / f"_norm_{uuid.uuid4().hex[:6]}_{i}.mp4"
        r = run_ff(["-i", p, "-vf",
                    f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
                    f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    "-c:a", "aac", "-ar", "44100", "-ac", "2",
                    "-movflags", "+faststart", str(t)])
        if r["ok"]:
            tmp.append(str(t))
    if not tmp:
        return {"ok": False, "error": "统一格式失败"}
    lst = out_dir() / f"_list_{uuid.uuid4().hex[:6]}.txt"
    lst.write_text("\n".join(f"file '{p}'" for p in tmp), encoding="utf-8")
    r = run_ff(["-f", "concat", "-safe", "0", "-i", str(lst),
                "-c", "copy", "-movflags", "+faststart", str(out)])
    for p in tmp + [str(lst)]:
        try:
            Path(p).unlink()
        except Exception:
            pass
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


def to_vertical(src: str, name: str = "", ratio: str = "9:16") -> dict:
    """转竖屏（16:9 → 9:16，模糊背景填充）。"""
    out = out_dir() / (name or f"vert_{uuid.uuid4().hex[:8]}.mp4")
    tw, th = (1080, 1920) if ratio == "9:16" else (1080, 1350)
    vf = (
        f"split=2[bg][fg];"
        f"[bg]scale={tw}:{th}:force_original_aspect_ratio=increase,"
        f"crop={tw}:{th},boxblur=24:2[bgb];"
        f"[fg]scale={tw}:{th}:force_original_aspect_ratio=decrease[fgs];"
        f"[bgb][fgs]overlay=(W-w)/2:(H-h)/2,setsar=1"
    )
    r = run_ff(["-i", src, "-filter_complex", vf,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
                str(out)])
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


def burn_subs(src: str, text: str, name: str = "",
              font_size: int = 42, color: str = "white") -> dict:
    """把一行文字烧进视频底部（不依赖字体文件，用默认字体）。"""
    out = out_dir() / (name or f"sub_{uuid.uuid4().hex[:8]}.mp4")
    # 转义特殊字符
    safe = (text.replace("\\", "\\\\").replace(":", "\\:")
                .replace("'", "\\'").replace("%", "\\%"))
    vf = (f"drawtext=text='{safe}':fontsize={font_size}:fontcolor={color}:"
          f"borderw=3:bordercolor=black:x=(w-text_w)/2:y=h-text_h-140")
    r = run_ff(["-i", src, "-vf", vf,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-c:a", "copy", "-movflags", "+faststart", str(out)])
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


def change_speed(src: str, speed: float, name: str = "") -> dict:
    """变速（0.5–2.0）。"""
    out = out_dir() / (name or f"spd_{uuid.uuid4().hex[:8]}.mp4")
    speed = max(0.5, min(2.0, speed))
    vf = f"setpts={1 / speed:.4f}*PTS"
    af = f"atempo={speed:.3f}"
    r = run_ff(["-i", src, "-filter_complex", f"[0:v]{vf}[v];[0:a]{af}[a]",
                "-map", "[v]", "-map", "[a]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-c:a", "aac", "-movflags", "+faststart", str(out)])
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


def normalize_audio(src: str, lufs: float = -14.0, name: str = "") -> dict:
    """响度归一（两遍 loudnorm）。"""
    out = out_dir() / (name or f"norm_{uuid.uuid4().hex[:8]}.mp4")
    r = run_ff(["-i", src, "-af",
                f"loudnorm=I={lufs}:TP=-1.5:LRA=11",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart", str(out)])
    return {"ok": r["ok"], "path": str(out) if r["ok"] else None,
            "error": r.get("error") or (r.get("stderr") or "")[:300]}


# ---------------- 组合流程 ----------------
async def make_video(job_id: str, src: str, plan: dict) -> None:
    """一键出片：按 plan 顺序执行多个步骤。

    注意：steps 里的 name 只是**显示名**，不当作输出文件名
    （否则多步会互相覆盖）。输出文件名统一自动生成。
    """
    steps_def = plan.get("steps") or []
    if not steps_def:
        db.exec("UPDATE jobs SET status='failed',error='没有步骤',ended_at=? WHERE id=?",
                (now_iso(), job_id))
        return

    steps = [{"name": s.get("name") or s.get("op"), "state": "wait", "note": ""}
             for s in steps_def]
    db.exec("UPDATE jobs SET status='running',steps=?,started_at=? WHERE id=?",
            (json.dumps(steps, ensure_ascii=False), now_iso(), job_id))

    cur = src
    results = []
    tag = uuid.uuid4().hex[:6]
    try:
        for i, s in enumerate(steps_def):
            op = s.get("op")
            steps[i]["state"] = "run"
            db.exec("UPDATE jobs SET steps=? WHERE id=?",
                    (json.dumps(steps, ensure_ascii=False), job_id))

            # 输出名统一生成，避免多步覆盖
            outname = f"mk_{tag}_{i}_{op}.mp4"

            if op == "clip":
                r = clip(cur, float(s.get("start") or 0),
                         float(s.get("end") or 0), outname)
            elif op == "vertical":
                r = to_vertical(cur, outname, s.get("ratio") or "9:16")
            elif op == "speed":
                r = change_speed(cur, float(s.get("speed") or 1.0), outname)
            elif op == "subtitle":
                r = burn_subs(cur, s.get("text") or "", outname,
                              int(s.get("fontSize") or 42),
                              s.get("color") or "white")
            elif op == "normalize":
                r = normalize_audio(cur, float(s.get("lufs") or -14), outname)
            elif op == "concat":
                paths = s.get("paths") or []
                r = concat([cur] + paths, outname)
            else:
                r = {"ok": False, "error": f"未知操作 {op}"}

            if r.get("ok") and r.get("path"):
                cur = r["path"]
                steps[i]["state"] = "done"
                steps[i]["note"] = Path(cur).name
                results.append({"op": op, "path": cur})
            else:
                steps[i]["state"] = "err"
                msg = (r.get("error") or r.get("stderr") or "失败")
                steps[i]["note"] = str(msg)[:160]
                db.exec("UPDATE jobs SET steps=?,status='failed',error=?,ended_at=?"
                        " WHERE id=?",
                        (json.dumps(steps, ensure_ascii=False),
                         steps[i]["note"], now_iso(), job_id))
                return

            db.exec("UPDATE jobs SET steps=?,progress=? WHERE id=?",
                    (json.dumps(steps, ensure_ascii=False),
                     int((i + 1) / len(steps_def) * 100), job_id))

        info = probe(cur)
        db.exec("UPDATE jobs SET status='done',result=?,ended_at=? WHERE id=?",
                (json.dumps({"output": cur, "info": info, "steps": results},
                            ensure_ascii=False), now_iso(), job_id))
        db.log_event("ok", "video", f"出片完成：{Path(cur).name} ({info.get('dur')}s)")
    except Exception as e:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "video", str(e)[:200])
