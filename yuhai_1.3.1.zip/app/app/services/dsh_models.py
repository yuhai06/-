"""DSH 模型注入：把本机 DSH 登录的模型接入工作台。

数据来源（都是本机真实文件，不外接）：
    $DSH_HOME/our-free-model/catalog.json   免费模型清单
    $DSH_HOME/profiles/<profile>/node_modules/dsh-*/   插件
    $DSH_HOME/skills/                       技能

注入后：
    · AI 分析/标题生成可以选具体模型
    · 界面能打开插件自己的页面（如果插件带了 web UI）
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from app.db import db, now_iso

log = logging.getLogger("yuhai.dsh")

DSH_HOME = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
PROFILE = os.environ.get("DSH_PROFILE", "desktop")


def catalog_path() -> Path:
    return DSH_HOME / "our-free-model" / "catalog.json"


def load_catalog() -> dict:
    p = catalog_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("catalog read failed: %s", e)
        return {}


# 渠道分类（实测 2026-11-07，网关 8326 共 19 个渠道 129 个模型）
#
# 用户要求：只要**账号接入**的模型（自己登录的账号池）
#          不要插件自带的免费池、不要 EAC 渠道
#
# our-free-model / our-free-model-region 是插件匿名免费通道 → 排除
# eac / magpie 系是付费转售通道 → 排除
EXCLUDE_CHANNELS = {
    "our-free-model",
    "our-free-model-region",
    "eac",
    "magpie",
    "magpie-responses",
}

# 账号接入渠道（用户自己的登录账号）
ACCOUNT_CHANNELS = {
    "workbuddy": "WorkBuddy 国内",
    "workbuddy-global": "WorkBuddy 国际",
    "codearts": "CodeArts",
    "raccoon": "Raccoon",
    "trae": "TRAE",
    "loomy": "Loomy",
    "qoder": "Qoder",
    "qodercn": "Qoder 国内",
    "buddy": "Buddy",
    "cline": "Cline",
    "opencodez": "OpenCodeZ",
    "deepseek-official": "DeepSeek 官方",
    "deepseek-account": "DeepSeek 账号",
    "minimax": "MiniMax",
    "muse": "Muse",
    "kilo": "Kilo",
    "zhipu": "智谱",
    "glm": "GLM",
}


def _channel_of(m: dict) -> str:
    return (m.get("owned_by") or
            (m.get("id") or "").split("/")[0] or "other")


def gateway_info() -> dict:
    """探测本机 DSH 的 OpenAI 兼容网关。

    实测结论（2026-11-07）：
        · DSH 进程监听 8326 端口，是 OpenAI 兼容网关
        · API key 在 $DSH_HOME/openai-gateway/api-key
        · /v1/models 返回 129 个模型，19 个渠道
    """
    key_file = DSH_HOME / "openai-gateway" / "api-key"
    key = ""
    if key_file.exists():
        try:
            key = key_file.read_text(encoding="utf-8").strip()
        except Exception:
            pass

    for port in (8326, 8325, 8327):
        base = f"http://127.0.0.1:{port}"
        try:
            import httpx
            r = httpx.get(f"{base}/v1/models",
                          headers={"Authorization": f"Bearer {key}"} if key else {},
                          timeout=4)
            if r.status_code == 200:
                data = r.json().get("data") or []
                return {"ok": True, "base": base, "key": key,
                        "models": data, "count": len(data), "port": port}
        except Exception:
            continue
    return {"ok": False, "base": "", "key": key, "models": [], "count": 0,
            "error": "DSH 网关未启动（8326 不通）"}


def free_models() -> list[dict]:
    """返回**账号接入**的模型（排除插件免费池和 EAC）。

    每条带 channel / channelLabel / free / vision / desc，
    前端按渠道分组展示，用户可以人工接上自己的账号模型。
    """
    gw = gateway_info()
    if not gw["ok"]:
        return _catalog_fallback()

    out = []
    for m in gw["models"]:
        mid = m.get("id") or ""
        if not mid:
            continue
        ch = _channel_of(m)
        if ch in EXCLUDE_CHANNELS:
            continue          # 插件自带免费池 / EAC，按要求排除
        name = m.get("name") or mid
        is_free = ("free" in mid.lower() or "x0.00" in name
                   or "免费" in name or "FREE" in name)
        out.append({
            "id": mid,
            "name": name,
            "channel": ch,
            "channelLabel": ACCOUNT_CHANNELS.get(ch, ch),
            "vision": "image" in str(m.get("input") or ""),
            "desc": (m.get("description") or "")[:120],
            "free": is_free,
            "source": "account",
        })
    # 账号渠道排前面，免费的排更前
    out.sort(key=lambda x: (x["channel"] not in ACCOUNT_CHANNELS,
                            not x["free"], x["channel"], x["id"]))
    return out


def _catalog_fallback() -> list[dict]:
    """网关不通时读 catalog 文件（也只能给个大概）。"""
    cat = load_catalog()
    out, seen = [], set()
    for mid in (cat.get("entries") or []) + (cat.get("sealIds") or []):
        if not mid or mid in seen:
            continue
        seen.add(mid)
        ch = mid.split("/")[0] if "/" in mid else "other"
        if ch in EXCLUDE_CHANNELS:
            continue
        out.append({"id": mid, "name": mid.split("/")[-1], "channel": ch,
                    "channelLabel": ACCOUNT_CHANNELS.get(ch, ch),
                    "vision": "vl" in mid.lower(), "desc": "",
                    "free": "free" in mid.lower(), "source": "catalog"})
    return out


def channels() -> list[dict]:
    """按渠道分组，给前端做分组下拉。"""
    ms = free_models()
    groups: dict[str, dict] = {}
    for m in ms:
        ch = m["channel"]
        g = groups.setdefault(ch, {
            "channel": ch,
            "label": m["channelLabel"],
            "models": [],
            "freeCount": 0,
            "isAccount": ch in ACCOUNT_CHANNELS,
        })
        g["models"].append(m)
        if m["free"]:
            g["freeCount"] += 1
    out = list(groups.values())
    out.sort(key=lambda g: (not g["isAccount"], -g["freeCount"], g["channel"]))
    return out


def dsh_available() -> dict:
    """DSH 是否可用 + 有哪些模型/插件/技能。"""
    cat = load_catalog()
    models = free_models()
    chs = channels()
    plugins_dir = DSH_HOME / "profiles" / PROFILE / "node_modules"
    plugins = []
    if plugins_dir.exists():
        for d in plugins_dir.iterdir():
            if not d.is_dir() or not d.name.startswith("dsh-"):
                continue
            ver = ""
            pj = d / "package.json"
            if pj.exists():
                try:
                    ver = json.loads(pj.read_text(encoding="utf-8")).get("version") or ""
                except Exception:
                    pass
            has_ui = any((d / x).exists() for x in
                         ("web", "ui", "dist/web", "public", "panel"))
            plugins.append({"name": d.name, "version": ver, "hasUi": has_ui})

    skills_dir = DSH_HOME / "skills"
    skills = []
    if skills_dir.exists():
        for d in skills_dir.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                skills.append(d.name)

    return {
        "dshHome": str(DSH_HOME),
        "profile": PROFILE,
        "hasCatalog": catalog_path().exists(),
        "catalogAt": cat.get("at"),
        "models": models,
        "modelCount": len(models),
        "channels": chs,
        "channelCount": len(chs),
        "excludedChannels": sorted(EXCLUDE_CHANNELS),
        "plugins": plugins,
        "pluginCount": len(plugins),
        "skills": skills,
        "skillCount": len(skills),
    }


def save_selection(model_id: str) -> dict:
    """保存用户选的默认模型。"""
    db.exec("INSERT INTO kv(k,v) VALUES('llm_model',?)"
            " ON CONFLICT(k) DO UPDATE SET v=excluded.v", (model_id,))
    return {"ok": True, "model": model_id}


def get_selection() -> str:
    r = db.q1("SELECT v FROM kv WHERE k='llm_model'")
    if r and r["v"]:
        return r["v"]
    return default_model()


def resolve_endpoint() -> dict:
    """解析调用模型的端点。

    优先级：
        ① 用户手填的 YUHAI_LLM_BASE（覆盖一切）
        ② DSH 网关（8326，自动探测 + 自动读 api-key）
        ③ 没有 → 返回未就绪，上层走规则兜底
    """
    base = os.environ.get("YUHAI_LLM_BASE") or ""
    key = os.environ.get("YUHAI_LLM_KEY") or ""

    if not base:
        # 读工作台配置
        try:
            from app.config import settings
            cfgp = settings.data_dir / "config.json"
            if cfgp.exists():
                cfg = json.loads(cfgp.read_text(encoding="utf-8"))
                base = cfg.get("llmBase") or ""
                key = key or cfg.get("llmKey") or ""
        except Exception:
            pass

    if base:
        return {"base": base, "key": key, "model": get_selection(),
                "ready": True, "source": "manual", "note": "已配置端点"}

    # 自动用 DSH 网关
    gw = gateway_info()
    if gw["ok"]:
        return {"base": gw["base"] + "/v1", "key": gw["key"],
                "model": get_selection(), "ready": True, "source": "dsh-gateway",
                "note": f"DSH 网关 {gw['base']}（{gw['count']} 个模型）"}

    return {"base": "", "key": "", "model": get_selection(), "ready": False,
            "source": "none",
            "note": "DSH 网关未启动（8326 不通），AI 分析走规则统计兜底"}


def default_model() -> str:
    """选一个账号接入且实测可用的默认模型。

    实测 workbuddy/hy4free 可用；opencodez/* 返回 502。
    只从账号渠道里挑（排除插件免费池和 EAC）。
    """
    gw = gateway_info()
    if not gw["ok"]:
        ms = _catalog_fallback()
        return ms[0]["id"] if ms else ""

    ids = []
    for m in gw["models"]:
        mid = m.get("id") or ""
        if not mid:
            continue
        if _channel_of(m) in EXCLUDE_CHANNELS:
            continue
        ids.append(mid)

    for pref in ("workbuddy/hy4free", "workbuddy-global/hy4free",
                 "workbuddy/", "buddy/hy4free", "raccoon/", "loomy/",
                 "qoder/", "codearts/"):
        for mid in ids:
            if mid.startswith(pref):
                return mid
    for mid in ids:
        if "free" in mid.lower():
            return mid
    return ids[0] if ids else ""
