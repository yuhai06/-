"""ReelsPublisher 内核对接——通过 Node worker 的 IPC 批量发布。

为什么用这个：
    自研 CDP 直接发 Reels 不稳（reels_composer 页面会让浏览器内核卡死，
    且上传 input 是动态创建的，直接 querySelector 找不到）。
    ReelsPublisher v19.7 已经有成熟的批量发布链路：
        playwright-core 连接 Hubstudio CDP →
        skill-runtime 的 publisher 完成「打开 composer → 塞视频 →
        填标题 → 点发布 → 提取回执 → 清理素材」
    我们直接复用它的 worker IPC。

通信方式：
    worker.mjs 必须由父进程 fork，且 process.send 存在。
    命令：status / checkBrowsers / start / discoverPages / shutdown
    资源：REELS_PUBLISHER_DATA_DIR（state.json 与历史记录）
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso

log = logging.getLogger("yuhai.reels")

# ---------- 路径 ----------
def reels_root() -> Path:
    """ReelsPublisher 安装根目录。"""
    env = os.environ.get("YUHAI_REELS_ROOT", "").strip()
    if env:
        return Path(env)
    # 从 reels_env_dir（.../resources/worker/src）上溯三级
    p = Path(settings.reels_env_dir)
    for _ in range(3):
        p = p.parent
    return p


def worker_entry() -> Path:
    return Path(settings.reels_env_dir) / "worker.mjs"


def data_dir() -> Path:
    """worker 的 state/history 目录。"""
    env = os.environ.get("YUHAI_REELS_DATA", "").strip()
    if env:
        d = Path(env)
    else:
        d = reels_root() / "resources" / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def node_cmd() -> list[str]:
    """拿一个可用的 node 命令前缀。"""
    n = shutil.which("node")
    if n:
        return [n]
    # 用 Electron 二进制当 node
    exe = Path(os.environ.get("YUHAI_ELECTRON_NODE",
                              r"E:\ReelsPublisher-v19.7-Portable\Reels Publisher.exe"))
    if exe.exists():
        return [str(exe)]
    return ["node"]


def available() -> dict:
    """内核可用性检查。"""
    w = worker_entry()
    d = data_dir()
    node = node_cmd()
    st = d / "state.json"
    plan = {}
    disc = {}
    if st.exists():
        try:
            s = json.loads(st.read_text(encoding="utf-8"))
            plan = s.get("plan") or {}
            disc = s.get("discovery") or {}
        except Exception:
            pass
    return {
        "ok": w.exists() and len(node) > 0,
        "worker": str(w),
        "workerExists": w.exists(),
        "dataDir": str(d),
        "node": node[0] if node else "",
        "planPages": len((plan.get("assignments") or [])),
        "discoveredPages": len((disc.get("pages") or [])),
        "hasState": st.exists(),
        "version": "v19.7",
    }


# ---------- 单次调用（不常驻） ----------
async def call_worker(commands: list[dict], timeout_s: float = 180,
                      on_progress=None) -> dict:
    """一次性启动 worker，按顺序执行 commands，返回最后一次结果。

    commands: [{"id":"c1","command":"status","payload":{}}, ...]
    最后会自动 shutdown。
    """
    w = worker_entry()
    if not w.exists():
        return {"ok": False, "error": f"worker 不存在: {w}"}

    d = data_dir()
    nc = node_cmd()

    # 写一个临时驱动脚本，避免复杂 IPC 编码问题
    drv = d / f"_drv_{uuid.uuid4().hex[:8]}.mjs"
    drv.write_text(_driver_js(str(w), str(d), commands), encoding="utf-8")

    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NO_WINDOW
    proc = subprocess.Popen(nc + [str(drv)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, **kw)
    out_lines: list[str] = []
    try:
        for raw in proc.stdout:  # type: ignore
            line = raw.decode("utf-8", "replace").rstrip()
            out_lines.append(line)
            if on_progress and line.startswith("[progress]"):
                try:
                    on_progress(line[10:].strip())
                except Exception:
                    pass
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"ok": False, "error": "worker 超时", "log": out_lines[-30:]}
    finally:
        try:
            drv.unlink()
        except Exception:
            pass

    # 解析最后一行 JSON
    result = {}
    for line in reversed(out_lines):
        if line.startswith("[result]"):
            try:
                result = json.loads(line[8:].strip())
                break
            except Exception:
                pass
    return {"ok": True, "result": result, "log": out_lines[-40:]}


def _driver_js(worker: str, data: str, commands: list[dict]) -> str:
    """生成驱动脚本（fork worker，顺跑命令，输出 [result] JSON）。"""
    return f"""
import {{ fork }} from 'node:child_process';
const WORKER = {json.dumps(worker)};
const DATA = {json.dumps(data)};
const CMDS = {json.dumps(commands, ensure_ascii=False)};

let seq = 0;
const pending = new Map();
const child = fork(WORKER, [], {{
  env: {{ ...process.env,
    REELS_PUBLISHER_DATA_DIR: DATA,
    REELS_PUBLISHER_OUTPUT_DIR: DATA }},
  stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
}});

function call(command, payload, timeoutMs) {{
  return new Promise((resolve, reject) => {{
    const id = 'r' + (++seq);
    pending.set(id, {{ resolve, reject }});
    child.send({{ id, command, payload: payload || {{}} }});
    setTimeout(() => {{
      if (pending.has(id)) {{ pending.delete(id); reject(new Error('timeout:' + command)); }}
    }}, timeoutMs || 180000);
  }});
}}

child.on('message', (m) => {{
  if (m.type === 'ready') {{ run(); return; }}
  if (m.type === 'progress') {{
    const e = m.event || {{}};
    if (e.stage) console.log('[progress] ' + e.stage);
    return;
  }}
  if (m.id && pending.has(m.id)) {{
    const {{ resolve, reject }} = pending.get(m.id);
    pending.delete(m.id);
    if (m.ok) resolve(m.value);
    else reject(new Error((m.error?.code || 'ERR') + ': ' + (m.error?.message || '')));
  }}
}});
child.stderr?.on('data', (d) => {{
  const s = d.toString().trim();
  if (s) console.log('[err] ' + s.slice(0, 300));
}});

async function run() {{
  let last = null;
  try {{
    for (const c of CMDS) {{
      last = await call(c.command, c.payload, c.timeout || 180000);
    }}
  }} catch (e) {{
    console.log('[result] ' + JSON.stringify({{ ok: false, error: e.message }}));
  }}
  console.log('[result] ' + JSON.stringify({{ ok: true, value: last }}));
  try {{ await call('shutdown', {{}}, 20000); }} catch {{}}
  child.kill();
  setTimeout(() => process.exit(0), 500);
}}
setTimeout(() => {{ console.log('[result] ' + JSON.stringify({{ ok: false, error: 'global timeout' }})); child.kill(); process.exit(1); }}, 3600000);
"""


# ---------- 高层操作 ----------
async def status() -> dict:
    r = await call_worker([{"command": "status", "payload": {}, "timeout": 60000}],
                          timeout_s=90)
    if not r.get("ok"):
        return r
    return {"ok": True, **(r.get("result") or {})}


async def check_browsers() -> dict:
    r = await call_worker(
        [{"command": "checkBrowsers", "payload": {}, "timeout": 120000}],
        timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{browserCheck:{...}}}
    if "value" in v and isinstance(v.get("value"), dict):
        v = v["value"]
    bc = (v.get("browserCheck") or {})
    return {"ok": True, "results": bc.get("results") or [],
            "environments": bc.get("environments") or []}


async def scan_materials(directory: str) -> dict:
    r = await call_worker(
        [{"command": "scanMaterials",
          "payload": {"directory": directory, "directories": [directory]},
          "timeout": 120000}], timeout_s=150)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    # worker 返回 {ok:true, value:{groups,total,folderCount,sampleTitle}}
    if "value" in v and isinstance(v.get("value"), dict):
        return {"ok": True, **(v["value"])}
    return {"ok": True, **v}


async def publish(directory: str, description: str, link_pool: str,
                  clips_per_page: int = 1, concurrency: int = 1,
                  publish_mode: str = "merge",
                  browser_ids: list[str] | None = None,
                  timeout_s: float = 3600, on_progress=None) -> dict:
    """批量发布。description 是标题模板，link_pool 是链接池（每行一个）。"""
    cmds = []
    if browser_ids:
        cmds.append({"command": "checkBrowsers", "payload": {}, "timeout": 120000})
    cmds.append({
        "command": "start",
        "payload": {
            "directory": directory,
            "directories": [directory],
            "publishMode": publish_mode,
            "clipsPerPage": clips_per_page,
            "concurrency": concurrency,
            "browserIds": browser_ids or [],
            "description": description,
            "linkPool": link_pool,
        },
        "timeout": int(timeout_s * 1000),
    })
    r = await call_worker(cmds, timeout_s=timeout_s + 120, on_progress=on_progress)
    if not r.get("ok"):
        return r
    v = r.get("result") or {}
    if "value" in v and isinstance(v.get("value"), dict):
        return {"ok": True, **(v["value"])}
    return {"ok": True, **v}


def state_snapshot() -> dict:
    """读 state.json 里的计划/发现数据（不启动 worker，快）。"""
    st = data_dir() / "state.json"
    if not st.exists():
        return {}
    try:
        return json.loads(st.read_text(encoding="utf-8"))
    except Exception:
        return {}


def plan_pages() -> list[dict]:
    """当前 plan 里的主页清单。"""
    s = state_snapshot()
    out = []
    for a in (s.get("plan") or {}).get("assignments") or []:
        out.append({
            "pageId": a.get("pageId"),
            "pageName": a.get("pageName"),
            "profileId": a.get("profileId"),
            "environmentId": a.get("environmentId"),
        })
    return out
