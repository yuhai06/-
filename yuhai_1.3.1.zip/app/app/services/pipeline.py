"""视频处理管线：把 tools/ 下实测过的流程接进来。

流程（来自实战 SOP，顺序不可调换）：
    ① 台词转录 whisper       → 逐句时间戳
    ② 语音检测              → 过滤无声段
    ③ 类型判定              → 强弱关键词加权（7 类）
    ④ 张力打分              → 每句一个张力分
    ⑤ 剪辑出片              → 单集线 / 精品混剪线

两条线标准不同，分开执行：
    单集：单集内，40–55s，段边界对齐台词边界
    混剪：跨全剧，120–150s，强制 5 阶段结构

硬约束（违反必返工）：
    · 台词完整不截断：冲突时丢低分段，不砍台词
    · 段间零重叠
    · pad 0.15s
    · 单段 > target×1.4 拆单句
    · 一部剧成片做完立即删原始素材
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from app.config import settings
from app.db import db, now_iso
from app import paths as _paths
from app import proc

log = logging.getLogger("yuhai.pipeline")

# tools 目录（统一解析，换机器自动发现）
TOOLS_DIR = _paths.tools_dir()
# 中间状态目录
STATE_DIR = _paths.state_dir()


STEPS = [
    {"key": "transcribe", "name": "台词转录 whisper", "script": "transcribe_audio.py"},
    {"key": "voice", "name": "语音检测", "script": "voice_check3.py"},
    {"key": "classify", "name": "类型判定", "script": "classify.py"},
    {"key": "score", "name": "张力打分", "script": "score_lines2.py"},
    {"key": "render", "name": "剪辑出片", "script": "cut_ep2.py / render_plan.py"},
]


def tools_ready() -> dict:
    """检查 tools 目录与依赖脚本是否齐备。"""
    return {
        "toolsDir": str(TOOLS_DIR),
        "exists": TOOLS_DIR.exists(),
        "scripts": {s["script"]: (TOOLS_DIR / s["script"].split(" / ")[0]).exists()
                    for s in STEPS},
        "stateDir": str(STATE_DIR),
        "stateExists": STATE_DIR.exists(),
    }


def _run_script(script: str, args: list[str], timeout: int = 7200) -> dict:
    """跑一个 tools 脚本，返回 {ok, code, stdout, stderr, cmd}。"""
    first = script.split(" / ")[0].strip()
    path = TOOLS_DIR / first
    if not path.exists():
        return {"ok": False, "code": -1, "error": f"脚本不存在: {path}",
                "stdout": "", "stderr": ""}
    cmd = [sys.executable, "-u", str(path), *args]
    try:
        r = proc.run(cmd, capture_output=True, text=True, timeout=timeout,
                           cwd=str(TOOLS_DIR), encoding="utf-8", errors="replace",
                           env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        return {"ok": r.returncode == 0, "code": r.returncode,
                "stdout": (r.stdout or "")[-4000:], "stderr": (r.stderr or "")[-2000:],
                "cmd": " ".join(cmd)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "code": -2, "error": "超时", "stdout": "", "stderr": "",
                "cmd": " ".join(cmd)}
    except Exception as e:
        return {"ok": False, "code": -3, "error": str(e)[:200], "stdout": "",
                "stderr": "", "cmd": " ".join(cmd)}


def _step_update(job_id: str, idx: int, state: str, note: str = "",
                 progress: int = -1) -> None:
    row = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
    if not row:
        return
    try:
        steps = json.loads(row["steps"] or "[]")
    except Exception:
        steps = []
    if idx < len(steps):
        steps[idx]["state"] = state
        if note:
            steps[idx]["note"] = note[:200]
    patch: dict[str, Any] = {"steps": json.dumps(steps, ensure_ascii=False)}
    if progress >= 0:
        patch["progress"] = progress
    sets = ",".join(f"{k}=?" for k in patch)
    db.exec(f"UPDATE jobs SET {sets} WHERE id=?", (*patch.values(), job_id))


def classify_drama_by_name(name: str) -> str:
    """剧名关键词初判（SOP 的 7 类，强特征 ×3 弱 ×1）。"""
    TYPES = {
        "punch": ["billionaire", "heir", "ceo", "humiliate", "kneel", "beg"],
        "ethics": ["divorce", "affair", "mistress", "husband", "custody"],
        "backer": ["bodyguard", "protect", "save", "scared", "beat", "threaten"],
        "mystery": ["secret", "truth", "hidden", "what happened", "evidence"],
        "tension": ["kiss", "touch", "closer", "breathe", "flirt", "sweetheart"],
        "sweet": ["love you", "crush", "blush", "heartbeat", "confess"],
        "rebirth": ["second chance", "rebirth", "reborn", "past life", "i died"],
    }
    low = (name or "").lower()
    best, score = "", 0
    for k, words in TYPES.items():
        s = sum(3 for w in words if w in low)
        if s > score:
            best, score = k, s
    return best


async def run_pipeline(job_id: str, drama: str, source_dir: str,
                       single: bool = True, premium: bool = True,
                       episodes: list[str] | None = None,
                       target_sec: int = 45) -> None:
    """执行处理管线。全程写 job.steps，前端可轮询。"""
    drama = drama.strip()
    if not drama:
        db.exec("UPDATE jobs SET status='failed',error='剧名不能为空',ended_at=? WHERE id=?",
                (now_iso(), job_id))
        return

    ready = tools_ready()
    if not ready["exists"]:
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (f"tools 目录不存在: {TOOLS_DIR}", now_iso(), job_id))
        db.log_event("err", "pipeline", f"tools 目录不存在: {TOOLS_DIR}")
        return

    db.exec("UPDATE jobs SET status='running',started_at=? WHERE id=?",
            (now_iso(), job_id))

    try:
        # ---- ① 台词转录 ----
        _step_update(job_id, 0, "run")
        r = _run_script("transcribe_audio.py", ["--drama", drama, "--model", "medium"])
        _step_update(job_id, 0, "done" if r["ok"] else "err",
                     f"exit {r['code']}" if not r["ok"] else "转录完成", 20)
        db.log_event("ok" if r["ok"] else "warn", "pipeline",
                     f"{drama} 转录 {'完成' if r['ok'] else '失败: ' + str(r.get('error') or r.get('stderr'))[:100]}")
        if not r["ok"]:
            # 转录失败无法继续
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (f"转录失败: {(r.get('error') or r['stderr'])[:300]}", now_iso(), job_id))
            return

        # ---- ② 语音检测 ----
        _step_update(job_id, 1, "run")
        r = _run_script("voice_check3.py", ["--drama", drama])
        _step_update(job_id, 1, "done" if r["ok"] else "warn",
                     "完成" if r["ok"] else "部分失败（继续）", 40)

        # ---- ③ 类型判定 ----
        _step_update(job_id, 2, "run")
        r = _run_script("classify.py", ["--drama", drama])
        dtype = classify_drama_by_name(drama)
        _step_update(job_id, 2, "done" if r["ok"] else "warn",
                     dtype or ("完成" if r["ok"] else "失败"), 55)

        # ---- ④ 张力打分 ----
        _step_update(job_id, 3, "run")
        r = _run_script("score_lines2.py",
                        ["--drama", drama, "--thresh", "1.0", "--max-gap", "1.5"])
        _step_update(job_id, 3, "done" if r["ok"] else "err",
                     "完成" if r["ok"] else f"exit {r['code']}", 70)
        if not r["ok"]:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (f"打分失败: {(r.get('error') or r['stderr'])[:300]}", now_iso(), job_id))
            return

        # ---- ⑤ 剪辑出片 ----
        _step_update(job_id, 4, "run")
        made: list[str] = []
        # 单集线
        if single:
            eps = episodes or []
            if not eps:
                # 从 state 里找该剧的集号
                sf = STATE_DIR / "subs" / f"{drama}_transcript.json"
                if sf.exists():
                    try:
                        data = json.loads(sf.read_text(encoding="utf-8"))
                        eps = sorted({f"EP{int(e):02d}" for e in
                                      (data.get("episodes") or {}).keys()})[:6]
                    except Exception:
                        eps = []
            for ep in eps[:10]:
                rr = _run_script("cut_ep2.py",
                                 ["--drama", drama, "--ep", ep,
                                  "--target", str(target_sec)])
                if rr["ok"]:
                    made.append(f"{drama}_{ep}")
                await asyncio.sleep(0.3)
        # 精品混剪线
        if premium:
            rr = _run_script("plan_from_tension.py", ["--drama", drama])
            if rr["ok"]:
                plan = STATE_DIR / "plans" / f"{drama}_premium_plan.json"
                if plan.exists():
                    out = settings.library_root / "待发布" / now_iso()[:10] / drama
                    out.mkdir(parents=True, exist_ok=True)
                    rr2 = _run_script(
                        "render_plan.py",
                        [str(plan), "--out", str(out / f"{drama}_主线版.mp4"),
                         "--no-stage-label"])
                    if rr2["ok"]:
                        made.append(f"{drama}_主线版")

        _step_update(job_id, 4, "done" if made else "warn",
                     f"出片 {len(made)} 条" if made else "未出片", 100)

        db.exec("UPDATE jobs SET status=?,result=?,ended_at=? WHERE id=?",
                ("done" if made else "blocked",
                 json.dumps({"drama": drama, "made": made, "dramaType": dtype,
                             "single": single, "premium": premium},
                            ensure_ascii=False),
                 now_iso(), job_id))
        db.log_event("ok" if made else "warn", "pipeline",
                     f"{drama} 处理完成，出片 {len(made)} 条")
    except Exception as e:
        log.exception("pipeline failed")
        db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                (str(e)[:400], now_iso(), job_id))
        db.log_event("err", "pipeline", str(e)[:200])
