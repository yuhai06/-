"""抓取去重台账——记录「已经抓过哪些剧/哪些集」。

为什么要单独一张表而不是只扫文件夹：
    · 用户可能删掉抓下来的素材，但那些剧**已经抓过**，不该再重复抓
    · 同一部剧可能只抓了前 10 集，下次要能只补第 11 集往后
    · 需要按剧型/时间查询「哪些类型已经抓够了」

表结构（grab_records）：
    cid         剧 ID（唯一键）
    title       剧名
    drama_type  内部 7 型
    type_zh     中文剧型名
    tags        中文标签（JSON 数组）
    episodes    已抓到的集号（JSON 数组，如 [1,2,3,...,10]）
    total_eps   上游总集数
    dir         落盘目录
    grabbed_at  最后抓取时间
    attempts    抓取次数

去重策略（可配）：
    dedupeCids   true  同一 cid 不再抓（默认）
                 false 允许重抓（用于补集）
    skipExisting true  同 cid 已抓过的集不重下（断点续传，默认 true）
"""
from __future__ import annotations

import json
import logging
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.grab.records")

TABLE_SQL = """
CREATE TABLE IF NOT EXISTS grab_records (
    cid         TEXT PRIMARY KEY,
    title       TEXT,
    drama_type  TEXT,
    type_zh     TEXT,
    tags        TEXT,
    episodes    TEXT,
    total_eps   INTEGER DEFAULT 0,
    dir         TEXT,
    grabbed_at  TEXT,
    attempts    INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_grab_type ON grab_records(drama_type);
CREATE INDEX IF NOT EXISTS ix_grab_at   ON grab_records(grabbed_at);
"""


def ensure_table() -> None:
    for stmt in TABLE_SQL.strip().split(";"):
        s = stmt.strip()
        if s:
            db.exec(s)


def _load_eps(raw: Any) -> list[int]:
    if isinstance(raw, list):
        return [int(x) for x in raw if str(x).isdigit()]
    if isinstance(raw, str) and raw:
        try:
            v = json.loads(raw)
            return [int(x) for x in v if str(x).isdigit()]
        except Exception:
            return []
    return []


def get(cid: str) -> dict | None:
    ensure_table()
    r = db.q1("SELECT * FROM grab_records WHERE cid=?", (str(cid),))
    if not r:
        return None
    out = dict(r)
    out["episodes"] = _load_eps(out.get("episodes"))
    try:
        out["tags"] = json.loads(out.get("tags") or "[]")
    except Exception:
        out["tags"] = []
    return out


def all_records() -> dict[str, dict]:
    """cid → 记录（一次性取全，避免循环查库）。"""
    ensure_table()
    out: dict[str, dict] = {}
    for r in db.q("SELECT * FROM grab_records"):
        d = dict(r)
        d["episodes"] = _load_eps(d.get("episodes"))
        try:
            d["tags"] = json.loads(d.get("tags") or "[]")
        except Exception:
            d["tags"] = []
        out[str(d["cid"])] = d
    return out


def upsert(cid: str, *, title: str = "", drama_type: str = "",
           type_zh: str = "", tags: list[str] | None = None,
           episodes: list[int] | None = None, total_eps: int = 0,
           dir: str = "") -> dict:
    """写入/更新一条记录。

    episodes 是**累加合并**的（不是覆盖），这样补集不会丢掉老记录。
    """
    ensure_table()
    cid = str(cid)
    cur = get(cid)
    old_eps = cur["episodes"] if cur else []
    eps = sorted(set(list(old_eps) + list(episodes or [])))
    attempts = (cur["attempts"] + 1) if cur else 1

    row = {
        "cid": cid,
        "title": title or (cur["title"] if cur else ""),
        "drama_type": drama_type or (cur["drama_type"] if cur else ""),
        "type_zh": type_zh or (cur["type_zh"] if cur else ""),
        "tags": json.dumps(tags if tags is not None
                           else (cur["tags"] if cur else []), ensure_ascii=False),
        "episodes": json.dumps(eps),
        "total_eps": int(total_eps or (cur["total_eps"] if cur else 0)),
        "dir": dir or (cur["dir"] if cur else ""),
        "grabbed_at": now_iso(),
        "attempts": attempts,
    }
    db.exec(
        "INSERT INTO grab_records(cid,title,drama_type,type_zh,tags,episodes,"
        "total_eps,dir,grabbed_at,attempts) VALUES(?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(cid) DO UPDATE SET title=excluded.title,"
        "drama_type=excluded.drama_type,type_zh=excluded.type_zh,"
        "tags=excluded.tags,episodes=excluded.episodes,"
        "total_eps=excluded.total_eps,dir=excluded.dir,"
        "grabbed_at=excluded.grabbed_at,attempts=excluded.attempts",
        (row["cid"], row["title"], row["drama_type"], row["type_zh"],
         row["tags"], row["episodes"], row["total_eps"], row["dir"],
         row["grabbed_at"], row["attempts"]))
    return row


def is_grabbed(cid: str) -> bool:
    return get(cid) is not None


def grabbed_eps(cid: str) -> list[int]:
    r = get(cid)
    return r["episodes"] if r else []


def filter_new(candidates: list[dict], dedupe: bool = True) -> tuple[list[dict], list[dict]]:
    """把候选分成 (没抓过的, 已抓过的)。

    dedupe=False 时全部当新的（重抓模式）。
    """
    if not dedupe:
        return candidates, []
    recs = all_records()
    fresh, seen = [], []
    for c in candidates:
        cid = str(c.get("cid") or "")
        if cid and cid in recs:
            seen.append({**c, "record": recs[cid]})
        else:
            fresh.append(c)
    return fresh, seen


def stats() -> dict:
    """台账概况（前端展示用）。"""
    ensure_table()
    rows = db.q("SELECT drama_type, type_zh, episodes, total_eps FROM grab_records")
    total = len(rows)
    eps_total = 0
    by_type: dict[str, int] = {}
    for r in rows:
        eps = _load_eps(r["episodes"])
        eps_total += len(eps)
        zh = r["type_zh"] or r["drama_type"] or "未分类"
        by_type[zh] = by_type.get(zh, 0) + 1
    return {"dramas": total, "episodes": eps_total,
            "byType": by_type,
            "types": sorted(by_type)}


def clear(cid: str = "") -> dict:
    """清台账（cid 为空则全清）——用于「强制重抓」。"""
    ensure_table()
    if cid:
        db.exec("DELETE FROM grab_records WHERE cid=?", (str(cid),))
        return {"ok": True, "cleared": str(cid)}
    db.exec("DELETE FROM grab_records")
    return {"ok": True, "cleared": "all"}
