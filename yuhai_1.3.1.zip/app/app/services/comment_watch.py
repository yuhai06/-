"""评论区常驻轮询：软件/电脑关了怎么办。

三个层次，从「软件开着」到「电脑关机」全覆盖：

    ① 软件运行时（本模块）
       后台 asyncio 任务，按设定间隔遍历主页 → 抓评论 → 分类 → 回复/删除。
       挂在 FastAPI lifespan 里，随服务启动。

    ② 软件关掉但电脑开着（Windows 计划任务）
       安装一个计划任务，每分钟检查后端是否在跑，没跑就拉起来。
       这样即使手动关了软件，轮询也会自己恢复。

    ③ 电脑关机
       两种方案（都可以，看用户选）：
       a) 开机自启：计划任务设成「计算机启动时」+「用户登录时」触发
       b) 常驻服务器：把后端部署到一台 7x24 的 Windows VPS，本地只连 API

本模块负责 ①，并提供 ②③ 的一键安装/卸载命令生成。
"""
from __future__ import annotations

import asyncio
import json
import logging
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from app.config import settings
from app.db import db, now_iso
from app import proc

log = logging.getLogger("yuhai.watch")


# ---------------- 配置 ----------------
DEFAULT_CFG = {
    "enabled": True,
    "intervalMin": 360,         # 每 6 小时轮一轮（用户指定）
    "pagesPerRound": 20,        # 一轮尽量覆盖更多主页（新增主页也能刷到）
    "allowReply": True,
    "allowDelete": True,
    "useRandomLink": True,      # 回复链接从池随机
    "quietHours": [2, 3, 4, 5, 6],   # 这些小时不动作（模拟人类睡觉）
    "catchUpOnBoot": True,      # 开机后补一轮（追上关机期间漏掉的）
    "catchUpPages": 30,         # 补漏时一次看更多
    "catchUpMaxHours": 72,      # 只补最近 72 小时内的
    "coverNewPages": True,      # 新增主页优先覆盖
    "lastRun": "",
    "lastResult": "",
    "lastBootGapMin": 0,
}


def load_cfg() -> dict:
    r = db.q1("SELECT v FROM kv WHERE k='comment_watch'")
    cfg = dict(DEFAULT_CFG)
    if r and r["v"]:
        try:
            cfg.update(json.loads(r["v"]))
        except Exception:
            pass
    return cfg


def save_cfg(patch: dict) -> dict:
    cfg = load_cfg()
    cfg.update({k: v for k, v in patch.items() if v is not None})
    db.exec("INSERT INTO kv(k,v) VALUES('comment_watch',?)"
            " ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            (json.dumps(cfg, ensure_ascii=False),))
    return cfg


def in_quiet_hours(cfg: dict) -> bool:
    quiet = cfg.get("quietHours") or []
    return datetime.now().hour in quiet


# ---------------- 常驻轮询 ----------------
class CommentWatcher:
    def __init__(self) -> None:
        self.task: asyncio.Task | None = None
        self.running = False
        self.last_tick = ""

    async def start(self) -> None:
        if self.task and not self.task.done():
            return
        self.running = True
        self.task = asyncio.create_task(self._loop())
        log.info("comment watcher started")

    async def stop(self) -> None:
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except (asyncio.CancelledError, Exception):
                pass
            self.task = None
        log.info("comment watcher stopped")

    async def _loop(self) -> None:
        # 启动后先等 60 秒，避开启动高峰
        await asyncio.sleep(60)

        # 开机补漏：算一下距上次运行隔了多久
        cfg0 = load_cfg()
        gap_min = 0
        if cfg0.get("lastRun"):
            try:
                last = datetime.fromisoformat(cfg0["lastRun"])
                gap_min = int((datetime.now() - last).total_seconds() / 60)
            except Exception:
                gap_min = 0
        save_cfg({"lastBootGapMin": gap_min})

        if (cfg0.get("catchUpOnBoot") and gap_min >= int(cfg0.get("intervalMin", 15)) * 2):
            log.info("boot catch-up: gap %s min, running extra round", gap_min)
            db.log_event("info", "watch",
                         f"开机补漏：距上次运行 {gap_min} 分钟，立即补一轮")
            try:
                await self.round({**cfg0,
                                  "pagesPerRound": cfg0.get("catchUpPages", 12)})
            except Exception as e:
                log.warning("catch-up failed: %s", e)

        while self.running:
            try:
                cfg = load_cfg()
                if cfg.get("enabled") and not in_quiet_hours(cfg):
                    await self.round(cfg)
                else:
                    reason = "已关闭" if not cfg.get("enabled") else "静默时段"
                    log.debug("comment watch skip: %s", reason)
            except Exception as e:
                log.warning("comment watch round failed: %s", e)
            self.last_tick = now_iso()
            cfg2 = load_cfg()
            await asyncio.sleep(max(60, int(cfg2.get("intervalMin", 15)) * 60))

    async def catch_up(self, hours: int = 72) -> dict:
        """手动触发补漏：把最近 N 小时没查过的都补一轮。"""
        cfg = load_cfg()
        cfg["pagesPerRound"] = cfg.get("catchUpPages", 12)
        res = await self.round(cfg)
        res["mode"] = "catch_up"
        res["hours"] = hours
        return res

    async def round(self, cfg: dict) -> dict:
        """跑一轮：覆盖尽可能多的主页，新增/最久没查的优先。"""
        from app.api import comments as capi
        from app.services import comments as cm

        env = db.q1("SELECT * FROM envs WHERE role='publisher' AND status='running'")
        if not env:
            res = {"skipped": "没有运行中的发布号环境"}
            save_cfg({"lastRun": now_iso(),
                      "lastResult": json.dumps(res, ensure_ascii=False)})
            return res

        limit = max(1, min(60, int(cfg.get("pagesPerRound", 20))))
        cover_new = bool(cfg.get("coverNewPages", True))

        if cover_new:
            # 排序优先级：
            #   1. 从没查过的（新增主页一定在这里，保证覆盖到）
            #   2. 最久没查过的
            pages = db.q(
                """SELECT p.page_id, p.name, p.asset_id,
                          MAX(c.ts) AS last_ts,
                          COUNT(c.id) AS checked_n
                   FROM pages p
                   LEFT JOIN comment_actions c ON c.page_id = p.page_id
                   WHERE p.asset_id IS NOT NULL
                   GROUP BY p.page_id
                   ORDER BY CASE WHEN COUNT(c.id) = 0 THEN 0 ELSE 1 END,
                            COALESCE(MAX(c.ts), '') ASC
                   LIMIT ?""", (limit,))
        else:
            pages = db.q(
                """SELECT p.page_id, p.name, p.asset_id, MAX(c.ts) AS last_ts
                   FROM pages p LEFT JOIN comment_actions c ON c.page_id = p.page_id
                   WHERE p.asset_id IS NOT NULL
                   GROUP BY p.page_id
                   ORDER BY COALESCE(last_ts, '') ASC
                   LIMIT ?""", (limit,))

        total_pages = db.q1(
            "SELECT COUNT(*) c FROM pages WHERE asset_id IS NOT NULL")["c"]

        fresh = [p for p in pages if not p.get("checked_n")]
        total_r, total_d, errors = 0, 0, []
        done_pages = 0

        for p in pages:
            try:
                r = await capi._collect_and_act(
                    page_id=p["page_id"],
                    env=env,
                    allow_reply=cfg.get("allowReply", True),
                    allow_delete=cfg.get("allowDelete", True),
                    dry_run=False,
                )
                total_r += r.get("reply", 0)
                total_d += r.get("delete", 0)
                done_pages += 1
                if r.get("guard"):
                    errors.append(f"{p['name']}: 风控 {r['guard'].get('kind')}")
                    if (r["guard"] or {}).get("scope") in ("account", "global"):
                        break
            except Exception as e:
                errors.append(f"{p['name']}: {str(e)[:80]}")
            # 主页之间停一下
            await asyncio.sleep(3)

        res = {
            "pages": done_pages,
            "totalPages": total_pages,
            "uncovered": max(0, total_pages - done_pages),
            "freshThisRound": len(fresh),
            "reply": total_r,
            "delete": total_d,
            "errors": errors[:5],
        }
        save_cfg({"lastRun": now_iso(),
                  "lastResult": json.dumps(res, ensure_ascii=False)})
        db.log_event("ok", "watch",
                     f"评论轮询：{done_pages}/{total_pages} 页"
                     f"（新增 {len(fresh)}）· 回 {total_r} · 删 {total_d}")
        return res


watcher = CommentWatcher()


# ---------------- 计划任务：已按用户要求移除 ----------------
# 用户明确不要 Windows 计划任务，改为随软件启动/关闭。
# 保留 status() 里的查询只为展示「未使用」，安装/卸载接口返回明确提示。


def task_command() -> dict:
    return {
        "disabled": True,
        "note": "已按用户要求移除 Windows 计划任务。评论轮询随软件启停。",
        "commands": {},
    }


def install_task(kind: str = "alive") -> dict:
    return {"ok": False, "disabled": True,
            "error": "计划任务功能已移除（用户要求）。评论轮询随软件运行。"}


def uninstall_tasks() -> dict:
    """尽力清掉之前可能装过的任务，避免残留。"""
    cleaned = []
    for name in ("YuhaiWorkbench", "YuhaiWorkbench-logon", "YuhaiWorkbench-boot"):
        try:
            r = proc.run(f'schtasks /Delete /TN "{name}" /F',
                               shell=True, capture_output=True, text=True,
                               timeout=20, encoding="utf-8", errors="replace")
            if r.returncode == 0:
                cleaned.append(name)
        except Exception:
            pass
    if cleaned:
        db.log_event("info", "watch", f"清理残留计划任务：{', '.join(cleaned)}")
    return {"ok": True, "cleaned": cleaned}


def status() -> dict:
    cfg = load_cfg()
    procs = []
    try:
        import psutil
        for p in psutil.process_iter(["pid", "name", "cmdline"]):
            cl = " ".join(p.info.get("cmdline") or [])
            if "uvicorn" in cl and "app.main" in cl:
                procs.append({"pid": p.info["pid"],
                              "cmd": cl[:160]})
    except Exception:
        pass
    # ---- 真实覆盖评估 ----
    now = datetime.now()
    last_run = cfg.get("lastRun") or ""
    gap_min = None
    gap_text = "尚未运行过"
    if last_run:
        try:
            d = datetime.fromisoformat(last_run)
            gap_min = int((now - d).total_seconds() / 60)
            if gap_min < 60:
                gap_text = f"{gap_min} 分钟前"
            elif gap_min < 1440:
                gap_text = f"{gap_min // 60} 小时前"
            else:
                gap_text = f"{gap_min // 1440} 天前"
        except Exception:
            pass

    total_pages = db.q1("SELECT COUNT(*) c FROM pages WHERE asset_id IS NOT NULL")
    total_pages = total_pages["c"] if total_pages else 0
    per_round = max(1, int(cfg.get("pagesPerRound", 5)))
    interval = max(5, int(cfg.get("intervalMin", 15)))
    rounds_needed = (total_pages + per_round - 1) // per_round if total_pages else 0
    full_cycle_min = rounds_needed * interval

    # 关机期间完全无覆盖 —— 必须诚实说明
    coverage = {
        "totalPages": total_pages,
        "perRound": per_round,
        "intervalMin": interval,
        "fullCycleMin": full_cycle_min,
        "fullCycleText": (f"全部 {total_pages} 个主页轮一遍要约 {full_cycle_min // 60} 小时"
                          if full_cycle_min >= 60
                          else f"全部 {total_pages} 个主页轮一遍约 {full_cycle_min} 分钟"),
        "lastRun": last_run,
        "gapMin": gap_min,
        "gapText": gap_text,
        "catchUpOnBoot": cfg.get("catchUpOnBoot", True),
        "offlineBlind": "关机期间完全无覆盖，开机后会补一轮（不保证一条不漏）",
    }

    return {
        "watcherRunning": bool(watcher.task and not watcher.task.done()),
        "lastTick": watcher.last_tick,
        "config": cfg,
        "inQuietHours": in_quiet_hours(cfg),
        "backendProcs": procs,
        "scheduledTask": "已移除（不需要）",
        "python": "（随软件内置）",
        "backendDir": "（随软件内置）",
        "coverage": coverage,
        # 诚实的能力边界
        "limits": [
            "① 软件运行：每 6 小时轮询一轮，覆盖最好",
            "② 关掉软件：完全不跑（已按你的要求不做计划任务）",
            "③ 电脑休眠 / 关机：完全不跑",
            "④ 下次打开软件：自动补一轮（catch-up），能补回大部分",
            "⑤ 要 7x24 真覆盖：必须部署到常开的机器",
        ],
    }
