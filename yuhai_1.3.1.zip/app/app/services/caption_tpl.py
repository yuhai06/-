"""发布文案：填一条参考文案 → 模型生成多个同风格变体。

用户的实际用法（他一直在用的模板）：
    🎬NEXT EPISODE👉🏻{{LINK}}
    🌟Watch all episodes for FREE
    🔍Title: "{{DRAMA}}".
    Click the link in the title to search the show name, don't miss any episode!✨

问题：每个视频都用同一段，同质化严重。
所以这里做的是：**保持结构不变，换钩子句式**，让模型生成 N 个变体。

关键约束：
    · {{LINK}} 必须原样保留 —— 链接一个字符都不能改
    · {{DRAMA}} 换成剧名
    · 结构（NEXT EPISODE / Watch all / Title / CTA）保留
    · 只改钩子句和措辞，不改变事实内容
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.caption_tpl")

# 用户的原版模板（首次启动自动写入）
DEFAULT_BODY = """🎬NEXT EPISODE👉🏻{{LINK}}
🌟Watch all episodes for FREE
🔍Title: "{{DRAMA}}".
Click the link in the title to search the show name, don't miss any episode!✨"""

VARS = {
    "{{LINK}}": "推广链接（原样插入，绝不改写）",
    "{{DRAMA}}": "剧名",
    "{{EP}}": "集号（如 EP12）",
}


def ensure_default() -> None:
    """确保有一条默认模板。"""
    r = db.q1("SELECT COUNT(*) c FROM caption_templates")["c"]
    if r:
        return
    db.exec("INSERT INTO caption_templates(id,name,body,vars,enabled,used_count,"
            "created_at) VALUES(?,?,?,?,1,0,?)",
            ("tpl-default", "标准追剧引导", DEFAULT_BODY,
             json.dumps(VARS, ensure_ascii=False), now_iso()))


def list_templates() -> list[dict]:
    ensure_default()
    rows = db.q("SELECT * FROM caption_templates ORDER BY created_at")
    for r in rows:
        try:
            r["varList"] = json.loads(r["vars"] or "{}")
        except Exception:
            r["varList"] = {}
    return rows


def get_template(tid: str = "") -> dict | None:
    ensure_default()
    if tid:
        return db.q1("SELECT * FROM caption_templates WHERE id=?", (tid,))
    return db.q1("SELECT * FROM caption_templates WHERE enabled=1 LIMIT 1")


def save_template(name: str, body: str, tid: str = "") -> str:
    if not body.strip():
        raise ValueError("文案不能为空")
    if tid and db.q1("SELECT id FROM caption_templates WHERE id=?", (tid,)):
        db.exec("UPDATE caption_templates SET name=?,body=? WHERE id=?",
                (name, body, tid))
        return tid
    nid = "tpl-" + uuid.uuid4().hex[:10]
    db.exec("INSERT INTO caption_templates(id,name,body,vars,enabled,used_count,"
            "created_at) VALUES(?,?,?,?,1,0,?)",
            (nid, name or "未命名", body,
             json.dumps(VARS, ensure_ascii=False), now_iso()))
    return nid


def build_prompt(body: str, drama: str, n: int) -> str:
    """让模型生成 N 个变体。prompt 保持短 —— 长 prompt 会让免费模型返回空。"""
    return f"""把下面这条短剧推广文案改写成 {n} 个不同版本。

原文：
{body}

要求：
- 保持四段结构：①NEXT EPISODE 引导 ②Watch all episodes for FREE ③Title: "剧名" ④点击链接搜索剧名的 CTA
- 保留所有 emoji（🎬🌟🔍👉🏻✨）
- {{LINK}} 原样保留，不要改、不要删、不要换成别的链接
- {{DRAMA}} 原样保留占位符
- 只改钩子句和措辞，让开头不那么雷同
- 每个版本的第一句必须不一样

只输出 JSON 数组，不要别的文字：
["版本1完整文案","版本2完整文案"]"""


async def generate_variants(body: str, drama: str = "", n: int = 5,
                            model: str = "", template_id: str = "",
                            page_id: str = "") -> dict:
    """生成变体。模型失败则用规则变体兜底。"""
    from app.services import ai_analysis as ai

    n = max(1, min(20, n))
    try:
        text, used = await ai.call_model(build_prompt(body, drama, n), model)
        data = ai.extract_json(text)
        if isinstance(data, dict):
            data = data.get("variants") or data.get("result") or []
        if isinstance(data, list) and data:
            out = []
            for v in data[:n]:
                s = str(v).strip()
                # 强制校验：必须含 {{LINK}} 或原样链接
                if s and ("{{LINK}}" in s or "onelink.me" in s or "http" in s):
                    out.append(s)
            if out:
                saved = _save(template_id, page_id, out, f"model:{used}")
                return {"ok": True, "variants": out, "source": f"model:{used}",
                        "saved": saved}
    except Exception as e:
        log.warning("variant model failed: %s", e)

    # 规则兜底：换开头钩子
    hooks = [
        "🎬NEXT EPISODE👉🏻", "🎬THE TWIST IS HERE👉🏻",
        "🎬DON'T MISS THIS👉🏻", "🎬EPISODE DROP👉🏻",
        "🎬IT GETS CRAZY NEXT👉🏻", "🎬WATCH WHAT HAPPENS👉🏻",
    ]
    out = []
    for i in range(n):
        v = body
        # 替换第一行开头的 emoji 短语
        lines = v.split("\n")
        if lines:
            hook = hooks[i % len(hooks)]
            lines[0] = re.sub(r"^[^\s]*NEXT EPISODE[^\s]*", hook, lines[0]) \
                if "NEXT EPISODE" in lines[0] else hook + lines[0].lstrip("🎬👉🏻")
        out.append("\n".join(lines))
    saved = _save(template_id, page_id, out, "heuristic")
    return {"ok": True, "variants": out, "source": "heuristic", "saved": saved}


def _save(template_id: str, page_id: str, variants: list[str], source: str) -> int:
    n = 0
    for v in variants:
        if not v.strip():
            continue
        vid = "cv-" + uuid.uuid4().hex[:10]
        db.exec("INSERT INTO caption_variants(id,template_id,page_id,body,source,"
                "enabled,used_count,created_at) VALUES(?,?,?,?,?,1,0,?)",
                (vid, template_id or "", page_id or "", v.strip()[:4000],
                 source, now_iso()))
        n += 1
    return n


def list_variants(page_id: str = "", limit: int = 100) -> list[dict]:
    sql = "SELECT * FROM caption_variants WHERE enabled=1"
    params: list[Any] = []
    if page_id:
        sql += " AND (page_id=? OR page_id='')"
        params.append(page_id)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(min(limit, 500))
    return db.q(sql, params)


def pick_variant(page_id: str, drama: str, link: str, ep: str = "") -> dict:
    """挑一条变体并替换占位符。链接原样插入。"""
    rows = list_variants(page_id)
    if not rows:
        tpl = get_template()
        body = (tpl or {}).get("body") or DEFAULT_BODY
        return {"body": _fill(body, drama, link, ep), "source": "template",
                "variantId": None}

    # 避开最近用过的
    recent = db.q("SELECT title_id FROM units WHERE page_id=? AND title_id IS NOT NULL"
                  " ORDER BY created_at DESC LIMIT 3", (page_id,))
    recent_ids = {r["title_id"] for r in recent}
    pool = [x for x in rows if x["id"] not in recent_ids] or rows
    import random
    pick = random.choice(pool)
    return {"body": _fill(pick["body"], drama, link, ep),
            "source": f"variant:{pick['id']}", "variantId": pick["id"]}


def _fill(body: str, drama: str, link: str, ep: str = "") -> str:
    """替换占位符。链接原样插入，不做任何转义或改写。"""
    out = body
    out = out.replace("{{LINK}}", link)
    out = out.replace("{{DRAMA}}", drama or "")
    out = out.replace("{{EP}}", ep or "")
    # 如果模板里没写 {{LINK}}，把链接追加到末尾
    if link and link not in out:
        out = out.rstrip() + "\n" + link
    return out
