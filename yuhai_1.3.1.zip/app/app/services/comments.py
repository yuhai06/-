"""评论区维护机器人：英文引导评论 + 删恶评/蹭量/违规。

用户需求：
    评论：英文话术，必须引导点击链接，回复里**必须附上链接**
    删除：恶评、别人进来蹭热度引流的、违规言论

设计原则（防封第一）：
    · 所有评论操作走拟人化层（humanize），不直接 send
    · 每个主页每小时评论/删除数量有上限，按账号状态递减
    · 删除是**不可恢复**操作，默认 dryRun，必须显式确认才真删
    · 命中风控立即熔断整批

评论分类（决定删不删）：
    spam_link    别人贴自己的链接 / 引流  → 删
    toxic        辱骂、人身攻击            → 删
    illegal      违禁词（drugs/weapon 等） → 删
    irrelevant   完全无关的广告            → 删
    genuine      真实观众提问/互动         → 回复引导
    ambiguous    判不准                    → 不动作，交人工

回复策略：
    · 英文，短，口语化
    · 一定包含推广链接（从 promo_links 池随机取，原样插入）
    · 不重复：同一帖子下不重复回同一句
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.comments")

# ---------------- 分类规则 ----------------
# 违反这些 → 删
TOXIC_WORDS = [
    "fuck", "shit", "bitch", "bastard", "asshole", "dick", "cunt", "slut",
    "whore", "retard", "idiot", "stupid", "dumb", "moron", "loser", "pathetic",
    "kill yourself", "kys", "ugly", "disgusting", "trash", "garbage",
    "worst ever", "scam", "cringe", "shut up", "go die", "nonsense",
]
ILLEGAL_WORDS = [
    "drugs for sale", "buy weed", "cocaine", "meth", "weapon for sale",
    "gun for sale", "porn", "xxx video", "18+ only", "escort service",
    "hack account", "free money", "double your money", "investment guaranteed",
]
SPAM_PATTERNS = [
    r"https?://(?!pinedrama\.onelink\.me)[^\s]+",       # 非我方链接
    r"www\.[a-z0-9\-]+\.(com|net|io|me|xyz|top|shop)",
    r"\b(whatsapp|telegram|t\.me|wa\.me)\b",
    r"\b(dm me|check my page|visit my profile|follow me|sub to my)\b",
    r"\b(free followers|free likes|promo code|click here to earn)\b",
    r"\+\d{1,3}[\s\-]?\d{6,}",                          # 手机号引流
]
# 真实观众互动信号
GENUINE_HINTS = [
    "what's the name", "whats the name", "name of", "where can i watch",
    "where to watch", "full episode", "full version", "part 2", "next part",
    "more episodes", "how many episodes", "link please", "send link",
    "love this", "so good", "amazing", "best drama", "keep going",
]

# 短评正面词：nice/good/wow 这类也是真实观众，应该回复
SHORT_POSITIVE = {
    "nice", "nice!", "good", "good!", "great", "great!", "wow", "wow!",
    "cool", "cool!", "awesome", "amazing", "perfect", "beautiful",
    "interesting", "omg", "omg!", "woww", "best", "love", "love it",
    "fire", "lit", "dope", "sick", "nice one", "so nice", "very nice",
    "good job", "well done", "bravo", "10/10", "5/5",
}

# 网络笑声 / 表情词：这些也是真实情绪反应，应该回复
LAUGH_WORDS = {
    "lol", "lmao", "lmfao", "rofl", "haha", "hahaha", "hahahaha", "hehe",
    "hehehe", "hihi", "xd", "lool", "lolol", "ahah", "ahaha", "kekeke",
    "hahah", "hahahah", "jaja", "jajaja", "rsrs", "kkk", "kkkk",
}

# emoji 字符范围（覆盖绝大多数表情/符号/贴纸替代字符）
EMOJI_RANGES = [
    (0x1F300, 0x1F5FF),   # Misc Symbols and Pictographs
    (0x1F600, 0x1F64F),   # Emoticons
    (0x1F680, 0x1F6FF),   # Transport and Map
    (0x1F900, 0x1F9FF),   # Supplemental Symbols
    (0x1FA70, 0x1FAFF),   # Symbols and Pictographs Extended-A
    (0x2600, 0x26FF),     # Misc symbols
    (0x2700, 0x27BF),     # Dingbats
    (0x2B00, 0x2BFF),     # Misc Symbols and Arrows
    (0x1F1E6, 0x1F1FF),   # Regional indicators (flags)
    (0xFE00, 0xFE0F),     # Variation selectors
    (0x2190, 0x21FF),     # Arrows
    (0x2764, 0x2764),     # Heart
]


def _is_emoji(ch: str) -> bool:
    o = ord(ch)
    for a, b in EMOJI_RANGES:
        if a <= o <= b:
            return True
    return False


def emoji_ratio(text: str) -> float:
    """非空白字符里 emoji 占多少。"""
    if not text:
        return 0.0
    chars = [c for c in text if not c.isspace()]
    if not chars:
        return 0.0
    return sum(1 for c in chars if _is_emoji(c)) / len(chars)


def is_sticker(text: str) -> bool:
    """抓取时贴纸（sticker）会被标成 [sticker] 或 [gif]。"""
    t = (text or "").strip().lower()
    return t in ("[sticker]", "[gif]", "[emoji]", "[图片]", "[贴纸]") \
        or t.startswith("[sticker") or t.startswith("[gif")


# 纯表情/符号短评也算真实互动（不回复显得冷漠）
EMOJI_ONLY_OK = True


# ---------------- 自定义规则 ----------------
_custom_cache: dict | None = None
_custom_cache_ts: float = 0.0
_CUSTOM_TTL = 5.0


def load_custom_rules(force: bool = False) -> dict:
    """自定义规则（存在 kv 表，前端可编辑）。5 秒缓存避免每句都查库。"""
    global _custom_cache, _custom_cache_ts
    import time
    now = time.time()
    if not force and _custom_cache is not None and now - _custom_cache_ts < _CUSTOM_TTL:
        return _custom_cache

    base = {"positive": [], "deleteWords": [], "deleteRegex": []}
    try:
        r = db.q1("SELECT v FROM kv WHERE k='comment_rules'")
        if r and r["v"]:
            d = json.loads(r["v"])
            for k in base:
                if isinstance(d.get(k), list):
                    base[k] = [str(x) for x in d[k] if str(x).strip()]
    except Exception:
        pass
    _custom_cache = base
    _custom_cache_ts = now
    return base


def save_custom_rules(patch: dict) -> dict:
    global _custom_cache
    cur = load_custom_rules(force=True)
    for k in ("positive", "deleteWords", "deleteRegex"):
        if k in patch and isinstance(patch[k], list):
            cur[k] = [str(x).strip() for x in patch[k] if str(x).strip()]
    db.exec("INSERT INTO kv(k,v) VALUES('comment_rules',?)"
            " ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            (json.dumps(cur, ensure_ascii=False),))
    _custom_cache = cur
    db.log_event("info", "comments",
                 f"自定义评论规则更新：正面 {len(cur['positive'])} "
                 f"删除词 {len(cur['deleteWords'])} 正则 {len(cur['deleteRegex'])}")
    return cur

# ---------------- 英文回复话术（必须含 {link}） ----------------
REPLY_TEMPLATES = [
    "Full series here 👉 {link}",
    "You can watch the whole thing here: {link}",
    "All episodes are on this link 👉 {link}",
    "Here's where I watched it: {link}",
    "Full version 👉 {link} — it gets wild after ep 3",
    "Everyone's asking — full series here: {link}",
    "Part 2 and the rest are here 👉 {link}",
    "Watch the full story here: {link}",
]

# 每个号的每小时限额（保守；受限号再减半）
LIMITS = {
    "new":     {"reply": 20, "delete": 30},
    "limited": {"reply": 8,  "delete": 15},
    "blocked": {"reply": 0,  "delete": 0},
}


@dataclass
class Comment:
    cid: str
    text: str
    author: str = ""
    post_id: str = ""
    created: str = ""
    likes: int = 0
    category: str = ""
    reason: str = ""
    action: str = ""          # reply | delete | skip
    reply_text: str = ""


def classify(text: str) -> tuple[str, str]:
    """给一条评论分类。返回 (category, reason)。

    顺序：自定义删除 → 违规删 → 真实互动回 → 表情/笑声回 → 模糊
    """
    t = (text or "").lower().strip()
    raw = (text or "").strip()
    if not t:
        return "empty", "空评论"

    custom = load_custom_rules()

    # ① 自定义删除规则（优先级最高，用户明确要删的）
    for w in custom.get("deleteWords", []):
        if w and w.lower() in t:
            return "custom_delete", f"自定义删除词：{w}"
    for pat in custom.get("deleteRegex", []):
        try:
            m = re.search(pat, raw, re.I)
            if m:
                return "custom_delete", f"自定义正则：{pat[:30]}"
        except re.error:
            pass

    # ② 贴纸 / GIF
    if is_sticker(raw):
        return "sticker", "贴纸/GIF"

    # ③ 违规
    for w in ILLEGAL_WORDS:
        if w in t:
            return "illegal", f"违禁词命中：{w}"

    for w in TOXIC_WORDS:
        if w in t:
            return "toxic", f"辱骂命中：{w}"

    # ④ 引流
    for pat in SPAM_PATTERNS:
        m = re.search(pat, t, re.I)
        if m:
            return "spam_link", f"引流/外链命中：{m.group(0)[:40]}"

    # ⑤ 自定义正面词（用户指定的回复对象）
    for w in custom.get("positive", []):
        if w and w.lower() in t:
            return "genuine", f"自定义正面词：{w}"

    # ⑥ 现有真实互动信号
    for h in GENUINE_HINTS:
        if h in t:
            return "genuine", f"真实互动：{h}"

    # ⑦ 笑声词
    core = re.sub(r"[\s!！.。~～,，]+", "", t)
    if core in LAUGH_WORDS or t.rstrip("!！~～.。 ") in LAUGH_WORDS:
        return "genuine", f"笑声：{t}"
    # hahaha / lolol 这类重复延长
    if re.fullmatch(r"(ha){2,}|(ha){2,}h?|l(o+|)l+|lmf?a?o+|(ja){2,}|(kk){2,}", core):
        return "genuine", f"笑声延长：{t}"

    # ⑧ 短评正面词
    if core in SHORT_POSITIVE or t.rstrip("!！~～.。 ") in SHORT_POSITIVE:
        return "genuine", f"短评正面：{t}"

    # ⑨ 纯表情（含表情 + 少量文字）
    ratio = emoji_ratio(raw)
    if EMOJI_ONLY_OK:
        if ratio >= 0.99:
            return "genuine", "纯表情"
        if ratio >= 0.5 and len(core) <= 12:
            return "genuine", f"表情为主（{int(ratio * 100)}%）"

    # ⑩ 句中正面词
    for w in ("nice", "good", "great", "love", "like", "beautiful", "interesting"):
        if re.search(rf"\b{w}\b", t):
            return "genuine", f"含正面词：{w}"

    if len(t) <= 3:
        return "ambiguous", "过短"
    return "genuine" if len(t) > 10 else "ambiguous", "未命中规则"


def should_delete(category: str) -> bool:
    return category in ("spam_link", "toxic", "illegal", "irrelevant",
                        "custom_delete")


def should_reply(category: str) -> bool:
    return category in ("genuine", "sticker")


def build_reply(link: str, exclude: list[str] | None = None) -> str:
    """生成英文回复。**必须含链接**。"""
    if not link:
        return ""
    pool = [t for t in REPLY_TEMPLATES
            if not exclude or t.format(link=link) not in exclude]
    tpl = random.choice(pool or REPLY_TEMPLATES)
    return tpl.format(link=link)


def quota_for(account_id: str) -> dict:
    """取该号当前小时额度。"""
    acc = db.q1("SELECT * FROM accounts WHERE id=?", (account_id,)) or {}
    lvl = acc.get("page_quota") or "new"
    lim = LIMITS.get(lvl, LIMITS["new"])

    hour_ago = (datetime.now() - timedelta(hours=1)).isoformat()
    used_r = db.q1(
        "SELECT COUNT(*) c FROM comment_actions WHERE account_id=? AND action='reply'"
        " AND ts >= ?", (account_id, hour_ago))["c"]
    used_d = db.q1(
        "SELECT COUNT(*) c FROM comment_actions WHERE account_id=? AND action='delete'"
        " AND ts >= ?", (account_id, hour_ago))["c"]
    return {
        "level": lvl,
        "replyLimit": lim["reply"], "replyUsed": used_r,
        "replyLeft": max(0, lim["reply"] - used_r),
        "deleteLimit": lim["delete"], "deleteUsed": used_d,
        "deleteLeft": max(0, lim["delete"] - used_d),
    }


def record(account_id: str, page_id: str, cid: str, action: str,
           category: str, comment_text: str = "", reply_text: str = "",
           permalink: str = "", dry: bool = False) -> None:
    db.exec(
        "INSERT INTO comment_actions(id,account_id,page_id,comment_id,action,"
        "category,comment_text,reply_text,permalink,dry,ts)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        ("ca-" + uuid.uuid4().hex[:10], account_id, page_id, cid, action,
         category, comment_text[:600], reply_text[:600], permalink,
         1 if dry else 0, now_iso()))


def recently_handled(page_id: str, cid: str, hours: int = 24) -> bool:
    since = (datetime.now() - timedelta(hours=hours)).isoformat()
    r = db.q1("SELECT 1 FROM comment_actions WHERE page_id=? AND comment_id=?"
              " AND ts >= ? AND dry=0 LIMIT 1", (page_id, cid, since))
    return bool(r)


def plan_for(comments: list[Comment], link: str,
             allow_delete: bool, allow_reply: bool,
             reply_left: int, delete_left: int) -> list[Comment]:
    """给一批评论定动作。纯逻辑，不碰网络，方便先 dryRun 给用户看。"""
    used_reply = 0
    used_delete = 0
    for c in comments:
        cat, reason = classify(c.text)
        c.category, c.reason = cat, reason

        if recently_handled(c.post_id or "", c.cid):
            c.action = "skip"
            c.reason += " · 24h 内已处理"
            continue

        if should_delete(cat):
            if not allow_delete:
                c.action = "skip"
                c.reason += " · 未开启删除"
            elif used_delete >= delete_left:
                c.action = "skip"
                c.reason += " · 删除额度用尽"
            else:
                c.action = "delete"
                used_delete += 1
        elif should_reply(cat):
            if not allow_reply:
                c.action = "skip"
                c.reason += " · 未开启回复"
            elif not link:
                c.action = "skip"
                c.reason += " · 没有可用推广链接"
            elif used_reply >= reply_left:
                c.action = "skip"
                c.reason += " · 回复额度用尽"
            else:
                c.action = "reply"
                c.reply_text = build_reply(link)
                used_reply += 1
        else:
            c.action = "skip"
    return comments


def summarize(comments: list[Comment]) -> dict:
    out = {"total": len(comments), "reply": 0, "delete": 0, "skip": 0,
           "byCategory": {}}
    for c in comments:
        out[c.action or "skip"] = out.get(c.action or "skip", 0) + 1
        out["byCategory"][c.category] = out["byCategory"].get(c.category, 0) + 1
    return out
