"""AI 分析层：根据视频数据 + 受众画像，给出「这个主页适合发什么」。

数据来源（按可靠度）：
    ① 视频数据（已有）：每条视频的播放/互动/点击/完播/发布时间
    ② 受众画像（需采集）：Business Suite → 受众 → 年龄/性别/地区
    ③ 内容元数据：剧型（dtype）、标签、时长

分析产物（写入 page_fit 表）：
    · drama_type  偏好的剧型
    · keywords    表现出色的内容特征词
    · avoid       表现差的特征
    · reason      给用户看的解释
    · confidence  置信度（样本量决定）

重要前提：冷启动期（播放样本 < 阈值）**不出结论**，只标记「数据不足」。
不造假结论 —— 没数据就说没数据，避免误导投放决策。
"""
from __future__ import annotations

import json
import logging
import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any

from app.db import db, now_iso

log = logging.getLogger("yuhai.ai")

# 冷启动阈值：少于这么多条「有播放」视频，不出类型结论
MIN_SAMPLES = 8
# 单条视频播放超过这个才算「有信号」
MIN_PLAYS = 50


@dataclass
class PageStats:
    page_id: str
    page_name: str = ""
    videos: int = 0
    videos_with_plays: int = 0
    total_plays: int = 0
    total_clicks: int = 0
    median_plays: float = 0.0
    by_type: dict[str, dict] = field(default_factory=dict)
    by_duration: dict[str, dict] = field(default_factory=dict)
    by_hour: dict[int, dict] = field(default_factory=dict)
    top_titles: list[dict] = field(default_factory=list)
    low_titles: list[dict] = field(default_factory=list)

    @property
    def sample_size(self) -> int:
        return self.videos_with_plays

    @property
    def ready(self) -> bool:
        return self.videos_with_plays >= MIN_SAMPLES


def _bucket_duration(d: float | None) -> str:
    if not d:
        return "unknown"
    if d < 30:
        return "short(<30s)"
    if d < 60:
        return "mid(30-60s)"
    if d < 120:
        return "long(60-120s)"
    return "xlong(>120s)"


def _acc(d: dict, key: str, plays: int, clicks: int) -> None:
    e = d.setdefault(key, {"n": 0, "plays": 0, "clicks": 0})
    e["n"] += 1
    e["plays"] += plays
    e["clicks"] += clicks


def collect_page_stats(page_id: str, window_days: int = 30) -> PageStats:
    """从已有数据算出该主页的统计特征。纯 SQL，不调模型。"""
    page = db.q1("SELECT * FROM pages WHERE page_id=?", (page_id,)) or {}
    st = PageStats(page_id=page_id, page_name=page.get("name") or page_id)

    since = (date.today() - timedelta(days=window_days)).isoformat()
    rows = db.q(
        """SELECT u.*, COALESCE(NULLIF(u.published_date,''), substr(u.created_at,1,10)) AS pdate,
                  COALESCE(m.plays,0) plays, COALESCE(m.clicks,0) clicks,
                  COALESCE(m.reactions,0) reactions, COALESCE(m.comments,0) comments,
                  COALESCE(m.shares,0) shares
           FROM units u LEFT JOIN unit_metrics m ON m.unit_id=u.id
           WHERE u.page_id=? AND COALESCE(NULLIF(u.published_date,''),
                 substr(u.created_at,1,10)) >= ?""",
        (page_id, since))

    lib_by_file = {}
    for lb in db.q("SELECT file,dur,dtype,tags,line FROM library"):
        lib_by_file[lb["file"]] = lb

    plays_list = []
    for r in rows:
        st.videos += 1
        p = int(r["plays"] or 0)
        c = int(r["clicks"] or 0)
        st.total_plays += p
        st.total_clicks += c
        if p >= MIN_PLAYS:
            st.videos_with_plays += 1
            plays_list.append(p)

        # 类型：优先 units.tags / library
        lb = lib_by_file.get(r.get("file") or "")
        dtype = (lb or {}).get("dtype") or ""
        if not dtype:
            try:
                tags = json.loads(r.get("tags") or "[]")
            except Exception:
                tags = []
            dtype = tags[0] if tags else "unknown"
        _acc(st.by_type, dtype or "unknown", p, c)

        dur = (lb or {}).get("dur")
        _acc(st.by_duration, _bucket_duration(dur), p, c)

        # 发布小时
        pdate = r.get("published_at") or ""
        hour = None
        import re
        m2 = re.search(r"(\d{1,2}):(\d{2})", str(pdate))
        if m2:
            hour = int(m2.group(1))
            _acc(st.by_hour, hour, p, c)

    if plays_list:
        st.median_plays = statistics.median(plays_list)

    # Top / 低效标题（给模型看内容特征）
    ranked = sorted(rows, key=lambda x: -(x["plays"] or 0))
    st.top_titles = [{"title": (x["title"] or "")[:120], "plays": x["plays"],
                      "clicks": x["clicks"]} for x in ranked[:5]]
    st.low_titles = [{"title": (x["title"] or "")[:120], "plays": x["plays"],
                      "clicks": x["clicks"]}
                     for x in reversed(ranked[-3:])] if len(ranked) > 3 else []
    return st


def build_prompt(st: PageStats) -> str:
    """拼给模型的提示词。要求严格 JSON 输出。

    注意：prompt 要短 —— 实测长 prompt 会让部分免费模型返回空。
    """
    def fmt(d: dict) -> str:
        if not d:
            return "无"
        parts = []
        for k, v in sorted(d.items(), key=lambda kv: -kv[1]["plays"])[:4]:
            avg = v["plays"] / max(1, v["n"])
            parts.append(f"{k}:{v['n']}条/均播{avg:.0f}")
        return "，".join(parts)

    top = "；".join(f"[{t['plays']}播]{t['title'][:40]}"
                    for t in st.top_titles[:3]) or "无"
    low = "；".join(f"[{t['plays']}播]{t['title'][:40]}"
                    for t in st.low_titles[:2]) or "无"

    return f"""分析这个 Facebook 短剧主页，判断适合发什么内容。

主页:{st.page_name}
近30天:视频{st.videos}条,有效样本{st.videos_with_plays}条,播放中位数{st.median_plays:.0f},总播放{st.total_plays},点击{st.total_clicks}
剧型表现:{fmt(st.by_type)}
时长表现:{fmt(st.by_duration)}
表现好:{top}
表现差:{low}

只输出这个 JSON，不要别的文字：
{{"drama_type":"punch|ethics|backer|mystery|tension|sweet|rebirth 之一","keywords":["3个内容特征词"],"avoid":["2个应避开的"],"best_hours":[1-3个整数小时],"best_duration":"short|mid|long|xlong","reason":"50字内,必须含两个数字","confidence":0.0-1.0}}

样本不足{MIN_SAMPLES}条时 confidence 不超过0.3，但仍要给出你的判断。"""


async def call_model(prompt: str, model_id: str = "") -> tuple[str, str]:
    """调用 DSH 网关的模型（OpenAI 兼容）。

    实测：部分模型（opencodez/*）返回 502，workbuddy/hy4free 可用。
    所以这里做**自动换模型重试**：首选失败就依次试其他免费模型。
    返回 (文本, 实际用的模型名)。
    """
    import httpx
    from app.services import dsh_models as dm

    ep = dm.resolve_endpoint()
    base = ep.get("base") or ""
    key = ep.get("key") or ""
    if not base:
        raise RuntimeError(ep.get("note") or "没有可用的模型端点")

    # 候选模型：指定的 → 默认 → 其他免费模型
    cands: list[str] = []
    for m in (model_id, ep.get("model"), dm.default_model()):
        if m and m not in cands:
            cands.append(m)
    # 补充其他免费模型作为后备
    for m in dm.free_models():
        if m.get("free") and m["id"] not in cands:
            cands.append(m["id"])
        if len(cands) >= 6:
            break

    url = base.rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    body_base = {
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.3,
        "max_tokens": 800,
    }

    last_err = ""
    for mid in cands:
        try:
            async with httpx.AsyncClient(timeout=120) as c:
                r = await c.post(url, json={**body_base, "model": mid},
                                 headers=headers)
            if r.status_code != 200:
                last_err = f"{mid} → {r.status_code}"
                log.debug("model %s failed: %s", mid, r.text[:120])
                continue
            d = r.json()
            ch = (d.get("choices") or [{}])[0]
            msg = ch.get("message") or {}
            text = msg.get("content") or ""
            # 有些模型把内容放 reasoning_content 或返回被截断
            if not text.strip():
                text = msg.get("reasoning_content") or ""
            if not text.strip():
                fr = ch.get("finish_reason") or ""
                last_err = f"{mid} → 空回复({fr})"
                log.debug("model %s empty, finish=%s full=%s", mid, fr,
                          json.dumps(d, ensure_ascii=False)[:200])
                continue
            log.info("model used: %s (%d chars)", mid, len(text))
            return text.strip(), mid
        except Exception as e:
            last_err = f"{mid} → {str(e)[:60]}"
            continue

    raise RuntimeError(f"所有模型都失败：{last_err}")


def extract_json(text: str) -> dict | None:
    """从模型输出里抠 JSON（容忍 ```json 包裹）。"""
    if not text:
        return None
    t = text.strip()
    if t.startswith("```"):
        t = t.split("```")[1] if "```" in t[3:] else t[3:]
        if t.startswith("json"):
            t = t[4:]
    t = t.strip().strip("`")
    try:
        return json.loads(t)
    except Exception:
        # 找第一个 { 到最后一个 }
        i, j = t.find("{"), t.rfind("}")
        if i >= 0 and j > i:
            try:
                return json.loads(t[i:j + 1])
            except Exception:
                return None
    return None


def save_fit(page_id: str, data: dict, model: str, st: PageStats) -> None:
    db.exec(
        "INSERT INTO page_fit(page_id,drama_type,keywords,avoid,reason,confidence,"
        "sample_size,model,ts) VALUES(?,?,?,?,?,?,?,?,?)"
        " ON CONFLICT(page_id) DO UPDATE SET drama_type=excluded.drama_type,"
        " keywords=excluded.keywords, avoid=excluded.avoid, reason=excluded.reason,"
        " confidence=excluded.confidence, sample_size=excluded.sample_size,"
        " model=excluded.model, ts=excluded.ts",
        (page_id, data.get("drama_type") or "unknown",
         json.dumps(data.get("keywords") or [], ensure_ascii=False),
         json.dumps(data.get("avoid") or [], ensure_ascii=False),
         (data.get("reason") or "")[:400],
         float(data.get("confidence") or 0),
         st.sample_size, model, now_iso()))
    db.exec(
        "INSERT INTO ai_analysis(scope,target,kind,model,input_json,result,confidence,"
        "sample_size,ts) VALUES('page',?,'content_fit',?,?,?,?,?,?)",
        (page_id, model,
         json.dumps({"videos": st.videos, "withPlays": st.videos_with_plays,
                     "byType": st.by_type, "byDuration": st.by_duration},
                    ensure_ascii=False, default=str),
         json.dumps(data, ensure_ascii=False),
         float(data.get("confidence") or 0), st.sample_size, now_iso()))


def heuristic_fit(st: PageStats) -> dict:
    """没有模型时的规则兜底：纯统计，不编造。"""
    if not st.ready:
        return {
            "drama_type": "unknown",
            "keywords": [],
            "avoid": [],
            "best_hours": [],
            "best_duration": "",
            "reason": (f"有效样本仅 {st.videos_with_plays} 条（需 ≥{MIN_SAMPLES}），"
                       f"不足以判断内容偏好。继续积累播放数据后再分析。"),
            "confidence": 0.2,
            "source": "heuristic",
        }
    best_type = max(st.by_type.items(),
                    key=lambda kv: kv[1]["plays"] / max(1, kv[1]["n"]))[0] \
        if st.by_type else "unknown"
    best_dur = max(st.by_duration.items(),
                   key=lambda kv: kv[1]["plays"] / max(1, kv[1]["n"]))[0] \
        if st.by_duration else ""
    best_hours = [h for h, _ in sorted(
        st.by_hour.items(), key=lambda kv: -kv[1]["plays"])[:2]]
    return {
        "drama_type": best_type,
        "keywords": [t["title"][:20] for t in st.top_titles[:3]],
        "avoid": [t["title"][:20] for t in st.low_titles[:2]],
        "best_hours": best_hours,
        "best_duration": best_dur,
        "reason": (f"{st.videos_with_plays} 条有效样本，均播 "
                   f"{st.total_plays / max(1, st.videos_with_plays):.0f}，"
                   f"{best_type} 类型表现最好"),
        "confidence": round(min(0.75, st.videos_with_plays / 40), 2),
        "source": "heuristic",
    }


async def analyze_page(page_id: str, model_id: str = "",
                       use_model: bool = True) -> dict:
    """分析单个主页，写 page_fit。返回结果 dict。

    样本不足也调模型 —— 但会在提示词里要求它**明确标注样本不足**并压低置信度。
    这样用户能看到模型基于现有数据的具体判断，而不是一句「样本不足」。
    """
    st = collect_page_stats(page_id)

    if use_model:
        try:
            prompt = build_prompt(st)
            text, used = await call_model(prompt, model_id)
            data = extract_json(text)
            if data:
                data["source"] = "model"
                # 样本不足时强制压低置信度（模型可能给高）
                if not st.ready:
                    data["confidence"] = min(
                        float(data.get("confidence") or 0.2), 0.35)
                    if "样本" not in (data.get("reason") or ""):
                        data["reason"] = (
                            f"（样本仅 {st.sample_size} 条，仅供参考）"
                            + (data.get("reason") or ""))
                save_fit(page_id, data, used, st)
                return {"ok": True, "pageId": page_id, "pageName": st.page_name,
                        "sample": st.sample_size, "model": used,
                        "ready": st.ready, "result": data}
            log.warning("model output not JSON: %s", text[:200])
        except Exception as e:
            log.warning("model call failed: %s", e)

    data = heuristic_fit(st)
    save_fit(page_id, data, data.get("source") or "heuristic", st)
    return {"ok": True, "pageId": page_id, "pageName": st.page_name,
            "sample": st.sample_size, "model": data.get("source"),
            "ready": st.ready, "result": data}
