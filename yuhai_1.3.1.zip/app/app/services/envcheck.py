"""环境自检 + 自动安装。

设计目标（用户要求）：**不只能在我这台电脑跑**。
换电脑时缺什么就装什么，或者明确告诉用户怎么装。

检查项：
    ① ffmpeg / ffprobe（内置优先，其次 PATH）
    ② Python 包：faster-whisper / Pillow / httpx / psutil / imapclient / zstandard
    ③ GPU / CUDA（faster-whisper 加速用，没有就降级 CPU）
    ④ NVENC（ffmpeg 硬件编码，没有就用 libx264）
    ⑤ tools/ 脚本目录
    ⑥ 字体（Montserrat，PIL 渲染字幕用）
    ⑦ BGM 音频素材
    ⑧ 本地 Clash 代理（抓取用）

安装策略：
    · Python 包 → pip install（可自动执行）
    · ffmpeg → 内置已打包；没有就提示下载地址 + 尝试 winget/choco
    · 字体/BGM → 提示从哪拷，或自动从内置资源复制
"""
from __future__ import annotations

import logging
import os
import shutil
import sys
from pathlib import Path

from app.config import settings
from app import paths as _paths
from app import proc

log = logging.getLogger("yuhai.envcheck")


# ---------------- Python 包 ----------------
PY_PACKAGES = [
    {"name": "faster-whisper", "import": "faster_whisper",
     "why": "台词转录（切片流程核心）", "required": True,
     "pip": "faster-whisper>=1.0"},
    {"name": "Pillow", "import": "PIL",
     "why": "字幕/CTA 图片渲染", "required": True, "pip": "Pillow"},
    {"name": "httpx", "import": "httpx",
     "why": "HTTP 请求", "required": True, "pip": "httpx"},
    {"name": "psutil", "import": "psutil",
     "why": "进程/端口探测", "required": True, "pip": "psutil"},
    {"name": "imapclient", "import": "imapclient",
     "why": "邮箱验证码", "required": False, "pip": "IMAPClient"},
    {"name": "zstandard", "import": "zstandard",
     "why": "压缩", "required": False, "pip": "zstandard"},
    {"name": "pywebview", "import": "webview",
     "why": "桌面窗口", "required": False, "pip": "pywebview"},
]


def check_python() -> list[dict]:
    out = []
    for p in PY_PACKAGES:
        ok = False
        ver = ""
        try:
            mod = __import__(p["import"])
            ok = True
            ver = getattr(mod, "__version__", "")
        except Exception:
            ok = False
        out.append({**p, "ok": ok, "version": str(ver)[:20]})
    return out


# ---------------- 可执行 ----------------
def check_ffmpeg() -> dict:
    from app.services import video_maker as vm
    ff = vm.ffmpeg_path()
    fp = vm.ffprobe_path()
    ok = False
    ver = ""
    nvenc = False
    try:
        r = proc.run([ff, "-version"], capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
        ok = r.returncode == 0
        ver = (r.stdout or "").split("\n")[0][:100]
        if ok:
            r2 = proc.run([ff, "-hide_banner", "-encoders"],
                                capture_output=True, text=True, timeout=20,
                                encoding="utf-8", errors="replace")
            nvenc = "h264_nvenc" in (r2.stdout or "")
    except Exception as e:
        ver = str(e)[:100]
    return {"ok": ok, "ffmpeg": ff, "ffprobe": fp, "version": ver,
            "bundled": (vm._bundle_dir() / "ffmpeg.exe").exists(),
            "nvenc": nvenc,
            "hint": "" if ok else "内置未打包且 PATH 里没有。"
                                  "下载 https://www.gyan.dev/ffmpeg/builds/ 解压后"
                                  "把 ffmpeg.exe/ffprobe.exe 放到程序目录 bin\\ 下"}


def check_gpu() -> dict:
    out = {"ok": False, "name": "", "cuda": False, "hint": ""}
    try:
        r = proc.run(["nvidia-smi", "--query-gpu=name,driver_version",
                            "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10,
                           encoding="utf-8", errors="replace")
        if r.returncode == 0 and (r.stdout or "").strip():
            parts = (r.stdout or "").strip().split("\n")[0].split(",")
            out["ok"] = True
            out["name"] = parts[0].strip()[:60]
            out["driver"] = parts[1].strip() if len(parts) > 1 else ""
    except Exception:
        out["hint"] = "没检测到 NVIDIA GPU。faster-whisper 会降级用 CPU（慢 5-10 倍）"
    if not out["ok"]:
        out["hint"] = out["hint"] or "无 GPU，转录走 CPU"
    return out


def check_tools() -> dict:
    from app.services import slicing as sl
    t = sl.tools_dir()
    need = ["transcribe_audio.py", "voice_check3.py", "classify.py",
            "score_lines2.py", "cut_ep2.py", "plan_from_tension.py",
            "render_plan.py", "pipeline2.py", "mark_done.py"]
    have = {s: (t / s).exists() for s in need}
    return {
        "dir": str(t), "exists": t.exists(), "scripts": have,
        "missing": [k for k, v in have.items() if not v],
        "ok": t.exists() and all(have.values()),
        "hint": "" if all(have.values()) else
                f"缺少脚本，把 tools 目录放到 {t}，或设环境变量 YUHAI_TOOLS 指向它",
    }


def check_assets() -> dict:
    """字体 + BGM（PIL 渲染和混音用），目录走统一解析。"""
    fonts_dir = _paths.fonts_dir()
    audio_dir = _paths.audio_dir()
    fonts = sorted(f.name for f in fonts_dir.glob("*.ttf")) if fonts_dir.exists() else []
    bgm = sorted(f.name for f in audio_dir.glob("bgm_*.wav")) if audio_dir.exists() else []
    sfx = sorted(f.name for f in audio_dir.glob("sfx_*.wav")) if audio_dir.exists() else []
    return {
        "fontsDir": str(fonts_dir), "fonts": fonts, "fontCount": len(fonts),
        "audioDir": str(audio_dir), "bgm": bgm, "bgmCount": len(bgm),
        "sfxCount": len(sfx),
        "ok": len(fonts) > 0 and len(bgm) > 0,
        "hint": "" if (fonts and bgm) else
                f"字体放 {fonts_dir}（Montserrat），BGM 放 {audio_dir}（bgm_*.wav）。"
                "也可用 YUHAI_FONTS / YUHAI_AUDIO 指定别的目录",
    }


def check_proxy() -> dict:
    import httpx
    proxy = _paths.proxy()
    if not proxy:
        return {"proxy": "", "alive": False,
                "hint": "没检测到本地代理。抓取 PineDrama 需要代理"
                        "（tiktokcdn DNS 被污染）；设 PD_PROXY 环境变量或启动 Clash"}
    alive = False
    try:
        httpx.get(proxy, timeout=2)
        alive = True
    except Exception:
        alive = False
    return {"proxy": proxy, "alive": alive,
            "hint": "" if alive else f"检测到 {proxy} 但连不上，检查代理是否在运行"}


def check_curl() -> dict:
    p = _paths.curl()
    ver = ""
    if p:
        try:
            r = proc.run([str(p), "--version"], capture_output=True, text=True,
                               timeout=10, encoding="utf-8", errors="replace")
            ver = (r.stdout or "").split("\n")[0][:80]
        except Exception:
            pass
    return {"path": str(p) if p else "", "ok": bool(p), "version": ver,
            "hint": "" if p else "Windows 10+ 自带 curl；没有就装 curl 或把 curl.exe 放 PATH"}


# ---------------- 总检 ----------------
def full_check() -> dict:
    py = check_python()
    ff = check_ffmpeg()
    gpu = check_gpu()
    tools = check_tools()
    assets = check_assets()
    proxy = check_proxy()
    curl = check_curl()

    required_ok = (all(p["ok"] for p in py if p["required"])
                   and ff["ok"] and tools["ok"])
    warnings = []
    if not gpu["ok"]:
        warnings.append("无 GPU，转录会慢（CPU 模式）")
    if not ff["nvenc"]:
        warnings.append("无 NVENC，编码用 CPU（慢但能用）")
    if not assets["ok"]:
        warnings.append("字体或 BGM 缺失，字幕/混音可能失败")
    if not proxy["alive"]:
        warnings.append("代理未启动，抓取功能不可用")
    if not curl["ok"]:
        warnings.append("curl 缺失，抓取功能不可用")

    return {
        "ok": required_ok,
        "python": py,
        "ffmpeg": ff,
        "gpu": gpu,
        "tools": tools,
        "assets": assets,
        "proxy": proxy,
        "curl": curl,
        "warnings": warnings,
        "paths": _paths.snapshot(),
        "platform": {
            "os": sys.platform,
            "python": sys.version.split()[0],
            "frozen": bool(getattr(sys, "frozen", False)),
            "dataDir": str(settings.data_dir),
        },
    }


# ---------------- 自动安装 ----------------
def install_python(packages: list[str] | None = None) -> dict:
    """pip 安装缺失的包。"""
    py = check_python()
    missing = [p for p in py if not p["ok"]]
    if packages:
        missing = [p for p in missing if p["name"] in packages]
    if not missing:
        return {"ok": True, "note": "没有需要安装的包", "installed": []}

    results = []
    for p in missing:
        spec = p.get("pip") or p["name"]
        try:
            r = proc.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", spec],
                capture_output=True, text=True, timeout=600,
                encoding="utf-8", errors="replace")
            ok = r.returncode == 0
            results.append({"name": p["name"], "ok": ok,
                            "output": (r.stdout or r.stderr or "")[-300:]})
            log.info("pip install %s -> %s", spec, ok)
        except Exception as e:
            results.append({"name": p["name"], "ok": False, "error": str(e)[:200]})
    return {"ok": all(x["ok"] for x in results),
            "installed": [x["name"] for x in results if x["ok"]],
            "failed": [x for x in results if not x["ok"]],
            "results": results}


def _bin_dir() -> Path:
    """程序自带的 bin 目录（没有就建）。"""
    import sys as _sys
    if getattr(_sys, "frozen", False):
        base = Path(_sys.executable).resolve().parent
    else:
        base = Path(__file__).resolve().parent.parent.parent
    d = base / "bin"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _dl_ok(dst: Path, min_bytes: int = 32) -> bool:
    """下载成功判定。小文件（校验和、清单）不能按 1KB 卡。"""
    try:
        return dst.exists() and dst.stat().st_size >= min_bytes
    except OSError:
        return False


def _proxy_alive(px: str) -> bool:
    if not px:
        return False
    try:
        import socket
        from urllib.parse import urlparse
        u = urlparse(px)
        with socket.create_connection((u.hostname or "127.0.0.1",
                                       u.port or 7897), timeout=0.6):
            return True
    except Exception:
        return False


def _download(url: str, dst: Path, proxy: str = "", timeout: int = 300,
              min_bytes: int = 32, prefer_proxy: bool = True) -> dict:
    """下载文件，带断点续传。

    实测（本机）：直连 gyan.dev 约 20KB/s，走本地代理约 2MB/s，差 100 倍，
    所以**代理活着就优先走代理**。代理不通时回退直连，最后回退 urllib。

    Windows 上 curl 用 schannel，离线时证书吊销检查会直接失败
    （CRYPT_E_REVOCATION_OFFLINE），必须带 --ssl-no-revoke。
    """
    dst.parent.mkdir(parents=True, exist_ok=True)
    from app import paths as _p

    px = proxy or _p.proxy()
    px_ok = _proxy_alive(px)

    order: list[tuple[str, str]] = []
    if prefer_proxy and px_ok:
        order.append(("proxy", px))
    order.append(("direct", ""))
    if px_ok and not prefer_proxy:
        order.append(("proxy", px))

    errs: list[str] = []
    cb = _p.curl()
    if cb:
        for mode, use_px in order:
            # 两次：第一次正常下，失败且已下了一部分就续传
            for attempt in (1, 2):
                have = dst.stat().st_size if dst.exists() else 0
                args = [str(cb), "-sS", "-L", "--ssl-no-revoke",
                        "--max-time", str(timeout), "-o", str(dst)]
                if attempt == 2 and have > min_bytes:
                    args.insert(1, "-C")
                    args.insert(2, "-")
                if use_px:
                    args += ["-x", use_px]
                args.append(url)
                try:
                    r = proc.run(args, capture_output=True, timeout=timeout + 30)
                    if r.returncode == 0 and _dl_ok(dst, min_bytes):
                        return {"ok": True, "via": f"curl-{mode}",
                                "size": dst.stat().st_size, "resumed": attempt == 2}
                    errs.append(f"curl-{mode}#{attempt}: "
                                f"{(r.stderr or b'').decode('utf-8', 'replace')[:110]}")
                except Exception as e:
                    errs.append(f"curl-{mode}#{attempt}: {str(e)[:110]}")
    else:
        errs.append("curl: 未找到")

    # urllib 回退（读 HTTP_PROXY/HTTPS_PROXY；也手动套代理）
    for use_px in ([px] if px_ok else []) + [""]:
        try:
            import urllib.request
            if use_px:
                op = urllib.request.build_opener(
                    urllib.request.ProxyHandler({"http": use_px, "https": use_px}))
            else:
                op = urllib.request.build_opener()
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with op.open(req, timeout=timeout) as resp:
                dst.write_bytes(resp.read())
            if _dl_ok(dst, min_bytes):
                return {"ok": True, "via": "urllib" + ("-proxy" if use_px else ""),
                        "size": dst.stat().st_size}
        except Exception as e:
            errs.append(f"urllib{'-proxy' if use_px else ''}: {str(e)[:130]}")
    return {"ok": False, "error": " | ".join(errs[-4:])}


def install_ffmpeg_portable(proxy: str = "") -> dict:
    """**不依赖任何包管理器**：直接下载便携版 ffmpeg 解压到 bin\\。

    依次尝试多个镜像源；Windows 用 gyan.dev，Linux/macOS 提示用系统包管理器。
    """
    import platform as _pf
    import tempfile
    import zipfile

    if _pf.system() != "Windows":
        return {
            "ok": False, "via": "unsupported",
            "manual": [
                "Ubuntu/Debian: sudo apt install -y ffmpeg",
                "macOS: brew install ffmpeg",
                "CentOS/RHEL: sudo yum install -y ffmpeg",
            ],
        }

    bin_dir = _bin_dir()
    targets = ("ffmpeg.exe", "ffprobe.exe")
    if all((bin_dir / t).exists() for t in targets):
        return {"ok": True, "via": "already", "dir": str(bin_dir)}

    sources = [
        ("https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip", "gyan"),
        ("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"
         "ffmpeg-master-latest-win64-gpl.zip", "BtbN"),
        ("https://github.com/GyanD/codexffmpeg/releases/download/7.1/"
         "ffmpeg-7.1-essentials_build.zip", "gyan-github"),
    ]

    attempts = []
    for url, tag in sources:
        with tempfile.TemporaryDirectory() as td:
            zp = Path(td) / "ff.zip"
            dl = _download(url, zp, proxy=proxy, timeout=600)
            attempts.append({"source": tag, "url": url, **dl})
            if not dl.get("ok"):
                continue
            try:
                with zipfile.ZipFile(zp) as z:
                    names = z.namelist()
                    got = 0
                    for t in targets:
                        hit = next((n for n in names
                                    if n.replace("\\", "/").endswith("/bin/" + t)), None)
                        if not hit:
                            continue
                        with z.open(hit) as src, open(bin_dir / t, "wb") as out:
                            out.write(src.read())
                        got += 1
                    if got == len(targets):
                        # 验证能跑
                        r = proc.run([str(bin_dir / "ffmpeg.exe"), "-version"],
                                           capture_output=True, text=True, timeout=30,
                                           encoding="utf-8", errors="replace")
                        if r.returncode == 0:
                            return {"ok": True, "via": tag, "dir": str(bin_dir),
                                    "version": (r.stdout or "").split("\n")[0][:90],
                                    "attempts": attempts}
                        attempts.append({"source": tag, "ok": False,
                                         "error": "解压后跑不起来"})
                    else:
                        attempts.append({"source": tag, "ok": False,
                                         "error": f"zip 里只找到 {got}/2 个可执行"})
            except Exception as e:
                attempts.append({"source": tag, "ok": False,
                                 "error": f"解压失败 {str(e)[:150]}"})

    return {
        "ok": False, "attempts": attempts,
        "manual": [
            "① 浏览器打开 https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
            f"② 解压后把 bin\\ffmpeg.exe 和 bin\\ffprobe.exe 复制到 {bin_dir}",
            "③ 重启程序，环境自检会变绿",
        ],
        "binDir": str(bin_dir),
    }


def install_tools() -> dict:
    """tools 脚本目录缺失时的处理（不能自动下载，给明确指引）。"""
    from app import paths as _p
    t = _p.tools_dir()
    need = ["pipeline2.py", "transcribe_audio.py", "cut_ep2.py"]
    have = all((t / s).exists() for s in need)
    if have:
        return {"ok": True, "dir": str(t), "note": "脚本齐全"}
    return {
        "ok": False, "dir": str(t),
        "manual": [
            f"把 tools 目录（含 pipeline2.py 等 9 个脚本）放到 {t}",
            f"或设环境变量 YUHAI_TOOLS 指向脚本实际位置",
            "或在「设置 → 路径 → 切片/抓取脚本目录」里改",
        ],
    }


def install_ffmpeg() -> dict:
    """装 ffmpeg：包管理器 → 便携包直下 → 手动指引（三级兜底）。"""
    attempts: list[dict] = []

    # ① 包管理器
    for tool, cmd in (
        ("winget", ["winget", "install", "--id", "Gyan.FFmpeg",
                    "--accept-package-agreements", "--accept-source-agreements",
                    "--silent"]),
        ("choco", ["choco", "install", "ffmpeg", "-y"]),
        ("scoop", ["scoop", "install", "ffmpeg"]),
        ("brew", ["brew", "install", "ffmpeg"]),
        ("apt", ["apt-get", "install", "-y", "ffmpeg"]),
    ):
        if not shutil.which(tool):
            continue
        try:
            r = proc.run(cmd, capture_output=True, text=True, timeout=900,
                               encoding="utf-8", errors="replace")
            attempts.append({"tool": tool, "ok": r.returncode == 0,
                             "output": (r.stdout or r.stderr or "")[-400:]})
            if r.returncode == 0:
                # 装完复查一次
                if check_ffmpeg()["ok"]:
                    return {"ok": True, "via": tool, "attempts": attempts,
                            "note": "已通过包管理器安装"}
        except Exception as e:
            attempts.append({"tool": tool, "ok": False, "error": str(e)[:200]})

    # ② 便携包直下（不依赖任何包管理器）
    port = install_ffmpeg_portable()
    if port.get("ok"):
        return {**port, "attempts": attempts + (port.get("attempts") or []),
                "note": "已下载便携版到 bin\\，无需包管理器"}

    # ③ 手动
    return {
        "ok": False,
        "attempts": attempts + (port.get("attempts") or []),
        "manual": port.get("manual") or [
            "下载 https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
            f"解压后把 ffmpeg.exe / ffprobe.exe 放到 {_bin_dir()}",
        ],
        "binDir": str(_bin_dir()),
    }


def install_all() -> dict:
    """一键：装 Python 包 + ffmpeg + 检查脚本目录，逐步返回。"""
    steps = []

    py = install_python()
    steps.append({
        "what": "Python 包",
        "ok": py.get("ok", False),
        "detail": ("无需安装" if not py.get("installed") and not py.get("failed")
                   else f"装上 {len(py.get('installed') or [])} 个"
                        + (f"，失败 {len(py.get('failed') or [])} 个"
                           if py.get("failed") else "")),
        "log": [f"{r['name']}: {'OK' if r['ok'] else (r.get('error') or '失败')}"
                for r in (py.get("results") or [])],
    })

    ff = {"ok": True, "note": "已可用"}
    if not check_ffmpeg()["ok"]:
        ff = install_ffmpeg()
    steps.append({
        "what": "FFmpeg",
        "ok": ff.get("ok", False),
        "detail": ff.get("note") or ff.get("via") or "失败",
        "log": [f"{a.get('tool') or a.get('source')}: "
                f"{'OK' if a.get('ok') else (a.get('error') or '失败')}"
                for a in (ff.get("attempts") or [])][-8:],
    })

    tl = install_tools()
    steps.append({
        "what": "切片脚本",
        "ok": tl.get("ok", False),
        "detail": tl.get("note") or f"缺脚本，见 {tl.get('dir')}",
        "log": tl.get("manual") or [],
    })

    manual = []
    for s in steps:
        if not s["ok"]:
            manual += [x for x in (s.get("log") or []) if isinstance(x, str)]

    return {
        "ok": all(s["ok"] for s in steps),
        "steps": steps,
        "manual": manual,
        "after": full_check(),
    }
