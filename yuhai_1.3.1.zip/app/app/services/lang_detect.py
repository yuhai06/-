"""语言识别——上游 API 没有语言字段，只能从标题/描述推断。

为什么要做：
    PineDrama 的片源混了印尼语、英语、印地语、他加禄语等。
    用户常只要某一种语言（比如只要英文，方便配英文字幕和 CTA），
    或者完全不要语言限制。所以抓取时要能筛。

判定方式（轻量、不联网、不调模型）：
    ① 字符集判断：中文/日文/韩文/泰文/阿拉伯文有明显 Unicode 区间
    ② 拉丁字母语言：用高频停用词打分（印尼语 vs 英语 vs 西班牙语等）
    ③ 拿不准就返回 unknown，按「不筛选」处理（绝不误杀）
"""
from __future__ import annotations

import re

# 语言代码 → 显示名
LANGS: dict[str, str] = {
    "id": "印尼语",
    "en": "英语",
    "es": "西班牙语",
    "pt": "葡萄牙语",
    "hi": "印地语",
    "tl": "他加禄语",
    "th": "泰语",
    "vi": "越南语",
    "zh": "中文",
    "ja": "日语",
    "ko": "韩语",
    "ar": "阿拉伯语",
    "unknown": "未识别",
}

# 拉丁字母语言的高频词（区分彼此）
_STOPWORDS: dict[str, list[str]] = {
    "id": ["yang", "dan", "di", "itu", "aku", "kamu", "dia", "tidak",
           "untuk", "dengan", "dari", "ini", "akan", "bisa", "sudah",
           "sayang", "cinta", "istri", "suami", "anak", "ibu", "ayah",
           "raja", "pangeran", "melawan", "penipu", "kembali", "rahasia",
           # 短剧标题高频词（覆盖面补全）
           "gadis", "ajaib", "pembawa", "rezeki", "nenek", "kakek",
           "mantan", "agen", "super", "pengasuh", "paham", "bayi",
           "bahtera", "kiamat", "serigala", "penyamar", "pengemis",
           "pewaris", "sang", "terlarang", "miliarder", "raksasa",
           "terjebak", "pacarku", "putri", "putra", "kakak", "adik",
           "saudara", "keluarga", "rumah", "tangga", "kaya", "miskin",
           "harta", "warisan", "kantoran", "bos", "karyawan", "direktur",
           "dihina", "direndahkan", "penjual", "pangsit", "pedagang",
           "mafia", "mafia", "tuan", "nyonya", "pelayan", "asisten",
           "konspirasi", "pertukaran", "pasangan", "rahmat", "dosa",
           "memilih", "pilihan", "dipaksa", "menikah", "pernikahan",
           "bercerai", "cerai", "selingkuh", "perselingkuhan",
           "kembar", "amnesia", "lupa", "ingatan", "masa", "lalu",
           "masa depan", "takdir", "cinta pertama", "benci", "dendam",
           "balas", "budi", "semangkuk", "mi", "nasi", "restoran",
           "perusahaan", "bisnis", "perang", "saingan", "kompetitor",
           "naik", "jadi", "derajat", "pangkat", "tahta", "singgasana",
           "istana", "kerajaan", "ratu", "raja", "bangsawan", "ksatria",
           "dewi", "dewa", "alam", "gaib", "sihir", "kutukan", "kutuk",
           "pembalasan", "keadilan", "hukum", "pengadilan", "jaksa",
           "hakim", "pengacara", "kontrak", "perjanjian", "utang",
           "pinjaman", "bank", "uang", "duit", "modal", "saham",
           "perusahaan", "pabrik", "pekerja", "buruh", "upah", "gaji",
           "kekuasaan", "kekuatan", "kelemahan", "kesempatan",
           "pertemuan", "perpisahan", "pertengkaran", "perdebatan",
           "wawancara", "lamaran", "pertunangan", "perkawinan",
           "jenius", "tersembunyi", "tersimpan", "sembunyi",
           "tersangka", "tertuduh", "tersingkir", "terbuang",
           "diusir", "dipermalukan", "dikhianati", "ditipu",
           "seorang", "sangat", "amat", "begitu", "sangatlah"],
    "en": ["the", "and", "you", "that", "this", "with", "for", "not",
           "have", "from", "love", "my", "her", "his", "she", "he",
           "billionaire", "ceo", "wife", "husband", "baby", "secret",
           "revenge", "divorce", "mrs", "mr", "was", "were", "are",
           "will", "would", "could", "should", "been", "being",
           "they", "them", "their", "our", "your", "its", "it",
           "what", "who", "when", "where", "why", "how", "all",
           "but", "if", "then", "than", "so", "just", "only",
           "never", "always", "again", "still", "even", "very",
           "married", "marry", "wedding", "pregnant", "child",
           "daughter", "son", "mother", "father", "sister", "brother",
           "family", "house", "home", "money", "rich", "poor",
           "boss", "company", "business", "war", "fight", "kill",
           "dead", "death", "life", "live", "heart", "kiss",
           "mistress", "affair", "cheat", "betray", "liar", "truth",
           "millionaire", "heiress", "maid", "nanny", "twins",
           "amnesia", "rebirth", "second chance", "contract",
           "papers", "wedding", "night", "first", "last", "new"],
    "es": ["el", "la", "de", "que", "y", "en", "los", "las", "por",
           "para", "con", "una", "amor", "mi", "es", "su", "del",
           "como", "más", "pero", "todo", "vida", "casa", "dinero",
           "familia", "madre", "padre", "hermano", "hermana",
           "esposa", "esposo", "hija", "hijo", "matrimonio",
           "divorcio", "traición", "venganza", "secreto", "jefe",
           "empresa", "millonario", "rico", "pobre"],
    "pt": ["o", "a", "de", "que", "e", "do", "da", "em", "para",
           "com", "um", "uma", "amor", "meu", "os", "as", "seu",
           "sua", "como", "mais", "mas", "tudo", "vida", "casa",
           "dinheiro", "família", "mãe", "pai", "irmão", "irmã",
           "esposa", "esposo", "filha", "filho", "casamento",
           "divórcio", "traição", "vingança", "segredo", "chefe"],
    "tl": ["ang", "ng", "sa", "na", "at", "si", "ko", "mo",
           "pag", "mga", "ako", "ikaw", "mahal", "ni", "kay",
           "para", "hindi", "may", "wala", "anak", "asawa",
           "pamilya", "pera", "bahay", "ina", "ama", "kapatid"],
    "vi": ["của", "và", "là", "có", "không", "trong", "người",
           "tình", "yêu", "em", "anh", "một", "hai", "nhà",
           "tiền", "gia đình", "mẹ", "cha", "vợ", "chồng"],
}

# Unicode 区间 → 语言（明确字符集优先，命中即定）
_SCRIPT: list[tuple[str, str, str]] = [
    (r"[\u3040-\u309f\u30a0-\u30ff]", "ja", "日语"),
    (r"[\uac00-\ud7af\u1100-\u11ff]", "ko", "韩语"),
    (r"[\u4e00-\u9fff]", "zh", "中文"),
    (r"[\u0e00-\u0e7f]", "th", "泰语"),
    (r"[\u0600-\u06ff\u0750-\u077f]", "ar", "阿拉伯语"),
    (r"[\u0900-\u097f]", "hi", "印地语"),
]


def detect(text: str) -> dict:
    """识别单条文本的语言。

    返回:
        {"lang": "id", "name": "印尼语", "confidence": 0.9, "by": "stopwords"}

    script=字符集命中（最可靠，confidence 1.0）
    stopwords=停用词打分
    unknown=判不出来（调用方按「不筛」处理）
    """
    t = (text or "").strip()
    if not t:
        return {"lang": "unknown", "name": LANGS["unknown"],
                "confidence": 0.0, "by": "empty"}

    # ① 字符集
    for pat, code, name in _SCRIPT:
        if re.search(pat, t):
            return {"lang": code, "name": name, "confidence": 1.0,
                    "by": "script"}

    # ② 拉丁字母：停用词打分
    low = " " + t.lower() + " "
    words = re.findall(r"[a-zà-ú]+", low)
    if not words:
        return {"lang": "unknown", "name": LANGS["unknown"],
                "confidence": 0.0, "by": "no-latin"}

    scores: dict[str, float] = {}
    for code, stops in _STOPWORDS.items():
        hit = 0
        for w in words:
            if w in stops:
                hit += 1
        # 长词（戏剧专有词）权重更高
        for s in stops:
            if len(s) >= 5 and s in low:
                hit += 1
        if hit:
            scores[code] = hit

    if not scores:
        return {"lang": "unknown", "name": LANGS["unknown"],
                "confidence": 0.0, "by": "no-hit"}

    best = max(scores.items(), key=lambda kv: kv[1])
    total = sum(scores.values())
    conf = round(min(1.0, best[1] / max(1.0, total)), 2)
    # 分数太低（只有 1 个弱命中）就别硬判
    if best[1] < 2:
        return {"lang": "unknown", "name": LANGS["unknown"],
                "confidence": conf, "by": "weak",
                "scores": scores}
    return {"lang": best[0], "name": LANGS[best[0]],
            "confidence": conf, "by": "stopwords", "scores": scores}


def detect_drama(item: dict) -> dict:
    """对一部剧判语言（标题权重更高，描述辅助）。"""
    title = str(item.get("title") or "")
    desc = str(item.get("desc") or item.get("description") or "")[:200]

    r1 = detect(title)
    if r1["lang"] != "unknown":
        return {**r1, "source": "title"}
    if desc:
        r2 = detect(desc)
        if r2["lang"] != "unknown":
            return {**r2, "source": "desc"}
    return r1


def matches(lang: str, want: list[str], mode: str = "include") -> bool:
    """这部剧的语言是否符合筛选要求。

    want 为空 → 一律通过（不筛选）
    mode=include → lang 必须在 want 里；unknown 时**放行**（不误杀）
    mode=exclude → lang 不能在 want 里；unknown 时也放行
    """
    if not want:
        return True
    if lang == "unknown":
        return True      # 判不出来就不拦，宁可多抓也不漏
    if mode == "exclude":
        return lang not in want
    return lang in want


def all_langs() -> list[dict]:
    """可选语言清单（前端渲染用）。"""
    return [{"code": k, "name": v} for k, v in LANGS.items()
            if k != "unknown"]
