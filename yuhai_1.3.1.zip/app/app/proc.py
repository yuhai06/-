"""子进程静默启动工具——避免打包后每次调用都弹黑框。

Windows 上 `subprocess.run/Popen` 默认会给控制台程序新建窗口；
打包成 windowed exe 后，这些窗口会一个个闪出来，很难看。
统一走这个模块拿 kwargs，保证所有外部命令都在后台跑。
"""
from __future__ import annotations

import os
import subprocess


def kw() -> dict:
    """给 subprocess.run / Popen 用的静默参数。"""
    if os.name == "nt":
        return {"creationflags": subprocess.CREATE_NO_WINDOW}
    return {}


def run(cmd, **kwargs):
    """subprocess.run 的静默版（默认带 capture_output）。"""
    kw_ = kw()
    kw_.update(kwargs)
    if "capture_output" not in kw_ and "stdout" not in kw_:
        kw_["capture_output"] = True
    return subprocess.run(cmd, **kw_)


def popen(cmd, **kwargs):
    """subprocess.Popen 的静默版。"""
    kw_ = kw()
    kw_.update(kwargs)
    return subprocess.Popen(cmd, **kw_)


def no_window_flags() -> int:
    """直接拿 creationflags 给别处用。"""
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
