"""统一路径解析 —— 换机器/换目录不用改代码。

优先级（高 → 低）：
    ① 环境变量（YUHAI_WORKSPACE / YUHAI_TOOLS / YUHAI_LIBRARY /
       YUHAI_OUTPUT / YUHAI_SOURCE_ROOTS / YUHAI_FONTS / YUHAI_AUDIO / PD_PROXY）
    ② 数据目录下的 config.json（用户可在「设置」里改，界面写入）
    ③ 自动发现（从可执行文件/代码位置向上找工作区标志）
    ④ 平台默认（Windows 用 %USERPROFILE% 下的固定名，其它系统用 ~ 下同名目录）

设计原则：任何路径都返回 Path，且**不保证存在**；调用方需要时自己 mkdir。
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------- 基础

IS_WIN = os.name == "nt"
IS_FROZEN = bool(getattr(sys, "frozen", False))


def _exe_dir() -> Path:
    """打包后：exe 所在目录；开发时：仓库根（backend 的上级）。"""
    if IS_FROZEN:
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _data_dir() -> Path:
    env = os.environ.get("YUHAI_DATA_DIR")
    if env:
        return Path(env)
    if IS_FROZEN:
        base = os.environ.get("LOCALAPPDATA") or str(Path.home())
        return Path(base) / "YuhaiWorkbench"
    return _exe_dir() / "data"


DATA_DIR = _data_dir()

# 工作区标志文件：有这些之一就认为是工作区根
_WORKSPACE_MARKS = ("tools", "素材库", "yuhai-workbench", "短剧切片完整流程.md")

# 盘根、系统目录不能当工作区
_BAD_WORKSPACE = {
    "c:\\", "d:\\", "e:\\", "f:\\", "g:\\",
    "c:\\windows", "c:\\program files", "c:\\program files (x86)",
    "c:\\users", "c:\\programdata",
}


def _is_bad_ws(p: Path) -> bool:
    s = str(p).lower().rstrip("\\") + "\\"
    if s in _BAD_WORKSPACE:
        return True
    # 盘根：D:\ 这种只有 3 个字符
    try:
        if p.parent == p:
            return True
        if len(str(p).rstrip("\\")) <= 3 and str(p)[1:3] == ":\\":
            return True
    except Exception:
        pass
    return False


def _user_cfg() -> dict[str, Any]:
    p = DATA_DIR / "config.json"
    if not p.exists():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8-sig"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


_CFG = _user_cfg()


def _cfg_get(*keys: str) -> str:
    """从 config.json 取第一个命中的键（大小写不敏感）。"""
    lower = {k.lower(): v for k, v in _CFG.items()}
    for k in keys:
        v = lower.get(k.lower())
        if isinstance(v, str) and v.strip():
            return v.strip()
        if isinstance(v, list) and v:
            return ";".join(str(x) for x in v)
    return ""


def _env_or_cfg(env_key: str, *cfg_keys: str) -> str:
    v = os.environ.get(env_key, "").strip()
    if v:
        return v
    return _cfg_get(*cfg_keys)


# ---------------------------------------------------------------- 工作区

def _workspace_is_shared(p: Path) -> bool:
    """这个目录是不是「很多程序共用的公共目录」（桌面/文档/下载等）。

    这类目录不能当工作区，否则素材库会散落一地。
    """
    low = str(p).lower().replace("/", "\\").rstrip("\\")
    for bad in ("\\desktop", "\\documents", "\\downloads", "\\pictures",
                "\\videos", "\\music", "\\onedrive", "\\appdata",
                "\\local", "\\roaming", "\\temp", "\\tmp"):
        if low.endswith(bad):
            return True
    return False


def workspace() -> Path:
    """工作区根（放 tools / 素材 / 素材库 / 处理好素材 的那一层）。

    优先找**已有素材类目录**的位置，其次看标志文件；
    盘根、系统目录、桌面/文档这类公共目录一律排除。
    """
    v = _env_or_cfg("YUHAI_WORKSPACE", "workspace", "workspace_root", "工作区")
    if v:
        return Path(v)

    start = _exe_dir()

    # ① 从 exe 目录向上找「已经有素材类目录」的位置（最可靠）
    for base in [start, *start.parents][:6]:
        if _is_bad_ws(base) or _workspace_is_shared(base):
            continue
        for name in ("素材库", "素材", "处理好素材"):
            try:
                if (base / name).is_dir():
                    return base
            except OSError:
                continue

    # ② 找标志文件
    for base in [start, *start.parents][:6]:
        if _is_bad_ws(base) or _workspace_is_shared(base):
            continue
        for mark in _WORKSPACE_MARKS:
            try:
                if (base / mark).exists():
                    return base
            except OSError:
                continue

    # ③ 兜底：exe 所在目录（打包后是 <root>\雨海工作台\）
    #    不用父目录，因为父目录可能是盘根或桌面这类"共享大目录"。
    return start


WORKSPACE = workspace()


def _first_existing(cands: list[Path], fallback: Path) -> Path:
    for c in cands:
        try:
            if c.exists():
                return c
        except OSError:
            continue
    return fallback


# ---------------------------------------------------------------- 工具脚本

def tools_dir() -> Path:
    """切片/抓取脚本目录（pipeline2.py 所在）。"""
    v = _env_or_cfg("YUHAI_TOOLS", "tools", "tools_dir", "工具目录")
    if v:
        return Path(v)
    cands = [
        WORKSPACE / "tools",
        _exe_dir() / "tools",
        _exe_dir() / "_internal" / "tools",       # 随包分发
        _exe_dir().parent / "tools",
        DATA_DIR / "tools",
    ]
    for c in cands:
        if (c / "pipeline2.py").exists() or (c / "pd_drama.py").exists():
            return c
    return _first_existing(cands, cands[0])


def state_dir() -> Path:
    return tools_dir() / "_state"


# ---------------------------------------------------------------- 素材

def library_root() -> Path:
    """素材库根：按 日期/剧名/文件 三层，发布完删。"""
    v = _env_or_cfg("YUHAI_LIBRARY", "library", "library_root", "素材库")
    if v:
        return Path(v)
    return WORKSPACE / "素材库"


def output_root() -> Path:
    """成片根目录（单集_日期 / 精品混剪_日期）。

    优先选**已经有成片**的目录，避免换环境后突然找不到历史产出。
    盘根本身不能当工作区，但「盘根下的某个具体目录」是合法的
    （旧版本常把成片放在 <盘>:\处理好素材）。
    """
    v = _env_or_cfg("YUHAI_OUTPUT", "output", "output_root", "成片目录")
    if v:
        return Path(v)
    cands = [WORKSPACE / "处理好素材", WORKSPACE / "成片"]
    # 同级历史位置：旧版本常把成片放在 <工作区的上级>\处理好素材。
    # 只有**该目录真的存在**时才纳入候选，否则新机器会跑到盘根上去。
    par = WORKSPACE.parent
    if not _is_bad_ws(WORKSPACE):
        hist = par / "处理好素材"
        try:
            if hist.is_dir() and hist != cands[0]:
                cands.insert(0, hist)
        except OSError:
            pass
    cands.append(DATA_DIR / "output")

    # 有 mp4 的优先
    for c in cands:
        try:
            if c.is_dir():
                for sub in c.iterdir():
                    if sub.is_dir() and any(sub.rglob("*.mp4")):
                        return c
        except OSError:
            continue
    # 其次存在的
    for c in cands:
        if c.exists():
            return c
    return cands[0]


def source_roots() -> list[Path]:
    """源素材可能存在的所有位置（按优先级）。"""
    v = _env_or_cfg("YUHAI_SOURCE_ROOTS", "source_roots", "源素材目录")
    if v:
        return [Path(p) for p in v.split(";") if p.strip()]
    cands = [
        WORKSPACE / "素材",
        library_root() / "原始素材",
        WORKSPACE / "视频素材",
    ]
    # 同级历史位置（工作区不是盘根时才算）
    if not _is_bad_ws(WORKSPACE.parent):
        cands.append(WORKSPACE.parent / "视频素材")
    # 去重（保持顺序）
    out: list[Path] = []
    for c in cands:
        if c not in out:
            out.append(c)
    return out


def asset_roots() -> list[Path]:
    """素材库页面要扫的根（素材库 + 成片）。"""
    v = _env_or_cfg("YUHAI_ASSET_ROOTS", "asset_roots")
    if v:
        return [Path(p) for p in v.split(";") if p.strip()]
    return [library_root(), output_root()]


# ---------------------------------------------------------------- 字体 / 音频

def _dsh_home() -> Path:
    return Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))


def fonts_dir() -> Path:
    """字幕/CTA 用的字体目录。"""
    v = _env_or_cfg("YUHAI_FONTS", "fonts", "fonts_dir", "字体目录")
    if v:
        return Path(v)
    cands = [
        _dsh_home() / "fonts",
        _exe_dir() / "assets" / "fonts",          # 随包分发
        _exe_dir() / "_internal" / "assets" / "fonts",
        WORKSPACE / "assets" / "fonts",
        DATA_DIR / "assets" / "fonts",
        Path("C:/Windows/Fonts") if IS_WIN else Path("/usr/share/fonts"),
    ]
    return _first_existing(cands, cands[0])


def audio_dir() -> Path:
    """BGM / 音效目录。"""
    v = _env_or_cfg("YUHAI_AUDIO", "audio", "audio_dir", "音频目录")
    if v:
        return Path(v)
    cands = [
        _dsh_home() / "audio",
        _exe_dir() / "assets" / "audio",          # 随包分发
        _exe_dir() / "_internal" / "assets" / "audio",
        WORKSPACE / "assets" / "audio",
        DATA_DIR / "assets" / "audio",
    ]
    return _first_existing(cands, cands[0])


# ---------------------------------------------------------------- 二进制

def ffmpeg() -> tuple[Path | None, Path | None]:
    """返回 (ffmpeg, ffprobe)。优先内置，其次 PATH。"""
    names = ("ffmpeg.exe", "ffprobe.exe") if IS_WIN else ("ffmpeg", "ffprobe")
    dirs = [
        _exe_dir() / "bin",
        _exe_dir() / "_internal" / "bin",
        Path(__file__).resolve().parent.parent / "bin",
        tools_dir() / "bin",
    ]
    ff = fp = None
    for d in dirs:
        a, b = d / names[0], d / names[1]
        if a.exists() and ff is None:
            ff = a
        if b.exists() and fp is None:
            fp = b
    if ff is None:
        w = shutil.which("ffmpeg")
        ff = Path(w) if w else None
    if fp is None:
        w = shutil.which("ffprobe")
        fp = Path(w) if w else None
    return ff, fp


def curl() -> Path | None:
    w = shutil.which("curl") or shutil.which("curl.exe")
    if w:
        return Path(w)
    for p in (Path("C:/Windows/System32/curl.exe"), Path("/usr/bin/curl")):
        if p.exists():
            return p
    return None


# ---------------------------------------------------------------- 网络

def proxy() -> str:
    """抓取用代理。没有代理也不报错，返回空串表示直连。"""
    v = _env_or_cfg("PD_PROXY", "proxy", "grab_proxy", "代理")
    if v:
        return v
    # 常见本地代理端口，探到哪个用哪个
    import socket
    for port in (7897, 7890, 10809, 1080, 8889):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.35):
                return f"http://127.0.0.1:{port}"
        except OSError:
            continue
    return ""


# ---------------------------------------------------------------- 汇总

@lru_cache(maxsize=1)
def snapshot() -> dict[str, Any]:
    """当前所有关键路径 + 存在性，供环境自检和设置页用。"""
    ff, fp = ffmpeg()
    return {
        "platform": {
            "os": sys.platform,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "frozen": IS_FROZEN,
            "exeDir": str(_exe_dir()),
        },
        "dataDir": str(DATA_DIR),
        "workspace": str(WORKSPACE),
        "tools": str(tools_dir()),
        "state": str(state_dir()),
        "library": str(library_root()),
        "output": str(output_root()),
        "sourceRoots": [str(p) for p in source_roots()],
        "assetRoots": [str(p) for p in asset_roots()],
        "fonts": str(fonts_dir()),
        "audio": str(audio_dir()),
        "ffmpeg": str(ff) if ff else "",
        "ffprobe": str(fp) if fp else "",
        "curl": str(curl()) if curl() else "",
        "proxy": proxy(),
        "configFile": str(DATA_DIR / "config.json"),
        "exists": {
            "tools": tools_dir().exists(),
            "library": library_root().exists(),
            "output": output_root().exists(),
            "fonts": fonts_dir().exists(),
            "audio": audio_dir().exists(),
            "ffmpeg": bool(ff),
        },
    }


def ensure_dirs() -> list[str]:
    """创建所有该存在的目录，返回创建了哪些。"""
    made = []
    for p in (DATA_DIR, library_root(), output_root(), source_roots()[0],
              DATA_DIR / "logs", DATA_DIR / "cache"):
        try:
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
                made.append(str(p))
        except OSError:
            continue
    return made
