"""短剧切片 API：严格对齐《短剧切片完整流程.md》。"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import slicing as sl
from app import proc

log = logging.getLogger("yuhai.api.slice")
router = APIRouter(tags=["slice"])


@router.get("/slice/env")
async def env():
    """检查流程环境：脚本 / 模型 / ffmpeg / GPU。"""
    import shutil
    from app.services import video_maker as vm

    t = sl.tools_dir()
    scripts = ["pipeline2.py", "transcribe_audio.py", "voice_check3.py",
               "classify.py", "score_lines2.py", "cut_ep2.py",
               "plan_from_tension.py", "render_plan.py", "mark_done.py"]
    have = {s: (t / s).exists() for s in scripts}

    # faster-whisper
    fw = False
    try:
        import faster_whisper  # noqa: F401
        fw = True
    except Exception:
        pass

    # GPU
    gpu = ""
    try:
        r = proc.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10,
                           encoding="utf-8", errors="replace")
        if r.returncode == 0:
            gpu = (r.stdout or "").strip().split("\n")[0][:60]
    except Exception:
        pass

    # NVENC
    nvenc = False
    try:
        r = proc.run([vm.ffmpeg_path(), "-hide_banner", "-encoders"],
                           capture_output=True, text=True, timeout=20,
                           encoding="utf-8", errors="replace")
        nvenc = "h264_nvenc" in (r.stdout or "")
    except Exception:
        pass

    return {
        "toolsDir": str(t),
        "stateDir": str(sl.state_dir()),
        "sourceDir": str(sl.source_dir()),
        "outRoot": str(sl.out_root()),
        "scripts": have,
        "allScripts": all(have.values()),
        "fasterWhisper": fw,
        "ffmpeg": vm.env_check(),
        "gpu": gpu,
        "nvenc": nvenc,
        "ok": all(have.values()) and fw,
    }


@router.get("/slice/dramas")
async def dramas():
    """列出所有可处理的剧 + 每部进行到哪步。"""
    return {"items": sl.list_dramas(), "count": len(sl.list_dramas())}


@router.get("/slice/status")
async def status(drama: str):
    """单部剧的详细状态（含中间产物）。"""
    st = sl.drama_status(drama)
    # 附带张力分布（前 30 句）
    tn = sl.read_tension(drama)
    lines = tn.get("lines") or tn.get("scored") or []
    st["tensionTop"] = sorted(
        [{"ep": x.get("ep"), "text": (x.get("text") or "")[:80],
          "score": x.get("score") or x.get("tension") or 0}
         for x in lines], key=lambda x: -(x["score"] or 0))[:30]
    # 计划阶段
    pl = sl.read_plan(drama)
    st["planStages"] = pl.get("stages") or []
    return st


class RunReq(BaseModel):
    drama: str
    single: bool = True
    premium: bool = True
    model: str = "small"
    target: float = 45
    maxEp: int = 0
    episodes: list[str] = []


@router.post("/slice/run")
async def run(req: RunReq):
    """跑完整流程（转录→检测→分类→打分→单集→精品）。"""
    if not req.drama.strip():
        raise HTTPException(400, "剧名不能为空")
    src = sl.find_drama_dir(req.drama)
    if not src:
        from app import paths as _p
        main_src = _p.source_roots()[0]
        raise HTTPException(400,
            f"源素材不存在：{req.drama}\n"
            f"已查找：{', '.join(str(r) for r in sl.source_roots())}\n"
            f"可用「素材抓取」先抓片，或手动放到 {main_src}\\{req.drama}\\EP01.mp4")

    job_id = "job-" + uuid.uuid4().hex[:12]
    names = ["① 台词转录", "② 语音检测", "③ 类型判定",
             "④ 张力打分", "⑤ 单集出片", "⑥ 精品混剪"]
    steps = [{"name": n, "state": "wait", "note": ""} for n in names]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "slice", f"切片 {req.drama}", "queued", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))
    asyncio.create_task(sl.run_pipeline(job_id, req.drama, req.model_dump()))
    return {"ok": True, "jobId": job_id,
            "note": "转录最慢（20集约 43 秒 GPU 加速）"}


class StepReq(BaseModel):
    drama: str
    ep: str = ""
    target: float = 45
    model: str = "small"


@router.post("/slice/step/{name}")
async def run_step(name: str, req: StepReq):
    """单独跑某一步（调试用）。"""
    steps = {
        "transcribe": lambda: sl.step_transcribe("", req.drama, req.model),
        "voice": lambda: sl.step_voice("", req.drama),
        "classify": lambda: sl.step_classify("", req.drama),
        "tension": lambda: sl.step_tension("", req.drama),
        "single": lambda: sl.step_single("", req.drama,
                                         [req.ep] if req.ep else None,
                                         req.target),
        "premium": lambda: sl.step_premium("", req.drama),
    }
    if name not in steps:
        raise HTTPException(400, f"未知步骤 {name}")
    r = await asyncio.to_thread(steps[name])
    return r


@router.get("/slice/verify")
async def verify(path: str):
    """校验成片：规格 + 静音段。"""
    if not Path(path).exists():
        raise HTTPException(404, "文件不存在")
    out = await asyncio.to_thread(sl.verify_output, path)
    sil = await asyncio.to_thread(sl.check_audio_guard, path)
    out["silence"] = sil
    return out


@router.get("/slice/check-dialogue")
async def check_dialogue(drama: str, ep: str = "", plan: str = ""):
    """台词完整性 + 无重叠校验（通用版 chk_full2.py）。"""
    return await asyncio.to_thread(sl.check_dialogue_complete, drama, ep, plan)


@router.get("/slice/audio-guard")
async def audio_guard(path: str, minSilence: float = 2.0):
    """静音段检查（通用版 audio_guard.py）。"""
    if not Path(path).exists():
        raise HTTPException(404, "文件不存在")
    return await asyncio.to_thread(sl.check_audio_guard, path, minSilence)


# ---------------- 环境自检 / 自动安装 ----------------
@router.get("/env/full")
async def env_full():
    """全环境自检（换电脑时先跑这个）。"""
    from app.services import envcheck
    return await asyncio.to_thread(envcheck.full_check)


@router.post("/env/install")
async def env_install(what: str = "all"):
    """自动安装缺失项。

    what: all | python | ffmpeg
    """
    from app.services import envcheck
    if what == "python":
        return await asyncio.to_thread(envcheck.install_python)
    if what == "ffmpeg":
        return await asyncio.to_thread(envcheck.install_ffmpeg)
    return await asyncio.to_thread(envcheck.install_all)


# ---------------- 路径配置（跨环境适配） ----------------
PATH_KEYS = {
    "workspace": ("YUHAI_WORKSPACE", "工作区根目录", "workspace"),
    "tools": ("YUHAI_TOOLS", "切片/抓取脚本目录", "tools"),
    "library": ("YUHAI_LIBRARY", "素材库目录", "library"),
    "output": ("YUHAI_OUTPUT", "成片输出目录", "output"),
    "source_roots": ("YUHAI_SOURCE_ROOTS", "源素材目录（多个用 ; 分隔）", "sourceRoots"),
    "fonts": ("YUHAI_FONTS", "字体目录", "fonts"),
    "audio": ("YUHAI_AUDIO", "BGM/音效目录", "audio"),
    "proxy": ("PD_PROXY", "抓取代理", "proxy"),
}


@router.get("/slice/sources")
async def slice_sources():
    """切片用源素材目录（可自定义，跨机器可指向别处的素材）。

    返回当前生效的目录 + 候选目录（带每部剧数量和是否可切片）。
    """
    from app import paths as _p
    import os
    cur_env = os.environ.get("YUHAI_SOURCE_ROOTS", "")
    cfg_val = ""
    try:
        cfg_val = str(_p._CFG.get("source_roots") or "")
    except Exception:
        pass
    roots = [str(x) for x in _p.source_roots()]
    items = []
    for r in roots:
        from pathlib import Path as _P
        p = _P(r)
        n = 0
        ok = False
        try:
            if p.is_dir():
                ok = True
                n = sum(1 for d in p.iterdir()
                        if d.is_dir() and list(d.glob("*.mp4")))
        except OSError:
            pass
        items.append({"path": r, "exists": ok, "dramaCount": n})
    return {
        "roots": roots,
        "items": items,
        "source": "环境变量" if cur_env else ("配置文件" if cfg_val else "自动发现"),
        "configFile": str(_p.DATA_DIR / "config.json"),
    }


class SourceReq(BaseModel):
    roots: list[str] = []


@router.post("/slice/sources")
async def slice_sources_save(req: SourceReq):
    """保存切片源素材目录（写 config.json，重启生效）。"""
    from app import paths as _p
    from app.config import settings
    from pathlib import Path as _P
    cleaned = []
    for r in (req.roots or []):
        s = str(r or "").strip()
        if not s:
            continue
        p = _P(s)
        try:
            p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return {"ok": False, "error": f"目录不可用：{s} — {e}"}
        if s not in cleaned:
            cleaned.append(s)
    if cleaned:
        settings.save_user_config({"source_roots": cleaned})
        try:
            _p._CFG["source_roots"] = cleaned
            _p.snapshot.cache_clear()
        except Exception:
            pass
    else:
        settings.save_user_config({"source_roots": ""})
        try:
            _p._CFG.pop("source_roots", None)
            _p.snapshot.cache_clear()
        except Exception:
            pass
    db.log_event("info", "slice", f"切片源素材目录改为 {cleaned or '默认'}")
    return {"ok": True, "roots": cleaned,
            "note": "已保存；重启程序后所有模块生效"}


@router.get("/env/paths")
async def env_paths():
    """当前生效的全部路径（含来源：env / config / auto）。"""
    from app import paths
    snap = paths.snapshot()
    cfg = paths._CFG
    cfg_lower = {k.lower() for k in cfg}
    items = []
    for key, (env_key, label, snap_key) in PATH_KEYS.items():
        env_val = os.environ.get(env_key, "")
        cfg_val = ""
        for ck in (key, f"{key}_root", label):
            if ck.lower() in cfg_lower:
                real = [k for k in cfg if k.lower() == ck.lower()][0]
                v = cfg[real]
                cfg_val = ";".join(map(str, v)) if isinstance(v, list) else str(v)
                break
        eff = snap.get(snap_key, "")
        if isinstance(eff, list):
            eff = ";".join(eff)
        items.append({
            "key": key, "label": label, "envKey": env_key,
            "envValue": env_val, "configValue": cfg_val,
            "value": eff,
            "source": "环境变量" if env_val else ("配置文件" if cfg_val else "自动发现"),
        })
    return {"items": items, "configFile": snap["configFile"],
            "snapshot": snap}


@router.post("/env/paths")
async def env_paths_save(patch: dict):
    """保存路径覆盖到 config.json（重启后生效）。"""
    from app import paths
    from app.config import settings
    clean = {}
    for k, v in (patch or {}).items():
        if k not in PATH_KEYS:
            continue
        if isinstance(v, list):
            v = ";".join(str(x).strip() for x in v if str(x).strip())
        v = str(v or "").strip()
        if v:
            clean[k] = v
        else:
            clean[k] = ""      # 空 = 清除该覆盖
    settings.save_user_config(clean)
    # 同步更新已加载的模块级常量（不重启也能看到效果）
    try:
        paths._CFG.update({k: v for k, v in clean.items() if v})
        for k, v in clean.items():
            if not v:
                paths._CFG.pop(k, None)
        paths.snapshot.cache_clear()
    except Exception:
        pass
    return {"ok": True, "saved": clean,
            "note": "已写入 config.json；重启程序后所有模块生效",
            "configFile": str(paths.DATA_DIR / "config.json")}


@router.post("/env/ensure-dirs")
async def env_ensure_dirs():
    """按当前路径创建缺失目录。"""
    from app import paths
    return {"ok": True, "created": paths.ensure_dirs(),
            "snapshot": paths.snapshot()}


@router.get("/slice/types")
async def types():
    """7 种剧型定义（含 BGM / 节奏 / 强特征）。"""
    return {"items": [
        {"id": k, **v} for k, v in sl.DRAMA_TYPES.items()
    ]}


@router.get("/slice/constraints")
async def constraints():
    """硬性约束清单。"""
    return {
        "constraints": sl.CONSTRAINTS,
        "stages": sl.STAGES,
        "rules": [
            "① 台词完整不截断（冲突丢低分段）",
            "② 段间零重叠（三道防线）",
            "③ pad 0.15s",
            "④ 不用字幕 OCR 对齐，用 whisper 时间戳",
            "⑤ 过滤 <1.5s 的段",
            "⑥ 单段 > target×1.4 拆单句",
            "⑦ 时长容差 ±6s",
            "⑧ 段数不足放宽到 max_lines=5",
            "⑨ 成片 <30s 直接不生成",
        ],
    }


@router.get("/slice/jobs")
async def jobs(limit: int = 50):
    rows = db.q("SELECT * FROM jobs WHERE kind='slice' ORDER BY created_at DESC"
                " LIMIT ?", (min(limit, 200),))
    for r in rows:
        for k in ("steps", "payload", "result"):
            if r.get(k):
                try:
                    r[k] = json.loads(r[k])
                except Exception:
                    pass
    return {"items": rows}


@router.post("/slice/mark-done")
async def mark_done(drama: str, deleteSource: bool = False):
    """标记完成 + 可选删原始素材（一部剧 3-4.5GB）。"""
    r = await asyncio.to_thread(sl._run, "mark_done.py",
                                [drama] + ([] if deleteSource else ["--no-delete"]))
    deleted = False
    if deleteSource:
        src = sl.source_dir() / drama
        if src.exists():
            import shutil
            shutil.rmtree(src, ignore_errors=True)
            deleted = True
    return {"ok": r["ok"], "deleted": deleted,
            "output": "\n".join(r["lines"][-5:])[:400]}
