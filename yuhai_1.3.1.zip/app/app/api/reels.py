"""ReelsPublisher 内核发布 API（批量发布，走官方 worker）。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.services import reels as rl

log = logging.getLogger("yuhai.api.reels")
router = APIRouter(tags=["reels"])


@router.get("/reels/status")
async def reels_status():
    """内核可用性 + 已规划主页。"""
    info = rl.available()
    return {**info, "pages": rl.plan_pages()}


@router.post("/reels/check")
async def reels_check():
    """检查每个环境是否有可用的 Meta 工作标签。"""
    r = await rl.check_browsers()
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "检查失败")
    return r


@router.get("/reels/materials")
async def reels_materials(directory: str = ""):
    """扫描素材目录（不启动发布）。"""
    from app import paths
    d = directory or str(paths.output_root())
    r = await rl.scan_materials(d)
    if not r.get("ok"):
        raise HTTPException(500, r.get("error") or "扫描失败")
    return {"directory": d,
            "total": r.get("total") or 0,
            "folderCount": r.get("folderCount") or 0,
            "groups": r.get("groups") or [],
            "sampleTitle": r.get("sampleTitle") or "",
            "debug": r}


class ReelsPublishReq(BaseModel):
    directory: str = ""
    description: str = ""          # 标题模板（含链接占位）
    linkPool: str = ""             # 链接池，每行一个
    clipsPerPage: int = 1
    concurrency: int = 1
    publishMode: str = "merge"     # merge | folders
    browserIds: list[str] = []


@router.post("/reels/publish")
async def reels_publish(req: ReelsPublishReq):
    """启动批量发布（后台跑，进度走 jobs）。"""
    from app import paths

    info = rl.available()
    if not info.get("ok"):
        raise HTTPException(400, "ReelsPublisher 内核不可用")

    directory = req.directory or str(paths.output_root())
    description = req.description.strip()
    if not description:
        # 默认文案：标题 + 链接（FB 模式，无标签）
        from app.services import platform_cfg as pc
        from app.services import caption as cap
        link = ""
        try:
            lk = cap.pick_link("")
            link = (lk or {}).get("url") or ""
        except Exception:
            pass
        description = f"{cap.REFERENCE_TITLE}\n\n{link}" if link else cap.REFERENCE_TITLE

    link_pool = req.linkPool.strip()

    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": "检查浏览器", "state": "wait", "note": ""},
             {"name": "扫描素材", "state": "wait", "note": ""},
             {"name": "执行发布", "state": "wait", "note": ""}]
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "reels", f"Reels 批量发布 · {req.clipsPerPage} 条/主页",
             "queued", 0, json.dumps(steps, ensure_ascii=False),
             json.dumps(req.model_dump(), ensure_ascii=False), now_iso()))

    async def _bg() -> None:
        def prog(msg: str) -> None:
            # 把 progress 写进 jobs 的 steps
            cur = db.q1("SELECT steps FROM jobs WHERE id=?", (job_id,))
            try:
                arr = json.loads((cur or {}).get("steps") or "[]")
            except Exception:
                arr = steps
            if arr:
                arr[-1]["note"] = (msg or "")[:60]
                db.exec("UPDATE jobs SET steps=? WHERE id=?",
                        (json.dumps(arr, ensure_ascii=False), job_id))
        try:
            db.exec("UPDATE jobs SET status='running',started_at=? WHERE id=?",
                    (now_iso(), job_id))
            steps[0]["state"] = "done"
            r = await rl.publish(
                directory=directory,
                description=description,
                link_pool=link_pool,
                clips_per_page=req.clipsPerPage,
                concurrency=req.concurrency,
                publish_mode=req.publishMode,
                browser_ids=req.browserIds,
                on_progress=prog)
            ok = bool(r.get("ok"))
            value = r.get("result") or r
            db.exec("UPDATE jobs SET status=?,result=?,progress=100,ended_at=? WHERE id=?",
                    ("done" if ok else "failed",
                     json.dumps(value, ensure_ascii=False, default=str),
                     now_iso(), job_id))
            db.log_event("ok" if ok else "err", "reels",
                         f"Reels 批量发布{'完成' if ok else '失败'}")
        except Exception as e:
            db.exec("UPDATE jobs SET status='failed',error=?,ended_at=? WHERE id=?",
                    (str(e)[:400], now_iso(), job_id))

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id, "directory": directory,
            "clipsPerPage": req.clipsPerPage,
            "note": "后台执行，进度看任务列表；素材发布成功后自动删除"}
