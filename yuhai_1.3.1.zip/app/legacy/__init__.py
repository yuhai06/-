﻿"""旧版 PineDrama 素材抓取（legacy）

保留原因：
    · mcp_server.py 的 grab_* 工具仍在使用
    · mcp_tools_full.py 依赖 grab.list_hot_fast / search_fast / run / download
    · 前端入口已移除，只作为 MCP 工具保留

新功能请用 app.services.dl（短剧下载，多站点）。
"""