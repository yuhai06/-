# -*- coding: utf-8 -*-
"""
mcp_tools_full.py — 全功能 MCP 工具（覆盖工作台 245 个端点的主要能力）

按用户要求，Agent 要能做：
  · 创建号 / 主页
  · 授权（主页授权给号）
  · 发布视频（含 Reels）
  · 查失败原因

命名规范：<模块>_<动作>
  账号   account_*
  主页   page_*
  授权   authz_*
  环境   env_*
  抓取   grab_*
  切片   slice_*
  素材   library_*
  发布   publish_*
  排期   schedule_*
  数据   data_*
  邮箱   mail_*
  系统   system_*
  记忆   memory_*

设计：直接调用 service 层 / API 函数，不绕 HTTP（避免端口依赖）。
"""
from __future__ import annotations

import json
import logging

log = logging.getLogger("yuhai.mcp.full")

# 由 mcp_server 传入注册器
def register(mcp):
    """把工具注册到给定的 MCPServer 实例。"""

    # 旧版 grab 工具默认从 MCP 隐藏，避免 Agent 误用。
    # 需要调试时：set YUHAI_ENABLE_LEGACY_GRAB=1
    import os as _os
    _LEGACY_GRAB = _os.getenv("YUHAI_ENABLE_LEGACY_GRAB", "").strip() in ("1", "true", "yes")

    def _ok(**kw):
        return {"ok": True, **kw}

    def _err(msg, **kw):
        return {"ok": False, "error": msg, **kw}

    # ═══════════════════════════════════════
    #  账号
    # ═══════════════════════════════════════
    @mcp.tool(description="列出所有账号（含配额、分组、角色、启用状态）")
    def account_list() -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM accounts ORDER BY rowid DESC""")
        out = []
        for r in rows:
            out.append({
                "id": r["id"], "label": r.get("label"),
                "role": r.get("role"), "email": r.get("email") or "",
                "envCode": r.get("env_code") or "",
                "groupName": r.get("group_name") or "",
                "enabled": bool(r.get("enabled")),
                "cUser": r.get("c_user") or "",
                "note": r.get("note") or "",
            })
        return _ok(count=len(out), items=out)

    @mcp.tool(description="新建账号。role: publisher|spare|admin")
    def account_create(label: str, role: str = "publisher",
                       cUser: str = "", email: str = "",
                       envCode: str = "", groupName: str = "",
                       note: str = "") -> dict:
        from app.db import db, now_iso
        try:
            aid = "acc-" + str(int(__import__("time").time() * 1000))
            db.exec(
                """INSERT INTO accounts (id, label, role, c_user, email,
                   env_code, group_name, enabled, note, created_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (aid, label, role, cUser, email, envCode, groupName,
                 1, note, now_iso()))
            return _ok(id=aid, label=label, role=role,
                       note=f"已创建账号 {label}")
        except Exception as e:
            return _err(f"创建失败: {str(e)[:120]}")

    @mcp.tool(description="改账号属性（label/role/enabled/note 等）")
    def account_update(account_id: str, fields: str) -> dict:
        from app.db import db
        try:
            patch = json.loads(fields) if isinstance(fields, str) else fields
        except Exception:
            return _err("fields 必须是 JSON 对象字符串")
        allowed = {"label", "role", "c_user", "email", "env_code",
                   "group_name", "enabled", "note"}
        sets = []
        vals = []
        for k, v in patch.items():
            if k not in allowed:
                continue
            sets.append("%s=?" % k)
            vals.append(v)
        if not sets:
            return _err("没有可改字段，允许: %s" % ", ".join(sorted(allowed)))
        vals.append(account_id)
        db.exec("UPDATE accounts SET %s WHERE id=?" % ", ".join(sets), tuple(vals))
        return _ok(account_id=account_id, updated=list(patch.keys()))

    @mcp.tool(description="删账号")
    def account_delete(account_id: str) -> dict:
        from app.db import db
        db.exec("DELETE FROM accounts WHERE id=?", (account_id,))
        return _ok(deleted=account_id)

    @mcp.tool(description="从指纹浏览器环境自动补建账号")
    def account_from_envs() -> dict:
        from app.api.accounts import from_envs
        import asyncio
        try:
            r = asyncio.run(from_envs())
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except RuntimeError:
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                r = ex.submit(lambda: asyncio.run(from_envs())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"补建失败: {str(e)[:120]}")

    @mcp.tool(description="查账号配额（每天能发多少）")
    def account_quota(account_id: str = "") -> dict:
        from app.db import db
        if account_id:
            rows = db.q("""SELECT * FROM accounts WHERE id=?""",
                        (account_id,))
        else:
            rows = db.q("""SELECT * FROM accounts WHERE enabled=1""")
        return _ok(count=len(rows),
                   items=[{"id": r["id"], "label": r.get("label"),
                           "quota": r.get("page_quota") or "new"}
                          for r in rows])

    # ═══════════════════════════════════════
    #  主页
    # ═══════════════════════════════════════
    @mcp.tool(description="列出主页（含粉丝、是否跳过发布、归属账号）")
    def page_list(limit: int = 100) -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM pages ORDER BY rowid DESC LIMIT ?""",
                    (limit,))
        out = []
        for r in rows:
            out.append({
                "id": r["page_id"], "name": r.get("name"),
                "drama": r.get("drama") or "",
                "genre": r.get("genre") or "",
                "followers": r.get("followers") or 0,
                "skipPublish": bool(r.get("skip_publish")),
                "envCode": r.get("env_code") or "",
                "health": r.get("health") or "",
            })
        return _ok(count=len(out), items=out)

    @mcp.tool(
        description="创建主页。name=主页名，category=分类，count=建几个，"
                    "accountId=归属账号，bio=简介")
    def page_create(name: str, category: str, count: int = 1,
                    accountId: str = "", bio: str = "",
                    dailyLimit: int = 0, gapSec: int = 420) -> dict:
        from app.api.pages import CreateReq, create_pages
        import asyncio
        try:
            req = CreateReq(name=name, category=category, count=count,
                            accountId=accountId, bio=bio,
                            dailyLimit=dailyLimit, gapSec=gapSec)
            try:
                r = asyncio.run(create_pages(req))
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(create_pages(req))).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"创建主页失败: {str(e)[:150]}")

    @mcp.tool(description="改主页属性（name/category/skipPublish 等）")
    def page_update(page_id: str, fields: str) -> dict:
        from app.db import db
        try:
            patch = json.loads(fields) if isinstance(fields, str) else fields
        except Exception:
            return _err("fields 必须是 JSON 对象字符串")
        allowed = {"name", "drama", "genre", "skip_publish", "env_code"}
        sets, vals = [], []
        for k, v in patch.items():
            if k in allowed:
                sets.append("%s=?" % k)
                vals.append(v)
        if not sets:
            return _err("没有可改字段，允许: %s" % ", ".join(sorted(allowed)))
        vals.append(page_id)
        db.exec("UPDATE pages SET %s WHERE id=?" % ", ".join(sets), tuple(vals))
        return _ok(page_id=page_id, updated=list(patch.keys()))

    @mcp.tool(description="设置主页是否跳过发布")
    def page_skip_publish(page_id: str, skip: bool = True) -> dict:
        from app.db import db
        db.exec("UPDATE pages SET skip_publish=? WHERE page_id=?",
                (1 if skip else 0, page_id))
        return _ok(page_id=page_id, skipPublish=skip)

    @mcp.tool(description="从浏览器当前登录态提取主页（需先启动环境）")
    def page_extract(envCode: str = "") -> dict:
        from app.api.pages import ExtractReq, extract
        import asyncio
        try:
            req = ExtractReq(envCode=envCode) if envCode else ExtractReq()
            try:
                r = asyncio.run(extract(req))
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(extract(req))).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"提取失败: {str(e)[:150]}")

    # ═══════════════════════════════════════
    #  授权
    # ═══════════════════════════════════════
    @mcp.tool(description="查授权矩阵：哪些账号对哪些主页有权限")
    def authz_matrix() -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM page_roles""")
        out = [{"accountId": r.get("c_user"),
                "pageId": r.get("page_id"),
                "role": r.get("role"),
                "state": r.get("state")} for r in rows]
        # 也给出账号和主页清单，方便 agent 判断
        accs = db.q("SELECT id, label FROM accounts")
        pgs = db.q("SELECT page_id, name FROM pages LIMIT 100")
        return _ok(grants=out, grantsCount=len(out),
                   accounts=[dict(a) for a in accs],
                   pages=[dict(p) for p in pgs])

    @mcp.tool(description="给账号授权主页。role: admin|publisher|viewer")
    def authz_grant(account_id: str, page_id: str,
                    role: str = "publisher") -> dict:
        from app.db import db, now_iso
        try:
            db.exec(
                """INSERT INTO page_roles (c_user, page_id, role, granted_at)
                   VALUES (?,?,?,?)
                   ON CONFLICT(c_user, page_id)
                   DO UPDATE SET role=?""",
                (account_id, page_id, role, now_iso(), role))
            return _ok(accountId=account_id, pageId=page_id, role=role,
                       note=f"已授权 {account_id} → {page_id} ({role})")
        except Exception as e:
            return _err(f"授权失败: {str(e)[:120]}",
                        hint="检查 accounts/pages 表里 id 是否存在")

    @mcp.tool(description="批量授权：一个账号对多个主页")
    def authz_grant_multi(account_id: str, page_ids: str,
                          role: str = "publisher") -> dict:
        ids = [x.strip() for x in page_ids.split(",") if x.strip()]
        ok, fail = [], []
        for pid in ids:
            r = authz_grant(account_id, pid, role)
            (ok if r.get("ok") else fail).append(pid)
        return _ok(granted=ok, failed=fail,
                   note=f"成功 {len(ok)} / 失败 {len(fail)}")

    @mcp.tool(description="校验授权是否真实生效（检查主页能否被账号操作）")
    def authz_verify() -> dict:
        from app.db import db
        accs = db.q("SELECT id, label, enabled FROM accounts")
        pgs = db.q("SELECT page_id, name, skip_publish FROM pages LIMIT 100")
        grants = db.q("SELECT c_user, page_id, role FROM page_roles")
        problems = []
        # 主页没有归属账号
        for p in pgs:
            g = [x for x in grants if x["page_id"] == p["page_id"]]
            if not g and not p.get("skip_publish"):
                problems.append({
                    "type": "page_without_account",
                    "pageId": p["page_id"], "pageName": p.get("name"),
                    "why": "这个主页没有任何账号授权，发不了",
                })
        # 账号没启用
        for a in accs:
            if not a.get("enabled"):
                problems.append({
                    "type": "account_disabled",
                    "accountId": a["id"], "accountLabel": a.get("label"),
                    "why": "账号已禁用",
                })
        return _ok(ok=not problems, problems=problems,
                   accountsCount=len(accs), pagesCount=len(pgs),
                   grantsCount=len(grants))

    # ═══════════════════════════════════════
    #  环境（指纹浏览器）
    # ═══════════════════════════════════════
    @mcp.tool(description="列出指纹浏览器环境（含运行状态、代理）")
    def env_list() -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM envs WHERE status<>'removed'
                       ORDER BY rowid DESC""")
        return _ok(count=len(rows),
                   items=[{"code": r.get("container_code"),
                           "name": r.get("name"),
                           "status": r.get("status"),
                           "proxy": f"{r.get('proxy_host') or ''}:{r.get('proxy_port') or ''}",
                           "accountId": r.get("account_id") or ""}
                          for r in rows])

    @mcp.tool(description="启动环境（打开指纹浏览器）。code 来自 env_list")
    def env_start(code: str) -> dict:
        from app.adapters import hubstudio as hs
        try:
            if hasattr(hs, "start_env"):
                r = hs.start_env(code)
            else:
                return _err("当前 Hubstudio 适配器不支持启动")
            return _ok(code=code, result=r)
        except Exception as e:
            return _err(f"启动失败: {str(e)[:150]}",
                        hint="检查 Hubstudio 客户端是否在运行")

    @mcp.tool(description="停止环境")
    def env_stop(code: str) -> dict:
        from app.adapters import hubstudio as hs
        try:
            if hasattr(hs, "stop_env"):
                r = hs.stop_env(code)
            else:
                return _err("当前适配器不支持停止")
            return _ok(code=code, result=r)
        except Exception as e:
            return _err(f"停止失败: {str(e)[:120]}")

    @mcp.tool(description="同步环境列表（从 Hubstudio 拉最新）")
    def env_sync() -> dict:
        from app.api.envs import sync_envs_api
        import asyncio
        try:
            try:
                r = asyncio.run(sync_envs_api())
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(sync_envs_api())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"同步失败: {str(e)[:150]}")

    @mcp.tool(description="测代理是否可用")
    def env_test_proxy(proxy: str) -> dict:
        from app.api.envs import test_proxy
        import asyncio
        try:
            r = asyncio.run(test_proxy(proxy=proxy))
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"测试失败: {str(e)[:120]}")

    # ═══════════════════════════════════════
    #  抓取
    # ═══════════════════════════════════════
    if _LEGACY_GRAB:
        @mcp.tool(
            description=(
                "热门剧榜单（单页）。cursor 从 1 开始翻页。"
                "返回剧名/集数/播放量/分类。可能需要 10-30 秒（走代理）"))
        def grab_hot(cursor: int = 1, limit: int = 20) -> dict:
            from app.legacy.services import grab as g
            try:
                r = g.list_hot_fast(cursor, limit)
                if not r.get("ok"):
                    return _err(r.get("error") or "拉取失败",
                                why=r.get("why"), fix=r.get("fix"),
                                retries=r.get("retries"),
                                elapsed=r.get("elapsed"))
                items = r.get("items") or []
                if not items:
                    return _err(
                        "榜单返回 0 条",
                        cursor=cursor,
                        why="可能是：① 代理没开 ② 上游限流（10 次/分）"
                            " ③ 接口临时故障",
                        fix="等 1 分钟再试；或先用 grab_search 按剧名搜",
                        hint="检查代理 127.0.0.1:7897 是否在运行")
                out = []
                for it in items[:limit]:
                    out.append({
                        "cid": (it.get("collection_id")
                                or it.get("id") or ""),
                        "title": it.get("title") or "",
                        "episodes": it.get("total_episodes")
                                    or it.get("episodes") or 0,
                        "views": it.get("views") or 0,
                        "categories": it.get("categories") or "",
                        "tags": it.get("tags") or [],
                        "cover": it.get("cover") or "",
                    })
                return _ok(count=len(out), cursor=cursor, items=out)
            except Exception as e:
                return _err(
                    f"拉榜单失败: {str(e)[:120]}",
                    why="网络请求出错",
                    fix="检查代理；或等 1 分钟重试")

    if _LEGACY_GRAB:
        @mcp.tool(
            description=(
                "按剧名搜索（剧名可以是中文/英文/印尼语）。"
                "pages 搜几页，每页 20 部。返回 cid 用于 grab_run"))
        def grab_search(keyword: str, pages: int = 1) -> dict:
            from app.legacy.services import grab as g
            try:
                r = g.search_fast(keyword, pages)
                if not r.get("ok"):
                    return _err(r.get("error") or "搜不到",
                                why=r.get("why"), fix=r.get("fix"))
                items = r.get("items") or []
                if not items:
                    return _err(
                        f"搜不到「{keyword}」",
                        why="可能是：① 剧名不对 ② 代理没开 ③ 这部剧没有",
                        fix="换个关键词；或去 App 里复制准确的剧名",
                    )
                out = []
                for it in items:
                    out.append({
                        "cid": (it.get("collection_id")
                                or it.get("id") or ""),
                        "title": it.get("title") or "",
                        "episodes": it.get("total_episodes")
                                    or it.get("episodes") or 0,
                        "views": it.get("views") or 0,
                        "categories": it.get("categories") or "",
                        "tags": it.get("tags") or [],
                    })
                return _ok(keyword=keyword, count=len(out), items=out)
            except Exception as e:
                return _err(f"搜索失败: {str(e)[:120]}",
                            why="网络请求出错", fix="检查代理是否启动")


    if _LEGACY_GRAB:
        @mcp.tool(description="开始抓取。cid 来自 grab_hot/grab_search，eps 如 '1-20'")
        def grab_run(cid: str, eps: str = "1-10", title: str = "") -> dict:
            from app.legacy.services import grab as g
            try:
                if hasattr(g, "run"):
                    r = g.run(cid=cid, eps=eps, title=title)
                elif hasattr(g, "download"):
                    r = g.download(cid, eps)
                else:
                    return _err("抓取模块没有 run/download 接口")
                return _ok(cid=cid, result=r)
            except Exception as e:
                return _err(f"抓取失败: {str(e)[:150]}",
                            hint="检查代理和环境")

    if _LEGACY_GRAB:
        @mcp.tool(description="已抓记录（哪些剧抓过、抓了多少集）")
        def grab_records() -> dict:
            from app.db import db
            rows = db.q("""SELECT * FROM grab_records ORDER BY rowid DESC
                           LIMIT 100""")
            return _ok(count=len(rows), items=[dict(r) for r in rows])

    # ═══════════════════════════════════════
    #  切片
    # ═══════════════════════════════════════
    @mcp.tool(description="列剧（含处理进度）")
    def slice_list_dramas() -> dict:
        from app.services import slicing as sl
        items = sl.list_dramas()
        out = []
        for d in items:
            st = d.get("steps") or {}
            out.append({
                "drama": d["drama"], "title": d.get("title"),
                "episodes": d.get("sourceEpisodes") or 0,
                "state": d.get("state"),
                "transcribed": bool((st.get("transcribe") or {}).get("done")),
                "type": (st.get("classify") or {}).get("typeName") or "",
                "singles": (st.get("single") or {}).get("count") or 0,
                "premiums": (st.get("premium") or {}).get("count") or 0,
            })
        return _ok(count=len(out), items=out)

    @mcp.tool(description="切片。mode: single|premium|all，返回 job_id")
    def slice_run(drama: str, mode: str = "all", eps: str = "",
                  target: int = 45) -> dict:
        from app.services import slicing as sl
        import uuid
        job_id = "mcp-" + uuid.uuid4().hex[:10]
        try:
            result = {}
            epl = [e.strip() for e in eps.split(",") if e.strip()] if eps else None
            if mode in ("single", "all"):
                result["single"] = sl.step_single(job_id, drama, epl, target)
            if mode in ("premium", "all"):
                result["premium"] = sl.step_premium(job_id, drama)
            ok = all((v or {}).get("ok", False) for v in result.values())
            if not ok:
                fails = {k: (v or {}).get("error", "") for k, v in result.items()
                         if not (v or {}).get("ok")}
                return _err("部分失败: " + json.dumps(fails, ensure_ascii=False)[:250],
                            job_id=job_id, detail=result)
            return _ok(job_id=job_id, drama=drama, mode=mode, result=result)
        except Exception as e:
            return _err(f"切片异常: {str(e)[:150]}", job_id=job_id)

    @mcp.tool(description="查 job 状态")
    def slice_status(job_id: str) -> dict:
        from app.db import db
        r = db.q1("SELECT * FROM jobs WHERE id=?", (job_id,))
        if not r:
            return _err(f"没有这个 job: {job_id}")
        return _ok(id=r["id"], status=r.get("status"),
                   progress=r.get("progress"),
                   steps=json.loads(r.get("steps") or "[]"),
                   error=r.get("error") or "")

    @mcp.tool(description="列成片")
    def slice_result(drama: str = "") -> dict:
        from app import paths
        out = []
        for pat in ("单集_*", "精品混剪_*"):
            for d in paths.output_root().glob(pat):
                if not d.is_dir():
                    continue
                for sub in d.iterdir():
                    if not sub.is_dir():
                        continue
                    if drama and drama.lower() not in sub.name.lower():
                        continue
                    vids = list(sub.glob("*.mp4"))
                    if not vids:
                        continue
                    out.append({
                        "kind": "single" if "单集" in pat else "premium",
                        "drama": sub.name, "date": d.name.split("_")[-1],
                        "count": len(vids),
                        "path": str(sub),
                        "files": [f.name for f in vids[:20]],
                    })
        return _ok(count=len(out), items=out)

    @mcp.tool(description="环境自检")
    def slice_env_check() -> dict:
        from app.services import envcheck
        r = envcheck.full_check()
        return _ok(ready=r["ok"], ffmpeg=r["ffmpeg"]["ok"],
                   nvenc=r["ffmpeg"].get("nvenc"),
                   model={"ok": r["model"]["ok"],
                          "name": r["model"]["name"],
                          "sizeMb": r["model"].get("sizeMb")},
                   gpu={"name": r["gpu"].get("name"),
                        "cuda": r["gpu"].get("cuda")},
                   warnings=r["warnings"],
                   fixable=[f["what"] for f in (r.get("fixable") or [])])

    @mcp.tool(description="修环境 what: all|python|ffmpeg|whisper|tools|cuda")
    def slice_env_install(what: str = "all") -> dict:
        from app.services import envcheck
        r = envcheck.install_one(what)
        return _ok(what=what, ok=r.get("ok"),
                   note=r.get("note") or r.get("error") or "")

    # ═══════════════════════════════════════
    #  素材库
    # ═══════════════════════════════════════
    @mcp.tool(description="列素材库（成片/待发布）")
    def library_list(limit: int = 50, state: str = "") -> dict:
        from app.db import db
        if state:
            rows = db.q("""SELECT * FROM library WHERE state=?
                           ORDER BY rowid DESC LIMIT ?""", (state, limit))
        else:
            rows = db.q("""SELECT * FROM library ORDER BY rowid DESC
                           LIMIT ?""", (limit,))
        return _ok(count=len(rows),
                   items=[{"id": r.get("id"), "file": r.get("file"),
                           "path": r.get("path"),
                           "state": r.get("state"),
                           "drama": r.get("drama") or "",
                           "dur": r.get("dur") or 0} for r in rows])

    @mcp.tool(description="扫素材库目录（发现新文件）")
    def library_scan() -> dict:
        from app.api.library import scan
        import asyncio
        try:
            try:
                r = asyncio.run(scan())
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(scan())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"扫描失败: {str(e)[:150]}")

    @mcp.tool(description="素材质检（时长/分辨率/音量）")
    def library_qc(lib_id: str = "") -> dict:
        from app.api.library import qc
        import asyncio
        try:
            try:
                r = asyncio.run(qc())
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(qc())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"质检失败: {str(e)[:150]}")

    # ═══════════════════════════════════════
    #  发布
    # ═══════════════════════════════════════
    @mcp.tool(description="发布（Facebook 主页）。items 是 JSON 数组字符串")
    def publish_run(items: str, gapSec: int = 300,
                    deleteOnSuccess: bool = True) -> dict:
        from app.api.publish import PublishReq, publish, PublishItem
        import asyncio
        try:
            raw = json.loads(items) if isinstance(items, str) else items
            req = PublishReq(items=[PublishItem(**x) for x in raw],
                             gapSec=gapSec,
                             deleteOnSuccess=deleteOnSuccess)
            try:
                r = asyncio.run(publish(req))
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(publish(req))).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"发布失败: {str(e)[:150]}",
                        hint="检查 pages 是否授权、环境是否启动")

    @mcp.tool(description="发布历史（含失败原因）")
    def publish_history(limit: int = 30) -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM jobs WHERE kind='publish'
                       ORDER BY rowid DESC LIMIT ?""", (limit,))
        out = []
        for r in rows:
            err = r.get("error") or ""
            out.append({
                "id": r["id"], "status": r.get("status"),
                "error": err,
                "why": _explain_error(err),
                "result": json.loads(r.get("result") or "{}")
                          if r.get("result") else {},
            })
        return _ok(count=len(out), items=out)

    @mcp.tool(description="Reels 发布（走 ReelsPublisher 内核）")
    def publish_reels(pageName: str = "", count: int = 0,
                      autoPrepare: bool = True) -> dict:
        from app.services import reels as rl
        try:
            if hasattr(rl, "publish_batch"):
                r = rl.publish_batch(pageName, count, autoPrepare)
            elif hasattr(rl, "publish"):
                r = rl.publish(pageName, count)
            else:
                return _err("reels 模块没有发布接口，用 publish_run 走主页发布")
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"Reels 发布失败: {str(e)[:150]}")

    @mcp.tool(description="Reels 状态（浏览器是否连上、主页是否识别）")
    def publish_reels_status() -> dict:
        from app.services import reels as rl
        try:
            r = rl.available() if hasattr(rl, "available") else {}
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"查询失败: {str(e)[:120]}")

    # ═══════════════════════════════════════
    #  失败诊断（关键）
    # ═══════════════════════════════════════
    @mcp.tool(description="查任务失败原因（自动解释错误码）")
    def system_failures(limit: int = 30, kind: str = "") -> dict:
        from app.db import db
        if kind:
            rows = db.q("""SELECT * FROM jobs WHERE status='failed' AND kind=?
                           ORDER BY rowid DESC LIMIT ?""", (kind, limit))
        else:
            rows = db.q("""SELECT * FROM jobs WHERE status='failed'
                           ORDER BY rowid DESC LIMIT ?""", (limit,))
        out = []
        for r in rows:
            err = r.get("error") or ""
            out.append({
                "id": r["id"], "kind": r.get("kind"),
                "title": r.get("title"),
                "error": err[:300],
                "why": _explain_error(err),
                "fix": _suggest_fix(err),
                "at": r.get("ended_at") or r.get("created_at"),
            })
        return _ok(count=len(out), items=out)

    @mcp.tool(description="风控状态：有没有被限流/封号预警")
    def system_guard() -> dict:
        from app.db import db
        events = db.q("""SELECT * FROM guard_events ORDER BY rowid DESC
                         LIMIT 20""")
        return _ok(count=len(events),
                   items=[dict(e) for e in events],
                   hint="" if not events else "有风控事件，先处理再发布")

    @mcp.tool(description="系统健康")
    def system_health() -> dict:
        from app.db import db
        from app.services import envcheck
        e = envcheck.full_check()
        jobs = db.q1("""SELECT COUNT(*) c FROM jobs
                        WHERE status='running'""")
        return _ok(ready=e["ok"], runningJobs=(jobs or {}).get("c", 0),
                   warnings=e["warnings"],
                   gpu=e["gpu"].get("name"), cuda=e["gpu"].get("cuda"))

    @mcp.tool(description="最近日志")
    def system_logs(limit: int = 30, level: str = "") -> dict:
        from app.db import db
        if level:
            rows = db.q("""SELECT * FROM events WHERE level=?
                           ORDER BY rowid DESC LIMIT ?""", (level, limit))
        else:
            rows = db.q("""SELECT * FROM events ORDER BY rowid DESC
                           LIMIT ?""", (limit,))
        return _ok(count=len(rows), items=[dict(r) for r in rows])

    # ═══════════════════════════════════════
    #  排期
    # ═══════════════════════════════════════
    @mcp.tool(description="列排队任务")
    def schedule_queue(state: str = "") -> dict:
        from app.db import db
        if state:
            rows = db.q("""SELECT * FROM queue WHERE state=?
                           ORDER BY rowid DESC LIMIT 60""", (state,))
        else:
            rows = db.q("""SELECT * FROM queue ORDER BY rowid DESC
                           LIMIT 60""")
        return _ok(count=len(rows), items=[dict(r) for r in rows])

    @mcp.tool(description="列排期")
    def schedule_list() -> dict:
        from app.db import db
        rows = db.q("""SELECT * FROM schedule ORDER BY rowid DESC LIMIT 60""")
        return _ok(count=len(rows), items=[dict(r) for r in rows])

    @mcp.tool(description="今日容量（还能发多少条）")
    def schedule_capacity() -> dict:
        from app.db import db
        pages = db.q1("SELECT COUNT(*) c FROM pages WHERE skip_publish=0")
        today = db.q1("""SELECT COUNT(*) c FROM jobs
                         WHERE kind='publish' AND status='done'""")
        return _ok(pagesEnabled=(pages or {}).get("c", 0),
                   publishedToday=(today or {}).get("c", 0))

    # ═══════════════════════════════════════
    #  数据
    # ═══════════════════════════════════════
    @mcp.tool(description="视频数据汇总")
    def data_overview() -> dict:
        from app.db import db
        v = db.q1("SELECT COUNT(*) c FROM videos")
        p = db.q1("SELECT COUNT(*) c FROM pages")
        a = db.q1("SELECT COUNT(*) c FROM accounts")
        return _ok(videos=(v or {}).get("c", 0), pages=(p or {}).get("c", 0),
                   accounts=(a or {}).get("c", 0))

    @mcp.tool(description="某主页的数据分析（AI 拟合结果）")
    def data_page_fit(page_id: str = "") -> dict:
        from app.db import db
        if page_id:
            r = db.q1("SELECT * FROM page_fit WHERE page_id=?", (page_id,))
            return _ok(fit=dict(r) if r else {}, page_id=page_id)
        rows = db.q("SELECT * FROM page_fit LIMIT 40")
        return _ok(count=len(rows), items=[dict(x) for x in rows])

    @mcp.tool(description="采集视频数据（播放/点赞/评论）")
    def data_collect(page_id: str = "") -> dict:
        from app.api.insights import collect
        import asyncio
        try:
            try:
                r = asyncio.run(collect())
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(collect())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"采集失败: {str(e)[:150]}")

    # ═══════════════════════════════════════
    #  邮箱
    # ═══════════════════════════════════════
    @mcp.tool(description="最新验证码")
    def mail_latest() -> dict:
        from app.api.mail import latest_code
        import asyncio
        try:
            try:
                r = asyncio.run(latest_code())
            except RuntimeError:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as ex:
                    r = ex.submit(lambda: asyncio.run(latest_code())).result()
            return _ok(**r) if isinstance(r, dict) else _ok(result=r)
        except Exception as e:
            return _err(f"读取失败: {str(e)[:120]}")

    @mcp.tool(description="邮箱通道列表")
    def mail_channels() -> dict:
        from app.db import db
        rows = db.q("SELECT * FROM mail_accounts LIMIT 20")
        return _ok(count=len(rows), items=[dict(r) for r in rows])

    # ═══════════════════════════════════════
    #  记忆
    # ═══════════════════════════════════════
    @mcp.tool(description="写记忆")
    def memory_set(key: str, value: str) -> dict:
        from app.services import agent_memory as mem
        return _ok(**mem.set(key, value))

    @mcp.tool(description="读记忆")
    def memory_get(key: str) -> dict:
        from app.services import agent_memory as mem
        r = mem.get(key)
        if not r.get("ok"):
            return _err(r.get("error") or "没有这个键", key=key)
        return _ok(key=r["key"], value=r["value"])

    @mcp.tool(description="列所有记忆")
    def memory_list() -> dict:
        from app.services import agent_memory as mem
        return _ok(**mem.list_all())

    # ═══════════════════════════════════════
    #  Agent 自身
    # ═══════════════════════════════════════
    @mcp.tool(description="当前接入 Agent 及其模型")
    def agent_models() -> dict:
        from app.services import agent_models as am
        o = am.overview()
        return _ok(connected=o["connected"], name=o["name"],
                   visible=len(o.get("visible") or []),
                   hidden=o.get("hiddenCount") or 0)

    return mcp


# ═══════════════════════════════════════════
#  错误解释（关键：用户要「失败的原因」）
# ═══════════════════════════════════════════
ERROR_MAP = [
    (("服务重启中断", "restart", "interrupt"),
     "服务重启打断了任务（非真故障）",
     "重新触发即可，不用排查"),
    (("input #0", "mov,mp4", "metadata:", "stream #0"),
     "ffmpeg 探测信息被当成错误（实际成功）",
     "忽略；只有出现 'Error'/'Invalid' 才是真失败"),
    (("no page", "page not found", "主页不存在"),
     "主页不存在或已删", "先在 page_list 确认主页还在"),
    (("no account", "account not found", "账号不存在"),
     "账号不存在", "用 account_create 建，或 account_from_envs 补"),
    (("permission", "forbidden", "403", "无权限", "未授权"),
     "没有授权", "用 authz_grant 给账号授权这个主页"),
    (("login", "cookie", "登录", "session"),
     "登录态失效", "env_start 重启环境，重新登录"),
    (("proxy", "代理", "connect timeout"),
     "代理不通", "env_test_proxy 测一下，换代理"),
    (("caption", "标题", "文案"),
     "文案生成失败", "检查标题池 links 表是否有数据"),
    (("timeout", "超时"),
     "执行超时", "重试；持续超时查 system_logs"),
    (("rate limit", "429", "限流"),
     "被限流", "降低频率，等配额恢复"),
    (("no video", "文件不存在", "not found.*mp4"),
     "视频文件找不到", "library_scan 重扫素材库"),
    (("quota", "配额"),
     "配额用尽", "等明天，或换账号"),
    (("browser", "chromium", "playwright"),
     "浏览器起不来", "检查 Hubstudio 是否运行"),
    (("disk", "space", "磁盘"),
     "磁盘空间不足", "清素材库"),
    (("error", "invalid", "failed", "cannot"),
     "ffmpeg/执行报错", "看 error 原文里的具体原因"),
]


def _explain_error(err: str) -> str:
    if not err:
        return ""
    low = str(err).lower()
    for keys, why, _fix in ERROR_MAP:
        for k in keys:
            if k in low:
                return why
    return "未识别的错误，看原文"


def _suggest_fix(err: str) -> str:
    if not err:
        return ""
    low = str(err).lower()
    for keys, _why, fix in ERROR_MAP:
        for k in keys:
            if k in low:
                return fix
    return "看 error 原文定位"
