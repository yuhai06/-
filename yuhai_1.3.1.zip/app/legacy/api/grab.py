"""素材抓取 API：PineDrama 智能抓取（带剧类型 / 自定义条件 / 自定义目录）。"""
from __future__ import annotations

import asyncio
import json
import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db import db, now_iso
from app.legacy.services import grab as g

log = logging.getLogger("yuhai.api.grab")
router = APIRouter(tags=["grab"])


# ---------------- 剧类型字典 ----------------
@router.get("/grab/types")
async def grab_types():
    """7 种内部剧型 + 中文标签 + 语言清单（前端多选用）。"""
    from app.services.slicing import DRAMA_TYPES
    from app.services import lang_detect as ld
    zh_tags: list[str] = []
    for v in g.CATEGORY_MAP.values():
        z = v.get("zh")
        if z and z not in zh_tags:
            zh_tags.append(z)
    return {
        "types": [{"key": k, "name": v["name"], "rhythm": v.get("rhythm", ""),
                   "bgm": v.get("bgm", [])}
                  for k, v in DRAMA_TYPES.items()],
        "tags": sorted(zh_tags),
        "languages": ld.all_langs(),
        "rawMap": {k: v for k, v in list(g.CATEGORY_MAP.items())[:40]},
    }


@router.get("/grab/hot")
async def hot(cursor: int = 1, limit: int = 20):
    """拉当天热门榜（不下载），每部带剧类型。"""
    items = await asyncio.to_thread(g.list_hot, cursor, limit)
    return {"items": items, "count": len(items),
            "note": "上游限流 10 次/分，7.5 秒间隔稳定"}


@router.get("/grab/detail")
async def detail(cid: str):
    d = await asyncio.to_thread(g.drama_detail, cid)
    if not d:
        raise HTTPException(404, "剧不存在或接口限流")
    return d


# ---------------- 自定义原始素材目录 ----------------
@router.get("/grab/roots")
async def grab_roots():
    """可选/已用的原始素材目录清单。"""
    return {
        "items": g.list_source_dirs(),
        "current": str(g.get_grab_root()),
        "default": str(g.get_grab_root()),
    }


class RootReq(BaseModel):
    path: str = ""


@router.post("/grab/root")
async def set_root(req: RootReq):
    """设置自定义原始素材文件夹（空=恢复默认）。"""
    r = g.set_grab_root(req.path)
    if not r.get("ok"):
        raise HTTPException(400, r.get("error") or "目录不可用")
    db.log_event("info", "grab", f"原始素材目录改为 {r['root']}")
    return {**r, "items": g.list_source_dirs()}


@router.get("/grab/grabbed")
async def grabbed(root: str = ""):
    """已抓下来的（带剧类型）。"""
    return {"items": g.list_grabbed(root),
            "root": str(g.get_grab_root(root))}


class GrabReq(BaseModel):
    dramas: int = 1
    episodes: int = 10
    useAnalysis: bool = True
    cids: list[str] = []
    # 自定义条件
    wantTypes: list[str] = []       # 内部 7 型（下拉勾选）
    customTypes: list[str] = []     # 自定义类型名（用户手填，硬过滤）
    wantTags: list[str] = []
    excludeTags: list[str] = []
    # 语言
    wantLangs: list[str] = []       # 语言代码，如 ["en","id"]
    langMode: str = "include"       # include 只要这些 / exclude 排除这些 / off 不筛
    # 抓取范围
    startEp: int = 1
    cursorFrom: int = 1
    cursorPages: int = 1
    orderBy: str = "list"      # list / hot / newest
    allHot: bool = False       # 抓当天全部热门
    # ★ 关键词搜索（百合/GL 等冷门题材只能靠这个）
    keywords: list[str] = []
    kwPages: int = 3
    tagFilter: list[str] = []   # 标签二次筛，如 ["sismance"]
    # 去重
    dedupe: bool = True        # 已抓过的剧不再抓
    skipExistingEps: bool = True   # 已抓过的集不再重下
    # 自定义原始素材目录（本次生效，不改全局）
    root: str = ""


@router.get("/grab/search")
async def search(query: str, pages: int = 2):
    """按关键词搜剧（不下载）。百合这类题材只能这样找到。"""
    items = await asyncio.to_thread(g.search_dramas, query, pages)
    return {"items": items, "count": len(items), "keyword": query,
            "note": "search 是模糊匹配标题+标签；要精确请配合标签二次筛"}


@router.get("/grab/keywords")
async def keyword_hints():
    """推荐关键词组合（重点：百合/GL）。"""
    return {
        "items": [
            {"label": "百合（最准）", "keywords": ["sismance"],
             "tagFilter": ["sismance"],
             "desc": "Sismance 是上游唯一可靠的百合标签，实测 19 部全部命中"},
            {"label": "百合（日系）", "keywords": ["yuri", "yuri academy", "百合"],
             "tagFilter": ["yuri"],
             "desc": "日系百合，量少但准；「百合」命中日文标题"},
            {"label": "百合（多语种）", "keywords": ["女同", "sapphic", "womance"],
             "tagFilter": ["sismance", "yuri"],
             "desc": "会带进意/葡/法/土语片源，靠标签筛掉无关的"},
            {"label": "爽剧打脸", "keywords": ["dihina", "melawan", "jadi bos"],
             "tagFilter": [], "desc": "印尼语打脸逆袭"},
            {"label": "豪门上层", "keywords": ["miliarder", "CEO", "kelas atas"],
             "tagFilter": [], "desc": "豪门题材"},
        ],
        "note": "百合抓不到就用第一个：关键词 sismance + 标签筛 sismance，"
                "这是实测最准的组合。量不够再加 yuri / 百合 / 女同 扩范围。",
    }


@router.get("/grab/all-hot")
async def all_hot(maxPages: int = 30):
    """拉当天热门全榜（自动翻页，含剧类型）。"""
    items = await asyncio.to_thread(g.list_hot_all, maxPages, 2)
    return {"items": items, "count": len(items)}


# ---------------- 抓取台账（去重） ----------------
@router.get("/grab/records")
async def records():
    """已抓台账：哪些剧抓过、抓到第几集、什么类型。"""
    from app.legacy.services import grab_records as gr
    rows = list(gr.all_records().values())
    rows.sort(key=lambda r: r.get("grabbed_at") or "", reverse=True)
    return {"items": rows, "stats": gr.stats()}


@router.post("/grab/records/clear")
async def records_clear(cid: str = ""):
    """清台账，用于强制重抓（cid 空则全清）。"""
    from app.legacy.services import grab_records as gr
    r = gr.clear(cid)
    db.log_event("warn", "grab",
                 f"抓取台账已清：{cid or '全部'}")
    return {**r, "stats": gr.stats()}


@router.get("/grab/records/check")
async def records_check(cid: str):
    """查单部剧抓过没（前端标灰用）。"""
    from app.legacy.services import grab_records as gr
    r = gr.get(cid)
    return {"cid": cid, "grabbed": bool(r), "record": r}


@router.post("/grab/run")
async def run(req: GrabReq):
    """开始抓取。剧类型会一起写进 meta.json / type.json。"""
    job_id = "job-" + uuid.uuid4().hex[:12]
    steps = [{"name": "拉热门榜", "state": "wait", "note": ""}]
    payload = req.model_dump()
    # langMode=off 时清空语言条件（= 不筛选）
    if req.langMode == "off":
        payload["wantLangs"] = []
    pieces = []
    if req.keywords:
        pieces.append(f"搜索 {len(req.keywords)} 词")
    if req.tagFilter:
        pieces.append(f"标签筛 {len(req.tagFilter)}")
    if req.wantTypes:
        pieces.append(f"剧型 {len(req.wantTypes)}")
    if req.customTypes:
        pieces.append(f"自定 {len(req.customTypes)}")
    if req.wantTags:
        pieces.append(f"标签 {len(req.wantTags)}")
    if req.excludeTags:
        pieces.append(f"排除 {len(req.excludeTags)}")
    if payload["wantLangs"]:
        pieces.append(("语言只要 " if req.langMode == "include" else "语言排除 ")
                      + f"{len(payload['wantLangs'])}")
    title = (f"抓取 {req.dramas} 部 × {req.episodes} 集"
             + (f"（{' · '.join(pieces)}）" if pieces else ""))
    db.exec("INSERT INTO jobs(id,kind,title,status,progress,steps,payload,"
            "created_at) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, "grab", title, "queued", 0,
             json.dumps(steps, ensure_ascii=False),
             json.dumps(payload, ensure_ascii=False), now_iso()))

    # 抓取是同步长任务（curl 子进程 + sleep）。必须丢到线程里跑，
    # 否则会堵住 event loop，整个界面（含健康检查）全部无响应。
    async def _bg() -> None:
        await asyncio.to_thread(_run_sync, job_id, payload)

    asyncio.create_task(_bg())
    return {"ok": True, "jobId": job_id,
            "note": "后台静默执行，进度看下方任务卡；每集两次 API，7.5 秒节流"}


def _run_sync(job_id: str, payload: dict) -> None:
    """在线程里跑同步抓取（grab_records 用的是同步 sqlite）。"""
    try:
        asyncio.run(g.run_grab(job_id, payload))
    except Exception as e:
        log.exception("grab job %s crashed: %s", job_id, e)


@router.get("/grab/env")
async def grab_env():
    """检查抓取环境：curl / 代理 / 工具目录（跨环境）。"""
    from app import paths as _paths
    from app import proc
    cb = _paths.curl()
    out = {
        "curl": str(cb) if cb else "",
        "proxy": _paths.proxy(),
        "toolsDir": str(g._tools_dir()),
        "grabRoot": str(g.get_grab_root()),
        "pdScript": (g._tools_dir() / "pd_drama.py").exists(),
        "ok": False,
    }
    if cb:
        try:
            r = proc.run([str(cb), "--version"], text=True, timeout=10,
                         encoding="utf-8", errors="replace")
            out["curlVersion"] = (r.stdout or "").split("\n")[0][:80]
            out["ok"] = r.returncode == 0
        except Exception as e:
            out["error"] = str(e)[:200]
    else:
        out["error"] = "未找到 curl"

    px = out["proxy"]
    out["proxyAlive"] = False
    if px:
        try:
            import httpx
            httpx.get(px, timeout=2)
            out["proxyAlive"] = True
        except Exception:
            pass
    # 代理不通时要提示：接口能直连，但下载必须走代理
    out["directApi"] = True
    out["downloadNeedsProxy"] = bool(px) and not out["proxyAlive"]
    return out
