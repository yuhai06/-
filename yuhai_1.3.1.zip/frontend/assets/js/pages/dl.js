/* 短剧下载（多站点）
   PineDrama / DramaBox / MoboReels / GoodShort / TikTok / TK短剧
   · 站点切换 → 搜剧 → 选集 → 下载（后台队列，实时进度）
   · 片库：本地已下载，内嵌播放，可一键送去切片
*/
import { icon } from '../icons.js';
import { api } from '../api.js';
import { pageHead, $, $$, toast, emptyState } from '../ui.js';

let SITES = [];
let SITE = 'pinedrama';
let rows = [];
let CUR = null;
let SEL = new Set();
let TASKS = [];
let VIEW = 'discover';
let PV = { files: [], idx: 0, name: '' };
let timer = null;
let ENV = {};

/* 跨页持久化：切走再回来恢复现场，不重新请求 */
let KW_MAP = {};             // 每个站点各自的输入内容 {pinedrama:'love', tiktok:'71...'}
let SCROLL = 0;              // 网格滚动位置
let BOOTED = false;          // 是否已初始化过（首次进页面才拉接口）
let LIB = null;              // 片库数据缓存
let TK = null;               // TikTok 查询结果缓存
let SD = null;               // TK短剧查询结果缓存
let SCROLL_BOUND = false;    // 滚动监听只绑一次（绑在 document 上，捕获阶段）
let CTL = null;              // 当前请求的 AbortController（点「停止」时中断）
let RUNNING = false;         // 是否有请求在跑

/* 每个栏目独立记忆输入内容，切栏目不会串 */
function getKw() { return KW_MAP[SITE] || ''; }
function setKw(v) { KW_MAP[SITE] = v || ''; }

/* 全局捕获滚动：main.js 在 render 前会 scrollTop=0，
   所以必须在用户滚动的那一刻记下来，不能等切页时再读。
   同时挂 document 捕获 + window 捕获，覆盖各种触发方式。 */
function bindScrollOnce() {
  if (SCROLL_BOUND) return;
  SCROLL_BOUND = true;
  const rec = (t) => {
    // 只认本页的 #view，且网格存在（说明页面还在）
    if (t && t.id === 'view' && document.getElementById('dl-grid')) {
      SCROLL = t.scrollTop;
    }
  };
  document.addEventListener('scroll', (e) => rec(e.target), true);
  window.addEventListener('scroll', (e) => rec(e.target), true);
}

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '短剧下载',
      desc: 'PineDrama · DramaBox · MoboReels · GoodShort · TikTok · TK短剧',
      actions: [
        `<button class="btn sm" data-act="lib"><span data-icon="layers"></span>片库</button>`,
        `<button class="btn sm" data-act="cfg"><span data-icon="cog"></span>下载设置</button>`,
        `<button class="btn sm" data-act="back" style="display:none"><span data-icon="arrowL"></span>返回发现</button>`,
      ],
    })}
    <div id="dl-sites" class="dl-sites"></div>
    <div id="dl-bar" class="dl-bar"></div>
    <div id="dl-tasks" class="dl-tasks"></div>
    <div id="dl-grid" class="dl-grid"></div>
    <div id="dl-drawer" class="dl-drawer"></div>
    <div id="dl-player" class="dl-player"></div>
  `;
  $$('[data-act="lib"]', root).forEach(b => b.onclick = () => {
    VIEW = 'library';
    LIB = null;                       // 进片库重扫一次
    paintLib(root);
  });
  $$('[data-act="cfg"]', root).forEach(b => b.onclick = () => showCfg(root));
  $$('[data-act="back"]', root).forEach(b => b.onclick = () => {
    VIEW = 'discover'; paintBar(root); restoreList(root);
  });
  // 记录滚动位置（挂 document 捕获，main.js 的清零动作在 render 之后不影响已记录值）
  bindScrollOnce();
  init(root);
}

async function init(root) {
  // 站点列表只需拉一次
  if (!SITES.length) {
    try {
      const s = await api.dlSites();
      SITES = s.items || [];
    } catch (e) {
      SITES = [{ id: 'pinedrama', name: 'PineDrama', color: '#2dd4bf' }];
    }
  }
  if (!ENV.root) {
    try { ENV = await api.dlEnv(); } catch (e) { ENV = {}; }
  }
  paintSites(root);
  paintBar(root);
  refreshTasks(root);
  if (timer) clearInterval(timer);
  timer = setInterval(() => refreshTasks(root), 1500);

  // 已加载过 → 直接还原现场，不重新请求
  if (BOOTED) {
    restoreList(root);
    return;
  }
  BOOTED = true;
  await loadList(root);
}

/* 还原之前的列表（不发请求） */
function restoreList(root) {
  const grid = $('#dl-grid', root);
  if (!grid) return;
  if (VIEW === 'library') return paintLib(root);

  if (SITE === 'tiktok' && TK) {
    grid.innerHTML = tkMetaHtml(TK.m);
    bindTk(root, TK.m);
    return;
  }
  if (SITE === 'tiktok_drama') {
    // 重新渲染底板：历史 + 上次结果（都不发网络请求）
    const results = (SD && SD.results) || [];
    loadSdHistorySafe().then(hist => {
      const g2 = document.getElementById('dl-grid');
      if (g2) renderSdBoard(document.getElementById('view'), hist, results);
    });
    return;
  }
  if (rows.length) {
    paintGrid(root);
    // 还原滚动：等两帧，确保 grid 撑开高度后再设
    const v = document.getElementById('view');
    if (v && SCROLL > 0) {
      const target = SCROLL;
      requestAnimationFrame(() => {
        v.scrollTop = target;
        requestAnimationFrame(() => { v.scrollTop = target; });
      });
    }
    return;
  }
  loadList(root);
}

function paintSites(root) {
  const box = $('#dl-sites', root);
  if (!box) return;
  box.innerHTML = SITES.map(s => `
    <button class="dl-site ${s.id === SITE ? 'on' : ''}" data-site="${s.id}">${s.name}</button>
  `).join('');
  $$('.dl-site', box).forEach(b => b.onclick = () => {
    SITE = b.dataset.site;
    VIEW = 'discover';
    paintSites(root);
    paintBar(root);
    loadList(root);
  });
}

function paintBar(root) {
  const bar = $('#dl-bar', root);
  const backBtn = $('[data-act="back"]', root);
  const libBtn = $('[data-act="lib"]', root);
  if (!bar) return;
  if (VIEW === 'library') {
    bar.innerHTML = `<span class="dl-hint" id="dl-hint"></span>`;
    if (backBtn) backBtn.style.display = '';
    if (libBtn) libBtn.style.display = 'none';
    return;
  }
  if (backBtn) backBtn.style.display = 'none';
  if (libBtn) libBtn.style.display = '';

  if (SITE === 'tiktok') {
    bar.innerHTML = `
      <input id="dl-kw" class="dl-input" placeholder="粘贴 TikTok 作品 ID 或整条链接" value="${esc(getKw())}">
      <button class="btn sm primary" id="dl-search"><span data-icon="search"></span>查询</button>
      <button class="btn sm" id="dl-go"><span data-icon="down"></span>下载</button>
      <button class="btn sm danger" id="dl-stop" style="display:none">停止</button>
      <span id="dl-hint" class="dl-hint"></span>`;
    $('#dl-search', root).onclick = () => loadList(root);
    $('#dl-go', root).onclick = () => {
      const v = ($('#dl-kw', root)?.value || '').trim();
      if (!v) return toast('先输入作品 ID', '', 'warn');
      doTikTokDownload(root, v);
    };
    $('#dl-kw', root).onkeydown = e => { if (e.key === 'Enter') loadList(root); };
    bindKw(root);
    bindStop(root);
    return;
  }
  if (SITE === 'tiktok_drama') {
    const br = ENV.browser || {};
    const alive = br.alive;
    bar.innerHTML = `
      <input id="dl-kw" class="dl-input" placeholder="粘贴短剧 ID（可多行，每行一个）" value="${esc(getKw())}">
      <button class="btn sm primary" id="dl-search"><span data-icon="search"></span>查询</button>
      <button class="btn sm danger" id="dl-stop" style="display:none">停止</button>
      <button class="btn sm" id="dl-hist"><span data-icon="clock"></span>历史</button>
      <span class="dl-br">
        <span class="dl-br-dot ${alive ? 'ok' : ''}"></span>
        ${alive ? (br.headless ? '浏览器(后台)' : '浏览器(可见)') : '浏览器未启动'}
      </span>
      <button class="btn sm" id="dl-br-toggle">${alive ? '关闭浏览器' : '启动浏览器'}</button>
      <select id="dl-br-mode" class="dl-sel" title="浏览器显示方式">
        <option value="1"${br.headless ? ' selected' : ''}>后台运行</option>
        <option value="0"${br.headless ? '' : ' selected'}>显示窗口</option>
      </select>
      <span id="dl-hint" class="dl-hint"></span>`;
    $('#dl-search', root).onclick = () => loadList(root);
    $('#dl-kw', root).onkeydown = e => {
      if (e.key === 'Enter' && !e.shiftKey) loadList(root);
    };
    $('#dl-kw', root).addEventListener('input', e => { setKw(e.target.value); });
    $('#dl-hist', root).onclick = () => showHistory(root);
    $('#dl-br-toggle', root).onclick = () => toggleBrowser(root);
    $('#dl-br-mode', root).onchange = async (e) => {
      const headless = e.target.value === '1';
      try {
        await api.dlSdBrowserConfig({ headless });
        await refreshEnv();
        toast('已设置', headless ? '以后在后台运行' : '以后显示窗口', 'ok');
        paintBar(root);
      } catch (err) { toast('设置失败', err.message, 'err'); }
    };
    bindStop(root);
    return;
  }
  bar.innerHTML = `
    <input id="dl-kw" class="dl-input" placeholder="搜索剧名关键词，留空看站点全部" value="${esc(getKw())}">
    <button class="btn sm primary" id="dl-search"><span data-icon="search"></span>搜索</button>
    <button class="btn sm" id="dl-refresh"><span data-icon="refresh"></span>刷新</button>
    <button class="btn sm danger" id="dl-stop" style="display:none">停止</button>
    <span id="dl-hint" class="dl-hint"></span>`;
  $('#dl-search', root).onclick = () => loadList(root);
  $('#dl-kw', root).onkeydown = e => { if (e.key === 'Enter') loadList(root); };
  $('#dl-refresh', root).onclick = () => { setKw(''); loadList(root, true); };
  bindKw(root);
  bindStop(root);
}

function bindStop(root) {
  const b = $('#dl-stop', root);
  if (b) b.onclick = () => stopAll(root);
}

/* 刷新环境信息（浏览器状态） */
async function refreshEnv() {
  try { ENV = await api.dlEnv(); } catch (e) { }
}

/* 启动/关闭调试浏览器 */
async function toggleBrowser(root) {
  const br = ENV.browser || {};
  const btn = $('#dl-br-toggle', root);
  if (btn) { btn.disabled = true; btn.textContent = br.alive ? '关闭中…' : '启动中…'; }
  try {
    if (br.alive) {
      await api.dlSdBrowserStop();
      toast('已关闭浏览器', '内存已释放，下次查询会自动重开', 'ok');
    } else {
      const headless = ($('#dl-br-mode', root)?.value ?? '1') === '1';
      const r = await api.dlSdBrowserStart({ headless });
      toast('浏览器已启动', headless ? '后台运行（看不到窗口）' : '已显示窗口', 'ok');
    }
    await refreshEnv();
    paintBar(root);
  } catch (e) {
    toast('操作失败', e.message, 'err', 6000);
    await refreshEnv();
    paintBar(root);
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* 下载设置：根目录 + 目录结构 */
async function showCfg(root) {
  const d = $('#dl-drawer', root);
  if (!d) return;
  d.classList.add('on');
  d.innerHTML = `<div class="dl-sheet"><div class="dl-loading" style="padding:36px">读取配置…</div></div>`;

  let cfg = {};
  try { cfg = await api.dlConfig(); } catch (e) { }

  let browsePath = cfg.root || '';
  let picked = cfg.root || '';

  const paint = () => {
    const isDrama = (cfg.layout || 'drama') === 'drama';
    d.innerHTML = `
    <div class="dl-sheet" style="width:min(720px,100%)">
      <div class="dl-sheet-h" style="padding-bottom:14px">
        <div class="dl-sheet-info">
          <h2>下载设置</h2>
          <div class="dl-sheet-desc">改完立即生效，不用重启</div>
        </div>
        <button class="dl-x" data-x>✕</button>
      </div>

      <div class="dl-sheet-body" style="max-height:64vh">

        <div class="dl-cfg-sec">
          <div class="dl-cfg-label">下载根目录</div>
          <div class="dl-cfg-row">
            <input id="cfg-root" class="dl-input" value="${esc(picked)}"
                   placeholder="留空使用默认：${esc(cfg.default_root || '')}">
            <button class="btn sm" id="cfg-pick" title="打开系统文件夹选择框">选择…</button>
            <button class="btn sm" id="cfg-browse" title="在页面内逐级浏览">浏览</button>
          </div>
          <div class="dl-cfg-tip">
            当前生效：<code>${esc(cfg.effective || '')}</code>
          </div>
        </div>

        <div class="dl-cfg-sec">
          <div class="dl-cfg-label">目录结构</div>
          <label class="dl-radio ${isDrama ? 'on' : ''}">
            <input type="radio" name="layout" value="drama" ${isDrama ? 'checked' : ''}>
            <div>
              <b>按剧名</b>
              <span>&lt;根&gt;/剧名/剧名-01.mp4</span>
            </div>
          </label>
          <label class="dl-radio ${!isDrama ? 'on' : ''}">
            <input type="radio" name="layout" value="site" ${!isDrama ? 'checked' : ''}>
            <div>
              <b>按站点</b>
              <span>&lt;根&gt;/站点/剧名/剧名-01.mp4</span>
            </div>
          </label>
        </div>

        <div id="cfg-browser" class="dl-browser" style="display:none"></div>
      </div>

      <div class="dl-sheet-f">
        <span class="dl-sel-info" id="cfg-msg"></span>
        <button class="btn sm" id="cfg-reset">恢复默认</button>
        <button class="btn sm primary" id="cfg-save">保存</button>
      </div>
    </div>`;

    $$('[data-x]', d).forEach(b => b.onclick = closeDetail);

    $$('input[name="layout"]', d).forEach(r => r.onchange = () => {
      cfg.layout = r.value;
      paint();
    });

    const inp = $('#cfg-root', d);
    if (inp) inp.oninput = () => { picked = inp.value.trim(); };

    const br = $('#cfg-browse', d);
    if (br) br.onclick = () => openBrowser(root, browsePath || '');

    // 系统原生文件夹选择框
    const pk = $('#cfg-pick', d);
    if (pk) pk.onclick = async () => {
      pk.disabled = true;
      const old = pk.textContent;
      pk.textContent = '等待选择…';
      const m = $('#cfg-msg', d);
      if (m) m.textContent = '请在弹出的系统窗口里选择文件夹（可能在任务栏闪烁）';
      try {
        const r = await api.dlPickFolder(picked || '');
        if (r.cancelled) {
          if (m) m.textContent = '';
        } else if (r.path) {
          picked = r.path;
          browsePath = r.path;
          paint();
          toast('已选择', r.path, 'ok', 4000);
        }
      } catch (e) {
        toast('打开失败', e.message, 'err', 6000);
        if (m) m.textContent = e.message;
      } finally {
        pk.disabled = false;
        pk.textContent = old;
      }
    };

    const rst = $('#cfg-reset', d);
    if (rst) rst.onclick = () => { picked = ''; browsePath = ''; paint(); };

    const sv = $('#cfg-save', d);
    if (sv) sv.onclick = async () => {
      sv.disabled = true; sv.textContent = '保存中…';
      try {
        const r = await api.dlConfigSet({ root: picked, layout: cfg.layout });
        toast('已保存', r.effective, 'ok', 5200);
        LIB = null;
        closeDetail();
        if (VIEW === 'library') paintLib(root);
        else if (SITE === 'tiktok_drama') loadList(root);
      } catch (e) {
        toast('保存失败', e.message, 'err', 6000);
        const m = $('#cfg-msg', d);
        if (m) m.textContent = e.message;
        sv.disabled = false; sv.textContent = '保存';
      }
    };
  };

  const openBrowser = (rt, path) => {
    const box = $('#cfg-browser', d);
    if (!box) return;
    box.style.display = '';
    const load = async (p) => {
      box.innerHTML = `<div class="dl-loading" style="padding:16px">读取…</div>`;
      try {
        const r = await api.dlBrowse(p);
        const items = r.items || [];
        box.innerHTML = `
          <div class="dl-br-h">
            <button class="btn sm" data-up ${r.parent === null ? 'disabled' : ''}>↑ 上级</button>
            <code class="dl-br-path">${esc(r.path || '选择盘符')}</code>
          </div>
          <div class="dl-br-list">
            ${items.length ? items.map(x => `
              <div class="dl-br-item" data-p="${esc(x.path)}">
                <span data-icon="db"></span>${esc(x.name)}
              </div>`).join('')
              : '<div class="dl-br-empty">（没有子目录）</div>'}
          </div>`;
        $$('.dl-br-item', box).forEach(el => el.onclick = () => load(el.dataset.p));
        const up = $('[data-up]', box);
        if (up && r.parent !== null) up.onclick = () => load(r.parent || '');
      } catch (e) {
        box.innerHTML = `<div class="dl-br-empty">${esc(e.message)}</div>`;
      }
    };
    load(path);
  };

  paint();
}

/* 查询历史 */
async function showHistory(root) {
  const d = $('#dl-drawer', root);
  if (!d) return;
  d.classList.add('on');
  d.innerHTML = `<div class="dl-sheet"><div class="dl-loading" style="padding:36px">读取历史…</div></div>`;
  let items = [];
  try {
    const r = await api.dlSdHistory();
    items = r.items || [];
  } catch (e) {
    d.innerHTML = `<div class="dl-sheet"><div class="dl-err">${esc(e.message)}</div></div>`;
    return;
  }
  const rows = items.map(x => `
    <div class="dl-hist-row" data-hid="${esc(x.id)}">
      <div class="dl-hist-main">
        <div class="dl-hist-name">${esc(x.name || '(无名)')}</div>
        <div class="dl-hist-sub">
          ${esc(x.id)} · ${x.total || 0} 集
          ${x.watched ? ' · ' + fmtNum(x.watched) + ' 播放' : ''}
          ${x.author ? ' · @' + esc(x.author) : ''}
          ${x.degraded ? ' · <span style="color:var(--warn)">降级</span>' : ''}
        </div>
      </div>
      <div class="dl-hist-acts">
        <button class="btn sm" data-req>填入</button>
        <button class="btn sm" data-del>删除</button>
      </div>
    </div>`).join('');

  d.innerHTML = `
  <div class="dl-sheet">
    <div class="dl-sheet-h" style="padding-bottom:14px">
      <div class="dl-sheet-info">
        <h2>查询历史</h2>
        <div class="dl-sheet-desc">共 ${items.length} 部 · 本地保留最近 300 条</div>
      </div>
      <button class="dl-x" data-x>✕</button>
    </div>
    <div class="dl-sheet-body" style="max-height:58vh">
      ${items.length ? rows : emptyState('还没有查询记录', '查过的剧会自动记在这里')}
    </div>
    <div class="dl-sheet-f">
      <span class="dl-sel-info">点「填入」把 ID 放进输入框</span>
      <button class="btn sm danger" data-clear>清空历史</button>
    </div>
  </div>`;

  $$('[data-x]', d).forEach(b => b.onclick = closeDetail);
  $$('[data-req]', d).forEach(b => b.onclick = () => {
    const id = b.closest('.dl-hist-row').dataset.hid;
    setKw(id);
    closeDetail();
    paintBar(root);
    toast('已填入', id, 'ok');
  });
  $$('[data-del]', d).forEach(b => b.onclick = async () => {
    const id = b.closest('.dl-hist-row').dataset.hid;
    try {
      await api.dlSdHistoryClear([id]);
      const row = b.closest('.dl-hist-row');
      if (row) row.remove();
      toast('已删除', id, 'ok');
    } catch (e) { toast('删除失败', e.message, 'err'); }
  });
  const clr = $('[data-clear]', d);
  if (clr) clr.onclick = async () => {
    try {
      await api.dlSdHistoryClear(null);
      closeDetail();
      toast('历史已清空', '', 'ok');
    } catch (e) { toast('清空失败', e.message, 'err'); }
  };
}

/* 中断当前所有在跑的请求 */
function stopAll(root) {
  if (CTL) {
    try { CTL.abort(); } catch (_) {}
    CTL = null;
  }
  RUNNING = false;
  const scope = root && root.querySelector ? root : document;
  setStopVisible(root, false);
  const grid = scope.querySelector('#dl-grid');
  const loading = grid && grid.querySelector('.dl-loading');
  if (grid && loading) {
    grid.innerHTML = emptyState('已停止', '点「搜索」重新开始');
  } else {
    toast('已停止', '当前请求已中断', 'ok');
  }
  const hint = scope.querySelector('#dl-hint');
  if (hint && /加载|解析/.test(hint.textContent)) hint.textContent = '已停止';
}

function setStopVisible(root, on) {
  const scope = root && root.querySelector ? root : document;
  const b = scope.querySelector('#dl-stop');
  if (b) b.style.display = on ? '' : 'none';
  const s = scope.querySelector('#dl-search');
  if (s) s.disabled = !!on;
}

function bindKw(root) {
  const el = $('#dl-kw', root);
  if (el) el.addEventListener('input', e => { setKw(e.target.value); });
}

async function loadList(root) {
  if (VIEW === 'library') { LIB = null; return paintLib(root); }
  const grid = $('#dl-grid', root);
  const hint = $('#dl-hint', root);
  if (!grid) return;
  if (SITE === 'tiktok') return loadTikTokMeta(root);
  if (SITE === 'tiktok_drama') return loadSdMeta(root);

  // 新请求前先中断旧的
  if (CTL) { try { CTL.abort(); } catch (_) {} }
  CTL = new AbortController();
  const sig = CTL.signal;
  RUNNING = true;
  setStopVisible(root, true);

  const kw = ($('#dl-kw', root)?.value ?? getKw()).trim();
  setKw(kw);
  grid.innerHTML = `<div class="dl-loading">加载中…<span style="opacity:.6">
    （可点「停止」中断）</span></div>`;
  if (hint) hint.textContent = '';

  try {
    const r = await api.dlSearch(SITE, kw, 60, sig);
    if (sig.aborted || !document.getElementById('dl-grid')) return;
    const items = r.items || [];
    if (hint) hint.textContent = `命中 ${r.total} 部，显示 ${items.length} 部`;
    rows = items.map(x => ({ slug: x.slug, site: x.site, name: x.slug, ready: false }));
    SCROLL = 0;
    paintGrid(root);

    // 并发补元数据；每批前检查是否已停止
    let i = 0;
    const q = rows.slice(0, 30);
    let doneN = 0;
    const setProgress = () => {
      if (hint && !sig.aborted) {
        hint.textContent = `命中 ${r.total} 部 · 已解析 ${doneN}/${q.length}`;
      }
    };
    setProgress();
    const worker = async () => {
      while (i < q.length) {
        if (sig.aborted) return;
        const it = q[i++];
        try {
          const m = await api.dlMeta(it.site, it.slug, 0, sig);
          if (sig.aborted) return;
          it.name = m.name || it.slug;
          it.cover = m.cover || '';
          it.total = m.total || 0;
          it.free = (m.eps || []).filter(e => e.free).length;
          it.ready = true;
          updateCard(document.getElementById('view'), it);
        } catch (e) {
          if (e.name === 'AbortError' || sig.aborted) return;
          // 单部失败不中断其它，标记一下即可
          it.ready = true;
          it.name = it.name || it.slug;
          updateCard(document.getElementById('view'), it);
        } finally {
          doneN++;
          setProgress();
        }
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
    if (sig.aborted) {
      if (hint) hint.textContent += ' · 已停止';
    } else if (hint) {
      hint.textContent = `命中 ${r.total} 部，显示 ${items.length} 部`;
    }
  } catch (e) {
    if (e.name === 'AbortError' || sig.aborted) {
      const g2 = document.getElementById('dl-grid');
      if (g2 && !rows.length) {
        g2.innerHTML = emptyState('已停止', '点「搜索」重新开始');
      }
      return;
    }
    grid.innerHTML = emptyState('加载失败', e.message);
  } finally {
    if (CTL && CTL.signal === sig) {
      RUNNING = false;
      setStopVisible(root, false);
    }
  }
}

async function loadTikTokMeta(root) {
  const grid = $('#dl-grid', root);
  const hint = $('#dl-hint', root);
  const raw = ($('#dl-kw', root)?.value ?? getKw()).trim();
  setKw(raw);
  if (!raw) { grid.innerHTML = emptyState('输入 TikTok 作品 ID', '支持纯 ID 或整条链接'); return; }
  // 同一个 ID 且已有缓存 → 直接显示
  if (TK && TK.key === raw) {
    grid.innerHTML = tkMetaHtml(TK.m);
    bindTk(root, TK.m);
    if (hint) hint.textContent = `@${TK.m.author?.uniqueId || '—'}`;
    return;
  }
  grid.innerHTML = `<div class="dl-loading">查询中…</div>`;
  try {
    const m = await api.dlTikTokMeta(raw);
    TK = { key: raw, m };
    if (hint) hint.textContent = `@${m.author?.uniqueId || '—'}`;
    grid.innerHTML = tkMetaHtml(m);
    bindTk(root, m);
  } catch (e) {
    grid.innerHTML = `<div class="dl-card" style="grid-column:1/-1;padding:18px">
      <div style="color:var(--danger);font-size:12px">${esc(e.message)}</div></div>`;
  }
}

function bindTk(root, m) {
  const grid = $('#dl-grid', root);
  if (!grid) return;
  const own = $('#dl-tk-play', grid);
  if (own && m.local && m.local.length) {
    own.onclick = () => playLocal(root,
      m.local.map((f, i) => ({ ep: i + 1, path: f.path })), m.desc || m.id);
  }
  const dlBtn = $('#dl-tk-dl', grid);
  if (dlBtn) dlBtn.onclick = () => doTikTokDownload(root, getKw());
  const openBtn = $('#dl-tk-open', grid);
  if (openBtn) openBtn.onclick = () => window.open(m.web_url, '_blank');
}

function tkMetaHtml(m) {
  const a = m.author || {}, st = m.stats || {};
  const cover = m.cover ? `/api/dl/cover?u=${encodeURIComponent(m.cover)}` : '';
  const local = (m.local || []).length;
  return `
  <div class="dl-tkc">
    <div class="dl-tkc-body">
      ${cover ? `<img class="dl-tkc-img" src="${cover}" onerror="this.style.opacity=.15">`
              : '<div class="dl-tkc-img"></div>'}
      <div class="dl-tkc-info">
        <div class="dl-tkc-desc">${esc(m.desc || '（无描述）')}</div>
        <div class="dl-tkc-meta">
          <b>${esc(a.nick || a.uniqueId || '—')}</b>
          ${a.verified ? '<span class="dl-tag">已认证</span>' : ''}
          <span class="dl-tag mute">@${esc(a.uniqueId || '—')}</span>
          ${a.followers ? `<span class="dl-tag mute">粉丝 ${fmtNum(a.followers)}</span>` : ''}
        </div>
        <div class="dl-tkc-sub">
          ID ${esc(m.id)} · ${fmtDur(m.duration)} · ${m.width || 0}×${m.height || 0}
          ${m.create ? ' · ' + new Date(m.create * 1000).toISOString().slice(0, 10) : ''}
        </div>
      </div>
    </div>
    <div class="dl-tkc-stats">
      <div><b>${fmtNum(st.play)}</b><span>播放</span></div>
      <div><b>${fmtNum(st.like)}</b><span>点赞</span></div>
      <div><b>${fmtNum(st.comment)}</b><span>评论</span></div>
      <div><b>${fmtNum(st.share)}</b><span>分享</span></div>
    </div>
    <div class="dl-tkc-acts">
      <span class="dl-sel-info">${local ? '✓ 本地已有 ' + local + ' 个文件' : '尚未下载'}</span>
      ${local ? '<button class="btn sm" id="dl-tk-play">播放本地</button>' : ''}
      <button class="btn sm" id="dl-tk-open">打开原页</button>
      <button class="btn sm primary" id="dl-tk-dl">下载</button>
    </div>
  </div>`;
}

async function loadSdMeta(root) {
  const grid = $('#dl-grid', root);
  const raw = ($('#dl-kw', root)?.value ?? getKw()).trim();
  setKw(raw);

  // 始终先加载历史（历史里的剧一直显示）
  const hist = await loadSdHistorySafe();

  if (!raw) {
    renderSdBoard(root, hist, []);
    return;
  }
  const ids = Array.from(new Set(raw.match(/\d{15,25}/g) || []));
  if (!ids.length) {
    renderSdBoard(root, hist, []);
    toast('没识别到 ID', '需要 15–25 位数字', 'warn');
    return;
  }

  // 同一批 ID 且已有缓存 → 直接还原
  if (SD && SD.key === ids.join(',')) {
    renderSdBoard(root, hist, SD.results);
    return;
  }

  if (CTL) { try { CTL.abort(); } catch (_) { } }
  CTL = new AbortController();
  const sig = CTL.signal;
  RUNNING = true;
  setStopVisible(root, true);

  const n = ids.length;
  const results = [];
  renderSdBoard(root, hist, results, `正在批量查询 ${n} 部…`);

  try {
    for (let i = 0; i < n; i++) {
      if (sig.aborted) break;
      const did = ids[i];
      const hint = document.querySelector('#dl-hint');
      if (hint) hint.textContent = `${i + 1}/${n} 查询中…`;
      renderSdBoard(root, hist, results,
        `${i + 1}/${n} 查询中 · ${did}`);
      try {
        const m = await api.dlSdMeta(did, 0, sig);
        results.push({ ok: true, m });
        // 新查到的立刻进历史
        hist.unshift({ id: m.id, name: m.name, total: m.total,
                       watched: m.watched, cover: m.cover,
                       author: (m.author || {}).uniqueId || '',
                       degraded: m.degraded });
      } catch (e) {
        if (e.name === 'AbortError' || sig.aborted) break;
        results.push({ ok: false, id: did, err: e.message });
      }
    }
  } finally {
    if (CTL && CTL.signal === sig) {
      RUNNING = false;
      setStopVisible(root, false);
    }
  }

  const okN = results.filter(r => r.ok).length;
  SD = { key: ids.join(','), results };
  const hint = document.querySelector('#dl-hint');
  if (hint) hint.textContent = sig.aborted
    ? `${okN}/${n} 成功 · 已停止`
    : `${okN}/${n} 成功`;
  const hist2 = await loadSdHistorySafe();
  renderSdBoard(root, hist2, results);
}

async function loadSdHistorySafe() {
  try {
    const r = await api.dlSdHistory();
    return r.items || [];
  } catch (e) {
    return [];
  }
}

/* 渲染底板：历史区（常驻） + 本次结果区 */
function renderSdBoard(root, hist, results, busyText) {
  const grid = $('#dl-grid', root);
  if (!grid) return;

  // 让外层退化成块级布局（否则网格只占 1 格，右侧全空）
  grid.classList.add('stacked');

  // 本次结果里的 id，避免和历史重复
  const gotIds = new Set(results.filter(r => r.ok).map(r => String(r.m.id)));
  const histOnly = hist.filter(h => !gotIds.has(String(h.id)));

  const histHtml = histOnly.length ? `
    <div class="dl-sec">
      <div class="dl-sec-h">
        <span>已查过的剧 · ${histOnly.length}</span>
        <button class="btn sm" id="dl-hist-clear">清空</button>
      </div>
      <div class="dl-grid-inner">
        ${histOnly.map(h => `
          <div class="dl-card" data-hist-id="${esc(h.id)}">
            <div class="dl-ph ${h.cover ? '' : 'noimg'}">
              ${h.cover ? `<img loading="lazy" src="/api/dl/cover?u=${encodeURIComponent(h.cover)}"
                    onload="this.classList.add('ok');this.parentNode.classList.remove('noimg')"
                    onerror="this.remove();this.parentNode.classList.add('noimg')">` : ''}
              ${h.total ? `<span class="dl-badge">${h.total} 集</span>` : ''}
              ${h.degraded ? `<span class="dl-badge warn" style="left:auto;right:6px">降级</span>` : ''}
            </div>
            <div class="dl-info">
              <div class="dl-name">${esc(h.name || h.id)}</div>
              <div class="dl-sub">${h.watched ? fmtNum(h.watched) + ' 观看' : esc(h.id)}</div>
            </div>
            <div class="dl-hist-acts">
              <button class="btn sm" data-req>重查</button>
              <button class="btn sm danger" data-drop>移除</button>
            </div>
          </div>`).join('')}
      </div>
    </div>` : '';

  const resHtml = results.length ? `
    <div class="dl-sec">
      <div class="dl-sec-h"><span>本次结果 · ${results.filter(r => r.ok).length}/${results.length}</span></div>
      <div class="dl-grid-inner">
        ${results.map(r => r.ok ? sdCardHtml(r.m) : sdErrHtml(r.id, r.err)).join('')}
      </div>
    </div>` : '';

  const busyHtml = busyText ? `<div class="dl-loading">${esc(busyText)}</div>` : '';

  const empty = (!histOnly.length && !results.length && !busyText)
    ? emptyState('还没有查过的剧',
        '在上面粘贴 ID 查询，查过的剧会一直留在这里')
    : '';

  grid.innerHTML = busyHtml + resHtml + histHtml + empty;

  // 事件绑定
  bindSd(root, results);
  $$('[data-hist-id]', grid).forEach(c => {
    const id = c.dataset.histId;
    c.onclick = (ev) => {
      if (ev.target.closest('button')) return;
      quickOpen(root, id);
    };
    const req = $('[data-req]', c);
    if (req) req.onclick = (ev) => {
      ev.stopPropagation();
      setKw(id); paintBar(root); loadList(root);
    };
    const drop = $('[data-drop]', c);
    if (drop) drop.onclick = async (ev) => {
      ev.stopPropagation();
      try {
        await api.dlSdHistoryClear([id]);
        const h2 = await loadSdHistorySafe();
        renderSdBoard(root, h2, results);
        toast('已移除', id, 'ok');
      } catch (e) { toast('移除失败', e.message, 'err'); }
    };
  });
  const clr = $('#dl-hist-clear', grid);
  if (clr) clr.onclick = async () => {
    try {
      await api.dlSdHistoryClear(null);
      renderSdBoard(root, [], results);
      toast('历史已清空', '', 'ok');
    } catch (e) { toast('清空失败', e.message, 'err'); }
  };
}

/* 点历史卡片：直接打开详情（不重新查询） */
async function quickOpen(root, id) {
  try {
    const m = await api.dlSdMeta(id, 0, null);
    openSdDetail(root, m);
  } catch (e) {
    toast('打开失败', e.message, 'err');
  }
}

function bindSd(root, results) {
  const grid = $('#dl-grid', root);
  if (!grid) return;
  const rs = results || (SD && SD.results) || [];
  $$('[data-sd-slug]', grid).forEach(c => c.onclick = () => {
    const did = c.dataset.sdSlug;
    const r = rs.find(x => x.ok && x.m.id === did);
    if (r) openSdDetail(root, r.m);
  });
}

function sdCardHtml(m) {
  const cover = m.cover ? `/api/dl/cover?u=${encodeURIComponent(m.cover)}` : '';
  return `
  <div class="dl-card" data-sd-slug="${esc(m.id)}">
    <div class="dl-ph ${cover ? '' : 'noimg'}">
      ${cover ? `<img loading="lazy" src="${cover}"
            onload="this.classList.add('ok');this.parentNode.classList.remove('noimg')"
            onerror="this.remove();this.parentNode.classList.add('noimg')">` : ''}
      ${m.total ? `<span class="dl-badge">${m.total} 集</span>` : ''}
    </div>
    <div class="dl-info">
      <div class="dl-name">${esc(m.name || m.id)}</div>
      <div class="dl-sub">${esc(m.author?.uniqueId ? '@' + m.author.uniqueId : '')} · ${fmtNum(m.watched)} 观看</div>
    </div>
  </div>`;
}

/* 查询失败：给出原因 + 可直接点开的验证链接 */
function sdErrHtml(id, err) {
  const e = String(err || '');
  const noCdp = /9222|调试端口/.test(e);
  const lines = e.split('\n').filter(Boolean);
  const head = lines[0] || '查询失败';
  const rest = lines.slice(1);
  return `
  <div class="dl-sderr">
    <div class="dl-sderr-h">
      <span class="dl-sderr-id">${esc(id)}</span>
      <span class="dl-sderr-tag ${noCdp ? 'warn' : 'mute'}">${noCdp ? '环境未就绪' : '该剧抓不到'}</span>
    </div>
    <div class="dl-sderr-msg">${esc(head)}</div>
    ${rest.length ? `<div class="dl-sderr-sub">${rest.map(esc).join('<br>')}</div>` : ''}
    <div class="dl-sderr-acts">
      <a class="btn sm" target="_blank"
         href="https://www.tiktok.com/shortdrama/episode/${esc(id)}/1">在浏览器验证</a>
      ${noCdp ? `<span class="dl-sderr-tip">运行「启动Chrome带调试端口.bat」后重试</span>` : ''}
    </div>
  </div>`;
}

async function doTikTokDownload(root, raw) {
  try {
    const r = await api.dlTikTokDownload(raw);
    toast('已加入队列', 'TikTok 下载中', 'ok');
    refreshTasks(root);
  } catch (e) {
    toast('下载失败', e.message, 'err');
  }
}

function paintGrid(root) {
  { const g = document.getElementById('dl-grid'); if (g) g.classList.remove('stacked'); }
  const grid = $('#dl-grid', root);
  if (!grid) return;
  if (!rows.length) {
    grid.innerHTML = emptyState('没有匹配的剧', '换个关键词，或点「刷新」重拉站点目录');
    return;
  }
  grid.innerHTML = rows.map(it => cardHtml(it)).join('');
  $$('.dl-card', grid).forEach(c => c.onclick = () => {
    const it = rows.find(x => x.slug === c.dataset.slug);
    if (it) openDetail(root, it);
  });
}

function cardHtml(it) {
  const cover = it.cover ? `/api/dl/cover?u=${encodeURIComponent(it.cover)}` : '';
  const meta = it.ready ? `${it.total || '?'} 集 · ${it.free || 0} 免费` : '…';
  return `
  <div class="dl-card" data-slug="${esc(it.slug)}">
    <div class="dl-ph ${cover ? '' : 'noimg'}">
      ${cover ? `<img loading="lazy" src="${cover}"
            onload="this.classList.add('ok');this.parentNode.classList.remove('noimg')"
            onerror="this.remove();this.parentNode.classList.add('noimg')">` : ''}
      ${it.free ? `<span class="dl-badge">${it.free} 免费</span>` : ''}
    </div>
    <div class="dl-info">
      <div class="dl-name">${esc(it.name || it.slug)}</div>
      <div class="dl-sub">${esc(meta)}</div>
    </div>
  </div>`;
}

function updateCard(root, it) {
  const c = $(`.dl-card[data-slug="${cssEsc(it.slug)}"]`, root);
  if (!c) return;
  const ph = $('.dl-ph', c);
  // 先把 img 挂进 DOM 再设 src，否则 new Image() 的加载事件不一定触发
  if (ph && it.cover && !$('img', ph)) {
    const img = document.createElement('img');
    img.loading = 'lazy';
    img.decoding = 'async';
    img.onload = () => {
      img.classList.add('ok');
      ph.classList.remove('noimg');
    };
    img.onerror = () => {
      if (img.parentNode) img.parentNode.removeChild(img);
      ph.classList.add('noimg');
    };
    ph.insertBefore(img, ph.firstChild);
    img.src = `/api/dl/cover?u=${encodeURIComponent(it.cover)}`;
  }
  const nm = $('.dl-name', c);
  if (nm) nm.textContent = it.name || it.slug;
  const sub = $('.dl-sub', c);
  if (sub) sub.textContent = `${it.total || '?'} 集 · ${it.free || 0} 免费`;
  if (it.free && ph && !$('.dl-badge', ph)) {
    const b = document.createElement('span');
    b.className = 'dl-badge';
    b.textContent = `${it.free} 免费`;
    ph.appendChild(b);
  }
}

/* ---------------- 详情 ---------------- */
async function openDetail(root, it) {
  const d = $('#dl-drawer', root);
  if (!d) return;
  d.classList.add('on');
  d.innerHTML = `<div class="dl-sheet"><div class="dl-loading" style="padding:40px">加载剧集…</div></div>`;
  try {
    const m = await api.dlMeta(it.site, it.slug);
    CUR = m; CUR.site = it.site;
    SEL.clear();
    renderDetail(root, m);
  } catch (e) {
    d.innerHTML = `<div class="dl-sheet"><div class="dl-err">${esc(e.message)}</div></div>`;
  }
}

function openSdDetail(root, m) {
  const d = $('#dl-drawer', root);
  d.classList.add('on');
  CUR = m; SEL.clear();
  renderDetail(root, m, 'tiktok_drama');
}

function renderDetail(root, m, forceSite) {
  const d = $('#dl-drawer', root);
  const eps = m.eps || [];
  const own = new Set(m.local_eps || []);
  const freeN = eps.filter(e => e.free).length;
  const cover = m.cover ? `/api/dl/cover?u=${encodeURIComponent(m.cover)}` : '';
  const site = forceSite || m.site;

  d.innerHTML = `
  <div class="dl-sheet">
    <div class="dl-sheet-h">
      ${cover ? `<img src="${cover}" onerror="this.style.opacity=.15">` : '<div class="dl-noimg"></div>'}
      <div class="dl-sheet-info">
        <h2>${esc(m.name || m.slug || m.id)}</h2>
        <div class="dl-sheet-meta">
          ${(m.genres || []).slice(0, 5).map(g => `<span class="dl-tag">${esc(g)}</span>`).join('')}
          ${m.rating ? `<span class="dl-tag gold">★ ${esc(m.rating)}</span>` : ''}
          <span class="dl-tag mute">${esc(siteName(site))}</span>
        </div>
        <div class="dl-sheet-desc">${esc((m.desc || '').slice(0, 300))}</div>
        ${m.note ? `<div class="dl-note">⚠ ${esc(m.note)}</div>` : ''}
      </div>
      <button class="dl-x" data-x>✕</button>
    </div>
    <div class="dl-sheet-stats">
      <div><b>${m.total || eps.length}</b><span>总集数</span></div>
      <div><b>${freeN}</b><span>可用</span></div>
      <div><b>${own.size}</b><span>已下载</span></div>
      ${m.watched ? `<div><b>${fmtNum(m.watched)}</b><span>观看</span></div>` : ''}
    </div>
    <div class="dl-sheet-body">
      <div class="dl-tip">${eps.length ? '点击选集（青色=选中，绿色=已下载，虚线=不可用）' : '未拿到分集列表'}</div>
      <div class="dl-eps" id="dl-eps">
        ${eps.map(e => `<div class="dl-ep ${e.free ? '' : 'lock'} ${own.has(e.ep) ? 'own' : ''}"
             data-ep="${e.ep}">${e.ep}</div>`).join('')}
      </div>
    </div>
    <div class="dl-sheet-f">
      <span class="dl-sel-info" id="dl-selinfo">未选择</span>
      <button class="btn sm" data-act="all">全选未下载</button>
      <button class="btn sm primary" data-act="go">开始下载</button>
    </div>
  </div>`;

  $$('[data-x]', d).forEach(b => b.onclick = closeDetail);
  $$('.dl-ep', d).forEach(el => {
    const ep = +el.dataset.ep;
    if (el.classList.contains('lock')) {
      el.onclick = () => toast('这一集没有可用地址', '付费或接口未下发', 'warn');
      return;
    }
    if (el.classList.contains('own')) {
      el.onclick = () => toast('已经下载过了', `第 ${ep} 集`, 'ok');
      return;
    }
    el.onclick = () => {
      if (SEL.has(ep)) { SEL.delete(ep); el.classList.remove('sel'); }
      else { SEL.add(ep); el.classList.add('sel'); }
      updSel(d);
    };
  });
  const allBtn = $('[data-act="all"]', d);
  if (allBtn) allBtn.onclick = () => {
    SEL.clear();
    $$('.dl-ep', d).forEach(el => {
      if (!el.classList.contains('lock') && !el.classList.contains('own')) {
        SEL.add(+el.dataset.ep); el.classList.add('sel');
      }
    });
    updSel(d);
  };
  const goBtn = $('[data-act="go"]', d);
  if (goBtn) goBtn.onclick = async () => {
    if (!SEL.size) return;
    try {
      const r = await api.dlDownload({
        site, slug: m.slug || m.id, eps: [...SEL],
        lang: (m.langs || ['en'])[0],
      });
      toast('已加入队列', `${r.count} 集`, 'ok');
      closeDetail();
      refreshTasks(root);
    } catch (e) {
      toast('下载失败', e.message, 'err');
    }
  };
  updSel(d);
}

function updSel(d) {
  const info = $('#dl-selinfo', d);
  if (info) info.textContent = SEL.size ? `已选 ${SEL.size} 集` : '未选择';
  const go = $('[data-act="go"]', d);
  if (go) go.disabled = !SEL.size;
}

function closeDetail() {
  const d = document.getElementById('dl-drawer');
  if (d) { d.classList.remove('on'); d.innerHTML = ''; }
  CUR = null; SEL.clear();
}

/* ---------------- 任务 ---------------- */
async function refreshTasks(root) {
  try {
    const r = await api.dlTasks();
    TASKS = r.items || [];
    paintTasks(root);
  } catch (e) { }
}

function paintTasks(root) {
  const box = $('#dl-tasks', root);
  if (!box) return;
  if (!TASKS.length) { box.innerHTML = ''; return; }
  box.innerHTML = TASKS.slice(0, 6).map(t => {
    const p = t.total ? Math.round(t.finished / t.total * 100) : 0;
    const cur = (t.eps.find(e => e.state === 'run') || {}).msg || '';
    return `
    <div class="dl-task">
      <div class="dl-task-h">
        <div class="dl-task-n">${esc(t.name)}</div>
        <div class="dl-task-m">${t.finished}/${t.total} 集 · ${fmtSize(t.bytes)}${t.done ? ' · 完成' : (cur ? ' · ' + esc(cur) : '')}</div>
        <button class="dl-task-x" data-tid="${t.id}" data-done="${t.done ? 1 : 0}">${t.done ? '✕' : '■'}</button>
      </div>
      <div class="dl-task-bar"><i style="width:${p}%"></i></div>
    </div>`;
  }).join('');
  $$('.dl-task-x', box).forEach(b => b.onclick = async () => {
    const id = +b.dataset.tid;
    try {
      if (b.dataset.done === '1') await api.dlRemove(id);
      else await api.dlCancel(id);
      refreshTasks(root);
    } catch (e) { }
  });
}

/* ---------------- 片库 ---------------- */
async function paintLib(root) {
  { const g = document.getElementById('dl-grid'); if (g) g.classList.remove('stacked'); }
  const grid = $('#dl-grid', root);
  const hint = $('#dl-hint', root);
  paintBar(root);

  // 有缓存且未失效 → 直接还原，不重扫
  if (LIB) {
    renderLib(root, LIB);
    return;
  }

  grid.innerHTML = `<div class="dl-loading">扫描片库…</div>`;
  try {
    const r = await api.dlLibrary();
    LIB = r;
    renderLib(root, r);
  } catch (e) {
    grid.innerHTML = emptyState('读取片库失败', e.message);
  }
}

function renderLib(root, r) {
  { const g = document.getElementById('dl-grid'); if (g) g.classList.remove('stacked'); }
  const grid = $('#dl-grid', root);
  const hint = $('#dl-hint', root);
  if (hint) hint.textContent = `${r.series} 部 · ${r.files} 个文件 · ${fmtSize(r.bytes)}`;
  if (!r.items.length) {
    grid.innerHTML = emptyState('片库还是空的', '去「发现」挑几部下');
    return;
  }
  grid.innerHTML = r.items.map(it => `
      <div class="dl-card">
        <div class="dl-ph lib noimg">
          <span class="dl-own">已下 ${it.count}${it.total ? '/' + it.total : ''} 集</span>
        </div>
        <div class="dl-info">
          <div class="dl-name">${esc(it.dir)}</div>
          <div class="dl-sub">${esc(it.site_name)} · ${it.count} 集 · ${fmtSize(it.bytes)}</div>
        </div>
        <div class="dl-lib-acts">
          <button class="btn sm" data-play>播放</button>
          <button class="btn sm" data-slice title="硬链接到源素材根，切片页可直接选">切片</button>
        </div>
      </div>`).join('');

  $$('.dl-card', grid).forEach((c, idx) => {
    const it = r.items[idx];
    if (!it) return;
    const pb = $('[data-play]', c);
    const sb = $('[data-slice]', c);
    if (pb) pb.onclick = (ev) => {
      ev.stopPropagation();
      playLocal(root, null, it.dir, it.site, it.slug || it.dir);
    };
    if (sb) sb.onclick = async (ev) => {
      ev.stopPropagation();
      sb.disabled = true; sb.textContent = '处理中…';
      try {
        const res = await api.dlSlice({ site: it.site, dir: it.dir });
        toast('已送去切片', `${res.total} 集 · ${res.target}`, 'ok', 5200);
      } catch (e) {
        toast('送去切片失败', e.message, 'err');
      } finally {
        sb.disabled = false; sb.textContent = '切片';
      }
    };
  });
}

async function playLocal(root, files, name, site, slug) {
  const pv = $('#dl-player', root);
  try {
    let fs = files;
    if (!fs) {
      const r = await api.dlEpisodes(site, slug);
      fs = (r.files || []).map(f => ({ ep: f.ep, path: f.path }));
      name = r.name || name;
    }
    if (!fs.length) { toast('没有视频文件', '', 'warn'); return; }
    PV = { files: fs, idx: 0, name };
    pv.classList.add('on');
    pv.innerHTML = `
      <div class="dl-pv">
        <div class="dl-pv-h">
          <span class="dl-pv-ep" id="dl-pv-ep">EP 1</span>
          <span class="dl-pv-t">${esc(PV.name)}</span>
          <button class="dl-x" data-pvx>✕</button>
        </div>
        <video id="dl-video" controls playsinline preload="metadata"></video>
        <div class="dl-pv-nav">
          <button class="btn sm" id="dl-prev">上一集</button>
          <span id="dl-idx" class="dl-pv-idx">—</span>
          <button class="btn sm" id="dl-next">下一集</button>
        </div>
      </div>`;
    $$('[data-pvx]', pv).forEach(b => b.onclick = closePlayer);
    $('#dl-prev', pv).onclick = () => playIdx(PV.idx - 1);
    $('#dl-next', pv).onclick = () => playIdx(PV.idx + 1);
    playIdx(0);
  } catch (e) {
    toast('打开失败', e.message, 'err');
  }
}

function playIdx(i) {
  if (!PV.files.length) return;
  PV.idx = Math.max(0, Math.min(i, PV.files.length - 1));
  const f = PV.files[PV.idx];
  const v = document.getElementById('dl-video');
  if (v) { v.src = `/api/dl/play?path=${encodeURIComponent(f.path)}`; v.play().catch(() => { }); }
  const epEl = document.getElementById('dl-pv-ep');
  if (epEl) epEl.textContent = 'EP ' + f.ep;
  const idxEl = document.getElementById('dl-idx');
  if (idxEl) idxEl.textContent = `${PV.idx + 1} / ${PV.files.length}`;
}

function closePlayer() {
  const pv = document.getElementById('dl-player');
  const v = document.getElementById('dl-video');
  if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
  if (pv) { pv.classList.remove('on'); pv.innerHTML = ''; }
}

/* ---------------- 工具 ---------------- */
function siteName(id) {
  const s = SITES.find(x => x.id === id);
  return s ? s.name : id;
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}
function cssEsc(s) { return String(s).replace(/["\\]/g, '\\$&'); }
function fmtSize(b) {
  b = Number(b) || 0;
  if (b > 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
  if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
  return Math.round(b / 1024) + ' KB';
}
function fmtNum(n) {
  n = Number(n) || 0;
  if (n >= 1e8) return (n / 1e8).toFixed(1) + '亿';
  if (n >= 1e4) return (n / 1e4).toFixed(1) + '万';
  return String(n);
}
function fmtDur(s) {
  s = Math.round(Number(s) || 0);
  if (!s) return '—';
  const m = Math.floor(s / 60), ss = s % 60;
  return `${m}:${String(ss).padStart(2, '0')}`;
}

export function destroy() {
  if (timer) { clearInterval(timer); timer = null; }
}
