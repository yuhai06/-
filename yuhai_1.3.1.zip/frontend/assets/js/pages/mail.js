/* 邮箱与验证码（真实数据） */
import { icon } from '../icons.js';
import { api } from '../api.js';
import { store } from '../store.js';
import {
  badge, pageHead, statCard, ts, ago, $, $$, toast, modal, copyText, emptyState,
} from '../ui.js';

// 后端支持 6 种邮箱通道
const CH_KINDS = {
  imap: {
    name: 'IMAP 邮箱（最常用）',
    desc: '用邮箱的 IMAP 读验证码。QQ/163/企业邮箱都支持',
    steps: [
      '登录你的邮箱网页版',
      '进「设置 → 账号 → POP3/IMAP/SMTP」开启 IMAP 服务',
      '生成「授权码」（不是登录密码！）15-20 位字符串',
      '把授权码填到下面',
    ],
    fields: [
      { k: 'host', label: 'IMAP 服务器', ph: 'imap.qq.com  /  imap.163.com',
        hint: ' QQ 用 imap.qq.com，163 用 imap.163.com' },
      { k: 'port', label: '端口', ph: '993', def: '993',
        hint: ' SSL 端口固定 993' },
      { k: 'user', label: '邮箱账号', ph: 'xxx@qq.com' },
      { k: 'password', label: '授权码', ph: '在邮箱设置里生成的那个',
        hint: ' 不是登录密码，是「授权码」' },
    ],
  },
  gmail: {
    name: 'Gmail（应用专用密码）',
    desc: 'Google 账号专用，必须开两步验证才能生成',
    steps: [
      '打开 myaccount.google.com/security',
      '开启「两步验证」（必须）',
      '进「应用专用密码」→ 选「邮件」→ 生成',
      '复制那 16 位字母（去掉空格）填到下面',
    ],
    fields: [
      { k: 'user', label: 'Gmail 地址', ph: 'xxx@gmail.com' },
      { k: 'password', label: '应用专用密码', ph: '16 位字母',
        hint: ' 形如 abcdefghijklmnop，空格要去掉' },
    ],
  },
  graph: {
    name: 'Microsoft Graph（Outlook）',
    desc: 'Outlook / Hotmail 走 Azure 应用授权',
    steps: [
      '打开 portal.azure.com → 应用注册',
      '新建应用 → 记下「应用程序(客户端) ID」和「目录(租户) ID」',
      '「证书和密码」→ 新建客户端密码 → 记下值',
      '「API 权限」→ 添加 Mail.Read',
    ],
    fields: [
      { k: 'tenant', label: 'Tenant ID（租户 ID）', ph: 'Azure 里的目录 ID' },
      { k: 'clientId', label: 'Client ID（应用 ID）', ph: 'Azure 里的应用 ID' },
      { k: 'clientSecret', label: 'Client Secret（密钥）', ph: 'Azure 里生成的密码值' },
      { k: 'user', label: '邮箱账号', ph: 'xxx@outlook.com' },
    ],
  },
  webhook: {
    name: 'Webhook（第三方转发）',
    desc: '用第三方服务把邮件转发到本工作台',
    steps: [
      '准备一个能 POST 的服务（如 Zapier / n8n）',
      '设置一个自定义 Token（随便一串字母数字）',
      '服务那边 POST 到 本机 /api/mail/webhook/<你的Token>',
      '把同样的 Token 填到下面',
    ],
    fields: [
      { k: 'token', label: '回调 Token', ph: '你自己定的字符串，别用简单的',
        hint: ' 填好后回调地址是 /api/mail/webhook/你的Token' },
    ],
  },
  browser: {
    name: '浏览器读取（网页邮箱）',
    desc: '用已登录的指纹浏览器直接读网页邮箱',
    steps: [
      '先在工作台「指纹浏览器」页登录你的邮箱',
      '记下那个环境的编号',
      '把邮箱网址和环境编号填到下面',
      '拉取时会自动打开那个环境读页面',
    ],
    fields: [
      { k: 'url', label: '邮箱网页地址', ph: 'https://mail.qq.com' },
      { k: 'envCode', label: '环境编号', ph: '指纹浏览器里的容器编号' },
    ],
  },
  manual: {
    name: '手动录入（不接邮箱）',
    desc: '什么都不配，看到验证码自己填。最简单',
    steps: [
      '不用配任何服务器',
      '收到验证码邮件后，用「手动录入」弹窗填进去',
      '系统会当成普通邮件存起来，发布时能自动用',
    ],
    fields: [],
  },
};


let activeMail = null;
let filterCode = false;

export function render(root) {
  root.innerHTML = `
    ${pageHead({
      title: '邮箱与验证码',
      desc: 'IMAP 直连 / Webhook / 手动录入 · 自动提取验证码',
      actions: [
        `<button class="btn sm" data-act="pull"><span data-icon="refresh"></span>立即拉取</button>`,
        `<button class="btn sm ghost" data-act="manual"><span data-icon="plus"></span>手动录入</button>`,
      ],
    })}
    <div id="ml-body"></div>
  `;
  $$('[data-act="pull"]', root).forEach((b) => (b.onclick = () => doPull(b)));
  $$('[data-act="manual"]', root).forEach((b) => (b.onclick = openManual));
  paint(root);
  load(root);
}

async function load(root) {
  await store.loadMail({ limit: 100, onlyCode: filterCode });
  if (!activeMail && store.mails.length) activeMail = store.mails[0].id;
  paint(root);
}

function paint(root) {
  const body = $('#ml-body', root);
  if (!body) return;
  const mails = store.mails || [];
  const chans = store.channels || [];
  const st = store.mailStats || {};
  const cur = mails.find((m) => m.id === activeMail) || mails[0];

  body.innerHTML = `
    <div class="grid g4" style="margin-bottom:13px">
      ${statCard({ label: '邮件总数', value: st.total || mails.length, unit: '封', iconName: 'mail' })}
      ${statCard({ label: '含验证码', value: st.withCode || mails.filter((m) => m.code).length, unit: '封', iconName: 'key' })}
      ${statCard({ label: '可用通道', value: chans.filter((c) => c.enabled).length, unit: '条', iconName: 'plug' })}
      ${statCard({ label: '未读', value: st.unseen || 0, unit: '封', iconName: 'clock' })}
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">收件箱</div>
        <div style="display:flex;gap:7px;align-items:center">
          <div class="seg" data-seg="filter">
            <button class="${filterCode ? '' : 'on'}" data-v="all">全部</button>
            <button class="${filterCode ? 'on' : ''}" data-v="code">只看验证码</button>
          </div>
        </div>
      </div>
      <div class="card-body tight">
        <div class="mail-list">
          <div class="mail-items" id="ml-list">${mailRows(mails)}</div>
          <div class="mail-detail" id="ml-detail">${cur ? mailDetail(cur) : emptyState('没有邮件', '点「立即拉取」从 IMAP 取信')}</div>
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:13px">
      <div class="card-head">
        <div class="card-title">接入通道</div>
        <button class="btn xs ghost" data-act="addchan"><span data-icon="plus"></span>新增</button>
      </div>
      <div class="card-body tight">
        ${chans.length ? chans.map((c) => `
          <div class="litem" data-chan="${c.id}">
            <span class="dot ${c.enabled ? 'ok' : ''}"></span>
            <div class="litem-main">
              <div class="litem-title">${esc(c.label)}
                <span class="badge ${c.kind === 'imap' ? 'info' : c.kind === 'webhook' ? 'purple' : 'mute'}">${c.kind}</span>
                ${c.hasSecret ? badge('已配置凭据', 'ok') : badge('缺凭据', 'warn')}
              </div>
              <div class="litem-sub">${esc(c.config?.user || c.config?.host || '—')}</div>
            </div>
            <button class="btn xs ghost" data-test="${c.id}">测试</button>
          </div>`).join('')
          : '<div class="litem" style="justify-content:center;color:var(--tx-3)">无通道</div>'}
      </div>
    </div>

    <!-- 接入教程（可收缩） -->
    <details class="card" style="margin-bottom:13px">
      <summary style="padding:13px 16px;cursor:pointer;font-size:12.5px;font-weight:600;
                      user-select:none;list-style:none;display:flex;align-items:center;gap:8px">
        <span style="color:var(--ac)">${icon('plug', 15)}</span>
        邮箱接入教程
        <span class="chip" style="font-size:9.5px;margin-left:auto">点开看</span>
      </summary>
      <div class="card-body" style="border-top:1px solid var(--line-soft);padding:14px 16px">
        <div style="font-size:11.5px;line-height:1.85;color:var(--tx-1)">

          <div style="font-weight:600;color:var(--ac);margin-bottom:5px">方式一：IMAP 直连（推荐）</div>
          <div style="color:var(--tx-2);margin-bottom:10px">
            适用于 163 / Gmail / Outlook / QQ 邮箱。填 4 个字段就行：
            <div style="font-family:var(--mono);font-size:10.5px;background:var(--bg-0);
                        padding:8px 10px;border-radius:6px;margin:6px 0;line-height:1.8">
              主机 = imap.163.com（163）<br/>
              端口 = 993（SSL）<br/>
              账号 = 你的完整邮箱<br/>
              密码 = <b style="color:var(--warn)">授权码，不是登录密码</b>
            </div>
            <b>163 授权码怎么拿</b>：登录 mail.163.com → 设置 → POP3/SMTP/IMAP →
            开启 IMAP → 生成授权码 → 复制那串 16 位字母。
          </div>

          <div style="font-weight:600;color:var(--ac);margin-bottom:5px">方式二：Webhook 转发</div>
          <div style="color:var(--tx-2);margin-bottom:10px">
            邮箱不支持 IMAP 时用这个。在邮箱里设「自动转发」到 webhook 地址，
            邮件到了会 POST 过来。
            <div style="font-family:var(--mono);font-size:10.5px;background:var(--bg-0);
                        padding:8px 10px;border-radius:6px;margin:6px 0">
              POST http://127.0.0.1:8710/api/mail/webhook
            </div>
          </div>

          <div style="font-weight:600;color:var(--ac);margin-bottom:5px">方式三：手动录入</div>
          <div style="color:var(--tx-2);margin-bottom:10px">
            验证码页面直接复制过来，点右上「手动录入」。适合临时用、或者接不上的邮箱。
          </div>

          <div style="font-weight:600;color:var(--ac);margin-bottom:5px">常见邮箱服务器</div>
          <div class="tbl-wrap" style="margin-bottom:10px">
            <table class="tbl" style="font-size:10.5px">
              <thead><tr><th>邮箱</th><th>IMAP 主机</th><th>端口</th><th>密码类型</th></tr></thead>
              <tbody>
                <tr><td>163</td><td class="mono">imap.163.com</td><td>993</td><td>授权码</td></tr>
                <tr><td>126</td><td class="mono">imap.126.com</td><td>993</td><td>授权码</td></tr>
                <tr><td>QQ</td><td class="mono">imap.qq.com</td><td>993</td><td>授权码</td></tr>
                <tr><td>Gmail</td><td class="mono">imap.gmail.com</td><td>993</td><td>应用专用密码</td></tr>
                <tr><td>Outlook</td><td class="mono">outlook.office365.com</td><td>993</td><td>应用密码</td></tr>
                <tr><td>企业微信</td><td class="mono">imap.exmail.qq.com</td><td>993</td><td>客户端专用密码</td></tr>
              </tbody>
            </table>
          </div>

          <div style="padding:9px 11px;background:rgba(251,191,36,.08);border-radius:6px;
                      font-size:10.5px;color:var(--tx-2);line-height:1.7">
            <b style="color:var(--warn)">常见问题</b><br/>
            · <b>登录失败</b>：90% 是用登录密码而不是授权码<br/>
            · <b>搜不到邮件</b>：IMAP 要先 SELECT INBOX，程序已处理<br/>
            · <b>163 报 AUTH 错</b>：要先发 IMAP ID 命令，程序已内置<br/>
            · <b>验证码提取不到</b>：确认邮件正文有 4–8 位连续数字
          </div>
        </div>
      </div>
    </details>
  `;

  $$('[data-seg="filter"] button', root).forEach((b) => {
    b.onclick = () => { filterCode = b.dataset.v === 'code'; load(root); };
  });
  bindMails(root);
  $$('[data-test]', root).forEach((b) => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const id = b.dataset.test;
      b.disabled = true; b.textContent = '测试中';
      try {
        const r = await api.testChannel(id);
        toast(r.ok ? '连接成功' : '连接失败',
          r.ok ? `${r.messages ?? ''} 封邮件` : (r.error || ''), r.ok ? 'ok' : 'err', 5000);
      } catch (err) { toast('测试失败', err.message, 'err'); }
      finally { b.disabled = false; b.textContent = '测试'; }
    };
  });
  $$('[data-act="addchan"]', root).forEach((b) => (b.onclick = () => openAddChannel(root)));
  $$('[data-act="editchan"]', root).forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); openAddChannel(root, b.dataset.editchan); };
  });
}

function mailRows(mails) {
  if (!mails.length) {
    return '<div style="padding:30px;text-align:center;color:var(--tx-3);font-size:11.5px">无邮件</div>';
  }
  return mails.map((m) => `
    <div class="mail-row ${m.id === activeMail ? 'on' : ''}" data-mail="${m.id}">
      <div class="from">
        ${esc((m.mailbox || '').split('@')[0])}
        <span class="badge mute" style="font-size:9px">${m.source}</span>
        ${m.code ? '' : (m.seen ? '' : '<span class="dot warn" style="margin-left:auto"></span>')}
      </div>
      <div class="subj">${esc((m.subject || '').slice(0, 60))}</div>
      <div class="meta">
        <span>${m.received_at ? ts(m.received_at, true) : '—'}</span>
        ${m.code ? `<span class="mail-code" style="font-size:10px">${m.code}</span>` : ''}
      </div>
    </div>`).join('');
}

function mailDetail(m) {
  return `
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px">
      <div>
        <div style="font-size:14px;font-weight:600;margin-bottom:3px">${esc(m.subject || '')}</div>
        <div style="font-size:11px;color:var(--tx-3);font-family:var(--mono)">
          ${esc(m.sender || '')} → ${esc(m.mailbox || '')}
        </div>
        <div style="font-size:10.5px;color:var(--tx-3);margin-top:2px">
          ${m.received_at ? ts(m.received_at, true) : ''} · ${m.received_at ? ago(m.received_at) : ''}
        </div>
      </div>
      ${m.code ? `<div style="text-align:right">
        <div style="font-size:9.5px;color:var(--tx-3);margin-bottom:3px">提取的验证码</div>
        <div class="mail-code" style="font-size:17px;letter-spacing:2px;padding:4px 11px">${m.code}</div>
      </div>` : ''}
    </div>
    ${m.matched ? `<div class="field"><label>匹配</label><div>${badge(m.matched, 'info')}</div></div>` : ''}
    <div class="section-title">正文</div>
    <div class="term" style="max-height:280px">
      ${(m.body || '').split('\n').slice(0, 40).map((l) =>
        `<div class="ln"><span class="msg">${esc(l)}</span></div>`).join('')}
    </div>
    <div style="display:flex;gap:7px;margin-top:13px">
      ${m.code ? `<button class="btn sm primary" data-copy="${m.code}">复制验证码</button>` : ''}
      <button class="btn sm ghost" data-seen="${m.id}">标记已读</button>
    </div>`;
}

function bindMails(root) {
  $$('[data-mail]', root).forEach((el) => {
    el.onclick = () => {
      activeMail = el.dataset.mail;
      const m = (store.mails || []).find((x) => x.id === activeMail);
      $('#ml-list', root).innerHTML = mailRows(store.mails || []);
      $('#ml-detail', root).innerHTML = m ? mailDetail(m) : '';
      bindMails(root);
      bindDetail(root, m);
    };
  });
  bindDetail(root, (store.mails || []).find((x) => x.id === activeMail));
}

function bindDetail(root, m) {
  $$('[data-copy]', root).forEach((b) => (b.onclick = () => copyText(b.dataset.copy)));
  $$('[data-seen]', root).forEach((b) => {
    b.onclick = async () => {
      try {
        await api.markSeen(b.dataset.seen);
        const x = (store.mails || []).find((v) => v.id === b.dataset.seen);
        if (x) x.seen = 1;
        toast('已标记', '已读', 'ok');
      } catch (e) { toast('失败', e.message, 'err'); }
    };
  });
}

async function doPull(btn) {
  btn.disabled = true;
  const old = btn.innerHTML;
  btn.innerHTML = '<span class="spin" data-icon="refresh"></span>拉取中…';
  try {
    const r = await api.pullMail({ sinceMinutes: 10080, limit: 40 });
    toast('拉取完成', `新邮件 ${r.fetched} 封${(r.errors || []).length ? ' · ' + r.errors.length + ' 个通道失败' : ''}`,
      (r.errors || []).length ? 'warn' : 'ok', 5000);
    await load(document.getElementById('view'));
  } catch (e) {
    toast('拉取失败', e.message, 'err');
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

function openManual() {
  const body = document.createElement('div');
  body.innerHTML = `
    <div class="mn-tip">
      <b>这是干什么的？</b><br>
      当你不接邮箱、或者邮箱拉不到验证码时，用这里手动把收到的验证码存进系统。
      存好后「收件箱」和「最新验证码」接口就能读到它，
      发布、授权时能自动带上。<br><br>
      <b>怎么用：</b><br>
      ① 打开你的邮箱（手机/电脑都行）→ 找到刚收到的那封验证码邮件<br>
      ② 把 6-8 位数字抄下来<br>
      ③ 在下面填进去 → 点保存<br>
      ④ 去「收件箱」看，能看到这条记录
    </div>
    <div class="field"><label>邮箱（这条验证码是哪个邮箱收到的）</label>
      <input class="input" id="mn-mb" value="manual@local"
        placeholder="可以填真实邮箱，也可以留默认" /></div>
    <div class="field"><label>验证码</label>
      <input class="input" id="mn-code" placeholder="6-8 位数字"
        style="font-family:var(--mono)" /></div>
    <div class="field"><label>备注（可选，方便以后认出来）</label>
      <input class="input" id="mn-subj" placeholder="例如 FB 主页授权 / 网易号登录" /></div>`;
  const m = modal({
    title: '手动录入验证码', body,
    footer: [
      Object.assign(document.createElement('button'), { className: 'btn', textContent: '取消', onclick: () => m.close() }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存',
        onclick: async () => {
          const code = (body.querySelector('#mn-code').value || '').trim();
          if (!code) return toast('请输入验证码', '', 'err');
          try {
            await api.manualMail({
              mailbox: body.querySelector('#mn-mb').value,
              code,
              subject: body.querySelector('#mn-subj').value || '手动录入',
            });
            toast('已保存', code, 'ok');
            m.close();
            await load(document.getElementById('view'));
          } catch (e) { toast('失败', e.message, 'err'); }
        },
      }),
    ],
  });
}

function esc(s) {
  return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ══════════════════════════════════════════
   新增 / 编辑 通道
   ══════════════════════════════════════════ */
async function openAddChannel(root, editId) {
  // 读现有通道（编辑时）
  let cur = null;
  if (editId) {
    try {
      const r = await api.mailChannels();
      cur = (r.items || r.channels || []).find((x) => x.id === editId);
    } catch (e) { /* ignore */ }
  }

  const kindSel = Object.keys(CH_KINDS).map((k) =>
    `<option value="${k}" ${cur && cur.kind === k ? 'selected' : ''}>
      ${esc(CH_KINDS[k].name)}</option>`).join('');

  const body = document.createElement('div');
  body.innerHTML = `
    <div class="ch-tip">
      选一种接入方式，按下面的步骤做。<b>不确定选哪个？选「IMAP 邮箱」</b>
      ——QQ、163、企业邮箱都支持，最常见最好用。
    </div>
    <div class="field"><label>接入方式</label>
      <select class="input" id="ch-kind">${kindSel}</select></div>
    <div id="ch-detail"></div>
    <div class="field"><label>给它起个名（方便区分）</label>
      <input class="input" id="ch-label"
        value="${cur ? esc(cur.label || '') : ''}"
        placeholder="例如 QQ 主号邮箱 / 网易发号邮箱" /></div>
    <div id="ch-steps"></div>`;

  const draw = () => {
    const kind = body.querySelector('#ch-kind').value;
    const cfg = CH_KINDS[kind] || { fields: [], steps: [], desc: '' };
    const fields = (cfg.fields || []).map((f) => {
      const old = cur && cur.config ? (cur.config[f.k] || '') : '';
      const isPw = /password|secret|token/i.test(f.k);
      return `<div class="field">
        <label>${esc(f.label)}</label>
        <input class="input" id="ch-f-${f.k}"
          type="${isPw ? 'password' : 'text'}"
          value="${esc(old || f.def || '')}"
          placeholder="${esc(f.ph || '')}" />
        ${f.hint ? `<div class="fhint">${esc(f.hint)}</div>` : ''}
      </div>`;
    }).join('');
    body.querySelector('#ch-detail').innerHTML =
      `<div class="ch-desc">${esc(cfg.desc || '')}</div>` + fields;

    const steps = (cfg.steps || []).map((st, i) =>
      `<li><span class="sn">${i + 1}</span>${esc(st)}</li>`).join('');
    body.querySelector('#ch-steps').innerHTML = steps
      ? `<div class="ch-stepsbox"><div class="cst">操作步骤</div>
         <ol class="ch-steps">${steps}</ol></div>`
      : '';
  };

  const m = modal({
    title: editId ? '编辑邮箱通道' : '新增邮箱通道',
    body, width: 'wide',
    footer: [
      Object.assign(document.createElement('button'), {
        className: 'btn', textContent: '取消',
        onclick: () => m.close(),
      }),
      Object.assign(document.createElement('button'), {
        className: 'btn primary', textContent: '保存通道',
        onclick: async () => {
          const kind = body.querySelector('#ch-kind').value;
          const cfg = CH_KINDS[kind] || {};
          const config = {};
          for (const f of (cfg.fields || [])) {
            const el = body.querySelector('#ch-f-' + f.k);
            if (el && el.value.trim()) config[f.k] = el.value.trim();
          }
          const label = (body.querySelector('#ch-label').value || '').trim()
            || cfg.name || kind;
          try {
            await api.saveChannel({
              id: editId || '', kind, label, enabled: true, config,
            });
            toast('已保存', label, 'ok');
            m.close();
            await load(root);
          } catch (e) { toast('保存失败', e.message, 'err'); }
        },
      }),
    ],
  });

  body.querySelector('#ch-kind').onchange = draw;
  draw();
}

